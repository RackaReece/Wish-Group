import { useState, useEffect, useCallback } from 'react';

/**
 * Hook for lazy loading components with code splitting
 */
export function useLazyComponent<T>(
  importFn: () => Promise<{ default: React.ComponentType<T> }>,
  fallback?: React.ReactNode
) {
  const [Component, setComponent] = useState<React.ComponentType<T> | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  useEffect(() => {
    let mounted = true;

    importFn()
      .then((module) => {
        if (mounted) {
          setComponent(() => module.default);
          setLoading(false);
        }
      })
      .catch((err) => {
        if (mounted) {
          setError(err);
          setLoading(false);
        }
      });

    return () => {
      mounted = false;
    };
  }, [importFn]);

  return { Component, loading, error, fallback };
}

/**
 * Preload a component for faster subsequent loads
 */
export function usePreloadComponent(importFn: () => Promise<any>) {
  const preload = useCallback(() => {
    importFn().catch(() => {
      // Silently fail preload
    });
  }, [importFn]);

  return { preload };
}

