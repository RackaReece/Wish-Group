import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { AISchedulingService } from '../../services/AISchedulingService';
import { colors } from '../../constants/colors';

const SKY = colors.SKY;

interface PriceOptimizationCardProps {
  valeterId: string;
  serviceType: string;
  location: { latitude: number; longitude: number };
  scheduledAt?: string;
  onPriceSelect?: (price: number) => void;
}

export default function PriceOptimizationCard({
  valeterId,
  serviceType,
  location,
  scheduledAt,
  onPriceSelect,
}: PriceOptimizationCardProps) {
  const [optimization, setOptimization] = useState<Awaited<ReturnType<typeof AISchedulingService.getPriceOptimization>> | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadOptimization();
  }, [valeterId, serviceType, location, scheduledAt]);

  const loadOptimization = async () => {
    try {
      setLoading(true);
      const data = await AISchedulingService.getPriceOptimization(valeterId, serviceType, location, scheduledAt);
      setOptimization(data);
    } catch (error) {
      console.error('Error loading price optimization:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="small" color={SKY} />
          <Text style={styles.loadingText}>Calculating optimal price...</Text>
        </View>
      </View>
    );
  }

  if (!optimization || optimization.multiplier === 1.0) {
    return null;
  }

  const priceDiff = optimization.suggestedPrice - optimization.basePrice;
  const isHigher = priceDiff > 0;

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['rgba(135,206,235,0.15)', 'rgba(30,58,138,0.1)']}
        style={styles.card}
      >
        <View style={styles.header}>
          <View style={styles.headerLeft}>
            <Ionicons name="trending-up" size={20} color={SKY} />
            <Text style={styles.title}>AI Price Suggestion</Text>
          </View>
          <View style={[styles.priceBadge, isHigher && styles.priceBadgeHigher]}>
            <Text style={styles.priceBadgeText}>
              {isHigher ? '+' : ''}£{Math.abs(priceDiff)}
            </Text>
          </View>
        </View>

        <View style={styles.priceRow}>
          <View>
            <Text style={styles.label}>Base Price</Text>
            <Text style={styles.basePrice}>£{optimization.basePrice}</Text>
          </View>
          <Ionicons name="arrow-forward" size={20} color={SKY} style={{ marginHorizontal: 12 }} />
          <View>
            <Text style={styles.label}>Suggested</Text>
            <Text style={styles.suggestedPrice}>£{optimization.suggestedPrice}</Text>
          </View>
        </View>

        {optimization.factors.length > 0 && (
          <View style={styles.factorsContainer}>
            <Text style={styles.factorsTitle}>Price Factors:</Text>
            {optimization.factors.map((factor, index) => (
              <View key={index} style={styles.factor}>
                <Ionicons
                  name={factor.impact > 0 ? 'arrow-up' : 'arrow-down'}
                  size={12}
                  color={factor.impact > 0 ? '#10B981' : '#EF4444'}
                />
                <Text style={styles.factorText}>
                  {factor.name}: {factor.description}
                </Text>
              </View>
            ))}
          </View>
        )}

        <TouchableOpacity
          style={styles.applyButton}
          onPress={() => onPriceSelect?.(optimization.suggestedPrice)}
          activeOpacity={0.8}
        >
          <LinearGradient colors={[SKY, '#3B82F6']} style={styles.applyGradient}>
            <Text style={styles.applyText}>Apply Suggested Price</Text>
          </LinearGradient>
        </TouchableOpacity>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 16,
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  card: {
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  headerLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  title: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  priceBadge: {
    backgroundColor: '#10B981',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  priceBadgeHigher: {
    backgroundColor: '#F59E0B',
  },
  priceBadgeText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '700',
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  label: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    marginBottom: 4,
  },
  basePrice: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 18,
    fontWeight: '600',
  },
  suggestedPrice: {
    color: SKY,
    fontSize: 20,
    fontWeight: 'bold',
  },
  factorsContainer: {
    marginBottom: 16,
  },
  factorsTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  factor: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  factorText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
  },
  applyButton: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  applyGradient: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  applyText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
});

