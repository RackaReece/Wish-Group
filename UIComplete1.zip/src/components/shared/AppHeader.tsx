import React, { useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Animated,
  Platform,
  Dimensions,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { AccountType, getAccountTheme } from '../../constants/accountThemes';
import { useAccountTheme } from './AccountThemeProvider';

const { width } = Dimensions.get('window');
// Header content heights (not including safe area or padding)
export const HEADER_CONTENT_HEIGHT = 64;
export const DASHBOARD_HEADER_CONTENT_HEIGHT = 88;
// Total header heights including padding (for calculating page padding)
// Formula: top padding (12/16) + content height + bottom padding (16/20)
export const HEADER_HEIGHT = 12 + HEADER_CONTENT_HEIGHT + 16; // = 92
export const DASHBOARD_HEADER_HEIGHT = 16 + DASHBOARD_HEADER_CONTENT_HEIGHT + 20; // = 124

// Standard spacing to position content directly beneath the header.
// These offsets already include the safe-area padding applied inside the header.
export const HEADER_CONTENT_OFFSET = HEADER_HEIGHT + 12;
export const DASHBOARD_HEADER_CONTENT_OFFSET = DASHBOARD_HEADER_HEIGHT + 16;

interface AppHeaderProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  rightAction?: React.ReactNode;
  variant?: 'default' | 'dashboard';
  scrollY?: Animated.Value;
  enableScrollAnimation?: boolean;
  accountType?: AccountType;
  showBack?: boolean;
  points?: number;
  businessName?: string;
  businessAddress?: string;
  businessRating?: number;
}

export default function AppHeader({
  title,
  subtitle,
  onBack,
  rightAction,
  variant = 'default',
  scrollY,
  enableScrollAnimation = false,
  accountType,
  showBack = true,
  points,
  businessName,
  businessAddress,
  businessRating,
}: AppHeaderProps) {
  const insets = useSafeAreaInsets();
  const defaultScrollY = useRef(new Animated.Value(0)).current;
  const scrollPosition = scrollY || defaultScrollY;
  
  const contextTheme = useAccountTheme();
  const theme = accountType 
    ? getAccountTheme(accountType)
    : contextTheme.theme;

  const headerOpacity = enableScrollAnimation
    ? scrollPosition.interpolate({
        inputRange: [0, 50, 100],
        outputRange: [1, 0.98, 0.96],
        extrapolate: 'clamp',
      })
    : 1;

  const handleBack = async () => {
    await hapticFeedback('light');
    if (onBack) {
      onBack();
    } else {
      router.back();
    }
  };

  const isDashboard = variant === 'dashboard';
  const headerContentHeight = isDashboard ? DASHBOARD_HEADER_CONTENT_HEIGHT : HEADER_CONTENT_HEIGHT;

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <Animated.View
        style={[
          styles.container,
          { 
            opacity: headerOpacity,
            borderBottomLeftRadius: 24,
            borderBottomRightRadius: 24,
          },
        ]}
      >
        <BlurView
          intensity={Platform.OS === 'ios' ? 40 : 30}
          tint="dark"
          style={StyleSheet.absoluteFill}
        >
          <LinearGradient
            colors={theme.headerBackground || theme.background}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
          <View style={StyleSheet.absoluteFill} pointerEvents="none">
            <LinearGradient
              colors={[`${theme.primary}15`, 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
          </View>
        </BlurView>

        <View style={[styles.glowLine, { 
          backgroundColor: `${theme.primary}50`,
          shadowColor: theme.primary,
        }]} />

        <View style={[styles.content, { 
          paddingTop: insets.top + (isDashboard ? 16 : 12),
          minHeight: headerContentHeight,
          paddingBottom: isDashboard ? 20 : 16,
        }]}>
          <View style={styles.leftSection}>
            {showBack && (
              <TouchableOpacity
                onPress={handleBack}
                style={styles.backButton}
                activeOpacity={0.7}
              >
                <Ionicons name="chevron-back" size={22} color={theme.primary} />
              </TouchableOpacity>
            )}
            <View style={styles.titleContainer}>
              {isDashboard && businessName ? (
                <>
                  <Text 
                    style={[
                      styles.title,
                      styles.titleDashboard,
                      { color: '#FFFFFF' }
                    ]} 
                    numberOfLines={1} 
                    ellipsizeMode="tail"
                  >
                    {businessName}
                  </Text>
                  {businessAddress && (
                    <View style={styles.businessInfoRow}>
                      <Ionicons name="location" size={12} color={theme.primary} style={{ marginRight: 4 }} />
                      <Text 
                        style={[styles.businessAddress, { color: theme.primary }]} 
                        numberOfLines={1} 
                        ellipsizeMode="tail"
                      >
                        {businessAddress}
                      </Text>
                    </View>
                  )}
                  {businessRating !== undefined && businessRating > 0 && (
                    <View style={styles.businessInfoRow}>
                      <Ionicons name="star" size={12} color="#FFD700" style={{ marginRight: 4 }} />
                      <Text 
                        style={[styles.businessRating, { color: '#FFD700' }]} 
                        numberOfLines={1}
                      >
                        {businessRating.toFixed(1)}
                      </Text>
                    </View>
                  )}
                </>
              ) : (
                <>
                  <Text 
                    style={[
                      styles.title,
                      isDashboard && styles.titleDashboard,
                      { color: '#FFFFFF' }
                    ]} 
                    numberOfLines={1} 
                    ellipsizeMode="tail"
                  >
                    {title || ' '}
                  </Text>
                  {subtitle && (
                    <Text 
                      style={[styles.subtitle, { color: theme.primary }]} 
                      numberOfLines={1} 
                      ellipsizeMode="tail"
                    >
                      {subtitle}
                    </Text>
                  )}
                </>
              )}
            </View>
          </View>

          <View style={styles.rightSection}>
            {isDashboard && points !== undefined && (
              <View style={styles.pointsBadge}>
                <Ionicons name="trophy" size={14} color="#FFD700" />
                <Text style={styles.pointsText}>{points} pts</Text>
              </View>
            )}
            {rightAction && rightAction}
          </View>
        </View>
      </Animated.View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    overflow: 'hidden',
    backgroundColor: 'transparent',
  },
  glowLine: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 8,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 16,
    zIndex: 200,
    elevation: 12,
    position: 'relative',
  },
  leftSection: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    minWidth: 0,
    zIndex: 200,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    flexShrink: 0,
  },
  titleContainer: {
    flex: 1,
    gap: 2,
    minWidth: 0,
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: '700',
    letterSpacing: 0.3,
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
    includeFontPadding: false,
    lineHeight: 24,
  },
  titleDashboard: {
    fontSize: 28,
    lineHeight: 32,
    fontWeight: '800',
  },
  subtitle: {
    fontSize: 13,
    fontWeight: '600',
    opacity: 0.9,
    marginTop: 1,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
    includeFontPadding: false,
  },
  rightSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginLeft: 12,
    zIndex: 200,
    elevation: 12,
  },
  pointsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255, 215, 0, 0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 215, 0, 0.3)',
  },
  pointsText: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  businessInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  businessAddress: {
    fontSize: 12,
    fontWeight: '500',
    opacity: 0.9,
    flex: 1,
  },
  businessRating: {
    fontSize: 12,
    fontWeight: '600',
  },
});

