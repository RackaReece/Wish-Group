import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Animated } from 'react-native';

export type StatusType = 'available' | 'busy' | 'offline';

interface StatusDotProps {
  status: StatusType;
  pulseOnChange?: boolean;
  size?: number;
}

const statusColors: Record<StatusType, string> = {
  available: '#10B981', // Green
  busy: '#F59E0B', // Yellow
  offline: '#6B7280', // Gray
};

export default function StatusDot({ 
  status, 
  pulseOnChange = true, 
  size = 12 
}: StatusDotProps) {
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const opacityAnim = useRef(new Animated.Value(1)).current;
  const previousStatusRef = useRef<StatusType>(status);

  useEffect(() => {
    if (pulseOnChange && previousStatusRef.current !== status) {
      // Trigger pulse animation when status changes
      Animated.sequence([
        Animated.parallel([
          Animated.timing(scaleAnim, {
            toValue: 1.5,
            duration: 200,
            useNativeDriver: true,
          }),
          Animated.timing(opacityAnim, {
            toValue: 0.6,
            duration: 200,
            useNativeDriver: true,
          }),
        ]),
        Animated.parallel([
          Animated.timing(scaleAnim, {
            toValue: 1,
            duration: 200,
            useNativeDriver: true,
          }),
          Animated.timing(opacityAnim, {
            toValue: 1,
            duration: 200,
            useNativeDriver: true,
          }),
        ]),
      ]).start();

      previousStatusRef.current = status;
    }
  }, [status, pulseOnChange, scaleAnim, opacityAnim]);

  return (
    <Animated.View
      style={[
        styles.container,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          backgroundColor: statusColors[status],
          transform: [{ scale: scaleAnim }],
          opacity: opacityAnim,
        },
      ]}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
});

