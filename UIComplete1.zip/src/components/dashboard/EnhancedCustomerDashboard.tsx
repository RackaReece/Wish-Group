import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Easing,
  Dimensions,
  ScrollView,
  Modal,
  ActivityIndicator,
  StatusBar,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../providers/enhanced-auth-context';
import { supabase } from '../../lib/supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import CarCareInfoHub from '../car-care/CarCareInfoHub';
import GradientNotificationBell from '../shared/GradientNotificationBell';
import AppHeader, { DASHBOARD_HEADER_CONTENT_OFFSET } from '../shared/AppHeader';
import BubbleBackground from '../shared/BubbleBackground';
import useLiveLocation from '../../hooks/useLiveLocation';
import { customerTheme } from '../../constants/customerTheme';
import { colors } from '../../constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY;

interface NearbyValeter {
  id: string;
  name: string;
  organization: string;
  rating: number;
  distance: number | null;
  isOnline: boolean;
}

interface QuickAction {
  id: string;
  title: string;
  subtitle: string;
  iconName: keyof typeof Ionicons.glyphMap;
  gradient: string[];
  route: string;
}

interface LoyaltyData {
  points: number;
  tier: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  pointsToNextTier: number;
  nextReward?: string;
}


interface PromotionalOffer {
  offerText: string;
  expiryTime?: Date;
  discountPercent?: number;
}

interface LastBooking {
  id: string;
  serviceType: string;
  serviceName: string;
  location?: {
    address?: string;
    latitude?: number;
    longitude?: number;
  };
  vehicleType?: string;
  vehicleInfo?: string;
}



export default function EnhancedCustomerDashboard() {
  const { user } = useAuth();
  const [nearbyValeters, setNearbyValeters] = useState<NearbyValeter[]>([]);
  const [showCarCareHub, setShowCarCareHub] = useState(false);
  const [loading, setLoading] = useState(true);
  const [profileName, setProfileName] = useState<string>('');
  const [notificationCount, setNotificationCount] = useState(0);
  const [lastBooking, setLastBooking] = useState<LastBooking | null>(null);
  
  // Revenue-driving features data (ready for backend integration)
  // These will be populated from backend - components show empty state when null/empty
  // TEMPORARY: Adding test data to visualize components - remove when backend is ready
  const [loyaltyData] = useState<LoyaltyData | null>({
    points: 850,
    tier: 'Silver',
    pointsToNextTier: 150,
    nextReward: '50 points = 10% off next wash',
  });
  const [promotionalOffer] = useState<PromotionalOffer | null>({
    offerText: '20% off your first booking',
    expiryTime: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours from now
    discountPercent: 20,
  });
  const {
    refresh,
  } = useLiveLocation();
  // Match the exact statuses used by the notifications page
  const notificationStatuses = useMemo(() => [
    'pending',
    'pending_valeter_acceptance',
    'pending_payment',
    'confirmed',
    'valeter_assigned',
    'en_route',
    'arrived',
    'in_progress',
    'scheduled',
    'completed',
    'cancelled',
  ], []);

  const refreshRef = useRef(refresh);
  useEffect(() => {
    refreshRef.current = refresh;
  }, [refresh]);

  useEffect(() => {
    const interval = setInterval(() => {
      refreshRef.current?.();
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(1)).current;

  // Promotional banner pulse animation
  useEffect(() => {
    if (promotionalOffer) {
      const pulse = Animated.loop(
        Animated.sequence([
          Animated.timing(fadeAnim, {
            toValue: 0.7,
            duration: 1500,
            easing: Easing.inOut(Easing.ease),
            useNativeDriver: true,
          }),
          Animated.timing(fadeAnim, {
            toValue: 1,
            duration: 1500,
            easing: Easing.inOut(Easing.ease),
            useNativeDriver: true,
          }),
        ])
      );
      pulse.start();
      return () => {
        pulse.stop();
      };
    }
    return undefined;
  }, [promotionalOffer, fadeAnim]);

  // Animated bubbles for header background - Slow and smooth
  const bubbleData = useRef(
    Array.from({ length: 8 }, (_, index) => {
      const random = Math.random();
      return {
        translateY: new Animated.Value(0),
        opacity: new Animated.Value(0.2 + random * 0.2),
        scale: new Animated.Value(0.6 + random * 0.3),
        size: 20 + random * 30,
        leftPosition: width * 0.6 + (random * width * 0.3),
        delay: index * 800,
        duration: 12000 + random * 8000, // Much slower: 12-20 seconds
        startY: 120 + random * 40,
        endY: -60,
        initialOpacity: 0.2 + random * 0.2,
      };
    })
  ).current;

  useEffect(() => {
    // Start bubble animations - Slow and smooth
    bubbleData.forEach((bubble) => {
      // Set initial position
      bubble.translateY.setValue(bubble.startY);
      bubble.opacity.setValue(bubble.initialOpacity);

      const animateBubble = () => {
        Animated.parallel([
          Animated.loop(
            Animated.sequence([
              Animated.delay(bubble.delay),
              Animated.timing(bubble.translateY, {
                toValue: bubble.endY,
                duration: bubble.duration,
                // Linear easing - default behavior, no easing needed
                useNativeDriver: true,
              }),
              Animated.timing(bubble.translateY, {
                toValue: bubble.startY,
                duration: 0,
                useNativeDriver: true,
              }),
            ])
          ),
          Animated.loop(
            Animated.sequence([
              Animated.timing(bubble.opacity, {
                toValue: 0.35, // Subtle opacity change
                duration: bubble.duration / 3,
                easing: Easing.inOut(Easing.ease), // Smooth easing
                useNativeDriver: true,
              }),
              Animated.timing(bubble.opacity, {
                toValue: 0.15, // Subtle opacity change
                duration: bubble.duration / 3,
                easing: Easing.inOut(Easing.ease), // Smooth easing
                useNativeDriver: true,
              }),
              Animated.timing(bubble.opacity, {
                toValue: bubble.initialOpacity,
                duration: bubble.duration / 3,
                easing: Easing.inOut(Easing.ease), // Smooth easing
                useNativeDriver: true,
              }),
            ])
          ),
        ]).start();
      };

      animateBubble();
    });
  }, []);

  useEffect(() => {
    if (!user?.id) return;
    let isMounted = true;
    const DISMISSED_STORAGE_KEY = 'wishawash:dismissed-notifications-v1';
    
    // Helper functions matching notifications page exactly
    const fetchVehicleReminders = async (userId: string): Promise<Array<{ id: string; type: 'vehicle_reminder' }>> => {
      try {
        const { data: vehicles, error } = await supabase
          .from('customer_vehicles')
          .select('id,make,model,registration,tax_expiry,mot_expiry')
          .eq('user_id', userId);

        if (error || !vehicles) return [];

        const reminders: Array<{ id: string; type: 'vehicle_reminder' }> = [];
        const now = new Date();
        const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

        vehicles.forEach((vehicle) => {
          if (vehicle.tax_expiry) {
            const taxExpiry = new Date(vehicle.tax_expiry);
            if (taxExpiry <= thirtyDaysFromNow && taxExpiry >= now) {
              reminders.push({
                id: `tax-reminder-${vehicle.id}`,
                type: 'vehicle_reminder',
              });
            }
          }
          if (vehicle.mot_expiry) {
            const motExpiry = new Date(vehicle.mot_expiry);
            if (motExpiry <= thirtyDaysFromNow && motExpiry >= now) {
              reminders.push({
                id: `mot-reminder-${vehicle.id}`,
                type: 'vehicle_reminder',
              });
            }
          }
        });

        return reminders;
      } catch (error) {
        console.warn('[CustomerDashboard] Vehicle reminders error', error);
        return [];
      }
    };

    const fetchRewardNotifications = async (userId: string): Promise<Array<{ id: string; type: 'reward' }>> => {
      try {
        const { data: userData, error } = await supabase
          .from('users')
          .select('tier_points,tier')
          .eq('id', userId)
          .single();

        if (error || !userData) return [];

        const notifications: Array<{ id: string; type: 'reward' }> = [];
        const points = userData.tier_points || 0;
        const milestones = [500, 1000, 2000, 3000, 5000];
        const nextMilestone = milestones.find(m => m > points);
        
        if (nextMilestone && points > 0) {
          const pointsNeeded = nextMilestone - points;
          if (pointsNeeded <= 100) {
            notifications.push({
              id: `reward-milestone-${nextMilestone}`,
              type: 'reward',
            });
          }
        }

        return notifications;
      } catch (error) {
        console.warn('[CustomerDashboard] Reward notifications error', error);
        return [];
      }
    };
    
    const fetchNotificationCount = async () => {
      try {
        // Use EXACT same query as notifications page
        const [bookingsResult, vehicleReminders, rewardNotifications] = await Promise.all([
          supabase
            .from('bookings')
            .select('id,status,service_name,service_type,price,created_at,updated_at,scheduled_at,time_slot,location_address,address,valeter_name')
            .eq('user_id', user.id)
            .in('status', notificationStatuses as any)
            .order('created_at', { ascending: false })
            .limit(100),
          fetchVehicleReminders(user.id),
          fetchRewardNotifications(user.id),
        ]);
        
        if (!isMounted) return;
        
        // Process bookings - create notification IDs exactly like notifications page
        const bookingNotifications: Array<{ id: string; type: 'booking' }> = [];
        if (!bookingsResult.error && bookingsResult.data) {
          bookingNotifications.push(...bookingsResult.data.map(b => ({
            id: `booking-${b.id}`,
            type: 'booking' as const,
          })));
        }
        
        // Combine all notifications
        const allNotifications = [
          ...bookingNotifications,
          ...vehicleReminders,
          ...rewardNotifications,
        ];
        
        // Load dismissed notifications from storage
        try {
          const raw = await AsyncStorage.getItem(DISMISSED_STORAGE_KEY);
          const dismissedStore = raw ? JSON.parse(raw) : {};
          const dismissedIds = new Set(dismissedStore[user.id] || []);
          
          // Filter out dismissed notifications
          const visibleNotifications = allNotifications.filter(notif => {
            return !dismissedIds.has(notif.id);
          });
          
          const visibleCount = visibleNotifications.length;
          
          // Debug logging
          console.log('[CustomerDashboard] Notification count:', {
            total: allNotifications.length,
            dismissed: dismissedIds.size,
            visible: visibleCount,
            bookingCount: bookingNotifications.length,
            vehicleCount: vehicleReminders.length,
            rewardCount: rewardNotifications.length,
            dismissedIds: Array.from(dismissedIds),
          });
          
          setNotificationCount(visibleCount);
        } catch (storageError) {
          // If storage read fails, show all notifications
          console.warn('[CustomerDashboard] Storage read error:', storageError);
          setNotificationCount(allNotifications.length);
        }
      } catch (error) {
        if (isMounted) {
          console.warn('[CustomerDashboard] Notification count exception:', error);
          setNotificationCount(0);
        }
      }
    };

    fetchNotificationCount();
    const interval = setInterval(fetchNotificationCount, 45000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [user?.id, notificationStatuses]);

  // Load profile name
  useEffect(() => {
    if (!user?.id) return;
    const loadProfileName = async () => {
      const { data: profileData } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', user.id)
        .maybeSingle();
      
      if (profileData) {
        setProfileName(profileData.full_name || user.name || 'Customer');
      } else {
        setProfileName(user.name || 'Customer');
      }
    };
    loadProfileName();
  }, [user?.id]);

  // Load last completed booking
  useEffect(() => {
    if (!user?.id) return;
    const loadLastBooking = async () => {
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('id, service_type, service_name, location_address, location_lat, location_lng, vehicle_type, vehicle_info')
          .eq('user_id', user.id)
          .eq('status', 'completed')
          .order('completed_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (error) {
          console.warn('[CustomerDashboard] Error loading last booking:', error);
          return;
        }

        if (data) {
          const booking: LastBooking = {
            id: data.id,
            serviceType: data.service_type || '',
            serviceName: data.service_name || data.service_type || '',
            vehicleType: data.vehicle_type || undefined,
            vehicleInfo: data.vehicle_info || undefined,
          };
          
          if (data.location_address) {
            booking.location = {
              address: data.location_address,
              ...(data.location_lat && { latitude: data.location_lat }),
              ...(data.location_lng && { longitude: data.location_lng }),
            };
          }
          
          setLastBooking(booking);
        }
      } catch (error) {
        console.error('[CustomerDashboard] Exception loading last booking:', error);
      }
    };
    loadLastBooking();
  }, [user?.id]);


  const loadNearbyValeters = async () => {
    if (!user?.id) return;
    try {
      const { data: presence, error: presErr } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online')
        .eq('is_online', true);

      if (presErr) console.warn('[NearbyValeters] presence error:', presErr);
      if (!presence || presence.length === 0) {
        setNearbyValeters([]);
        return;
      }

      const ids = presence.map((p) => p.user_id);
      const { data: profiles } = await supabase
        .from('valeter_profiles')
        .select('user_id, display_name, company_name')
        .in('user_id', ids);

      // TODO: Calculate actual distance from user location to valeter location
      // For now, set distance to null - it will be calculated when user location is available
      const list: NearbyValeter[] = (presence || []).map((p) => {
        const profile = profiles?.find((pr) => pr.user_id === p.user_id);
        return {
          id: p.user_id,
          name: profile?.display_name || 'Valeter',
          organization: profile?.company_name || 'Independent',
          rating: 4.5, // TODO: Load actual rating from reviews table
          distance: null, // TODO: Calculate actual distance
          isOnline: p.is_online,
        };
      });

      setNearbyValeters(list.slice(0, 8));
    } catch (e) {
      console.error('[NearbyValeters] load error:', e);
      setNearbyValeters([]);
    }
  };

  useEffect(() => {
    loadNearbyValeters();
    const interval = setInterval(loadNearbyValeters, 30000);
    return () => clearInterval(interval);
  }, [user?.id]);

  // Set loading to false once user is available
  useEffect(() => {
    if (user?.id) {
      // Small delay to allow initial data to load
      const timer = setTimeout(() => {
        setLoading(false);
      }, 500);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, [user?.id]);





  const handleNotificationPress = () => {
    router.push('/owner/features/notifications');
  };

  const handleRepeatBooking = () => {
    if (!lastBooking) return;
    
    // Navigate to appropriate booking flow based on service type
    if (lastBooking.serviceType?.includes('detailing')) {
      router.push({
        pathname: '/owner/booking/detailing/create',
        params: {
          ...(lastBooking.location?.address && { address: lastBooking.location.address }),
          ...(lastBooking.location?.latitude && { latitude: lastBooking.location.latitude.toString() }),
          ...(lastBooking.location?.longitude && { longitude: lastBooking.location.longitude.toString() }),
          ...(lastBooking.vehicleType && { vehicleType: lastBooking.vehicleType }),
          ...(lastBooking.vehicleInfo && { vehicleInfo: lastBooking.vehicleInfo }),
        },
      });
    } else if (lastBooking.serviceType?.includes('eco')) {
      router.push({
        pathname: '/owner/booking/eco/create',
        params: {
          deliveryType: 'comeToYou',
          ...(lastBooking.location?.address && { address: lastBooking.location.address }),
          ...(lastBooking.location?.latitude && { latitude: lastBooking.location.latitude.toString() }),
          ...(lastBooking.location?.longitude && { longitude: lastBooking.location.longitude.toString() }),
        },
      });
    } else {
      // Default to valeter booking
      router.push({
        pathname: '/owner/booking/create',
        params: {
          ...(lastBooking.location?.address && { address: lastBooking.location.address }),
          ...(lastBooking.location?.latitude && { latitude: lastBooking.location.latitude.toString() }),
          ...(lastBooking.location?.longitude && { longitude: lastBooking.location.longitude.toString() }),
          ...(lastBooking.vehicleType && { vehicleType: lastBooking.vehicleType }),
        },
      });
    }
  };

  const promotionActions: QuickAction[] = [
    { id: 'promo', title: 'Promotions', subtitle: 'View all offers', iconName: 'pricetag' as any, gradient: ['rgba(239,68,68,0.25)', 'rgba(220,38,38,0.25)'], route: '/owner/car-care-hub' },
    { id: 'sub', title: 'Subscriptions', subtitle: 'Wash plans', iconName: 'infinite' as any, gradient: ['rgba(139,92,246,0.25)', 'rgba(124,58,237,0.25)'], route: '/owner/features/subscription' },
    { id: 'referral', title: 'Refer Friends', subtitle: 'Earn £10', iconName: 'people' as any, gradient: ['#10B981', '#059669'], route: '/owner/features/referral-system' },
  ];

  const scaleFor = () => new Animated.Value(1);
  const pressIn = (v: Animated.Value) =>
    Animated.spring(v, { toValue: 0.97, useNativeDriver: true }).start();
  const pressOut = (v: Animated.Value) =>
    Animated.spring(v, { toValue: 1, friction: 3, useNativeDriver: true }).start();

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={customerTheme.backgroundColor} />
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="customer" />

      <AppHeader
        title={profileName || user?.name || 'Customer'}
        subtitle={new Date().getHours() < 12 ? 'Good morning!' : 
                 new Date().getHours() < 17 ? 'Good afternoon!' : 'Good evening!'}
        variant="dashboard"
        accountType="customer"
        showBack={false}
        scrollY={scrollY}
        enableScrollAnimation={true}
        {...(loyaltyData?.points !== undefined && { points: loyaltyData.points })}
        rightAction={
              <GradientNotificationBell
                count={notificationCount}
                onPress={handleNotificationPress}
              />
        }
      />

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={{
          paddingTop: DASHBOARD_HEADER_CONTENT_OFFSET,
          paddingBottom: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Booking Buttons */}
        <View style={styles.bookingButtonsSection}>
          <TouchableOpacity
            style={styles.bookingButton}
            onPress={() => router.push('/owner/booking')}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={['rgba(135,206,235,0.5)', 'rgba(59,130,246,0.5)']}
              style={styles.bookingButtonGradient}
            >
              <Ionicons name="water" size={24} color={LIGHT_SKY} />
              <Text style={styles.bookingButtonText} numberOfLines={1}>Book a Wash</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.bookingButton}
            onPress={() => router.push('/owner/booking/detailing')}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={['rgba(139,92,246,0.5)', 'rgba(124,58,237,0.5)']}
              style={styles.bookingButtonGradient}
            >
              <Ionicons name="diamond" size={24} color={LIGHT_SKY} />
              <Text style={styles.bookingButtonText}>Book Detailing</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Car Care Info Hub */}
        <View style={styles.assistantSection}>
          <TouchableOpacity
            style={styles.assistantCard}
            onPress={() => {
              setShowCarCareHub(true);
            }}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={['rgba(135,206,235,0.2)', 'rgba(30,58,138,0.25)']}
              style={styles.assistantGradient}
            >
              <View style={styles.assistantContent}>
                <View style={styles.assistantIconWrapper}>
                  <Ionicons name="information-circle" size={28} color={SKY} />
                </View>
                <View style={styles.assistantTextContainer}>
                  <Text style={styles.assistantTitle}>Car Care Info Hub</Text>
                  <Text style={styles.assistantSubtitle}>Tips, locations & more</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color={SKY} />
              </View>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Repeat Booking Quick Action */}
        {lastBooking && (
          <View style={styles.quickActionsSection}>
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.quickActionsContainer}>
              {(() => {
                const s = scaleFor();
                return (
                  <Animated.View style={{ transform: [{ scale: s }], marginRight: 10 }}>
                    <TouchableOpacity
                      activeOpacity={0.85}
                      onPressIn={() => pressIn(s)}
                      onPressOut={() => pressOut(s)}
                      onPress={handleRepeatBooking}
                      style={styles.quickActionCard}
                    >
                      <LinearGradient
                        colors={['rgba(16,185,129,0.7)', 'rgba(5,150,105,0.7)']}
                        style={styles.quickActionGradient}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 1 }}
                      >
                        <View style={styles.quickActionContent}>
                          <View style={styles.quickActionIconWrapper}>
                            <Ionicons name="repeat" size={22} color={LIGHT_SKY} />
                          </View>
                          <Text style={styles.quickActionTitle}>Repeat Booking</Text>
                          <Text style={styles.quickActionSubtitle}>{lastBooking.serviceName}</Text>
                        </View>
                      </LinearGradient>
                    </TouchableOpacity>
                  </Animated.View>
                );
              })()}
            </ScrollView>
          </View>
        )}

        {/* Promotions & Subscriptions */}
        <View style={styles.quickActionsSection}>
          <Text style={styles.sectionTitle}>Promotions & Subscriptions</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.quickActionsContainer}>
            {promotionActions.map((action) => {
              const s = scaleFor();
              return (
                <Animated.View key={action.id} style={{ transform: [{ scale: s }], marginRight: 10 }}>
                  <TouchableOpacity
                    activeOpacity={0.85}
                    onPressIn={() => pressIn(s)}
                    onPressOut={() => pressOut(s)}
                    onPress={() => {
                      if (action.id === 'promo') {
                        setShowCarCareHub(true);
                      } else {
                        router.push(action.route as any);
                      }
                    }}
                    style={styles.quickActionCard}
                  >
                    <LinearGradient
                      colors={action.gradient as [string, string, ...string[]]}
                      style={styles.quickActionGradient}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 1 }}
                    >
                      <View style={styles.quickActionContent}>
                        <View style={styles.quickActionIconWrapper}>
                          <Ionicons name={action.iconName} size={22} color={LIGHT_SKY} />
                        </View>
                        <Text style={styles.quickActionTitle}>{action.title}</Text>
                        <Text style={styles.quickActionSubtitle}>{action.subtitle}</Text>
                      </View>
                    </LinearGradient>
                  </TouchableOpacity>
                </Animated.View>
              );
            })}
          </ScrollView>
        </View>


        {/* Nearby Valeters */}
        <View style={styles.nearbyValetersSection}>
          <Text style={styles.sectionTitle}>Nearby Valeters</Text>
          {nearbyValeters.length === 0 ? (
            <Text style={styles.emptyHint}>No valeters online nearby right now. Pull to refresh in a moment.</Text>
          ) : (
            <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.nearbyValetersContainer}>
              {nearbyValeters.filter((v) => v.isOnline).slice(0, 8).map((valeter) => {
                return (
                  <View key={valeter.id} style={styles.nearbyValeterCard}>
                    <View style={styles.valeterContent}>
                      <View style={styles.valeterIconWrapper}>
                        <Ionicons name="person" size={20} color={SKY} />
                      </View>
                      <View style={styles.valeterTextContainer}>
                        <Text style={styles.valeterName} numberOfLines={1}>{valeter.name}</Text>
                        <View style={styles.valeterMeta}>
                          <Ionicons name="star" size={12} color="#F59E0B" />
                          <Text style={styles.valeterRating}>{valeter.rating.toFixed(1)}</Text>
                          <Text style={styles.valeterDistance}>
                            {valeter.distance != null ? ` • ${(valeter.distance * 0.621371).toFixed(1)}mi` : ''}
                          </Text>
                        </View>
                      </View>
                      <View style={[
                        styles.onlineIndicator,
                        { backgroundColor: '#10B981' }
                      ]}/>
                    </View>
                  </View>
                );
              })}
            </ScrollView>
          )}
        </View>

        {/* Powered By */}
        <View style={styles.poweredBySection}>
          <Text style={styles.poweredByText}>Powered by Wish a Wash ⚡</Text>
        </View>
      </Animated.ScrollView>

      {/* Car Care Info Hub Modal */}
      <Modal visible={showCarCareHub} animationType="slide" presentationStyle="fullScreen">
        <CarCareInfoHub userType="customer" onClose={() => setShowCarCareHub(false)} />
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: customerTheme.backgroundColor },
  loadingText: { color: LIGHT_SKY, fontSize: 16 },
  scrollView: { flex: 1 },

  bookingButtonsSection: {
    flexDirection: 'row',
    gap: 12,
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginTop: -10,
    marginBottom: 20,
  },
  bookingButton: {
    flex: 1,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
  },
  bookingButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 10,
  },
  bookingButtonText: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: 'bold',
    letterSpacing: 0.3,
    flexShrink: 0,
  },
  repeatBookingSection: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 20,
  },
  repeatBookingButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    borderWidth: 1.5,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  repeatBookingGradient: {
    padding: 16,
  },
  repeatBookingContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  repeatBookingIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(16,185,129,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.4)',
  },
  repeatBookingTextContainer: {
    flex: 1,
    gap: 4,
  },
  repeatBookingTitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 15 : 17,
    fontWeight: '700',
    letterSpacing: 0.2,
    flexShrink: 1,
  },
  repeatBookingSubtitle: {
    color: '#059669',
    fontSize: isSmallScreen ? 12 : 13,
    opacity: 0.9,
    fontWeight: '500',
    flexShrink: 1,
  },
  assistantSection: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 20,
  },
  assistantCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  assistantGradient: {
    padding: 16,
  },
  assistantContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  assistantIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  assistantTextContainer: {
    flex: 1,
    gap: 4,
  },
  assistantTitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '700',
    letterSpacing: 0.2,
    flexShrink: 1,
  },
  assistantSubtitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 12 : 13,
    opacity: 0.9,
    fontWeight: '500',
    flexShrink: 1,
  },
  poweredBySection: {
    alignItems: 'center',
    paddingVertical: 24,
    paddingHorizontal: isSmallScreen ? 12 : 20,
    marginTop: 8,
  },
  poweredByText: {
    color: LIGHT_SKY,
    fontSize: 12,
    opacity: 0.8,
    fontWeight: '600',
  },

  /* Quick Actions */
  quickActionsSection: { marginBottom: 24 },
  sectionTitle: {
    color: LIGHT_SKY, fontSize: isSmallScreen ? 18 : 20, fontWeight: 'bold',
    marginBottom: 16, marginHorizontal: isSmallScreen ? 12 : 20
  },
  quickActionsContainer: { paddingHorizontal: isSmallScreen ? 12 : 20 },
  quickActionCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  quickActionGradient: {
    borderRadius: 16,
    padding: 2,
  },
  quickActionContent: {
    flexDirection: 'column',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    gap: 6,
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderRadius: 14,
  },
  quickActionIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  quickActionTitle: { 
    color: LIGHT_SKY, 
    fontSize: isSmallScreen ? 13 : 14, 
    fontWeight: '700', 
    letterSpacing: 0.1,
    flexShrink: 1,
    textAlign: 'center',
  },
  quickActionSubtitle: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 11,
    fontWeight: '500',
    marginTop: 2,
    flexShrink: 1,
    textAlign: 'center',
  },

  /* Stats */
  statsSection: { marginBottom: 32 },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 12,
    paddingHorizontal: isSmallScreen ? 12 : 20,
  },
  statCard: {
    width: (width - (isSmallScreen ? 36 : 40)) / 2 - 6,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  statCardContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    gap: 12,
  },
  statIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  statIconWrapperGold: {
    backgroundColor: 'rgba(245,158,11,0.15)',
    borderColor: 'rgba(245,158,11,0.3)',
  },
  statIconWrapperGreen: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderColor: 'rgba(16,185,129,0.3)',
  },
  statTextContainer: {
    flex: 1,
  },
  statNumber: {
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '800',
    color: LIGHT_SKY,
    marginBottom: 2,
    letterSpacing: -0.3,
  },
  /* Nearby Valeters */
  nearbyValetersSection: { marginBottom: 32 },
  nearbyValetersContainer: { paddingHorizontal: isSmallScreen ? 12 : 20 },
  emptyHint: { color: '#CBE3FF', opacity: 0.8, marginHorizontal: isSmallScreen ? 12 : 20 },
  nearbyValeterCard: {
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    overflow: 'hidden',
    marginRight: 10,
  },
  valeterContent: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 16,
    gap: 12,
  },
  valeterIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  valeterTextContainer: {
    flex: 1,
    gap: 4,
  },
  valeterName: { 
    fontSize: isSmallScreen ? 13 : 14, 
    fontWeight: '700', 
    color: LIGHT_SKY,
  },
  valeterMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  valeterRating: { 
    fontSize: 12, 
    color: '#F59E0B', 
    fontWeight: '600',
  },
  valeterDistance: { 
    fontSize: 12, 
    color: LIGHT_SKY,
    fontWeight: '500',
  },
  onlineIndicator: { width: 10, height: 10, borderRadius: 5 },
});

