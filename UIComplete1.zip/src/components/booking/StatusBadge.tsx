import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

interface StatusBadgeProps {
  status: 'pending' | 'confirmed' | 'en_route' | 'arrived' | 'in_progress' | 'completed' | 'cancelled';
  size?: 'small' | 'medium' | 'large';
}

const statusConfig = {
  pending: { 
    label: 'Pending', 
    icon: 'time-outline', 
    colors: ['rgba(251,191,36,0.3)', 'rgba(251,191,36,0.1)'],
    borderColor: 'rgba(251,191,36,0.5)',
    textColor: '#FBBF24'
  },
  confirmed: { 
    label: 'Confirmed', 
    icon: 'checkmark-circle', 
    colors: ['rgba(16,185,129,0.3)', 'rgba(16,185,129,0.1)'],
    borderColor: 'rgba(16,185,129,0.5)',
    textColor: '#10B981'
  },
  en_route: { 
    label: 'En Route', 
    icon: 'car', 
    colors: ['rgba(59,130,246,0.3)', 'rgba(59,130,246,0.1)'],
    borderColor: 'rgba(59,130,246,0.5)',
    textColor: '#3B82F6'
  },
  arrived: { 
    label: 'Arrived', 
    icon: 'location', 
    colors: ['rgba(139,92,246,0.3)', 'rgba(139,92,246,0.1)'],
    borderColor: 'rgba(139,92,246,0.5)',
    textColor: '#8B5CF6'
  },
  in_progress: { 
    label: 'In Progress', 
    icon: 'water', 
    colors: ['rgba(135,206,235,0.3)', 'rgba(135,206,235,0.1)'],
    borderColor: 'rgba(135,206,235,0.5)',
    textColor: '#87CEEB'
  },
  completed: { 
    label: 'Completed', 
    icon: 'checkmark-done-circle', 
    colors: ['rgba(16,185,129,0.3)', 'rgba(16,185,129,0.1)'],
    borderColor: 'rgba(16,185,129,0.5)',
    textColor: '#10B981'
  },
  cancelled: { 
    label: 'Cancelled', 
    icon: 'close-circle', 
    colors: ['rgba(239,68,68,0.3)', 'rgba(239,68,68,0.1)'],
    borderColor: 'rgba(239,68,68,0.5)',
    textColor: '#EF4444'
  },
};

export default function StatusBadge({ status, size = 'medium' }: StatusBadgeProps) {
  const config = statusConfig[status];
  const iconSize = size === 'small' ? 12 : size === 'medium' ? 16 : 20;
  const fontSize = size === 'small' ? 10 : size === 'medium' ? 12 : 14;
  const padding = size === 'small' ? 6 : size === 'medium' ? 8 : 10;

  return (
    <BlurView intensity={30} tint="dark" style={[styles.container, { paddingHorizontal: padding, paddingVertical: padding / 2 }]}>
      <LinearGradient
        colors={config.colors}
        style={StyleSheet.absoluteFill}
      />
      <View style={[styles.border, { borderColor: config.borderColor }]} />
      <View style={styles.content}>
        <Ionicons name={config.icon as any} size={iconSize} color={config.textColor} />
        <Text style={[styles.label, { color: config.textColor, fontSize }]}>
          {config.label}
        </Text>
      </View>
    </BlurView>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
  },
  border: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  label: {
    fontWeight: '600',
  },
});

