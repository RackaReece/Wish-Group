// src/services/BookingService.ts
import { supabase } from '../lib/supabase';

const TAG = '[BookingService]';
const warn = (...a:any[]) => console.warn(TAG, new Date().toISOString(), ...a);
const err  = (...a:any[]) => console.error(TAG, new Date().toISOString(), ...a);

export interface Booking {
  id: string;
  customerId: string;
  serviceType: string;
  serviceName: string;
  vehicleType: string;
  vehicleInfo?: string;
  location: { address: string; latitude: number; longitude: number };
  price: number;
  status:
    | 'scheduled'
    | 'in_progress'
    | 'completed'
    | 'cancelled'
    | 'pending'
    | 'confirmed'
    | 'valeter_assigned'
    | 'en_route'
    | 'arrived';
  valeterId?: string | null;
  valeterName?: string | null;
  valeterRating?: number | null;
  valeterOrganization?: string | null;
  valeterPhoto?: string | null;
  estimatedArrival?: string | null;
  scheduledDate?: string | null;
  scheduledTime?: string | null;
  createdAt: string;
  updatedAt: string;
  specialInstructions?: string | null;
  paymentStatus: 'unpaid' | 'pending' | 'paid' | 'failed' | 'refunded';
  paymentMethod?: string | null;
}

type CreateInput = {
  customerId: string;
  serviceType: string;
  serviceName?: string;
  price: number;
  status?: Booking['status'];
  scheduledAt?: string;
  location: { address: string; latitude: number; longitude: number };
  vehicleType?: string;
  vehicleInfo?: string;
};

function toAppBooking(row: any): Booking {
  const scheduledAt: string | undefined = row.scheduled_at ?? row.scheduledAt;
  const scheduledDate = scheduledAt ? new Date(scheduledAt).toISOString().slice(0, 10) : null;
  const scheduledTime = scheduledAt ? new Date(scheduledAt).toISOString().slice(11, 16) : null;
  const serviceName = row.service_name || row.serviceName || row.service_type;

  return {
    id: row.id,
    customerId: row.user_id ?? row.userId,
    serviceType: row.service_type ?? row.serviceType,
    serviceName,
    vehicleType: row.vehicle_type || row.vehicleType || 'unknown',
    vehicleInfo: row.vehicle_info || row.vehicleInfo || null,
    location: {
      address: row.location_address ?? '',
      latitude: Number(row.location_lat ?? 0),
      longitude: Number(row.location_lng ?? 0),
    },
    price: Number(row.price ?? 0),
    status: (row.status as Booking['status']) ?? 'scheduled',
    valeterId: row.valeter_id ?? null,
    valeterName: row.valeter_name ?? null,
    valeterRating: row.valeter_rating ?? null,
    valeterOrganization: row.valeter_organization ?? null,
    valeterPhoto: row.valeter_photo ?? null,
    estimatedArrival: row.estimated_arrival ?? null,
    scheduledDate,
    scheduledTime,
    createdAt: row.created_at ?? new Date().toISOString(),
    updatedAt: row.updated_at ?? new Date().toISOString(),
    specialInstructions: row.special_instructions ?? null,
    paymentStatus: 'unpaid',
    paymentMethod: null,
  };
}

function coerceStatus(s?: Booking['status']): 'scheduled' | 'in_progress' | 'completed' | 'cancelled' {
  switch (s) {
    case 'scheduled':
    case 'in_progress':
    case 'completed':
    case 'cancelled':
      return s;
    default:
      return 'scheduled';
  }
}

/**
 * DB statuses that count as "active" for preventing a new booking.
 * Keep in sync with client guard.
 */
const ACTIVE_DB_STATUSES: Booking['status'][] = [
  'pending',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
  'scheduled',
  'in_progress',
];

class BookingService {
  private static instance: BookingService;
  static getInstance(): BookingService {
    if (!BookingService.instance) BookingService.instance = new BookingService();
    return BookingService.instance;
  }

  // CREATE
  async createBooking(input: CreateInput): Promise<Booking> {
    const scheduledAt = input.scheduledAt ?? new Date().toISOString();
    const status = coerceStatus(input.status);

    const row = {
      user_id: input.customerId,
      service_type: input.serviceType,
      scheduled_at: scheduledAt,
      status,
      price: input.price,
      location_address: input.location.address,
      location_lat: input.location.latitude,
      location_lng: input.location.longitude,
      // Persist optional extras if you've added columns for them:
      vehicle_type: input.vehicleType ?? null,
      vehicle_info: input.vehicleInfo ?? null,
      service_name: input.serviceName ?? input.serviceType,
    };

    const { data, error } = await supabase
      .from('bookings')
      .insert(row)
      .select('*')
      .single();

    if (error) throw error;
    return toAppBooking(data);
  }

  // READ
  async getUserBookings(userId: string): Promise<Booking[]> {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false });
    if (error) throw error;
    return (data ?? []).map(toAppBooking);
  }

  async getBooking(bookingId: string, userId: string): Promise<Booking | null> {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .eq('id', bookingId)
      .eq('user_id', userId)
      .maybeSingle();
    if (error) throw error;
    return data ? toAppBooking(data) : null;
  }

  /**
   * Legacy/short "active" getter (kept for backwards compatibility).
   * NOTE: historically only considered 'scheduled' and 'in_progress'.
   */
  async getActiveBooking(userId: string): Promise<Booking | null> {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .eq('user_id', userId)
      .in('status', ['scheduled', 'in_progress'])
      .order('created_at', { ascending: false })
      .limit(1);
    if (error) throw error;
    const row = data?.[0];
    return row ? toAppBooking(row) : null;
  }

  /**
   * New: full-spectrum "active booking" for booking guard on the client.
   * Matches more states (pending/confirmed/valeter_assigned/en_route/arrived/etc).
   */
  async getActiveBookingForUser(userId: string): Promise<Booking | null> {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .eq('user_id', userId)
      .in('status', ACTIVE_DB_STATUSES)
      .order('created_at', { ascending: false })
      .limit(1);

    if (error) throw error;
    const row = data?.[0];
    return row ? toAppBooking(row) : null;
  }

  /**
   * Safely cancel a booking: set status, null uuid fields, and write audit info.
   */
  async cancelBooking(
    bookingId: string,
    userId: string,
    opts?: { reason?: string; by?: 'customer' | 'valeter' | 'system' }
  ): Promise<Booking | null> {
    const payload: Record<string, any> = {
      status: 'cancelled',
      cancelled_at: new Date().toISOString(),
      cancelled_by: opts?.by ?? 'customer',
      cancellation_reason: opts?.reason ?? 'user_cancelled',
      // Null any uuid assignment fields
      valeter_id: null,
      //assigned_valeter_id: null,
      //driver_id: null,
      eta_minutes: null,
    };

    const { data, error } = await supabase
      .from('bookings')
      .update(payload)
      .eq('id', bookingId)
      .eq('user_id', userId)
      .select('*')
      .maybeSingle();

    if (error) throw error;
    return data ? toAppBooking(data) : null;
  }

  /**
   * Generic status update. If setting to 'cancelled', also null uuid fields.
   */
  async updateBookingStatus(bookingId: string, userId: string, status: Booking['status']) {
    const dbStatus = coerceStatus(status);
    const base: Record<string, any> = { status: dbStatus };

    if (dbStatus === 'cancelled') {
      base.cancelled_at = new Date().toISOString();
      base.cancelled_by = 'customer';
      base.cancellation_reason = base.cancellation_reason ?? 'user_cancelled';
      base.valeter_id = null;
      //base.assigned_valeter_id = null;
      //base.driver_id = null;
      base.eta_minutes = null;
    }

    const { data, error } = await supabase
      .from('bookings')
      .update(base)
      .eq('id', bookingId)
      .eq('user_id', userId)
      .select('*')
      .single();

    if (error) throw error;
    return data ? toAppBooking(data) : null;
  }

  // Helper: does this valeter currently have an active job?
  async hasActiveValeterJob(valeterId: string): Promise<string | null> {
    const { data, error } = await supabase
      .from('bookings')
      .select('id')
      .eq('valeter_id', valeterId)
      .in('status', ['scheduled', 'in_progress'])
      .order('created_at', { ascending: false })
      .limit(1);

    if (error) {
      warn('hasActiveValeterJob(): error ->', error.message);
      // Fail closed (treat as active) to be safe
      return 'UNKNOWN';
    }
    return data?.[0]?.id ?? null;
  }

  // HARD GUARANTEE + friendly errors
  async assignValeter(
    bookingId: string,
    _userId: string,
    v: { valeterId: string; valeterName: string; valeterRating?: number }
  ) {

    // 1) Pre-check on client: if active exists, block early
    const activeId = await this.hasActiveValeterJob(v.valeterId);
    if (activeId) {
      const e: any = new Error('You already have an active job.');
      e.code = 'ACTIVE_JOB_EXISTS';
      e.activeJobId = activeId;
      throw e;
    }

    // 2) Attempt claim; DB unique index still protects under race
    const { data, error } = await supabase
      .from('bookings')
      .update({
        valeter_id: v.valeterId,
        valeter_name: v.valeterName,
        valeter_rating: v.valeterRating ?? null,
        status: 'scheduled', // counts as active in the partial unique index
      })
      .eq('id', bookingId)
      .is('valeter_id', null) // only if unassigned
      .select('*')
      .maybeSingle();

    if (error) {
      const code = (error as any)?.code || '';
      const msg  = (error as any)?.message || '';
      if (code === '23505' || /duplicate key value/.test(msg)) {
        const e: any = new Error('You already have an active job.');
        e.code = 'ACTIVE_JOB_EXISTS';
        e.activeJobId = await this.hasActiveValeterJob(v.valeterId);
        throw e;
      }
      err('assignValeter(): ERROR ->', error);
      throw error;
    }

    if (!data) {
      const e: any = new Error('Job already taken or not available.');
      e.code = 'JOB_TAKEN_OR_FORBIDDEN';
      throw e;
    }

    return toAppBooking(data);
  }

  async updateEta(bookingId: string, etaMinutes: number) {
    const { data, error } = await supabase
      .from('bookings')
      .update({ eta_minutes: etaMinutes })
      .eq('id', bookingId)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data ? toAppBooking(data) : null;
  }

  async getOpenBookings(): Promise<Booking[]> {
    const { data, error } = await supabase
      .from('bookings')
      .select('*')
      .is('valeter_id', null)
      .in('status', [
        'pending',
        'scheduled',
      ])
      .order('created_at', { ascending: false });

    if (error) throw error;
    return (data ?? []).map(toAppBooking);
  }



  async updateDriverLocation(bookingId: string, p: { lat: number; lng: number; label?: string }) {
    const { data, error } = await supabase
      .from('bookings')
      .update({ driver_lat: p.lat, driver_lng: p.lng, driver_location: p.label ?? null })
      .eq('id', bookingId)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data ? toAppBooking(data) : null;
  }

  async setProgress(bookingId: string, percent: number) {
    const clamped = Math.max(0, Math.min(100, Math.round(percent)));
    const { data, error } = await supabase
      .from('bookings')
      .update({ progress_percent: clamped })
      .eq('id', bookingId)
      .select('*')
      .maybeSingle();
    if (error) throw error;
    return data ? toAppBooking(data) : null;
  }

  // STATS
  async getBookingStats(userId: string) {
    const bookings = await this.getUserBookings(userId);
    const completed = bookings.filter(b => b.status === 'completed');
    const totalSpent = completed.reduce((s, b) => s + (b.price || 0), 0);
    return {
      totalBookings: bookings.length,
      totalSpent,
      completedServices: completed.length,
      averageRating: Number(
        (completed.length ? completed.reduce((s, b) => s + (b.valeterRating || 0), 0) / completed.length : 0).toFixed(1)
      ),
      savings: Math.round(totalSpent * 0.1),
    };
  }

  // REALTIME
  subscribeToBookings(userId: string, callback: (rows: Booking[]) => void): () => void {
    this.getUserBookings(userId).then(callback).catch(err);

    const channel = supabase
      .channel(`bookings:user:${userId}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'bookings', filter: `user_id=eq.${userId}` },
        async () => { const rows = await this.getUserBookings(userId); callback(rows); })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }

  subscribeToOpenBookings(callback: (rows: Booking[]) => void): () => void {
    this.getOpenBookings().then(callback).catch(err);

    const channel = supabase
      .channel('bookings:open')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'bookings' },
        async () => { const rows = await this.getOpenBookings(); callback(rows); })
      .subscribe();

    return () => supabase.removeChannel(channel);
  }
}

const instance = BookingService.getInstance();
export default instance;
export { instance as bookingService };
export const getBookingStats = (userId: string) => instance.getBookingStats(userId);
export const getOpenBookings = () => instance.getOpenBookings();
