import { supabase } from '../lib/supabase';
import { BadgeType } from '../components/valeter/BadgeSystem';

interface ValeterStats {
  totalBookings: number;
  averageRating: number;
  totalReviews: number;
  ecoWashesCount: number;
  isNewValeter: boolean; // Less than 3 months
  fiveStarReviews: number;
}

/**
 * Calculate which badges a valeter has earned based on their stats
 */
export async function calculateValeterBadges(valeterId: string): Promise<BadgeType[]> {
  try {
    // Fetch valeter stats
    const stats = await getValeterStats(valeterId);
    const badges: BadgeType[] = [];

    // Most Booked Badge (top 10% by booking count)
    const isMostBooked = await checkMostBooked(stats.totalBookings);
    if (isMostBooked) {
      badges.push('most_booked');
    }

    // Top Rated Badge (4.8+ stars, 20+ reviews)
    if (stats.averageRating >= 4.8 && stats.totalReviews >= 20) {
      badges.push('top_rated');
    }

    // Eco Champion Badge (50+ eco washes)
    if (stats.ecoWashesCount >= 50) {
      badges.push('eco_champion');
    }

    // Rising Star Badge (new valeter with 5+ 5-star reviews)
    if (stats.isNewValeter && stats.fiveStarReviews >= 5) {
      badges.push('rising_star');
    }

    return badges;
  } catch (error) {
    console.error('Error calculating badges:', error);
    return [];
  }
}

/**
 * Get valeter statistics for badge calculation
 */
async function getValeterStats(valeterId: string): Promise<ValeterStats> {
  // Get total bookings
  const { count: totalBookings } = await supabase
    .from('bookings')
    .select('*', { count: 'exact', head: true })
    .eq('valeter_id', valeterId)
    .in('status', ['completed']);

  // Get ratings and reviews
  const { data: bookings } = await supabase
    .from('bookings')
    .select('rating, review, service_type')
    .eq('valeter_id', valeterId)
    .not('rating', 'is', null);

  const ratings = bookings?.map(b => b.rating).filter(Boolean) as number[] || [];
  const averageRating = ratings.length > 0 
    ? ratings.reduce((sum, r) => sum + r, 0) / ratings.length 
    : 0;
  const totalReviews = bookings?.filter(b => b.review).length || 0;
  const fiveStarReviews = ratings.filter(r => r === 5).length;

  // Count eco washes
  const ecoWashesCount = bookings?.filter(b => 
    b.service_type?.toLowerCase().includes('eco')
  ).length || 0;

  // Check if valeter is new (created less than 3 months ago)
  const { data: valeterProfile } = await supabase
    .from('valeter_profiles')
    .select('created_at')
    .eq('user_id', valeterId)
    .maybeSingle();

  const threeMonthsAgo = new Date();
  threeMonthsAgo.setMonth(threeMonthsAgo.getMonth() - 3);
  const isNewValeter = valeterProfile?.created_at 
    ? new Date(valeterProfile.created_at) > threeMonthsAgo 
    : false;

  return {
    totalBookings: totalBookings || 0,
    averageRating,
    totalReviews,
    ecoWashesCount,
    isNewValeter,
    fiveStarReviews,
  };
}

/**
 * Check if valeter is in top 10% by booking count
 */
async function checkMostBooked(bookingCount: number): Promise<boolean> {
  // Get all valeters' booking counts
  const { data: allBookings } = await supabase
    .from('bookings')
    .select('valeter_id')
    .in('status', ['completed']);

  if (!allBookings || allBookings.length === 0) return false;

  // Count bookings per valeter
  const valeterCounts: Record<string, number> = {};
  allBookings.forEach(booking => {
    if (booking.valeter_id) {
      valeterCounts[booking.valeter_id] = (valeterCounts[booking.valeter_id] || 0) + 1;
    }
  });

  const counts = Object.values(valeterCounts).sort((a, b) => b - a);
  if (counts.length === 0) return false;

  // Top 10% threshold
  const top10PercentIndex = Math.floor(counts.length * 0.1);
  const top10PercentThreshold = counts[top10PercentIndex] || 0;

  return bookingCount >= top10PercentThreshold;
}

