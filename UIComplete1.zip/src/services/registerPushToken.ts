// src/services/push/registerPushToken.ts
import * as Notifications from 'expo-notifications';
import { Platform } from 'react-native';
import Constants from 'expo-constants';
import { supabase } from '../lib/supabase';

export async function registerPushToken() {
  try {
    const { status } = await Notifications.requestPermissionsAsync();
    if (status !== 'granted') return;

    const token = (await Notifications.getExpoPushTokenAsync({
      projectId: Constants.expoConfig?.extra?.eas?.projectId, // optional but recommended on EAS builds
    })).data;

    const session = (await supabase.auth.getSession()).data.session;
    const userId = session?.user?.id;
    if (!userId || !token) return;

    await supabase.from('user_devices').upsert({
      user_id: userId,
      expo_push_token: token,
      platform: Platform.OS as 'ios' | 'android' | 'web',
    });
  } catch (e) {
    console.warn('[push] register failed', e);
  }
}