import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  TextInput,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function RequestRefund() {
  const { user } = useAuth();
    const [selectedBooking, setSelectedBooking] = useState('');
  const [refundReason, setRefundReason] = useState('');
  const [refundAmount, setRefundAmount] = useState('');

  const refundReasons = [
    { id: 'service', label: 'Service Not Completed', icon: 'close-circle' },
    { id: 'quality', label: 'Poor Quality', icon: 'thumbs-down' },
    { id: 'cancelled', label: 'Cancelled by Valeter', icon: 'ban' },
    { id: 'other', label: 'Other', icon: 'help-circle' },
  ];

  const handleSubmit = () => {
    if (!selectedBooking || !refundReason) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }
    Alert.alert('Success', 'Your refund request has been submitted. We\'ll review it within 24-48 hours.');
    router.back();
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Request Refund" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Booking Selection */}
        <View style={styles.section}>
          <Text style={styles.inputLabel}>Booking ID *</Text>
          <TextInput
            style={styles.input}
            value={selectedBooking}
            onChangeText={setSelectedBooking}
            placeholder="Enter booking ID"
            placeholderTextColor="#6B7280"
          />
        </View>

        {/* Refund Reason */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Refund Reason *</Text>
          <View style={styles.reasonGrid}>
            {refundReasons.map((reason) => (
              <TouchableOpacity
                key={reason.id}
                style={[
                  styles.reasonCard,
                  refundReason === reason.id && styles.reasonCardSelected,
                ]}
                onPress={() => setRefundReason(reason.id)}
              >
                <Ionicons
                  name={reason.icon as any}
                  size={24}
                  color={refundReason === reason.id ? '#0A1929' : SKY}
                />
                <Text
                  style={[
                    styles.reasonLabel,
                    refundReason === reason.id && styles.reasonLabelSelected,
                  ]}
                >
                  {reason.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Refund Amount */}
        <View style={styles.section}>
          <Text style={styles.inputLabel}>Refund Amount (£) *</Text>
          <TextInput
            style={styles.input}
            value={refundAmount}
            onChangeText={setRefundAmount}
            placeholder="Enter amount"
            placeholderTextColor="#6B7280"
            keyboardType="decimal-pad"
          />
        </View>

        {/* Info Card */}
        <View style={styles.infoCard}>
          <Ionicons name="information-circle" size={20} color={SKY} />
          <Text style={styles.infoText}>
            Refunds are typically processed within 5-7 business days. You'll receive a confirmation email once your request is reviewed.
          </Text>
        </View>

        {/* Submit Button */}
        <TouchableOpacity style={styles.submitButton} onPress={handleSubmit}>
          <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.submitGradient}>
            <Ionicons name="card" size={20} color="#0A1929" />
            <Text style={styles.submitText}>Submit Refund Request</Text>
          </LinearGradient>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 12 : 20 },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 17,
    fontWeight: '700',
    marginBottom: 12,
  },
  inputLabel: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  input: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 14,
    color: '#F9FAFB',
    fontSize: 16,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  reasonGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  reasonCard: {
    width: (width - (isSmallScreen ? 48 : 60)) / 2 - 6,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  reasonCardSelected: {
    backgroundColor: SKY,
    borderColor: SKY,
  },
  reasonLabel: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '700',
    marginTop: 8,
    textAlign: 'center',
  },
  reasonLabelSelected: {
    color: '#0A1929',
  },
  infoCard: {
    flexDirection: 'row',
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderRadius: 12,
    padding: 16,
    marginBottom: 24,
    gap: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  infoText: {
    flex: 1,
    color: '#87CEEB',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
  },
  submitButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginTop: 8,
    marginBottom: 20,
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  submitGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    gap: 8,
  },
  submitText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: '700',
  },
});

