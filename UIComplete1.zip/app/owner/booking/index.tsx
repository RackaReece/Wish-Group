import React, { useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Dimensions,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

const washTypes = [
  {
    id: 'valeter',
    title: 'On-Demand Valeter',
    description: 'We send a vetted valeter to your location with live tracking.',
    icon: 'car-outline',
    borderColor: 'rgba(135,206,235,0.3)',
    iconColor: colors.SKY,
    route: '/owner/booking/create',
    bulletPoints: [
      'Live status + tracking',
      'Pay only after acceptance',
      'Perfect for home/office',
    ],
  },
  {
    id: 'physical',
    title: 'Physical Wash Hub',
    description: 'Drive to a premium Wish a Wash hub and get instant service.',
    icon: 'business-outline',
    borderColor: 'rgba(59,130,246,0.3)',
    iconColor: '#3B82F6',
    route: '/owner/booking/physical/vehicle',
    bulletPoints: [
      'Certified wash locations',
      'Book date & time slot',
      'Ideal for nearby errands',
    ],
  },
  {
    id: 'eco',
    title: 'Eco Wash',
    description: 'Environmentally friendly car wash with biodegradable products.',
    icon: 'leaf-outline',
    borderColor: 'rgba(16,185,129,0.3)',
    iconColor: colors.ECO_GREEN,
    route: '/owner/booking/eco',
    bulletPoints: [
      'Eco-friendly products',
      'Carbon-neutral process',
      'Better for environment',
    ],
  },
];

export default function WashTypeSelection() {
  const insets = useSafeAreaInsets();
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 500,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        friction: 8,
        tension: 60,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handleSelect = (route: string) => {
    router.push(route as any);
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="How would you like to book?"
        subtitle="Select your preferred booking method"
        showBack={false}
      />

      <Animated.ScrollView
        showsVerticalScrollIndicator={false}
        style={[
          styles.cardsWrapper,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
        contentContainerStyle={{
          paddingTop: HEADER_CONTENT_OFFSET,
          paddingBottom: Math.max(insets.bottom, 24),
        }}
      >
        {washTypes.map((option) => {
          const isEco = option.id === 'eco';
          return (
            <View key={option.id} style={isEco ? styles.ecoCardWrapper : null}>
              {isEco && (
                <LinearGradient
                  colors={['rgba(16,185,129,0.15)', 'rgba(5,150,105,0.1)']}
                  style={StyleSheet.absoluteFill}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                />
              )}
              <GlassCard
                onPress={() => handleSelect(option.route)}
                style={[styles.card, isEco && styles.ecoCard]}
                borderColor={isEco ? 'rgba(16,185,129,0.5)' : option.borderColor}
                accountType="customer"
              >
                <View style={styles.cardHeader}>
                  <View style={[styles.iconWrapper, { backgroundColor: option.iconColor + '20' }]}>
                    <Ionicons name={option.icon as any} size={20} color={option.iconColor} />
                  </View>
                  <Text style={styles.cardTitle}>{option.title}</Text>
                </View>
                <Text style={styles.cardDescription} numberOfLines={2}>{option.description}</Text>
                <View style={styles.bullets}>
                  {option.bulletPoints.slice(0, 2).map((point) => (
                    <View key={point} style={styles.bulletRow}>
                      <Ionicons name="checkmark-circle" size={12} color={option.iconColor} style={{ opacity: 0.8 }} />
                      <Text style={styles.bulletText} numberOfLines={1}>{point}</Text>
                    </View>
                  ))}
                </View>
                <View style={styles.cardCTA}>
                  <Text style={styles.cardCTAText}>Continue</Text>
                  <Ionicons name="arrow-forward" size={16} color="#F9FAFB" />
                </View>
              </GlassCard>
            </View>
          );
        })}
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  cardsWrapper: {
    paddingHorizontal: isSmallScreen ? 16 : 24,
    paddingTop: 8,
    flex: 1,
  },
  ecoCardWrapper: {
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 12,
  },
  card: {
    padding: isSmallScreen ? 16 : 18,
    marginBottom: 12,
  },
  ecoCard: {
    marginBottom: 0,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 6,
  },
  iconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 17,
    fontWeight: '700',
    flex: 1,
  },
  cardDescription: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 12,
    marginBottom: 8,
    lineHeight: 16,
  },
  bullets: {
    gap: 4,
    marginBottom: 10,
  },
  bulletRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  bulletText: {
    color: '#E5E7EB',
    fontSize: 11,
    flex: 1,
  },
  cardCTA: {
    marginTop: 2,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 4,
  },
  cardCTAText: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '700',
  },
});


