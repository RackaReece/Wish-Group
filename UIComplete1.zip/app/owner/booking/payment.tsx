import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { Platform } from 'react-native';
import { useAuth } from '../../../src/providers/enhanced-auth-context';

// Conditionally import Stripe only on native platforms
let useStripe: any = () => ({ confirmPayment: async () => {} });
if (Platform.OS !== 'web') {
  try {
    const stripe = require('@stripe/stripe-react-native');
    useStripe = stripe.useStripe;
  } catch (e) {
    console.warn('Stripe not available:', e);
  }
}
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import CountdownTimer from '../../../src/components/booking/CountdownTimer';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';
import LoadingScreen from '../../../src/components/LoadingScreen';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function BookingPayment() {
  const { user } = useAuth();
    const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;
  const { confirmPayment } = useStripe();

  const [booking, setBooking] = useState<any | null>(null);
  const [processing, setProcessing] = useState(false);
  const [countdown, setCountdown] = useState(600); // 10 minutes

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const cardAnim = useRef(new Animated.Value(0)).current;
  const successAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(cardAnim, {
        toValue: 1,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();

    loadBooking();
  }, [bookingId]);

  const loadBooking = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', bookingId)
        .single();

      if (error) throw error;
      setBooking(data);
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const handlePayment = async () => {
    if (!booking || !user?.id) return;
    if (processing) return;

    setProcessing(true);
    await hapticFeedback('medium');

    try {
      const amountPence = Math.round(booking.price * 100);

      // Create payment intent (simplified - in production, call your backend)
      // For now, we'll update the booking status directly
      const { error: updateError } = await supabase
        .from('bookings')
        .update({
          status: 'confirmed',
          payment_completed_at: new Date().toISOString(),
        })
        .eq('id', bookingId);

      if (updateError) throw updateError;

      // Success animation
      Animated.spring(successAnim, {
        toValue: 1,
        tension: 50,
        friction: 7,
        useNativeDriver: true,
      }).start();

      setTimeout(() => {
        router.replace({
          pathname: '/owner/booking/tracking',
          params: { bookingId },
        });
      }, 1500);
    } catch (error: any) {
      Alert.alert('Payment Failed', error?.message || 'Please try again');
    } finally {
      setProcessing(false);
    }
  };

  const handleCountdownComplete = () => {
    Alert.alert(
      'Payment Timeout',
      'The payment window has expired. Please try again.',
      [
        { text: 'OK', onPress: () => router.back() },
      ]
    );
  };

  if (!booking) {
    return <LoadingScreen />;
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Payment" />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          {/* Countdown Timer */}
          <View style={styles.timerContainer}>
            <CountdownTimer
              seconds={countdown}
              onComplete={handleCountdownComplete}
              size="medium"
            />
          </View>

          {/* Booking Summary */}
          <GlassCard style={styles.summaryCard} accountType="customer">
            <View style={styles.summaryHeader}>
              <Ionicons name="receipt-outline" size={24} color={SKY} />
              <Text style={styles.summaryTitle}>Booking Summary</Text>
            </View>
            <View style={styles.summaryContent}>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Service</Text>
                <Text style={styles.summaryValue}>
                  {getServiceDisplayName(booking.service_type, booking.service_name)}
                </Text>
              </View>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Location</Text>
                <Text style={styles.summaryValue} numberOfLines={2}>
                  {booking.location_address}
                </Text>
              </View>
              <View style={[styles.summaryRow, styles.totalRow]}>
                <Text style={styles.totalLabel}>Total</Text>
                <Text style={styles.totalValue}>£{booking.price?.toFixed(2) || '0.00'}</Text>
              </View>
            </View>
          </GlassCard>

          {/* Payment Card */}
          <Animated.View
            style={[
              styles.paymentCardContainer,
              {
                transform: [{ scale: cardAnim }],
              },
            ]}
          >
            <GlassCard style={styles.paymentCard}>
              <View style={styles.paymentHeader}>
                <Ionicons name="card-outline" size={32} color={SKY} />
                <Text style={styles.paymentTitle}>Payment Method</Text>
              </View>
              <View style={styles.paymentMethod}>
                <View style={styles.cardIcon}>
                  <Ionicons name="card" size={24} color="#FFFFFF" />
                </View>
                <View style={styles.cardInfo}>
                  <Text style={styles.cardText}>•••• •••• •••• 4242</Text>
                  <Text style={styles.cardExpiry}>Expires 12/25</Text>
                </View>
                <TouchableOpacity>
                  <Ionicons name="chevron-forward" size={20} color={SKY} />
                </TouchableOpacity>
              </View>
            </GlassCard>
          </Animated.View>

          {/* Success Animation */}
          <Animated.View
            style={[
              styles.successContainer,
              {
                opacity: successAnim,
                transform: [
                  {
                    scale: successAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [0.8, 1],
                    }),
                  },
                ],
              },
            ]}
            pointerEvents="none"
          >
            <View style={styles.successCircle}>
              <Ionicons name="checkmark-circle" size={64} color="#10B981" />
            </View>
            <Text style={styles.successText}>Payment Successful!</Text>
          </Animated.View>

          {/* Pay Button */}
          {!processing && (
            <TouchableOpacity
              onPress={handlePayment}
              style={styles.payButton}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={['#10B981', '#059669']}
                style={styles.payGradient}
              >
                <Ionicons name="lock-closed" size={20} color="#FFFFFF" />
                <Text style={styles.payText}>Pay £{booking.price?.toFixed(2) || '0.00'}</Text>
              </LinearGradient>
            </TouchableOpacity>
          )}

          {processing && (
            <View style={styles.processingContainer}>
              <Text style={styles.processingText}>Processing payment...</Text>
            </View>
          )}
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  timerContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  summaryCard: {
    padding: 20,
    marginBottom: 20,
  },
  summaryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  summaryTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  summaryContent: {
    gap: 12,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  summaryLabel: {
    color: '#9CA3AF',
    fontSize: 14,
  },
  summaryValue: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    textAlign: 'right',
    flex: 1,
    marginLeft: 16,
  },
  totalRow: {
    marginTop: 8,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  totalLabel: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  totalValue: {
    color: SKY,
    fontSize: 24,
    fontWeight: 'bold',
  },
  paymentCardContainer: {
    marginBottom: 24,
  },
  paymentCard: {
    padding: 20,
  },
  paymentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  paymentTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  paymentMethod: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  cardIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardInfo: {
    flex: 1,
  },
  cardText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  cardExpiry: {
    color: '#9CA3AF',
    fontSize: 12,
  },
  successContainer: {
    position: 'absolute',
    top: '50%',
    left: 0,
    right: 0,
    alignItems: 'center',
    zIndex: 1000,
  },
  successCircle: {
    marginBottom: 16,
  },
  successText: {
    color: '#10B981',
    fontSize: 20,
    fontWeight: 'bold',
  },
  payButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  payGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 32,
    gap: 8,
  },
  payText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  processingContainer: {
    padding: 20,
    alignItems: 'center',
  },
  processingText: {
    color: SKY,
    fontSize: 14,
  },
});

