import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { supabase } from '../../../../src/lib/supabase';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { serviceOptions } from '../../../../src/constants/serviceOptions';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import GlassCard from '../../../../src/components/booking/GlassCard';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { Hub } from '../../../../src/types/booking';

export default function PhysicalConfirm() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams<{ locationId?: string; serviceId?: string; vehicleId?: string; washType?: string; scheduledAt?: string }>();
  const { locationId, serviceId, vehicleId, washType, scheduledAt } = params;
  const [hub, setHub] = useState<Hub | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const service = serviceOptions.find((opt) => opt.id === serviceId);

  useEffect(() => {
    if (!locationId) return;
    const fetchHub = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude')
        .eq('id', locationId)
        .maybeSingle();
      if (!error && data) {
        setHub(data);
      } else {
        setHub(null);
      }
      setLoading(false);
    };
    fetchHub();
  }, [locationId]);

  const handleConfirm = async () => {
    if (!user?.id || !service || !hub || !scheduledAt) return;
    try {
      setSubmitting(true);
      await hapticFeedback('medium');
      const { data, error } = await supabase
        .from('bookings')
        .insert({
          user_id: user.id,
          service_type: service.id,
          service_name: service.name,
          price: service.price,
          status: 'scheduled',
          location_address: hub.address,
          location_lat: hub.latitude,
          location_lng: hub.longitude,
          request_sent_at: new Date().toISOString(),
          scheduled_at: scheduledAt,
        })
        .select()
        .single();

      if (error) throw error;

      router.replace({
        pathname: '/owner/booking/physical/confirmation',
        params: { bookingId: data.id },
      });
    } catch (err: any) {
      console.error('[physical-confirm] booking error', err);
      Alert.alert('Error', err?.message || 'Unable to create booking');
    } finally {
      setSubmitting(false);
    }
  };

  if (!service || !scheduledAt) {
    return (
      <SafeAreaView style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ color: '#fff' }}>Missing booking information.</Text>
      </SafeAreaView>
    );
  }

  const formattedTime = new Date(scheduledAt as string).toLocaleString('en-GB', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Confirm booking" />

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#87CEEB" />
        </View>
      ) : (
        <ScrollView contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]} showsVerticalScrollIndicator={false}>
          <GlassCard style={styles.summaryCard} accountType="customer">
            <Text style={styles.summaryLabel}>Service</Text>
            <Text style={styles.summaryTitle}>{service.name}</Text>
            <Text style={styles.summarySubtitle}>{service.desc}</Text>
            <View style={styles.summaryRow}>
              <Text style={styles.summaryMeta}>Duration: {service.dur}</Text>
              <Text style={styles.summaryPrice}>£{service.price}</Text>
            </View>
          </GlassCard>

          {hub && (
            <GlassCard style={styles.summaryCard} accountType="customer">
              <Text style={styles.summaryLabel}>Location</Text>
              <Text style={styles.summaryTitle}>{hub.name}</Text>
              <Text style={styles.summarySubtitle}>{hub.address}</Text>
            </GlassCard>
          )}

          <GlassCard style={styles.summaryCard} accountType="customer">
            <Text style={styles.summaryLabel}>Slot</Text>
            <Text style={styles.summaryTitle}>{formattedTime}</Text>
            <Text style={styles.summarySubtitle}>Arrive 5 minutes early to keep your slot.</Text>
          </GlassCard>
        </ScrollView>
      )}

      <View style={[styles.footer, { paddingBottom: insets.bottom + 16 }]}>
        <TouchableOpacity
          style={[styles.confirmButton, submitting && { opacity: 0.6 }]}
          onPress={handleConfirm}
          disabled={submitting || loading || !hub}
          activeOpacity={0.85}
        >
          {submitting ? (
            <ActivityIndicator color="#0A1929" />
          ) : (
            <>
              <Ionicons name="shield-checkmark" size={18} color="#0A1929" />
              <Text style={styles.confirmText}>Confirm booking</Text>
            </>
          )}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 140,
    gap: 16,
  },
  summaryCard: {
    padding: 18,
  },
  summaryLabel: {
    color: 'rgba(135,206,235,0.8)',
    fontSize: 12,
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 6,
  },
  summaryTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
  },
  summarySubtitle: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 14,
    marginTop: 4,
  },
  summaryRow: {
    marginTop: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  summaryMeta: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
  },
  summaryPrice: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
  },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 20,
    backgroundColor: customerTheme.backgroundColor,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.05)',
  },
  confirmButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    backgroundColor: '#87CEEB',
    borderRadius: 18,
    paddingVertical: 14,
  },
  confirmText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: '700',
  },
});


