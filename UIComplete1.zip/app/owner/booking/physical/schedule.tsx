import React, { useEffect, useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { supabase } from '../../../../src/lib/supabase';
import { serviceOptions } from '../../../../src/constants/serviceOptions';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import GlassCard from '../../../../src/components/booking/GlassCard';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { colors } from '../../../../src/constants/colors';
import { Hub } from '../../../../src/types/booking';
import { generateTimeSlots } from '../../../../src/utils/timeSlots';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../../app/components/NavigationTab';

const SKY = colors.SKY;
const { width } = Dimensions.get('window');

export default function PhysicalSchedule() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ locationId?: string; serviceId?: string; vehicleId?: string; washType?: string }>();
  const locationId = params.locationId as string | undefined;
  const serviceId = params.serviceId as string | undefined;
  const vehicleId = params.vehicleId as string | undefined;
  const washType = params.washType as string | undefined;
  const [hub, setHub] = useState<Hub | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const timeSlots = useMemo(() => generateTimeSlots(), []);
  const service = serviceOptions.find((opt) => opt.id === serviceId);

  useEffect(() => {
    if (!locationId) return;
    const loadHub = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address')
        .eq('id', locationId)
        .maybeSingle();
      if (!error && data) {
        setHub(data);
      } else {
        setHub(null);
      }
      setLoading(false);
    };
    loadHub();
  }, [locationId]);

  const handleContinue = async () => {
    if (!serviceId || !selectedSlot || !locationId || !vehicleId) return;
    await hapticFeedback('medium');
    router.push({
      pathname: '/owner/booking/physical/confirm',
      params: {
        locationId,
        serviceId: serviceId,
        vehicleId: vehicleId,
        washType: washType || '',
        scheduledAt: selectedSlot,
      },
    });
  };

  if (!locationId || !serviceId || !vehicleId) {
    return (
      <SafeAreaView style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ color: '#fff' }}>Missing booking information.</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Pick time slot" />

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      ) : (
        <ScrollView contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]} showsVerticalScrollIndicator={false}>
          {hub && (
            <GlassCard style={styles.hubSummary} accountType="customer">
              <Text style={styles.hubLabel}>Location</Text>
              <Text style={styles.hubName}>{hub.name}</Text>
              <Text style={styles.hubAddress}>{hub.address}</Text>
            </GlassCard>
          )}

          {service && (
            <GlassCard style={styles.summaryCard} accountType="customer">
              <Text style={styles.summaryLabel}>Service</Text>
              <Text style={styles.summaryTitle}>{service.name}</Text>
              <Text style={styles.summarySubtitle}>{service.desc}</Text>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryMeta}>Duration: {service.dur}</Text>
                <Text style={styles.summaryPrice}>£{service.price}</Text>
              </View>
            </GlassCard>
          )}

          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Choose a time slot</Text>
            <View style={styles.slotGrid}>
              {timeSlots.map((slot) => {
                const date = new Date(slot);
                const isSelected = selectedSlot === slot;
                return (
                  <GlassCard
                    key={slot}
                    onPress={() => setSelectedSlot(slot)}
                    style={[styles.slotCard, isSelected && styles.slotCardSelected]}
                    accountType="customer"
                  >
                    <Text style={styles.slotDay}>
                      {date.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })}
                    </Text>
                    <Text style={styles.slotTime}>
                      {date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
                    </Text>
                  </GlassCard>
                );
              })}
            </View>
          </View>
        </ScrollView>
      )}

      <View style={[styles.footer, { paddingBottom: insets.bottom + TAB_BAR_TOTAL_HEIGHT }]}>
        <TouchableOpacity
          style={[
            styles.continueButton,
            (!serviceId || !selectedSlot) && { opacity: 0.5 },
          ]}
          disabled={!serviceId || !selectedSlot}
          onPress={handleContinue}
        >
          <Text style={styles.continueText}>Continue</Text>
          <Ionicons name="arrow-forward" size={18} color="#0A1929" />
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 120,
    gap: 24,
  },
  hubSummary: {
    padding: 16,
  },
  hubLabel: {
    color: 'rgba(135,206,235,0.8)',
    fontSize: 12,
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  hubName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
  },
  hubAddress: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 14,
    marginTop: 4,
  },
  section: {
    gap: 12,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
  },
  serviceGrid: {
    gap: 12,
  },
  serviceCard: {
    padding: 16,
  },
  serviceCardSelected: {
    borderColor: SKY,
    backgroundColor: 'rgba(135,206,235,0.1)',
  },
  serviceTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  serviceDesc: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 13,
    marginTop: 4,
    marginBottom: 10,
  },
  serviceMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  serviceDuration: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
  },
  servicePrice: {
    color: '#F9FAFB',
    fontWeight: '700',
    fontSize: 16,
  },
  slotGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  slotCard: {
    width: (width - 20 * 2 - 12) / 2,
    paddingVertical: 12,
    paddingHorizontal: 10,
  },
  slotCardSelected: {
    borderColor: SKY,
    backgroundColor: 'rgba(135,206,235,0.12)',
  },
  slotDay: {
    color: '#E5E7EB',
    fontSize: 12,
  },
  slotTime: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginTop: 2,
  },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 20,
    backgroundColor: 'transparent',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.05)',
  },
  continueButton: {
    backgroundColor: SKY,
    borderRadius: 18,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  continueText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: '700',
  },
});


