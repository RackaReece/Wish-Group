import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Image,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../../src/lib/supabase';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import { ecoServiceOptions } from '../../../../src/constants/serviceOptions';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const ECO_GREEN = colors.ECO_GREEN;
const BG = colors.BG;

interface Valeter {
  id: string;
  name: string;
  rating: number;
  totalJobs: number;
  distance: number;
  isOnline: boolean;
  profilePicture?: string;
  lastLat?: number;
  lastLng?: number;
}

export default function EcoValeterSelection() {
  const { user } = useAuth();
    const params = useLocalSearchParams();
  const serviceId = params.serviceId as string;
  const vehicleId = params.vehicleId as string;
  const latitude = parseFloat(params.latitude as string);
  const longitude = parseFloat(params.longitude as string);
  const address = params.address as string;
  const washType = params.washType as string;
  const discountAmount = parseFloat(params.discountAmount as string) || 0;

  const [valeters, setValeters] = useState<Valeter[]>([]);
  const [selectedValeter, setSelectedValeter] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();

    loadNearbyValeters();
  }, []);

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 3959; // Earth's radius in miles
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const loadNearbyValeters = async () => {
    try {
      // Load online valeters with their presence data
      const { data: presenceData, error: presenceError } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng')
        .eq('is_online', true);

      if (presenceError) throw presenceError;

      if (!presenceData || presenceData.length === 0) {
        setValeters([]);
        setLoading(false);
        return;
      }

      // Load valeter profiles
      const userIds = presenceData.map(p => p.user_id);
      const { data: profilesData, error: profilesError } = await supabase
        .from('valeter_profiles')
        .select('user_id, full_name, profile_photo_url')
        .in('user_id', userIds);

      if (profilesError) throw profilesError;

      // Combine data and calculate distances
      const valetersList: Valeter[] = presenceData
        .map(presence => {
          const profile = profilesData?.find(p => p.user_id === presence.user_id);
          const distance = presence.last_lat && presence.last_lng
            ? calculateDistance(latitude, longitude, presence.last_lat, presence.last_lng)
            : 999;

          return {
            id: presence.user_id,
            name: profile?.full_name || 'Valeter',
            rating: 4.8, // TODO: Get from reviews
            totalJobs: 0, // TODO: Get from bookings
            distance: Math.round(distance * 10) / 10,
            isOnline: presence.is_online,
            profilePicture: profile?.profile_photo_url,
            lastLat: presence.last_lat,
            lastLng: presence.last_lng,
          };
        })
        .filter(v => v.distance <= 10) // Within 10 miles
        .sort((a, b) => a.distance - b.distance);

      setValeters(valetersList);
    } catch (error) {
      console.error('Error loading valeters:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleValeterSelect = async (valeterId: string) => {
    await hapticFeedback('light');
    setSelectedValeter(valeterId);
  };

  const selectedServiceOption = ecoServiceOptions.find((option) => option.id === serviceId);

  const handleContinue = async () => {
    if (!selectedValeter || !selectedServiceOption) return;
    await hapticFeedback('medium');
    
    // Create booking with pending_valeter_acceptance status
    if (!user?.id) return;
    
    try {
      const scheduledAt = new Date().toISOString();
      const basePrice = selectedServiceOption.price || 18;
      const finalPrice = basePrice - discountAmount;
      
      const { data, error } = await supabase
        .from('bookings')
        .insert({
          user_id: user.id,
          valeter_id: selectedValeter,
          service_type: serviceId,
          service_name: selectedServiceOption.name || serviceId,
          status: 'pending_valeter_acceptance',
          price: finalPrice,
          location_address: address,
          location_lat: latitude,
          location_lng: longitude,
          discount_amount: discountAmount,
          request_sent_at: new Date().toISOString(),
          scheduled_at: scheduledAt,
        })
        .select()
        .single();

      if (error) throw error;

      router.push({
        pathname: '/owner/booking/waiting-acceptance',
        params: { bookingId: data.id },
      });
    } catch (error: any) {
      console.error('Error creating booking:', error);
      Alert.alert('Error', error?.message || 'Failed to create booking');
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[BG, '#065F46']} style={StyleSheet.absoluteFill} />

      <AppHeader title="Select Eco Valeter" />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Available Valeters</Text>
            <Text style={styles.sectionSubtitle}>Choose your preferred eco-friendly valeter</Text>

            {loading ? (
              <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color={ECO_GREEN} />
                <Text style={styles.loadingText}>Finding nearby valeters...</Text>
              </View>
            ) : valeters.length === 0 ? (
              <GlassCard style={styles.emptyCard}>
                <View style={styles.emptyContent}>
                  <Ionicons name="person-outline" size={48} color={ECO_GREEN} style={{ opacity: 0.5 }} />
                  <Text style={styles.emptyText}>No valeters available</Text>
                  <Text style={styles.emptySubtext}>Try again later or adjust your location</Text>
                </View>
              </GlassCard>
            ) : (
              <View style={styles.valeterList}>
                {valeters.map((valeter, index) => {
                  const isSelected = selectedValeter === valeter.id;
                  return (
                    <Animated.View
                      key={valeter.id}
                      style={{
                        opacity: fadeAnim,
                        transform: [
                          {
                            translateY: slideAnim.interpolate({
                              inputRange: [0, 50],
                              outputRange: [0, 50 * (index + 1)],
                            }),
                          },
                        ],
                      }}
                    >
                      <GlassCard
                        onPress={() => handleValeterSelect(valeter.id)}
                        style={[styles.valeterCard, isSelected && styles.valeterCardSelected]}
                        borderColor={isSelected ? ECO_GREEN : 'rgba(16,185,129,0.3)'}
                      >
                        <View style={styles.valeterContent}>
                          <View style={styles.valeterLeft}>
                            {valeter.profilePicture ? (
                              <Image
                                source={{ uri: valeter.profilePicture }}
                                style={styles.profileImage}
                              />
                            ) : (
                              <View style={styles.profilePlaceholder}>
                                <Ionicons name="person" size={24} color={ECO_GREEN} />
                              </View>
                            )}
                            {valeter.isOnline && (
                              <View style={styles.onlineBadge}>
                                <View style={styles.onlineDot} />
                              </View>
                            )}
                          </View>

                          <View style={styles.valeterInfo}>
                            <View style={styles.valeterHeader}>
                              <Text style={styles.valeterName}>{valeter.name}</Text>
                              {isSelected && (
                                <View style={styles.selectedBadge}>
                                  <Ionicons name="checkmark-circle" size={20} color={ECO_GREEN} />
                                </View>
                              )}
                            </View>
                            <View style={styles.valeterStats}>
                              <View style={styles.statItem}>
                                <Ionicons name="star" size={14} color="#FBBF24" />
                                <Text style={styles.statText}>{valeter.rating.toFixed(1)}</Text>
                              </View>
                              <View style={styles.statItem}>
                                <Ionicons name="car" size={14} color={ECO_GREEN} />
                                <Text style={styles.statText}>{valeter.totalJobs} jobs</Text>
                              </View>
                              <View style={styles.statItem}>
                                <Ionicons name="location" size={14} color={ECO_GREEN} />
                                <Text style={styles.statText}>{valeter.distance} mi</Text>
                              </View>
                            </View>
                          </View>
                        </View>
                      </GlassCard>
                    </Animated.View>
                  );
                })}
              </View>
            )}
          </View>

          {/* Continue Button */}
          {selectedValeter && (
            <Animated.View
              style={{
                opacity: fadeAnim,
                transform: [{ scale: fadeAnim }],
              }}
            >
              <TouchableOpacity
                onPress={handleContinue}
                style={styles.continueButton}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={[ECO_GREEN, '#059669']}
                  style={styles.continueGradient}
                >
                  <Text style={styles.continueText}>Continue</Text>
                  <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                </LinearGradient>
              </TouchableOpacity>
            </Animated.View>
          )}
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  sectionSubtitle: {
    color: ECO_GREEN,
    fontSize: 14,
    marginBottom: 20,
    opacity: 0.8,
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: ECO_GREEN,
    fontSize: 14,
  },
  emptyCard: {
    padding: 40,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtext: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
  },
  valeterList: {
    gap: 16,
  },
  valeterCard: {
    padding: 16,
  },
  valeterCardSelected: {
    elevation: 12,
    shadowColor: ECO_GREEN,
    shadowOpacity: 0.4,
  },
  valeterContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  valeterLeft: {
    position: 'relative',
  },
  profileImage: {
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 2,
    borderColor: ECO_GREEN,
  },
  profilePlaceholder: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(16,185,129,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: ECO_GREEN,
  },
  onlineBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: '#0A1929',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  onlineDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#10B981',
  },
  valeterInfo: {
    flex: 1,
  },
  valeterHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  selectedBadge: {
    marginLeft: 'auto',
  },
  valeterStats: {
    flexDirection: 'row',
    gap: 16,
    flexWrap: 'wrap',
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  statText: {
    color: ECO_GREEN,
    fontSize: 12,
    fontWeight: '600',
  },
  continueButton: {
    marginTop: 20,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: ECO_GREEN,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  continueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 8,
  },
  continueText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

