import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import MapView, { Marker, Region } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import GlassCard from '../../../src/components/booking/GlassCard';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

type BookingStatus = 'confirmed' | 'valeter_assigned' | 'en_route' | 'arrived' | 'in_progress' | 'completed';

export default function BookingTracking() {
  const { user } = useAuth();
    const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;

  const [booking, setBooking] = useState<any | null>(null);
  const [status, setStatus] = useState<BookingStatus>('confirmed');
  const [valeterLocation, setValeterLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const progressAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    // Pulse animation for marker
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(markerPulse, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    loadBooking();
    subscribeToBooking();
  }, [bookingId]);

  const loadBooking = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', bookingId)
        .single();

      if (error) throw error;
      setBooking(data);
      setStatus(data.status);

      // Set map region to booking location
      if (data.location_lat && data.location_lng) {
        setRegion({
          latitude: data.location_lat,
          longitude: data.location_lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      }
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const subscribeToBooking = () => {
    const channel = supabase
      .channel(`booking-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          setStatus(updated.status);

          if (updated.status === 'completed') {
            router.replace({
              pathname: '/owner/booking/completion',
              params: { bookingId },
            });
          }
        }
      )
      .subscribe();

    // Subscribe to valeter location updates
    if (booking?.valeter_id) {
      const valeterChannel = supabase
        .channel(`valeter-location-${booking.valeter_id}`)
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'valeter_presence',
            filter: `user_id=eq.${booking.valeter_id}`,
          },
          (payload) => {
            const updated = payload.new as any;
            if (updated.last_lat && updated.last_lng) {
              setValeterLocation({
                latitude: updated.last_lat,
                longitude: updated.last_lng,
              });
            }
          }
        )
        .subscribe();

      return () => {
        supabase.removeChannel(channel);
        supabase.removeChannel(valeterChannel);
      };
    }

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const getStatusProgress = (): number => {
    switch (status) {
      case 'confirmed':
        return 20;
      case 'valeter_assigned':
        return 40;
      case 'en_route':
        return 60;
      case 'arrived':
        return 80;
      case 'in_progress':
        return 90;
      case 'completed':
        return 100;
      default:
        return 0;
    }
  };

  const getStatusMessage = (): string => {
    switch (status) {
      case 'confirmed':
        return 'Payment complete! Valeter preparing to start';
      case 'valeter_assigned':
        return 'Valeter found and assigned';
      case 'en_route':
        return 'Valeter on the way';
      case 'arrived':
        return 'Your valeter has arrived';
      case 'in_progress':
        return 'Service in progress';
      case 'completed':
        return 'Service completed';
      default:
        return 'Tracking your booking';
    }
  };

  const getStatusSteps = () => {
    const steps = [
      { label: 'Confirmed', completed: ['confirmed', 'valeter_assigned', 'en_route', 'arrived', 'in_progress', 'completed'].includes(status) },
      { label: 'En Route', completed: ['en_route', 'arrived', 'in_progress', 'completed'].includes(status) },
      { label: 'Arrived', completed: ['arrived', 'in_progress', 'completed'].includes(status) },
      { label: 'In Progress', completed: ['in_progress', 'completed'].includes(status) },
      { label: 'Completed', completed: status === 'completed' },
    ];
    return steps;
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Live Tracking" />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
          },
        ]}
      >
        {/* Map */}
        <View style={styles.mapContainer}>
          <MapView style={styles.map} region={region} showsUserLocation={true}>
            {/* Booking location marker */}
            {booking?.location_lat && booking?.location_lng && (
              <Marker
                coordinate={{
                  latitude: booking.location_lat,
                  longitude: booking.location_lng,
                }}
              >
                <View style={styles.destinationMarker}>
                  <Ionicons name="flag" size={24} color="#EF4444" />
                </View>
              </Marker>
            )}

            {/* Valeter location marker */}
            {valeterLocation && (
              <Marker coordinate={valeterLocation}>
                <Animated.View
                  style={[
                    styles.valeterMarkerContainer,
                    {
                      transform: [{ scale: markerPulse }],
                    },
                  ]}
                >
                  <View style={styles.valeterMarker}>
                    <Ionicons name="car" size={20} color="#FFFFFF" />
                  </View>
                  <View style={styles.valeterPulse} />
                </Animated.View>
              </Marker>
            )}
          </MapView>
        </View>

        {/* Tracking Card */}
        <View style={styles.cardContainer}>
          <GlassCard style={styles.trackingCard}>
            <View style={styles.trackingHeader}>
              <StatusBadge status={status} size="medium" />
              <Text style={styles.statusMessage}>{getStatusMessage()}</Text>
            </View>

            {/* Progress Ring */}
            <View style={styles.progressContainer}>
              <AnimatedProgress progress={getStatusProgress()} size={120} />
            </View>

            {/* Status Steps */}
            <View style={styles.stepsContainer}>
              {getStatusSteps().map((step, index) => (
                <View key={index} style={styles.stepItem}>
                  <View
                    style={[
                      styles.stepDot,
                      step.completed && styles.stepDotCompleted,
                    ]}
                  >
                    {step.completed && (
                      <Ionicons name="checkmark" size={12} color="#FFFFFF" />
                    )}
                  </View>
                  <Text
                    style={[
                      styles.stepLabel,
                      step.completed && styles.stepLabelCompleted,
                    ]}
                  >
                    {step.label}
                  </Text>
                </View>
              ))}
            </View>

            {/* Booking Info */}
            {booking && (
              <View style={styles.bookingInfo}>
                <View style={styles.infoRow}>
                  <Ionicons name="water-outline" size={16} color={SKY} />
                  <Text style={styles.infoText}>
                    {getServiceDisplayName(booking.service_type, booking.service_name)}
                  </Text>
                </View>
                <View style={styles.infoRow}>
                  <Ionicons name="location-outline" size={16} color={SKY} />
                  <Text style={styles.infoText} numberOfLines={1}>
                    {booking.location_address}
                  </Text>
                </View>
                <View style={styles.infoRow}>
                  <Ionicons name="cash-outline" size={16} color={SKY} />
                  <Text style={styles.infoText}>£{booking.price?.toFixed(2) || '0.00'}</Text>
                </View>
              </View>
            )}
          </GlassCard>
        </View>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  content: {
    flex: 1,
    paddingTop: HEADER_CONTENT_OFFSET,
  },
  mapContainer: {
    flex: 1,
  },
  map: {
    flex: 1,
  },
  destinationMarker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  valeterMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  valeterMarker: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  valeterPulse: {
    position: 'absolute',
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: SKY,
    opacity: 0.3,
  },
  cardContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 20,
    paddingBottom: 40,
  },
  trackingCard: {
    padding: 20,
  },
  trackingHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  statusMessage: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginTop: 12,
    textAlign: 'center',
  },
  progressContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  stepsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
    paddingHorizontal: 8,
  },
  stepItem: {
    alignItems: 'center',
    flex: 1,
  },
  stepDot: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  stepDotCompleted: {
    backgroundColor: SKY,
  },
  stepLabel: {
    color: '#9CA3AF',
    fontSize: 10,
    textAlign: 'center',
  },
  stepLabelCompleted: {
    color: SKY,
    fontWeight: '600',
  },
  bookingInfo: {
    gap: 12,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  infoText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
  },
});

