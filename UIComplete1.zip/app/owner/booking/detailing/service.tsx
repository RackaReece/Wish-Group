import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import { detailingServiceOptions } from '../../../../src/constants/serviceOptions';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;

export default function DetailingServiceSelection() {
    const params = useLocalSearchParams();
  const locationId = params.locationId as string;
  const vehicleId = params.vehicleId as string;
  
  const [selectedService, setSelectedService] = useState<string | null>(null);
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handleServiceSelect = async (serviceId: string) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
  };

  const handleContinue = async () => {
    if (!selectedService || !locationId || !vehicleId) return;
    await hapticFeedback('medium');
    
    router.push({
      pathname: '/owner/booking/detailing/schedule',
      params: {
        serviceId: selectedService,
        vehicleId,
        locationId,
      },
    });
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[BG, '#4C1D95']} style={StyleSheet.absoluteFill} />

      <AppHeader title="Select Detailing Service" />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Choose Service</Text>
            <Text style={styles.sectionSubtitle}>Select your preferred detailing package</Text>
            
            <View style={styles.serviceGrid}>
              {detailingServiceOptions.map((service, index) => {
                const isSelected = selectedService === service.id;
                return (
                  <Animated.View
                    key={service.id}
                    style={[
                      styles.serviceCardWrapper,
                      {
                        opacity: fadeAnim,
                        transform: [
                          {
                            translateY: slideAnim.interpolate({
                              inputRange: [0, 50],
                              outputRange: [0, 50 * (index % 2)],
                            }),
                          },
                        ],
                      },
                    ]}
                  >
                    <GlassCard
                      onPress={() => handleServiceSelect(service.id)}
                      style={[styles.serviceCard, isSelected && styles.serviceCardSelected]}
                      borderColor={isSelected ? service.colors[0] : 'rgba(139,92,246,0.3)'}
                    >
                      <LinearGradient
                        colors={isSelected ? [service.colors[0] + '30', service.colors[1] + '20'] : ['transparent', 'transparent']}
                        style={StyleSheet.absoluteFill}
                      />
                      <View style={styles.serviceContent}>
                        <View style={[styles.serviceIconWrapper, { backgroundColor: service.colors[0] + '20' }]}>
                          <Ionicons name={service.icon as any} size={26} color={service.colors[0]} />
                        </View>
                        <View style={styles.serviceDetails}>
                          <Text
                            style={[styles.serviceName, isSelected && { color: service.colors[0] }]}
                            numberOfLines={1}
                          >
                            {service.name}
                          </Text>
                          <Text style={styles.serviceDesc} numberOfLines={2}>
                            {service.desc}
                          </Text>
                          <View style={styles.serviceMeta}>
                            <Ionicons name="time-outline" size={12} color={PREMIUM_PURPLE} />
                            <Text style={styles.serviceMetaText}>{service.dur}</Text>
                          </View>
                        </View>
                        <View style={styles.priceColumn}>
                          <Text style={styles.priceLabel}>Price</Text>
                          <Text style={[styles.servicePriceText, isSelected && { color: service.colors[0] }]}>
                            £{service.price}
                          </Text>
                        </View>
                        {isSelected && (
                          <View style={[styles.selectedBadge, { backgroundColor: service.colors[0] }]}>
                            <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                          </View>
                        )}
                      </View>
                    </GlassCard>
                  </Animated.View>
                );
              })}
            </View>
          </View>

          {selectedService && (
            <Animated.View
              style={{
                opacity: fadeAnim,
                transform: [{ scale: fadeAnim }],
              }}
            >
              <TouchableOpacity
                onPress={handleContinue}
                style={styles.continueButton}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={[PREMIUM_PURPLE, '#7C3AED']}
                  style={styles.continueGradient}
                >
                  <Text style={styles.continueText}>Continue</Text>
                  <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                </LinearGradient>
              </TouchableOpacity>
            </Animated.View>
          )}
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  sectionSubtitle: {
    color: PREMIUM_PURPLE,
    fontSize: 14,
    marginBottom: 20,
    opacity: 0.8,
  },
  serviceGrid: {
    gap: 16,
  },
  serviceCardWrapper: {
    width: '100%',
  },
  serviceCard: {
    padding: 16,
  },
  serviceCardSelected: {
    elevation: 12,
    shadowColor: PREMIUM_PURPLE,
    shadowOpacity: 0.4,
  },
  serviceContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  serviceIconWrapper: {
    width: 60,
    height: 60,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  serviceDetails: {
    flex: 1,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
    textAlign: 'left',
  },
  serviceDesc: {
    color: '#E5E7EB',
    fontSize: 12,
    marginBottom: 10,
    textAlign: 'left',
    lineHeight: 16,
  },
  serviceMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 0,
  },
  serviceMetaText: {
    color: PREMIUM_PURPLE,
    fontSize: 10,
  },
  priceColumn: {
    alignItems: 'flex-end',
    justifyContent: 'center',
    minWidth: 70,
  },
  priceLabel: {
    color: '#94A3B8',
    fontSize: 12,
    marginBottom: 4,
  },
  servicePriceText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  selectedBadge: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 22,
    height: 22,
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
  },
  continueButton: {
    marginTop: 20,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: PREMIUM_PURPLE,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  continueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 8,
  },
  continueText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

