import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Region, MapPressEvent } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import * as Location from 'expo-location';
import { supabase } from '../../../../src/lib/supabase';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { Hub } from '../../../../src/types/booking';

const { width, height } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;
const LIGHT_SKY = colors.LIGHT_SKY;
const HUB_RADIUS_MILES = 10;

export default function DetailingLocation() {
  const params = useLocalSearchParams();
  const vehicleId = params.vehicleId as string;
  const { coords } = useLiveLocation();

  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const [selectedHub, setSelectedHub] = useState<Hub | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<{ latitude: number; longitude: number; address: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [hubs, setHubs] = useState<Hub[]>([]);
  const [filteredHubs, setFilteredHubs] = useState<Hub[]>([]);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const mapAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const panelSlideAnim = useRef(new Animated.Value(height)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(mapAnim, {
        toValue: 1,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(markerPulse, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    loadHubs();
    getCurrentLocation();
  }, []);

  const loadHubs = async () => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude,status,wait_time_minutes,organization_id')
        .order('created_at', { ascending: true });
      if (error) throw error;
      setHubs(data || []);
    } catch (err) {
      console.error('[detailing-location] load hubs error', err);
      setHubs([]);
    } finally {
      setLoading(false);
    }
  };

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        setLoading(false);
        return;
      }

      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
      };
      
      setLocation(coords);
      setRegion({
        ...coords,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    } catch (error) {
      console.error('Error getting location:', error);
    }
  };

  const handleMapPress = async (event: MapPressEvent) => {
    const coordinate = event?.nativeEvent?.coordinate;
    if (!coordinate) return;

    await hapticFeedback('light');
    setSelectedHub(null); // Clear hub selection when tapping map
    const coords = {
      latitude: coordinate.latitude,
      longitude: coordinate.longitude,
    };
    setLocation(coords);
    setRegion({
      ...coords,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    });

    try {
      const [result] = await Location.reverseGeocodeAsync(coords);
      if (result) {
        const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim();
        const newLocation = { ...coords, address: addr };
        setSelectedLocation(newLocation);
        
        Animated.spring(panelSlideAnim, {
          toValue: 0,
          tension: 50,
          friction: 8,
          useNativeDriver: true,
        }).start();
      }
    } catch (error) {
      console.error('Error reverse geocoding:', error);
    }
  };

  const handleHubMarkerPress = (hub: Hub) => {
    hapticFeedback('light');
    setSelectedHub(hub);
    setSelectedLocation(null);
    
    if (hub.latitude && hub.longitude) {
      setLocation({ latitude: hub.latitude, longitude: hub.longitude });
      setRegion({
        latitude: hub.latitude,
        longitude: hub.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    }
    
    Animated.spring(panelSlideAnim, {
      toValue: 0,
      tension: 50,
      friction: 8,
      useNativeDriver: true,
    }).start();
  };

  const handleUseCurrentLocation = async () => {
    await hapticFeedback('medium');
    await getCurrentLocation();
    
    setTimeout(() => {
      if (location) {
        Animated.spring(panelSlideAnim, {
          toValue: 0,
          tension: 50,
          friction: 8,
          useNativeDriver: true,
        }).start();
      }
    }, 300);
  };

  const handleSelect = () => {
    if (!selectedHub) {
      Alert.alert('Hub Required', 'Please select a hub from the map.');
      return;
    }
    hapticFeedback('medium');
    
    router.push({
      pathname: '/owner/booking/detailing/service',
      params: { 
        locationId: selectedHub.id,
        vehicleId: vehicleId || '',
      },
    });
  };

  const calculateDistance = (hub: Hub) => {
    if (!coords || !hub.latitude || !hub.longitude) return null;
    const toRad = (value: number) => (value * Math.PI) / 180;
    const R = 3959;
    const dLat = toRad(hub.latitude - coords.latitude);
    const dLon = toRad(hub.longitude - coords.longitude);
    const lat1 = toRad(coords.latitude);
    const lat2 = toRad(hub.latitude);
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return (R * c).toFixed(1);
  };

  const filterHubsByRadius = () => {
    if (!coords) {
      // If no coords available, show all hubs with valid coordinates
      setFilteredHubs(hubs.filter(hub => hub.latitude && hub.longitude));
      return;
    }

    const filtered = hubs.filter(hub => {
      if (!hub.latitude || !hub.longitude) return false;
      const distanceStr = calculateDistance(hub);
      if (!distanceStr) return false;
      const distance = parseFloat(distanceStr);
      return distance <= HUB_RADIUS_MILES;
    });

    setFilteredHubs(filtered);
  };

  // Filter hubs when coords or hubs change
  useEffect(() => {
    filterHubsByRadius();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [coords, hubs]);

  const formatWait = (minutes?: number | null) => {
    if (!minutes) return 'Instant availability';
    if (minutes < 15) return 'Under 15 min wait';
    return `${minutes} min wait`;
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[BG, colors.premiumPurple]} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Choose detailing hub"
        rightAction={
          <TouchableOpacity onPress={handleUseCurrentLocation} style={styles.currentLocationButton}>
            <Ionicons name="locate" size={20} color={SKY} />
          </TouchableOpacity>
        }
      />

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={PREMIUM_PURPLE} />
          <Text style={styles.loadingText}>Finding detailing hubs…</Text>
        </View>
      ) : (
        <Animated.View
          style={[
            styles.content,
            {
              opacity: fadeAnim,
              transform: [{ scale: mapAnim }],
            },
          ]}
        >
          {/* Map */}
          <View style={styles.mapContainer}>
            <MapView
              style={styles.map}
              region={region}
              onPress={handleMapPress}
              showsUserLocation={true}
              showsMyLocationButton={false}
            >
              {/* Hub Markers */}
              {filteredHubs.map((hub) => (
                  <Marker
                    key={hub.id}
                    coordinate={{
                      latitude: hub.latitude!,
                      longitude: hub.longitude!,
                    }}
                    onPress={() => handleHubMarkerPress(hub)}
                  >
                    <View style={styles.hubMarkerContainer}>
                      <View style={styles.hubMarkerPin}>
                        <Ionicons name="diamond" size={20} color={PREMIUM_PURPLE} />
                      </View>
                      {selectedHub?.id === hub.id && (
                        <Animated.View
                          style={[
                            styles.hubMarkerPulse,
                            {
                              transform: [{ scale: markerPulse }],
                            },
                          ]}
                        />
                      )}
                    </View>
                  </Marker>
                ))}

              {/* Selected Location Marker */}
              {selectedLocation && !selectedHub && location && (
                <Marker coordinate={location}>
                  <Animated.View
                    style={[
                      styles.markerContainer,
                      {
                        transform: [{ scale: markerPulse }],
                      },
                    ]}
                  >
                    <View style={styles.markerPin}>
                      <Ionicons name="location" size={24} color={PREMIUM_PURPLE} />
                    </View>
                    <View style={styles.markerPulse} />
                  </Animated.View>
                </Marker>
              )}
            </MapView>
          </View>

          {/* Hub/Location Card - Slides up from bottom */}
          <Animated.View
            style={[
              styles.cardContainer,
              {
                transform: [{ translateY: panelSlideAnim }],
              },
            ]}
          >
            <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollContainer}>
              {selectedHub ? (
                <GlassCard style={styles.locationCard}>
                  <View style={styles.badge}>
                    <Ionicons name="diamond" size={14} color={PREMIUM_PURPLE} />
                    <Text style={styles.badgeText}>Premium Detailing</Text>
                  </View>
                  <View style={styles.locationHeader}>
                    <Text style={styles.locationTitle}>{selectedHub.name}</Text>
                    {calculateDistance(selectedHub) && (
                      <View style={styles.distancePill}>
                        <Ionicons name="navigate" size={12} color={BG} />
                        <Text style={styles.distanceText}>{calculateDistance(selectedHub)} mi</Text>
                      </View>
                    )}
                  </View>
                  <Text style={styles.locationAddress}>{selectedHub.address || 'Address coming soon'}</Text>
                  <View style={styles.hubMetaRow}>
                    <View style={styles.metaItem}>
                      <Ionicons name="time-outline" size={14} color={PREMIUM_PURPLE} />
                      <Text style={styles.metaText}>{formatWait(selectedHub.wait_time_minutes)}</Text>
                    </View>
                    {selectedHub.status && (
                      <View style={styles.metaItem}>
                        <Ionicons name="sparkles-outline" size={14} color={PREMIUM_PURPLE} />
                        <Text style={styles.metaText}>{selectedHub.status}</Text>
                      </View>
                    )}
                  </View>
                </GlassCard>
              ) : selectedLocation ? (
                <GlassCard style={styles.locationCard}>
                  <View style={styles.locationHeader}>
                    <Ionicons name="location" size={24} color={PREMIUM_PURPLE} />
                    <Text style={styles.locationTitle}>Selected Location</Text>
                  </View>
                  <View style={styles.locationInfo}>
                    <Text style={styles.locationAddress}>{selectedLocation.address}</Text>
                    <View style={styles.locationCoords}>
                      <Ionicons name="map-outline" size={12} color={PREMIUM_PURPLE} />
                      <Text style={styles.coordsText}>
                        {selectedLocation.latitude.toFixed(4)}, {selectedLocation.longitude.toFixed(4)}
                      </Text>
                    </View>
                  </View>
                  <Text style={styles.tapHint}>Tap a hub marker on the map to select</Text>
                </GlassCard>
              ) : (
                <GlassCard style={styles.locationCard}>
                  <Text style={styles.tapHint}>Tap on the map or select a hub marker</Text>
                </GlassCard>
              )}
            </ScrollView>

            {/* Continue Button */}
            {selectedHub && (
              <Animated.View
                style={{
                  opacity: fadeAnim,
                  transform: [{ scale: fadeAnim }],
                }}
              >
                <TouchableOpacity
                  onPress={handleSelect}
                  style={styles.continueButton}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={[PREMIUM_PURPLE, '#6D28D9']}
                    style={styles.continueGradient}
                  >
                    <Text style={styles.continueText}>Select Hub</Text>
                    <Ionicons name="arrow-forward" size={20} color={LIGHT_SKY} />
                  </LinearGradient>
                </TouchableOpacity>
              </Animated.View>
            )}
          </Animated.View>
        </Animated.View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  currentLocationButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: '#E5E7EB',
    fontSize: 14,
  },
  content: {
    flex: 1,
    paddingTop: HEADER_CONTENT_OFFSET,
  },
  mapContainer: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 0,
  },
  map: {
    flex: 1,
  },
  hubMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  hubMarkerPin: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: LIGHT_SKY,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  hubMarkerPulse: {
    position: 'absolute',
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: PREMIUM_PURPLE,
    opacity: 0.3,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  markerPin: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: LIGHT_SKY,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  markerPulse: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: PREMIUM_PURPLE,
    opacity: 0.3,
  },
  cardContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    maxHeight: height * 0.5,
    backgroundColor: customerTheme.backgroundColor,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 16,
    zIndex: 100,
  },
  scrollContainer: {
    padding: 16,
    paddingBottom: 20,
  },
  locationCard: {
    padding: 16,
    marginBottom: 12,
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(139,92,246,0.2)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    alignSelf: 'flex-start',
    marginBottom: 12,
  },
  badgeText: {
    color: PREMIUM_PURPLE,
    fontSize: 11,
    fontWeight: '700',
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
    marginBottom: 8,
  },
  locationTitle: {
    color: LIGHT_SKY,
    fontSize: 18,
    fontWeight: '700',
    flex: 1,
  },
  distancePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: PREMIUM_PURPLE,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 999,
  },
  distanceText: {
    color: BG,
    fontSize: 12,
    fontWeight: '700',
  },
  locationInfo: {
    gap: 8,
  },
  locationAddress: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 14,
    marginBottom: 8,
  },
  hubMetaRow: {
    flexDirection: 'row',
    gap: 16,
    marginTop: 8,
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  metaText: {
    color: '#E5E7EB',
    fontSize: 13,
  },
  locationCoords: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  coordsText: {
    color: PREMIUM_PURPLE,
    fontSize: 12,
  },
  tapHint: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
    fontStyle: 'italic',
  },
  continueButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: PREMIUM_PURPLE,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    marginTop: 8,
    marginHorizontal: 16,
    marginBottom: 16,
  },
  continueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 32,
    gap: 8,
  },
  continueText: {
    color: LIGHT_SKY,
    fontSize: 18,
    fontWeight: 'bold',
  },
});
