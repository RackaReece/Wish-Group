import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

type PaymentMethod = {
  id: string;
  type: 'card' | 'apple_pay' | 'google_pay';
  name: string;
  last4?: string;
  expiry?: string;
  isDefault: boolean;
};

export default function PaymentMethods() {
    const [paymentMethods] = useState<PaymentMethod[]>([
    {
      id: '1',
      type: 'card',
      name: 'Visa ending in 4242',
      last4: '4242',
      expiry: '12/25',
      isDefault: true,
    },
    {
      id: '2',
      type: 'card',
      name: 'Mastercard ending in 5555',
      last4: '5555',
      expiry: '08/26',
      isDefault: false,
    },
  ]);

  const getIcon = (type: string) => {
    switch (type) {
      case 'card':
        return 'card';
      case 'apple_pay':
        return 'logo-apple';
      case 'google_pay':
        return 'logo-google';
      default:
        return 'card';
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Payment Methods"
        rightAction={
          <TouchableOpacity style={styles.addButton}>
            <Ionicons name="add" size={24} color={SKY} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
      >
        {paymentMethods.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="card-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
            <Text style={styles.emptyTitle}>No Payment Methods</Text>
            <Text style={styles.emptySubtitle}>Add a payment method to get started</Text>
          </View>
        ) : (
          paymentMethods.map((method) => (
            <View key={method.id} style={styles.paymentCard}>
              <View style={styles.paymentIconWrapper}>
                <Ionicons name={getIcon(method.type) as any} size={24} color={SKY} />
              </View>
              <View style={styles.paymentContent}>
                <View style={styles.paymentHeader}>
                  <Text style={styles.paymentName}>{method.name}</Text>
                  {method.isDefault && (
                    <View style={styles.defaultBadge}>
                      <Text style={styles.defaultText}>Default</Text>
                    </View>
                  )}
                </View>
                {method.expiry && (
                  <Text style={styles.paymentExpiry}>Expires {method.expiry}</Text>
                )}
              </View>
              <TouchableOpacity>
                <Ionicons name="chevron-forward" size={20} color="#87CEEB" />
              </TouchableOpacity>
            </View>
          ))
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 12 : 20 },
  addButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
  },
  paymentCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  paymentIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  paymentContent: {
    flex: 1,
  },
  paymentHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  paymentName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '700',
    marginRight: 8,
  },
  defaultBadge: {
    backgroundColor: 'rgba(16,185,129,0.2)',
    paddingVertical: 2,
    paddingHorizontal: 8,
    borderRadius: 6,
  },
  defaultText: {
    color: '#10B981',
    fontSize: 11,
    fontWeight: '700',
  },
  paymentExpiry: {
    color: '#87CEEB',
    fontSize: 13,
    opacity: 0.8,
  },
});

