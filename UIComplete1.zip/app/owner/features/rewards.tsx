import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function Rewards() {
  const { user } = useAuth();
    const [points] = useState(1250);

  const rewards = [
    { id: '1', title: 'Free Basic Wash', points: 500, icon: 'car', available: points >= 500 },
    { id: '2', title: 'Free Premium Wash', points: 1000, icon: 'sparkles', available: points >= 1000 },
    { id: '3', title: 'Free Full Valet', points: 2000, icon: 'diamond', available: points >= 2000 },
    { id: '4', title: '10% Discount', points: 300, icon: 'pricetag', available: points >= 300 },
    { id: '5', title: '20% Discount', points: 750, icon: 'pricetag', available: points >= 750 },
  ];

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Rewards" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Points Card */}
        <View style={styles.pointsCard}>
          <BlurView intensity={35} tint="dark" style={styles.pointsBlur}>
            <LinearGradient
              colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.pointsBorder} />
            <View style={styles.pointsGradient}>
              <View style={styles.pointsIconWrapper}>
                <Ionicons name="gift" size={32} color={SKY} />
              </View>
              <Text style={styles.pointsLabel}>Your Points</Text>
              <Text style={styles.pointsValue}>{points.toLocaleString()}</Text>
              <Text style={styles.pointsSubtext}>Keep booking to earn more!</Text>
            </View>
          </BlurView>
        </View>

        {/* Rewards List */}
        <View style={styles.rewardsSection}>
          <Text style={styles.sectionTitle}>Available Rewards</Text>
          {rewards.map((reward) => (
            <TouchableOpacity
              key={reward.id}
              style={[styles.rewardCard, !reward.available && styles.rewardCardDisabled]}
              disabled={!reward.available}
              activeOpacity={0.8}
            >
              <BlurView intensity={30} tint="dark" style={styles.rewardBlur}>
                <LinearGradient
                  colors={['rgba(255,255,255,0.06)', 'rgba(255,255,255,0.02)']}
                  style={StyleSheet.absoluteFill}
                />
                <View style={[styles.rewardBorder, { 
                  borderColor: reward.available 
                    ? 'rgba(135,206,235,0.25)' 
                    : 'rgba(107,114,128,0.2)' 
                }]} />
                <View style={styles.rewardContentWrapper}>
                  <View style={[styles.rewardIconWrapper, { 
                    backgroundColor: reward.available 
                      ? 'rgba(135,206,235,0.15)' 
                      : 'rgba(107,114,128,0.1)' 
                  }]}>
                    <Ionicons name={reward.icon as any} size={24} color={reward.available ? SKY : '#6B7280'} />
                  </View>
                  <View style={styles.rewardContent}>
                    <Text style={[styles.rewardTitle, !reward.available && styles.rewardTitleDisabled]}>
                      {reward.title}
                    </Text>
                    <Text style={styles.rewardPoints}>{reward.points} points</Text>
                  </View>
                  {reward.available ? (
                    <Ionicons name="checkmark-circle" size={24} color="#10B981" />
                  ) : (
                    <Ionicons name="lock-closed" size={24} color="#6B7280" />
                  )}
                </View>
              </BlurView>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 12 : 20 },
  pointsCard: {
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  pointsBlur: {
    borderRadius: 20,
    overflow: 'hidden',
  },
  pointsBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  pointsGradient: {
    padding: 24,
    alignItems: 'center',
  },
  pointsIconWrapper: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  pointsLabel: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  pointsValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 36 : 42,
    fontWeight: '800',
    marginBottom: 4,
  },
  pointsSubtext: {
    color: '#87CEEB',
    fontSize: 13,
    opacity: 0.8,
  },
  rewardsSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  rewardCard: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  rewardCardDisabled: {
    opacity: 0.5,
  },
  rewardBlur: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  rewardBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 16,
    borderWidth: 1,
  },
  rewardContentWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  rewardIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  rewardContent: {
    flex: 1,
  },
  rewardTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 17,
    fontWeight: '700',
    marginBottom: 4,
  },
  rewardTitleDisabled: {
    color: '#6B7280',
  },
  rewardPoints: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '600',
  },
});



