import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import StatusBadge from '../../src/components/booking/StatusBadge';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

interface Booking {
  id: string;
  customer_name: string;
  service_type: string;
  location_address: string | null;
  scheduled_time: string | null;
  status: string;
  assigned_valeter_name: string | null;
  created_at: string;
  customer_on_way?: boolean;
  cancelled?: boolean;
  has_report?: boolean;
}

export default function BusinessBookings() {
  const { user } = useAuth();
    const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string | null>(null);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadBookings();
    } else {
      setLoading(false);
    }
  }, [user?.id, filterStatus]);

  const loadBookings = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      
      // Get all locations for this business
      const { data: locations } = await supabase
        .from('car_wash_locations')
        .select('address')
        .eq('organization_id', user.id);

      const locationAddresses = locations?.map((l) => l.address).filter(Boolean) || [];

      let query = supabase
        .from('bookings')
        .select('id, customer_id, service_type, location_address, scheduled_time, status, valeter_id, created_at')
        .in('status', [
          'pending_business_acceptance',
          'pending_valeter_acceptance',
          'confirmed',
          'in_progress',
          'completed',
          'cancelled',
        ])
        .order('created_at', { ascending: false })
        .limit(50);

      // Filter by location addresses if any
      if (locationAddresses.length > 0) {
        query = query.in('location_address', locationAddresses);
      }

      const { data, error } = await query;

      if (error) throw error;

      // Enrich with customer and valeter names
      const enrichedBookings = await Promise.all(
        (data || []).map(async (booking) => {
          const { data: customer } = await supabase
            .from('users')
            .select('name')
            .eq('id', booking.customer_id)
            .single();

          const { data: valeter } = booking.valeter_id
            ? await supabase
                .from('users')
                .select('name')
                .eq('id', booking.valeter_id)
                .single()
            : { data: null };

          return {
            id: booking.id,
            customer_name: customer?.name || 'Unknown',
            service_type: booking.service_type || 'Unknown',
            location_address: booking.location_address,
            scheduled_time: booking.scheduled_time,
            status: booking.status,
            assigned_valeter_name: valeter?.name || null,
            created_at: booking.created_at,
            customer_on_way: booking.status === 'in_progress', // Placeholder
            cancelled: booking.status === 'cancelled',
            has_report: false, // Placeholder
          };
        })
      );

      const filtered = filterStatus
        ? enrichedBookings.filter((b) => b.status === filterStatus)
        : enrichedBookings;

      setBookings(filtered);
    } catch (error) {
      console.error('Error loading bookings:', error);
    } finally {
      setLoading(false);
    }
  };

  const statusFilters = [
    { label: 'All', value: null },
    { label: 'Pending', value: 'pending_business_acceptance' },
    { label: 'Confirmed', value: 'confirmed' },
    { label: 'In Progress', value: 'in_progress' },
    { label: 'Completed', value: 'completed' },
    { label: 'Cancelled', value: 'cancelled' },
  ];

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Bookings" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading bookings...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Bookings"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        {/* Status Filters */}
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={styles.filtersContainer}
          contentContainerStyle={styles.filtersContent}
        >
          {statusFilters.map((filter) => (
            <TouchableOpacity
              key={filter.value || 'all'}
              onPress={async () => {
                await hapticFeedback('light');
                setFilterStatus(filter.value);
              }}
              style={styles.filterButton}
            >
              <GlassCard
                style={[
                  styles.filterCard,
                  filterStatus === filter.value && styles.filterCardActive,
                ]}
                accountType="business"
              >
                <Text
                  style={[
                    styles.filterText,
                    filterStatus === filter.value && styles.filterTextActive,
                  ]}
                >
                  {filter.label}
                </Text>
              </GlassCard>
            </TouchableOpacity>
          ))}
        </ScrollView>

        {/* Bookings List */}
        {bookings.length === 0 ? (
          <Animated.View style={[styles.emptyContainer, { opacity: fadeAnim }]}>
            <GlassCard style={styles.emptyCard} accountType="business">
              <View style={styles.emptyContent}>
                <Ionicons name="calendar-outline" size={40} color="#8B5CF6" style={{ opacity: 0.6 }} />
                <Text style={styles.emptyTitle}>No bookings yet</Text>
                <Text style={styles.emptyText}>
                  {filterStatus
                    ? `No ${statusFilters.find((f) => f.value === filterStatus)?.label.toLowerCase()} bookings`
                    : 'Bookings will appear here as customers book your services'}
                </Text>
              </View>
            </GlassCard>
          </Animated.View>
        ) : (
          <View style={styles.bookingsList}>
            {bookings.map((booking, index) => (
              <Animated.View
                key={booking.id}
                style={[
                  { opacity: fadeAnim },
                  {
                    transform: [
                      {
                        translateY: fadeAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [30 + index * 10, 0],
                        }),
                      },
                    ],
                  },
                ]}
              >
                <GlassCard
                  onPress={async () => {
                    await hapticFeedback('light');
                    router.push(`/business/bookings/${booking.id}` as any);
                  }}
                  style={styles.bookingCard}
                  accountType="business"
                >
                  <View style={styles.bookingHeader}>
                    <View style={styles.bookingInfo}>
                      <Text style={styles.customerName}>{booking.customer_name}</Text>
                      <Text style={styles.serviceType}>{booking.service_type}</Text>
                    </View>
                    <StatusBadge status={booking.status as any} size="small" />
                  </View>

                  <View style={styles.bookingDetails}>
                    {booking.location_address && (
                      <View style={styles.detailRow}>
                        <Ionicons name="location" size={16} color={SKY} />
                        <Text style={styles.detailText} numberOfLines={1}>
                          {booking.location_address}
                        </Text>
                      </View>
                    )}

                    {booking.scheduled_time && (
                      <View style={styles.detailRow}>
                        <Ionicons name="time" size={16} color={SKY} />
                        <Text style={styles.detailText}>
                          {new Date(booking.scheduled_time).toLocaleString()}
                        </Text>
                      </View>
                    )}

                    {booking.assigned_valeter_name && (
                      <View style={styles.detailRow}>
                        <Ionicons name="person" size={16} color={SKY} />
                        <Text style={styles.detailText}>
                          {booking.assigned_valeter_name}
                        </Text>
                      </View>
                    )}
                  </View>

                  {(booking.customer_on_way || booking.has_report || booking.cancelled) && (
                    <View style={styles.bookingFlags}>
                      {booking.customer_on_way && (
                        <View style={styles.flag}>
                          <Ionicons name="car" size={14} color="#F59E0B" />
                          <Text style={styles.flagText}>On Way</Text>
                        </View>
                      )}
                      {booking.has_report && (
                        <View style={[styles.flag, styles.flagReport]}>
                          <Ionicons name="alert-circle" size={14} color="#EF4444" />
                          <Text style={[styles.flagText, styles.flagTextReport]}>Report</Text>
                        </View>
                      )}
                      {booking.cancelled && (
                        <View style={[styles.flag, styles.flagCancelled]}>
                          <Ionicons name="close-circle" size={14} color="#EF4444" />
                          <Text style={[styles.flagText, styles.flagTextCancelled]}>
                            Cancelled
                          </Text>
                        </View>
                      )}
                    </View>
                  )}

                  <View style={styles.bookingActions}>
                    <TouchableOpacity
                      onPress={async (e) => {
                        e.stopPropagation();
                        await hapticFeedback('light');
                        router.push(`/business/bookings/${booking.id}` as any);
                      }}
                      style={styles.actionButton}
                    >
                      <Text style={styles.actionText}>View Details</Text>
                      <Ionicons name="chevron-forward" size={16} color={SKY} />
                    </TouchableOpacity>
                  </View>
                </GlassCard>
              </Animated.View>
            ))}
          </View>
        )}
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  filtersContainer: {
    marginBottom: 12,
  },
  filtersContent: {
    gap: 12,
    paddingRight: 20,
  },
  filterButton: {
    marginRight: 8,
  },
  filterCard: {
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  filterCardActive: {
    backgroundColor: 'rgba(135,206,235,0.15)',
  },
  filterText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    fontWeight: '600',
  },
  filterTextActive: {
    color: SKY,
    fontWeight: '700',
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    minHeight: 300,
    marginTop: 8,
  },
  emptyCard: {
    padding: 40,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginTop: 20,
    marginBottom: 12,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  bookingsList: {
    gap: 16,
  },
  bookingCard: {
    padding: 16,
  },
  bookingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  bookingInfo: {
    flex: 1,
  },
  customerName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  serviceType: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
  },
  bookingDetails: {
    gap: 8,
    marginBottom: 12,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  detailText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    flex: 1,
  },
  bookingFlags: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  flag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(245,158,11,0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  flagReport: {
    backgroundColor: 'rgba(239,68,68,0.15)',
  },
  flagCancelled: {
    backgroundColor: 'rgba(239,68,68,0.15)',
  },
  flagText: {
    color: '#F59E0B',
    fontSize: 11,
    fontWeight: '600',
  },
  flagTextReport: {
    color: '#EF4444',
  },
  flagTextCancelled: {
    color: '#EF4444',
  },
  bookingActions: {
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  actionText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
});
