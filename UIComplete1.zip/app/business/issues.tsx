import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  TextInput,
  ActivityIndicator,
  Alert,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const businessTheme = getAccountTheme('business');

interface Issue {
  id: string;
  title: string;
  description: string;
  type: 'damage' | 'complaint' | 'technical' | 'other';
  status: 'open' | 'in_progress' | 'resolved';
  createdAt: string;
}

export default function BusinessIssues() {
  const { user } = useAuth();
    const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [issues, setIssues] = useState<Issue[]>([]);
  const [showReportForm, setShowReportForm] = useState(false);
  const [reportTitle, setReportTitle] = useState('');
  const [reportDescription, setReportDescription] = useState('');
  const [reportType, setReportType] = useState<'damage' | 'complaint' | 'technical' | 'other'>('other');

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadIssues();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadIssues = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      // Load issues from database
      const { data, error } = await supabase
        .from('business_issues')
        .select('*')
        .eq('organization_id', user.id)
        .order('created_at', { ascending: false })
        .limit(50);

      if (error) {
        console.error('Error loading issues:', error);
        setIssues([]);
        return;
      }

      // Transform database records to Issue format
      const issuesList: Issue[] = (data || []).map((issue: any) => ({
        id: issue.id,
        title: issue.title || 'Untitled Issue',
        description: issue.description || '',
        type: issue.type || 'other',
        status: issue.status || 'open',
        createdAt: issue.created_at || new Date().toISOString(),
      }));

      setIssues(issuesList);
    } catch (error) {
      console.error('Error loading issues:', error);
      setIssues([]);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitReport = async () => {
    if (!user?.id || !reportTitle || !reportDescription) {
      Alert.alert('Error', 'Please fill in all required fields');
      return;
    }

    try {
      setSubmitting(true);
      await hapticFeedback('medium');

      // Submit to database
      // await supabase.from('business_issues').insert({...});

      Alert.alert('Success', 'Report submitted successfully');
      setShowReportForm(false);
      setReportTitle('');
      setReportDescription('');
      setReportType('other');
      loadIssues();
    } catch (error) {
      console.error('Error submitting report:', error);
      Alert.alert('Error', 'Failed to submit report');
    } finally {
      setSubmitting(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'open':
        return '#8B5CF6';
      case 'in_progress':
        return '#F59E0B';
      case 'resolved':
        return '#10B981';
      default:
        return '#6B7280';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'damage':
        return 'warning';
      case 'complaint':
        return 'chatbubble-ellipses';
      case 'technical':
        return 'construct';
      default:
        return 'help-circle';
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Reports & Issues" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8B5CF6" />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Reports & Issues"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="business"
        rightAction={
          !showReportForm ? (
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                setShowReportForm(true);
              }}
              style={styles.addButton}
            >
              <Ionicons name="add" size={20} color="#8B5CF6" />
            </TouchableOpacity>
          ) : (
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                setShowReportForm(false);
              }}
              style={styles.addButton}
            >
              <Ionicons name="close" size={20} color="#8B5CF6" />
            </TouchableOpacity>
          )
        }
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          {showReportForm ? (
            <GlassCard style={styles.formCard} accountType="business">
              <View style={styles.formContent}>
                <Text style={styles.formTitle}>Report an Issue</Text>

                <View style={styles.formSection}>
                  <Text style={styles.formLabel}>Issue Type</Text>
                  <View style={styles.typeButtons}>
                    {(['damage', 'complaint', 'technical', 'other'] as const).map((type) => (
                      <TouchableOpacity
                        key={type}
                        onPress={() => {
                          hapticFeedback('light');
                          setReportType(type);
                        }}
                        style={[
                          styles.typeButton,
                          reportType === type && styles.typeButtonActive,
                        ]}
                      >
                        <Text
                          style={[
                            styles.typeButtonText,
                            reportType === type && styles.typeButtonTextActive,
                          ]}
                        >
                          {type.charAt(0).toUpperCase() + type.slice(1)}
                        </Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                <View style={styles.formSection}>
                  <Text style={styles.formLabel}>Title</Text>
                  <GlassCard style={styles.inputCard} accountType="business">
                    <TextInput
                      style={styles.input}
                      value={reportTitle}
                      onChangeText={setReportTitle}
                      placeholder="Enter issue title"
                      placeholderTextColor="rgba(249,250,251,0.5)"
                    />
                  </GlassCard>
                </View>

                <View style={styles.formSection}>
                  <Text style={styles.formLabel}>Description</Text>
                  <GlassCard style={styles.inputCard} accountType="business">
                    <TextInput
                      style={[styles.input, styles.textArea]}
                      value={reportDescription}
                      onChangeText={setReportDescription}
                      placeholder="Describe the issue in detail"
                      placeholderTextColor="rgba(249,250,251,0.5)"
                      multiline
                      numberOfLines={6}
                    />
                  </GlassCard>
                </View>

                <TouchableOpacity
                  style={styles.submitButton}
                  onPress={handleSubmitReport}
                  disabled={submitting}
                >
                  <View style={styles.submitButtonContent}>
                    {submitting ? (
                      <ActivityIndicator size="small" color="#FFFFFF" />
                    ) : (
                      <>
                        <Ionicons name="send" size={18} color="#FFFFFF" />
                        <Text style={styles.submitButtonText}>Submit Report</Text>
                      </>
                    )}
                  </View>
                </TouchableOpacity>
              </View>
            </GlassCard>
          ) : (
            <>
              {issues.length === 0 ? (
                <GlassCard style={styles.emptyCard} accountType="business">
                  <View style={styles.emptyContent}>
                    <Ionicons name="checkmark-circle-outline" size={40} color="#8B5CF6" style={{ opacity: 0.6 }} />
                    <Text style={styles.emptyTitle}>No issues reported</Text>
                    <Text style={styles.emptyText}>
                      All systems operational. Report any issues using the + button above.
                    </Text>
                  </View>
                </GlassCard>
              ) : (
                <View style={styles.issuesList}>
                  {issues.map((issue) => (
                    <GlassCard key={issue.id} style={styles.issueCard} accountType="business">
                      <View style={styles.issueContent}>
                        <View style={styles.issueHeader}>
                          <View style={styles.issueTitleRow}>
                            <Ionicons
                              name={getTypeIcon(issue.type) as any}
                              size={20}
                              color="#8B5CF6"
                            />
                            <Text style={styles.issueTitle}>{issue.title}</Text>
                          </View>
                          <View
                            style={[
                              styles.statusBadge,
                              { backgroundColor: `${getStatusColor(issue.status)}15` },
                            ]}
                          >
                            <Text
                              style={[
                                styles.statusText,
                                { color: getStatusColor(issue.status) },
                              ]}
                            >
                              {issue.status.replace('_', ' ').toUpperCase()}
                            </Text>
                          </View>
                        </View>
                        <Text style={styles.issueDescription}>{issue.description}</Text>
                        <Text style={styles.issueDate}>
                          {new Date(issue.createdAt).toLocaleDateString('en-GB', {
                            day: 'numeric',
                            month: 'long',
                            year: 'numeric',
                          })}
                        </Text>
                      </View>
                    </GlassCard>
                  ))}
                </View>
              )}
            </>
          )}
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: '#8B5CF6',
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: isSmallScreen ? 16 : 20,
    paddingBottom: 100,
  },
  content: {
    gap: SPACING.md,
  },
  addButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(139,92,246,0.15)',
  },
  formCard: {
    ...CARD_SIZES.large,
  },
  formContent: {
    padding: CARD_SIZES.large.padding,
    gap: SPACING.xl,
  },
  formTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
  },
  formSection: {
    gap: SPACING.sm,
  },
  formLabel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  typeButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.sm,
  },
  typeButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: 'rgba(139,92,246,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.2)',
  },
  typeButtonActive: {
    backgroundColor: 'rgba(139,92,246,0.2)',
    borderColor: '#8B5CF6',
  },
  typeButtonText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  typeButtonTextActive: {
    color: '#8B5CF6',
  },
  inputCard: {
    ...CARD_SIZES.small,
  },
  input: {
    color: '#F9FAFB',
    fontSize: 16,
    padding: 0,
  },
  textArea: {
    minHeight: 120,
    textAlignVertical: 'top',
  },
  submitButton: {
    marginTop: SPACING.md,
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: '#8B5CF6',
    elevation: 4,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  submitButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 24,
  },
  submitButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
  issuesList: {
    gap: SPACING.md,
  },
  issueCard: {
    ...CARD_SIZES.medium,
  },
  issueContent: {
    padding: CARD_SIZES.medium.padding,
    gap: SPACING.sm,
  },
  issueHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 4,
  },
  issueTitleRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
  },
  issueTitle: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusText: {
    fontSize: 10,
    fontWeight: '700',
  },
  issueDescription: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 14,
    lineHeight: 20,
    marginTop: 4,
  },
  issueDate: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    marginTop: 4,
  },
  emptyCard: {
    ...CARD_SIZES.large,
  },
  emptyContent: {
    alignItems: 'center',
    padding: CARD_SIZES.large.padding,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
});

