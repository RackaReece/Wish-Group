import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const businessTheme = getAccountTheme('business');

export default function BusinessCoverage() {
  const { user } = useAuth();
    const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      setLoading(false);
    }
  }, [user?.id]);

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Damage Coverage Policy" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8B5CF6" />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Damage Coverage Policy"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <GlassCard style={styles.policyCard} accountType="business">
            <View style={styles.policyContent}>
              <View style={styles.policyHeader}>
                <Ionicons name="shield-checkmark" size={24} color="#8B5CF6" />
                <Text style={styles.policyTitle}>Coverage Details</Text>
              </View>

              <View style={styles.policySection}>
                <Text style={styles.policySubtitle}>What's Covered</Text>
                <View style={styles.bulletList}>
                  <View style={styles.bulletItem}>
                    <Ionicons name="checkmark-circle" size={16} color="#8B5CF6" />
                    <Text style={styles.bulletText}>
                      Damage to customer vehicles during service
                    </Text>
                  </View>
                  <View style={styles.bulletItem}>
                    <Ionicons name="checkmark-circle" size={16} color="#8B5CF6" />
                    <Text style={styles.bulletText}>
                      Accidental damage by valeters
                    </Text>
                  </View>
                  <View style={styles.bulletItem}>
                    <Ionicons name="checkmark-circle" size={16} color="#8B5CF6" />
                    <Text style={styles.bulletText}>
                      Equipment damage or loss
                    </Text>
                  </View>
                </View>
              </View>

              <View style={styles.policySection}>
                <Text style={styles.policySubtitle}>Coverage Limits</Text>
                <View style={styles.limitCard}>
                  <Text style={styles.limitLabel}>Maximum Coverage per Incident</Text>
                  <Text style={styles.limitValue}>£5,000</Text>
                </View>
                <View style={styles.limitCard}>
                  <Text style={styles.limitLabel}>Annual Coverage Limit</Text>
                  <Text style={styles.limitValue}>£50,000</Text>
                </View>
              </View>

              <View style={styles.policySection}>
                <Text style={styles.policySubtitle}>How to Report</Text>
                <Text style={styles.policyText}>
                  If damage occurs during service, report it immediately through the app or contact support.
                  All claims are reviewed within 48 hours.
                </Text>
              </View>

              <TouchableOpacity
                style={styles.contactButton}
                onPress={async () => {
                  await hapticFeedback('light');
                  router.push('/business/issues');
                }}
              >
                <View style={styles.contactButtonContent}>
                  <Ionicons name="mail" size={18} color="#FFFFFF" />
                  <Text style={styles.contactButtonText}>Report an Issue</Text>
                </View>
              </TouchableOpacity>
            </View>
          </GlassCard>
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: '#8B5CF6',
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: isSmallScreen ? 16 : 20,
    paddingBottom: 100,
  },
  content: {
    gap: SPACING.lg,
  },
  policyCard: {
    ...CARD_SIZES.large,
  },
  policyContent: {
    padding: CARD_SIZES.large.padding,
    gap: SPACING.xl,
  },
  policyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.md,
  },
  policyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
  },
  policySection: {
    gap: SPACING.md,
  },
  policySubtitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: SPACING.sm,
  },
  bulletList: {
    gap: SPACING.sm,
  },
  bulletItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: SPACING.sm,
  },
  bulletText: {
    flex: 1,
    color: 'rgba(249,250,251,0.9)',
    fontSize: 14,
    lineHeight: 20,
  },
  limitCard: {
    padding: SPACING.md,
    borderRadius: 12,
    backgroundColor: 'rgba(139,92,246,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.2)',
    marginBottom: SPACING.sm,
  },
  limitLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    marginBottom: 4,
  },
  limitValue: {
    color: '#8B5CF6',
    fontSize: 20,
    fontWeight: '700',
  },
  policyText: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 14,
    lineHeight: 20,
  },
  contactButton: {
    marginTop: SPACING.md,
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: '#8B5CF6',
    elevation: 4,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  contactButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 24,
  },
  contactButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});

