import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING, getMetricCardWidth } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

export default function BusinessAnalytics() {
  const { user } = useAuth();
    const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      // Simulate loading
      setTimeout(() => setLoading(false), 1000);
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Analytics" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading analytics...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Analytics"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        {/* Overview Stats */}
        <View style={styles.statsGrid}>
          <Animated.View style={[{ opacity: fadeAnim }]}>
            <GlassCard style={styles.statCard} accountType="business">
              <View style={styles.statContent}>
                <Ionicons name="trending-up" size={24} color="#8B5CF6" />
                <Text style={styles.statValue}>£0</Text>
                <Text style={styles.statLabel}>Total Revenue</Text>
              </View>
            </GlassCard>
          </Animated.View>

          <Animated.View style={[{ opacity: fadeAnim }]}>
            <GlassCard style={styles.statCard} accountType="business">
              <View style={styles.statContent}>
                <Ionicons name="calendar" size={24} color="#8B5CF6" />
                <Text style={styles.statValue}>0</Text>
                <Text style={styles.statLabel}>Total Bookings</Text>
              </View>
            </GlassCard>
          </Animated.View>

          <Animated.View style={[{ opacity: fadeAnim }]}>
            <GlassCard style={styles.statCard} accountType="business">
              <View style={styles.statContent}>
                <Ionicons name="people" size={24} color="#8B5CF6" />
                <Text style={styles.statValue}>0</Text>
                <Text style={styles.statLabel}>Active Valeters</Text>
              </View>
            </GlassCard>
          </Animated.View>

          <Animated.View style={[{ opacity: fadeAnim }]}>
            <GlassCard style={styles.statCard} accountType="business">
              <View style={styles.statContent}>
                <Ionicons name="star" size={24} color="#8B5CF6" />
                <Text style={styles.statValue}>0.0</Text>
                <Text style={styles.statLabel}>Avg Rating</Text>
              </View>
            </GlassCard>
          </Animated.View>
        </View>

        {/* Charts Section */}
        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Revenue Trends</Text>
          <GlassCard style={styles.emptyCard} accountType="business">
            <View style={styles.emptyContent}>
              <Ionicons name="bar-chart-outline" size={40} color="#8B5CF6" style={{ opacity: 0.6 }} />
              <Text style={styles.emptyTitle}>No data yet</Text>
              <Text style={styles.emptyText}>
                Revenue charts will appear here as your business grows
              </Text>
            </View>
          </GlassCard>
        </Animated.View>

        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Booking Trends</Text>
          <GlassCard style={styles.emptyCard} accountType="business">
            <View style={styles.emptyContent}>
              <Ionicons name="trending-up-outline" size={40} color="#8B5CF6" style={{ opacity: 0.6 }} />
              <Text style={styles.emptyTitle}>No data yet</Text>
              <Text style={styles.emptyText}>
                Booking trends will be displayed here once you have bookings
              </Text>
            </View>
          </GlassCard>
        </Animated.View>

        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Valeter Performance</Text>
          <GlassCard style={styles.emptyCard} accountType="business">
            <View style={styles.emptyContent}>
              <Ionicons name="people-outline" size={40} color="#8B5CF6" style={{ opacity: 0.6 }} />
              <Text style={styles.emptyTitle}>No data yet</Text>
              <Text style={styles.emptyText}>
                Valeter performance metrics will appear here
              </Text>
            </View>
          </GlassCard>
        </Animated.View>

        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Location Breakdown</Text>
          <GlassCard style={styles.emptyCard} accountType="business">
            <View style={styles.emptyContent}>
              <Ionicons name="location-outline" size={40} color="#8B5CF6" style={{ opacity: 0.6 }} />
              <Text style={styles.emptyTitle}>No data yet</Text>
              <Text style={styles.emptyText}>
                Revenue breakdown by location will be shown here
              </Text>
            </View>
          </GlassCard>
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 32,
  },
  statCard: {
    width: (width - 52) / 2,
    padding: 0,
    overflow: 'hidden',
  },
  statGradient: {
    padding: 20,
    alignItems: 'center',
    gap: 12,
  },
  statValue: {
    color: '#F9FAFB',
    fontSize: 28,
    fontWeight: '800',
  },
  statLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 16,
    letterSpacing: 0.2,
  },
  emptyCard: {
    ...CARD_SIZES.large,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
});
