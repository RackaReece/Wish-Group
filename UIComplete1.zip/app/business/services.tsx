import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Switch,
  ActivityIndicator,
  Alert,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { WASH_DEFINITIONS, WashDefinition, getVehicleSizeAdjustmentGBP, VehicleSize } from '../../src/pricing/pricingEngine';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const businessTheme = getAccountTheme('business');

interface Service {
  id: string;
  name: string;
  enabled: boolean;
  price?: number;
  priceFrom?: number;
  priceTo?: number;
  description?: string;
  washDefinitionId?: string; // Link to WASH_DEFINITIONS
}

export default function BusinessServices() {
  const { user } = useAuth();
    const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [services, setServices] = useState<Service[]>([]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadServices();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadServices = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      // Convert WASH_DEFINITIONS to Service format for business configuration
      // Only include mobile wash services (not physical location only)
      const washServices: Service[] = WASH_DEFINITIONS
        .filter(wash => wash.isMobile) // Only mobile services
        .map((wash, index) => {
          // Calculate price range: SMALL (base) to XL (base + max adjustment)
          const basePrice = wash.basePriceSmallGBP;
          const smallPrice = basePrice; // SMALL = base price
          const xlPrice = basePrice + getVehicleSizeAdjustmentGBP('XL'); // XL = base + £7
          
          return {
            id: wash.id,
            name: wash.label,
            enabled: true, // Default to enabled
            price: basePrice, // Base price for small vehicle (for compatibility)
            priceFrom: smallPrice,
            priceTo: xlPrice,
            description: wash.description,
            washDefinitionId: wash.id,
          };
        });
      
      // Try to load saved service configurations from database
      // For now, use the wash definitions as default
      setServices(washServices);
    } catch (error) {
      console.error('Error loading services:', error);
      Alert.alert('Error', 'Failed to load services');
    } finally {
      setLoading(false);
    }
  };

  const toggleService = async (serviceId: string) => {
    if (!user?.id) return;
    try {
      await hapticFeedback('light');
      setServices(prev =>
        prev.map(s => (s.id === serviceId ? { ...s, enabled: !s.enabled } : s))
      );

      // Save to database
      // This would update your organization_services table
      // await supabase.from('organization_services').upsert({...});
    } catch (error) {
      console.error('Error toggling service:', error);
      Alert.alert('Error', 'Failed to update service');
    }
  };

  const handleSave = async () => {
    if (!user?.id) return;
    try {
      setSaving(true);
      await hapticFeedback('medium');
      // Save all service configurations
      Alert.alert('Success', 'Services configuration saved successfully');
    } catch (error) {
      console.error('Error saving services:', error);
      Alert.alert('Error', 'Failed to save services configuration');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Services Configuration" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#8B5CF6" />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Services Configuration"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Services & Pricing</Text>
          <Text style={styles.sectionSubtitle}>
            View available wash services, what they include, and base pricing ranges
          </Text>

          <View style={styles.servicesList}>
            {services.map((service) => {
              const washDef = WASH_DEFINITIONS.find(w => w.id === service.washDefinitionId);
              const isEco = washDef?.isEco || false;
              const tier = washDef?.tier || 'BRONZE';
              
              return (
                <GlassCard key={service.id} style={styles.serviceCard} accountType="business">
                  <View style={styles.serviceContent}>
                    <View style={styles.serviceInfo}>
                      <View style={styles.serviceHeader}>
                        <Text style={styles.serviceName}>{service.name}</Text>
                        {isEco && (
                          <View style={styles.ecoBadge}>
                            <Ionicons name="leaf" size={12} color="#10B981" />
                            <Text style={styles.ecoBadgeText}>Eco</Text>
                          </View>
                        )}
                        {tier && (
                          <View style={[styles.tierBadge, { backgroundColor: getTierColor(tier) }]}>
                            <Text style={styles.tierBadgeText}>{tier}</Text>
                          </View>
                        )}
                      </View>
                      {service.description && (
                        <Text style={styles.serviceDescription}>{service.description}</Text>
                      )}
                      <View style={styles.priceRangeContainer}>
                        <View style={styles.priceRangeRow}>
                          <Text style={styles.priceRangeLabel}>Price Range:</Text>
                          <View style={styles.priceRangeValues}>
                            <Text style={styles.priceFrom}>From £{service.priceFrom?.toFixed(2) || '0.00'}</Text>
                            <Text style={styles.priceSeparator}> - </Text>
                            <Text style={styles.priceTo}>£{service.priceTo?.toFixed(2) || '0.00'}</Text>
                          </View>
                        </View>
                        <Text style={styles.priceNote}>
                          Base pricing for Small to XL vehicles. Final price may vary by distance and time.
                        </Text>
                      </View>
                    </View>
                    <Switch
                      value={service.enabled}
                      onValueChange={() => toggleService(service.id)}
                      trackColor={{ false: 'rgba(255,255,255,0.1)', true: businessTheme.primary }}
                      thumbColor={service.enabled ? '#FFFFFF' : '#6B7280'}
                      ios_backgroundColor="rgba(255,255,255,0.1)"
                    />
                  </View>
                </GlassCard>
              );
            })}
          </View>

          <TouchableOpacity
            style={styles.saveButton}
            onPress={handleSave}
            disabled={saving}
          >
            <View style={styles.saveButtonContent}>
              {saving ? (
                <ActivityIndicator size="small" color="#FFFFFF" />
              ) : (
                <>
                  <Ionicons name="checkmark" size={18} color="#FFFFFF" />
                  <Text style={styles.saveButtonText}>Save Configuration</Text>
                </>
              )}
            </View>
          </TouchableOpacity>
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

// Helper function to get tier color
const getTierColor = (tier: string): string => {
  switch (tier) {
    case 'BRONZE':
      return 'rgba(205,127,50,0.2)';
    case 'SILVER':
      return 'rgba(192,192,192,0.2)';
    case 'GOLD':
      return 'rgba(255,215,0,0.2)';
    case 'PLATINUM':
      return 'rgba(229,228,226,0.2)';
    default:
      return 'rgba(255,255,255,0.1)';
  }
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: '#8B5CF6',
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: isSmallScreen ? 16 : 20,
    paddingBottom: 100,
  },
  content: {
    gap: SPACING.lg,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 4,
  },
  sectionSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    marginBottom: SPACING.xl,
  },
  servicesList: {
    gap: SPACING.md,
  },
  serviceCard: {
    ...CARD_SIZES.medium,
  },
  serviceContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: CARD_SIZES.medium.padding,
  },
  serviceInfo: {
    flex: 1,
    gap: 4,
  },
  serviceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 6,
    flexWrap: 'wrap',
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  ecoBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(16,185,129,0.2)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  ecoBadgeText: {
    color: '#10B981',
    fontSize: 10,
    fontWeight: '600',
  },
  tierBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  tierBadgeText: {
    color: '#F9FAFB',
    fontSize: 9,
    fontWeight: '700',
    textTransform: 'uppercase',
  },
  priceRangeContainer: {
    marginTop: 8,
    gap: 4,
  },
  priceRangeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
  },
  priceRangeLabel: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
  },
  priceRangeValues: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  priceFrom: {
    color: businessTheme.primary,
    fontSize: 16,
    fontWeight: '700',
  },
  priceSeparator: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 14,
    marginHorizontal: 4,
  },
  priceTo: {
    color: businessTheme.primary,
    fontSize: 16,
    fontWeight: '700',
  },
  priceNote: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 10,
    marginTop: 2,
    fontStyle: 'italic',
  },
  serviceDescription: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    marginTop: 2,
  },
  saveButton: {
    marginTop: SPACING.lg,
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: '#8B5CF6',
    elevation: 4,
    shadowColor: '#8B5CF6',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  saveButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 24,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});

