import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  TextInput,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import StatusDot, { StatusType } from '../../src/components/shared/StatusDot';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

interface Valeter {
  id: string;
  name: string;
  email: string;
  phone?: string;
  is_online: boolean;
  total_jobs?: number;
  rating?: number;
  location_assignment?: string;
  role?: string;
  clocked_in?: boolean;
  created_at: string;
}

export default function BusinessTeam() {
  const { user } = useAuth();
    const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [valeters, setValeters] = useState<Valeter[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterLocation, setFilterLocation] = useState<string | null>(null);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadValeters();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadValeters = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('users')
        .select('id, name, email, phone, created_at')
        .eq('organization_id', user.id)
        .eq('user_type', 'valeter')
        .order('created_at', { ascending: false });

      if (error) throw error;

      // Get additional valeter data
      const valeterData = await Promise.all(
        (data || []).map(async (v) => {
          const { data: presence } = await supabase
            .from('valeter_presence')
            .select('is_online')
            .eq('user_id', v.id)
            .maybeSingle();

          const { data: stats } = await supabase
            .from('bookings')
            .select('id, rating')
            .eq('valeter_id', v.id)
            .eq('status', 'completed');

          return {
            ...v,
            is_online: presence?.is_online || false,
            total_jobs: stats?.length || 0,
            rating: stats?.length
              ? stats.reduce((acc, s) => acc + (s.rating || 0), 0) / stats.length
              : 0,
            location_assignment: null, // Will be fetched from location assignments
            role: 'valeter', // Default role
            clocked_in: false, // Will be fetched from time tracking
          };
        })
      );

      setValeters(valeterData);
    } catch (error) {
      console.error('Error loading valeters:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredValeters = valeters.filter((valeter) => {
    const matchesSearch =
      valeter.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      valeter.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesLocation = !filterLocation || valeter.location_assignment === filterLocation;
    return matchesSearch && matchesLocation;
  });

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Team" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading team...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Team"
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.push('/business/team/invite');
            }}
            style={styles.inviteButton}
          >
            <Ionicons name="person-add" size={24} color={SKY} />
          </TouchableOpacity>
        }
        scrollY={scrollY}
        enableScrollAnimation={true}
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        {/* Search Bar */}
        <GlassCard style={styles.searchCard} accountType="business">
          <View style={styles.searchContainer}>
            <Ionicons name="search" size={18} color="#8B5CF6" style={styles.searchIcon} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search valeters..."
              placeholderTextColor="rgba(249,250,251,0.5)"
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>
        </GlassCard>

        {/* Invite & Requests Section */}
        <View style={styles.quickActions}>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.push('/business/team/invite');
            }}
            style={styles.quickActionButton}
          >
            <GlassCard
              onPress={undefined}
              style={styles.quickActionCard}
              accountType="business"
            >
              <View style={styles.quickActionContent}>
                <Ionicons name="person-add" size={20} color="#8B5CF6" />
                <Text style={styles.quickActionText}>Invite Valeter</Text>
              </View>
            </GlassCard>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.push('/business/team/requests');
            }}
            style={styles.quickActionButton}
          >
            <GlassCard
              onPress={undefined}
              style={styles.quickActionCard}
              accountType="business"
            >
              <View style={styles.quickActionContent}>
                <Ionicons name="mail-unread" size={20} color="#8B5CF6" />
                <Text style={styles.quickActionText}>Requests</Text>
              </View>
            </GlassCard>
          </TouchableOpacity>
        </View>

        {/* Team Stats */}
        <View style={styles.statsRow}>
          <GlassCard style={styles.statCard} accountType="business">
            <Text style={styles.statValue}>{valeters.length}</Text>
            <Text style={styles.statLabel}>Total Valeters</Text>
          </GlassCard>
          <GlassCard style={styles.statCard} accountType="business">
            <Text style={styles.statValue}>
              {valeters.filter((v) => v.is_online).length}
            </Text>
            <Text style={styles.statLabel}>Online Now</Text>
          </GlassCard>
          <GlassCard style={styles.statCard} accountType="business">
            <Text style={styles.statValue}>
              {valeters.filter((v) => v.clocked_in).length}
            </Text>
            <Text style={styles.statLabel}>Clocked In</Text>
          </GlassCard>
        </View>

        {/* Valeters List */}
        {filteredValeters.length === 0 ? (
          <GlassCard style={styles.emptyCard}>
            <View style={styles.emptyContent}>
              <Ionicons name="people-outline" size={48} color={SKY} style={{ opacity: 0.5 }} />
              <Text style={styles.emptyTitle}>
                {searchQuery ? 'No valeters found' : 'No valeters yet'}
              </Text>
              <Text style={styles.emptyText}>
                {searchQuery
                  ? 'Try adjusting your search'
                  : 'Invite valeters to join your business team'}
              </Text>
            </View>
          </GlassCard>
        ) : (
          <View style={styles.valetersList}>
            {filteredValeters.map((valeter, index) => (
              <Animated.View
                key={valeter.id}
                style={[
                  { opacity: fadeAnim },
                  {
                    transform: [
                      {
                        translateY: fadeAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [30 + index * 10, 0],
                        }),
                      },
                    ],
                  },
                ]}
              >
                <GlassCard style={styles.valeterCard} accountType="business">
                  <View style={styles.valeterHeader}>
                    <View style={styles.valeterAvatar}>
                      <Ionicons name="person" size={24} color={SKY} />
                    </View>
                    <View style={styles.valeterInfo}>
                      <View style={styles.valeterNameRow}>
                        <Text style={styles.valeterName}>{valeter.name}</Text>
                        {valeter.role && (
                          <View style={styles.roleBadge}>
                            <Text style={styles.roleText}>{valeter.role}</Text>
                          </View>
                        )}
                      </View>
                      <Text style={styles.valeterEmail}>{valeter.email}</Text>
                      {valeter.phone && (
                        <Text style={styles.valeterPhone}>{valeter.phone}</Text>
                      )}
                    </View>
                    <View style={styles.statusContainer}>
                      <StatusDot
                        status={
                          valeter.is_online
                            ? 'available'
                            : valeter.clocked_in
                            ? 'busy'
                            : 'offline'
                        }
                        size={12}
                        pulseOnChange={true}
                      />
                    </View>
                  </View>

                  <View style={styles.valeterStats}>
                    <View style={styles.statItem}>
                      <Ionicons name="car" size={14} color="#8B5CF6" />
                      <Text style={styles.statItemText}>{valeter.total_jobs || 0} jobs</Text>
                    </View>
                    {valeter.rating > 0 && (
                      <View style={styles.statItem}>
                        <Ionicons name="star" size={14} color="#8B5CF6" />
                        <Text style={styles.statItemText}>
                          {valeter.rating.toFixed(1)}
                        </Text>
                      </View>
                    )}
                    <View style={styles.statItem}>
                      <Ionicons
                        name={valeter.clocked_in ? 'time' : 'time-outline'}
                        size={14}
                        color="#8B5CF6"
                      />
                      <Text style={styles.statItemText}>
                        {valeter.clocked_in ? 'Clocked In' : 'Off'}
                      </Text>
                    </View>
                  </View>
                </GlassCard>
              </Animated.View>
            ))}
          </View>
        )}
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  inviteButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  searchCard: {
    padding: 0,
    marginBottom: 20,
    overflow: 'hidden',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  searchIcon: {
    marginRight: 12,
  },
  searchInput: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 16,
  },
  quickActions: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  quickActionButton: {
    flex: 1,
  },
  quickActionCard: {
    ...CARD_SIZES.small,
  },
  quickActionContent: {
    padding: CARD_SIZES.small.padding,
    alignItems: 'center',
    gap: SPACING.sm,
  },
  quickActionText: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '600',
  },
  statsRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    ...CARD_SIZES.small,
    alignItems: 'center',
  },
  statValue: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 4,
  },
  statLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 11,
    fontWeight: '500',
  },
  valetersList: {
    gap: 12,
  },
  valeterCard: {
    ...CARD_SIZES.medium,
  },
  valeterHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  valeterAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(139,92,246,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  valeterInfo: {
    flex: 1,
  },
  valeterNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  roleBadge: {
    backgroundColor: 'rgba(139,92,246,0.15)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  roleText: {
    color: '#8B5CF6',
    fontSize: 9,
    fontWeight: '600',
    textTransform: 'uppercase',
  },
  valeterEmail: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    marginBottom: 2,
  },
  valeterPhone: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
  },
  statusContainer: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  statusDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  valeterStats: {
    flexDirection: 'row',
    gap: SPACING.lg,
    paddingTop: SPACING.md,
    borderTopWidth: 1,
    borderTopColor: 'rgba(139,92,246,0.15)',
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statItemText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  emptyCard: {
    ...CARD_SIZES.large,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
  },
});
