import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { getServiceDisplayName } from '../../src/utils/serviceNameMapper';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import { colors } from '../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function ValeterWashHistory() {
  const { user } = useAuth();
    const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [bookings, setBookings] = useState<any[]>([]);
  const [totalEarnings, setTotalEarnings] = useState(0);
  const [stats, setStats] = useState({
    totalJobs: 0,
    thisMonth: 0,
    thisWeek: 0,
    averageRating: 0,
  });

  const loadBookings = async () => {
    if (!user?.id) return;
    try {
      // Load valeter bookings from Supabase
      const { data: allBookings, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id);
      
      if (error) throw error;
      
      const bookingsList = allBookings || [];
      const completed = bookingsList.filter((b: any) => 
        ['completed', 'rated', 'closed'].includes(b.status)
      );
      
      // Sort by completion date (most recent first)
      const sorted = completed.sort((a: any, b: any) => {
        const dateA = a.updated_at || a.created_at || a.completed_at;
        const dateB = b.updated_at || b.created_at || b.completed_at;
        const timeA = dateA ? new Date(dateA).getTime() : 0;
        const timeB = dateB ? new Date(dateB).getTime() : 0;
        return timeB - timeA;
      });
      
      setBookings(sorted);
      
      // Calculate earnings
      const earnings = completed.reduce((sum: number, b: any) => sum + (b.price || 0), 0);
      setTotalEarnings(earnings);
      
      // Calculate stats
      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const firstDayOfWeek = new Date(now);
      firstDayOfWeek.setDate(now.getDate() - now.getDay());
      
      const thisMonth = completed.filter((b: any) => {
        const date = b.updated_at || b.created_at || b.completed_at;
        return date && new Date(date) >= firstDayOfMonth;
      }).length;
      
      const thisWeek = completed.filter((b: any) => {
        const date = b.updated_at || b.created_at || b.completed_at;
        return date && new Date(date) >= firstDayOfWeek;
      }).length;
      
      setStats({
        totalJobs: completed.length,
        thisMonth,
        thisWeek,
        averageRating: 0, // TODO: Calculate from reviews
      });
    } catch (error: any) {
      console.error('[ValeterWashHistory] Error loading bookings:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadBookings();
  }, [user?.id]);

  const onRefresh = () => {
    setRefreshing(true);
    loadBookings();
  };

  const formatDate = (dateStr: string | undefined) => {
    if (!dateStr) return 'Date unavailable';
    try {
      const date = new Date(dateStr);
      if (isNaN(date.getTime())) return 'Date unavailable';
      return date.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return 'Date unavailable';
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={[BG, colors.headerBg]} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading earnings history...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Earnings & History"
        subtitle={`${bookings.length} completed jobs`}
        rightAction={
          <TouchableOpacity onPress={loadBookings} style={styles.refreshButton}>
            <Ionicons name="refresh" size={20} color={SKY} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {/* Earnings Summary */}
        <View style={styles.earningsCard}>
          <LinearGradient
            colors={['rgba(135,206,235,0.25)', 'rgba(30,58,138,0.3)']}
            style={styles.earningsGradient}
          >
            <View style={styles.earningsIconWrapper}>
              <Ionicons name="cash" size={36} color={SKY} />
            </View>
            <Text style={styles.earningsLabel}>Total Earnings</Text>
            <Text style={styles.earningsValue}>£{totalEarnings.toFixed(2)}</Text>
            <Text style={styles.earningsSubtext}>{bookings.length} completed jobs</Text>
          </LinearGradient>
        </View>

        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{stats.totalJobs}</Text>
            <Text style={styles.statLabel}>Total Jobs</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{stats.thisMonth}</Text>
            <Text style={styles.statLabel}>This Month</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{stats.thisWeek}</Text>
            <Text style={styles.statLabel}>This Week</Text>
          </View>
          {stats.averageRating > 0 && (
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.averageRating.toFixed(1)}</Text>
              <Text style={styles.statLabel}>Avg Rating</Text>
            </View>
          )}
        </View>

        {/* Bookings List */}
        {bookings.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="time-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
            <Text style={styles.emptyTitle}>No History Yet</Text>
            <Text style={styles.emptySubtitle}>Your completed jobs will appear here</Text>
          </View>
        ) : (
          <>
            <Text style={styles.sectionTitle}>Job History</Text>
            {bookings.map((booking) => (
              <View key={booking.id} style={styles.bookingCard}>
                <LinearGradient
                  colors={['rgba(255,255,255,0.08)', 'rgba(135,206,235,0.05)']}
                  style={styles.bookingCardGradient}
                >
                  <View style={styles.bookingHeader}>
                    <View style={styles.bookingIconWrapper}>
                      <Ionicons name="car-sport" size={22} color="#87CEEB" />
                    </View>
                    <View style={styles.bookingInfo}>
                      <Text style={styles.bookingService}>
                        {getServiceDisplayName(booking.service_type, booking.serviceName)}
                      </Text>
                      <Text style={styles.bookingDate}>{formatDate(booking.updated_at || booking.created_at || booking.completed_at)}</Text>
                    </View>
                    <Text style={styles.bookingPrice}>£{booking.price?.toFixed(2) || '0.00'}</Text>
                  </View>
                  
                  <View style={styles.bookingFooter}>
                    {booking.location?.address && (
                      <View style={styles.bookingMeta}>
                        <Ionicons name="location" size={14} color="#87CEEB" />
                        <Text style={styles.metaText} numberOfLines={1}>
                          {booking.location.address}
                        </Text>
                      </View>
                    )}
                    {booking.vehicleType && (
                      <View style={styles.bookingMeta}>
                        <Ionicons name="car" size={14} color="#87CEEB" />
                        <Text style={styles.metaText}>{booking.vehicleType}</Text>
                      </View>
                    )}
                  </View>
                </LinearGradient>
              </View>
            ))}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 12 : 20 },
  refreshButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  earningsCard: {
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 24,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  earningsGradient: {
    padding: 28,
    alignItems: 'center',
  },
  earningsIconWrapper: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  earningsLabel: {
    color: '#87CEEB',
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 8,
    letterSpacing: 0.5,
  },
  earningsValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 40 : 48,
    fontWeight: '800',
    marginBottom: 6,
  },
  earningsSubtext: {
    color: '#87CEEB',
    fontSize: 14,
    opacity: 0.9,
    fontWeight: '500',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    minWidth: (width - (isSmallScreen ? 36 : 40) - 12) / 2,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: '800',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
    marginTop: 8,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
  },
  bookingCard: {
    borderRadius: 18,
    marginBottom: 14,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  bookingCardGradient: {
    padding: 18,
  },
  bookingHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  bookingIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  bookingInfo: {
    flex: 1,
  },
  bookingService: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '700',
    marginBottom: 6,
  },
  bookingDate: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '600',
  },
  bookingPrice: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '800',
  },
  bookingFooter: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginTop: 8,
  },
  bookingMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flex: 1,
    minWidth: '45%',
  },
  metaText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
    flex: 1,
  },
  ratingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(245,158,11,0.2)',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 8,
    gap: 4,
    borderWidth: 1,
    borderColor: 'rgba(245,158,11,0.3)',
    alignSelf: 'flex-start',
    marginTop: 8,
  },
  ratingText: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '700',
  },
});
