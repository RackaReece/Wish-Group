import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  Alert,
  Image,
  TextInput,
  Modal,
  Dimensions,
  ActivityIndicator,
  Animated,
  StatusBar,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Platform } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { ValeterStatsService, ValeterPerformanceStats } from '../../../src/services/Valeterstatsservice';
import { ValeterTierService, ValeterTier } from '../../../src/services/ValeterTierService';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;

interface ValeterDocument {
  id: string;
  type: 'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed';
  name: string;
  description: string;
  status: 'pending' | 'approved' | 'rejected' | 'not_uploaded';
  file_url?: string;
  uploaded_at?: string;
  approved_at?: string;
  rejection_reason?: string;
}

interface ValeterProfileData {
  user_id: string;
  full_name: string;
  bio?: string;
  experience?: string;
  profile_photo_url?: string;
  vehicle_make?: string;
  vehicle_model?: string;
  vehicle_registration?: string;
  verification_status: 'pending' | 'verified' | 'rejected';
  verification_badge: boolean;
}

export default function ValeterProfile() {
  const router = useRouter();
  const { user, logout } = useAuth();
    const scrollY = useRef(new Animated.Value(0)).current;
  
  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [uploadingPicture, setUploadingPicture] = useState(false);
  const [showPhotoModal, setShowPhotoModal] = useState(false);

  const [valeterStats, setValeterStats] = useState<ValeterPerformanceStats>({
    totalJobs: 0,
    experienceMonths: 1,
    averageRating: 0,
    totalEarnings: 0,
    jobsThisMonth: 0,
    customerReviews: 0,
    onTimePercentage: 100,
    cancellationRate: 0
  });
  const [currentTier, setCurrentTier] = useState<ValeterTier | null>(null);
  const [documents, setDocuments] = useState<ValeterDocument[]>([]);
  const [organizationId, setOrganizationId] = useState<string | null>(null);
  const [organizationName, setOrganizationName] = useState<string | null>(null);
  const [isIndependent, setIsIndependent] = useState<boolean>(true);
  const [benefitsExpanded, setBenefitsExpanded] = useState(false);
  const [todayStats, setTodayStats] = useState({
    hoursOnline: '0h 0m',
    jobsCompleted: 0,
    earnings: 0
  });

  // CountUpNumber component for animated numbers
  const CountUpNumber = ({
    value,
    prefix = '',
    suffix = '',
    decimals = 0,
    duration = 650,
    style,
  }: {
    value: number;
    prefix?: string;
    suffix?: string;
    decimals?: number;
    duration?: number;
    style?: any;
  }) => {
    const anim = useRef(new Animated.Value(0)).current;
    const [display, setDisplay] = useState(0);

    useEffect(() => {
      anim.stopAnimation();
      anim.setValue(0);
      const listenerId = anim.addListener(({ value: v }) => setDisplay(v));
      Animated.timing(anim, { toValue: value, duration, useNativeDriver: false }).start(() => {
        anim.removeListener(listenerId);
        setDisplay(value);
      });
      return () => anim.removeListener(listenerId);
    }, [value]);

    const shown = useMemo(() => Number(display).toFixed(decimals), [display, decimals]);
    return <Text style={style}>{`${prefix}${shown}${suffix}`}</Text>;
  };

  // Floating bubbles animation
  const bubbleData = useRef(
    Array.from({ length: 5 }, (_, i) => ({
      translateY: new Animated.Value(0),
      translateX: new Animated.Value(0),
      opacity: new Animated.Value(0.15 + Math.random() * 0.1),
      scale: new Animated.Value(0.8 + Math.random() * 0.4),
      size: 20 + Math.random() * 30,
      leftPosition: Math.random() * Dimensions.get('window').width,
      duration: 8000 + Math.random() * 4000,
      delay: i * 1000,
    }))
  ).current;

  useEffect(() => {
    bubbleData.forEach((bubble) => {
      const animateBubble = () => {
        Animated.parallel([
          Animated.loop(
            Animated.sequence([
              Animated.timing(bubble.translateY, {
                toValue: -64 - 50,
                duration: bubble.duration,
                useNativeDriver: true,
              }),
              Animated.timing(bubble.translateY, {
                toValue: 0,
                duration: 0,
                useNativeDriver: true,
              }),
            ])
          ),
          Animated.loop(
            Animated.sequence([
              Animated.timing(bubble.translateX, {
                toValue: 20,
                duration: bubble.duration * 0.7,
                useNativeDriver: true,
              }),
              Animated.timing(bubble.translateX, {
                toValue: -20,
                duration: bubble.duration * 0.7,
                useNativeDriver: true,
              }),
            ])
          ),
          Animated.loop(
            Animated.sequence([
              Animated.timing(bubble.scale, {
                toValue: 1.2,
                duration: bubble.duration * 0.5,
                useNativeDriver: true,
              }),
              Animated.timing(bubble.scale, {
                toValue: 0.8,
                duration: bubble.duration * 0.5,
                useNativeDriver: true,
              }),
            ])
          ),
        ]).start();
      };

      const timeout = setTimeout(() => {
        animateBubble();
      }, bubble.delay);

      return () => clearTimeout(timeout);
    });
  }, []);

  useEffect(() => {
    const fetchStats = async () => {
      if (user) {
        try {
          const stats = await ValeterStatsService.getValeterStats(user.id);
          setValeterStats(stats);
          const tier = ValeterTierService.calculateTier(stats);
          setCurrentTier(tier);
          
          // Calculate today's stats
          const today = new Date();
          today.setHours(0, 0, 0, 0);
          
          // Fetch today's bookings
          const { data: todayBookings } = await supabase
            .from('bookings')
            .select('price, completed_at, created_at')
            .eq('valeter_id', user.id)
            .eq('status', 'completed')
            .gte('completed_at', today.toISOString());
          
          const jobsCompleted = todayBookings?.length || 0;
          const earnings = todayBookings?.reduce((sum, b) => sum + (Number(b.price) || 0), 0) || 0;
          
          // Calculate hours online (placeholder - would need presence tracking)
          const hoursOnline = '0h 0m'; // TODO: Calculate from presence data
          
          setTodayStats({
            hoursOnline,
            jobsCompleted,
            earnings: Math.round(earnings),
          });
        } catch (error) {
          console.error('Error fetching valeter stats:', error);
        }
      }
    };
    fetchStats();
  }, [user]);

  useEffect(() => {
    if (user?.id) {
      loadProfile();
      loadDocuments();
      loadBusinessInfo();
    }
  }, [user?.id]);

  // Set up real-time subscription for business info updates
  useEffect(() => {
    if (!user?.id) return;

    // Subscribe to users table changes for organization_id
    const usersSubscription = supabase
      .channel('user-organization-changes')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'users',
          filter: `id=eq.${user.id}`,
        },
        (payload) => {
          loadBusinessInfo();
        }
      )
      .subscribe();

    return () => {
      usersSubscription.unsubscribe();
    };
  }, [user?.id]);

  const loadBusinessInfo = async () => {
    if (!user?.id) return;
    try {
      const { data: userData } = await supabase
        .from('users')
        .select('organization_id, is_individual_valeter')
        .eq('id', user.id)
        .maybeSingle();

      if (userData) {
        const hasOrg = !!userData.organization_id;
        setIsIndependent(!hasOrg || userData.is_individual_valeter === true);
        setOrganizationId(userData.organization_id || null);

        if (hasOrg && userData.organization_id) {
          const { data: orgData } = await supabase
            .from('organizations')
            .select('name')
            .eq('id', userData.organization_id)
            .maybeSingle();
          
          if (orgData) {
            setOrganizationName(orgData.name);
          } else {
            setOrganizationName(null);
          }
        } else {
          setOrganizationName(null);
        }
      } else {
        // No user data found, default to independent
        setIsIndependent(true);
        setOrganizationId(null);
        setOrganizationName(null);
      }
    } catch (error) {
      console.error('Error loading business info:', error);
    }
  };

  const loadProfile = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('valeter_profiles')
        .select('*')
        .eq('user_id', user!.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setProfile(data);
        setProfilePicture(data.profile_photo_url || null);
      } else {
        const newProfile: Partial<ValeterProfileData> = {
          user_id: user!.id,
          full_name: user!.name || 'Valeter',
          bio: 'Professional mobile valeter',
          experience: '0 years',
          verification_status: 'pending',
          verification_badge: false,
        };

        const { data: created, error: createError } = await supabase
          .from('valeter_profiles')
          .insert(newProfile)
          .select()
          .single();

        if (createError) throw createError;
        setProfile(created);
      }
      
    } catch (error) {
      console.error('Error loading profile:', error);
      Alert.alert('Error', 'Failed to load profile');
    } finally {
      setIsLoading(false);
    }
  };

  const loadDocuments = async () => {
    try {
      const { data, error } = await supabase
        .from('valeter_documents')
        .select('*')
        .eq('user_id', user!.id);

      if (error) throw error;

      if (data && data.length > 0) {
        setDocuments(data);
      } else {
        const requiredDocs: Partial<ValeterDocument>[] = [
          {
            user_id: user!.id,
            type: 'id_proof',
            name: 'Proof of Identity',
            description: 'Valid government-issued ID (passport, driving licence, or national ID)',
            status: 'not_uploaded',
          },
          {
            user_id: user!.id,
            type: 'selfie',
            name: 'Selfie Photo',
            description: 'Clear selfie for identity verification',
            status: 'not_uploaded',
          },
          {
            user_id: user!.id,
            type: 'profile_photo',
            name: 'Profile Photo',
            description: 'Professional headshot for customer trust',
            status: 'not_uploaded',
          },
          {
            user_id: user!.id,
            type: 'disclaimer_signed',
            name: 'Terms & Conditions',
            description: 'Signed agreement to Wish a Wash terms and conditions',
            status: 'not_uploaded',
          },
        ];

        const { data: created, error: createError } = await supabase
          .from('valeter_documents')
          .insert(requiredDocs)
          .select();

        if (createError) throw createError;
        setDocuments(created || []);
      }
    } catch (error) {
      console.error('Error loading documents:', error);
    }
  };


  const BUCKET = 'valeter_documents';

  async function uploadUriToSupabase(
    uri: string,
    path: string,
    contentType = 'image/jpeg'
  ) {
    const file = {
      uri,
      name: path.split('/').pop() || 'upload.jpg',
      type: contentType,
    } as any;

    const { data, error } = await supabase
      .storage
      .from(BUCKET)
      .upload(path, file, {
        contentType,
        upsert: false,
      });

    if (error) throw error;

    const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(path);
    const publicUrl = pub?.publicUrl ?? null;

    return { path: data?.path ?? path, publicUrl };
  }

  function extFromMime(m?: string | null) {
    if (!m) return 'jpg';
    if (m.includes('png')) return 'png';
    if (m.includes('heic')) return 'heic';
    if (m.includes('webp')) return 'webp';
    if (m.includes('jpeg')) return 'jpg';
    return 'jpg';
  }

  const handleLogout = async () => {
    try {
      await hapticFeedback('medium');
      Alert.alert(
        'Logout',
        'Are you sure you want to logout?',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Logout',
            style: 'destructive',
            onPress: async () => {
              try {
                await logout();
                router.replace('/');
              } catch (error) {
                console.error('Logout error:', error);
                Alert.alert('Logout Error', 'Failed to logout. Please try again.');
              }
            }
          }
        ]
      );
    } catch (error) {
      // Haptic feedback not available
    }
  };

  const handleDeleteAccount = async () => {
    try {
      await hapticFeedback('heavy');
      Alert.alert(
        'Delete Account',
        'This action cannot be undone. Are you sure you want to delete your account?',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Delete',
            style: 'destructive',
            onPress: () => {
              Alert.alert('Account Deleted', 'Your account has been deleted.');
            }
          }
        ]
      );
    } catch (error) {
      // Haptic feedback not available
    }
  };

  const handleUploadProfilePicture = async () => {
    try {
      await hapticFeedback('light');
      setShowPhotoModal(true);
    } catch (error) {
      // Haptic feedback not available
    }
  };

  const takePhoto = async () => {
    try {
      setIsLoading(true);

      const { status } = await ImagePicker.requestCameraPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Camera permission is required to take a photo.');
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        await uploadProfilePhoto(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Error taking photo:', error);
      Alert.alert('Error', 'Failed to take photo. Please try again.');
    } finally {
      setUploadingPicture(false);
    }
  };

  const pickImage = async () => {
    try {
      setUploadingPicture(true);

      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission Required', 'Gallery permission is required to select a photo.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        await uploadProfilePhoto(result.assets[0].uri);
      }
    } catch (error) {
      console.error('Error picking image:', error);
      Alert.alert('Error', 'Failed to select image. Please try again.');
    } finally {
      setUploadingPicture(false);
    }
  };

  const uploadProfilePhoto = async (uri: string) => {
    try {
      const ext = uri.split('.').pop() || 'jpg';
      const fileName = `profile_${user!.id}_${Date.now()}.${ext}`;
      const storagePath = `profiles/${user!.id}/${fileName}`;

      const { publicUrl } = await uploadUriToSupabase(uri, storagePath, `image/${ext}`);

      const { error } = await supabase
        .from('valeter_profiles')
        .update({ profile_photo_url: publicUrl })
        .eq('user_id', user!.id);

      if (error) throw error;

      setProfilePicture(publicUrl);
      setProfile(prev => prev ? { ...prev, profile_photo_url: publicUrl } : null);

      await hapticFeedback('medium');
      Alert.alert('Success', 'Profile picture uploaded successfully!');
    } catch (error: any) {
      console.error('Error uploading profile photo:', error);
      Alert.alert('Upload Failed', error?.message || 'Please try again.');
    }
  };


  const getVerificationProgress = () => {
    const total = documents.length;
    const completed = documents.filter(doc => doc.status === 'approved').length;
    const percentage = total > 0 ? Math.round((completed / total) * 100) : 0;
    const missing = documents
      .filter(doc => doc.status !== 'approved')
      .map(doc => doc.name);

    return { total, completed, percentage, missing };
  };


  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading profile...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!profile) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Failed to load profile</Text>
        </View>
      </SafeAreaView>
    );
  }

  const progress = getVerificationProgress();

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Valeter Profile"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="valeter"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={{ paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Profile Hero Section */}
        <View style={styles.heroSection}>
          <View style={styles.profilePictureContainer}>
            {profilePicture ? (
              <View style={styles.profilePicture}>
                <Image source={{ uri: profilePicture }} style={styles.profileImage} />
                {profile?.verification_badge && (
                  <View style={styles.verificationBadge}>
                    <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                  </View>
                )}
              </View>
            ) : (
              <View style={styles.profilePicturePlaceholder}>
                <Ionicons name="person" size={40} color={SKY} />
                {profile?.verification_badge && (
                  <View style={styles.verificationBadge}>
                    <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                  </View>
                )}
              </View>
            )}
            <TouchableOpacity
              style={[styles.uploadButton, isLoading && styles.uploadButtonDisabled]}
              onPress={handleUploadProfilePicture}
              disabled={isLoading}
            >
              <Ionicons name="camera" size={16} color="#0A1929" />
            </TouchableOpacity>
          </View>

          <View style={styles.profileInfo}>
            <View style={styles.nameRow}>
              <Text style={styles.userName}>{profile.full_name || 'Valeter Name'}</Text>
              {profile.verification_badge && (
                <View style={styles.verificationBadgeSmall}>
                  <Ionicons name="checkmark-circle" size={14} color="#FFFFFF" />
                </View>
              )}
            </View>
            <View style={styles.emailRow}>
            <Text style={styles.userEmail}>{user?.email || 'valeter@example.com'}</Text>
              {currentTier && (
                <Text style={styles.tierBadgeIcon}>{currentTier.icon}</Text>
              )}
            </View>
            {profile.experience && (
              <Text style={styles.userExperience}>{profile.experience} experience</Text>
            )}
            {profile.is_self_sufficient !== undefined && (
              <View style={styles.selfSufficiencyBadge}>
                <Ionicons 
                  name={profile.is_self_sufficient ? "battery-charging" : "water"} 
                  size={14} 
                  color={profile.is_self_sufficient ? "#10B981" : SKY} 
                />
                <Text style={[styles.selfSufficiencyText, { color: profile.is_self_sufficient ? "#10B981" : SKY }]}>
                  {profile.is_self_sufficient ? "Self-Sufficient" : "Needs Resources"}
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Tier Info Section - Simplified */}
        {currentTier && (
          <View style={styles.section}>
            <View style={styles.tierInfoCard}>
            <LinearGradient
                colors={[currentTier.color + '20', currentTier.color + '10']}
                style={styles.tierInfoCardGradient}
            >
                <View style={styles.tierInfoRow}>
                  <Text style={styles.tierInfoIcon}>{currentTier.icon}</Text>
                  <View style={styles.tierInfoTextContainer}>
                    <Text style={styles.tierInfoTitle}>{currentTier.name} Valeter</Text>
                    <Text style={styles.tierInfoSubtitle}>
                    {valeterStats.totalJobs} jobs • {valeterStats.experienceMonths} months • ⭐ {valeterStats.averageRating.toFixed(1)}
                  </Text>
                  </View>
                  {currentTier.nextTierProgress > 0 && (
                    <View style={styles.tierInfoProgress}>
                      <Text style={[styles.tierInfoProgressText, { color: currentTier.color }]}>
                        {currentTier.nextTierProgress}%
                      </Text>
                      <Text style={styles.tierInfoProgressLabel}>to next tier</Text>
                    </View>
                  )}
              </View>
            </LinearGradient>
            </View>
          </View>
        )}

        {/* Overview Stats Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Today's Overview</Text>
          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <View style={styles.statCardContent}>
                <View style={styles.statIconWrapper}>
                  <Ionicons name="time" size={22} color={SKY} />
                </View>
                <View style={styles.statTextContainer}>
                  <Text style={styles.statNumber}>{todayStats.hoursOnline}</Text>
                  <Text style={styles.statLabel}>Hours Online</Text>
                </View>
              </View>
            </View>
            <View style={styles.statCard}>
              <View style={styles.statCardContent}>
                <View style={styles.statIconWrapper}>
                  <Ionicons name="checkmark-circle" size={22} color="#10B981" />
                </View>
                <View style={styles.statTextContainer}>
                  <CountUpNumber value={todayStats.jobsCompleted} style={styles.statNumber} />
                  <Text style={styles.statLabel}>Jobs Completed</Text>
                </View>
              </View>
            </View>
            <View style={styles.statCard}>
              <View style={styles.statCardContent}>
                <View style={styles.statIconWrapper}>
                  <Ionicons name="cash" size={22} color={SKY} />
                </View>
                <View style={styles.statTextContainer}>
                  <CountUpNumber value={todayStats.earnings} prefix="£" style={styles.statNumber} />
                  <Text style={styles.statLabel}>Earnings Today</Text>
                </View>
              </View>
            </View>
            <View style={styles.statCard}>
              <View style={styles.statCardContent}>
                <View style={styles.statIconWrapper}>
                  <Ionicons name="trending-up" size={22} color="#F59E0B" />
                </View>
                <View style={styles.statTextContainer}>
                  <Text style={styles.statNumber}>
                    {todayStats.jobsCompleted > 0
                      ? `£${(todayStats.earnings / todayStats.jobsCompleted).toFixed(2)}`
                      : '£0'}
                  </Text>
                  <Text style={styles.statLabel}>Avg per Job</Text>
                </View>
              </View>
            </View>
          </View>
        </View>


        {/* Business Section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Business Information</Text>
          <View style={styles.businessCard}>
            <View style={styles.businessHeader}>
              <Ionicons 
                name={isIndependent ? "person" : "business"} 
                size={18} 
                color={SKY} 
              />
              <View style={styles.businessInfo}>
                <Text style={styles.businessTitle}>
                  {isIndependent ? 'Independent Valeter' : 'Organization Valeter'}
                </Text>
                {!isIndependent && organizationName && (
                  <Text style={styles.businessSubtitle}>{organizationName}</Text>
                )}
            </View>
                  </View>
                  </View>
        </View>

        {/* Verification Progress */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Verification Progress</Text>
          <View style={styles.verificationCard}>
            <View style={styles.progressHeader}>
              <Text style={styles.progressText}>
                {progress.completed} of {progress.total} completed
              </Text>
              <Text style={styles.progressPercentage}>{progress.percentage}%</Text>
            </View>
            <View style={styles.progressBar}>
              <View
                style={[
                  styles.progressFill,
                  { width: `${progress.percentage}%` }
                ]}
              />
            </View>
            {progress.missing.length > 0 && (
              <Text style={styles.missingText}>
                Pending: {progress.missing.join(', ')}
              </Text>
            )}
          </View>
        </View>

        {/* Menu Items */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Profile Settings</Text>
          <View style={styles.menuSection}>
            <TouchableOpacity 
              style={styles.menuItem} 
              onPress={() => router.push('/valeter/profile/valeter-personal-info')}
              activeOpacity={0.8}
            >
              <View style={styles.menuIconWrapper}>
                <Ionicons name="person" size={18} color={SKY} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Personal Information</Text>
                <Text style={styles.menuSubtitle}>Name, email, bio, experience</Text>
            </View>
              <Ionicons name="chevron-forward" size={18} color="#87CEEB" />
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.menuItem} 
              onPress={() => router.push('/valeter/profile/valeter-vehicle-info')}
              activeOpacity={0.8}
            >
              <View style={styles.menuIconWrapper}>
                <Ionicons name="car" size={18} color={SKY} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Vehicle Information</Text>
                <Text style={styles.menuSubtitle}>Make, model, registration</Text>
            </View>
              <Ionicons name="chevron-forward" size={18} color="#87CEEB" />
            </TouchableOpacity>

            <TouchableOpacity 
              style={styles.menuItem} 
              onPress={() => router.push('/valeter/profile/valeter-legal-compliance')}
              activeOpacity={0.8}
            >
              <View style={styles.menuIconWrapper}>
                <Ionicons name="shield-checkmark" size={18} color={SKY} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Legal Compliance</Text>
                <Text style={styles.menuSubtitle}>Compliance status and action items</Text>
            </View>
              <Ionicons name="chevron-forward" size={18} color="#87CEEB" />
            </TouchableOpacity>

              <TouchableOpacity
              style={styles.menuItem} 
              onPress={() => router.push('/valeter/profile/valeter-documents')}
              activeOpacity={0.8}
              >
              <View style={styles.menuIconWrapper}>
                <Ionicons name="document-text" size={18} color={SKY} />
                  </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Required Documents</Text>
                <Text style={styles.menuSubtitle}>Upload and manage documents</Text>
                </View>
              <Ionicons name="chevron-forward" size={18} color="#87CEEB" />
              </TouchableOpacity>

            <TouchableOpacity 
              style={styles.menuItem} 
              onPress={() => router.push('/valeter/features/referral-system')}
              activeOpacity={0.8}
            >
              <View style={styles.menuIconWrapper}>
                <Ionicons name="gift" size={18} color={SKY} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Referrals</Text>
                <Text style={styles.menuSubtitle}>Invite valeters and earn bonuses</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="#87CEEB" />
            </TouchableOpacity>
          </View>
        </View>


        {/* Account Settings */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Settings</Text>
          <View style={styles.settingsContainer}>
            <TouchableOpacity
              style={styles.settingItem}
              onPress={async () => {
                await hapticFeedback('light');
                router.push('/owner/settings/privacy-settings');
              }}
            >
              <View style={styles.settingLeft}>
                <Ionicons name="settings" size={20} color={SKY} style={styles.settingIcon} />
                <Text style={styles.settingText}>Privacy & Security</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color={SKY} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Account Actions */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Account Actions</Text>
          <View style={styles.settingsContainer}>
            <TouchableOpacity style={[styles.settingItem, styles.logoutItem]} onPress={handleLogout}>
              <View style={styles.settingLeft}>
                <Ionicons name="log-out" size={20} color="#EF4444" style={styles.settingIcon} />
                <Text style={[styles.settingText, styles.logoutText]}>Logout</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#EF4444" />
            </TouchableOpacity>

            <TouchableOpacity style={[styles.settingItem, styles.deleteItem]} onPress={handleDeleteAccount}>
              <View style={styles.settingLeft}>
                <Ionicons name="trash" size={20} color="#EF4444" style={styles.settingIcon} />
                <Text style={[styles.settingText, styles.deleteText]}>Delete Account</Text>
              </View>
              <Ionicons name="chevron-forward" size={20} color="#EF4444" />
            </TouchableOpacity>
          </View>
        </View>

        {/* App Info */}
        <View style={styles.appInfoSection}>
          <Text style={styles.appInfoText}>Wish a Wash v1.0.0</Text>
          <Text style={styles.appInfoText}>© 2025 Wish a Wash. All rights reserved.</Text>
        </View>
      </Animated.ScrollView>

      {/* Photo Upload Modal */}
      <Modal
        visible={showPhotoModal}
        transparent={true}
        animationType="slide"
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Upload Profile Picture</Text>
            <Text style={styles.modalDescription}>Choose how you want to add your profile picture</Text>

            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => {
                  setShowPhotoModal(false);
                  takePhoto();
                }}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={[SKY, '#0EA5E9']}
                  style={styles.modalButtonGradient}
                >
                  <Ionicons name="camera" size={20} color="#FFFFFF" />
                  <Text style={styles.modalButtonText}>Take Photo</Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.modalButton}
                onPress={() => {
                  setShowPhotoModal(false);
                  pickImage();
                }}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={[SKY, '#0EA5E9']}
                  style={styles.modalButtonGradient}
                >
                  <Ionicons name="images" size={20} color="#FFFFFF" />
                  <Text style={styles.modalButtonText}>Choose from Gallery</Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.modalButtonCancel}
                onPress={() => setShowPhotoModal(false)}
                activeOpacity={0.8}
              >
                <Text style={styles.modalButtonTextCancel}>Cancel</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#F9FAFB',
    fontSize: 18,
    marginTop: 12,
  },
  scrollView: {
    flex: 1,
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    backgroundColor: 'transparent',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    overflow: 'hidden',
  },
  bubblesContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 0,
    overflow: 'hidden',
  },
  bubble: {
    position: 'absolute',
    borderRadius: 50,
    backgroundColor: SKY,
    opacity: 0.15,
  },
  glowLine: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: 'rgba(135,206,235,0.4)',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 4,
  },
  headerContent: {
    flex: 1,
    paddingHorizontal: 16,
    justifyContent: 'center',
    height: 64,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    overflow: 'hidden',
  },
  backButtonGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    flex: 1,
    textAlign: 'center',
    letterSpacing: 0.2,
  },
  headerSpacer: {
    width: 36,
  },
  heroSection: {
    padding: isSmallScreen ? 20 : 24,
    alignItems: 'center',
    marginBottom: 0,
  },
  profilePictureContainer: {
    alignItems: 'center',
    marginBottom: 20,
    position: 'relative',
  },
  profilePicture: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(135,206,235,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 3,
    borderColor: 'rgba(135,206,235,0.3)',
    overflow: 'hidden',
  },
  profilePicturePlaceholder: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(135,206,235,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 3,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  profileImage: {
    width: '100%',
    height: '100%',
    borderRadius: 60,
  },
  uploadButton: {
    position: 'absolute',
    bottom: 12,
    right: 0,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  uploadButtonDisabled: {
    opacity: 0.7,
    backgroundColor: '#6B7280',
  },
  profileInfo: {
    alignItems: 'center',
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 4,
  },
  userName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: '800',
  },
  emailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 4,
  },
  userEmail: {
    color: SKY,
    fontSize: isSmallScreen ? 14 : 16,
  },
  userExperience: {
    color: SKY,
    fontSize: isSmallScreen ? 14 : 16,
    fontStyle: 'italic',
  },
  selfSufficiencyBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignSelf: 'flex-start',
  },
  selfSufficiencyText: {
    fontSize: 12,
    fontWeight: '600',
  },
  tierSection: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 0,
    marginBottom: 20,
  },
  tierCardContainer: {
    marginBottom: 16,
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  tierCard: {
    padding: 24,
    borderRadius: 20,
    alignItems: 'center',
  },
  tierInfoContainer: {
    alignItems: 'center',
    width: '100%',
    marginBottom: 16,
  },
  tierNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    marginBottom: 10,
  },
  tierBadgeIcon: {
    fontSize: 40,
  },
  tierInfoCard: {
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  tierInfoCardGradient: {
    padding: 12,
  },
  tierInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  tierInfoIcon: {
    fontSize: 32,
  },
  tierInfoTextContainer: {
    flex: 1,
  },
  tierInfoTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 4,
  },
  tierInfoSubtitle: {
    color: '#E0E7FF',
    fontSize: 13,
    fontWeight: '500',
  },
  tierInfoProgress: {
    alignItems: 'flex-end',
  },
  tierInfoProgressText: {
    fontSize: 18,
    fontWeight: '900',
    marginBottom: 2,
  },
  tierInfoProgressLabel: {
    color: '#E0E7FF',
    fontSize: 11,
    fontWeight: '600',
  },
  tierNameText: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '800',
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
    letterSpacing: 0.3,
  },
  tierStatsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  tierStatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255,255,255,0.12)',
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
  },
  tierStatDivider: {
    width: 1,
    height: 20,
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  tierStatText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '700',
  },
  tierProgressContainer: {
    width: '100%',
    marginTop: 8,
    alignItems: 'center',
  },
  tierProgressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    width: '100%',
    marginBottom: 8,
  },
  tierProgressLabel: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '600',
    opacity: 0.9,
  },
  tierProgressPercent: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '800',
  },
  tierProgressBarContainer: {
    width: '100%',
    marginBottom: 16,
  },
  tierProgressBar: {
    height: 8,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  tierProgressFill: {
    height: '100%',
    borderRadius: 4,
  },
  circularProgressContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  circularProgress: {
    width: 60,
    height: 60,
    borderRadius: 30,
    borderWidth: 4,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  circularProgressText: {
    fontSize: 14,
    fontWeight: '800',
  },
  tierBenefitsContainer: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  benefitsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  benefitsHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  benefitsTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  benefitsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'space-between',
  },
  benefitCard: {
    width: (width - (isSmallScreen ? 16 : 20) * 2 - 40 - 12) / 2,
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1.5,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  benefitCardGradient: {
    padding: 12,
    alignItems: 'center',
    minHeight: 90,
    justifyContent: 'center',
  },
  benefitIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  benefitText: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
    lineHeight: 16,
  },
  viewAllBenefitsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    marginTop: 12,
    paddingVertical: 10,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  viewAllBenefitsText: {
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  section: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.05)',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '800',
    marginBottom: 12,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 12,
  },
  statCard: {
    width: (width - 48) / 2 - 6,
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.1)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  statCardContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    gap: 12,
  },
  statIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  statTextContainer: {
    flex: 1,
  },
  statNumber: {
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '800',
    color: '#F9FAFB',
    marginBottom: 2,
  },
  statLabel: {
    fontSize: 12,
    color: SKY,
    fontWeight: '600',
  },
  verificationCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  progressText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  progressPercentage: {
    color: SKY,
    fontSize: 16,
    fontWeight: '800',
  },
  missingText: {
    color: '#F59E0B',
    fontSize: 12,
    marginTop: 8,
  },
  settingsContainer: {
    gap: 8,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    marginRight: 10,
    width: 20,
    textAlign: 'center',
  },
  settingText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
  },
  settingValue: {
    color: SKY,
    fontSize: 13,
    textAlign: 'right',
    flex: 1,
  },
  settingInput: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    textAlign: 'right',
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: SKY,
    paddingVertical: 4,
  },
  bioInput: {
    height: 60,
    textAlignVertical: 'top',
    textAlign: 'left',
  },
  documentInfo: {
    flex: 1,
  },
  documentDescription: {
    color: SKY,
    fontSize: 12,
    marginTop: 2,
  },
  documentStatus: {
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  complianceStatusCard: {
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.15,
    shadowRadius: 2,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  complianceStatusGradient: {
    padding: 12,
  },
  complianceStatusHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  complianceStatusBadge: {
    width: 40,
    height: 40,
    borderRadius: 20,
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  complianceStatusInfo: {
    flex: 1,
  },
  complianceStatusTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 2,
    letterSpacing: 0.2,
  },
  complianceStatusSubtitle: {
    color: '#E0E7FF',
    fontSize: 12,
    fontWeight: '500',
    opacity: 0.9,
  },
  complianceScoreCompact: {
    alignItems: 'center',
    justifyContent: 'center',
    minWidth: 50,
  },
  complianceScoreText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '900',
  },
  complianceActionCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.15,
    shadowRadius: 2,
  },
  complianceActionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  complianceActionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  complianceChecklist: {
    marginBottom: 14,
  },
  complianceChecklistTitle: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  complianceItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    paddingHorizontal: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 10,
    marginBottom: 6,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  complianceItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 12,
  },
  complianceItemIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  complianceItemText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    flex: 1,
  },
  complianceActionButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginTop: 8,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  complianceActionButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    gap: 8,
  },
  complianceActionButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  saveButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  saveButtonGradient: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  logoutItem: {
    borderBottomWidth: 0,
    backgroundColor: 'rgba(239,68,68,0.1)',
  },
  deleteItem: {
    borderBottomWidth: 0,
    backgroundColor: 'rgba(239,68,68,0.1)',
  },
  logoutText: {
    color: '#EF4444',
  },
  deleteText: {
    color: '#EF4444',
  },
  appInfoSection: {
    padding: 20,
  },
  appInfoText: {
    color: SKY,
    fontSize: 12,
    textAlign: 'center',
    marginBottom: 4,
    opacity: 0.7,
  },
  verificationBadge: {
    position: 'absolute',
    top: -5,
    right: -5,
    backgroundColor: '#10B981',
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#0A1929',
  },
  verificationBadgeSmall: {
    backgroundColor: '#10B981',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginLeft: 8,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.8)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalContent: {
    backgroundColor: '#1E3A8A',
    borderRadius: 20,
    padding: 24,
    margin: 20,
    width: '90%',
    maxWidth: 400,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
    textAlign: 'center',
  },
  modalDescription: {
    color: '#E5E7EB',
    fontSize: 14,
    marginBottom: 24,
    textAlign: 'center',
  },
  modalActions: {
    gap: 12,
  },
  modalButton: {
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  modalButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    gap: 8,
  },
  modalButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
  },
  modalButtonCancel: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    paddingVertical: 14,
    paddingHorizontal: 16,
    alignItems: 'center',
    borderRadius: 12,
    marginTop: 4,
  },
  modalButtonTextCancel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  businessCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  businessHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  businessInfo: {
    flex: 1,
  },
  businessTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
  },
  businessSubtitle: {
    color: SKY,
    fontSize: 13,
    marginTop: 2,
  },
  menuSection: {
    gap: 8,
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.15,
    shadowRadius: 3,
    marginBottom: 8,
  },
  menuIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  menuContent: {
    flex: 1,
  },
  menuTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 2,
  },
  menuSubtitle: {
    color: '#87CEEB',
    fontSize: 11,
    fontWeight: '600',
  },
});
