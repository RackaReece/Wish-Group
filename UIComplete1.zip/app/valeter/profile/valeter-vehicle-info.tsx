import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  TextInput,
  Dimensions,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

interface ValeterProfileData {
  user_id: string;
  vehicle_make?: string;
  vehicle_model?: string;
  vehicle_registration?: string;
}

export default function ValeterVehicleInfo() {
  const router = useRouter();
  const { user } = useAuth();
  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (user?.id) {
      loadProfile();
    }
  }, [user?.id]);

  const loadProfile = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('valeter_profiles')
        .select('user_id, vehicle_make, vehicle_model, vehicle_registration')
        .eq('user_id', user!.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setProfile(data);
      } else {
        const newProfile: Partial<ValeterProfileData> = {
          user_id: user!.id,
        };

        const { data: created, error: createError } = await supabase
          .from('valeter_profiles')
          .insert(newProfile)
          .select()
          .single();

        if (createError) throw createError;
        setProfile(created);
      }
    } catch (error: any) {
      console.error('Error loading profile:', error);
      Alert.alert('Error', 'Failed to load vehicle information');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!user?.id || !profile) return;

    try {
      setIsSaving(true);
      const { error } = await supabase
        .from('valeter_profiles')
        .update({
          vehicle_make: profile.vehicle_make,
          vehicle_model: profile.vehicle_model,
          vehicle_registration: profile.vehicle_registration,
        })
        .eq('user_id', user.id);

      if (error) throw error;

      Alert.alert('Success', 'Vehicle information updated successfully');
      setIsEditing(false);
    } catch (error: any) {
      console.error('Error saving profile:', error);
      Alert.alert('Error', error.message || 'Failed to save vehicle information');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={[BG, colors.headerBg]} style={StyleSheet.absoluteFill} />
        <AppHeader title="Vehicle Information" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!profile) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={[BG, colors.headerBg]} style={StyleSheet.absoluteFill} />
        <AppHeader title="Vehicle Information" />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Failed to load vehicle information</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={[BG, colors.headerBg]} style={StyleSheet.absoluteFill} />

      <AppHeader 
        title="Vehicle Information"
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              setIsEditing(!isEditing);
            }}
            activeOpacity={0.7}
            style={{ padding: 8 }}
          >
            <Ionicons name={isEditing ? "close" : "create"} size={20} color={SKY} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: 40 }}
      >
        <View style={styles.section}>
          <View style={styles.settingsContainer}>
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="car" size={20} color={SKY} style={styles.settingIcon} />
                <Text style={styles.settingText}>Make</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.vehicle_make || ''}
                  onChangeText={(text) => setProfile({ ...profile, vehicle_make: text })}
                  placeholder="Auto-filled from DVLA lookup"
                  placeholderTextColor={SKY}
                />
              ) : (
                <Text style={styles.settingValue}>{profile.vehicle_make || 'Not set'}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="car-sport" size={20} color={SKY} style={styles.settingIcon} />
                <Text style={styles.settingText}>Model</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.vehicle_model || ''}
                  onChangeText={(text) => setProfile({ ...profile, vehicle_model: text })}
                  placeholder="Auto-filled from DVLA lookup"
                  placeholderTextColor={SKY}
                />
              ) : (
                <Text style={styles.settingValue}>{profile.vehicle_model || 'Not set'}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="receipt" size={20} color={SKY} style={styles.settingIcon} />
                <Text style={styles.settingText}>Registration</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.vehicle_registration || ''}
                  onChangeText={(text) => {
                    // Clean registration: uppercase and remove spaces (for DVLA lookup)
                    const cleanReg = text.replace(/\s/g, '').toUpperCase();
                    setProfile({ ...profile, vehicle_registration: cleanReg });
                  }}
                  placeholder="Enter UK registration (e.g., AB12 CDE)"
                  placeholderTextColor={SKY}
                  autoCapitalize="characters"
                />
              ) : (
                <Text style={styles.settingValue}>{profile.vehicle_registration || 'Not set'}</Text>
              )}
            </View>
          </View>
        </View>

        {/* Save Button */}
        {isEditing && (
          <View style={styles.section}>
            <TouchableOpacity
              style={[styles.saveButton, isSaving && { opacity: 0.6 }]}
              onPress={handleSaveProfile}
              disabled={isSaving}
            >
              <LinearGradient
                colors={['#10B981', '#059669']}
                style={styles.saveButtonGradient}
              >
                {isSaving ? (
                  <ActivityIndicator color="#FFFFFF" />
                ) : (
                  <Text style={styles.saveButtonText}>Save Changes</Text>
                )}
              </LinearGradient>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#FFFFFF',
    marginTop: 16,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'center',
  },
  editButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  section: {
    marginBottom: 20,
  },
  settingsContainer: {
    gap: 8,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    marginRight: 10,
    width: 20,
    textAlign: 'center',
  },
  settingText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
  },
  settingValue: {
    color: SKY,
    fontSize: 13,
    textAlign: 'right',
    flex: 1,
  },
  settingInput: {
    color: '#F9FAFB',
    fontSize: 13,
    textAlign: 'right',
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: SKY,
    paddingVertical: 4,
  },
  saveButton: {
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  saveButtonGradient: {
    paddingVertical: 16,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});

