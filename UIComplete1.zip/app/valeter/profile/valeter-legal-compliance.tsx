import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';

const SKY = colors.SKY;

interface ValeterDocument {
  id: string;
  type: 'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed';
  name: string;
  description: string;
  status: 'pending' | 'approved' | 'rejected' | 'not_uploaded';
  file_url?: string;
  uploaded_at?: string;
  approved_at?: string;
  rejection_reason?: string;
}

interface ValeterProfileData {
  profile_photo_url?: string;
}

export default function ValeterLegalCompliance() {
  const router = useRouter();
  const { user } = useAuth();
  const [documents, setDocuments] = useState<ValeterDocument[]>([]);
  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);

  const refreshData = async () => {
    if (!user?.id) return;
    setRefreshing(true);
    try {
      await Promise.all([loadDocuments(), loadProfile()]);
    } catch (error) {
      console.error('Error refreshing compliance data:', error);
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (user?.id) {
      // Load both documents and profile in parallel
      Promise.all([loadDocuments(), loadProfile()]).catch(error => {
        console.error('Error loading compliance data:', error);
        setIsLoading(false);
      });
    }
  }, [user?.id]);

  const loadDocuments = async () => {
    if (!user?.id) return;
    try {
      setIsLoading(true);
      // Load documents from Supabase valeter_documents table
      const { data, error } = await supabase
        .from('valeter_documents')
        .select('*')
        .eq('user_id', user.id);

      if (error) {
        console.error('Error loading documents:', error);
        // If table doesn't exist or error, set empty array
        setDocuments([]);
        return;
      }

      if (data && data.length > 0) {
        // Map database documents to ValeterDocument interface - only show real database records
        const mappedDocs: ValeterDocument[] = data
          .map((doc: any) => ({
            id: doc.id,
            type: doc.type as 'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed',
            name: doc.name || 'Document',
            description: doc.description || '',
            status: (doc.status || 'not_uploaded') as 'pending' | 'approved' | 'rejected' | 'not_uploaded',
            file_url: doc.file_url || doc.fileUrl,
            uploaded_at: doc.uploaded_at || doc.created_at,
            approved_at: doc.approved_at || doc.updated_at,
            rejection_reason: doc.rejection_reason,
          }))
          .sort((a, b) => {
            // Sort by uploaded_at date, most recent first
            const dateA = a.uploaded_at ? new Date(a.uploaded_at).getTime() : 0;
            const dateB = b.uploaded_at ? new Date(b.uploaded_at).getTime() : 0;
            return dateB - dateA;
          });
        setDocuments(mappedDocs);
        setLastUpdated(new Date());
      } else {
        // No documents found in database - set empty array (don't create fake data)
        setDocuments([]);
        setLastUpdated(new Date());
      }
    } catch (error) {
      console.error('Error loading documents:', error);
      setDocuments([]);
    } finally {
      setIsLoading(false);
    }
  };

  const loadProfile = async () => {
    if (!user?.id) return;
    try {
      // Check valeter_profiles table for profile photo
      const { data: profileData } = await supabase
        .from('valeter_profiles')
        .select('profile_photo_url')
        .eq('user_id', user.id)
        .maybeSingle();
      
      // Also check if profile photo exists in documents table
      const { data: docData } = await supabase
        .from('valeter_documents')
        .select('file_url, status')
        .eq('user_id', user.id)
        .eq('type', 'profile_photo')
        .maybeSingle();
      
      // Use profile photo from valeter_profiles or from documents table
      const profilePhotoUrl = profileData?.profile_photo_url || (docData?.status === 'approved' ? docData.file_url : null);
      
      if (profilePhotoUrl || profileData) {
        setProfile({ profile_photo_url: profilePhotoUrl || profileData?.profile_photo_url });
      }
    } catch (error) {
      console.error('Error loading profile:', error);
    }
    // Note: setIsLoading(false) is handled in loadDocuments
  };

  // Calculate comprehensive statistics
  const calculateStatistics = () => {
    const totalDocuments = documents.length;
    const approvedCount = documents.filter(d => d.status === 'approved').length;
    const pendingCount = documents.filter(d => d.status === 'pending').length;
    const rejectedCount = documents.filter(d => d.status === 'rejected').length;
    const notUploadedCount = documents.filter(d => d.status === 'not_uploaded').length;
    
    const approvalRate = totalDocuments > 0 ? (approvedCount / totalDocuments) * 100 : 0;
    
    // Group documents by type
    const documentsByType = {
      id_proof: documents.filter(d => d.type === 'id_proof'),
      selfie: documents.filter(d => d.type === 'selfie'),
      profile_photo: documents.filter(d => d.type === 'profile_photo'),
      disclaimer_signed: documents.filter(d => d.type === 'disclaimer_signed'),
    };
    
    // Calculate time-based metrics
    const approvedDocs = documents.filter(d => d.status === 'approved' && d.approved_at);
    const latestApprovalDate = approvedDocs.length > 0 
      ? new Date(Math.max(...approvedDocs.map(d => new Date(d.approved_at!).getTime())))
      : null;
    
    const pendingDocs = documents.filter(d => d.status === 'pending' && d.uploaded_at);
    const oldestPendingDate = pendingDocs.length > 0
      ? new Date(Math.min(...pendingDocs.map(d => new Date(d.uploaded_at!).getTime())))
      : null;
    
    const daysSinceLastUpload = documents.length > 0 && documents[0].uploaded_at
      ? Math.floor((Date.now() - new Date(documents[0].uploaded_at).getTime()) / (1000 * 60 * 60 * 24))
      : null;
    
    const daysSinceLastApproval = latestApprovalDate
      ? Math.floor((Date.now() - latestApprovalDate.getTime()) / (1000 * 60 * 60 * 24))
      : null;
    
    const daysPendingReview = oldestPendingDate
      ? Math.floor((Date.now() - oldestPendingDate.getTime()) / (1000 * 60 * 60 * 24))
      : null;
    
    // Calculate average approval time (for approved documents)
    let averageApprovalTime = null;
    if (approvedDocs.length > 0) {
      const approvalTimes = approvedDocs
        .filter(d => d.uploaded_at && d.approved_at)
        .map(d => {
          const uploadTime = new Date(d.uploaded_at!).getTime();
          const approvalTime = new Date(d.approved_at!).getTime();
          return Math.floor((approvalTime - uploadTime) / (1000 * 60 * 60 * 24));
        });
      
      if (approvalTimes.length > 0) {
        averageApprovalTime = Math.round(
          approvalTimes.reduce((sum, time) => sum + time, 0) / approvalTimes.length
        );
      }
    }
    
    return {
      totalDocuments,
      approvedCount,
      pendingCount,
      rejectedCount,
      notUploadedCount,
      approvalRate: Math.round(approvalRate),
      documentsByType,
      latestApprovalDate,
      oldestPendingDate,
      daysSinceLastUpload,
      daysSinceLastApproval,
      daysPendingReview,
      averageApprovalTime,
    };
  };

  const getComplianceStatus = () => {
    const issues: string[] = [];
    const recommendations: string[] = [];

    // Define required document types
    const requiredDocTypes: Array<'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed'> = [
      'id_proof',
      'selfie',
      'profile_photo',
      'disclaimer_signed',
    ];
    let missingDocumentsCount = 0;
    let missingTypes: Array<'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed'> = [];

    // Check documents from database (real data only)
    if (documents && documents.length > 0) {
      const rejectedDocs = documents.filter(d => d.status === 'rejected');
      const pendingDocs = documents.filter(d => d.status === 'pending');
      
      // Check which required documents are missing
      const uploadedTypes = documents.map(d => d.type);
      missingTypes = requiredDocTypes.filter(type => !uploadedTypes.includes(type));
      missingDocumentsCount = missingTypes.length;
      
      if (rejectedDocs.length > 0) {
        rejectedDocs.forEach(doc => {
          issues.push(`${doc.name} was rejected${doc.rejection_reason ? `: ${doc.rejection_reason}` : ''}`);
          recommendations.push(`Re-upload ${doc.name} with corrections`);
        });
      }
      
      if (pendingDocs.length > 0) {
        issues.push(`${pendingDocs.length} document(s) pending review`);
        recommendations.push('Wait for document verification to complete');
      }
      
      if (missingTypes.length > 0) {
        const missingNames = missingTypes.map(type => {
          switch (type) {
            case 'id_proof': return 'Proof of Identity';
            case 'selfie': return 'Selfie Photo';
            case 'profile_photo': return 'Profile Photo';
            case 'disclaimer_signed': return 'Terms & Conditions';
            default: return 'Document';
          }
        });
        issues.push(`${missingTypes.length} required document(s) not uploaded: ${missingNames.join(', ')}`);
        recommendations.push('Upload all required documents for verification');
      }
    } else {
      // No documents found in database - all required documents are missing
      issues.push('No documents uploaded yet');
      recommendations.push('Upload all required documents: Proof of Identity, Selfie Photo, Profile Photo, and Terms & Conditions');
      missingDocumentsCount = requiredDocTypes.length;
    }

    // Check profile photo from database (real data)
    const hasProfilePhotoDoc = documents?.some(d => d.type === 'profile_photo') ?? false;
    if (!profile?.profile_photo_url) {
      if (!hasProfilePhotoDoc) {
        issues.push('Profile photo required');
        recommendations.push('Upload a clear profile photo');
        if (!missingTypes.includes('profile_photo') && documents?.length) {
          missingDocumentsCount += 1;
        }
      } else {
        recommendations.push('Profile photo pending approval');
      }
    }

    // Calculate compliance score
    const requiredCount = requiredDocTypes.length;
    const approvedRequired = documents.filter(d => 
      requiredDocTypes.includes(d.type) && d.status === 'approved'
    ).length;
    const complianceScore = Math.round((approvedRequired / requiredCount) * 100);

    const pendingCount = documents.filter(d => d.status === 'pending').length;
    const rejectedCount = documents.filter(d => d.status === 'rejected').length;

    return {
      compliant: issues.length === 0,
      issues,
      recommendations,
      complianceScore,
      missingDocumentsCount,
      pendingCount,
      rejectedCount,
    };
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const compliance = getComplianceStatus();
  const stats = calculateStatistics();
  const actionRequired = compliance.missingDocumentsCount > 0;
  const inReview = !actionRequired && !compliance.compliant;
  const statusVariant = actionRequired ? 'danger' : inReview ? 'warning' : 'success';
  const statusTitle =
    statusVariant === 'danger'
      ? 'Action Required'
      : statusVariant === 'warning'
      ? 'In Review'
      : 'Fully Compliant';
  const missingSubtitle =
    compliance.missingDocumentsCount === 1
      ? '1 required document missing'
      : `${compliance.missingDocumentsCount} required documents missing`;
  const statusSubtitle =
    statusVariant === 'danger'
      ? missingSubtitle
      : statusVariant === 'warning'
      ? `${compliance.issues.length} issue${compliance.issues.length === 1 ? '' : 's'} in progress`
      : 'All requirements met';
  const statusGradient =
    statusVariant === 'success'
      ? ['rgba(16,185,129,0.2)', 'rgba(5,150,105,0.15)']
      : statusVariant === 'warning'
      ? ['rgba(251,191,36,0.25)', 'rgba(245,158,11,0.15)']
      : ['rgba(239,68,68,0.2)', 'rgba(220,38,38,0.15)'];
  const badgeColor =
    statusVariant === 'success' ? '#10B981' : statusVariant === 'warning' ? '#FBBF24' : '#EF4444';
  const badgeIcon =
    statusVariant === 'success'
      ? 'shield-checkmark'
      : statusVariant === 'warning'
      ? 'time'
      : 'warning';
  const complianceScoreValue =
    statusVariant === 'success'
      ? 100
      : Math.max(0, Math.min(100, compliance.complianceScore));

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      <AppHeader title="Legal Compliance" />

      <ScrollView 
        style={styles.content} 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: 40 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={refreshData}
            tintColor={SKY}
            colors={[SKY]}
          />
        }
      >
        {/* Statistics Section */}
        <View style={styles.section}>
          <View style={styles.statisticsCard}>
            <View style={styles.statisticsHeader}>
              <Ionicons name="stats-chart" size={20} color={SKY} />
              <Text style={styles.statisticsTitle}>Document Statistics</Text>
              {lastUpdated && (
                <Text style={styles.lastUpdatedText}>
                  Updated {lastUpdated.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
                </Text>
              )}
            </View>
            
            <View style={styles.statisticsGrid}>
              <View style={styles.statItem}>
                <View style={[styles.statIcon, { backgroundColor: 'rgba(135,206,235,0.2)' }]}>
                  <Ionicons name="document-text" size={20} color={SKY} />
                </View>
                <Text style={styles.statValue}>{stats.totalDocuments}</Text>
                <Text style={styles.statLabel}>Total Documents</Text>
              </View>
              
              <View style={styles.statItem}>
                <View style={[styles.statIcon, { backgroundColor: 'rgba(16,185,129,0.2)' }]}>
                  <Ionicons name="checkmark-circle" size={20} color="#10B981" />
                </View>
                <Text style={styles.statValue}>{stats.approvedCount}</Text>
                <Text style={styles.statLabel}>Approved</Text>
              </View>
              
              <View style={styles.statItem}>
                <View style={[styles.statIcon, { backgroundColor: 'rgba(234,179,8,0.2)' }]}>
                  <Ionicons name="time" size={20} color="#EAB308" />
                </View>
                <Text style={styles.statValue}>{stats.pendingCount}</Text>
                <Text style={styles.statLabel}>Pending</Text>
              </View>
              
              <View style={styles.statItem}>
                <View style={[styles.statIcon, { backgroundColor: 'rgba(239,68,68,0.2)' }]}>
                  <Ionicons name="close-circle" size={20} color="#EF4444" />
                </View>
                <Text style={styles.statValue}>{stats.rejectedCount}</Text>
                <Text style={styles.statLabel}>Rejected</Text>
              </View>
            </View>
            
            {/* Approval Rate */}
            <View style={styles.approvalRateCard}>
              <View style={styles.approvalRateHeader}>
                <Text style={styles.approvalRateLabel}>Approval Rate</Text>
                <Text style={styles.approvalRateValue}>{stats.approvalRate}%</Text>
              </View>
              <View style={styles.progressBarContainer}>
                <View style={styles.progressBarBackground}>
                  <View 
                    style={[
                      styles.progressBarFill, 
                      { width: `${stats.approvalRate}%` }
                    ]} 
                  />
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* Document Breakdown by Type */}
        <View style={styles.section}>
          <View style={styles.breakdownCard}>
            <View style={styles.breakdownHeader}>
              <Ionicons name="list" size={20} color={SKY} />
              <Text style={styles.breakdownTitle}>Documents by Type</Text>
            </View>
            
            {Object.entries(stats.documentsByType).map(([type, docs]) => {
              const typedDocs = docs as ValeterDocument[];
              const typeName = type === 'id_proof' ? 'ID Proof' :
                               type === 'selfie' ? 'Selfie' :
                               type === 'profile_photo' ? 'Profile Photo' :
                               'Terms & Conditions';
              const approved = typedDocs.filter((d: ValeterDocument) => d.status === 'approved').length;
              const pending = typedDocs.filter((d: ValeterDocument) => d.status === 'pending').length;
              const rejected = typedDocs.filter((d: ValeterDocument) => d.status === 'rejected').length;
              const total = typedDocs.length;
              const progress = total > 0 ? (approved / total) * 100 : 0;
              
              return (
                <View key={type} style={styles.breakdownItem}>
                  <View style={styles.breakdownItemHeader}>
                    <Text style={styles.breakdownItemName}>{typeName}</Text>
                    <View style={styles.breakdownItemCounts}>
                      {approved > 0 && (
                        <View style={styles.countBadge}>
                          <Text style={[styles.countText, { color: '#10B981' }]}>
                            ✓ {approved}
                          </Text>
                        </View>
                      )}
                      {pending > 0 && (
                        <View style={styles.countBadge}>
                          <Text style={[styles.countText, { color: '#EAB308' }]}>
                            ⏱ {pending}
                          </Text>
                        </View>
                      )}
                      {rejected > 0 && (
                        <View style={styles.countBadge}>
                          <Text style={[styles.countText, { color: '#EF4444' }]}>
                            ✗ {rejected}
                          </Text>
                        </View>
                      )}
                    </View>
                  </View>
                  <View style={styles.progressBarContainer}>
                    <View style={styles.progressBarBackground}>
                      <View 
                        style={[
                          styles.progressBarFill, 
                          { 
                            width: `${progress}%`,
                            backgroundColor: approved > 0 ? '#10B981' : '#6B7280'
                          }
                        ]} 
                      />
                    </View>
                  </View>
                </View>
              );
            })}
          </View>
        </View>

        {/* Timeline Section */}
        {documents.length > 0 && (
          <View style={styles.section}>
            <View style={styles.timelineCard}>
              <View style={styles.timelineHeader}>
                <Ionicons name="time-outline" size={20} color={SKY} />
                <Text style={styles.timelineTitle}>Document Timeline</Text>
              </View>
              
              {documents.slice(0, 10).map((doc) => {
                const uploadDate = doc.uploaded_at ? new Date(doc.uploaded_at) : null;
                const approvalDate = doc.approved_at ? new Date(doc.approved_at) : null;
                const statusColor = doc.status === 'approved' ? '#10B981' :
                                   doc.status === 'rejected' ? '#EF4444' :
                                   doc.status === 'pending' ? '#EAB308' : '#6B7280';
                
                return (
                  <View key={doc.id} style={styles.timelineItem}>
                    <View style={[styles.timelineDot, { backgroundColor: statusColor }]} />
                    <View style={styles.timelineContent}>
                      <View style={styles.timelineItemHeader}>
                        <Text style={styles.timelineItemName}>{doc.name}</Text>
                        <View style={[styles.timelineStatusBadge, { backgroundColor: `${statusColor}20` }]}>
                          <Text style={[styles.timelineStatusText, { color: statusColor }]}>
                            {doc.status.charAt(0).toUpperCase() + doc.status.slice(1)}
                          </Text>
                        </View>
                      </View>
                      {uploadDate && (
                        <Text style={styles.timelineDate}>
                          Uploaded: {uploadDate.toLocaleDateString('en-GB', { 
                            day: 'numeric', 
                            month: 'short', 
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </Text>
                      )}
                      {approvalDate && (
                        <Text style={styles.timelineDate}>
                          {doc.status === 'approved' ? 'Approved' : 'Updated'}: {approvalDate.toLocaleDateString('en-GB', { 
                            day: 'numeric', 
                            month: 'short', 
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </Text>
                      )}
                      {doc.rejection_reason && (
                        <Text style={styles.timelineRejectionReason}>
                          Reason: {doc.rejection_reason}
                        </Text>
                      )}
                    </View>
                  </View>
                );
              })}
            </View>
          </View>
        )}

        {/* Detailed Metrics */}
        <View style={styles.section}>
          <View style={styles.metricsCard}>
            <View style={styles.metricsHeader}>
              <Ionicons name="analytics" size={20} color={SKY} />
              <Text style={styles.metricsTitle}>Compliance Metrics</Text>
            </View>
            
            <View style={styles.metricsGrid}>
              <View style={styles.metricItem}>
                <Text style={styles.metricValue}>{compliance.complianceScore}%</Text>
                <Text style={styles.metricLabel}>Compliance Score</Text>
              </View>
              
              {stats.daysSinceLastUpload !== null && (
                <View style={styles.metricItem}>
                  <Text style={styles.metricValue}>{stats.daysSinceLastUpload}</Text>
                  <Text style={styles.metricLabel}>
                    Days Since{'\n'}Last Upload
                  </Text>
                </View>
              )}
              
              {stats.daysSinceLastApproval !== null && (
                <View style={styles.metricItem}>
                  <Text style={styles.metricValue}>{stats.daysSinceLastApproval}</Text>
                  <Text style={styles.metricLabel}>
                    Days Since{'\n'}Last Approval
                  </Text>
                </View>
              )}
              
              {stats.daysPendingReview !== null && (
                <View style={styles.metricItem}>
                  <Text style={styles.metricValue}>{stats.daysPendingReview}</Text>
                  <Text style={styles.metricLabel}>
                    Days Pending{'\n'}Review
                  </Text>
                </View>
              )}
              
              {stats.averageApprovalTime !== null && (
                <View style={styles.metricItem}>
                  <Text style={styles.metricValue}>{stats.averageApprovalTime}</Text>
                  <Text style={styles.metricLabel}>
                    Avg Approval{'\n'}Time (days)
                  </Text>
                </View>
              )}
            </View>
          </View>
        </View>

        {/* Compliance Status Card */}
        <View style={styles.section}>
          <View style={styles.complianceStatusCard}>
            <LinearGradient
              colors={statusGradient}
              style={styles.complianceStatusGradient}
            >
              <View style={styles.complianceStatusHeader}>
                <View style={[
                  styles.complianceStatusBadge,
                  { backgroundColor: badgeColor }
                ]}>
                  <Ionicons
                    name={badgeIcon as any}
                    size={20}
                    color="#FFFFFF"
                  />
                </View>
                <View style={styles.complianceStatusInfo}>
                  <Text style={styles.complianceStatusTitle}>
                    {statusTitle}
                  </Text>
                  <Text style={styles.complianceStatusSubtitle}>
                    {statusSubtitle}
                  </Text>
                </View>
                <View style={styles.complianceScoreCompact}>
                  <Text style={styles.complianceScoreText}>
                    {complianceScoreValue}%
                  </Text>
                </View>
              </View>
            </LinearGradient>
          </View>

          {/* Action Items Card */}
          {(compliance.issues.length > 0 || compliance.recommendations.length > 0) && (
            <View style={styles.complianceActionCard}>
              <View style={styles.complianceActionHeader}>
                <Ionicons name="list" size={20} color={SKY} />
                <Text style={styles.complianceActionTitle}>Action Items</Text>
              </View>

              {/* Issues Checklist */}
              {compliance.issues.length > 0 && (
                <View style={styles.complianceChecklist}>
                  <Text style={styles.complianceChecklistTitle}>Issues to Resolve</Text>
                  {compliance.issues.map((issue, index) => {
                    const isDocumentIssue = issue.toLowerCase().includes('document');
                    const isProfileIssue = issue.toLowerCase().includes('profile') || issue.toLowerCase().includes('photo');
                    
                    return (
                      <TouchableOpacity
                        key={index}
                        style={styles.complianceItem}
                        onPress={async () => {
                          await hapticFeedback('light');
                          if (isDocumentIssue) {
                            router.push('/valeter/profile/valeter-documents');
                          } else if (isProfileIssue) {
                            router.push('/valeter/profile/valeter-profile');
                          }
                        }}
                        activeOpacity={0.7}
                      >
                        <View style={styles.complianceItemLeft}>
                          <View style={[styles.complianceItemIcon, { backgroundColor: 'rgba(239,68,68,0.2)' }]}>
                            <Ionicons name="close-circle" size={18} color="#EF4444" />
                          </View>
                          <Text style={styles.complianceItemText}>{issue}</Text>
                        </View>
                        <Ionicons name="chevron-forward" size={18} color={SKY} />
                      </TouchableOpacity>
                    );
                  })}
                </View>
              )}

              {/* Recommendations */}
              {compliance.recommendations.length > 0 && (
                <View style={styles.complianceChecklist}>
                  <Text style={styles.complianceChecklistTitle}>Recommendations</Text>
                  {compliance.recommendations.map((rec, index) => {
                    const isDocumentRec = rec.toLowerCase().includes('document');
                    const isProfileRec = rec.toLowerCase().includes('profile') || rec.toLowerCase().includes('photo');
                    
                    return (
                      <TouchableOpacity
                        key={index}
                        style={styles.complianceItem}
                        onPress={async () => {
                          await hapticFeedback('light');
                          if (isDocumentRec) {
                            router.push('/valeter/profile/valeter-documents');
                          } else if (isProfileRec) {
                            router.push('/valeter/profile/valeter-profile');
                          }
                        }}
                        activeOpacity={0.7}
                      >
                        <View style={styles.complianceItemLeft}>
                          <View style={[styles.complianceItemIcon, { backgroundColor: 'rgba(16,185,129,0.2)' }]}>
                            <Ionicons name="checkmark-circle" size={18} color="#10B981" />
                          </View>
                          <Text style={styles.complianceItemText}>{rec}</Text>
                        </View>
                        <Ionicons name="chevron-forward" size={18} color={SKY} />
                      </TouchableOpacity>
                    );
                  })}
                </View>
              )}

              {/* Quick Action Button */}
              {compliance.issues.length > 0 && (
                <TouchableOpacity
                  style={styles.complianceActionButton}
                  onPress={async () => {
                    await hapticFeedback('medium');
                    router.push('/valeter/valeter-documents');
                  }}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={[SKY, '#0EA5E9']}
                    style={styles.complianceActionButtonGradient}
                  >
                    <Ionicons name="document-text" size={18} color="#FFFFFF" />
                    <Text style={styles.complianceActionButtonText}>Upload Documents</Text>
                  </LinearGradient>
                </TouchableOpacity>
              )}
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#FFFFFF',
    marginTop: 16,
  },
  refreshButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  refreshingIcon: {
    opacity: 0.5,
  },
  lastUpdatedText: {
    color: '#9CA3AF',
    fontSize: 10,
    marginLeft: 'auto',
  },
  statisticsCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    marginBottom: 12,
  },
  statisticsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  statisticsTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    flex: 1,
  },
  statisticsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 16,
  },
  statItem: {
    flex: 1,
    minWidth: '45%',
    alignItems: 'center',
    padding: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  statIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  statValue: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '800',
    marginBottom: 4,
  },
  statLabel: {
    color: '#9CA3AF',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  approvalRateCard: {
    marginTop: 8,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
  },
  approvalRateHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  approvalRateLabel: {
    color: '#E0E7FF',
    fontSize: 14,
    fontWeight: '600',
  },
  approvalRateValue: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  progressBarContainer: {
    marginTop: 4,
  },
  progressBarBackground: {
    height: 8,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: SKY,
    borderRadius: 4,
  },
  breakdownCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    marginBottom: 12,
  },
  breakdownHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  breakdownTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  breakdownItem: {
    marginBottom: 16,
  },
  breakdownItemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  breakdownItemName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    flex: 1,
  },
  breakdownItemCounts: {
    flexDirection: 'row',
    gap: 6,
  },
  countBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  countText: {
    fontSize: 11,
    fontWeight: '700',
  },
  timelineCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    marginBottom: 12,
  },
  timelineHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  timelineTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  timelineItem: {
    flexDirection: 'row',
    marginBottom: 16,
    paddingLeft: 8,
  },
  timelineDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 12,
    marginTop: 4,
  },
  timelineContent: {
    flex: 1,
    paddingBottom: 16,
    borderLeftWidth: 2,
    borderLeftColor: 'rgba(255,255,255,0.1)',
    paddingLeft: 12,
  },
  timelineItemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  timelineItemName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    flex: 1,
  },
  timelineStatusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  timelineStatusText: {
    fontSize: 11,
    fontWeight: '700',
  },
  timelineDate: {
    color: '#9CA3AF',
    fontSize: 12,
    marginTop: 2,
  },
  timelineRejectionReason: {
    color: '#EF4444',
    fontSize: 12,
    marginTop: 4,
    fontStyle: 'italic',
  },
  metricsCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    marginBottom: 12,
  },
  metricsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  metricsTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  metricItem: {
    flex: 1,
    minWidth: '45%',
    alignItems: 'center',
    padding: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  metricValue: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '800',
    marginBottom: 4,
  },
  metricLabel: {
    color: '#9CA3AF',
    fontSize: 11,
    fontWeight: '600',
    textAlign: 'center',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  section: {
    marginBottom: 20,
  },
  complianceStatusCard: {
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.15,
    shadowRadius: 2,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  complianceStatusGradient: {
    padding: 12,
  },
  complianceStatusHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  complianceStatusBadge: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  complianceStatusInfo: {
    flex: 1,
  },
  complianceStatusTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 2,
  },
  complianceStatusSubtitle: {
    color: '#E0E7FF',
    fontSize: 12,
    fontWeight: '500',
  },
  complianceScoreCompact: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  complianceScoreText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '900',
  },
  complianceActionCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.15,
    shadowRadius: 2,
  },
  complianceActionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  complianceActionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  complianceChecklist: {
    marginBottom: 14,
  },
  complianceChecklistTitle: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  complianceItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 10,
    paddingHorizontal: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 10,
    marginBottom: 6,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  complianceItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 12,
  },
  complianceItemIcon: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  complianceItemText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '500',
    flex: 1,
  },
  complianceActionButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginTop: 8,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  complianceActionButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    gap: 8,
  },
  complianceActionButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
  },
});

