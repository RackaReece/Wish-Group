import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  Image,
  ActivityIndicator,
  SafeAreaView,
  Animated,
  StatusBar,
  Dimensions,
  Modal,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { simpleDocumentUploadService, UploadedDocument } from '../../../src/services/SimpleDocumentUploadService';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;

interface RequiredDocument {
  id: string;
  name: string;
  description: string;
  required: boolean;
  type: 'photo' | 'document' | 'pdf';
  icon: string;
}

export default function ValeterDocuments() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  
  const [documents, setDocuments] = useState<UploadedDocument[]>([]);
  const [uploading, setUploading] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [showSourceModal, setShowSourceModal] = useState(false);
  const [selectedDocumentType, setSelectedDocumentType] = useState<RequiredDocument | null>(null);

  const requiredDocuments: RequiredDocument[] = [
    {
      id: 'profile_photo',
      name: 'Profile Photo',
      description: 'Clear face shot on plain background',
      required: true,
      type: 'photo',
      icon: 'camera'
    },
    {
      id: 'driving_license',
      name: 'Driving Licence',
      description: 'Valid UK driving licence',
      required: true,
      type: 'document',
      icon: 'car'
    },
    {
      id: 'dbs_check',
      name: 'DBS Check',
      description: 'Enhanced DBS certificate',
      required: true,
      type: 'document',
      icon: 'shield-checkmark'
    },
    {
      id: 'public_liability',
      name: 'Public Liability Insurance',
      description: 'Minimum £2M coverage',
      required: true,
      type: 'document',
      icon: 'document-text'
    },
    {
      id: 'vehicle_insurance',
      name: 'Vehicle Insurance',
      description: 'Comprehensive vehicle insurance',
      required: true,
      type: 'document',
      icon: 'car-sport'
    },
    {
      id: 'vehicle_registration',
      name: 'Vehicle Registration',
      description: 'V5C registration document',
      required: true,
      type: 'document',
      icon: 'receipt'
    },
    {
      id: 'id_proof',
      name: 'ID Proof',
      description: 'Passport or national ID',
      required: true,
      type: 'document',
      icon: 'id-card'
    }
  ];

  const headerHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [140, 100],
    extrapolate: 'clamp',
  });

  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 50, 100],
    outputRange: [1, 0.8, 0.6],
    extrapolate: 'clamp',
  });

  useEffect(() => {
    loadDocuments();
  }, []);

  const loadDocuments = async () => {
    try {
      setLoading(true);
      const userDocs = simpleDocumentUploadService.getUserDocuments(user?.id || 'default');
      setDocuments(userDocs);
    } catch (error) {
      console.error('Error loading documents:', error);
      Alert.alert('Error', 'Failed to load documents');
    } finally {
      setLoading(false);
    }
  };

  const handleUploadDocument = (documentType: RequiredDocument) => {
    setSelectedDocumentType(documentType);
    setShowSourceModal(true);
  };

  const handleTakePhoto = async () => {
    if (!selectedDocumentType) return;
    
    try {
      setUploading(selectedDocumentType.id);
      setShowSourceModal(false);
      
      const document = await simpleDocumentUploadService.takePhoto(selectedDocumentType.name);

      if (document) {
        simpleDocumentUploadService.addProgressListener(document.id, (progress) => {
          // Upload progress tracking
        });

        await simpleDocumentUploadService.uploadDocument(document.id);
        await loadDocuments();
        
        Alert.alert('Success', `${selectedDocumentType.name} uploaded successfully!`);
      }
    } catch (error) {
      console.error('Error taking photo:', error);
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to take photo');
    } finally {
      setUploading(null);
      setSelectedDocumentType(null);
    }
  };

  const handlePickDocument = async () => {
    if (!selectedDocumentType) return;
    
    try {
      setUploading(selectedDocumentType.id);
      setShowSourceModal(false);
      
      const document = await simpleDocumentUploadService.pickDocument(selectedDocumentType.name);

      if (document) {
        simpleDocumentUploadService.addProgressListener(document.id, (progress) => {
          // Upload progress tracking
        });

        await simpleDocumentUploadService.uploadDocument(document.id);
        await loadDocuments();
        
        Alert.alert('Success', `${selectedDocumentType.name} uploaded successfully!`);
      }
    } catch (error) {
      console.error('Error picking document:', error);
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to pick document');
    } finally {
      setUploading(null);
      setSelectedDocumentType(null);
    }
  };

  const handleDeleteDocument = async (documentId: string) => {
    Alert.alert(
      'Delete Document',
      'Are you sure you want to delete this document?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await simpleDocumentUploadService.deleteDocument(documentId);
              await loadDocuments();
              Alert.alert('Success', 'Document deleted successfully');
            } catch (error) {
              console.error('Error deleting document:', error);
              Alert.alert('Error', 'Failed to delete document');
            }
          }
        }
      ]
    );
  };

  const getDocumentStatus = (documentType: RequiredDocument) => {
    const doc = documents.find(d => d.name.toLowerCase().includes(documentType.name.toLowerCase()));
    if (!doc) return 'missing';
    if (doc.verificationStatus === 'approved') return 'approved';
    if (doc.verificationStatus === 'rejected') return 'rejected';
    return 'pending';
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return '#10B981';
      case 'rejected': return '#EF4444';
      case 'pending': return '#F59E0B';
      default: return '#6B7280';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'approved': return 'checkmark-circle';
      case 'rejected': return 'close-circle';
      case 'pending': return 'time';
      default: return 'document';
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading documents...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const approvedCount = documents.filter(d => d.verificationStatus === 'approved').length;
  const progressPercentage = (approvedCount / requiredDocuments.length) * 100;

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />

      {/* Animated Header */}
      <Animated.View
        style={[
          styles.header,
          {
            height: headerHeight,
            opacity: headerOpacity,
            paddingTop: insets.top,
          },
        ]}
      >
        <View style={styles.headerContent}>
          <View style={styles.headerTop}>
            <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
              <Ionicons name="arrow-back" size={20} color="#FFFFFF" />
            </TouchableOpacity>
            <Text style={styles.headerTitle}>Documents</Text>
            <View style={styles.placeholder} />
          </View>
        </View>
      </Animated.View>

      <Animated.ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={{ paddingTop: 140, paddingBottom: 20 }}
      >
        {/* Summary */}
        <View style={styles.summaryCard}>
          <View style={styles.summaryHeader}>
            <View style={styles.summaryIconWrapper}>
              <Ionicons name="checkmark-circle" size={28} color={SKY} />
            </View>
            <View style={styles.summaryTextContainer}>
              <Text style={styles.summaryTitle}>Document Verification</Text>
              <Text style={styles.summarySubtitle}>
                Upload all required documents to start accepting jobs
              </Text>
            </View>
          </View>
          
          <View style={styles.progressContainer}>
            <View style={styles.progressHeader}>
              <Text style={styles.progressText}>
                {approvedCount} of {requiredDocuments.length} documents approved
              </Text>
              <Text style={styles.progressPercentage}>{Math.round(progressPercentage)}%</Text>
            </View>
            <View style={styles.progressBar}>
              <View 
                style={[
                  styles.progressFill, 
                  { width: `${progressPercentage}%` }
                ]} 
              />
            </View>
          </View>
        </View>

        {/* Required Documents */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Required Documents</Text>
          
          {requiredDocuments.map((docType) => {
            const status = getDocumentStatus(docType);
            const document = documents.find(d => d.name.toLowerCase().includes(docType.name.toLowerCase()));
            
            return (
              <View key={docType.id} style={styles.documentCard}>
                <LinearGradient
                  colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.04)']}
                  style={styles.documentGradient}
                >
                  <View style={styles.documentHeader}>
                    <View style={styles.documentInfo}>
                      <View style={styles.documentIconWrapper}>
                        <Ionicons name={docType.icon as any} size={24} color={SKY} />
                      </View>
                      <View style={styles.documentDetails}>
                        <Text style={styles.documentName}>{docType.name}</Text>
                        <Text style={styles.documentDescription}>{docType.description}</Text>
                      </View>
                    </View>
                    
                    <View style={[styles.statusBadge, { backgroundColor: getStatusColor(status) + '20' }]}>
                      <Ionicons
                        name={getStatusIcon(status) as any}
                        size={16}
                        color={getStatusColor(status)}
                      />
                    </View>
                  </View>

                  {document && (
                    <View style={styles.uploadedDocument}>
                      <View style={styles.documentPreview}>
                        {document.type === 'photo' ? (
                          <Image source={{ uri: document.uri }} style={styles.previewImage} />
                        ) : (
                          <View style={styles.documentIcon}>
                            <Ionicons name="document" size={24} color={SKY} />
                          </View>
                        )}
                        <View style={styles.documentInfo}>
                          <Text style={styles.fileName}>{document.name}</Text>
                          <Text style={styles.uploadDate}>
                            {document.uploadDate.toLocaleDateString('en-GB')}
                          </Text>
                        </View>
                      </View>
                      
                      <View style={styles.documentActions}>
                        <TouchableOpacity 
                          style={styles.deleteButton}
                          onPress={() => handleDeleteDocument(document.id)}
                        >
                          <Ionicons name="trash" size={16} color="#EF4444" />
                          <Text style={styles.deleteButtonText}>Delete</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  )}

                  {!document && (
                    <TouchableOpacity 
                      style={[styles.uploadButton, { opacity: uploading === docType.id ? 0.6 : 1 }]}
                      onPress={() => handleUploadDocument(docType)}
                      disabled={uploading === docType.id}
                    >
                      {uploading === docType.id ? (
                        <ActivityIndicator size="small" color="#0A1929" />
                      ) : (
                        <>
                          <Ionicons name="cloud-upload" size={18} color="#0A1929" />
                          <Text style={styles.uploadButtonText}>Upload Document</Text>
                        </>
                      )}
                    </TouchableOpacity>
                  )}
                </LinearGradient>
              </View>
            );
          })}
        </View>

        {/* Help Section */}
        <View style={styles.helpSection}>
          <View style={styles.helpHeader}>
            <Ionicons name="help-circle" size={24} color={SKY} />
            <Text style={styles.helpTitle}>Need Help?</Text>
          </View>
          <Text style={styles.helpText}>
            If you're having trouble uploading documents or have questions about requirements, 
            contact our support team.
          </Text>
          
          <TouchableOpacity 
            style={styles.helpButton}
            onPress={() => router.push('/owner/support/help-support')}
          >
            <LinearGradient
              colors={[SKY, '#1E3A8A']}
              style={styles.helpButtonGradient}
            >
              <Ionicons name="chatbubble" size={18} color="#0A1929" />
              <Text style={styles.helpButtonText}>Contact Support</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </Animated.ScrollView>

      {/* Source Selection Modal */}
      <Modal
        visible={showSourceModal}
        transparent={true}
        animationType="slide"
        onRequestClose={() => {
          setShowSourceModal(false);
          setSelectedDocumentType(null);
        }}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <LinearGradient
              colors={['rgba(10, 25, 41, 0.98)', 'rgba(10, 25, 41, 0.95)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Choose Upload Method</Text>
              <TouchableOpacity
                onPress={() => {
                  setShowSourceModal(false);
                  setSelectedDocumentType(null);
                }}
              >
                <Ionicons name="close" size={24} color={SKY} />
              </TouchableOpacity>
            </View>

            <View style={styles.modalBody}>
              <TouchableOpacity
                style={styles.sourceOption}
                onPress={handleTakePhoto}
                activeOpacity={0.7}
              >
                <LinearGradient
                  colors={['rgba(135,206,235,0.2)', 'rgba(135,206,235,0.1)']}
                  style={styles.sourceOptionGradient}
                >
                  <View style={styles.sourceOptionIcon}>
                    <Ionicons name="camera" size={32} color={SKY} />
                  </View>
                  <Text style={styles.sourceOptionTitle}>Take Photo</Text>
                  <Text style={styles.sourceOptionSubtitle}>Use your camera to capture the document</Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.sourceOption}
                onPress={handlePickDocument}
                activeOpacity={0.7}
              >
                <LinearGradient
                  colors={['rgba(139,92,246,0.2)', 'rgba(139,92,246,0.1)']}
                  style={styles.sourceOptionGradient}
                >
                  <View style={styles.sourceOptionIcon}>
                    <Ionicons name="folder-open" size={32} color="#8B5CF6" />
                  </View>
                  <Text style={styles.sourceOptionTitle}>Choose File</Text>
                  <Text style={styles.sourceOptionSubtitle}>Select from your device gallery or files</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#F9FAFB',
    fontSize: 16,
    marginTop: 16,
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    backgroundColor: '#0A1929',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.15)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  headerContent: {
    flex: 1,
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingBottom: 12,
    justifyContent: 'flex-start',
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  headerTitle: {
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '800',
    color: '#FFFFFF',
    flex: 1,
    textAlign: 'center',
  },
  placeholder: {
    width: 40,
  },
  content: {
    flex: 1,
    paddingHorizontal: isSmallScreen ? 12 : 20,
  },
  summaryCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  summaryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 12,
  },
  summaryIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  summaryTextContainer: {
    flex: 1,
  },
  summaryTitle: {
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '800',
    color: '#FFFFFF',
    marginBottom: 4,
  },
  summarySubtitle: {
    fontSize: 13,
    color: SKY,
    opacity: 0.9,
  },
  progressContainer: {
    marginTop: 12,
  },
  progressHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  progressText: {
    color: '#E5E7EB',
    fontSize: 14,
    fontWeight: '600',
  },
  progressPercentage: {
    color: SKY,
    fontSize: 16,
    fontWeight: '800',
  },
  progressBar: {
    height: 8,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#10B981',
    borderRadius: 4,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '800',
    color: '#FFFFFF',
    marginBottom: 16,
  },
  documentCard: {
    marginBottom: 12,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  documentGradient: {
    padding: 16,
  },
  documentHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  documentInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  documentIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  documentDetails: {
    flex: 1,
  },
  documentName: {
    fontSize: 16,
    fontWeight: '800',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  documentDescription: {
    fontSize: 12,
    color: SKY,
    opacity: 0.9,
  },
  statusBadge: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  uploadedDocument: {
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
    paddingTop: 12,
  },
  documentPreview: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  previewImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 12,
  },
  documentIcon: {
    width: 60,
    height: 60,
    borderRadius: 8,
    backgroundColor: 'rgba(135,206,235,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  fileName: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
    marginBottom: 2,
  },
  uploadDate: {
    fontSize: 12,
    color: SKY,
    opacity: 0.8,
  },
  documentActions: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
  },
  deleteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(239,68,68,0.15)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
  },
  deleteButtonText: {
    color: '#EF4444',
    fontSize: 12,
    fontWeight: '700',
  },
  uploadActions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 8,
  },
  uploadButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: SKY,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
  },
  uploadButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '700',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    justifyContent: 'flex-end',
  },
  modalContent: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: 'hidden',
    paddingBottom: 40,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.2)',
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '700',
    color: '#F9FAFB',
  },
  modalBody: {
    padding: 20,
    gap: 16,
  },
  sourceOption: {
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  sourceOptionGradient: {
    padding: 20,
    alignItems: 'center',
  },
  sourceOptionIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  sourceOptionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  sourceOptionSubtitle: {
    fontSize: 14,
    color: '#87CEEB',
    textAlign: 'center',
    opacity: 0.8,
  },
  helpSection: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 20,
    marginTop: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  helpHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  helpTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: '#FFFFFF',
  },
  helpText: {
    fontSize: 14,
    color: SKY,
    marginBottom: 16,
    lineHeight: 20,
    opacity: 0.9,
  },
  helpButton: {
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  helpButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 20,
  },
  helpButtonText: {
    color: '#0A1929',
    fontSize: 14,
    fontWeight: '700',
  },
});
