import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function JobComplete() {
  const { user } = useAuth();
    const params = useLocalSearchParams();
  const jobId = params.jobId as string;

  const [job, setJob] = useState<any | null>(null);
  const [customerName, setCustomerName] = useState('Customer');

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const successScale = useRef(new Animated.Value(0)).current;
  const confettiAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(successScale, {
        toValue: 1,
        tension: 50,
        friction: 7,
        useNativeDriver: true,
      }),
    ]).start();

    // Confetti animation
    Animated.timing(confettiAnim, {
      toValue: 1,
      duration: 2000,
      useNativeDriver: true,
    }).start();

    loadJob();
  }, [jobId]);

  const loadJob = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', jobId)
        .single();

      if (error) throw error;
      setJob(data);
      if (data?.user_id) {
        const profile = await fetchProfileById(data.user_id);
        setCustomerName(profile?.full_name || 'Customer');
      } else {
        setCustomerName('Customer');
      }
    } catch (error) {
      console.error('Error loading job:', error);
    }
  };

  const handleBackToQueue = () => {
    router.replace('/valeter/jobs/queue');
  };

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" backgroundColor={BG} />
      <LinearGradient colors={[BG, '#1E3A8A']} style={StyleSheet.absoluteFill} />

      <AppHeader title="Job Complete!" showBack={false} />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        >
          {/* Success Animation */}
          <Animated.View
            style={[
              styles.successContainer,
              {
                transform: [{ scale: successScale }],
                opacity: confettiAnim,
              },
            ]}
          >
            <View style={styles.successCircle}>
              <Ionicons name="checkmark-done-circle" size={80} color="#10B981" />
            </View>
            <Text style={styles.successTitle}>Well Done!</Text>
            <Text style={styles.successSubtitle}>Job completed successfully</Text>
          </Animated.View>

          {/* Job Summary */}
          {job && (
            <GlassCard style={styles.summaryCard}>
              <View style={styles.summaryHeader}>
                <Ionicons name="receipt-outline" size={24} color={SKY} />
                <Text style={styles.summaryTitle}>Job Summary</Text>
              </View>
              <View style={styles.summaryContent}>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Service</Text>
                  <Text style={styles.summaryValue}>
                    {getServiceDisplayName(job.service_type, job.service_name)}
                  </Text>
                </View>
                <View style={styles.summaryRow}>
                  <Text style={styles.summaryLabel}>Earnings</Text>
                  <Text style={styles.summaryValue}>£{job.price?.toFixed(2) || '0.00'}</Text>
                </View>
                {job.user_id && (
                  <View style={styles.summaryRow}>
                    <Text style={styles.summaryLabel}>Customer</Text>
                    <Text style={styles.summaryValue}>{customerName}</Text>
                  </View>
                )}
              </View>
            </GlassCard>
          )}

          {/* Celebration Card */}
          <GlassCard style={styles.celebrationCard}>
            <View style={styles.celebrationContent}>
              <Ionicons name="trophy" size={48} color="#FBBF24" />
              <Text style={styles.celebrationTitle}>Great Job!</Text>
              <Text style={styles.celebrationText}>
                You've earned points and moved closer to your next achievement
              </Text>
            </View>
          </GlassCard>

          {/* Action Button */}
          <TouchableOpacity
            onPress={handleBackToQueue}
            style={styles.backButton}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={[SKY, '#3B82F6']}
              style={styles.backGradient}
            >
              <Text style={styles.backText}>Back to Job Queue</Text>
              <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
            </LinearGradient>
          </TouchableOpacity>
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: '#0A1929',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.15)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'center',
  },
  headerSpacer: {
    width: 40,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
    alignItems: 'center',
  },
  successContainer: {
    alignItems: 'center',
    marginBottom: 32,
  },
  successCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(16,185,129,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  successTitle: {
    color: '#F9FAFB',
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  successSubtitle: {
    color: SKY,
    fontSize: 16,
  },
  summaryCard: {
    padding: 20,
    marginBottom: 20,
    width: '100%',
  },
  summaryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  summaryTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  summaryContent: {
    gap: 12,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  summaryLabel: {
    color: '#9CA3AF',
    fontSize: 14,
  },
  summaryValue: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  celebrationCard: {
    padding: 24,
    marginBottom: 24,
    width: '100%',
  },
  celebrationContent: {
    alignItems: 'center',
  },
  celebrationTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 12,
    marginBottom: 8,
  },
  celebrationText: {
    color: '#E5E7EB',
    fontSize: 14,
    textAlign: 'center',
  },
  backButton: {
    width: '100%',
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  backGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 8,
  },
  backText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

