import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Region } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';

import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

type JobStatus = 'pending_payment' | 'confirmed' | 'en_route' | 'arrived' | 'in_progress' | 'completed';

export default function JobTracking() {
  const { user } = useAuth();
    const params = useLocalSearchParams();
  const jobIdParam = typeof params.jobId === 'string' ? params.jobId : undefined;
  const jobId = jobIdParam && jobIdParam !== 'undefined' ? jobIdParam : null;

  const [job, setJob] = useState<any | null>(null);
  const [customerName, setCustomerName] = useState('Customer');
  const [status, setStatus] = useState<JobStatus>('pending_payment');
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    // Pulse animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(markerPulse, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    if (!jobId && user?.id) {
      // If no jobId provided, try to load the valeter's active job
      loadActiveJob();
      return;
    }
    if (!jobId) {
      console.warn('[JobTracking] Missing jobId param');
      return;
    }
    loadJob();
    const unsubscribe = subscribeToJob();
    return () => {
      unsubscribe?.();
    };
  }, [jobId, user?.id]);

  const loadActiveJob = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id)
        .in('status', ['confirmed', 'en_route', 'arrived', 'in_progress'])
        .order('request_sent_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;
      if (data) {
        setJob(data);
        setStatus(data.status);
        if (data?.user_id) {
          const profile = await fetchProfileById(data.user_id);
          setCustomerName(profile?.full_name || 'Customer');
        }
        if (data.location_lat && data.location_lng) {
          setRegion({
            latitude: data.location_lat,
            longitude: data.location_lng,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          });
        }
      }
    } catch (error) {
      console.error('Error loading active job:', error);
    }
  };

  const loadJob = async () => {
    if (!jobId) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', jobId)
        .single();

      if (error) throw error;
      setJob(data);
      setStatus(data.status);
      if (data?.user_id) {
        const profile = await fetchProfileById(data.user_id);
        setCustomerName(profile?.full_name || 'Customer');
      } else {
        setCustomerName('Customer');
      }

      if (data.location_lat && data.location_lng) {
        setRegion({
          latitude: data.location_lat,
          longitude: data.location_lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      }
    } catch (error) {
      console.error('Error loading job:', error);
    }
  };

  const subscribeToJob = () => {
    if (!jobId) return undefined;
    const channel = supabase
      .channel(`job-${jobId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${jobId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          setStatus(updated.status);

          if (updated.status === 'completed') {
    router.replace({
      pathname: '/valeter/jobs/complete',
      params: { jobId: jobId ?? '' },
    });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const updateStatus = async (newStatus: JobStatus) => {
    if (!user?.id) return;
    await hapticFeedback('medium');

    try {
      const { error } = await supabase
        .from('bookings')
        .update({ status: newStatus })
        .eq('id', jobId);

      if (error) throw error;
      setStatus(newStatus);
    } catch (error: any) {
      Alert.alert('Error', error?.message || 'Failed to update status');
    }
  };

  const getStatusProgress = (): number => {
    switch (status) {
      case 'pending_payment':
        return 20;
      case 'confirmed':
        return 40;
      case 'en_route':
        return 60;
      case 'arrived':
        return 80;
      case 'in_progress':
        return 90;
      case 'completed':
        return 100;
      default:
        return 0;
    }
  };

  const getStatusMessage = (): string => {
    switch (status) {
      case 'pending_payment':
        return 'Waiting for customer payment';
      case 'confirmed':
        return 'Payment received - Ready to start';
      case 'en_route':
        return 'On the way to location';
      case 'arrived':
        return 'Arrived at location';
      case 'in_progress':
        return 'Service in progress';
      case 'completed':
        return 'Service completed';
      default:
        return 'Tracking job';
    }
  };

  const getNextAction = (): { label: string; action: () => void } | null => {
    switch (status) {
      case 'pending_payment':
        return null; // Wait for payment
      case 'confirmed':
        return {
          label: 'Start Journey',
          action: () => updateStatus('en_route'),
        };
      case 'en_route':
        return {
          label: 'Mark Arrived',
          action: () => updateStatus('arrived'),
        };
      case 'arrived':
        return {
          label: 'Start Service',
          action: () => updateStatus('in_progress'),
        };
      case 'in_progress':
        return {
          label: 'Complete Service',
          action: () => updateStatus('completed'),
        };
      default:
        return null;
    }
  };

  if (!jobId && !job) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <AppHeader title="Job Tracking" accountType="valeter" />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>No active job found.</Text>
          <TouchableOpacity
            style={styles.backToQueueButton}
            onPress={() => router.push('/valeter/jobs/queue')}
          >
            <Text style={styles.backToQueueText}>View Job Queue</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (!job) {
    return (
      <SafeAreaView style={styles.container} edges={['top']}>
        <AppHeader title="Job Tracking" accountType="valeter" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading job...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const nextAction = getNextAction();

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[BG, '#1E3A8A']} style={StyleSheet.absoluteFill} />

      <AppHeader title="Job Tracking" accountType="valeter" />

      <Animated.View
        style={[
          styles.content,
          {
            paddingTop: HEADER_CONTENT_OFFSET,
            opacity: fadeAnim,
          },
        ]}
      >
        {/* Map */}
        <View style={styles.mapContainer}>
          <MapView style={styles.map} region={region} showsUserLocation={true}>
            {job.location_lat && job.location_lng && (
              <Marker
                coordinate={{
                  latitude: job.location_lat,
                  longitude: job.location_lng,
                }}
              >
                <Animated.View
                  style={[
                    styles.markerContainer,
                    {
                      transform: [{ scale: markerPulse }],
                    },
                  ]}
                >
                  <View style={styles.marker}>
                    <Ionicons name="flag" size={20} color="#FFFFFF" />
                  </View>
                  <View style={styles.markerPulse} />
                </Animated.View>
              </Marker>
            )}
          </MapView>
        </View>

        {/* Tracking Card */}
        <View style={styles.cardContainer}>
          <GlassCard style={styles.trackingCard}>
            <View style={styles.trackingHeader}>
              <StatusBadge status={status} size="medium" />
              <Text style={styles.statusMessage}>{getStatusMessage()}</Text>
            </View>

            {/* Progress Ring */}
            <View style={styles.progressContainer}>
              <AnimatedProgress progress={getStatusProgress()} size={120} />
            </View>

            {/* Job Info */}
            <View style={styles.jobInfo}>
              <View style={styles.infoRow}>
                <Ionicons name="water-outline" size={16} color={SKY} />
                <Text style={styles.infoText}>
                  {getServiceDisplayName(job.service_type, job.service_name)}
                </Text>
              </View>
              {job.user_id && (
                <View style={styles.infoRow}>
                  <Ionicons name="person-outline" size={16} color={SKY} />
                  <Text style={styles.infoText}>{customerName}</Text>
                </View>
              )}
              <View style={styles.infoRow}>
                <Ionicons name="location-outline" size={16} color={SKY} />
                <Text style={styles.infoText} numberOfLines={1}>
                  {job.location_address}
                </Text>
              </View>
              <View style={styles.infoRow}>
                <Ionicons name="cash-outline" size={16} color={SKY} />
                <Text style={styles.infoText}>£{job.price?.toFixed(2) || '0.00'}</Text>
              </View>
            </View>

            {/* Action Button */}
            {nextAction && (
              <TouchableOpacity
                onPress={nextAction.action}
                style={styles.actionButton}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={[SKY, '#3B82F6']}
                  style={styles.actionGradient}
                >
                  <Text style={styles.actionText}>{nextAction.label}</Text>
                  <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                </LinearGradient>
              </TouchableOpacity>
            )}
          </GlassCard>
        </View>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  content: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: SKY,
    fontSize: 16,
    marginTop: 12,
    textAlign: 'center',
  },
  backToQueueButton: {
    marginTop: 20,
    paddingVertical: 12,
    paddingHorizontal: 24,
    backgroundColor: SKY,
    borderRadius: 12,
  },
  backToQueueText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: '700',
  },
  mapContainer: {
    flex: 1,
  },
  map: {
    flex: 1,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  marker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#EF4444',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  markerPulse: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: '#EF4444',
    opacity: 0.3,
  },
  cardContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 20,
    paddingBottom: 40,
  },
  trackingCard: {
    padding: 20,
  },
  trackingHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  statusMessage: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginTop: 12,
    textAlign: 'center',
  },
  progressContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  jobInfo: {
    gap: 12,
    marginBottom: 20,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  infoText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
  },
  actionButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  actionGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 8,
  },
  actionText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});

