import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { fetchProfilesByIds } from '../../../src/utils/customerProfiles';
import { fetchRadiusPreference } from '../../../src/utils/radiusPreference';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';

import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

interface JobRequest {
  id: string;
  service_type: string;
  service_name?: string;
  price: number;
  location_address: string;
  location_lat: number;
  location_lng: number;
  scheduled_at?: string;
  request_sent_at: string;
  customer_name?: string;
  distance?: number;
  assignedToValeter?: boolean;
}

export default function JobsQueue() {
  const { user } = useAuth();
    const [jobs, setJobs] = useState<JobRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();

    loadJobs();
    subscribeToJobs();
  }, [user?.id]);

  const loadJobs = async () => {
    if (!user?.id) return;
    try {
      // Load pending job requests (not yet assigned to any valeter)
      let query = supabase
        .from('bookings')
        .select(`
          id,
          service_type,
          service_name,
          price,
          location_address,
          location_lat,
          location_lng,
          scheduled_at,
          request_sent_at,
          status,
          user_id,
          valeter_id
        `)
        .order('request_sent_at', { ascending: false })
        .limit(40);

      if (user?.id) {
        query = query.or(
          `and(status.eq.pending_valeter_acceptance,valeter_id.is.null),and(status.eq.pending_valeter_acceptance,valeter_id.eq.${user.id})`
        );
      } else {
        query = query.eq('status', 'pending_valeter_acceptance').is('valeter_id', null);
      }

      const { data, error } = await query;

      if (error) throw error;

      const customerIds = Array.from(
        new Set(
          (data || [])
            .map((job: any) => job.user_id)
            .filter((id: string | null) => Boolean(id))
        )
      ) as string[];

      const customerProfiles = await fetchProfilesByIds(customerIds);

      // Get valeter location for distance calculation
      const { data: presenceData } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', user.id)
        .single();

      const valeterLat = presenceData?.last_lat;
      const valeterLng = presenceData?.last_lng;

      const radiusResult = await fetchRadiusPreference(user.id);
      const workingRadiusMiles = radiusResult.value ?? 10;

      const jobsWithDistance: JobRequest[] = (data || [])
        .map((job: any) => {
        const assignedToValeter = Boolean(user?.id && job.valeter_id === user.id);
        let distance = null;
        if (valeterLat && valeterLng && job.location_lat && job.location_lng) {
          distance = calculateDistance(
            valeterLat,
            valeterLng,
            job.location_lat,
            job.location_lng
          );
        }

        return {
          id: job.id,
          service_type: job.service_type,
          service_name: job.service_name,
          price: job.price,
          location_address: job.location_address,
          location_lat: job.location_lat,
          location_lng: job.location_lng,
          scheduled_at: job.scheduled_at,
          request_sent_at: job.request_sent_at,
          customer_name: customerProfiles.get(job.user_id)?.full_name || 'Customer',
          distance: distance ? Math.round(distance * 10) / 10 : null,
          assignedToValeter,
        };
        })
        .filter((job) => {
          if (job.assignedToValeter) {
            return true;
          }
          if (job.distance == null) return true;
          return job.distance <= workingRadiusMiles;
        });

      setJobs(jobsWithDistance);
    } catch (error) {
      console.error('Error loading jobs:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 3959; // Earth's radius in miles
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const subscribeToJobs = () => {
    const channel = supabase
      .channel('job-requests')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: 'status=eq.pending_valeter_acceptance',
        },
        () => {
          loadJobs();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadJobs();
  };

  const handleJobPress = async (jobId: string) => {
    await hapticFeedback('light');
    router.push({
      pathname: '/valeter/jobs/accept',
      params: { jobId },
    });
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[BG, '#1E3A8A']} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Job Queue"
        rightAction={
          <TouchableOpacity onPress={handleRefresh} style={styles.refreshButton}>
            <Ionicons name="refresh" size={20} color={SKY} />
          </TouchableOpacity>
        }
      />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
          },
        ]}
      >
        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={SKY} />
            <Text style={styles.loadingText}>Loading jobs...</Text>
          </View>
        ) : jobs.length === 0 ? (
          <ScrollView
            contentContainerStyle={styles.emptyContainer}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={SKY} />
            }
          >
            <GlassCard style={styles.emptyCard}>
              <View style={styles.emptyContent}>
                <Ionicons name="briefcase-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
                <Text style={styles.emptyTitle}>No Jobs Available</Text>
                <Text style={styles.emptyText}>
                  New job requests will appear here when customers book services
                </Text>
              </View>
            </GlassCard>
          </ScrollView>
        ) : (
          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
            refreshControl={
              <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={SKY} />
            }
          >
            {jobs.map((job, index) => (
              <Animated.View
                key={job.id}
                style={{
                  opacity: fadeAnim,
                  transform: [
                    {
                      translateY: slideAnim.interpolate({
                        inputRange: [0, 50],
                        outputRange: [0, 50 * (index + 1)],
                      }),
                    },
                  ],
                }}
              >
                <GlassCard
                  onPress={() => handleJobPress(job.id)}
                  style={styles.jobCard}
                  borderColor="rgba(135,206,235,0.3)"
                >
                  <View style={styles.jobHeader}>
                    <View style={styles.jobTitleRow}>
                      <Ionicons name="water" size={24} color={SKY} />
                      <Text style={styles.jobTitle}>
                        {getServiceDisplayName(job.service_type, job.service_name)}
                      </Text>
                    </View>
                    <Text style={styles.jobPrice}>£{job.price?.toFixed(2) || '0.00'}</Text>
                  </View>

                  <View style={styles.jobDetails}>
                    <View style={styles.jobDetailRow}>
                      <Ionicons name="location" size={16} color={SKY} />
                      <Text style={styles.jobDetailText} numberOfLines={2}>
                        {job.location_address}
                      </Text>
                    </View>
                    {job.distance !== null && (
                      <View style={styles.jobDetailRow}>
                        <Ionicons name="navigate" size={16} color={SKY} />
                        <Text style={styles.jobDetailText}>{job.distance} miles away</Text>
                      </View>
                    )}
                    {job.customer_name && (
                      <View style={styles.jobDetailRow}>
                        <Ionicons name="person" size={16} color={SKY} />
                        <Text style={styles.jobDetailText}>{job.customer_name}</Text>
                      </View>
                    )}
                  </View>

                  <View style={styles.jobFooter}>
                    <StatusBadge status="pending" size="small" />
                    <TouchableOpacity style={styles.viewButton}>
                      <Text style={styles.viewButtonText}>View Details</Text>
                      <Ionicons name="chevron-forward" size={16} color={SKY} />
                    </TouchableOpacity>
                  </View>
                </GlassCard>
              </Animated.View>
            ))}
          </ScrollView>
        )}
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  refreshButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    padding: 20,
  },
  emptyCard: {
    padding: 40,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  jobCard: {
    padding: 20,
    marginBottom: 16,
  },
  jobHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
  },
  jobTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
  },
  jobTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    flex: 1,
  },
  jobPrice: {
    color: SKY,
    fontSize: 20,
    fontWeight: 'bold',
  },
  jobDetails: {
    gap: 8,
    marginBottom: 16,
  },
  jobDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  jobDetailText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
  },
  jobFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  viewButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  viewButtonText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
});

