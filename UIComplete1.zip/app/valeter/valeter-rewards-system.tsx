import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import { colors } from '../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function ValeterRewardsSystem() {
  const { user } = useAuth();
    const [points] = useState(850);

  const rewards = [
    { id: '1', title: 'Bonus Payment', points: 500, icon: 'cash', available: points >= 500 },
    { id: '2', title: 'Premium Tools', points: 1000, icon: 'construct', available: points >= 1000 },
    { id: '3', title: 'Free Training', points: 750, icon: 'school', available: points >= 750 },
    { id: '4', title: 'Extra Commission', points: 300, icon: 'trending-up', available: points >= 300 },
    { id: '5', title: 'Equipment Upgrade', points: 1500, icon: 'hardware-chip', available: points >= 1500 },
  ];

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[BG, colors.headerBg]} style={StyleSheet.absoluteFill} />

      <AppHeader title="Rewards" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Points Card */}
        <View style={styles.pointsCard}>
          <LinearGradient colors={['rgba(135,206,235,0.2)', 'rgba(30,58,138,0.25)']} style={styles.pointsGradient}>
            <View style={styles.pointsIconWrapper}>
              <Ionicons name="gift" size={32} color={SKY} />
            </View>
            <Text style={styles.pointsLabel}>Your Points</Text>
            <Text style={styles.pointsValue}>{points.toLocaleString()}</Text>
            <Text style={styles.pointsSubtext}>Keep completing jobs to earn more!</Text>
          </LinearGradient>
        </View>

        {/* Rewards List */}
        <View style={styles.rewardsSection}>
          <Text style={styles.sectionTitle}>Available Rewards</Text>
          {rewards.map((reward) => (
            <TouchableOpacity
              key={reward.id}
              style={[styles.rewardCard, !reward.available && styles.rewardCardDisabled]}
              disabled={!reward.available}
            >
              <View style={styles.rewardIconWrapper}>
                <Ionicons name={reward.icon as any} size={24} color={reward.available ? SKY : '#6B7280'} />
              </View>
              <View style={styles.rewardContent}>
                <Text style={[styles.rewardTitle, !reward.available && styles.rewardTitleDisabled]}>
                  {reward.title}
                </Text>
                <Text style={styles.rewardPoints}>{reward.points} points</Text>
              </View>
              {reward.available ? (
                <Ionicons name="checkmark-circle" size={24} color="#10B981" />
              ) : (
                <Ionicons name="lock-closed" size={24} color="#6B7280" />
              )}
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 12 : 20 },
  pointsCard: {
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 24,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  pointsGradient: {
    padding: 24,
    alignItems: 'center',
  },
  pointsIconWrapper: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  pointsLabel: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  pointsValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 36 : 42,
    fontWeight: '800',
    marginBottom: 4,
  },
  pointsSubtext: {
    color: '#87CEEB',
    fontSize: 13,
    opacity: 0.8,
  },
  rewardsSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  rewardCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  rewardCardDisabled: {
    opacity: 0.5,
  },
  rewardIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  rewardContent: {
    flex: 1,
  },
  rewardTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 17,
    fontWeight: '700',
    marginBottom: 4,
  },
  rewardTitleDisabled: {
    color: '#6B7280',
  },
  rewardPoints: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '600',
  },
});



