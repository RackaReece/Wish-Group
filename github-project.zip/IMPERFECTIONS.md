# Wish a Wash — UI & Backend Imperfections Audit

Comprehensive audit of imperfections, technical debt, and improvement opportunities across the app. Last updated: Feb 4, 2025.

---

## Critical — Security & Credentials

### 1. Hardcoded Demo Credentials (login.tsx)
- **Location:** `app/auth/login.tsx` lines 69–77
- **Issue:** Demo email/password are pre-filled in `useEffect` based on user type. Real credentials are exposed in source code.
- **Impact:** Credential leakage in production builds; security vulnerability.
- **Fix:** Remove pre-filled credentials entirely before production release.

### 2. Hardcoded Supabase Keys (supabase.ts)
- **Location:** `src/lib/supabase.ts` lines 5–6
- **Issue:** Supabase URL and anon key have hardcoded fallbacks. Keys differ from `env.example` (different Supabase project).
- **Impact:** Risk of using wrong project in production; keys visible in source.
- **Fix:** Remove fallbacks or use env-only; ensure `.env` is in `.gitignore` and never committed.

### 3. ~~env.example Contains Real Keys~~ ✅ FIXED
- **Location:** `env.example`
- **Fix applied:** Replaced real Supabase URL/keys with placeholders `your_supabase_url_here` and `your_supabase_anon_key_here`.

---

## High — Backend & Data

### 4. Simulated / Mock Services (See MOCK_DATA_REPLACEMENT.md)
- **FileUploadService:** Simulated upload progress and fake metadata.
- **DocumentUploadService:** Simulated camera, upload progress, and document picker.
- **PriorityWashService:** Simulated demand and wait times.
- **WashCompletionService:** In-memory completions/ratings; not persisted.
- **ValeterVerificationService:** Simulated verification based on email domain.
- **PerformanceService:** Placeholder optimization (returns `true` without real work).
- **ChatService (utils):** In-memory conversations; no Supabase persistence.

### 5. Placeholder Backend Integrations
- **Business team invite:** `app/business/team/invite.tsx` — “For now, just UI placeholder.”
- **Business team requests:** `app/business/team/requests.tsx` — TODO: fetch from `valeter_requests`, approve/reject.
- **Delete account:** `app/business/settings.tsx`, `app/valeter/settings/account.tsx`, `app/valeter/profile/valeter-profile.tsx` — “Placeholder: wire to real delete.”
- **Data export:** `app/valeter/profile/valeter-profile.tsx` — “Placeholder: wire to export/data request.”
- **Analytics:** `app/business/analytics.tsx` — No real data fetch for revenue/bookings.
- **Wash completion:** `WashCompletionUpload.tsx` — Simulated AI analysis, completion upload, rating submission.

### 6. TODO Items in Codebase
- `ComprehensiveValeterDashboard.tsx`: `distance: 0 // TODO: Calculate distance`, `status: 'washing' // TODO: Get actual status`
- `valeter-analytics.tsx`: `onlineHours: 0 // TODO: Calculate from presence data`
- `valeter-wash-history.tsx`: `averageRating: 0 // TODO: Calculate from reviews`
- `valeter-detail-profile.tsx`: `// TODO: Load actual valeter profile from Supabase`
- `DocumentUploadService.ts`: `// TODO: Implement actual file picker using expo-document-picker`

### 7. Typos in Role Checks (login.tsx)
- **Location:** `app/auth/login.tsx` lines 157, 165
- **Issue:** `organistion` (typo for organization), `valetor` (typo for valeter). Kept as fallbacks for legacy DB data.
- **Recommendation:** Add comment explaining legacy compatibility; consider fixing DB data and removing typos.

### 8. ~~Filename Typo: Valeterstatsservice.ts~~ ✅ FIXED
- **Location:** `src/services/ValeterStatsService.ts`
- **Fix applied:** Renamed from `Valeterstatsservice.ts` to `ValeterStatsService.ts`; updated all imports.

---

## High — UI / Frontend

### 9. Inconsistent Theme/Style Usage (from ERRORS_FIX.md)
- `businessTheme` vs `theme` confusion in some screens.
- StyleSheet references to `theme`/`businessTheme` inside components where theme is not available at top level.
- Fix pattern: Use top-level constants like `SKY`, `BUSINESS_PRIMARY` in StyleSheet.create().

### 10. ~~Duplicate StatusBadge Components~~ ✅ FIXED
- **Locations:** `app/components/statusBadge.tsx` (simple) vs `src/components/booking/StatusBadge.tsx` (feature-rich)
- **Fix applied:** Removed `app/components/statusBadge.tsx`; all usages already use `src/components/booking/StatusBadge.tsx`.

### 11. Excessive `as any` and TypeScript Bypasses
- **Count:** 100+ uses of `as any`, `catch (e: any)`, `(x as any)?.prop` across the codebase.
- **Impact:** Weak type safety; harder refactoring and maintenance.
- **Fix:** Add proper types for Supabase responses, router params, and error objects.

### 12. Console Logging in Production Code
- **Count:** 60+ `console.log`, `console.warn`, `console.error` in app source (excluding node_modules).
- **Impact:** Clutter in production logs; potential info leakage.
- **Fix:** Use a logging utility (e.g. `__DEV__ ? console.log : noop`) or a proper logging service.

### 13. Lack of Accessibility Props
- **Issue:** No `accessibilityLabel`, `accessibilityRole`, or `accessibilityHint` in app components.
- **Impact:** Poor screen reader support; accessibility compliance risk.
- **Fix:** Add accessibility props to interactive elements (buttons, inputs, links).
- **Progress:** Added to NavigationTab (all tab buttons, profile modal), LoadingView (loading state), and login (email, password, sign-in button). Roll out to remaining screens.

### 14. Inconsistent placeholderTextColor
- **Issue:** Hardcoded values like `rgba(249,250,251,0.5)`, `rgba(255,255,255,0.4)`, `#64748B` across screens.
- **Fix:** Use `getTextColors(theme).placeholder` from `src/constants/themeColors` for screens that use theme (light: `rgba(249,250,251,0.5)`, dark: `rgba(255,255,255,0.4)`). Migrate screens gradually.

### 15. Mixed Router Casting
- **Issue:** Frequent `router.push('/path' as any)` due to expo-router typing.
- **Fix:** Define typed routes or use `Href` from expo-router correctly.

---

## Medium — UX & Consistency

### 16. Location Card Placeholders
- **Location:** `app/business/locations.tsx`
- **Issue:** “Add cover photo” and “Photo” placeholders with no upload flow wired.
- **Fix:** Wire to real image upload or hide until implemented.

### 17. ~~Chat Screen Avatar Placeholders~~ ✅ FIXED
- **Location:** `app/chat-screen.tsx`
- **Fix applied:** Shared `Avatar` component from `src/components/shared/Avatar.tsx` used for header and message avatars; supports imageUri and placeholder.

### 18. ~~Profile Picture Placeholders~~ ✅ FIXED
- **Locations:** `valeter-profile.tsx`, `valeter-detail-profile.tsx`, `PowerfulDriverDashboard.tsx`, `AppHeader.tsx`
- **Issue:** Multiple styles of profile placeholders; some show “Photo” text.
- **Fix:** Standardize into a single `Avatar` or `ProfilePicture` component.

### 19. Database Schema Migration Alerts
- **Location:** `app/valeter/settings/distance-covering.tsx`
- **Issue:** Users see raw SQL in Alert when columns are missing.
- **Fix:** Provide a migration script or docs link; avoid exposing SQL to end users.

### 20. Loading & Error States
- **Issue:** Some screens lack loading indicators during fetches; others use inconsistent patterns. Fetch failures often showed only an alert.
- **Fix:** Use shared `LoadingView` / `SkeletonLoader` consistently. Use `ErrorView` (`src/components/shared/ErrorView.tsx`) with `onRetry` for failed loads — applied on valeter profile and business dashboard.

---

## Medium — Code Quality

### 21. Duplicate Logic
- `money` formatter, `coerceDetailingMenu`, `coerceTierPricing`, `isMissingTableErr` duplicated in:
  - `app/business/locations/[id].tsx`
  - `app/valeter/profile/valeter-profile.tsx`
  - `app/valeter/settings/services-pricing.tsx`
- **Fix:** Extract to shared utils (e.g. `src/utils/formatters.ts`, `src/utils/dbHelpers.ts`).

### 22. env.example Supabase Mismatch
- **Issue:** `env.example` points to `cbtnhqbfmdavtcbjqepv.supabase.co`; `supabase.ts` fallback uses `rmhlnfqgjipeawaddwor.supabase.co`.
- **Fix:** Align on one Supabase project and ensure env vars are the single source of truth.

### 23. ESLint / Prettier
- **Issue:** No eslint/prettier in devDependencies despite lint scripts in package.json.
- **Fix:** Add `eslint`, `prettier`, and config; run in CI.

---

## Low — Polish

### 24. Asset Naming
- **Issue:** `Onboarding.mp4` vs `onboarding-intro.mp4` — inconsistent casing.
- **Fix:** Use consistent kebab-case or camelCase.

### 25. Wishwizz.png in App Root
- **Location:** `app/wishwizz.png`
- **Issue:** Image in app folder; unclear if used or legacy.
- **Fix:** Move to assets if used; remove if unused.

### 26. ~~Tab Bar Naming~~ ✅ FIXED
- **Location:** `NavigationTab.tsx` — Valeter tab renamed from “Hours” to “Schedule”; Profile tab now opens options modal when tapped (valeter gets Valeter Profile / Settings, business gets Business Profile / Settings).

---

## Summary of Recommended Fixes (Priority Order)

| Priority | Issue | Action |
|----------|-------|--------|
| P0 | Hardcoded demo credentials | Remove immediately |
| P0 | Hardcoded Supabase keys | Use env only; remove fallbacks |
| P1 | Mock/simulated services | Replace with real Supabase/API (see MOCK_DATA_REPLACEMENT.md) |
| P1 | Placeholder delete/invite/export | Wire to backend |
| P1 | Valeterstatsservice filename | Rename to ValeterStatsService.ts |
| P2 | Duplicate StatusBadge | Remove or consolidate |
| P2 | Accessibility props | Add to interactive elements |
| P2 | Console logging | Use __DEV__ or logger |
| P2 | Duplicate formatter logic | Extract to shared utils |
| P3 | TypeScript `any` usage | Gradual typing improvement |
| P3 | env.example keys | Use placeholders |
| P3 | ESLint/Prettier | Add and run in CI |

---

## References

- **ERRORS_FIX.md** — Known runtime errors and style fixes
- **MOCK_DATA_REPLACEMENT.md** — Full list of mock data and simulated logic to replace

this should explain everything in depth for you bro