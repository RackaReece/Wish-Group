import MapKit
import CoreLocation
import ExpoModulesCore

public class ExpoMapKitDirectionsModule: Module {
  public func definition() -> ModuleDefinition {
    Name("ExpoMapKitDirections")

    AsyncFunction("getDirections") { (fromLat: Double, fromLng: Double, toLat: Double, toLng: Double) -> [String: Any]? in
      let source = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: fromLat, longitude: fromLng)))
      let destination = MKMapItem(placemark: MKPlacemark(coordinate: CLLocationCoordinate2D(latitude: toLat, longitude: toLng)))
      let request = MKDirections.Request()
      request.source = source
      request.destination = destination
      request.transportType = .automobile
      request.requestsAlternateRoutes = false

      let directions = MKDirections(request: request)
      return try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<[String: Any]?, Error>) in
        directions.calculate { response, error in
          if let error = error {
            continuation.resume(throwing: error)
            return
          }
          guard let route = response?.routes.first else {
            continuation.resume(returning: nil)
            return
          }
          let polyline = Self.decodePolyline(route.polyline)
          var stepEndIndex = 0
          var steps: [[String: Any]] = []
          for step in route.steps {
            stepEndIndex += Self.pointCount(step.polyline)
            steps.append([
              "instruction": step.instructions ?? "",
              "distanceMeters": step.distance,
              "polylineEndIndex": stepEndIndex - 1
            ])
          }
          let result: [String: Any] = [
            "polyline": polyline,
            "steps": steps,
            "distanceMeters": route.distance,
            "expectedTravelTimeSeconds": route.expectedTravelTime
          ]
          continuation.resume(returning: result)
        }
      }
    }
  }

  private static func pointCount(_ polyline: MKPolyline) -> Int {
    return polyline.pointCount
  }

  private static func decodePolyline(_ polyline: MKPolyline) -> [[String: Double]] {
    let count = polyline.pointCount
    guard count > 0 else { return [] }
    let coords = UnsafeMutablePointer<CLLocationCoordinate2D>.allocate(capacity: count)
    defer { coords.deallocate() }
    polyline.getCoordinates(coords, range: NSRange(location: 0, length: count))
    var result: [[String: Double]] = []
    for i in 0..<count {
      let c = coords[i]
      result.append(["latitude": c.latitude, "longitude": c.longitude])
    }
    return result
  }
}
