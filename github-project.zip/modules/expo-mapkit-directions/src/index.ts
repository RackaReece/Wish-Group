import { NativeModulesProxy, Platform } from 'expo-modules-core';

const { ExpoMapKitDirections } = NativeModulesProxy;

export interface RouteStep {
  instruction: string;
  distanceMeters: number;
  /** Index into polyline of the last point of this step (for distance-to-next-step). */
  polylineEndIndex: number;
}

export interface MapKitRouteResult {
  polyline: { latitude: number; longitude: number }[];
  steps: RouteStep[];
  distanceMeters: number;
  expectedTravelTimeSeconds: number;
}

export async function getDirections(
  fromLatitude: number,
  fromLongitude: number,
  toLatitude: number,
  toLongitude: number
): Promise<MapKitRouteResult | null> {
  if (Platform.OS !== 'ios' || !ExpoMapKitDirections?.getDirections) {
    return null;
  }
  return ExpoMapKitDirections.getDirections(
    fromLatitude,
    fromLongitude,
    toLatitude,
    toLongitude
  );
}

export function isAvailable(): boolean {
  return Platform.OS === 'ios' && typeof ExpoMapKitDirections?.getDirections === 'function';
}
