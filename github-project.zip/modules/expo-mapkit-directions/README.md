# expo-mapkit-directions

iOS-only Expo native module that uses Apple MapKit **MKDirections** to fetch driving routes and turn-by-turn steps. Used for in-app navigation (no external Apple Maps).

## Requirements

- iOS 15.1+
- **Expo prebuild**: Run `npx expo prebuild` (or use EAS Build) so the native iOS code is included. The module is not used in Expo Go.

## API

- `getDirections(fromLat, fromLng, toLat, toLng)` → `Promise<MapKitRouteResult | null>`
  - Returns polyline coordinates, steps (instruction + distance + polylineEndIndex), total distance and expected travel time.
- `isAvailable()` → `boolean` (true on iOS when the native module is linked).

## Usage

See `app/valeter/navigation.tsx`: it requests a route with `getDirections`, draws the polyline on `react-native-maps`, tracks location with `expo-location`, and shows a turn-by-turn card with distance to the next step.
