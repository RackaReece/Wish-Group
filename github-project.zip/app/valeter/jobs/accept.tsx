import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  StatusBar,
  Alert,
  Image,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import MapView, { Marker, Region } from 'react-native-maps';
import { VALETER_MAP_ICON } from '../../../src/constants/mapIcons';
import { useGlobalTheme } from '../../../src/components/shared/GlobalThemeContext';
import { DARK_MAP_STYLE } from '../../../src/constants/mapStyles';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import ValeterJobCard from '../../../src/components/valeter/ValeterJobCard';
import { CustomerProfileRow, fetchProfileById } from '../../../src/utils/customerProfiles';
import AppHeader from '../../../src/components/shared/AppHeader';
import LoadingView from '../../../src/components/shared/LoadingView';
import ErrorView from '../../../src/components/shared/ErrorView';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { colors } from '../../../src/constants/colors';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { getIconColors } from '../../../src/constants/themeColors';
import { getAccountTheme } from '../../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

export default function JobAccept() {
  const insets = useSafeAreaInsets();
  const { mode } = useGlobalTheme();
  const theme = getAccountTheme('valeter', mode);
  const pageBg = theme.background;
  const primaryColor = theme.primary;
  const isLight = theme.mode === 'light';
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const jobId = params.jobId as string;

  const [job, setJob] = useState<any | null>(null);
  const [customerProfile, setCustomerProfile] = useState<CustomerProfileRow | null>(null);
  const [loading, setLoading] = useState(true);
  const [accepting, setAccepting] = useState(false);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const cardAnim = useRef(new Animated.Value(0)).current;
  const markerPulseRef = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulseRef, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulseRef, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, [markerPulseRef]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(cardAnim, {
        toValue: 1,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();

    loadJob();
  }, [jobId]);

  const loadJob = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', jobId)
        .single();

      if (error) throw error;
      setJob(data);
      if (data?.user_id) {
        const profile = await fetchProfileById(data.user_id);
        setCustomerProfile(profile);
      } else {
        setCustomerProfile(null);
      }

      if (data.location_lat && data.location_lng) {
        setRegion({
          latitude: data.location_lat,
          longitude: data.location_lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      }
    } catch (error) {
      console.error('Error loading job:', error);
      setJob(null);
    } finally {
      setLoading(false);
    }
  };

  const handleAccept = async () => {
    if (!user?.id || !job) return;
    if (accepting) return;

    setAccepting(true);
    await hapticFeedback('medium');

    try {
      // Update booking to assign valeter and change status
      const { error: updateError } = await supabase
        .from('bookings')
        .update({
          valeter_id: user.id,
          status: 'pending_payment',
          valeter_accepted_at: new Date().toISOString(),
        })
        .eq('id', jobId);

      if (updateError) throw updateError;

      // Navigate to trips page
      router.replace({
        pathname: '/valeter/trips',
        params: { jobId },
      });
    } catch (error: any) {
      Alert.alert('Error', error?.message || 'Failed to accept job');
      setAccepting(false);
    }
  };

  const handleDecline = async () => {
    await hapticFeedback('light');
    Alert.alert(
      'Decline job request?',
      'Are you sure you want to decline this job? You won’t be assigned to this booking.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Decline',
          style: 'destructive',
          onPress: async () => {
            if (!job?.id) {
              router.back();
              return;
            }
            try {
              const { error } = await supabase
                .from('bookings')
                .update({ status: 'cancelled', valeter_id: null })
                .eq('id', job.id);
              if (error) throw error;
            } catch (_) {}
            router.back();
          },
        },
      ]
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: pageBg[0] }]} edges={[]}>
        <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <LoadingView style={styles.loadingContainer} />
      </SafeAreaView>
    );
  }

  if (!job) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: pageBg[0] }]} edges={[]}>
        <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <ErrorView message="Failed to load job details" onRetry={loadJob} style={styles.loadingContainer} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: pageBg[0] }]} edges={[]}>
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} backgroundColor="transparent" translucent />
      <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      {/* Full-screen map (customer-app style) */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          mapType="standard"
          customMapStyle={mode === 'dark' ? DARK_MAP_STYLE : undefined}
          userInterfaceStyle={isLight ? 'light' : 'dark'}
          mapPadding={{ top: 0, bottom: 0, left: 0, right: 0 }}
        >
          {job.location_lat && job.location_lng && (
            <Marker
              coordinate={{
                latitude: job.location_lat,
                longitude: job.location_lng,
              }}
              anchor={{ x: 0.5, y: 0.5 }}
              tracksViewChanges={false}
            >
              <Animated.View style={[styles.marker, { transform: [{ scale: markerPulseRef }] }]}>
                <Image
                  source={VALETER_MAP_ICON}
                  style={styles.carMarkerImage}
                  resizeMode="contain"
                />
              </Animated.View>
            </Marker>
          )}
        </MapView>
      </View>

      <View style={styles.headerOverlay}>
        <AppHeader title="Job request" subtitle="Accept or decline" showBack onBack={() => router.back()} accountType="valeter" />
      </View>

      {/* Floating card at bottom (same UI as customer app tracking/waiting) */}
      <Animated.View
        style={[
          styles.cardContainer,
          {
            opacity: fadeAnim,
            transform: [{ scale: cardAnim }],
            bottom: TAB_BAR_TOTAL_HEIGHT + (insets?.bottom ?? 0) + 12,
          },
        ]}
      >
        <ValeterJobCard
          job={{
            id: job.id,
            service_type: job.service_type,
            service_name: job.service_name,
            price: job.price ?? 0,
            location_address: job.location_address ?? '',
            request_sent_at: job.request_sent_at ?? new Date().toISOString(),
            customer_name: customerProfile?.full_name ?? 'Customer',
            formatted_location: job.location_address ?? undefined,
          }}
          variant="accept"
          theme={theme}
          primaryColor={primaryColor}
          isLight={isLight}
          onPrimary={handleAccept}
          onSecondary={handleDecline}
          primaryLoading={accepting}
          showStatusStrip={false}
        />
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.BG,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    backgroundColor: colors.BG,
    borderBottomWidth: 0,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontFamily: 'Rubik_600SemiBold',
    fontWeight: 'bold',
    flex: 1,
    textAlign: 'center',
  },
  headerSpacer: {
    width: 40,
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 100,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: colors.SKY,
    fontSize: 16,
  },
  mapContainer: {
    flex: 1,
  },
  map: {
    flex: 1,
  },
  marker: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  carMarkerImage: {
    width: 28,
    height: 28,
  },
  cardContainer: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 100,
  },
  detailsCard: {
    padding: 16,
    marginBottom: 12,
  },
  detailsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 12,
  },
  detailsTitleContainer: {
    flex: 1,
  },
  detailsTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  detailsPrice: {
    color: colors.SKY,
    fontSize: 24,
    fontWeight: 'bold',
  },
  detailsContent: {
    gap: 10,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  detailText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
  },
  actionsContainer: {
    gap: 10,
  },
  acceptButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  acceptGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 32,
    gap: 8,
  },
  buttonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  declineButton: {
    paddingVertical: 18,
    alignItems: 'center',
    borderRadius: 16,
    borderWidth: 0,
  },
  declineText: {
    color: '#EF4444',
    fontSize: 16,
    fontWeight: '600',
  },
});

