import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  Image,
  Platform,
  ScrollView,
  Alert,
  StatusBar,
  RefreshControl,
  FlatList,
  NativeSyntheticEvent,
  NativeScrollEvent,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { fetchProfilesByIds } from '../../../src/utils/customerProfiles';
import { fetchRadiusPreference } from '../../../src/utils/radiusPreference';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import LoadingView from '../../../src/components/shared/LoadingView';
import ValeterJobCard from '../../../src/components/valeter/ValeterJobCard';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { useGlobalTheme } from '../../../src/components/shared/GlobalThemeContext';
import { colors } from '../../../src/constants/colors';
import { getIconColors } from '../../../src/constants/themeColors';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import * as Location from 'expo-location';
import { fetchAreaStats, getPeakUrgencyText, DEFAULT_STATS, type AreaStats } from '../../../src/utils/areaStats';
import MapView, { Marker, Region } from 'react-native-maps';
import { DARK_MAP_STYLE, DEFAULT_MAP_ZOOM_DELTA } from '../../../src/constants/mapStyles';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { VALETER_MAP_ICON } from '../../../src/constants/mapIcons';

const { width, height } = Dimensions.get('window');
const CARD_PADDING = 24;
const cardWidth = width - CARD_PADDING;

interface JobRequest {
  id: string;
  service_type: string;
  service_name?: string;
  price: number;
  location_address: string;
  location_lat: number;
  location_lng: number;
  scheduled_at?: string;
  request_sent_at: string;
  customer_name?: string;
  customer_rating?: number | undefined;
  customer_review_count?: number | undefined;
  distance?: number | undefined;
  drive_time_minutes?: number | undefined;
  formatted_location?: string;
  assignedToValeter?: boolean;
  status?: string;
  vehicle_type?: string | null;
  vehicle_info?: string | null;
  vehicle_registration?: string | null;
  vehicle_make?: string | null;
  vehicle_model?: string | null;
}

export default function JobsPage() {
  const { user } = useAuth();
  const { mode } = useGlobalTheme();
  const theme = getAccountTheme('valeter', mode);
  const iconColors = getIconColors(theme);
  const insets = useSafeAreaInsets();
  const isLight = theme.mode === 'light';
  const pageBg = theme.background;
  const primaryColor = theme.primary;
  const quickAccessButtonStyle = {
    backgroundColor: isLight ? `${primaryColor}22` : `${primaryColor}2B`,
    borderWidth: 0,
  };
  const statusOnlineBg = theme.statusOnlineCardBg ?? 'rgba(16,185,129,0.2)';
  const statusOnlineAccent = theme.statusOnlineAccent ?? '#10B981';
  const emptyCtaColors = isLight ? [theme.primary, theme.primaryAlt] : [colors.SKY, '#60A5FA'];
  
  // Jobs state
  const [jobs, setJobs] = useState<JobRequest[]>([]);
  const [jobsLoading, setJobsLoading] = useState(true);
  const [onlineCustomersCount, setOnlineCustomersCount] = useState(0);
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [emptyTipIndex, setEmptyTipIndex] = useState(0);
  const [areaStats, setAreaStats] = useState<AreaStats | null>(null);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedJobIndex, setSelectedJobIndex] = useState(0);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
    longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
  });
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [locationPermission, setLocationPermission] = useState<Location.PermissionStatus | null>(null);
  const [initialRegion, setInitialRegion] = useState<Region | null>(null);
  const [nearbyValeters, setNearbyValeters] = useState<{ user_id: string; last_lat: number; last_lng: number }[]>([]);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const mapRef = useRef<MapView>(null);
  const listRef = useRef<FlatList>(null);

  useEffect(() => {
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
    }).start();

      const requestLocation = async () => {
        try {
          const { status } = await Location.requestForegroundPermissionsAsync();
          setLocationPermission(status);
          if (status === 'granted') {
            try {
              const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.High });
              setUserLocation({ latitude: loc.coords.latitude, longitude: loc.coords.longitude });
            } catch (_) {}
          }
        } catch (_) {}
      };
      requestLocation();
      loadJobs();
    loadOnlineCustomersCount();
      subscribeToJobs();

    const loadPresence = async () => {
      if (!user?.id) return;
      const { data } = await supabase
        .from('valeter_presence')
        .select('is_online')
        .eq('user_id', user.id)
        .maybeSingle();
      setIsOnline(!!(data as any)?.is_online);
    };
    loadPresence();
    const channel = supabase
      .channel('jobs-presence')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'valeter_presence', filter: `user_id=eq.${user?.id ?? ''}` },
        (payload) => {
          const row: any = payload.new ?? payload.old;
          if (row && typeof row.is_online === 'boolean') setIsOnline(row.is_online);
        }
      )
      .subscribe();
    
    const interval = setInterval(() => {
      loadOnlineCustomersCount();
    }, 30000); // Update every 30 seconds

    return () => {
      clearInterval(interval);
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  // Rotate empty-state tip every 12s when no jobs
  useEffect(() => {
    if (jobs.length > 0) return;
    const t = setInterval(() => setEmptyTipIndex((i) => (i + 1) % 4), 12000);
    return () => clearInterval(t);
  }, [jobs.length]);

  // Fetch nearby online valeters to show their actual locations on the map
  useEffect(() => {
    const lat = userLocation?.latitude ?? region.latitude;
    const lng = userLocation?.longitude ?? region.longitude;
    let cancelled = false;
    (async () => {
      try {
        const { data } = await supabase
          .from('valeter_presence')
          .select('user_id, last_lat, last_lng')
          .eq('is_online', true)
          .not('last_lat', 'is', null)
          .not('last_lng', 'is', null);
        if (cancelled) return;
        const deg = 0.08;
        const inArea = (data ?? []).filter(
          (r: any) =>
            r.user_id !== user?.id &&
            r.last_lat >= lat - deg && r.last_lat <= lat + deg &&
            r.last_lng >= lng - deg && r.last_lng <= lng + deg
        ).map((r: any) => ({ user_id: r.user_id, last_lat: r.last_lat, last_lng: r.last_lng }));
        setNearbyValeters(inArea);
      } catch {
        if (!cancelled) setNearbyValeters([]);
      }
    })();
    return () => { cancelled = true; };
  }, [user?.id, userLocation?.latitude, userLocation?.longitude, region.latitude, region.longitude]);

  // When jobs load and we have user location, fit map to show both
  useEffect(() => {
    if (jobs.length === 0 || !userLocation) return;
    const t = setTimeout(() => fitMapToShowUserAndJobs(), 400);
    return () => clearTimeout(t);
  }, [jobs.length, userLocation?.latitude, userLocation?.longitude]);

  // When no jobs, center map on user's real location
  useEffect(() => {
    if (jobs.length > 0 || !userLocation) return;
    const newRegion: Region = {
      latitude: userLocation.latitude,
      longitude: userLocation.longitude,
      latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
      longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
    };
    setRegion(newRegion);
    setInitialRegion(newRegion);
  }, [jobs.length, userLocation?.latitude, userLocation?.longitude]);

  // Push current device location to valeter_presence so availability/radius for customers is based on current location
  useEffect(() => {
    if (!user?.id || !isOnline) return;
    const pushLocation = async () => {
      try {
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        const lat = Number(loc.coords.latitude.toFixed(6));
        const lng = Number(loc.coords.longitude.toFixed(6));
        const { error } = await supabase.rpc('update_my_presence', { p_is_online: true, p_last_lat: lat, p_last_lng: lng });
        if (error) {
          await supabase.from('valeter_presence').upsert(
            { user_id: user.id, is_online: true, last_lat: lat, last_lng: lng, updated_at: new Date().toISOString() },
            { onConflict: 'user_id' }
          );
        }
        setUserLocation({ latitude: loc.coords.latitude, longitude: loc.coords.longitude });
      } catch (_) {}
    };
    pushLocation();
    const interval = setInterval(pushLocation, 15000);
    return () => clearInterval(interval);
  }, [user?.id, isOnline]);

  // Fetch real area stats (peak times, avg wait) when no jobs
  const DEFAULT_LAT = 51.5074;
  const DEFAULT_LNG = -0.1278;
  useEffect(() => {
    if (jobs.length > 0) return;
    const lat = userLocation?.latitude ?? DEFAULT_LAT;
    const lng = userLocation?.longitude ?? DEFAULT_LNG;
    let cancelled = false;
    fetchAreaStats(lat, lng).then((s) => {
      if (!cancelled) setAreaStats(s);
    });
    return () => { cancelled = true; };
  }, [jobs.length, userLocation?.latitude, userLocation?.longitude]);

  const handleGoOnline = async () => {
    await hapticFeedback('light');
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Location permission is required to go online so customers can find you.');
        return;
      }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const lat = Number(loc.coords.latitude.toFixed(6));
      const lng = Number(loc.coords.longitude.toFixed(6));
      const { error } = await supabase.rpc('update_my_presence', { p_is_online: true, p_last_lat: lat, p_last_lng: lng });
      if (error) {
        await supabase.from('valeter_presence').upsert(
          { user_id: user?.id, is_online: true, last_lat: lat, last_lng: lng, updated_at: new Date().toISOString() },
          { onConflict: 'user_id' }
        );
      }
      setUserLocation({ latitude: loc.coords.latitude, longitude: loc.coords.longitude });
      setIsOnline(true);
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Could not go online. Try again.');
    }
  };

  const loadOnlineCustomersCount = async () => {
    if (!user?.id) return;
    try {
      // Get valeter's location and radius
      const { data: presenceData } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', user.id)
        .single();

      if (!presenceData?.last_lat || !presenceData?.last_lng) {
        setOnlineCustomersCount(0);
        return;
      }

      const radiusResult = await fetchRadiusPreference(user.id);
      const workingRadiusMiles = radiusResult.value ?? 10;

      // Count customers with active bookings in the area
      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('user_id, location_lat, location_lng')
        .in('status', ['pending_valeter_acceptance', 'pending_payment', 'confirmed', 'scheduled'])
        .not('location_lat', 'is', null)
        .not('location_lng', 'is', null);

      if (error) throw error;

      const valeterLat = presenceData.last_lat;
      const valeterLng = presenceData.last_lng;

      const customersInRadius = (bookings || []).filter((booking: any) => {
        if (!booking.location_lat || !booking.location_lng) return false;
        const distance = calculateDistance(
          valeterLat,
          valeterLng,
          booking.location_lat,
          booking.location_lng
        );
        return distance <= workingRadiusMiles;
      });

      // Get unique customer count
      const uniqueCustomers = new Set(customersInRadius.map((b: any) => b.user_id));
      setOnlineCustomersCount(uniqueCustomers.size);
    } catch (error) {
      console.error('Error loading online customers count:', error);
    }
  };

  const loadJobs = async () => {
    if (!user?.id) return;
    try {
      let query = supabase
        .from('bookings')
        .select(`
          id,
          service_type,
          service_name,
          price,
          location_address,
          location_lat,
          location_lng,
          scheduled_at,
          request_sent_at,
          status,
          user_id,
          valeter_id,
          vehicle_type,
          vehicle_info
        `)
        .order('request_sent_at', { ascending: false })
        .limit(20);

      if (user?.id) {
        query = query.or(
          `and(status.eq.pending_valeter_acceptance,valeter_id.is.null),` +
          `and(status.eq.pending_valeter_acceptance,valeter_id.eq.${user.id}),` +
          `and(status.in.(pending_payment,confirmed,en_route,arrived,in_progress),valeter_id.eq.${user.id})`
        );
      } else {
        query = query.eq('status', 'pending_valeter_acceptance').is('valeter_id', null);
      }

      const { data, error } = await query;

      if (error) throw error;

      const customerIds = Array.from(
        new Set(
          (data || [])
            .map((job: any) => job.user_id)
            .filter(Boolean)
        )
      ) as string[];

      const customerProfiles = await fetchProfilesByIds(customerIds);

      // Fetch vehicle information from customer_vehicles table
      const vehicleMap = new Map<string, { registration?: string; make?: string; model?: string; type?: string }>();
      if (customerIds.length > 0) {
        try {
          const { data: vehicles, error: vehicleErr } = await supabase
            .from('customer_vehicles')
            .select('user_id, registration, make, model, type')
            .in('user_id', customerIds)
            .eq('is_default', true);

          if (vehicleErr) {
            console.warn('[ValeterJobs] vehicle lookup error:', vehicleErr.message);
          } else {
            (vehicles || []).forEach((v: any) => {
              vehicleMap.set(v.user_id, {
                registration: v.registration || undefined,
                make: v.make || undefined,
                model: v.model || undefined,
                type: v.type || undefined,
              });
            });
          }
        } catch (error) {
          console.warn('[ValeterJobs] vehicle lookup failed:', error);
        }
      }

      // Fetch customer ratings and review counts
      // Calculate based on completed bookings (proxy for customer reliability)
      const { data: customerBookings } = await supabase
        .from('bookings')
        .select('user_id, status, rating, review')
        .in('user_id', customerIds)
        .eq('status', 'completed');

      const customerRatingMap = new Map<string, { rating: number; count: number }>();
      if (customerBookings) {
        customerIds.forEach(customerId => {
          const completedBookings = customerBookings.filter(b => b.user_id === customerId);
          const totalCompleted = completedBookings.length;
          
          // Use completed bookings as a proxy for customer rating
          // More completed bookings = better customer (reliable, pays on time, etc.)
          // Calculate a rating based on completion rate and total bookings
          if (totalCompleted > 0) {
            // Base rating: 4.0 + (completed bookings / 10) capped at 5.0
            // This gives customers with more successful bookings a higher rating
            const baseRating = Math.min(4 + (totalCompleted / 10), 5);
            const reviews = completedBookings.filter(b => b.review).length;
            
            customerRatingMap.set(customerId, {
              rating: Math.round(baseRating * 10) / 10,
              count: reviews || totalCompleted, // Use review count or total bookings as count
            });
          }
        });
      }

      const { data: presenceData } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', user.id)
        .single();

      const valeterLat = presenceData?.last_lat;
      const valeterLng = presenceData?.last_lng;

      const radiusResult = await fetchRadiusPreference(user.id);
      const workingRadiusMiles = radiusResult.value ?? 10;

      const jobsWithDistance: JobRequest[] = (data || [])
        .map((job: any) => {
          const assignedToValeter = Boolean(user?.id && job.valeter_id === user.id);
          let distance = null;
          let driveTime = null;
          if (valeterLat && valeterLng && job.location_lat && job.location_lng) {
            distance = calculateDistance(
              valeterLat,
              valeterLng,
              job.location_lat,
              job.location_lng
            );
            driveTime = calculateDriveTime(distance);
          }

          const customerRating = customerRatingMap.get(job.user_id);
          const formattedLocation = formatLocation(job.location_address);
          const vehicleData = job.user_id ? vehicleMap.get(job.user_id) : null;

          return {
            id: job.id,
            service_type: job.service_type,
            service_name: job.service_name,
            price: job.price,
            location_address: job.location_address,
            location_lat: job.location_lat,
            location_lng: job.location_lng,
            scheduled_at: job.scheduled_at,
            request_sent_at: job.request_sent_at,
            customer_name: customerProfiles.get(job.user_id)?.full_name || 'Customer',
            customer_rating: customerRating?.rating ?? undefined,
            customer_review_count: customerRating?.count ?? undefined,
            distance: distance ? Math.round(distance * 10) / 10 : undefined,
            drive_time_minutes: driveTime ?? undefined,
            formatted_location: formattedLocation,
            assignedToValeter,
            status: job.status,
            vehicle_type: job.vehicle_type || vehicleData?.type || null,
            vehicle_info: job.vehicle_info || null,
            vehicle_registration: vehicleData?.registration || null,
            vehicle_make: vehicleData?.make || null,
            vehicle_model: vehicleData?.model || null,
          };
        })
        .filter((job) => {
          if (job.assignedToValeter) {
            return true;
          }
          if (job.distance == null) return true;
          return job.distance <= workingRadiusMiles;
        });

      setJobs(jobsWithDistance);
      if (jobsWithDistance.length > 0) {
        setSelectedJobIndex(0);
        const first = jobsWithDistance[0];
        if (first?.location_lat != null && first?.location_lng != null) {
          const newRegion: Region = {
            latitude: first.location_lat,
            longitude: first.location_lng,
            latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
            longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
          };
          setRegion(newRegion);
          setInitialRegion(newRegion);
        }
      }
    } catch (error) {
      console.error('Error loading jobs:', error);
    } finally {
      setJobsLoading(false);
    }
  };

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 3959;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const calculateDriveTime = (distanceMiles: number): number => {
    // Estimate: average 30 mph in city, so 1 mile ≈ 2 minutes
    return Math.round(distanceMiles * 2);
  };

  const formatLocation = (address: string): string => {
    // Try to extract area and postcode from address
    // Format: "Street, Area, City (POSTCODE)" or similar
    const postcodeRegex = /\b([A-Z]{1,2}\d{1,2}[A-Z]?\s?\d[A-Z]{2})\b/i;
    const postcodeMatch = postcodeRegex.exec(address);
    const postcode = postcodeMatch ? postcodeMatch[1].toUpperCase() : null;
    
    // Try to extract area/city name
    const parts = address.split(',').map(p => p.trim());
    let area = '';
    let city = '';
    
    if (parts.length >= 2) {
      // Usually format is: Street, Area, City, Postcode
      area = parts.at(-3) || parts.at(-2) || '';
      city = parts.at(-2) || parts.at(-1) || '';
      } else {
      area = address;
    }
    
    // Clean up - remove postcode from area/city if present
    if (postcode) {
      area = area.replace(postcode, '').trim();
      city = city.replace(postcode, '').trim();
    }
    
    // Build formatted string
    if (area && city && postcode) {
      return `${area}, ${city} (${postcode})`;
    } else if (area && postcode) {
      return `${area} (${postcode})`;
    } else if (city && postcode) {
      return `${city} (${postcode})`;
    } else if (postcode) {
      return `(${postcode})`;
    } else if (area) {
      return area;
    }
    
    // Fallback to first part of address
    return parts[0] || address;
  };

  const subscribeToJobs = () => {
    const channel = supabase
      .channel('job-requests')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: 'status=eq.pending_valeter_acceptance',
        },
        () => {
          loadJobs();
          loadOnlineCustomersCount();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleRefresh = async () => {
    setRefreshing(true);
    await Promise.all([loadJobs(), loadOnlineCustomersCount()]);
    setRefreshing(false);
  };

  const handleJobPress = async (job: JobRequest) => {
    await hapticFeedback('light');
    
    if (job.assignedToValeter || (job.status && job.status !== 'pending_valeter_acceptance')) {
      router.push({
        pathname: '/valeter/trips',
        params: { jobId: job.id },
      });
    } else {
    router.push({
      pathname: '/valeter/jobs/accept',
        params: { jobId: job.id },
      });
    }
  };

  const handleAcceptJob = async (job: JobRequest) => {
    if (!user?.id || !job) return;
    await hapticFeedback('medium');

    try {
      const { error } = await supabase
        .from('bookings')
        .update({
          valeter_id: user.id,
          status: 'pending_payment',
          valeter_accepted_at: new Date().toISOString(),
        })
        .eq('id', job.id);

      if (error) throw error;

      router.push({
        pathname: '/valeter/trips',
        params: { jobId: job.id },
      });
    } catch (error: any) {
      console.error('Error accepting job:', error);
    }
  };

  const handleRejectJob = async (job: JobRequest) => {
    await hapticFeedback('light');
    Alert.alert(
      'Decline booking?',
      'Are you sure you want to decline this booking? The customer will be notified.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Decline',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('bookings')
                .update({ status: 'cancelled', valeter_id: null })
                .eq('id', job.id);
              if (error) throw error;
              setJobs((prev) => prev.filter((j) => j.id !== job.id));
              setSelectedJobIndex((prev) => Math.min(prev, Math.max(0, jobs.length - 2)));
            } catch (e: any) {
              Alert.alert('Error', e?.message ?? 'Failed to decline job.');
            }
          },
        },
      ]
    );
  };

  const handleCancelAll = async () => {
    if (jobs.length === 0) return;
    hapticFeedback('light');
    Alert.alert(
      'Cancel all jobs',
      `Cancel all ${jobs.length} job(s)? These bookings will be cancelled.`,
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, cancel all',
          style: 'destructive',
          onPress: async () => {
            try {
              const ids = jobs.map((j) => j.id).filter(Boolean);
              if (ids.length === 0) {
                setJobs([]);
                setSelectedJobIndex(0);
                return;
              }
              const { error } = await supabase
                .from('bookings')
                .update({ status: 'cancelled', valeter_id: null })
                .in('id', ids);
              if (error) throw error;
              setJobs([]);
              setSelectedJobIndex(0);
            } catch (e: any) {
              Alert.alert('Error', e?.message ?? 'Failed to cancel jobs.');
            }
          },
        },
      ]
    );
  };

  const fitMapToShowUserAndJobs = () => {
    const coords: { latitude: number; longitude: number }[] = [];
    if (userLocation) coords.push({ latitude: userLocation.latitude, longitude: userLocation.longitude });
    jobs.forEach((j) => {
      if (j.location_lat != null && j.location_lng != null) {
        coords.push({ latitude: j.location_lat, longitude: j.location_lng });
      }
    });
    const unique = coords.filter((c, i) => coords.findIndex((d) => d.latitude === c.latitude && d.longitude === c.longitude) === i);
    if (unique.length >= 2) {
      mapRef.current?.fitToCoordinates(unique, {
        edgePadding: { top: 80, right: 40, bottom: height * 0.45 + 40, left: 40 },
        animated: true,
      });
      return true;
    }
    return false;
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    const coords: { latitude: number; longitude: number }[] = [];
    if (userLocation) coords.push({ latitude: userLocation.latitude, longitude: userLocation.longitude });
    jobs.forEach((j) => {
      if (j.location_lat != null && j.location_lng != null) coords.push({ latitude: j.location_lat, longitude: j.location_lng });
    });
    const unique = coords.filter((c, i) => coords.findIndex((d) => d.latitude === c.latitude && d.longitude === c.longitude) === i);
    if (unique.length >= 2) {
      setTimeout(() => {
        mapRef.current?.fitToCoordinates(unique, {
          edgePadding: { top: 80, right: 40, bottom: height * 0.45 + 40, left: 40 },
          animated: true,
        });
      }, 100);
      return;
    }
    const selectedJob = jobs[selectedJobIndex];
    if (selectedJob?.location_lat != null && selectedJob?.location_lng != null) {
      const newRegion: Region = {
        latitude: selectedJob.location_lat,
        longitude: selectedJob.location_lng,
        latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
        longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
      };
      setRegion(newRegion);
      mapRef.current?.animateToRegion(newRegion, 400);
    } else if (initialRegion) {
      setRegion(initialRegion);
      mapRef.current?.animateToRegion(initialRegion, 400);
    } else if (userLocation) {
      const newRegion: Region = {
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
        longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
      };
      setRegion(newRegion);
      mapRef.current?.animateToRegion(newRegion, 400);
    }
  };

  const renderJobCard = (job: JobRequest) => (
    <ValeterJobCard
      job={job}
      variant="list"
      theme={theme}
      primaryColor={primaryColor}
      isLight={isLight}
      showStatusStrip
      onPrimary={() => {
        if (job.assignedToValeter && job.status !== 'pending_valeter_acceptance') {
          handleJobPress(job);
        } else {
          handleAcceptJob(job);
        }
      }}
      onSecondary={() => handleRejectJob(job)}
    />
  );


  const firstName = (user as any)?.name?.split(' ')[0] || 'there';
  const stats = areaStats ?? DEFAULT_STATS;
  const rotatingTips = [
    { icon: 'flash' as const, text: 'Fast accept = priority jobs', color: '#34D399' },
    { icon: 'flame' as const, text: getPeakUrgencyText(stats ?? undefined), color: '#FBBF24' },
    { icon: 'trophy' as const, text: 'Keep your streak: accept the next job for priority queue', color: '#34D399' },
    { icon: 'trophy' as const, text: 'Gold washers receive 30–40% more job offers', color: '#F59E0B' },
  ];
  const currentTip = rotatingTips[emptyTipIndex % rotatingTips.length];
  const ctaLabel = !isOnline ? 'Go Online' : 'Refresh';
  const ctaAction = !isOnline ? handleGoOnline : handleRefresh;

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: pageBg[0] }]} edges={[]}>
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} backgroundColor="transparent" translucent />
      <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />
      <ScrollView
        style={styles.content}
        contentContainerStyle={{ flex: 1 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={primaryColor} />
        }
        showsVerticalScrollIndicator={false}
      >
        <Animated.View style={[StyleSheet.absoluteFill, { opacity: fadeAnim }]}>
          <View style={styles.mapContainer}>
            <MapView
              ref={mapRef}
              style={styles.map}
              region={region}
              showsUserLocation={true}
              showsMyLocationButton={false}
              mapType="standard"
              customMapStyle={mode === 'dark' || isLight ? DARK_MAP_STYLE : undefined}
              mapPadding={{ top: 0, bottom: height * 0.45, left: 0, right: 0 }}
              loadingEnabled
              loadingIndicatorColor={primaryColor}
              onMapReady={() => {
                if (jobs.length > 0 && userLocation) setTimeout(() => fitMapToShowUserAndJobs(), 300);
              }}
            >
              {jobs.filter((j) => j.location_lat != null && j.location_lng != null).map((job) => (
                <Marker
                  key={`job-${job.id}`}
                  coordinate={{ latitude: job.location_lat!, longitude: job.location_lng! }}
                  anchor={{ x: 0.5, y: 0.5 }}
                  tracksViewChanges={false}
                >
                  <View style={[styles.jobMarker, { backgroundColor: primaryColor }]} />
                </Marker>
              ))}
              {nearbyValeters.map((v) => (
                <Marker
                  key={`valeter-${v.user_id}`}
                  coordinate={{ latitude: v.last_lat, longitude: v.last_lng }}
                  anchor={{ x: 0.5, y: 0.5 }}
                  tracksViewChanges={false}
                >
                  <View style={styles.valeterMarkerWrap}>
                    <Image source={VALETER_MAP_ICON} style={styles.valeterMarkerIcon} resizeMode="contain" />
                  </View>
                </Marker>
              ))}
            </MapView>
            <View style={[styles.recenterButtonContainer, { top: HEADER_CONTENT_OFFSET + 56 }]} pointerEvents="box-none">
              <TouchableOpacity onPress={handleRecenter} style={[styles.recenterButton, isLight && styles.recenterButtonLight]} activeOpacity={0.85}>
                <Ionicons name="locate" size={22} color={primaryColor} />
              </TouchableOpacity>
            </View>
            <View style={[styles.mapControlsOverlay, { top: HEADER_CONTENT_OFFSET + 12 }]} pointerEvents="box-none">
              <View style={[styles.mapOnlinePill, !isOnline && styles.mapOnlinePillOffline, isLight && { backgroundColor: isOnline ? statusOnlineBg : 'rgba(156,163,175,0.2)' }]}>
                <View style={[styles.mapOnlineDot, { backgroundColor: isOnline ? statusOnlineAccent : '#9CA3AF' }]} />
                <Text style={[styles.mapOnlineLabel, isLight && { color: theme.textPrimary }]}>{isOnline ? 'Online' : 'Offline'}</Text>
              </View>
              {!jobsLoading && jobs.length > 0 && (
                <View style={styles.customersBadge}>
                  <View style={styles.badgeContent}>
                    <View style={[styles.onlineIndicator, { backgroundColor: colors.SKY }]} />
                    <Text style={styles.badgeText}>{jobs.length} {jobs.length === 1 ? 'job' : 'jobs'}</Text>
                  </View>
                </View>
              )}
            </View>
          </View>
          <View style={styles.headerOverlay}>
            <AppHeader title="Jobs" accountType="valeter" lowOpacity />
          </View>
          {jobsLoading && (
            <View style={styles.loadingOverlay} pointerEvents="none">
              <ActivityIndicator size="large" color={primaryColor} />
              <Text style={[styles.loadingOverlayText, isLight && { color: theme.textPrimary }]}>Loading jobs…</Text>
            </View>
          )}
          {!jobsLoading && jobs.length === 0 && (
            <View style={[styles.emptyContainer, { bottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 48 }]}>
              <BlurView intensity={isLight ? 28 : 60} tint={isLight ? 'light' : 'dark'} style={[styles.emptyCard, styles.emptyCardCompact, isLight && { shadowColor: theme.shadowColor }]}>
                <View style={[styles.jobCardBackground, isLight && { backgroundColor: `${primaryColor}0A` }]} />
                <View style={[styles.jobCardBorder]} />
                <View style={styles.emptyContent}>
                  <Ionicons name="briefcase-outline" size={48} color={primaryColor} style={{ opacity: 0.8 }} />
                  <Text style={[styles.emptyTitle, styles.emptyTitleCompact, isLight && { color: theme.textPrimary }]}>No jobs right now</Text>
                  <Text style={[styles.emptyPersonality, styles.emptyPersonalityCompact, isLight && { color: theme.textSecondary }]}>Hey {firstName}, fast accept = priority jobs.</Text>
                  <Text style={[styles.emptyAvgWait, styles.emptyAvgWaitCompact, isLight && { color: primaryColor }]}>Avg wait: {stats?.avgWaitMinsLow ?? 3}–{stats?.avgWaitMinsHigh ?? 8} mins</Text>
                  <View style={styles.emptyNudgeRow}>
                    <Ionicons name={currentTip.icon} size={16} color={currentTip.color} style={styles.emptyNudgeIcon} />
                    <Text style={[styles.emptyNudgeText, styles.emptyNudgeTextCompact, isLight && { color: theme.textSecondary }]}>{currentTip.text}</Text>
                  </View>
                  <TouchableOpacity onPress={ctaAction} activeOpacity={0.85} style={styles.emptyCtaButton}>
                    <LinearGradient colors={emptyCtaColors} style={styles.emptyCtaGradient}>
                      <Ionicons name={!isOnline ? 'radio' : 'refresh'} size={20} color="#FFFFFF" />
                      <Text style={styles.emptyCtaLabel}>{ctaLabel}</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </View>
              </BlurView>
            </View>
          )}
          {!jobsLoading && jobs.length > 0 && (
            <Animated.View style={[styles.cardContainer, { bottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom, opacity: fadeAnim }]}>
              <FlatList
                ref={listRef}
                data={jobs}
                keyExtractor={(item) => item.id}
                horizontal
                pagingEnabled
                showsHorizontalScrollIndicator={false}
                snapToInterval={cardWidth}
                snapToAlignment="start"
                decelerationRate="fast"
                getItemLayout={(_, index) => ({ length: cardWidth, offset: cardWidth * index, index })}
                onMomentumScrollEnd={(e: NativeSyntheticEvent<NativeScrollEvent>) => {
                  const i = Math.round(e.nativeEvent.contentOffset.x / cardWidth);
                  setSelectedJobIndex(i);
                  const job = jobs[i];
                  if (job?.location_lat != null && job?.location_lng != null) {
                    const newRegion: Region = {
                      latitude: job.location_lat,
                      longitude: job.location_lng,
                      latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
                      longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
                    };
                    setRegion(newRegion);
                    mapRef.current?.animateToRegion(newRegion, 400);
                  }
                }}
                renderItem={({ item: job }) => (
                  <View style={[styles.cardSlide, { width: cardWidth }]}>
                    {renderJobCard(job)}
                  </View>
                )}
              />
              {jobs.length > 1 && (
                <View style={styles.pageIndicator}>
                  {jobs.map((_, i) => (
                    <View key={i} style={[styles.pageDot, i === selectedJobIndex && [styles.pageDotActive, { backgroundColor: primaryColor }]]} />
                  ))}
                </View>
              )}
            </Animated.View>
          )}
        </Animated.View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  content: {
    flex: 1,
  },
  mapContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  jobMarker: {
    width: 24,
    height: 24,
    borderRadius: 12,
    opacity: 0.9,
  },
  valeterMarkerWrap: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(16,185,129,0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFF',
  },
  valeterMarkerIcon: {
    width: 20,
    height: 20,
  },
  recenterButtonContainer: {
    position: 'absolute',
    right: 16,
    zIndex: 20,
  },
  recenterButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  recenterButtonLight: {
    backgroundColor: 'rgba(125,211,252,0.35)',
    borderColor: 'rgba(125,211,252,0.5)',
  },
  mapControlsOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    zIndex: 10,
  },
  loadingOverlay: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
    zIndex: 15,
  },
  loadingOverlayText: {
    color: '#F9FAFB',
    fontSize: 14,
    marginTop: 12,
  },
  emptyContainer: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 15,
  },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 16,
    zIndex: 15,
  },
  cardSlide: {
    paddingHorizontal: 0,
  },
  pageIndicator: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    marginTop: 12,
  },
  pageDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.4)',
  },
  pageDotActive: {
    backgroundColor: colors.SKY,
  },
  mapOnlinePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 0,
  },
  mapOnlinePillOffline: {
    backgroundColor: 'rgba(156,163,175,0.25)',
  },
  mapOnlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  mapOnlineLabel: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '600',
  },
  contentContainer: {
    flexGrow: 1,
    paddingTop: HEADER_CONTENT_OFFSET + 52,
  },
  jobListTopBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    paddingBottom: 12,
  },
  jobListContainer: {
    paddingHorizontal: 16,
    paddingTop: 8,
  },
  jobListContent: {
    paddingBottom: 16,
  },
  jobListItem: {
    width: '100%',
    marginBottom: 12,
  },
  emptyContainerList: {
    paddingHorizontal: 16,
    paddingTop: 24,
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 100,
    backgroundColor: 'transparent',
  },
  customersBadge: {
    borderRadius: 12,
    backgroundColor: 'rgba(0,0,0,0.6)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  badgeContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  onlineIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  badgeText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  cardsLoadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  jobCardBackground: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(135,206,235,0.18)',
    borderRadius: 20,
  },
  jobCardBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 0,
    pointerEvents: 'none',
  },
  emptyCardCompact: {
    padding: 24,
  },
  emptyTitleCompact: { fontSize: 18, marginTop: 4 },
  emptyPersonalityCompact: { fontSize: 13, marginBottom: 6 },
  emptyAvgWaitCompact: { fontSize: 12, marginBottom: 8 },
  emptyNudgeTextCompact: { fontSize: 12 },
  emptyCard: {
    padding: 24,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 0,
    backgroundColor: 'rgba(135,206,235,0.12)',
    elevation: 8,
    shadowColor: colors.SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    position: 'relative',
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 8,
    marginBottom: 4,
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
  },
  emptyPersonality: {
    color: 'rgba(135,206,235,0.95)',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
    textAlign: 'center',
  },
  emptyAvgWait: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 13,
    marginBottom: 12,
    textAlign: 'center',
  },
  emptyNudges: {
    width: '100%',
    gap: 10,
  },
  emptyNudgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  emptyNudgeIcon: {
    width: 22,
    textAlign: 'center',
  },
  emptyNudgeText: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 13,
    flex: 1,
  },
  emptyCtaButton: {
    marginTop: 12,
    borderRadius: 12,
    overflow: 'hidden',
    alignSelf: 'stretch',
    maxWidth: 280,
  },
  emptyCtaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 24,
  },
  emptyCtaLabel: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});
