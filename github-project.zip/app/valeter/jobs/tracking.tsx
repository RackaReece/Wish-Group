import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Image,
  Linking,
  StatusBar,
  ScrollView,
  Modal,
  Pressable,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Region } from 'react-native-maps';
import { VALETER_MAP_ICON } from '../../../src/constants/mapIcons';
import { useGlobalTheme } from '../../../src/components/shared/GlobalThemeContext';
import { DARK_MAP_STYLE, DEFAULT_MAP_ZOOM_DELTA } from '../../../src/constants/mapStyles';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import ProBookingCard from '../../../src/components/booking/ProBookingCard';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import { openInAppNavigation } from '../../../src/utils/openInAppNavigation';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import LoadingView from '../../../src/components/shared/LoadingView';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';

import * as ColorsModule from '../../../src/constants/colors';
import { getIconColors } from '../../../src/constants/themeColors';
import { getAccountTheme } from '../../../src/constants/accountThemes';

const appColors: any =
  (ColorsModule as any).colors ??
  (ColorsModule as any).default ??
  ColorsModule;

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

type JobStatus =
  | 'pending_valeter_acceptance'
  | 'pending_payment'
  | 'payment_processing'
  | 'confirmed'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed';

const ACTIVE_STATUSES: JobStatus[] = ['confirmed', 'en_route', 'arrived', 'in_progress'];

const STATUS_STEPS: { key: JobStatus; label: string; icon: string; progress: number }[] = [
  { key: 'pending_valeter_acceptance', label: 'Accept', icon: 'hand-left-outline', progress: 10 },
  { key: 'pending_payment', label: 'Payment', icon: 'card-outline', progress: 20 },
  { key: 'payment_processing', label: 'Processing', icon: 'hourglass-outline', progress: 30 },
  { key: 'confirmed', label: 'Paid', icon: 'checkmark-circle-outline', progress: 40 },
  { key: 'en_route', label: 'En route', icon: 'navigate-outline', progress: 60 },
  { key: 'arrived', label: 'Arrived', icon: 'location-outline', progress: 80 },
  { key: 'in_progress', label: 'Service', icon: 'water-outline', progress: 90 },
  { key: 'completed', label: 'Done', icon: 'checkmark-done', progress: 100 },
];

export default function JobTracking() {
  const { user } = useAuth();
  const { mode } = useGlobalTheme();
  const theme = getAccountTheme('valeter', mode);
  const iconColors = getIconColors(theme);
  const isLight = theme.mode === 'light';
  const params = useLocalSearchParams();
  const insets = useSafeAreaInsets();

  const jobIdParam = typeof params.jobId === 'string' ? params.jobId : undefined;
  const jobId = jobIdParam && jobIdParam !== 'undefined' ? jobIdParam : null;

  const [job, setJob] = useState<any | null>(null);
  const [customerName, setCustomerName] = useState('Customer');
  const [customerPhone, setCustomerPhone] = useState<string | null>(null);
  const [infoModalVisible, setInfoModalVisible] = useState(false);
  const [cancelling, setCancelling] = useState(false);
  const [status, setStatus] = useState<JobStatus>('pending_valeter_acceptance');
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
    longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
  });

  // Use route param jobId if present; otherwise fall back to loaded active job id
  const effectiveJobId = useMemo(() => {
    return jobId ?? job?.id ?? null;
  }, [jobId, job?.id]);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const mapRef = useRef<MapView>(null);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(markerPulse, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    // If no jobId provided, try to load the valeter's active job
    if (!jobId && user?.id) {
      loadActiveJob();
      return;
    }

    if (!jobId) {
      console.warn('[JobTracking] Missing jobId param');
      return;
    }

    loadJob();
  }, [jobId, user?.id]);

  // Subscribe once we have an actual booking id (route param OR loaded active job)
  useEffect(() => {
    const unsubscribe = subscribeToJob();
    return () => {
      unsubscribe?.();
    };
  }, [effectiveJobId]);

  const loadActiveJob = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id)
        .in('status', ['pending_valeter_acceptance', ...ACTIVE_STATUSES])
        .order('request_sent_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setJob(data);
        setStatus(data.status);

        if (data?.user_id) {
          const profile = await fetchProfileById(data.user_id);
          setCustomerName(profile?.full_name || 'Customer');
          setCustomerPhone(profile?.phone ?? null);
        }

        if (data.location_lat && data.location_lng) {
          setRegion({
            latitude: data.location_lat,
            longitude: data.location_lng,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          });
        }
      }
    } catch (error) {
      console.error('Error loading active job:', error);
    }
  };

  const loadJob = async () => {
    if (!jobId) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', jobId)
        .single();

      if (error) throw error;

      setJob(data);
      setStatus(data.status);

      if (data?.user_id) {
        const profile = await fetchProfileById(data.user_id);
        setCustomerName(profile?.full_name || 'Customer');
        setCustomerPhone(profile?.phone ?? null);
      } else {
        setCustomerName('Customer');
        setCustomerPhone(null);
      }

      if (data.location_lat && data.location_lng) {
        setRegion({
          latitude: data.location_lat,
          longitude: data.location_lng,
          latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
          longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
        });
      }
    } catch (error) {
      console.error('Error loading job:', error);
    }
  };

  const subscribeToJob = () => {
    const idToSub = effectiveJobId;
    if (!idToSub) return undefined;

    const channel = supabase
      .channel(`job-${idToSub}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${idToSub}`,
        },
        (payload) => {
          const updated = payload.new as any;
          setStatus(updated.status);

          if (updated.status === 'completed') {
            router.replace({
              pathname: '/valeter/jobs/complete',
              params: { jobId: idToSub },
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  /**
   * Guard against the DB constraint: only one "active job" per valeter.
   * We block moving into in_progress if another booking for this valeter is already active.
   */
  const assertNoOtherActiveJob = async (currentBookingId: string) => {
    if (!user?.id) return;

    // If your constraint only considers a subset (e.g. in_progress only),
    // you can narrow ACTIVE_STATUSES here.
    const { data, error } = await supabase
      .from('bookings')
      .select('id,status')
      .eq('valeter_id', user.id)
      .in('status', ACTIVE_STATUSES)
      .neq('id', currentBookingId)
      .order('request_sent_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;

    if (data?.id) {
      throw new Error(
        `You already have another active job (${data.status}). Finish it first before starting service on this one.`
      );
    }
  };

  const updateStatus = async (newStatus: JobStatus) => {
    if (!user?.id) return;
    await hapticFeedback('medium');

    const idToUpdate = effectiveJobId;
    if (!idToUpdate) {
      Alert.alert(
        'Error',
        'Missing booking id (jobId). Please reopen the job from the queue.'
      );
      return;
    }

    try {
      // Only do the "active job" precheck when trying to begin the actual service
      if (newStatus === 'in_progress') {
        await assertNoOtherActiveJob(idToUpdate);
      }

      const updatePayload: Record<string, unknown> = { status: newStatus };
      if (newStatus === 'completed') {
        updatePayload.completed_at = new Date().toISOString();
      }
      const { error } = await supabase
        .from('bookings')
        .update(updatePayload)
        .eq('id', idToUpdate);

      if (error) throw error;
      setStatus(newStatus);
      if (newStatus === 'completed') {
        router.replace({
          pathname: '/valeter/jobs/complete',
          params: { jobId: idToUpdate },
        });
      }
    } catch (error: any) {
      // Postgres unique violation (most Supabase errors include a Postgres code)
      const pgCode = error?.code || error?.details?.code;

      if (
        pgCode === '23505' ||
        String(error?.message || '').toLowerCase().includes('duplicate key value') ||
        String(error?.message || '').includes('ux_active_job_per_valeter')
      ) {
        Alert.alert(
          'You already have an active job',
          'Looks like your account already has another active job assigned. Open your active job and complete it first, or ask an admin to clear the stuck active job flag.'
        );
        return;
      }

      Alert.alert('Error', error?.message || 'Failed to update status');
    }
  };

  const getStatusProgress = (): number => {
    switch (status) {
      case 'pending_valeter_acceptance':
        return 10;
      case 'pending_payment':
        return 20;
      case 'payment_processing':
        return 30;
      case 'confirmed':
        return 40;
      case 'en_route':
        return 60;
      case 'arrived':
        return 80;
      case 'in_progress':
        return 90;
      case 'completed':
        return 100;
      default:
        return 0;
    }
  };

  const getStatusMessage = (): string => {
    switch (status) {
      case 'pending_valeter_acceptance':
        return 'Job awaiting your response';
      case 'pending_payment':
        return 'Waiting for customer payment';
      case 'payment_processing':
        return 'Payment processing';
      case 'confirmed':
        return 'Paid - Ready to start';
      case 'en_route':
        return 'On the way to location';
      case 'arrived':
        return 'Arrived at location';
      case 'in_progress':
        return 'Service in progress';
      case 'completed':
        return 'Service completed';
      default:
        return 'Tracking job';
    }
  };

  const handleAcceptOnTracking = async () => {
    if (!user?.id || !effectiveJobId) return;
    await hapticFeedback('medium');
    try {
      const { error } = await supabase
        .from('bookings')
        .update({
          valeter_id: user.id,
          status: 'pending_payment',
          valeter_accepted_at: new Date().toISOString(),
        })
        .eq('id', effectiveJobId);

      if (error) throw error;
      setStatus('pending_payment');
    } catch (error: any) {
      Alert.alert('Error', error?.message || 'Failed to accept job');
    }
  };

  const handleRejectOnTracking = async () => {
    await hapticFeedback('light');
    Alert.alert(
      'Decline and leave?',
      'Are you sure you want to decline and leave this job? You will be removed from this booking.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Yes, decline',
          style: 'destructive',
          onPress: () => router.replace('/valeter/jobs'),
        },
      ]
    );
  };

  const chatCallLocked = status === 'pending_payment' || status === 'payment_processing';

  const handleCallChat = () => {
    if (chatCallLocked) {
      hapticFeedback('light');
      Alert.alert('Unlocks after payment', 'Chat / Call becomes available once the customer has paid.');
      return;
    }
    hapticFeedback('light');
    router.push({
      pathname: '/chat-screen' as any,
      params: {
        recipientId: job?.user_id ?? '',
        recipientName: customerName,
        recipientType: 'customer',
        phone: customerPhone ?? '',
        vehicle: job?.vehicle_reg ?? job?.vehicle_make_model ?? '',
        bookingStatus: status?.replace(/_/g, ' ') ?? '',
      },
    });
  };

  const canCancel = status !== 'completed' && status !== 'cancelled';
  const handleCancelBooking = () => {
    hapticFeedback('light');
    if (!canCancel) return;
    Alert.alert(
      'Cancel booking',
      'Cancel this booking? You will be removed from this job.',
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, cancel',
          style: 'destructive',
          onPress: async () => {
            if (!effectiveJobId) return;
            setCancelling(true);
            try {
              const { error } = await supabase
                .from('bookings')
                .update({ status: 'cancelled', valeter_id: null })
                .eq('id', effectiveJobId);
              if (error) throw error;
              Alert.alert('Cancelled', 'Booking cancelled.');
              router.replace('/valeter/jobs');
            } catch (e: any) {
              Alert.alert('Error', e?.message ?? 'Failed to cancel booking.');
            } finally {
              setCancelling(false);
            }
          },
        },
      ]
    );
  };

  const getNextAction = (): { label: string; action: () => void | Promise<void> } | null => {
    switch (status) {
      case 'pending_valeter_acceptance':
      case 'pending_payment':
      case 'payment_processing':
        return null;
      case 'confirmed':
        return {
          label: 'Start Journey',
          action: async () => {
            await updateStatus('en_route');
            if (job?.location_lat != null && job?.location_lng != null) {
              openInAppNavigation(
                job.location_lat,
                job.location_lng,
                job.location_address ?? undefined,
                job?.id
              );
              Alert.alert(
                'Navigation started',
                'Use in-app turn-by-turn, or return here and tap "Mark Arrived" when you arrive.',
                [{ text: 'OK' }]
              );
            }
          },
        };
      case 'en_route':
        return {
          label: 'Mark Arrived',
          action: () => updateStatus('arrived'),
        };
      case 'arrived':
        return {
          label: 'Start Service',
          action: () => updateStatus('in_progress'),
        };
      case 'in_progress':
        return {
          label: 'Complete Service',
          action: () => updateStatus('completed'),
        };
      default:
        return null;
    }
  };

  // Default region (user's location or default)
  const defaultRegion: Region = {
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (job?.location_lat != null && job?.location_lng != null) {
      const newRegion: Region = {
        latitude: job.location_lat,
        longitude: job.location_lng,
        latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
        longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
      };
      setRegion(newRegion);
      mapRef.current?.animateToRegion(newRegion, 400);
    } else {
      mapRef.current?.animateToRegion(defaultRegion, 400);
    }
  };

  const nextAction = getNextAction();
  const mapRegion = job ? region : defaultRegion;
  const isLoading = !jobId && !job && user?.id;

  const pageBg = theme.background;
  const primaryColor = theme.primary;
  const mapAccent = '#60A5FA';
  return (
    <SafeAreaView style={[styles.container, { backgroundColor: pageBg[0] }]} edges={[] as any}>
      <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
      <View style={styles.mapWrapper}>
        <MapView
          ref={mapRef}
          style={styles.map}
          region={mapRegion}
          showsUserLocation={true}
          mapPadding={{ top: 0, bottom: 0, left: 0, right: 0 }}
          mapType="standard"
          customMapStyle={mode === 'dark' || isLight ? DARK_MAP_STYLE : undefined}
          userInterfaceStyle="dark"
        >
          {job && job.location_lat && job.location_lng && (
            <Marker
              coordinate={{
                latitude: job.location_lat,
                longitude: job.location_lng,
              }}
              anchor={{ x: 0.5, y: 0.5 }}
              tracksViewChanges={false}
            >
              <Animated.View
                style={[
                  styles.markerContainer,
                  {
                    transform: [{ scale: markerPulse }],
                  },
                ]}
              >
                <View style={styles.marker}>
                  <Image
                    source={VALETER_MAP_ICON}
                    style={styles.carMarkerImage}
                    resizeMode="contain"
                  />
                </View>
                <View style={styles.markerPulse} />
              </Animated.View>
            </Marker>
          )}
        </MapView>
        {/* Overlay disabled in light mode to keep map darker */}
        {!isLight && <View style={styles.mapOverlay} pointerEvents="none" />}

        {/* Header Overlay */}
        <View style={styles.headerOverlay}>
          <AppHeader title="Tracking" accountType="valeter" lowOpacity />
        </View>

        {/* Recenter map button */}
        <View style={[styles.recenterButtonContainer, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + 56 }]} pointerEvents="box-none">
          <TouchableOpacity onPress={handleRecenter} style={[styles.recenterButton, isLight && styles.recenterButtonLight]} activeOpacity={0.85}>
            <Ionicons name="locate" size={22} color={primaryColor} />
          </TouchableOpacity>
        </View>

        {/* Chat & Cancel floating on map */}
        {job && (
          <View style={[styles.mapActionButtons, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + 16 }]} pointerEvents="box-none">
            <TouchableOpacity onPress={handleCallChat} style={styles.mapActionBtn} activeOpacity={0.85}>
              <View style={[styles.mapActionBtnInner, chatCallLocked && styles.mapActionBtnInnerDisabled]}>
                <Ionicons name="chatbubble-ellipses-outline" size={24} color={chatCallLocked ? '#64748B' : mapAccent} />
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleCancelBooking}
              disabled={!canCancel || cancelling}
              style={[styles.mapActionBtn, (!canCancel || cancelling) && styles.mapActionBtnDisabled]}
              activeOpacity={0.85}
            >
              <View style={[styles.mapActionBtnInner, (!canCancel || cancelling) && styles.mapActionBtnInnerDisabled]}>
                {cancelling ? (
                  <ActivityIndicator size="small" color="#EF4444" />
                ) : (
                  <Ionicons name="close-circle-outline" size={24} color={canCancel ? '#EF4444' : '#64748B'} />
                )}
              </View>
            </TouchableOpacity>
          </View>
        )}

        {/* Content Overlay */}
        {isLoading ? (
          <View style={styles.loadingOverlay}>
            <LoadingView />
          </View>
        ) : !job ? (
          <View style={styles.emptyOverlay}>
            <GlassCard style={styles.emptyCard} accountType="valeter">
              <View style={styles.emptyContent}>
                <Ionicons name="navigate-outline" size={64} color={mapAccent} style={{ opacity: 0.5 }} />
                <Text style={styles.emptyTitle}>No Active Job</Text>
                <Text style={styles.emptyText}>
                  You don't have any active jobs to track at the moment. Check the jobs page for available opportunities.
                </Text>
                <TouchableOpacity
                  style={styles.backToQueueButton}
                  onPress={() => router.push('/valeter/jobs')}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={[appColors?.SKY ?? '#7DD3FC', '#60A5FA']}
                    style={styles.backToQueueGradient}
                  >
                    <Text style={styles.backToQueueText}>View Jobs</Text>
                    <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </GlassCard>
          </View>
        ) : (
          <Animated.View
            style={[
              styles.cardContainer,
              {
                opacity: fadeAnim,
                bottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom,
              },
            ]}
          >
            <ProBookingCard
              stripColor={primaryColor}
              intensity={isLight ? 24 : 40}
              compact
              style={[styles.trackingCardPremium, isLight && { shadowColor: theme.shadowColor, shadowOpacity: 0.22 }]}
            >
              <LinearGradient
                colors={isLight ? ['rgba(96,165,250,0.18)', 'rgba(96,165,250,0.08)'] : ['rgba(135,206,235,0.12)', 'rgba(135,206,235,0.06)']}
                style={StyleSheet.absoluteFill}
              />
              <View style={styles.trackingCardGradient}>
                <View style={styles.cardTopRow}>
                  <View style={styles.trackingHeaderCompact}>
                    <StatusBadge status={status} size="small" />
                    <Text style={[styles.statusMessageCompact, styles.statusMessage, isLight && styles.statusMessageLight]} numberOfLines={1}>{getStatusMessage()}</Text>
                  </View>
                  <TouchableOpacity onPress={() => { hapticFeedback('light'); setInfoModalVisible(true); }} style={styles.infoBox} activeOpacity={0.8}>
                    <View style={[styles.infoBoxInner, isLight && styles.infoBoxInnerLight]}>
                      <Ionicons name="information-circle-outline" size={22} color={mapAccent} />
                    </View>
                  </TouchableOpacity>
                </View>

                <View style={styles.ringRow}>
                  <AnimatedProgress
                    progress={getStatusProgress()}
                    size={72}
                    strokeWidth={6}
                    color={mapAccent}
                    colorCycle={[appColors?.SKY ?? '#7DD3FC', '#10B981', '#8B5CF6', '#F59E0B']}
                    percentageFontSize={14}
                  />
                </View>

              {status === 'pending_valeter_acceptance' ? (
                <View style={styles.acceptRejectRow}>
                  <TouchableOpacity
                    onPress={handleAcceptOnTracking}
                    style={styles.acceptButton}
                    activeOpacity={0.8}
                  >
                    <LinearGradient
                      colors={['#10B981', '#059669']}
                      style={styles.acceptGradient}
                    >
                      <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                      <Text style={styles.acceptButtonText}>Accept Job</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={handleRejectOnTracking}
                    style={styles.rejectButton}
                    activeOpacity={0.8}
                  >
                    <Ionicons name="close-circle-outline" size={20} color="#EF4444" />
                    <Text style={styles.rejectButtonText}>Decline</Text>
                  </TouchableOpacity>
                </View>
              ) : nextAction ? (
                <TouchableOpacity
                  onPress={nextAction.action}
                  style={styles.actionButton}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={[appColors?.SKY ?? '#7DD3FC', '#60A5FA']}
                    style={styles.actionGradient}
                  >
                    <Text style={styles.actionText}>{nextAction.label}</Text>
                    <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                  </LinearGradient>
                </TouchableOpacity>
              ) : null}
              </View>
            </ProBookingCard>
          </Animated.View>
        )}

        {/* Job info modal */}
        {job && (
          <Modal visible={infoModalVisible} transparent animationType="fade" onRequestClose={() => setInfoModalVisible(false)}>
            <Pressable style={styles.modalOverlay} onPress={() => setInfoModalVisible(false)}>
              <Pressable
                style={[
                  styles.infoModalContent,
                  { backgroundColor: isLight ? (theme.cardBackground ?? '#F1F5F9') : (theme.background?.[0] ?? '#1E293B') },
                ]}
                onPress={(e) => e.stopPropagation()}
              >
                <View style={styles.infoModalHeader}>
                  <Text style={[styles.infoModalTitle, { color: theme.textPrimary ?? '#F9FAFB' }]}>Job details</Text>
                  <TouchableOpacity onPress={() => setInfoModalVisible(false)} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}>
                    <Ionicons name="close" size={24} color={theme.textSecondary ?? '#94A3B8'} />
                  </TouchableOpacity>
                </View>
                <View style={styles.infoModalBody}>
                  <View style={styles.infoRowModal}>
                    <Ionicons name="water-outline" size={18} color={primaryColor} />
                    <Text style={[styles.infoTextModal, { color: theme.textSecondary ?? '#E5E7EB' }]} numberOfLines={2}>
                      {getServiceDisplayName(job.service_type, job.service_name)}
                    </Text>
                  </View>
                  {job.user_id ? (
                    <View style={styles.infoRowModal}>
                      <Ionicons name="person-outline" size={18} color={mapAccent} />
                      <Text style={[styles.infoTextModal, isLight && styles.infoTextModalLight]} numberOfLines={1}>{customerName}</Text>
                    </View>
                  ) : null}
                  <View style={styles.infoRowModal}>
                    <Ionicons name="location-outline" size={18} color={primaryColor} />
                    <Text style={[styles.infoTextModal, { color: theme.textSecondary ?? '#E5E7EB' }]} numberOfLines={2}>{job.location_address ?? '—'}</Text>
                  </View>
                  <View style={styles.infoRowModal}>
                    <Ionicons name="cash-outline" size={18} color={primaryColor} />
                    <Text style={[styles.infoTextModal, { color: theme.textSecondary ?? '#E5E7EB' }]}>£{job.price?.toFixed(2) || '0.00'}</Text>
                  </View>
                  <View style={styles.infoModalProgress}>
                    <Text style={[styles.infoModalProgressLabel, isLight && styles.infoModalProgressLabelLight]}>Progress</Text>
                    <AnimatedProgress progress={getStatusProgress()} size={64} strokeWidth={6} color={mapAccent} percentageFontSize={12} />
                  </View>
                </View>
                <TouchableOpacity onPress={() => setInfoModalVisible(false)} style={[styles.infoModalDone, { backgroundColor: primaryColor }]} activeOpacity={0.9}>
                  <Text style={styles.infoModalDoneText}>Close</Text>
                </TouchableOpacity>
              </Pressable>
            </Pressable>
          </Modal>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  mapWrapper: {
    flex: 1,
  },
  mapOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(10, 25, 41, 0.35)',
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 100,
  },
  recenterButtonContainer: {
    position: 'absolute',
    right: 16,
    zIndex: 20,
  },
  recenterButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(96,165,250,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 0,
  },
  recenterButtonLight: {
    backgroundColor: 'rgba(96,165,250,0.2)',
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(10, 25, 41, 0.7)',
  },
  loadingText: {
    color: '#7DD3FC',
    fontSize: 16,
    marginTop: 12,
    textAlign: 'center',
  },
  emptyOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    padding: 20,
    paddingBottom: 100,
  },
  emptyCard: {
    padding: 40,
    maxWidth: 400,
    alignSelf: 'center',
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 8,
    marginBottom: 8,
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 20,
  },
  backToQueueButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: appColors?.SKY ?? '#7DD3FC',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    marginTop: 8,
  },
  backToQueueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 28,
    gap: 8,
  },
  backToQueueText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  marker: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#EF4444',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  markerPulse: {
    position: 'absolute',
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#EF4444',
    opacity: 0.3,
  },
  carMarkerImage: {
    width: 28,
    height: 28,
  },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    padding: 16,
  },
  trackingCardPremium: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 0,
    elevation: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 14,
  },
  trackingCardGradient: {
    padding: 16,
  },
  cardTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  trackingHeaderCompact: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    minWidth: 0,
  },
  statusMessageCompact: {
    fontSize: 12,
    fontWeight: '600',
    flex: 1,
    minWidth: 0,
  },
  infoBox: { width: 36, height: 36 },
  infoBoxInner: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoBoxInnerLight: {
    backgroundColor: 'rgba(96,165,250,0.15)',
  },
  ringRow: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  mapActionButtons: {
    position: 'absolute',
    right: 16,
    zIndex: 100,
    gap: 10,
  },
  mapActionBtn: { width: 48, height: 48 },
  mapActionBtnDisabled: { opacity: 0.6 },
  mapActionBtnInner: {
    width: '100%',
    height: '100%',
    borderRadius: 24,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapActionBtnInnerDisabled: {
    backgroundColor: 'rgba(100,116,139,0.25)',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  infoModalContent: {
    width: '100%',
    maxWidth: 340,
    borderRadius: 20,
    padding: 20,
    borderWidth: 0,
  },
  infoModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  infoModalTitle: {
    fontSize: 18,
    fontWeight: '800',
  },
  infoModalBody: { gap: 12, marginBottom: 20 },
  infoRowModal: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  infoTextModal: { fontSize: 14, flex: 1 },
  infoModalProgress: {
    alignItems: 'center',
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 0,
  },
  infoModalProgressLabel: {
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 8,
  },
  infoModalDone: {
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  infoModalDoneText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  stepTimelineScroll: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 18,
    paddingVertical: 4,
    paddingHorizontal: 2,
  },
  stepItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginRight: 4,
  },
  stepIconWrap: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: 'rgba(249,250,251,0.7)',
    marginLeft: 6,
    maxWidth: 52,
  },
  stepLabelLight: {
    color: 'rgba(11,60,93,0.8)',
  },
  stepLabelCurrent: {
    color: '#F9FAFB',
    fontWeight: '800',
  },
  stepConnector: {
    width: 14,
    height: 2,
    borderRadius: 1,
    backgroundColor: 'rgba(135,206,235,0.2)',
    marginLeft: 6,
    marginRight: 2,
  },
  stepConnectorDone: {
    backgroundColor: appColors?.SKY ?? '#7DD3FC',
  },
  trackingHeader: {
    alignItems: 'center',
    marginBottom: 12,
  },
  statusMessage: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginTop: 8,
    textAlign: 'center',
  },
  statusMessageLight: {
    color: '#F9FAFB',
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingHorizontal: 8,
  },
  progressRingWrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconButton: {
    alignItems: 'center',
    minWidth: 64,
  },
  iconButtonInner: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  iconButtonCancel: {
    backgroundColor: 'rgba(239,68,68,0.15)',
  },
  iconButtonLabel: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 12,
    fontWeight: '600',
  },
  iconButtonLabelLight: {
    color: '#1E4976',
  },
  iconButtonLocked: { opacity: 0.7 },
  iconButtonInnerLocked: { backgroundColor: 'rgba(255,255,255,0.06)' },
  iconButtonLabelLocked: { color: 'rgba(249,250,251,0.5)' },
  jobInfo: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 14,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  jobInfoLight: {
    borderTopColor: 'rgba(91,143,168,0.4)',
  },
  infoPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.12)',
    maxWidth: '48%',
  },
  infoPillLight: {
    backgroundColor: 'rgba(96,165,250,0.12)',
  },
  infoPillWide: {
    maxWidth: '100%',
    flex: 1,
    minWidth: '100%',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  infoText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
  },
  infoTextLight: {
    color: 'rgba(249,250,251,0.9)',
  },
  acceptRejectRow: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
    marginTop: 4,
  },
  acceptButton: {
    flex: 1,
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.45,
    shadowRadius: 14,
  },
  acceptGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 24,
    gap: 10,
  },
  acceptButtonText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
  },
  rejectButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 24,
    gap: 10,
    borderRadius: 18,
    borderWidth: 0,
    backgroundColor: 'rgba(239,68,68,0.08)',
  },
  rejectButtonText: {
    color: '#EF4444',
    fontSize: 17,
    fontWeight: '700',
  },
  actionButton: {
    width: '100%',
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: appColors?.SKY ?? '#7DD3FC',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.45,
    shadowRadius: 14,
    marginTop: 4,
  },
  actionGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 32,
    gap: 10,
  },
  actionText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '800',
  },
});
