import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Dimensions,
  StatusBar,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Platform } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { ValeterStatsService } from '../../src/services/ValeterStatsService';
import { supabase } from '../../src/lib/supabase';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import LoadingView from '../../src/components/shared/LoadingView';
import { colors } from '../../src/constants/colors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { getTextColors, getBackgroundColors } from '../../src/constants/themeColors';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

export default function ValeterAnalytics() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { mode } = useAccountTheme();
  const theme = getAccountTheme('valeter', mode);
  const pageBg = theme.background;
  const primaryColor = theme.primary;
  const isLight = theme.mode === 'light';
  const textColors = getTextColors(theme);
  const bgColors = getBackgroundColors(theme);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    totalEarnings: 0,
    totalJobs: 0,
    averageRating: 0,
    completedJobs: 0,
    cancelledJobs: 0,
    onlineHours: 0,
    thisMonthEarnings: 0,
    thisWeekEarnings: 0,
  });

  useEffect(() => {
    loadAnalytics();
  }, [user?.id]);

  const loadAnalytics = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      
      // Load bookings from Supabase
      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id);
      
      if (error) throw error;
      
      const bookingsList = bookings || [];
      const completed = bookingsList.filter((b: any) => ['completed', 'rated', 'closed'].includes(b.status));
      const cancelled = bookingsList.filter((b: any) => b.status === 'cancelled');
      
      // Calculate earnings
      const totalEarnings = completed.reduce((sum: number, b: any) => sum + (b.price || 0), 0);
      
      // Calculate monthly/weekly earnings
      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const firstDayOfWeek = new Date(now);
      firstDayOfWeek.setDate(now.getDate() - now.getDay());
      
      const thisMonthEarnings = completed
        .filter((b: any) => {
          const date = b.completed_at || b.updated_at || b.created_at;
          return date && new Date(date) >= firstDayOfMonth;
        })
        .reduce((sum: number, b: any) => sum + (b.price || 0), 0);
      
      const thisWeekEarnings = completed
        .filter((b: any) => {
          const date = b.completed_at || b.updated_at || b.created_at;
          return date && new Date(date) >= firstDayOfWeek;
        })
        .reduce((sum: number, b: any) => sum + (b.price || 0), 0);
      
      // Load valeter stats
      let valeterStats = null;
      try {
        valeterStats = await ValeterStatsService.getValeterStats(user.id);
      } catch (e) {
        console.warn('[Analytics] Failed to load valeter stats:', e);
      }
      
      setStats({
        totalEarnings,
        totalJobs: bookingsList.length,
        averageRating: valeterStats?.averageRating || 0,
        completedJobs: completed.length,
        cancelledJobs: cancelled.length,
        onlineHours: 0, // TODO: Calculate from presence data
        thisMonthEarnings,
        thisWeekEarnings,
      });
    } catch (error: any) {
      console.error('[Analytics] Error loading analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, { backgroundColor: pageBg[0] }]}>
        <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  const successRate = stats.totalJobs > 0
    ? Math.round((stats.completedJobs / stats.totalJobs) * 100)
    : 0;

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: pageBg[0] }]} edges={[]}>
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} backgroundColor="transparent" translucent />
      <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      {/* Floating Header */}
      <View style={styles.headerWrapper}>
        <View style={[styles.header, { marginTop: insets.top + 8 }]}>
          <BlurView
            intensity={Platform.OS === 'ios' ? 40 : 30}
            tint={isLight ? 'light' : 'dark'}
            style={StyleSheet.absoluteFill}
          >
            <LinearGradient
              colors={theme.headerBackground ?? (isLight ? ['rgba(125,211,252,0.4)', 'rgba(125,211,252,0.25)'] : ['rgba(37,99,235,0.4)', 'rgba(37,99,235,0.25)'])}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
            <View style={StyleSheet.absoluteFill} pointerEvents="none">
              <LinearGradient
                colors={isLight ? ['rgba(125,211,252,0.2)', 'transparent'] : ['rgba(59,130,246,0.15)', 'transparent']}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={StyleSheet.absoluteFill}
              />
            </View>
          </BlurView>
          <View style={[styles.glassStroke, { borderColor: theme.glassBorder ?? (isLight ? 'rgba(125,211,252,0.4)' : 'rgba(59,130,246,0.3)'), borderRadius: 24 }]} />
          <View style={[styles.glowLine, { backgroundColor: isLight ? 'rgba(125,211,252,0.5)' : 'rgba(59,130,246,0.5)', shadowColor: primaryColor }]} />
          <View style={styles.headerContent}>
            <View style={styles.headerTop}>
              <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
                <Ionicons name="arrow-back" size={22} color={primaryColor} />
              </TouchableOpacity>
              <Text style={[styles.headerTitle, { color: textColors.primary }]}>Analytics</Text>
              <TouchableOpacity onPress={loadAnalytics} style={styles.refreshButton}>
                <Ionicons name="refresh" size={20} color={primaryColor} />
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent, 
          { 
            paddingTop: 120,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
            paddingLeft: isSmallScreen ? 36 : 40,
            paddingRight: 20,
          }
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Overview Stats */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: textColors.primary }]}>Overview</Text>
          <View style={styles.statsGrid}>
            <View style={[styles.statCard, isLight && { backgroundColor: bgColors.card, borderColor: bgColors.cardBorder }]}>
              <LinearGradient
                colors={isLight ? [bgColors.card ?? '#F8FBFF', bgColors.card ?? '#F8FBFF'] : (theme.headerBackground || theme.background) as [string, string]}
                style={styles.statCardGradient}
              >
                <Ionicons name="wallet" size={28} color={primaryColor} />
                <Text style={[styles.statNumber, { color: textColors.primary }]}>£{stats.totalEarnings.toFixed(2)}</Text>
                <Text style={[styles.statLabel, { color: textColors.secondary }]}>Total Earnings</Text>
              </LinearGradient>
            </View>
            
            <View style={[styles.statCard, isLight && { backgroundColor: bgColors.card, borderColor: bgColors.cardBorder }]}>
              <LinearGradient
                colors={isLight ? [bgColors.card ?? '#F8FBFF', bgColors.card ?? '#F8FBFF'] : (theme.headerBackground || theme.background) as [string, string]}
                style={styles.statCardGradient}
              >
                <Ionicons name="briefcase" size={28} color={primaryColor} />
                <Text style={[styles.statNumber, { color: textColors.primary }]}>{stats.totalJobs}</Text>
                <Text style={[styles.statLabel, { color: textColors.secondary }]}>Total Jobs</Text>
              </LinearGradient>
            </View>
            
            {stats.averageRating > 0 && (
              <View style={[styles.statCard, isLight && { backgroundColor: bgColors.card, borderColor: bgColors.cardBorder }]}>
                <LinearGradient
                  colors={isLight ? [bgColors.card ?? '#F8FBFF', bgColors.card ?? '#F8FBFF'] : (theme.headerBackground || theme.background) as [string, string]}
                  style={styles.statCardGradient}
                >
                  <Ionicons name="star" size={28} color="#F59E0B" />
                  <Text style={[styles.statNumber, { color: textColors.primary }]}>{stats.averageRating.toFixed(1)}</Text>
                  <Text style={[styles.statLabel, { color: textColors.secondary }]}>Avg Rating</Text>
                </LinearGradient>
              </View>
            )}
            
            <View style={[styles.statCard, isLight && { backgroundColor: bgColors.card, borderColor: bgColors.cardBorder }]}>
              <LinearGradient
                colors={isLight ? [bgColors.card ?? '#F8FBFF', bgColors.card ?? '#F8FBFF'] : (theme.headerBackground || theme.background) as [string, string]}
                style={styles.statCardGradient}
              >
                <Ionicons name="checkmark-circle" size={28} color="#10B981" />
                <Text style={[styles.statNumber, { color: textColors.primary }]}>{stats.completedJobs}</Text>
                <Text style={[styles.statLabel, { color: textColors.secondary }]}>Completed</Text>
              </LinearGradient>
            </View>
          </View>
        </View>

        {/* Earnings Breakdown */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: textColors.primary }]}>Earnings Breakdown</Text>
          
          <View style={[styles.earningsCard, isLight && { backgroundColor: bgColors.card, borderColor: bgColors.cardBorder }]}>
            <View style={styles.earningsRow}>
              <View style={styles.earningsLeft}>
                <Ionicons name="calendar" size={20} color={primaryColor} />
                <Text style={[styles.earningsLabel, { color: textColors.secondary }]}>This Month</Text>
              </View>
              <Text style={[styles.earningsValue, { color: textColors.primary }]}>£{stats.thisMonthEarnings.toFixed(2)}</Text>
            </View>
          </View>
          
          <View style={[styles.earningsCard, isLight && { backgroundColor: bgColors.card, borderColor: bgColors.cardBorder }]}>
            <View style={styles.earningsRow}>
              <View style={styles.earningsLeft}>
                <Ionicons name="time" size={20} color={primaryColor} />
                <Text style={[styles.earningsLabel, { color: textColors.secondary }]}>This Week</Text>
              </View>
              <Text style={[styles.earningsValue, { color: textColors.primary }]}>£{stats.thisWeekEarnings.toFixed(2)}</Text>
            </View>
          </View>
        </View>

        {/* Job Breakdown */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: textColors.primary }]}>Job Performance</Text>
          
          <View style={[styles.jobCard, isLight && { backgroundColor: bgColors.card, borderColor: bgColors.cardBorder }]}>
            <View style={styles.jobRow}>
              <View style={styles.jobLeft}>
                <Ionicons name="checkmark-circle" size={20} color="#10B981" />
                <Text style={[styles.jobLabel, { color: textColors.secondary }]}>Completed Jobs</Text>
              </View>
              <Text style={[styles.jobValue, { color: textColors.primary }]}>{stats.completedJobs}</Text>
            </View>
          </View>
          
          <View style={[styles.jobCard, isLight && { backgroundColor: bgColors.card, borderColor: bgColors.cardBorder }]}>
            <View style={styles.jobRow}>
              <View style={styles.jobLeft}>
                <Ionicons name="close-circle" size={20} color="#EF4444" />
                <Text style={[styles.jobLabel, { color: textColors.secondary }]}>Cancelled Jobs</Text>
              </View>
              <Text style={[styles.jobValue, { color: textColors.primary }]}>{stats.cancelledJobs}</Text>
            </View>
          </View>
          
          <View style={[styles.jobCard, isLight && { backgroundColor: bgColors.card, borderColor: bgColors.cardBorder }]}>
            <View style={styles.jobRow}>
              <View style={styles.jobLeft}>
                <Ionicons name="trending-up" size={20} color={primaryColor} />
                <Text style={[styles.jobLabel, { color: textColors.secondary }]}>Success Rate</Text>
              </View>
              <Text style={[styles.jobValue, { color: textColors.primary }]}>{successRate}%</Text>
            </View>
          </View>
        </View>

        {/* Quick Actions */}
        <View style={styles.section}>
          <Text style={[styles.sectionTitle, { color: textColors.primary }]}>Quick Actions</Text>
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push('/valeter/valeter-dashboard')}
          >
            <LinearGradient colors={[primaryColor, theme.primaryAlt]} style={styles.actionButtonGradient}>
              <Ionicons name="home" size={20} color="#FFFFFF" />
              <Text style={[styles.actionButtonText, { color: '#FFFFFF' }]}>Go to Dashboard</Text>
            </LinearGradient>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push('/valeter/valeter-history')}
          >
            <LinearGradient
              colors={isLight ? [`${primaryColor}30`, `${primaryColor}15`] : ['rgba(135,206,235,0.2)', 'rgba(30,58,138,0.25)']}
              style={styles.actionButtonGradient}
            >
              <Ionicons name="time" size={20} color={primaryColor} />
              <Text style={[styles.actionButtonText, { color: textColors.primary }]}>View History</Text>
            </LinearGradient>
          </TouchableOpacity>
          
          <TouchableOpacity
            style={styles.actionButton}
            onPress={() => router.push('/valeter/profile/valeter-profile')}
          >
            <LinearGradient
              colors={isLight ? [`${primaryColor}30`, `${primaryColor}15`] : ['rgba(135,206,235,0.2)', 'rgba(30,58,138,0.25)']}
              style={styles.actionButtonGradient}
            >
              <Ionicons name="person" size={20} color={primaryColor} />
              <Text style={[styles.actionButtonText, { color: textColors.primary }]}>View Profile</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: '#7DD3FC',
    fontSize: 14,
    fontWeight: '600',
  },
  scrollView: { flex: 1 },
  scrollContent: { padding: 16 },
  headerWrapper: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    alignItems: 'center',
    pointerEvents: 'box-none',
  },
  header: {
    width: width - 40,
    borderRadius: 24,
    marginHorizontal: 20,
    overflow: 'hidden',
    backgroundColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 28,
  },
  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
  },
  glowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 8,
  },
  headerContent: {
    flex: 1,
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingTop: 12,
    paddingBottom: 16,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 20 : 22,
    fontFamily: 'Rubik_600SemiBold',
    fontWeight: '700',
    letterSpacing: 0.3,
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },
  refreshButton: {
    width: 40,
    height: 40,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  section: {
    marginBottom: 14,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  statCard: {
    width: (width - (isSmallScreen ? 72 : 60) - 12) / 2,
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  statCardGradient: {
    padding: 18,
    alignItems: 'center',
    gap: 8,
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 22 : 26,
    fontWeight: '800',
  },
  statLabel: {
    color: '#7DD3FC',
    fontSize: 12,
    fontWeight: '600',
  },
  earningsCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 18,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  earningsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  earningsLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  earningsLabel: {
    color: '#7DD3FC',
    fontSize: 15,
    fontWeight: '600',
  },
  earningsValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '800',
  },
  jobCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 18,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  jobRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  jobLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  jobLabel: {
    color: '#7DD3FC',
    fontSize: 15,
    fontWeight: '600',
  },
  jobValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '800',
  },
  actionButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 12,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  actionButtonGradient: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  actionButtonText: {
    color: colors.SKY,
    fontSize: 16,
    fontWeight: '700',
  },
});
