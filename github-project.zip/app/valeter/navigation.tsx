import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Platform,
  Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Marker, Polyline } from 'react-native-maps';
import * as Location from 'expo-location';
import type { MapKitRouteResult, RouteStep } from 'expo-mapkit-directions';

function loadMapKitModule(): {
  getDirections: (fromLat: number, fromLng: number, toLat: number, toLng: number) => Promise<MapKitRouteResult | null>;
  isAvailable: () => boolean;
} {
  try {
    const mod = require('expo-mapkit-directions');
    return {
      getDirections: mod.getDirections ?? (async () => null),
      isAvailable: mod.isAvailable ?? (() => false),
    };
  } catch {
    return { getDirections: async () => null, isAvailable: () => false };
  }
}
const { getDirections, isAvailable } = loadMapKitModule();
import { openTurnByTurnNavigation } from '../../src/utils/openTurnByTurnNavigation';
import { getDirectionsOSRM } from '../../src/utils/getDirectionsOSRM';
import { DARK_MAP_STYLE } from '../../src/constants/mapStyles';
import { colors } from '../../src/constants/colors';

const { width, height } = Dimensions.get('window');
const SKY = colors.SKY;

function haversineMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371000;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

function distanceToNextStep(
  userLat: number,
  userLng: number,
  polyline: { latitude: number; longitude: number }[],
  stepEndIndex: number
): number {
  if (polyline.length === 0 || stepEndIndex < 0) return 0;
  const end = polyline[Math.min(stepEndIndex, polyline.length - 1)];
  return haversineMeters(userLat, userLng, end.latitude, end.longitude);
}

function formatDistance(meters: number): string {
  if (meters >= 1000) return `${(meters / 1000).toFixed(1)} km`;
  return `${Math.round(meters)} m`;
}

function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  if (mins >= 60) return `${Math.floor(mins / 60)} h ${mins % 60} min`;
  return `${mins} min`;
}

export default function ValeterNavigationScreen() {
  const params = useLocalSearchParams<{
    destinationLat: string;
    destinationLng: string;
    address?: string;
    jobId?: string;
  }>();
  const insets = useSafeAreaInsets();
  const destLat = params.destinationLat ? parseFloat(params.destinationLat) : NaN;
  const destLng = params.destinationLng ? parseFloat(params.destinationLng) : NaN;
  const address = params.address ?? '';
  const jobId = params.jobId ?? null;

  const [route, setRoute] = useState<MapKitRouteResult | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [currentStepIndex, setCurrentStepIndex] = useState(0);
  const [distanceToNext, setDistanceToNext] = useState<number>(0);
  const [locationPermission, setLocationPermission] = useState<Location.PermissionStatus | null>(null);

  const mapRef = useRef<MapView>(null);

  const useMapKit = Platform.OS === 'ios' && isAvailable();
  const destination: { latitude: number; longitude: number } | null =
    !Number.isNaN(destLat) && !Number.isNaN(destLng)
      ? { latitude: destLat, longitude: destLng }
      : null;

  // Request location and fetch route (iOS MapKit)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (cancelled) return;
      setLocationPermission(status);
      if (status !== 'granted') {
        setError('Location permission is required for navigation.');
        setLoading(false);
        return;
      }
      let loc: Location.LocationObject;
      try {
        loc = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.High,
        });
      } catch (locErr: any) {
        if (!cancelled) {
          setError(locErr?.message ?? 'Cannot obtain current location.');
          setLoading(false);
        }
        return;
      }
      if (cancelled) return;
      setUserLocation({
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
      });

      if (!destination) {
        setLoading(false);
        setError('Missing destination.');
        return;
      }

      const fromLat = loc.coords.latitude;
      const fromLng = loc.coords.longitude;
      const toLat = destination.latitude;
      const toLng = destination.longitude;

      try {
        let result: typeof route;
        if (useMapKit) {
          result = await getDirections(fromLat, fromLng, toLat, toLng);
        } else {
          result = await getDirectionsOSRM(fromLat, fromLng, toLat, toLng);
        }
        if (cancelled) return;
        if (result) {
          setRoute(result);
          setCurrentStepIndex(0);
          const firstStep = result.steps[0];
          setDistanceToNext(
            firstStep
              ? distanceToNextStep(fromLat, fromLng, result.polyline, firstStep.polylineEndIndex)
              : 0
          );
        } else {
          setError('No route found. Tap "Open in Maps" to use your maps app.');
        }
      } catch (e: any) {
        if (!cancelled) setError(e?.message ?? 'Failed to get directions.');
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [destination?.latitude, destination?.longitude, useMapKit]);

  // Watch user location and update distance to next step / current step index
  useEffect(() => {
    if (!route || route.steps.length === 0) return;
    const sub = Location.watchPositionAsync(
      {
        accuracy: Location.Accuracy.High,
        distanceInterval: 20,
        timeInterval: 5000,
      },
      (loc) => {
        const lat = loc.coords.latitude;
        const lng = loc.coords.longitude;
        setUserLocation({ latitude: lat, longitude: lng });
        const steps = route.steps;
        const poly = route.polyline;
        let stepIdx = 0;
        let minDist = Infinity;
        for (let i = 0; i < steps.length; i++) {
          const endIdx = steps[i].polylineEndIndex;
          const pt = poly[Math.min(endIdx, poly.length - 1)];
          if (!pt) continue;
          const d = haversineMeters(lat, lng, pt.latitude, pt.longitude);
          if (d < minDist) {
            minDist = d;
            stepIdx = i;
          }
        }
        setCurrentStepIndex(stepIdx);
        const nextStep = steps[stepIdx];
        setDistanceToNext(
          nextStep
            ? distanceToNextStep(lat, lng, poly, nextStep.polylineEndIndex)
            : 0
        );
      }
    );
    return () => {
      sub.then((s) => s.remove());
    };
  }, [route]);

  // Fit map to route + user when we have route
  useEffect(() => {
    if (!route?.polyline?.length || !mapRef.current) return;
    const coords = route.polyline.map((p) => ({
      latitude: p.latitude,
      longitude: p.longitude,
    }));
    if (userLocation) coords.push(userLocation);
    mapRef.current.fitToCoordinates(coords, {
      edgePadding: { top: 80, right: 40, bottom: 280, left: 40 },
      animated: true,
    });
  }, [route?.polyline, userLocation]);

  const handleOpenExternal = () => {
    if (destination)
      openTurnByTurnNavigation(destination.latitude, destination.longitude, address || undefined);
  };

  const handleBack = () => router.back();

  if (!destination) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <View style={styles.centered}>
          <Text style={styles.errorText}>Missing destination.</Text>
          <TouchableOpacity onPress={handleBack} style={styles.button}>
            <Text style={styles.buttonText}>Go back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <View style={styles.centered}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Getting route…</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (error && !route) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <View style={styles.centered}>
          <Ionicons name="warning-outline" size={48} color={SKY} />
          <Text style={styles.errorText}>{error}</Text>
          <TouchableOpacity onPress={handleOpenExternal} style={styles.primaryButton}>
            <Text style={styles.primaryButtonText}>Open in Maps</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleBack} style={styles.button}>
            <Text style={styles.buttonText}>Go back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const currentStep: RouteStep | undefined = route?.steps[currentStepIndex];
  const isLastStep = currentStepIndex >= (route?.steps.length ?? 0) - 1;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <MapView
        ref={mapRef}
        style={StyleSheet.absoluteFill}
        mapType="standard"
        customMapStyle={DARK_MAP_STYLE}
        showsUserLocation
        initialRegion={{
          latitude: userLocation?.latitude ?? destination.latitude,
          longitude: userLocation?.longitude ?? destination.longitude,
          latitudeDelta: 0.02,
          longitudeDelta: 0.02,
        }}
      >
        {destination && (
          <Marker
            coordinate={destination}
            title="Customer"
            pinColor={SKY}
          />
        )}
        {route && route.polyline && route.polyline.length > 0 && (
          <Polyline
            coordinates={route.polyline.map((p) => ({
              latitude: p.latitude,
              longitude: p.longitude,
            }))}
            strokeColor={SKY}
            strokeWidth={5}
            lineCap="round"
            lineJoin="round"
          />
        )}
      </MapView>

      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top + 8 }]}>
        <TouchableOpacity onPress={handleBack} style={styles.backButton} hitSlop={12}>
          <Ionicons name="chevron-back" size={28} color="#FFF" />
        </TouchableOpacity>
        <Text style={styles.headerTitle} numberOfLines={1}>
          {address || 'Customer location'}
        </Text>
      </View>

      {/* Turn-by-turn card */}
      <View style={[styles.card, { bottom: insets.bottom + 24 }]}>
        <LinearGradient
          colors={['rgba(0,0,0,0.92)', 'rgba(0,0,0,0.88)']}
          style={styles.cardGradient}
        >
          {currentStep && (
            <>
              <View style={styles.cardRow}>
                <Ionicons name="navigate" size={24} color={SKY} />
                <Text style={styles.instruction} numberOfLines={2}>
                  {currentStep.instruction || (isLastStep ? 'Arrive at destination' : 'Continue')}
                </Text>
              </View>
              <View style={styles.metrics}>
                <Text style={styles.distanceLabel}>Distance to next step</Text>
                <Text style={styles.distanceValue}>{formatDistance(distanceToNext)}</Text>
              </View>
              {route && (
                <View style={styles.etaRow}>
                  <Text style={styles.etaLabel}>Remaining</Text>
                  <Text style={styles.etaValue}>
                    {formatTime(route.expectedTravelTimeSeconds)} • {formatDistance(route.distanceMeters)}
                  </Text>
                </View>
              )}
            </>
          )}
        </LinearGradient>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  loadingText: {
    marginTop: 12,
    fontSize: 16,
    color: '#94A3B8',
  },
  errorText: {
    fontSize: 16,
    color: '#E2E8F0',
    textAlign: 'center',
    marginBottom: 16,
  },
  button: {
    paddingVertical: 12,
    paddingHorizontal: 24,
    marginTop: 8,
  },
  buttonText: {
    color: SKY,
    fontSize: 16,
  },
  primaryButton: {
    backgroundColor: SKY,
    paddingVertical: 14,
    paddingHorizontal: 28,
    borderRadius: 12,
    marginTop: 8,
  },
  primaryButtonText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '600',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 8,
    paddingBottom: 8,
  },
  backButton: {
    padding: 4,
  },
  headerTitle: {
    flex: 1,
    fontSize: 17,
    color: '#FFF',
    marginLeft: 8,
  },
  card: {
    position: 'absolute',
    left: 20,
    right: 20,
    borderRadius: 16,
    overflow: 'hidden',
  },
  cardGradient: {
    padding: 20,
  },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  instruction: {
    flex: 1,
    fontSize: 17,
    color: '#F1F5F9',
    marginLeft: 12,
  },
  metrics: {
    marginBottom: 8,
  },
  distanceLabel: {
    fontSize: 12,
    color: '#94A3B8',
    marginBottom: 2,
  },
  distanceValue: {
    fontSize: 24,
    fontWeight: '700',
    color: SKY,
  },
  etaRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  etaLabel: {
    fontSize: 12,
    color: '#94A3B8',
  },
  etaValue: {
    fontSize: 14,
    color: '#CBD5E1',
  },
});
