import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  TextInput,
  Switch,
  ScrollView,
  StatusBar,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import LoadingView from '../../../src/components/shared/LoadingView';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { getTextColors, getBackgroundColors } from '../../../src/constants/themeColors';

const { width } = Dimensions.get('window');

interface DaySchedule {
  enabled: boolean;
  startTime: string;
  endTime: string;
}

interface AvailabilitySchedule {
  monday: DaySchedule;
  tuesday: DaySchedule;
  wednesday: DaySchedule;
  thursday: DaySchedule;
  friday: DaySchedule;
  saturday: DaySchedule;
  sunday: DaySchedule;
}

const DEFAULT_AVAILABILITY: AvailabilitySchedule = {
  monday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  tuesday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  wednesday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  thursday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  friday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  saturday: { enabled: true, startTime: '09:00', endTime: '17:00' },
  sunday: { enabled: false, startTime: '09:00', endTime: '17:00' },
};

const DAY_ORDER: (keyof AvailabilitySchedule)[] = ['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'];
const DAY_LABELS: Record<keyof AvailabilitySchedule, string> = {
  monday: 'Monday',
  tuesday: 'Tuesday',
  wednesday: 'Wednesday',
  thursday: 'Thursday',
  friday: 'Friday',
  saturday: 'Saturday',
  sunday: 'Sunday',
};

/** Parse "HH:MM" (24h) to minutes since midnight; invalid returns 0 */
function timeToMinutes(t: string): number {
  const [h, m] = (t || '').split(':').map(Number);
  if (!Number.isFinite(h) || !Number.isFinite(m)) return 0;
  return h * 60 + m;
}

/** Normalize 24h "HH:MM" for display (schedules show 24h, no am/pm) */
function format24Display(t: string): string {
  const [hStr, mStr] = (t || '').split(':');
  const h = parseInt(hStr || '0', 10);
  const m = parseInt(mStr || '0', 10);
  if (!Number.isFinite(h) || !Number.isFinite(m)) return '';
  const hh = h >= 0 && h <= 23 ? (h < 10 ? `0${h}` : String(h)) : '';
  const mm = m >= 0 && m <= 59 ? (m < 10 ? `0${m}` : String(m)) : '';
  return hh && mm ? `${hh}:${mm}` : '';
}

/** Parse time input: 12h "9:00 AM" / "6:30 pm" or 24h "09:00" / "18:00" to 24h "HH:MM" */
function parseTimeTo24(input: string): string | null {
  const raw = (input || '').trim();
  if (!raw) return null;
  const amPmMatch = raw.match(/^(\d{1,2})(?::(\d{1,2}))?\s*(am|pm)$/i);
  if (amPmMatch) {
    let h = parseInt(amPmMatch[1], 10);
    const m = amPmMatch[2] != null ? parseInt(amPmMatch[2], 10) : 0;
    if (!Number.isFinite(h) || h < 1 || h > 12) return null;
    if (!Number.isFinite(m) || m < 0 || m > 59) return null;
    const isPm = (amPmMatch[3] || '').toLowerCase() === 'pm';
    if (h === 12) h = isPm ? 12 : 0;
    else if (isPm) h += 12;
    const hh = h < 10 ? `0${h}` : String(h);
    const mm = m < 10 ? `0${m}` : String(m);
    return `${hh}:${mm}`;
  }
  const h24Match = raw.match(/^(\d{1,2}):(\d{1,2})$/);
  if (h24Match) {
    const h = parseInt(h24Match[1], 10);
    const m = parseInt(h24Match[2], 10);
    if (!Number.isFinite(h) || h < 0 || h > 23 || !Number.isFinite(m) || m < 0 || m > 59) return null;
    const hh = h < 10 ? `0${h}` : String(h);
    const mm = m < 10 ? `0${m}` : String(m);
    return `${hh}:${mm}`;
  }
  return null;
}

// Backward compatibility (avoid "format24to12 doesn't exist" if bundle was cached)
const format24to12 = format24Display;
const parse12to24 = parseTimeTo24;

/** Format minutes to "Xh Ym" */
function formatHoursMinutes(totalMinutes: number): string {
  if (totalMinutes <= 0) return '0h 0m';
  const h = Math.floor(totalMinutes / 60);
  const m = totalMinutes % 60;
  if (m === 0) return `${h}h`;
  if (h === 0) return `${m}m`;
  return `${h}h ${m}m`;
}

export default function WorkingHours() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { mode } = useAccountTheme();
  const theme = getAccountTheme('valeter', mode);
  const pageBg = theme.background;
  const primaryColor = theme.primary;
  const isLight = theme.mode === 'light';
  const iconColor = primaryColor;
  const textColors = getTextColors(theme);
  const bgColors = getBackgroundColors(theme);
  const placeholderColor = textColors.placeholder;

  const [loading, setLoading] = useState(true);
  const [availabilitySchedule, setAvailabilitySchedule] = useState<AvailabilitySchedule>(DEFAULT_AVAILABILITY);
  const [saving, setSaving] = useState(false);
  /** Per-day, per-field editing buffer so partial input (e.g. "9" or "9:0") is visible until valid 24h */
  const [editingTimes, setEditingTimes] = useState<Record<string, { start?: string; end?: string }>>({});

  const fadeAnim = useRef(new Animated.Value(0)).current;

  const weeklySummary = useMemo(() => {
    let totalMinutes = 0;
    let daysActive = 0;
    DAY_ORDER.forEach((day) => {
      const s = availabilitySchedule[day];
      if (!s.enabled) return;
      daysActive += 1;
      const start = timeToMinutes(s.startTime);
      const end = timeToMinutes(s.endTime);
      if (end > start) totalMinutes += end - start;
    });
    return { totalMinutes, daysActive, formatted: formatHoursMinutes(totalMinutes) };
  }, [availabilitySchedule]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadAvailabilitySchedule();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadAvailabilitySchedule = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const { data: profile, error } = await supabase
        .from('valeter_profiles')
        .select('availability_schedule')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;

      if (profile?.availability_schedule) {
        setAvailabilitySchedule(profile.availability_schedule as AvailabilitySchedule);
      }
      setEditingTimes({});
    } catch (error) {
      console.error('Error loading availability schedule:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDayToggle = async (day: keyof AvailabilitySchedule) => {
    try {
      await hapticFeedback('light');
      const newSchedule = {
        ...availabilitySchedule,
        [day]: { ...availabilitySchedule[day], enabled: !availabilitySchedule[day].enabled },
      };
      setAvailabilitySchedule(newSchedule);

      if (user?.id) {
        setSaving(true);
        const { error } = await supabase
          .from('valeter_profiles')
          .update({ availability_schedule: newSchedule })
          .eq('user_id', user.id);
        
        if (error) throw error;
        setSaving(false);
      }
    } catch (error) {
      console.error('Error updating availability schedule:', error);
      setSaving(false);
    }
  };

  const handleTimeChange = async (day: keyof AvailabilitySchedule, field: 'startTime' | 'endTime', value: string) => {
    try {
      // Value is 24h "HH:MM"; allow empty
      const timeRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
      if (value !== '' && !timeRegex.test(value)) {
        return;
      }

      const newSchedule = {
        ...availabilitySchedule,
        [day]: { ...availabilitySchedule[day], [field]: value },
      };
      setAvailabilitySchedule(newSchedule);

      // Auto-save after a delay
      if (user?.id) {
        setTimeout(async () => {
          setSaving(true);
          const { error } = await supabase
            .from('valeter_profiles')
            .update({ availability_schedule: newSchedule })
            .eq('user_id', user.id);
          
          if (error) {
            console.error('Error updating time:', error);
          }
          setSaving(false);
        }, 1000);
      }
    } catch (error) {
      console.error('Error updating time:', error);
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, { backgroundColor: pageBg[0] }]}>
        <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: pageBg[0] }]} edges={[]}>
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} backgroundColor="transparent" translucent />
      <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader title="Hours" subtitle="Availability" accountType="valeter" />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollContent,
            {
              paddingTop: HEADER_CONTENT_OFFSET + 16,
              paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
              flexGrow: 1,
            },
          ]}
          keyboardShouldPersistTaps="handled"
          decelerationRate="fast"
        >
          {/* Weekly summary */}
          <GlassCard style={styles.summaryCard} accountType="valeter">
            <LinearGradient colors={[`${primaryColor}18`, `${primaryColor}08`]} style={StyleSheet.absoluteFill} />
            <View style={styles.summaryRow}>
              <View style={styles.summaryItem}>
                <View style={styles.summaryIconWrap}>
                  <Ionicons name="time" size={22} color={iconColor} />
                </View>
                <Text style={[styles.summaryValue, { color: textColors.primary }]}>{weeklySummary.formatted}</Text>
                <Text style={[styles.summaryLabel, { color: textColors.secondary }]}>This week</Text>
              </View>
              <View style={styles.summaryDivider} />
              <View style={styles.summaryItem}>
                <View style={styles.summaryIconWrap}>
                  <Ionicons name="calendar" size={22} color={iconColor} />
                </View>
                <Text style={[styles.summaryValue, { color: textColors.primary }]}>{weeklySummary.daysActive}</Text>
                <Text style={[styles.summaryLabel, { color: textColors.secondary }]}>Days active</Text>
              </View>
            </View>
          </GlassCard>

          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <View style={styles.sectionHeaderIcon}>
                <Ionicons name="calendar-outline" size={22} color={iconColor} />
              </View>
              <View style={styles.sectionHeaderText}>
                <Text style={[styles.sectionTitle, { color: textColors.primary }]}>Your schedule</Text>
                <Text style={[styles.sectionSubtitle, { color: textColors.secondary }]}>Customers see when you're available. Toggle off for days you don't work.</Text>
              </View>
            </View>

            <GlassCard style={styles.scheduleCard} accountType="valeter">
              <LinearGradient colors={[`${primaryColor}12`, `${primaryColor}04`]} style={StyleSheet.absoluteFill} />
              {DAY_ORDER.map((day, index) => {
                const schedule = availabilitySchedule[day];
                const label = DAY_LABELS[day];
                const dayAbbr = label.substring(0, 3);
                const isWeekend = day === 'saturday' || day === 'sunday';

                return (
                  <View key={day}>
                    <TouchableOpacity
                      style={[
                        styles.scheduleDayCard,
                        schedule.enabled && styles.scheduleDayCardActive,
                        index === 6 && { marginBottom: 0 },
                      ]}
                      activeOpacity={0.8}
                    >
                      <View style={styles.scheduleDayContent}>
                        <View style={styles.scheduleDayLeft}>
                          <View style={[styles.scheduleDayBadge, schedule.enabled && styles.scheduleDayBadgeActive, isWeekend && !schedule.enabled && styles.scheduleDayBadgeWeekend]}>
                            <Text style={[styles.scheduleDayAbbr, schedule.enabled && styles.scheduleDayAbbrActive]}>
                              {dayAbbr}
                            </Text>
                          </View>
                        </View>

                        <View style={styles.scheduleMiddleSection}>
                          {schedule.enabled ? (
                            <View style={styles.scheduleTimeContainer}>
                              <BlurView intensity={40} tint={isLight ? 'light' : 'dark'} style={styles.scheduleTimeInputWrap}>
                                <TextInput
                                  value={editingTimes[day]?.start ?? format24Display(schedule.startTime)}
                                  onChangeText={(text) => {
                                    setEditingTimes((prev) => ({ ...prev, [day]: { ...(prev[day] || {}), start: text } }));
                                    const v = parseTimeTo24(text);
                                    if (v != null) {
                                      handleTimeChange(day, 'startTime', v);
                                      setEditingTimes((prev) => ({ ...prev, [day]: { ...(prev[day] || {}), start: undefined } }));
                                    }
                                  }}
                                  onBlur={() => setEditingTimes((prev) => ({ ...prev, [day]: { ...(prev[day] || {}), start: undefined } }))}
                                  placeholder="09:00"
                                  placeholderTextColor={placeholderColor}
                                  style={styles.scheduleTimeInputText}
                                  keyboardType="numbers-and-punctuation"
                                  maxLength={8}
                                />
                              </BlurView>
                              <Text style={styles.scheduleTimeSeparator}>–</Text>
                              <BlurView intensity={40} tint={isLight ? 'light' : 'dark'} style={styles.scheduleTimeInputWrap}>
                                <TextInput
                                  value={editingTimes[day]?.end ?? format24Display(schedule.endTime)}
                                  onChangeText={(text) => {
                                    setEditingTimes((prev) => ({ ...prev, [day]: { ...(prev[day] || {}), end: text } }));
                                    const v = parseTimeTo24(text);
                                    if (v != null) {
                                      handleTimeChange(day, 'endTime', v);
                                      setEditingTimes((prev) => ({ ...prev, [day]: { ...(prev[day] || {}), end: undefined } }));
                                    }
                                  }}
                                  onBlur={() => setEditingTimes((prev) => ({ ...prev, [day]: { ...(prev[day] || {}), end: undefined } }))}
                                  placeholder="18:00"
                                  placeholderTextColor={placeholderColor}
                                  style={styles.scheduleTimeInputText}
                                  keyboardType="numbers-and-punctuation"
                                  maxLength={8}
                                />
                              </BlurView>
                            </View>
                          ) : (
                            <View style={styles.scheduleOffBadge}>
                              <Ionicons name="moon-outline" size={16} color="rgba(255,255,255,0.5)" />
                              <Text style={styles.scheduleOffText}>Off</Text>
                            </View>
                          )}
                        </View>

                        <View style={styles.scheduleToggleWrapper}>
                          <Switch
                            value={schedule.enabled}
                            onValueChange={() => handleDayToggle(day)}
                            trackColor={{ false: isLight ? 'rgba(11,60,93,0.2)' : 'rgba(255,255,255,0.2)', true: primaryColor }}
                            thumbColor="#FFFFFF"
                            ios_backgroundColor="rgba(255,255,255,0.2)"
                          />
                        </View>
                      </View>
                    </TouchableOpacity>
                    {index < 6 && <View style={styles.scheduleDivider} />}
                  </View>
                );
              })}
            </GlassCard>

            <Text style={[styles.scheduleDisclaimer, { color: textColors.tertiary }]}>
              This schedule is used for detailing bookings, not the bronze to platinum washes.
            </Text>

            {saving && (
              <View style={styles.savingIndicator}>
                <ActivityIndicator size="small" color={iconColor} />
                <Text style={[styles.savingText, { color: textColors.secondary }]}>Saving...</Text>
              </View>
            )}
          </View>
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: '#7DD3FC',
    fontSize: 14,
  },
  section: {
    marginBottom: 14,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 10,
  },
  sectionHeaderIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sectionHeaderText: {
    flex: 1,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  sectionSubtitle: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 13,
    lineHeight: 18,
  },
  summaryCard: {
    padding: 20,
    borderRadius: 20,
    marginBottom: 14,
    overflow: 'hidden',
  },
  summaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
  },
  summaryItem: {
    alignItems: 'center',
    flex: 1,
  },
  summaryIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },
  summaryValue: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: -0.3,
    marginBottom: 2,
  },
  summaryLabel: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    fontWeight: '600',
  },
  summaryDivider: {
    width: 1,
    height: 40,
    backgroundColor: 'rgba(135,206,235,0.25)',
  },
  scheduleCard: {
    padding: 16,
    borderRadius: 20,
    overflow: 'hidden',
  },
  scheduleDayCard: {
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  scheduleDayCardActive: {
    backgroundColor: 'rgba(135,206,235,0.1)',
  },
  scheduleDayContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  scheduleDayLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flexShrink: 0,
  },
  scheduleMiddleSection: {
    flex: 1,
    alignItems: 'stretch',
    justifyContent: 'center',
    minWidth: 0,
  },
  scheduleToggleWrapper: {
    width: 48,
    flexShrink: 0,
    alignItems: 'flex-end',
    justifyContent: 'center',
  },
  scheduleDayBadge: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  scheduleDayBadgeActive: {
    backgroundColor: 'rgba(135,206,235,0.25)',
  },
  scheduleDayBadgeWeekend: {
    backgroundColor: 'rgba(245,158,11,0.15)',
  },
  scheduleDayAbbr: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    fontWeight: '700',
  },
  scheduleDayAbbrActive: {
    color: '#7DD3FC',
  },
  scheduleTimeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
    minWidth: 0,
  },
  scheduleTimeInputWrap: {
    flex: 1,
    minWidth: 72,
    borderRadius: 10,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  scheduleTimeInputText: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    textAlign: 'center',
    paddingVertical: 10,
    paddingHorizontal: 8,
  },
  scheduleTimeSeparator: {
    color: '#7DD3FC',
    fontSize: 16,
    fontWeight: '700',
  },
  scheduleOffBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    flex: 1,
  },
  scheduleOffText: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 14,
    fontWeight: '600',
  },
  scheduleDivider: {
    height: 1,
    backgroundColor: 'rgba(135,206,235,0.1)',
    marginVertical: 8,
  },
  scheduleDisclaimer: {
    marginTop: 16,
    paddingHorizontal: 4,
    color: 'rgba(249,250,251,0.6)',
    fontSize: 13,
    lineHeight: 18,
    textAlign: 'center',
  },
  savingIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 16,
  },
  savingText: {
    color: '#7DD3FC',
    fontSize: 14,
  },
});
