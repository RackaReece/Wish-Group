import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert, StatusBar } from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import AppHeader from '../../../src/components/shared/AppHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { useGlobalTheme } from '../../../src/components/shared/GlobalThemeContext';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';

export default function ValeterAccountScreen() {
  const insets = useSafeAreaInsets();
  const { mode } = useGlobalTheme();
  const theme = getAccountTheme('valeter', mode);
  const pageBg = theme.background;
  const isLight = theme.mode === 'light';

  const handleDeleteAccount = async () => {
    try {
      await hapticFeedback('heavy');
      Alert.alert(
        'Delete account',
        'This will permanently remove your account and all data. This cannot be undone.',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Delete account',
            style: 'destructive',
            onPress: () => {
              // Placeholder: wire to real delete when backend supports it
              Alert.alert('Account deleted', 'Your account has been deleted.');
            },
          },
        ]
      );
    } catch {}
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: pageBg[0] }]} edges={[]}>
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} backgroundColor="transparent" translucent />
      <BubbleBackground accountType="valeter" />
      <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
      <AppHeader title="Account & data" accountType="valeter" />
      <View style={[styles.content, { paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24 }]}>
        <View style={styles.section}>
          <Text style={styles.sectionLabel}>Danger zone</Text>
          <GlassCard style={styles.deleteCard} accountType="valeter" borderColor="rgba(239,68,68,0.25)">
            <TouchableOpacity onPress={handleDeleteAccount} activeOpacity={0.85} style={styles.deleteTouch}>
              <View style={styles.deleteIconWrap}>
                <Ionicons name="trash-outline" size={22} color="#EF4444" />
              </View>
              <View style={styles.deleteTextWrap}>
                <Text style={styles.deleteTitle}>Delete account</Text>
                <Text style={styles.deleteSubtitle}>Permanently delete your account and all data. This cannot be undone.</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="rgba(239,68,68,0.8)" />
            </TouchableOpacity>
          </GlassCard>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, paddingHorizontal: 20, paddingTop: 16 },
  section: { gap: 10 },
  sectionLabel: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 13,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    paddingHorizontal: 4,
  },
  deleteCard: {
    padding: 0,
    overflow: 'hidden',
    backgroundColor: 'rgba(239,68,68,0.06)',
    borderWidth: 1,
  },
  deleteTouch: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    gap: 14,
  },
  deleteIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(239,68,68,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  deleteTextWrap: { flex: 1 },
  deleteTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 2,
  },
  deleteSubtitle: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 13,
    lineHeight: 18,
  },
});
