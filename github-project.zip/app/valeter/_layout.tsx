import { Stack } from 'expo-router';
import { AccountThemeProvider } from '../../src/components/shared/AccountThemeProvider';
import { ValeterNavStateProvider } from '../../src/contexts/ValeterNavStateContext';

export default function ValeterLayout() {
  return (
    <AccountThemeProvider accountType="valeter">
      <ValeterNavStateProvider>
        <Stack screenOptions={{ headerShown: false }} />
      </ValeterNavStateProvider>
    </AccountThemeProvider>
  );
}
