import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Switch,
  ScrollView,
  StatusBar,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import LoadingView from '../../../src/components/shared/LoadingView';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { useGlobalTheme } from '../../../src/components/shared/GlobalThemeContext';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import { getTextColors } from '../../../src/constants/themeColors';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import AsyncStorage from '@react-native-async-storage/async-storage';

const { width } = Dimensions.get('window');

interface NotificationPreferences {
  jobAlerts: boolean;
  sound: boolean;
  vibration: boolean;
  email: boolean;
}

const DEFAULT_NOTIFICATION_PREFS: NotificationPreferences = {
  jobAlerts: true,
  sound: true,
  vibration: true,
  email: false,
};

const getNotifPrefsKey = (userId: string) => `valeter:notif_prefs:${userId}`;

export default function ValeterNotificationPreferences() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { mode } = useGlobalTheme();
  const theme = getAccountTheme('valeter', mode);
  const pageBg = theme.background;
  const isLight = theme.mode === 'light';
  const primaryColor = theme.primary;
  const textColors = getTextColors(theme);
  const [loading, setLoading] = useState(true);
  const [notificationPrefs, setNotificationPrefs] = useState<NotificationPreferences>(DEFAULT_NOTIFICATION_PREFS);

  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadNotificationPreferencesLocal();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadNotificationPreferencesLocal = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const key = getNotifPrefsKey(user.id);
      const raw = await AsyncStorage.getItem(key);
      
      if (!raw) {
        setNotificationPrefs(DEFAULT_NOTIFICATION_PREFS);
        setLoading(false);
        return;
      }

      const parsed = JSON.parse(raw) as Partial<NotificationPreferences> | null;
      const merged: NotificationPreferences = {
        ...DEFAULT_NOTIFICATION_PREFS,
        ...(parsed || {}),
      };
      setNotificationPrefs(merged);
    } catch (error) {
      console.error('Error loading local notification preferences:', error);
      setNotificationPrefs(DEFAULT_NOTIFICATION_PREFS);
    } finally {
      setLoading(false);
    }
  };

  const saveNotificationPreferencesLocal = async (prefs: NotificationPreferences) => {
    if (!user?.id) return;
    try {
      const key = getNotifPrefsKey(user.id);
      await AsyncStorage.setItem(key, JSON.stringify(prefs));
    } catch (error) {
      console.error('Error saving local notification preferences:', error);
    }
  };

  const handleNotificationToggle = async (key: keyof NotificationPreferences) => {
    try {
      await hapticFeedback('light');
      const newPrefs: NotificationPreferences = { ...notificationPrefs, [key]: !notificationPrefs[key] };
      setNotificationPrefs(newPrefs);
      await saveNotificationPreferencesLocal(newPrefs);
    } catch (error) {
      console.error('Error updating local notification preferences:', error);
    }
  };

  if (loading) {
    return (
      <View style={[styles.container, { backgroundColor: pageBg[0] }]}>
        <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: pageBg[0] }]} edges={[]}>
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} backgroundColor="transparent" translucent />
      <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader title="Alerts" accountType="valeter" />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollContent,
            {
              paddingTop: HEADER_CONTENT_OFFSET + 20,
            },
          ]}
        >
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <View style={styles.sectionHeaderIcon}>
                <Ionicons name="notifications-outline" size={24} color={primaryColor} />
              </View>
              <View style={styles.sectionHeaderText}>
                <Text style={[styles.sectionTitle, { color: textColors.primary }]}>Notification Preferences</Text>
                <Text style={[styles.sectionSubtitle, { color: textColors.secondary }]}>Control how and when you receive alerts</Text>
              </View>
            </View>
            
            <GlassCard style={styles.settingsCard} accountType="valeter">
              <LinearGradient
                colors={['rgba(135,206,235,0.08)', 'rgba(135,206,235,0.02)']}
                style={StyleSheet.absoluteFill}
              />
              
              {/* Job Alerts - Featured */}
              <View style={styles.featuredToggleRow}>
                <LinearGradient
                  colors={notificationPrefs.jobAlerts 
                    ? ['rgba(16,185,129,0.15)', 'rgba(16,185,129,0.05)']
                    : ['rgba(255,255,255,0.05)', 'rgba(255,255,255,0.02)']
                  }
                  style={styles.featuredToggleBackground}
                >
                  <View style={styles.featuredToggleContent}>
                    <View style={styles.featuredToggleLeft}>
                      <View style={[styles.featuredIconWrapper, notificationPrefs.jobAlerts && styles.featuredIconWrapperActive]}>
                        <Ionicons name="briefcase" size={22} color={notificationPrefs.jobAlerts ? (isLight ? primaryColor : '#10B981') : primaryColor} />
                      </View>
                      <View style={styles.featuredToggleText}>
                        <Text style={[styles.featuredToggleLabel, { color: textColors.primary }]}>Job Request Alerts</Text>
                        <Text style={[styles.featuredToggleDescription, { color: textColors.secondary }]}>Get notified about new job opportunities</Text>
                      </View>
                    </View>
                    <Switch
                      value={notificationPrefs.jobAlerts}
                      onValueChange={() => handleNotificationToggle('jobAlerts')}
                      trackColor={{ false: isLight ? 'rgba(125,211,252,0.25)' : 'rgba(255,255,255,0.2)', true: primaryColor }}
                      thumbColor="#FFFFFF"
                      ios_backgroundColor={isLight ? 'rgba(125,211,252,0.25)' : 'rgba(255,255,255,0.2)'}
                    />
                  </View>
                </LinearGradient>
              </View>

              {/* Other Preferences */}
              <View style={styles.preferencesGrid}>
                <TouchableOpacity
                  style={styles.preferenceCard}
                  onPress={() => handleNotificationToggle('sound')}
                  activeOpacity={0.7}
                >
                  <View style={[styles.preferenceIconBox, notificationPrefs.sound && styles.preferenceIconBoxActive]}>
                    <Ionicons name="volume-high" size={20} color={notificationPrefs.sound ? (isLight ? primaryColor : '#10B981') : primaryColor} />
                  </View>
                  <Text style={[styles.preferenceLabel, { color: textColors.primary }]}>Sound</Text>
                  <Switch
                    value={notificationPrefs.sound}
                    onValueChange={() => handleNotificationToggle('sound')}
                    trackColor={{ false: isLight ? 'rgba(125,211,252,0.25)' : 'rgba(255,255,255,0.2)', true: primaryColor }}
                    thumbColor="#FFFFFF"
                    ios_backgroundColor={isLight ? 'rgba(125,211,252,0.25)' : 'rgba(255,255,255,0.2)'}
                  />
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.preferenceCard}
                  onPress={() => handleNotificationToggle('vibration')}
                  activeOpacity={0.7}
                >
                  <View style={[styles.preferenceIconBox, notificationPrefs.vibration && styles.preferenceIconBoxActive]}>
                    <Ionicons name="phone-portrait" size={20} color={notificationPrefs.vibration ? (isLight ? primaryColor : '#10B981') : primaryColor} />
                  </View>
                  <Text style={[styles.preferenceLabel, { color: textColors.primary }]}>Vibration</Text>
                  <Switch
                    value={notificationPrefs.vibration}
                    onValueChange={() => handleNotificationToggle('vibration')}
                    trackColor={{ false: isLight ? 'rgba(125,211,252,0.25)' : 'rgba(255,255,255,0.2)', true: primaryColor }}
                    thumbColor="#FFFFFF"
                    ios_backgroundColor={isLight ? 'rgba(125,211,252,0.25)' : 'rgba(255,255,255,0.2)'}
                  />
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.preferenceCard}
                  onPress={() => handleNotificationToggle('email')}
                  activeOpacity={0.7}
                >
                  <View style={[styles.preferenceIconBox, notificationPrefs.email && styles.preferenceIconBoxActive]}>
                    <Ionicons name="mail" size={20} color={notificationPrefs.email ? (isLight ? primaryColor : '#10B981') : primaryColor} />
                  </View>
                  <Text style={[styles.preferenceLabel, { color: textColors.primary }]}>Email</Text>
                  <Switch
                    value={notificationPrefs.email}
                    onValueChange={() => handleNotificationToggle('email')}
                    trackColor={{ false: isLight ? 'rgba(125,211,252,0.25)' : 'rgba(255,255,255,0.2)', true: primaryColor }}
                    thumbColor="#FFFFFF"
                    ios_backgroundColor={isLight ? 'rgba(125,211,252,0.25)' : 'rgba(255,255,255,0.2)'}
                  />
                </TouchableOpacity>
              </View>
            </GlassCard>
          </View>
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: '#7DD3FC',
    fontSize: 14,
  },
  section: {
    marginBottom: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
    gap: 12,
  },
  sectionHeaderIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sectionHeaderText: {
    flex: 1,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  sectionSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
  },
  settingsCard: {
    padding: 20,
  },
  featuredToggleRow: {
    marginBottom: 14,
  },
  featuredToggleBackground: {
    borderRadius: 16,
    padding: 16,
  },
  featuredToggleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  featuredToggleLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  featuredIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  featuredIconWrapperActive: {
    backgroundColor: 'rgba(16,185,129,0.2)',
  },
  featuredToggleText: {
    flex: 1,
  },
  featuredToggleLabel: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 4,
  },
  featuredToggleDescription: {
    color: '#94A3B8',
    fontSize: 13,
  },
  preferencesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  preferenceCard: {
    flex: 1,
    minWidth: (width - 60) / 3,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 16,
    alignItems: 'center',
    gap: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.1)',
  },
  preferenceIconBox: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  preferenceIconBoxActive: {
    backgroundColor: 'rgba(16,185,129,0.2)',
  },
  preferenceLabel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
});
