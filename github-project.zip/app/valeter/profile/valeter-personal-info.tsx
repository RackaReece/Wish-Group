import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Dimensions,
  ActivityIndicator,
  StatusBar,
  Alert,
  Switch,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';

import { colors } from '../../../src/constants/colors';
import { textStyles } from '../../../src/constants/typography';
import LoadingView from '../../../src/components/shared/LoadingView';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { useGlobalTheme } from '../../../src/components/shared/GlobalThemeContext';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import { getTextColors, getBackgroundColors } from '../../../src/constants/themeColors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

const PRESET_BIOS = [
  { id: 'mobile', label: 'Professional mobile valeter', value: 'Professional mobile valeter' },
  { id: 'hybrid', label: 'Hybrid valeter', value: 'Hybrid valeter – mobile and static services' },
  { id: 'static', label: 'Static valeter', value: 'Static valeter – fixed location services' },
] as const;

interface ValeterProfileData {
  user_id: string;
  full_name: string;
  bio?: string;
  experience?: string;
  profile_photo_url?: string;
  is_self_sufficient?: boolean;
  phone?: string;
  date_of_birth?: string;
}

export default function ValeterPersonalInfo() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { mode } = useGlobalTheme();
  const theme = getAccountTheme('valeter', mode);
  const pageBg = theme.background;
  const primaryColor = theme.primary;
  const isLight = theme.mode === 'light';
  const textColors = getTextColors(theme);
  const bgColors = getBackgroundColors(theme);
  const placeholderColor = textColors.placeholder;
  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [email, setEmail] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [useCustomBio, setUseCustomBio] = useState(false);

  useEffect(() => {
    if (user?.id) {
      loadProfile();
    }
  }, [user?.id]);

  const loadProfile = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('valeter_profiles')
        .select('*')
        .eq('user_id', user!.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setProfile(data);
        const isPreset = PRESET_BIOS.some((p) => p.value === (data.bio || '').trim());
        setUseCustomBio(data.bio ? !isPreset : false);
      } else {
        const newProfile: Partial<ValeterProfileData> = {
          user_id: user!.id,
          full_name: user!.name || 'Valeter',
          bio: 'Professional mobile valeter',
          experience: '0 years',
          phone: '',
          date_of_birth: '',
        };

        const { data: created, error: createError } = await supabase
          .from('valeter_profiles')
          .insert(newProfile)
          .select()
          .single();

        if (createError) throw createError;
        setProfile(created);
      }

      setEmail(user!.email || '');
    } catch (error: any) {
      console.error('Error loading profile:', error);
      Alert.alert('Error', 'Failed to load profile information');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!user?.id || !profile) return;

    try {
      setIsSaving(true);
      const { error } = await supabase
        .from('valeter_profiles')
        .update({
          full_name: profile.full_name,
          bio: profile.bio,
          experience: profile.experience,
          is_self_sufficient: profile.is_self_sufficient,
        })
        .eq('user_id', user.id);

      if (error) throw error;

      Alert.alert('Success', 'Profile updated successfully');
      setIsEditing(false);
    } catch (error: any) {
      console.error('Error saving profile:', error);
      Alert.alert('Error', error.message || 'Failed to save profile');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  if (!profile) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Failed to load profile</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: pageBg[0] }]}>
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} backgroundColor="transparent" translucent />
      <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />
      <AppHeader
        title="Personal Info"
        accountType="valeter"
        onBack={async () => {
          await hapticFeedback('light');
          router.back();
        }}
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              setIsEditing(!isEditing);
            }}
            activeOpacity={0.7}
            style={styles.headerEditButton}
          >
            <Ionicons name={isEditing ? 'close' : 'create'} size={20} color={primaryColor} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24 },
        ]}
        decelerationRate="fast"
        keyboardShouldPersistTaps="handled"
      >
        {/* Profile completeness */}
        {(() => {
          const fields = [!!profile.full_name?.trim(), !!profile.bio?.trim(), !!profile.experience?.trim(), !!profile.phone?.trim(), !!profile.date_of_birth?.trim()];
          const filled = fields.filter(Boolean).length;
          const pct = Math.round((filled / fields.length) * 100);
          return (
            <View style={styles.completionCard}>
              <View style={styles.completionHeader}>
                <Ionicons name="checkmark-circle-outline" size={18} color={colors.SKY} />
                <Text style={[textStyles.sectionTitle, { color: '#F9FAFB', marginBottom: 0, fontSize: 16 }]}>Profile completeness</Text>
              </View>
              <View style={styles.completionBar}>
                <View style={[styles.completionFill, { width: `${pct}%` }]} />
              </View>
            </View>
          );
        })()}

        <View style={styles.section}>
          <View style={styles.settingsContainer}>
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="person" size={20} color={colors.SKY} />
                <Text style={styles.settingText}>Name</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.full_name}
                  onChangeText={(text) => setProfile({ ...profile, full_name: text })}
                  placeholder="Enter your name"
                  placeholderTextColor={placeholderColor}
                />
              ) : (
                <Text style={styles.settingValue}>{profile.full_name}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="mail" size={20} color={colors.SKY} />
                <Text style={styles.settingText}>Email</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={email}
                  onChangeText={setEmail}
                  placeholder="Enter your email"
                  placeholderTextColor={placeholderColor}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              ) : (
                <Text style={styles.settingValue}>{user?.email || 'No email'}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="call" size={20} color={colors.SKY} />
                <Text style={styles.settingText}>Mobile number</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.phone || ''}
                  onChangeText={(text) => setProfile({ ...profile, phone: text })}
                  placeholder="e.g. 07123456789"
                  placeholderTextColor={placeholderColor}
                  keyboardType="phone-pad"
                />
              ) : (
                <Text style={styles.settingValue}>{profile.phone || 'Not set'}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="calendar" size={20} color={colors.SKY} />
                <Text style={styles.settingText}>Date of birth</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.date_of_birth || ''}
                  onChangeText={(text) => setProfile({ ...profile, date_of_birth: text })}
                  placeholder="e.g. 15/03/1990"
                  placeholderTextColor={placeholderColor}
                  keyboardType="numbers-and-punctuation"
                />
              ) : (
                <Text style={styles.settingValue}>{profile.date_of_birth || 'Not set'}</Text>
              )}
            </View>

            <View style={[styles.settingItem, isEditing && styles.settingItemBio]}>
              <View style={styles.settingLeft}>
                <Ionicons name="document-text" size={20} color={colors.SKY} />
                <Text style={styles.settingText}>Bio</Text>
              </View>
              {isEditing ? (
                <View style={styles.bioEditContainer}>
                  <View style={styles.presetBioRow}>
                    {PRESET_BIOS.map((preset) => {
                      const isSelected = !useCustomBio && (profile.bio || '').trim() === preset.value;
                      return (
                        <TouchableOpacity
                          key={preset.id}
                          style={[styles.presetBioChip, isSelected && styles.presetBioChipSelected]}
                          onPress={async () => {
                            await hapticFeedback('light');
                            setProfile({ ...profile, bio: preset.value });
                            setUseCustomBio(false);
                          }}
                          activeOpacity={0.7}
                        >
                          <Text style={[styles.presetBioLabel, isSelected && styles.presetBioLabelSelected]} numberOfLines={1}>
                            {preset.label}
                          </Text>
                          {isSelected && <Ionicons name="checkmark-circle" size={16} color={colors.SKY} style={{ marginLeft: 6 }} />}
                        </TouchableOpacity>
                      );
                    })}
                  </View>
                  <TouchableOpacity
                    style={[styles.presetBioChip, useCustomBio && styles.presetBioChipSelected]}
                    onPress={async () => {
                      await hapticFeedback('light');
                      setUseCustomBio(true);
                      if (!profile.bio || PRESET_BIOS.some((p) => p.value === (profile.bio || '').trim())) {
                        setProfile({ ...profile, bio: '' });
                      }
                    }}
                    activeOpacity={0.7}
                  >
                    <Text style={[styles.presetBioLabel, useCustomBio && styles.presetBioLabelSelected]}>Custom</Text>
                    {useCustomBio && <Ionicons name="checkmark-circle" size={16} color={colors.SKY} style={{ marginLeft: 6 }} />}
                  </TouchableOpacity>
                  {useCustomBio && (
                    <TextInput
                      style={[styles.settingInput, styles.bioInput]}
                      value={profile.bio || ''}
                      onChangeText={(text) => setProfile({ ...profile, bio: text })}
                      placeholder="Tell customers about yourself"
                      placeholderTextColor={placeholderColor}
                      multiline
                      autoFocus
                    />
                  )}
                </View>
              ) : (
                <Text style={styles.settingValue}>{profile.bio || 'No bio added'}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="time" size={20} color={colors.SKY} />
                <Text style={styles.settingText}>Experience</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.experience || ''}
                  onChangeText={(text) => setProfile({ ...profile, experience: text })}
                  placeholder="e.g., 3+ years"
                  placeholderTextColor={placeholderColor}
                />
              ) : (
                <Text style={styles.settingValue}>{profile.experience || 'Not specified'}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="battery-charging" size={20} color={primaryColor} style={styles.settingIcon} />
                <View style={styles.settingTextContainer}>
                  <Text style={styles.settingText}>Self-Sufficient</Text>
                  <Text style={styles.settingSubtext}>I have my own water and electricity</Text>
                </View>
              </View>
              <Switch
                value={profile.is_self_sufficient ?? false}
                onValueChange={async (value) => {
                  await hapticFeedback('light');
                  const updatedProfile = { ...profile, is_self_sufficient: value };
                  setProfile(updatedProfile);
                  // Auto-save when toggled
                  if (user?.id) {
                    try {
                      await supabase
                        .from('valeter_profiles')
                        .update({ is_self_sufficient: value })
                        .eq('user_id', user.id);
                    } catch (error) {
                      console.error('Error saving self-sufficiency:', error);
                    }
                  }
                }}
                trackColor={{ false: isLight ? 'rgba(125,211,252,0.3)' : 'rgba(135,206,235,0.3)', true: primaryColor }}
                thumbColor="#FFFFFF"
              />
            </View>
          </View>
        </View>

        {/* Save Button */}
        {isEditing && (
          <View style={styles.section}>
            <TouchableOpacity
              style={[styles.saveButton, isSaving && { opacity: 0.6 }]}
              onPress={handleSaveProfile}
              disabled={isSaving}
            >
              <LinearGradient
                colors={['#10B981', '#059669']}
                style={styles.saveButtonGradient}
              >
                {isSaving ? (
                  <ActivityIndicator color="#FFFFFF" />
                ) : (
                  <Text style={styles.saveButtonText}>Save Changes</Text>
                )}
              </LinearGradient>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#FFFFFF',
    marginTop: 8,
  },
  headerEditButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    paddingTop: HEADER_CONTENT_OFFSET,
    paddingHorizontal: 20,
  },
  section: {
    marginBottom: 14,
  },
  settingsContainer: {
    gap: 8,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 8,
  },
  settingIcon: {
    marginRight: 0,
  },
  completionCard: {
    padding: 16,
    marginBottom: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    gap: 10,
  },
  completionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  completionBar: {
    height: 5,
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.15)',
    overflow: 'hidden',
  },
  completionFill: {
    height: '100%',
    borderRadius: 3,
    backgroundColor: colors.SKY,
  },
  settingText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
  },
  settingTextContainer: {
    flex: 1,
  },
  settingSubtext: {
    color: '#9CA3AF',
    fontSize: 11,
    marginTop: 2,
  },
  settingValue: {
    color: colors.SKY,
    fontSize: 13,
    textAlign: 'right',
    flex: 1,
  },
  settingInput: {
    color: '#F9FAFB',
    fontSize: 13,
    textAlign: 'right',
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: colors.SKY,
    paddingVertical: 4,
  },
  bioInput: {
    height: 60,
    textAlignVertical: 'top',
  },
  settingItemBio: {
    flexDirection: 'column',
    alignItems: 'stretch',
  },
  bioEditContainer: {
    width: '100%',
    marginTop: 12,
    gap: 10,
  },
  presetBioRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  presetBioChip: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  presetBioChipSelected: {
    borderColor: colors.SKY,
    backgroundColor: 'rgba(135,206,235,0.15)',
  },
  presetBioLabel: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 14,
    fontWeight: '600',
  },
  presetBioLabelSelected: {
    color: colors.SKY,
    fontWeight: '700',
  },
  saveButton: {
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  saveButtonGradient: {
    paddingVertical: 16,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});

