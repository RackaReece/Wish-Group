// app/valeter/profile/valeter-profile.tsx

import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Image,
  Dimensions,
  ActivityIndicator,
  Animated,
  StatusBar,
  TextInput,
  Switch,
  Pressable,
  ScrollView,
  Platform,
  KeyboardAvoidingView,
  ActionSheetIOS,
  Modal,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { ValeterStatsService, ValeterPerformanceStats } from '../../../src/services/ValeterStatsService';
import { ValeterTierService, ValeterTier } from '../../../src/services/ValeterTierService';
import * as ImagePicker from 'expo-image-picker';
import { supabase } from '../../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import LoadingView from '../../../src/components/shared/LoadingView';
import ErrorView from '../../../src/components/shared/ErrorView';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { getIconAccentColors } from '../../../src/constants/themeColors';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import * as FileSystem from 'expo-file-system/legacy';
import { simpleDocumentUploadService } from '../../../src/services/SimpleDocumentUploadService';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { isMissingTableErr } from '../../../src/utils/dbHelpers';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

interface NotificationPreferences {
  jobAlerts: boolean;
  sound: boolean;
  vibration: boolean;
  email: boolean;
}

interface DaySchedule {
  enabled: boolean;
  startTime: string;
  endTime: string;
}

interface AvailabilitySchedule {
  monday: DaySchedule;
  tuesday: DaySchedule;
  wednesday: DaySchedule;
  thursday: DaySchedule;
  friday: DaySchedule;
  saturday: DaySchedule;
  sunday: DaySchedule;
}

const DEFAULT_NOTIFICATION_PREFS: NotificationPreferences = {
  jobAlerts: true,
  sound: true,
  vibration: true,
  email: false,
};

const DEFAULT_AVAILABILITY: AvailabilitySchedule = {
  monday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  tuesday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  wednesday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  thursday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  friday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  saturday: { enabled: true, startTime: '09:00', endTime: '17:00' },
  sunday: { enabled: false, startTime: '09:00', endTime: '17:00' },
};

const getNotifPrefsKey = (userId: string) => `valeter:notif_prefs:${userId}`;

interface ValeterProfileData {
  user_id: string;
  full_name: string;
  bio?: string;
  experience?: string;
  profile_photo_url?: string;
  vehicle_make?: string;
  vehicle_model?: string;
  vehicle_registration?: string;
  verification_status: 'pending' | 'verified' | 'rejected';
  verification_badge: boolean;
  is_self_sufficient?: boolean;
}

// -------- New: service settings defs --------
type TierKey = 'bronze' | 'silver' | 'gold' | 'platinum';
const TIER_DEFS: Array<{ 
  key: TierKey; 
  name: string; 
  icon: keyof typeof Ionicons.glyphMap;
  color: string;
  gradient: string[];
}> = [
  { key: 'bronze', name: 'Bronze Wash', icon: 'layers-outline', color: '#CD7F32', gradient: ['#CD7F32', '#B87333'] },
  { key: 'silver', name: 'Silver Wash', icon: 'star-outline', color: '#C0C0C0', gradient: ['#C0C0C0', '#A8A8A8'] },
  { key: 'gold', name: 'Gold Wash', icon: 'trophy', color: '#FFD700', gradient: ['#FFD700', '#FFA500'] },
  { key: 'platinum', name: 'Platinum Wash', icon: 'diamond', color: '#E5E4E2', gradient: ['#E5E4E2', '#D3D3D3'] },
];

type DetailingKey = 'mini' | 'interior' | 'exterior' | 'full' | 'seats' | 'engine' | 'ceramic';

type DetailingItem = {
  key: DetailingKey;
  name: string;
  enabled: boolean;
  price: number | null;
};

const DETAILING_DEFS: Array<{ key: DetailingKey; name: string; icon: keyof typeof Ionicons.glyphMap }> = [
  { key: 'mini', name: 'Mini Detail', icon: 'sparkles-outline' },
  { key: 'interior', name: 'Interior Detail', icon: 'car-outline' },
  { key: 'exterior', name: 'Exterior Detail', icon: 'water-outline' },
  { key: 'full', name: 'Full Detail', icon: 'diamond-outline' },
  { key: 'seats', name: 'Seat Shampoo', icon: 'shirt-outline' },
  { key: 'engine', name: 'Engine Bay Clean', icon: 'cog-outline' },
  { key: 'ceramic', name: 'Ceramic Coating', icon: 'shield-checkmark-outline' },
];

const money = (n: any) => {
  const v = typeof n === 'string' ? Number(n) : typeof n === 'number' ? n : 0;
  if (!Number.isFinite(v)) return '0.00';
  return v.toFixed(2);
};

const parseMaybeNumber = (raw: string, kind: 'price' | 'minutes'): number | null => {
  const t = (raw || '').trim();
  if (!t) return null;
  const v = Number(t);
  if (!Number.isFinite(v) || v < 0) return null;
  return kind === 'minutes' ? Math.round(v) : v;
};

const buildDefaultDetailingItems = (): DetailingItem[] =>
  DETAILING_DEFS.map((d) => ({ key: d.key, name: d.name, enabled: false, price: null }));

const coerceDetailingMenu = (raw: any): DetailingItem[] => {
  const defaults = buildDefaultDetailingItems();
  const map = new Map<DetailingKey, DetailingItem>();
  defaults.forEach((d) => map.set(d.key, d));
  const items = raw?.items;
  if (Array.isArray(items)) {
    for (const it of items) {
      const key = it?.key as DetailingKey;
      if (!key || !map.has(key)) continue;
      map.set(key, {
        key,
        name: String(it?.name || map.get(key)!.name),
        enabled: !!it?.enabled,
        price:
          it?.price === null || it?.price === undefined || it?.price === ''
            ? null
            : Number.isFinite(Number(it?.price))
              ? Number(it?.price)
              : null,
      });
    }
  }
  return Array.from(map.values());
};

type TierPricing = Record<TierKey, { price: number | null; minutes: number | null }>;
const defaultTierPricing = (): TierPricing => ({
  bronze: { price: null, minutes: null },
  silver: { price: null, minutes: null },
  gold: { price: null, minutes: null },
  platinum: { price: null, minutes: null },
});

const coerceTierPricing = (raw: any): TierPricing => {
  const base = defaultTierPricing();
  const obj = raw && typeof raw === 'object' ? raw : {};
  (Object.keys(base) as TierKey[]).forEach((k) => {
    const row = obj?.[k] || {};
    base[k] = {
      price:
        row?.price === null || row?.price === undefined
          ? null
          : Number.isFinite(Number(row.price))
            ? Number(row.price)
            : null,
      minutes:
        row?.minutes === null || row?.minutes === undefined
          ? null
          : Number.isFinite(Number(row.minutes))
            ? Math.round(Number(row.minutes))
            : null,
    };
  });
  return base;
};

const SERVICE_SETTINGS_SQL = `-- Run in Supabase SQL editor
create table if not exists public.valeter_service_settings (
  valeter_id uuid primary key references auth.users(id) on delete cascade,
  eco_washing boolean not null default false,
  detailing_offered boolean not null default false,
  detailing_menu jsonb,
  tier_pricing jsonb,
  updated_at timestamptz not null default now()
);

create index if not exists idx_valeter_service_settings_updated_at
  on public.valeter_service_settings(updated_at);

-- Optional: keep updated_at fresh
create or replace function public.touch_valeter_service_settings_updated_at()
returns trigger language plpgsql as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

drop trigger if exists trg_touch_valeter_service_settings_updated_at on public.valeter_service_settings;
create trigger trg_touch_valeter_service_settings_updated_at
before update on public.valeter_service_settings
for each row execute function public.touch_valeter_service_settings_updated_at();
`;

// ✅ New image-picker API (no MediaTypeOptions)
const IMAGE_MEDIA_TYPES: any =
  (ImagePicker as any)?.MediaType?.Images ? [(ImagePicker as any).MediaType.Images] : undefined;

const getExtAndMimeFromUri = (uri: string) => {
  const clean = (uri || '').split('?')[0];
  const extRaw = (clean.split('.').pop() || 'jpg').toLowerCase();
  const ext = extRaw === 'jpg' ? 'jpeg' : extRaw;

  let mime = 'image/jpeg';
  if (ext === 'png') mime = 'image/png';
  else if (ext === 'webp') mime = 'image/webp';
  else if (ext === 'heic') mime = 'image/heic';
  else if (ext === 'heif') mime = 'image/heif';
  else if (ext === 'jpeg') mime = 'image/jpeg';

  return { extRaw, ext, mime };
};

export default function ValeterProfile() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { user, logout } = useAuth();
  const { theme, mode, toggleMode } = useAccountTheme();
  const iconAccent = getIconAccentColors(theme) ?? colors.iconAccent;
  const scrollY = useRef(new Animated.Value(0)).current;

  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [uploadingPicture, setUploadingPicture] = useState(false);

  const [valeterStats, setValeterStats] = useState<ValeterPerformanceStats>({
    totalJobs: 0,
    experienceMonths: 1,
    averageRating: 0,
    totalEarnings: 0,
    jobsThisMonth: 0,
    customerReviews: 0,
    onTimePercentage: 100,
    cancellationRate: 0,
  });

  const [currentTier, setCurrentTier] = useState<ValeterTier | null>(null);

  const [organizationName, setOrganizationName] = useState<string | null>(null);
  const [isIndependent, setIsIndependent] = useState<boolean>(true);

  const [documentsCount, setDocumentsCount] = useState(0);
  const [notificationPrefs, setNotificationPrefs] = useState<NotificationPreferences>(DEFAULT_NOTIFICATION_PREFS);
  const [availabilitySchedule, setAvailabilitySchedule] = useState<AvailabilitySchedule>(DEFAULT_AVAILABILITY);
  const [accountDataModalVisible, setAccountDataModalVisible] = useState(false);

  const CountUpNumber = ({
    value,
    prefix = '',
    suffix = '',
    decimals = 0,
    duration = 650,
    style,
  }: {
    value: number;
    prefix?: string;
    suffix?: string;
    decimals?: number;
    duration?: number;
    style?: any;
  }) => {
    const anim = useRef(new Animated.Value(0)).current;
    const [display, setDisplay] = useState(0);

    useEffect(() => {
      anim.stopAnimation();
      anim.setValue(0);
      const listenerId = anim.addListener(({ value: v }) => setDisplay(v));
      Animated.timing(anim, { toValue: value, duration, useNativeDriver: false }).start(() => {
        anim.removeListener(listenerId);
        setDisplay(value);
      });
      return () => anim.removeListener(listenerId);
    }, [value]);

    const shown = useMemo(() => Number(display).toFixed(decimals), [display, decimals]);
    return <Text style={style}>{`${prefix}${shown}${suffix}`}</Text>;
  };

  useEffect(() => {
    const fetchStats = async () => {
      if (!user?.id) return;

      try {
        const stats = await ValeterStatsService.getValeterStats(user.id);
        setValeterStats(stats);
        setCurrentTier(ValeterTierService.calculateTier(stats));
      } catch (error) {
        console.error('Error fetching valeter stats:', error);
      }
    };

    fetchStats();
  }, [user?.id]);

  useEffect(() => {
    if (user?.id) {
      // Phase 1: Load critical profile data first
      loadProfile();
      loadNotificationPreferencesLocal();
      
      // Phase 2: Load secondary data in background (non-blocking)
      Promise.all([
        loadBusinessInfo(),
        loadDocumentsCount(),
        loadAvailabilitySchedule(),
      ]).catch((error) => {
        console.error('Error loading secondary profile data:', error);
      });
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  useEffect(() => {
    if (!user?.id) return;

    let channel: ReturnType<typeof supabase.channel> | null = null;
    try {
      channel = supabase
        .channel('profile-organization-changes')
        .on(
          'postgres_changes',
          {
            event: 'UPDATE',
            schema: 'public',
            table: 'profiles',
            filter: `id=eq.${user.id}`,
          },
          () => {
            loadBusinessInfo();
          }
        )
        .subscribe();
    } catch (err) {
      console.warn('Profile subscription setup failed:', err);
    }

    return () => {
      try {
        channel?.unsubscribe();
      } catch (_) {}
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const loadDocumentsCount = async () => {
    if (!user?.id) return;
    try {
      const docs = simpleDocumentUploadService.getUserDocuments(user.id);
      setDocumentsCount(docs?.length ?? 0);
    } catch (error) {
      console.error('Error loading documents count:', error);
      setDocumentsCount(0);
    }
  };

  const loadNotificationPreferencesLocal = async () => {
    if (!user?.id) {
      setNotificationPrefs(DEFAULT_NOTIFICATION_PREFS);
      return;
    }

    try {
      const raw = await AsyncStorage.getItem(getNotifPrefsKey(user.id));
      if (!raw) {
        setNotificationPrefs(DEFAULT_NOTIFICATION_PREFS);
        return;
      }

      const parsed = JSON.parse(raw) as Partial<NotificationPreferences> | null;
      const merged: NotificationPreferences = {
        ...DEFAULT_NOTIFICATION_PREFS,
        ...(parsed || {}),
      };

      setNotificationPrefs(merged);
    } catch (error) {
      console.error('Error loading local notification preferences:', error);
      setNotificationPrefs(DEFAULT_NOTIFICATION_PREFS);
    }
  };

  const saveNotificationPreferencesLocal = async (prefs: NotificationPreferences) => {
    if (!user?.id) return;
    try {
      await AsyncStorage.setItem(getNotifPrefsKey(user.id), JSON.stringify(prefs));
    } catch (error) {
      console.error('Error saving local notification preferences:', error);
    }
  };

  const loadAvailabilitySchedule = async () => {
    if (!user?.id) return;
    try {
      const { data: profile } = await supabase
        .from('valeter_profiles')
        .select('availability_schedule')
        .eq('user_id', user.id)
        .maybeSingle();

      if (profile?.availability_schedule) {
        setAvailabilitySchedule(profile.availability_schedule as AvailabilitySchedule);
      }
    } catch (error) {
      console.error('Error loading availability schedule:', error);
    }
  };

  const handleNotificationToggle = async (key: keyof NotificationPreferences) => {
    try {
      await hapticFeedback('light');
      const newPrefs: NotificationPreferences = { ...notificationPrefs, [key]: !notificationPrefs[key] };
      setNotificationPrefs(newPrefs);
      await saveNotificationPreferencesLocal(newPrefs);
    } catch (error) {
      console.error('Error updating local notification preferences:', error);
    }
  };

  const handleDayToggle = async (day: keyof AvailabilitySchedule) => {
    try {
      await hapticFeedback('light');
      const newSchedule = {
        ...availabilitySchedule,
        [day]: { ...availabilitySchedule[day], enabled: !availabilitySchedule[day].enabled },
      };
      setAvailabilitySchedule(newSchedule);

      if (user?.id) {
        await supabase.from('valeter_profiles').update({ availability_schedule: newSchedule }).eq('user_id', user.id);
      }
    } catch (error) {
      console.error('Error updating availability schedule:', error);
    }
  };

  const handleTimeChange = async (day: keyof AvailabilitySchedule, field: 'startTime' | 'endTime', value: string) => {
    try {
      // Validate time format (HH:MM)
      const timeRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
      if (!timeRegex.test(value) && value !== '') {
        return; // Invalid format, don't update
      }

      const newSchedule = {
        ...availabilitySchedule,
        [day]: { ...availabilitySchedule[day], [field]: value },
      };
      setAvailabilitySchedule(newSchedule);

      // Auto-save after a delay
      if (user?.id) {
        setTimeout(async () => {
          await supabase.from('valeter_profiles').update({ availability_schedule: newSchedule }).eq('user_id', user.id);
        }, 1000);
      }
    } catch (error) {
      console.error('Error updating time:', error);
    }
  };

  const loadBusinessInfo = async () => {
    if (!user?.id) return;
    try {
      const { data: userData } = await supabase
        .from('users')
        .select('organization_id, is_individual_valeter')
        .eq('id', user.id)
        .maybeSingle();

      if (userData) {
        const hasOrg = !!userData.organization_id;
        setIsIndependent(!hasOrg || userData.is_individual_valeter === true);

        if (hasOrg && userData.organization_id) {
          const { data: orgData } = await supabase.from('organizations').select('name').eq('id', userData.organization_id).maybeSingle();

          setOrganizationName(orgData?.name ?? null);
        } else {
          setOrganizationName(null);
        }
      } else {
        setIsIndependent(true);
        setOrganizationName(null);
      }
    } catch (error) {
      console.error('Error loading business info:', error);
    }
  };

  const loadProfile = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase.from('valeter_profiles').select('*').eq('user_id', user!.id).maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;

      if (data) {
        setProfile(data);
        setProfilePicture(data.profile_photo_url || null);
      } else {
        const newProfile: Partial<ValeterProfileData> = {
          user_id: user!.id,
          full_name: (user as any)?.name || 'Valeter',
          bio: 'Professional mobile valeter',
          experience: '0 years',
          verification_status: 'pending',
          verification_badge: false,
        };

        const { data: created, error: createError } = await supabase.from('valeter_profiles').insert(newProfile).select().single();

        if (createError) throw createError;
        setProfile(created);
      }
    } catch (error) {
      console.error('Error loading profile:', error);
      Alert.alert('Error', 'Failed to load profile');
    } finally {
      setIsLoading(false);
    }
  };

  const BUCKET = 'valeter_documents';

  const base64ToUint8Array = (base64: string) => {
    const binary = globalThis.atob ? globalThis.atob(base64) : Buffer.from(base64, 'base64').toString('binary');
    const len = binary.length;
    const bytes = new Uint8Array(len);
    for (let i = 0; i < len; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  };


  // ✅ Expo Go safe Supabase Storage upload (no blob.arrayBuffer)
  async function uploadUriToSupabase(uri: string, path: string, contentType = 'image/jpeg') {
    const fileUri = uri.startsWith('file://') ? uri : uri;

    const base64 = await FileSystem.readAsStringAsync(fileUri, {
      encoding: 'base64' as any,
    });

    const bytes = base64ToUint8Array(base64);

    const { data, error } = await supabase.storage.from(BUCKET).upload(path, bytes, {
      contentType,
      upsert: true,
    });

    if (error) throw error;

    const { data: pub } = supabase.storage.from(BUCKET).getPublicUrl(data?.path ?? path);
    const publicUrl = pub?.publicUrl ?? null;

    return { path: data?.path ?? path, publicUrl };
  }

  const uploadProfilePhoto = async (uri: string) => {
    try {
      if (!user?.id) throw new Error('No user');

      const { extRaw, mime } = getExtAndMimeFromUri(uri);
      const fileName = `profile_${user.id}_${Date.now()}.${extRaw || 'jpg'}`;
      const storagePath = `profiles/${user.id}/${fileName}`;

      const { publicUrl } = await uploadUriToSupabase(uri, storagePath, mime);

      const { error } = await supabase.from('valeter_profiles').update({ profile_photo_url: publicUrl }).eq('user_id', user.id);

      if (error) throw error;

      setProfilePicture(publicUrl);
      setProfile((prev) => (prev ? { ...prev, profile_photo_url: publicUrl } : null));

      await hapticFeedback('medium');
      Alert.alert('Success', 'Profile picture uploaded successfully!');
    } catch (error: any) {
      console.error('[ValeterProfile] uploadProfilePhoto failed:', error);
      Alert.alert('Upload Failed', error?.message || 'Please try again.');
    }
  };

  const takePhoto = async () => {
    if (uploadingPicture) return;
    try {
      setUploadingPicture(true);

      const perm = await ImagePicker.requestCameraPermissionsAsync();
      if (perm.status !== 'granted') {
        Alert.alert('Permission Required', 'Camera permission is required to take a photo.');
        return;
      }

      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: IMAGE_MEDIA_TYPES,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets?.[0]?.uri) {
        await uploadProfilePhoto(result.assets[0].uri);
      }
    } catch (error: any) {
      console.error('[ValeterProfile] takePhoto error:', error);
      Alert.alert('Error', error?.message || 'Failed to take photo. Please try again.');
    } finally {
      setUploadingPicture(false);
    }
  };

  const pickImage = async () => {
    if (uploadingPicture) return;
    try {
      setUploadingPicture(true);

      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (perm.status !== 'granted') {
        Alert.alert('Permission Required', 'Gallery permission is required to select a photo.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: IMAGE_MEDIA_TYPES,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      });

      if (!result.canceled && result.assets?.[0]?.uri) {
        await uploadProfilePhoto(result.assets[0].uri);
      }
    } catch (error: any) {
      console.error('[ValeterProfile] pickImage error:', error);
      Alert.alert('Error', error?.message || 'Failed to select image. Please try again.');
    } finally {
      setUploadingPicture(false);
    }
  };

  const handleUploadProfilePicture = async () => {
    try {
      await hapticFeedback('light');

      if (uploadingPicture) return;

      if (Platform.OS === 'ios') {
        ActionSheetIOS.showActionSheetWithOptions(
          {
            title: 'Upload Profile Picture',
            message: 'Choose how you want to add your profile picture',
            options: ['Cancel', 'Take Photo', 'Choose from Gallery'],
            cancelButtonIndex: 0,
            userInterfaceStyle: 'dark',
          },
          async (buttonIndex) => {
            if (buttonIndex === 1) await takePhoto();
            if (buttonIndex === 2) await pickImage();
          }
        );
      } else {
        Alert.alert('Upload Profile Picture', 'Choose how you want to add your profile picture', [
          { text: 'Cancel', style: 'cancel' },
          { text: 'Take Photo', onPress: takePhoto },
          { text: 'Choose from Gallery', onPress: pickImage },
        ]);
      }
    } catch (e) {
      console.warn('[ValeterProfile] handleUploadProfilePicture error:', e);
    }
  };

  const handleLogout = async () => {
    try {
      await hapticFeedback('medium');
      Alert.alert('Logout', 'Are you sure you want to logout?', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: async () => {
            try {
              await logout();
              router.replace('/');
            } catch (error) {
              console.error('Logout error:', error);
              Alert.alert('Logout Error', 'Failed to logout. Please try again.');
            }
          },
        },
      ]);
    } catch {}
  };

  const handleDeleteAccount = async () => {
    try {
      await hapticFeedback('heavy');
      Alert.alert(
        'Delete account',
        'This will permanently remove your account and all data. This cannot be undone.',
        [
          { text: 'Cancel', style: 'cancel' },
          {
            text: 'Delete account',
            style: 'destructive',
            onPress: () => {
              setAccountDataModalVisible(false);
              // Placeholder: wire to real delete when backend supports it
              Alert.alert('Account deleted', 'Your account has been deleted.');
            },
          },
        ]
      );
    } catch {}
  };

  const handleDataRequest = async () => {
    await hapticFeedback('light');
    setAccountDataModalVisible(false);
    // Placeholder: wire to export/data request when backend supports it
    Alert.alert('Data request', 'We’ll prepare a copy of your data and send it to your email within a few days.');
  };

  const pageBg = theme.background;
  const isLight = theme.mode === 'light';
  const primaryColor = theme.primary;

  if (isLoading) {
    return (
      <View style={[styles.container, { backgroundColor: pageBg[0] }]}>
        <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  if (!profile) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: pageBg[0] }]} edges={[]}>
        <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <ErrorView message="Failed to load profile" onRetry={loadProfile} style={styles.loadingContainer} />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: pageBg[0] }]} edges={[]}>
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} backgroundColor="transparent" translucent />
      <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader 
        title="Profile" 
        accountType="valeter"
        profilePicture={profilePicture}
        onNotificationPress={() => router.push('/valeter/notifications')}
        isProfilePage
      />

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
          useNativeDriver: false,
        })}
        scrollEventThrottle={16}
        contentContainerStyle={{ 
          paddingTop: HEADER_CONTENT_OFFSET, 
          paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
          paddingHorizontal: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Profile Hero Section */}
        <View style={styles.heroSection}>
          <View style={styles.profilePictureContainer}>
            {profilePicture ? (
              <View style={styles.profilePicture}>
                <Image source={{ uri: profilePicture }} style={styles.profileImage} />
                {profile?.verification_badge && (
                  <View style={styles.verificationBadge}>
                    <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                  </View>
                )}
              </View>
            ) : (
              <View style={styles.profilePicturePlaceholder}>
                <Ionicons name="person" size={40} color={iconAccent.primary} />
                {profile?.verification_badge && (
                  <View style={styles.verificationBadge}>
                    <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                  </View>
                )}
              </View>
            )}

            <TouchableOpacity
              style={[styles.uploadButton, (isLoading || uploadingPicture) && styles.uploadButtonDisabled]}
              onPress={handleUploadProfilePicture}
              disabled={isLoading || uploadingPicture}
            >
              <Ionicons name="camera" size={16} color="#FFFFFF" />
            </TouchableOpacity>
          </View>

          <View style={styles.profileInfo}>
            <View style={styles.nameRow}>
              <Text style={styles.userName}>{profile.full_name || 'Valeter Name'}</Text>
              {profile.verification_badge && (
                <View style={styles.verificationBadgeSmall}>
                  <Ionicons name="checkmark-circle" size={14} color="#FFFFFF" />
                </View>
              )}
            </View>

            <View style={styles.emailRow}>
              <Text style={styles.userEmail}>{user?.email ?? '—'}</Text>
            </View>

            {profile.experience && <Text style={styles.userExperience}>{profile.experience} experience</Text>}

            {profile.is_self_sufficient !== undefined && (
              <View style={styles.selfSufficiencyBadge}>
                <Ionicons
                  name={profile.is_self_sufficient ? 'battery-charging' : 'water'}
                  size={14}
                  color={profile.is_self_sufficient ? '#10B981' : iconAccent.primary}
                />
                <Text style={[styles.selfSufficiencyText, { color: profile.is_self_sufficient ? '#10B981' : iconAccent.primary }]}>
                  {profile.is_self_sufficient ? 'Self-Sufficient' : 'Needs Resources'}
                </Text>
              </View>
            )}
          </View>

          {uploadingPicture && (
            <View style={{ marginTop: 12, alignItems: 'center', gap: 10 }}>
              <ActivityIndicator size="small" color={iconAccent.primary} />
              <Text style={{ color: '#E5E7EB', fontWeight: '700' }}>Uploading…</Text>
            </View>
          )}
        </View>

        {/* Tier Info Section */}
        {currentTier && (
          <View style={styles.section}>
            <View style={styles.tierInfoCard}>
              <LinearGradient colors={[currentTier.color + '20', currentTier.color + '10']} style={styles.tierInfoCardGradient}>
                <View style={styles.tierInfoRow}>
                  <Text style={styles.tierInfoIcon}>{currentTier.icon}</Text>
                  <View style={styles.tierInfoTextContainer}>
                    <Text style={styles.tierInfoTitle}>{currentTier.name} Valeter</Text>
                    <Text style={styles.tierInfoSubtitle}>
                      {valeterStats.totalJobs} jobs • {valeterStats.experienceMonths} months • ⭐ {valeterStats.averageRating.toFixed(1)}
                    </Text>
                  </View>
                  {currentTier.nextTierProgress > 0 && (
                    <View style={styles.tierInfoProgress}>
                      <Text style={[styles.tierInfoProgressText, { color: currentTier.color }]}>{currentTier.nextTierProgress}%</Text>
                      <Text style={styles.tierInfoProgressLabel}>to next tier</Text>
                    </View>
                  )}
                </View>
                {currentTier.nextTierProgress > 0 && currentTier.nextTierProgress < 100 && (
                  <View style={styles.tierProgressBarWrap}>
                    <View style={styles.tierProgressBarBg}>
                      <View style={[styles.tierProgressBarFill, { width: `${currentTier.nextTierProgress}%`, backgroundColor: currentTier.color }]} />
                    </View>
                  </View>
                )}
                <TouchableOpacity
                  style={styles.tierCtaButton}
                  onPress={() => { hapticFeedback('light'); router.push('/valeter/valeter-rewards-system'); }}
                  activeOpacity={0.8}
                >
                  <Text style={[styles.tierCtaText, { color: currentTier.color }]}>
                    {currentTier.nextTierProgress > 0 && currentTier.nextTierProgress < 100
                      ? `Complete more to reach ${ValeterTierService.getNextTier(currentTier.name)?.name ?? 'next tier'}`
                      : 'View Tier Benefits'}
                  </Text>
                  <Ionicons name="arrow-forward" size={14} color={currentTier.color} />
                </TouchableOpacity>
              </LinearGradient>
            </View>
          </View>
        )}

        {/* Business & Compliance */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionHeaderIcon}>
              <Ionicons name="business-outline" size={22} color={iconAccent.primary} />
            </View>
            <View style={styles.sectionHeaderText}>
              <Text style={styles.sectionTitle}>Business & Compliance</Text>
              <Text style={styles.sectionSubtitle}>Vehicle, documents, legal</Text>
            </View>
          </View>
          <View style={styles.menuSection}>
            <TouchableOpacity style={styles.menuItem} onPress={() => { hapticFeedback('light'); router.push('/valeter/profile/valeter-vehicle-info'); }} activeOpacity={0.8}>
              <View style={styles.menuIconWrapper}>
                <Ionicons name="car-sport-outline" size={18} color={iconAccent.primary} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Vehicle</Text>
                <Text style={styles.menuSubtitle}>Make, model, registration, Tax & MOT</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={iconAccent.primary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.menuItem} onPress={() => { hapticFeedback('light'); router.push('/valeter/profile/valeter-documents'); }} activeOpacity={0.8}>
              <View style={styles.menuIconWrapper}>
                <Ionicons name="document-text-outline" size={18} color={iconAccent.primary} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Documents</Text>
                <Text style={styles.menuSubtitle}>
                  {documentsCount > 0 ? `${documentsCount} document${documentsCount !== 1 ? 's' : ''} uploaded` : 'Upload verification documents'}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={iconAccent.primary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.menuItem} onPress={() => { hapticFeedback('light'); router.push('/valeter/profile/valeter-legal-compliance'); }} activeOpacity={0.8}>
              <View style={styles.menuIconWrapper}>
                <Ionicons name="shield-checkmark-outline" size={18} color={iconAccent.primary} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Legal Compliance</Text>
                <Text style={styles.menuSubtitle}>Compliance status and action items</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={iconAccent.primary} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Operations */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionHeaderIcon}>
              <Ionicons name="construct-outline" size={22} color={iconAccent.primary} />
            </View>
            <View style={styles.sectionHeaderText}>
              <Text style={styles.sectionTitle}>Operations</Text>
              <Text style={styles.sectionSubtitle}>Hours and pricing</Text>
            </View>
          </View>
          <View style={styles.menuSection}>
            <TouchableOpacity style={styles.menuItem} onPress={() => { hapticFeedback('light'); router.push('/valeter/settings/working-hours'); }} activeOpacity={0.8}>
              <View style={styles.menuIconWrapper}>
                <Ionicons name="time-outline" size={18} color={iconAccent.primary} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Working Hours</Text>
                <Text style={styles.menuSubtitle}>Set your availability schedule</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={iconAccent.primary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.menuItem} onPress={() => { hapticFeedback('light'); router.push('/valeter/settings/services-pricing'); }} activeOpacity={0.8}>
              <View style={styles.menuIconWrapper}>
                <Ionicons name="pricetags-outline" size={18} color={iconAccent.money} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Services & Pricing</Text>
                <Text style={styles.menuSubtitle}>Wash tiers, eco washing, detailing</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={iconAccent.primary} />
            </TouchableOpacity>
          </View>
        </View>

        {/* Account */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionHeaderIcon}>
              <Ionicons name="person-circle-outline" size={22} color={iconAccent.primary} />
            </View>
            <View style={styles.sectionHeaderText}>
              <Text style={styles.sectionTitle}>Account</Text>
              <Text style={styles.sectionSubtitle}>Personal info, payment, notifications</Text>
            </View>
          </View>
          <View style={styles.menuSection}>
            <TouchableOpacity style={styles.menuItem} onPress={() => { hapticFeedback('light'); router.push('/valeter/profile/valeter-personal-info'); }} activeOpacity={0.8}>
              <View style={styles.menuIconWrapper}>
                <Ionicons name="person-outline" size={18} color={iconAccent.primary} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Personal Info</Text>
                <Text style={styles.menuSubtitle}>Name, email, bio, experience</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={iconAccent.primary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.menuItem} onPress={() => { hapticFeedback('light'); router.push('/valeter/settings/payment-methods'); }} activeOpacity={0.8}>
              <View style={styles.menuIconWrapper}>
                <Ionicons name="wallet-outline" size={18} color={iconAccent.money} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Payment Methods</Text>
                <Text style={styles.menuSubtitle}>Bank account & payouts via Stripe</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={iconAccent.primary} />
            </TouchableOpacity>
            <TouchableOpacity style={styles.menuItem} onPress={() => { hapticFeedback('light'); router.push('/valeter/profile/valeter-notification-preferences'); }} activeOpacity={0.8}>
              <View style={styles.menuIconWrapper}>
                <Ionicons name="notifications-outline" size={18} color={iconAccent.warning} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Notifications</Text>
                <Text style={styles.menuSubtitle}>Control how and when you receive alerts</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={iconAccent.primary} />
            </TouchableOpacity>
            <Pressable style={styles.menuItem} onPress={() => { hapticFeedback('light'); toggleMode(); }}>
              <View style={styles.menuIconWrapper}>
                <Ionicons name={mode === 'light' ? 'sunny' : 'moon'} size={18} color={iconAccent.primary} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Appearance</Text>
                <Text style={styles.menuSubtitle}>
                  {mode === 'light' ? 'Light mode' : 'Dark mode (original)'}
                </Text>
              </View>
              <Switch
                value={mode === 'light'}
                onValueChange={() => { hapticFeedback('light'); toggleMode(); }}
                trackColor={{ false: isLight ? 'rgba(11,60,93,0.3)' : 'rgba(255,255,255,0.25)', true: primaryColor }}
                thumbColor="#FFFFFF"
                ios_backgroundColor={isLight ? 'rgba(11,60,93,0.3)' : 'rgba(255,255,255,0.25)'}
              />
            </Pressable>
          </View>
        </View>

        {/* Session & data */}
        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionHeaderIcon}>
              <Ionicons name="log-out-outline" size={22} color={iconAccent.primary} />
            </View>
            <View style={styles.sectionHeaderText}>
              <Text style={styles.sectionTitle}>Session</Text>
              <Text style={styles.sectionSubtitle}>Sign out or manage account data</Text>
            </View>
          </View>
          <View style={styles.menuSection}>
            <TouchableOpacity style={styles.menuItem} onPress={() => { hapticFeedback('light'); setAccountDataModalVisible(true); }} activeOpacity={0.8}>
              <View style={styles.menuIconWrapper}>
                <Ionicons name="shield-outline" size={18} color={iconAccent.primary} />
              </View>
              <View style={styles.menuContent}>
                <Text style={styles.menuTitle}>Account & data</Text>
                <Text style={styles.menuSubtitle}>Request your data or delete account</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={iconAccent.primary} />
            </TouchableOpacity>
          </View>
          <TouchableOpacity onPress={handleLogout} activeOpacity={0.88} style={styles.logoutButton}>
            <LinearGradient colors={['rgba(239,68,68,0.45)', 'rgba(220,38,38,0.25)']} style={styles.logoutButtonGradient}>
              <View style={styles.logoutButtonIconWrap}>
                <Ionicons name="log-out-outline" size={22} color="#EF4444" />
              </View>
              <View style={styles.logoutButtonTextWrap}>
                <Text style={styles.logoutButtonText}>Log out</Text>
                <Text style={styles.logoutButtonSubtext}>Sign out of your valeter account</Text>
              </View>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        <View style={styles.appInfoSection}>
          <Text style={styles.appInfoText}>Wish a Wash v1.0.0</Text>
          <Text style={styles.appInfoText}>© 2025 Wish a Wash. All rights reserved.</Text>
        </View>
      </Animated.ScrollView>

      {/* Account & data overlay */}
      <Modal visible={accountDataModalVisible} transparent animationType="fade">
        <Pressable style={styles.accountModalBackdrop} onPress={() => setAccountDataModalVisible(false)}>
          <Pressable style={[styles.accountModalSheet, { paddingBottom: Math.max(insets.bottom, 24) + 24 }]} onPress={(e) => e.stopPropagation()}>
            <View style={styles.accountModalHandle} />
            <View style={styles.accountModalHeader}>
              <Text style={styles.accountModalTitle}>Account & data</Text>
              <TouchableOpacity onPress={() => setAccountDataModalVisible(false)} hitSlop={12} style={styles.accountModalClose}>
                <Ionicons name="close" size={24} color={primaryColor} />
              </TouchableOpacity>
            </View>
            <View style={styles.accountModalContent}>
              <TouchableOpacity onPress={handleDataRequest} activeOpacity={0.85} style={styles.accountModalOption}>
                <View style={styles.accountModalOptionIcon}>
                  <Ionicons name="document-text-outline" size={22} color={primaryColor} />
                </View>
                <View style={styles.accountModalOptionText}>
                  <Text style={styles.accountModalOptionTitle}>Request my data</Text>
                  <Text style={styles.accountModalOptionSubtitle}>Get a copy of your personal data by email</Text>
                </View>
                <Ionicons name="chevron-forward" size={18} color={primaryColor} />
              </TouchableOpacity>
              <TouchableOpacity onPress={handleDeleteAccount} activeOpacity={0.85} style={[styles.accountModalOption, styles.accountModalOptionDanger]}>
                <View style={[styles.accountModalOptionIcon, styles.accountModalOptionIconDanger]}>
                  <Ionicons name="trash-outline" size={22} color="#EF4444" />
                </View>
                <View style={styles.accountModalOptionText}>
                  <Text style={styles.accountModalOptionTitleDanger}>Delete account</Text>
                  <Text style={styles.accountModalOptionSubtitle}>Permanently delete your account and all data</Text>
                </View>
                <Ionicons name="chevron-forward" size={18} color="rgba(239,68,68,0.9)" />
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: '#F9FAFB', fontSize: 18, marginTop: 12 },
  scrollView: { flex: 1 },

  heroSection: { padding: 18, alignItems: 'center', marginBottom: 14 },
  profilePictureContainer: { alignItems: 'center', marginBottom: 14, position: 'relative' },
  profilePicture: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(135,206,235,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 3,
    borderColor: 'rgba(135,206,235,0.3)',
    overflow: 'hidden',
  },
  profilePicturePlaceholder: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(135,206,235,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 3,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  profileImage: { width: '100%', height: '100%', borderRadius: 60 },
  uploadButton: {
    position: 'absolute',
    bottom: 12,
    right: 0,
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: colors.SKY,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  uploadButtonDisabled: { opacity: 0.7, backgroundColor: '#6B7280' },

  profileInfo: { alignItems: 'center' },
  nameRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 4 },
  userName: { color: '#F9FAFB', fontSize: isSmallScreen ? 24 : 28, fontWeight: '800' },
  emailRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  userEmail: { color: colors.SKY, fontSize: isSmallScreen ? 14 : 16 },
  userExperience: { color: colors.SKY, fontSize: isSmallScreen ? 14 : 16, fontStyle: 'italic' },
  selfSufficiencyBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 8,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignSelf: 'flex-start',
  },
  selfSufficiencyText: { fontSize: 12, fontWeight: '600' },

  tierBadgeIcon: { fontSize: 40 },
  tierInfoCard: { borderRadius: 12, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)' },
  tierInfoCardGradient: { padding: 12 },
  tierInfoRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  tierInfoIcon: { fontSize: 32 },
  tierInfoTextContainer: { flex: 1 },
  tierInfoTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '800', marginBottom: 4 },
  tierInfoSubtitle: { color: '#E0E7FF', fontSize: 13, fontWeight: '500' },
  tierInfoProgress: { alignItems: 'flex-end' },
  tierInfoProgressText: { fontSize: 18, fontWeight: '900', marginBottom: 2 },
  tierInfoProgressLabel: { color: '#E0E7FF', fontSize: 11, fontWeight: '600' },
  tierProgressBarWrap: { marginTop: 10 },
  tierProgressBarBg: { height: 6, borderRadius: 3, backgroundColor: 'rgba(255,255,255,0.15)', overflow: 'hidden' },
  tierProgressBarFill: { height: '100%', borderRadius: 3 },
  tierCtaButton: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: 10, paddingVertical: 8 },
  tierCtaText: { fontSize: 13, fontWeight: '700' },

  section: {
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.05)',
    marginBottom: 14,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  sectionHeaderIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.12)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  sectionHeaderText: {
    flex: 1,
    gap: 4,
  },
  sectionTitle: { 
    color: '#F9FAFB', 
    fontSize: 20, 
    fontWeight: '600', 
    letterSpacing: -0.3, 
    marginBottom: 0,
  },
  sectionSubtitle: { 
    color: 'rgba(249,250,251,0.65)', 
    fontSize: 13, 
    fontWeight: '500',
    lineHeight: 18,
    marginBottom: 0,
  },
  settingsCard: {
    borderRadius: 18,
    padding: 16,
    marginTop: 0,
    overflow: 'hidden',
  },
  featuredToggleRow: {
    marginBottom: 14,
  },
  featuredToggleBackground: {
    borderRadius: 16,
    padding: 16,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  featuredToggleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  featuredToggleLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    flex: 1,
  },
  featuredIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  featuredIconWrapperActive: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderColor: 'rgba(16,185,129,0.3)',
  },
  featuredToggleText: {
    flex: 1,
    gap: 2,
  },
  featuredToggleLabel: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  featuredToggleDescription: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    fontWeight: '500',
  },
  preferencesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  preferenceCard: {
    flex: 1,
    minWidth: '30%',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 14,
    padding: 14,
    alignItems: 'center',
    gap: 10,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  preferenceIconBox: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  preferenceIconBoxActive: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderColor: 'rgba(16,185,129,0.3)',
  },
  preferenceLabel: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '700',
    textAlign: 'center',
  },
  scheduleCard: {
    borderRadius: 18,
    padding: 14,
    marginTop: 0,
    overflow: 'hidden',
  },
  scheduleDayCard: {
    paddingVertical: 10,
    paddingHorizontal: 4,
  },
  scheduleDayCardActive: {
    backgroundColor: 'rgba(16,185,129,0.08)',
    borderRadius: 12,
    paddingVertical: 10,
    paddingHorizontal: 12,
  },
  scheduleDayContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  scheduleDayLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  scheduleDayBadge: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  scheduleDayBadgeActive: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderColor: 'rgba(16,185,129,0.3)',
  },
  scheduleDayBadgeWeekend: {
    backgroundColor: 'rgba(251,191,36,0.1)',
    borderColor: 'rgba(251,191,36,0.2)',
  },
  scheduleDayAbbr: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  scheduleDayAbbrActive: {
    color: '#10B981',
  },
  scheduleDayLabel: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: -0.2,
    minWidth: 100,
  },
  scheduleDayLabelActive: {
    color: '#F9FAFB',
  },
  scheduleTimeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flex: 1,
    marginRight: 8,
    justifyContent: 'flex-end',
  },
  scheduleTimeInput: {
    backgroundColor: 'rgba(16,185,129,0.12)',
    borderWidth: 1.5,
    borderColor: 'rgba(16,185,129,0.3)',
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 5,
    minWidth: 65,
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  scheduleTimeInputText: {
    color: '#10B981',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.5,
    textAlign: 'center',
    padding: 0,
    width: '100%',
    height: '100%',
    textAlignVertical: 'center',
  },
  scheduleTimeSeparator: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 13,
    fontWeight: '700',
    marginHorizontal: 4,
  },
  scheduleOffBadge: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  scheduleOffText: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  scheduleDivider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.08)',
    marginLeft: 52,
    marginVertical: 6,
  },

  businessCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  businessHeader: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  businessInfo: { flex: 1 },
  businessTitle: { color: '#F9FAFB', fontSize: 15, fontWeight: '700' },
  businessSubtitle: { color: colors.SKY, fontSize: 13, marginTop: 2 },

  documentsCard: {
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.15,
    shadowRadius: 3,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    marginTop: 12,
  },
  documentsCardGradient: { padding: 12 },
  documentsCardContent: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  documentsIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  documentsTextContainer: { flex: 1, gap: 2 },
  documentsCardTitle: { color: '#F9FAFB', fontSize: 14, fontWeight: '700', marginBottom: 2 },
  documentsCardSubtitle: { color: '#7DD3FC', fontSize: 11, fontWeight: '600' },

  menuSection: { gap: 8 },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.15,
    shadowRadius: 3,
    marginBottom: 8,
  },
  menuIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  menuContent: { flex: 1 },
  menuTitle: { color: '#F9FAFB', fontSize: 14, fontWeight: '700', marginBottom: 2 },
  menuSubtitle: { color: '#7DD3FC', fontSize: 11, fontWeight: '600' },

  settingsContainer: { gap: 12 },
  logoutButton: {
    marginTop: 12,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.5)',
    elevation: 4,
    shadowColor: '#EF4444',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  logoutButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 14,
  },
  logoutButtonIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(239,68,68,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoutButtonTextWrap: { flex: 1 },
  logoutButtonText: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 2,
  },
  logoutButtonSubtext: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 13,
  },

  appInfoSection: { padding: 20 },
  appInfoText: { color: colors.SKY, fontSize: 12, textAlign: 'center', marginBottom: 4, opacity: 0.7 },

  accountModalBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  accountModalSheet: {
    backgroundColor: 'rgba(15,23,42,0.98)',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    minHeight: 280,
  },
  accountModalHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.3)',
    alignSelf: 'center',
    marginTop: 12,
    marginBottom: 8,
  },
  accountModalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  accountModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
  },
  accountModalClose: {
    padding: 4,
  },
  accountModalContent: {
    paddingHorizontal: 20,
    gap: 12,
  },
  accountModalOption: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    gap: 14,
  },
  accountModalOptionDanger: {
    backgroundColor: 'rgba(239,68,68,0.06)',
    borderColor: 'rgba(239,68,68,0.2)',
  },
  accountModalOptionIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  accountModalOptionIconDanger: {
    backgroundColor: 'rgba(239,68,68,0.15)',
  },
  accountModalOptionText: { flex: 1 },
  accountModalOptionTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 2,
  },
  accountModalOptionTitleDanger: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 2,
  },
  accountModalOptionSubtitle: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 13,
  },

  verificationBadge: {
    position: 'absolute',
    top: -5,
    right: -5,
    backgroundColor: '#10B981',
    width: 32,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  verificationBadgeSmall: {
    backgroundColor: '#10B981',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    marginLeft: 8,
  },

  // ✅ Modal styles - Redesigned
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.75)',
    padding: 0,
    justifyContent: 'flex-end',
  },
  modalCard: {
    height: '90%',
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    backgroundColor: 'rgba(10,25,41,0.98)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    overflow: 'hidden',
    elevation: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
  },
  modalHeader: {
    padding: 24,
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.15)',
  },
  modalHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 16,
    flex: 1,
  },
  modalHeaderIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  modalHeaderIconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalHeaderText: {
    flex: 1,
    gap: 4,
  },
  modalTitle: { color: '#F9FAFB', fontSize: 24, fontWeight: '800', letterSpacing: 0.3 },
  modalSub: { color: 'rgba(249,250,251,0.6)', fontSize: 14, marginTop: 2, lineHeight: 20 },
  modalScrollContent: {
    paddingBottom: 24,
  },
  modalIconBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  sectionHeaderContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 14,
  },
  modalLoading: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 10 },
  modalLoadingText: { color: 'rgba(249,250,251,0.8)', fontWeight: '800' },

  modalSection: { padding: 20, borderBottomWidth: 1, borderBottomColor: 'rgba(135,206,235,0.1)' },
  modalSectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '700', letterSpacing: 0.2 },
  modalHint: { color: 'rgba(249,250,251,0.6)', fontSize: 13, marginTop: 4, lineHeight: 20 },
  
  // Eco Wash Card
  ecoWashCard: {
    padding: 20,
    borderRadius: 20,
  },
  ecoWashContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  ecoWashLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    flex: 1,
  },
  ecoWashIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 16,
    backgroundColor: 'rgba(16,185,129,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(16,185,129,0.4)',
  },
  ecoWashText: {
    flex: 1,
    gap: 4,
  },

  rowBetweenCenter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 12 },

  serviceRow: {
    padding: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.14)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  serviceRowTop: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  serviceRowTitle: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  serviceName: { color: '#F9FAFB', fontSize: 14, fontWeight: '900', flexShrink: 1 },

  servicePills: { flexDirection: 'row', gap: 8 },
  pill: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
  },
  pillText: { color: 'rgba(249,250,251,0.85)', fontSize: 12, fontWeight: '900' },

  inputsRow: { flexDirection: 'row', gap: 10, marginTop: 12 },
  inputLabel: { color: 'rgba(249,250,251,0.6)', fontSize: 11, fontWeight: '900', marginBottom: 6 },
  inputWrap: {
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
    overflow: 'hidden',
  },
  input: { color: '#F9FAFB', fontSize: 14, paddingVertical: 10, paddingHorizontal: 12 },

  // Tier pricing styles - Enhanced
  tierCardsContainer: {
    gap: 16,
    marginTop: 8,
  },
  tierCardEnhanced: {
    padding: 20,
    borderRadius: 24,
    overflow: 'hidden',
    marginBottom: 0,
    borderWidth: 1.5,
  },
  tierCardHeaderEnhanced: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    marginBottom: 14,
  },
  tierIconWrapperEnhanced: {
    width: 60,
    height: 60,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  tierHeaderTextEnhanced: {
    flex: 1,
  },
  tierNameEnhanced: {
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 10,
    letterSpacing: 0.3,
  },
  tierPillsRowEnhanced: {
    flexDirection: 'row',
    gap: 10,
  },
  tierPillEnhanced: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 14,
    borderWidth: 1,
  },
  tierPillTextEnhanced: {
    fontSize: 14,
    fontWeight: '700',
  },
  tierInputsRowEnhanced: {
    flexDirection: 'row',
    gap: 14,
  },
  tierInputGroup: {
    flex: 1,
  },
  tierInputLabelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 10,
  },
  tierInputLabelEnhanced: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  tierInputBlur: {
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  tierInputEnhanced: {
    color: '#F9FAFB',
    fontSize: 16,
    paddingVertical: 14,
    paddingHorizontal: 16,
    fontWeight: '700',
  },

  sqlHelpCard: {
    margin: 14,
    padding: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    gap: 10,
  },
  sqlHelpTitle: { color: '#F9FAFB', fontSize: 13, fontWeight: '900' },
  sqlHelpText: { color: 'rgba(249,250,251,0.72)', fontSize: 12, marginTop: 4, lineHeight: 18 },

  sqlBtn: {
    alignSelf: 'flex-start',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: colors.SKY,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 14,
  },
  sqlBtnText: { color: '#FFFFFF', fontWeight: '900', fontSize: 12 },

  // Detailing styles - Enhanced
  detailingToggleCard: {
    padding: 20,
    borderRadius: 20,
  },
  detailingToggleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  detailingToggleLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    flex: 1,
  },
  detailingToggleIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 16,
    backgroundColor: 'rgba(245,158,11,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(245,158,11,0.4)',
  },
  detailingToggleText: {
    flex: 1,
    gap: 4,
  },
  detailingItemsContainer: {
    gap: 12,
    marginTop: 8,
  },
  detailingItemCard: {
    padding: 18,
    borderRadius: 20,
    borderWidth: 1.5,
  },
  detailingItemCardDisabled: {
    opacity: 0.6,
  },
  detailingItemHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  detailingItemLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  detailingItemIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  detailingItemIconDisabled: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderColor: 'rgba(255,255,255,0.1)',
  },
  detailingItemName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  detailingItemNameDisabled: {
    color: 'rgba(249,250,251,0.5)',
  },
  detailingItemInputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 12,
  },
  detailingItemInputGroup: {
    flex: 1,
  },
  detailingItemInputLabelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 10,
  },
  detailingItemInputLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  detailingItemInputBlur: {
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  detailingItemInput: {
    color: '#F9FAFB',
    fontSize: 16,
    paddingVertical: 14,
    paddingHorizontal: 16,
    fontWeight: '700',
  },
  detailingItemPriceBadge: {
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  detailingItemPriceBadgeText: {
    color: colors.SKY,
    fontSize: 16,
    fontWeight: '700',
  },
  
  // Enhanced Footer
  modalFooterEnhanced: {
    padding: 20,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
    flexDirection: 'row',
    gap: 14,
    backgroundColor: 'rgba(10,25,41,0.5)',
  },
  modalSecondaryBtnEnhanced: {
    flex: 1,
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    backgroundColor: 'rgba(135,206,235,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
  },
  modalSecondaryTextEnhanced: { color: '#E5E7EB', fontWeight: '700', fontSize: 16 },
  modalPrimaryBtnEnhanced: {
    flex: 1.5,
    borderRadius: 18,
    backgroundColor: colors.SKY,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    flexDirection: 'row',
    gap: 10,
    elevation: 8,
    shadowColor: colors.SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
  },
  modalPrimaryTextEnhanced: { color: '#FFFFFF', fontWeight: '700', fontSize: 16 },
});
