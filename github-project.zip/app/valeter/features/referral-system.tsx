import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Share,
  Alert,
  StatusBar,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import { getTextColors, getBackgroundColors } from '../../../src/constants/themeColors';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

export default function ValeterReferralSystem() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { mode } = useAccountTheme();
  const theme = getAccountTheme('valeter', mode);
  const pageBg = theme.background;
  const primaryColor = theme.primary;
  const isLight = theme.mode === 'light';
  const textColors = getTextColors(theme);
  const bgColors = getBackgroundColors(theme);

  // Generate short referral code from user ID (first 6 characters, uppercase)
  const generateShortCode = (userId: string | undefined): string => {
    if (!userId) return 'WAW000';
    // Take first 6 chars of user ID, convert to uppercase, remove hyphens
    const shortId = userId.replace(/-/g, '').substring(0, 6).toUpperCase();
    return shortId || 'WAW000';
  };
  
  const [referralCode] = useState(generateShortCode(user?.id));
  const [referrals] = useState<Array<{ id: string; name: string; date: string; reward: string }>>([]);

  const handleShare = async () => {
    try {
      await Share.share({
        message: `Join me on Wish a Wash as a valeter! Use my referral code: ${referralCode} and get £10 bonus when you complete your first job!`,
      });
    } catch (error) {
      Alert.alert('Error', 'Unable to share referral code');
    }
  };

  const handleCopy = () => {
    Alert.alert('Copied!', 'Referral code copied to clipboard');
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: pageBg[0] }]} edges={[]}>
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} backgroundColor="transparent" translucent />
      <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader title="Referrals" accountType="valeter" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Referral Code Card */}
        <View style={[styles.codeCard, isLight && { borderColor: bgColors.cardBorder }]}>
          <BlurView intensity={isLight ? 20 : 35} tint={isLight ? 'light' : 'dark'} style={styles.codeBlur}>
            <LinearGradient
              colors={isLight ? [bgColors.card ?? '#F8FBFF', bgColors.card ?? '#F8FBFF'] : ['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={[styles.codeBorder, isLight && { borderColor: bgColors.cardBorder }]} />
            <View style={styles.codeGradient}>
              <View style={[styles.codeIconWrapper, isLight && { backgroundColor: theme.iconCircleBg ?? `${primaryColor}20`, borderColor: bgColors.cardBorder }]}>
                <Ionicons name="gift" size={32} color={primaryColor} />
              </View>
              <Text style={[styles.codeLabel, { color: textColors.secondary }]}>Your Referral Code</Text>
              <View style={[styles.codeContainer, isLight && { backgroundColor: `${primaryColor}12`, borderColor: bgColors.cardBorder }]}>
                <Text style={[styles.codeText, { color: textColors.primary }]}>{referralCode}</Text>
              </View>
              <View style={styles.codeActions}>
                <TouchableOpacity style={[styles.codeButton, isLight && { backgroundColor: `${primaryColor}25`, borderColor: bgColors.cardBorder }]} onPress={handleCopy}>
                  <Ionicons name="copy" size={18} color={primaryColor} />
                  <Text style={[styles.codeButtonText, { color: primaryColor }]}>Copy</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.codeButton, isLight && { backgroundColor: `${primaryColor}25`, borderColor: bgColors.cardBorder }]} onPress={handleShare}>
                  <Ionicons name="share" size={18} color={primaryColor} />
                  <Text style={[styles.codeButtonText, { color: primaryColor }]}>Share</Text>
                </TouchableOpacity>
              </View>
            </View>
          </BlurView>
        </View>

        {/* Rewards Info */}
        <View style={[styles.infoCard, isLight && { borderColor: bgColors.cardBorder }]}>
          <BlurView intensity={isLight ? 20 : 30} tint={isLight ? 'light' : 'dark'} style={styles.infoBlur}>
            <LinearGradient
              colors={isLight ? [bgColors.card ?? '#F8FBFF', bgColors.card ?? '#F8FBFF'] : ['rgba(255,255,255,0.06)', 'rgba(255,255,255,0.02)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={[styles.infoBorder, isLight && { borderColor: bgColors.cardBorder }]} />
            <View style={styles.infoContentWrapper}>
              <View style={[styles.infoIconWrapper, isLight && { backgroundColor: theme.iconCircleBg ?? `${primaryColor}18`, borderColor: bgColors.cardBorder }]}>
                <Ionicons name="information-circle" size={24} color={primaryColor} />
              </View>
              <View style={styles.infoContent}>
                <Text style={[styles.infoTitle, { color: textColors.primary }]}>How it Works</Text>
                <Text style={[styles.infoText, { color: textColors.secondary }]}>
                  Share your code with other valeters. When they sign up and complete their first job, you both get £10 bonus!
                </Text>
              </View>
            </View>
          </BlurView>
        </View>

        {/* Referrals List */}
        <View style={styles.referralsSection}>
          <Text style={[styles.sectionTitle, { color: textColors.primary }]}>Your Referrals ({referrals.length})</Text>
          {referrals.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Ionicons name="people-outline" size={48} color={primaryColor} style={{ opacity: 0.5 }} />
              <Text style={[styles.emptyText, { color: textColors.primary }]}>No referrals yet</Text>
              <Text style={[styles.emptySubtext, { color: textColors.secondary }]}>Start sharing your code!</Text>
            </View>
          ) : (
            referrals.map((referral) => (
              <View key={referral.id} style={[styles.referralCard, isLight && { borderColor: bgColors.cardBorder }]}>
                <BlurView intensity={isLight ? 20 : 30} tint={isLight ? 'light' : 'dark'} style={styles.referralBlur}>
                  <LinearGradient
                    colors={isLight ? [bgColors.card ?? '#F8FBFF', bgColors.card ?? '#F8FBFF'] : ['rgba(255,255,255,0.06)', 'rgba(255,255,255,0.02)']}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={[styles.referralBorder, isLight && { borderColor: bgColors.cardBorder }]} />
                  <View style={styles.referralContentWrapper}>
                    <View style={[styles.referralIconWrapper, isLight && { backgroundColor: `${primaryColor}18`, borderColor: bgColors.cardBorder }]}>
                      <Ionicons name="person" size={20} color={primaryColor} />
                    </View>
                    <View style={styles.referralContent}>
                      <Text style={[styles.referralName, { color: textColors.primary }]}>{referral.name}</Text>
                      <Text style={[styles.referralDate, { color: textColors.secondary }]}>{referral.date}</Text>
                    </View>
                    <View style={styles.rewardBadge}>
                      <Text style={styles.rewardText}>{referral.reward}</Text>
                    </View>
                  </View>
                </BlurView>
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  scrollView: { flex: 1 },
  scrollContent: { padding: 18, paddingBottom: 24 },
  codeCard: {
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 14,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  codeBlur: {
    borderRadius: 20,
    overflow: 'hidden',
  },
  codeBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  codeGradient: {
    padding: 24,
    alignItems: 'center',
  },
  codeIconWrapper: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  codeLabel: {
    color: '#7DD3FC',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 12,
  },
  codeContainer: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  codeText: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: '800',
    letterSpacing: 2,
  },
  codeActions: {
    flexDirection: 'row',
    gap: 10,
  },
  codeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(135,206,235,0.25)',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 12,
    gap: 6,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  codeButtonText: {
    color: '#7DD3FC',
    fontSize: 14,
    fontWeight: '700',
  },
  infoCard: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 14,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  infoBlur: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  infoBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  infoContentWrapper: {
    flexDirection: 'row',
    padding: 16,
  },
  infoIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  infoContent: {
    flex: 1,
  },
  infoTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 17,
    fontWeight: '700',
    marginBottom: 6,
  },
  infoText: {
    color: '#7DD3FC',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
  },
  referralsSection: {
    marginBottom: 14,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 40,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginTop: 12,
    marginBottom: 4,
  },
  emptySubtext: {
    color: '#7DD3FC',
    fontSize: 13,
  },
  referralCard: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  referralBlur: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  referralBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  referralContentWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  referralIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  referralContent: {
    flex: 1,
  },
  referralName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 15 : 16,
    fontWeight: '700',
    marginBottom: 4,
  },
  referralDate: {
    color: '#7DD3FC',
    fontSize: 12,
    fontWeight: '600',
  },
  rewardBadge: {
    backgroundColor: 'rgba(16,185,129,0.2)',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  rewardText: {
    color: '#10B981',
    fontSize: 12,
    fontWeight: '700',
  },
});


