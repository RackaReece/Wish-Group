import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Image,
  Alert,
  Linking,
  FlatList,
  NativeSyntheticEvent,
  NativeScrollEvent,
  StatusBar,
  ScrollView,
  RefreshControl,
  Modal,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import ProBookingCard from '../../../src/components/booking/ProBookingCard';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import { openInAppNavigation } from '../../../src/utils/openInAppNavigation';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import MapView, { Marker, Region } from 'react-native-maps';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import * as Location from 'expo-location';
import { useGlobalTheme } from '../../../src/components/shared/GlobalThemeContext';
import { DARK_MAP_STYLE, DEFAULT_MAP_ZOOM_DELTA } from '../../../src/constants/mapStyles';

import { colors } from '../../../src/constants/colors';
import { VALETER_MAP_ICON } from '../../../src/constants/mapIcons';

const APP_ICON = require('../../assets/icon.png');
import { getIconColors } from '../../../src/constants/themeColors';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import { fetchAreaStats, getPeakUrgencyText, DEFAULT_STATS, type AreaStats } from '../../../src/utils/areaStats';

const { width, height } = Dimensions.get('window');
const CARD_PADDING = 24;
const cardWidth = width - CARD_PADDING;
const isSmallScreen = width < 375;
const TRIPS_ACCENT = '#14B8A6'; // teal – distinct from Jobs blue (dark mode)

function formatTimeAgo(iso: string): string {
  const then = new Date(iso).getTime();
  const now = Date.now();
  const mins = Math.floor((now - then) / 60000);
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  return `${days}d ago`;
}

type JobStatus =
  | 'pending_payment'
  | 'payment_processing'
  | 'confirmed'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed';

const ACTIVE_STATUSES: JobStatus[] = ['confirmed', 'en_route', 'arrived', 'in_progress'];

export default function TripsPage() {
  const { user } = useAuth();
  const { mode } = useGlobalTheme();
  const theme = getAccountTheme('valeter', mode);
  const iconColors = getIconColors(theme);
  const params = useLocalSearchParams();
  const insets = useSafeAreaInsets();

  const jobIdParam = typeof params.jobId === 'string' ? params.jobId : undefined;
  const jobId = jobIdParam && jobIdParam !== 'undefined' ? jobIdParam : null;

  const [activeBookings, setActiveBookings] = useState<any[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
    longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
  });
  const [infoModalVisible, setInfoModalVisible] = useState(false);
  const [infoModalBooking, setInfoModalBooking] = useState<any | null>(null);
  const [initialRegion, setInitialRegion] = useState<Region | null>(null);
  const [tripsLoading, setTripsLoading] = useState(true);
  const [lastCompletedTrip, setLastCompletedTrip] = useState<{ completed_at: string; price: number } | null>(null);
  const [valeterLocation, setValeterLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [locationPermission, setLocationPermission] = useState<Location.PermissionStatus | null>(null);
  const [isOnline, setIsOnline] = useState<boolean>(true);
  const [emptyTipIndex, setEmptyTipIndex] = useState(0);
  const [areaStats, setAreaStats] = useState<AreaStats | null>(null);
  const [nearbyValetersCount, setNearbyValetersCount] = useState<number | null>(null);
  const [tripsRefreshing, setTripsRefreshing] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const ctaPulseAnim = useRef(new Animated.Value(1)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const mapRef = useRef<MapView>(null);
  const listRef = useRef<FlatList>(null);

  const activeJob = activeBookings[selectedIndex] ?? null;
  const status: JobStatus = activeJob?.status ?? 'pending_payment';
  const customerName = activeJob?.customer_name ?? 'Customer';
  const customerPhone = activeJob?.customer_phone ?? null;

  const loadAllActiveBookings = React.useCallback(async () => {
    if (!user?.id) return;
    try {
      setTripsLoading(true);
      const { data: rows, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id)
        .in('status', ['pending_payment', ...ACTIVE_STATUSES])
        .order('scheduled_at', { ascending: true });

      if (error) throw error;

      const enriched = await Promise.all(
        (rows ?? []).map(async (b) => {
          let customer_name = 'Customer';
          let customer_phone: string | null = null;
          if (b.user_id) {
            const profile = await fetchProfileById(b.user_id);
            customer_name = profile?.full_name || 'Customer';
            customer_phone = profile?.phone ?? null;
          }
          let vehicle_registration = null;
          let vehicle_make = null;
          let vehicle_model = null;
          let vehicle_type = b.vehicle_type ?? null;
          try {
            const { data: vehicle } = await supabase
              .from('customer_vehicles')
              .select('registration, make, model, type')
              .eq('user_id', b.user_id)
              .eq('is_default', true)
              .maybeSingle();
            if (vehicle) {
              vehicle_registration = vehicle.registration ?? null;
              vehicle_make = vehicle.make ?? null;
              vehicle_model = vehicle.model ?? null;
              vehicle_type = vehicle.type ?? vehicle_type;
            }
          } catch {}
          return {
            ...b,
            customer_name,
            customer_phone,
            vehicle_registration,
            vehicle_make,
            vehicle_model,
            vehicle_type,
          };
        })
      );

      setActiveBookings(enriched);
      const idx = jobId ? enriched.findIndex((b) => b.id === jobId) : 0;
      const safeIdx = idx >= 0 ? idx : 0;
      setSelectedIndex(safeIdx);

      const first = enriched[safeIdx];
      if (first?.location_lat != null && first?.location_lng != null) {
        const newRegion: Region = {
          latitude: first.location_lat,
          longitude: first.location_lng,
          latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
          longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
        };
        setRegion(newRegion);
        setInitialRegion((prev) => prev ?? newRegion);
      }
    } catch (error) {
      console.error('Error loading active bookings:', error);
    } finally {
      setTripsLoading(false);
    }
  }, [user?.id, jobId]);

  const loadLastCompletedTrip = React.useCallback(async () => {
    if (!user?.id) return;
    try {
      const { data: rows, error } = await supabase
        .from('bookings')
        .select('completed_at, price')
        .eq('valeter_id', user.id)
        .eq('status', 'completed')
        .not('completed_at', 'is', null)
        .order('completed_at', { ascending: false })
        .limit(1);
      if (!error && rows?.[0]) {
        setLastCompletedTrip({ completed_at: rows[0].completed_at, price: Number(rows[0].price) || 0 });
      } else {
        setLastCompletedTrip(null);
      }
    } catch {
      setLastCompletedTrip(null);
    }
  }, [user?.id]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(markerPulse, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Request location permission and get user location (non-fatal: simulator may not have location)
    const requestLocationPermission = async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        setLocationPermission(status);
        if (status === 'granted') {
          try {
            const location = await Location.getCurrentPositionAsync({
              accuracy: Location.Accuracy.High,
            });
            setUserLocation({
              latitude: location.coords.latitude,
              longitude: location.coords.longitude,
            });
          } catch (_locErr) {
            // Cannot obtain location – leave userLocation null
          }
        }
      } catch (_permErr) {
        // Permission or location error – non-fatal
      }
    };
    
    requestLocationPermission();
    loadValeterLocation();

    loadAllActiveBookings();
    loadLastCompletedTrip();
  }, [jobId, user?.id, loadAllActiveBookings, loadLastCompletedTrip]);

  const bookingIds = activeBookings.map((b) => b.id).filter(Boolean).join(',');
  useEffect(() => {
    if (activeBookings.length === 0) return;
    const unsub = subscribeToBookings();
    return () => { unsub?.(); };
  }, [bookingIds]);

  useEffect(() => {
    if (activeBookings.length > 0 && selectedIndex > 0) {
      listRef.current?.scrollToOffset({ offset: cardWidth * selectedIndex, animated: false });
    }
  }, [activeBookings.length]);

  // Load and subscribe to online status (valeter_presence)
  useEffect(() => {
    if (!user?.id) return;
    const loadPresence = async () => {
      const { data } = await supabase
        .from('valeter_presence')
        .select('is_online')
        .eq('user_id', user.id)
        .maybeSingle();
      setIsOnline(!!(data as any)?.is_online);
    };
    loadPresence();
    const channel = supabase
      .channel('trips-presence')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'valeter_presence', filter: `user_id=eq.${user.id}` },
        (payload) => {
          const row: any = payload.new ?? payload.old;
          if (row && typeof row.is_online === 'boolean') setIsOnline(row.is_online);
          if (row?.last_lat != null && row?.last_lng != null) setValeterLocation({ lat: row.last_lat, lng: row.last_lng });
        }
      )
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [user?.id]);

  // Watch user location for live updates
  useEffect(() => {
    if (locationPermission !== 'granted') return;
    
    const subscription = Location.watchPositionAsync(
      {
        accuracy: Location.Accuracy.High,
        distanceInterval: 100, // Update every 100 meters
        timeInterval: 30000, // Or every 30 seconds
      },
      (location) => {
        setUserLocation({
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        });
      }
    );

    return () => {
      subscription.then(sub => sub.remove());
    };
  }, [locationPermission]);

  // Push current device location to valeter_presence so customers see valeter in the right place (availability/radius based on current location)
  useEffect(() => {
    if (!user?.id || !isOnline || !userLocation) return;
    const pushLocation = async () => {
      try {
        const lat = Number(userLocation.latitude.toFixed(6));
        const lng = Number(userLocation.longitude.toFixed(6));
        const { error } = await supabase.rpc('update_my_presence', {
          p_is_online: true,
          p_last_lat: lat,
          p_last_lng: lng,
        });
        if (error) {
          await supabase.from('valeter_presence').upsert(
            { user_id: user.id, is_online: true, last_lat: lat, last_lng: lng, updated_at: new Date().toISOString() },
            { onConflict: 'user_id' }
          );
        }
      } catch (_) {}
    };
    pushLocation();
    const interval = setInterval(pushLocation, 15000);
    return () => clearInterval(interval);
  }, [user?.id, isOnline, userLocation?.latitude, userLocation?.longitude]);

  // When we have trips and location(s), fit map to show both valeter and customer (prefer current device location for valeter)
  useEffect(() => {
    if (tripsLoading || activeBookings.length === 0) return;
    const valeterCoords = userLocation ?? (valeterLocation ? { latitude: valeterLocation.lat, longitude: valeterLocation.lng } : null);
    if (!valeterCoords) return;
    const t = setTimeout(() => {
      const coords: { latitude: number; longitude: number }[] = [valeterCoords];
      const job = activeBookings[selectedIndex];
      if (job?.location_lat != null && job?.location_lng != null) coords.push({ latitude: job.location_lat, longitude: job.location_lng });
      if (coords.length >= 2) {
        mapRef.current?.fitToCoordinates(coords, {
          edgePadding: { top: 80, right: 40, bottom: height * 0.45 + 40, left: 40 },
          animated: true,
        });
      }
    }, 500);
    return () => clearTimeout(t);
  }, [tripsLoading, activeBookings.length, selectedIndex, valeterLocation?.lat, valeterLocation?.lng, userLocation?.latitude, userLocation?.longitude]);

  // When there are no trips, center the map on the user's real (device) location
  useEffect(() => {
    if (activeBookings.length > 0 || !userLocation) return;
    const newRegion: Region = {
      latitude: userLocation.latitude,
      longitude: userLocation.longitude,
      latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
      longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
    };
    setRegion(newRegion);
    setInitialRegion(newRegion);
  }, [activeBookings.length, userLocation?.latitude, userLocation?.longitude]);

  const loadValeterLocation = async () => {
    if (!user?.id) return;
    try {
      const { data } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', user.id)
        .single();

      if (data?.last_lat && data?.last_lng) {
        setValeterLocation({ lat: data.last_lat, lng: data.last_lng });
        const newRegion = {
          latitude: data.last_lat,
          longitude: data.last_lng,
          latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
          longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
        };
        setRegion(newRegion);
        setInitialRegion(newRegion);
      }
    } catch (error) {
      console.error('Error loading valeter location:', error);
    }
  };

  const fitMapToShowUserAndCustomer = () => {
    const coords: { latitude: number; longitude: number }[] = [];
    const valeterCoords = userLocation ?? (valeterLocation ? { latitude: valeterLocation.lat, longitude: valeterLocation.lng } : null);
    if (valeterCoords) coords.push(valeterCoords);
    const job = mapSelectedJob ?? activeJob;
    if (job?.location_lat != null && job?.location_lng != null) {
      coords.push({ latitude: job.location_lat, longitude: job.location_lng });
    }
    if (coords.length >= 2) {
      mapRef.current?.fitToCoordinates(coords, {
        edgePadding: { top: 80, right: 40, bottom: height * 0.45 + 40, left: 40 },
        animated: true,
      });
      return true;
    }
    return false;
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    const coords: { latitude: number; longitude: number }[] = [];
    const valeterCoords = userLocation ?? (valeterLocation ? { latitude: valeterLocation.lat, longitude: valeterLocation.lng } : null);
    if (valeterCoords) coords.push(valeterCoords);
    const job = mapSelectedJob ?? activeJob;
    if (job?.location_lat != null && job?.location_lng != null) coords.push({ latitude: job.location_lat, longitude: job.location_lng });
    const unique = coords.filter((c, i) => coords.findIndex((d) => d.latitude === c.latitude && d.longitude === c.longitude) === i);
    if (unique.length >= 2) {
      setTimeout(() => {
        mapRef.current?.fitToCoordinates(unique, {
          edgePadding: { top: 80, right: 40, bottom: height * 0.45 + 40, left: 40 },
          animated: true,
        });
      }, 100);
      return;
    }
    if (activeJob && activeJob.location_lat && activeJob.location_lng) {
      const newRegion: Region = {
        latitude: activeJob.location_lat,
        longitude: activeJob.location_lng,
        latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
        longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
      };
      setRegion(newRegion);
      mapRef.current?.animateToRegion(newRegion, 500);
    } else if (initialRegion) {
      setRegion(initialRegion);
      mapRef.current?.animateToRegion(initialRegion, 500);
    } else if (userLocation) {
      const newRegion: Region = {
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
        longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
      };
      setRegion(newRegion);
      mapRef.current?.animateToRegion(newRegion, 500);
    }
  };

  const handleGoOnline = async () => {
    await hapticFeedback('light');
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Location permission is required to go online so customers can find you.');
        return;
      }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const lat = Number(loc.coords.latitude.toFixed(6));
      const lng = Number(loc.coords.longitude.toFixed(6));
      const { error } = await supabase.rpc('update_my_presence', { p_is_online: true, p_last_lat: lat, p_last_lng: lng });
      if (error) {
        await supabase.from('valeter_presence').upsert(
          { user_id: user?.id, is_online: true, last_lat: lat, last_lng: lng, updated_at: new Date().toISOString() },
          { onConflict: 'user_id' }
        );
      }
      setUserLocation({ latitude: loc.coords.latitude, longitude: loc.coords.longitude });
      setIsOnline(true);
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Could not go online. Try again.');
    }
  };

  const subscribeToBookings = () => {
    if (!user?.id || activeBookings.length === 0) return undefined;
    const ids = new Set(activeBookings.map((b) => b.id).filter(Boolean));
    if (ids.size === 0) return undefined;

    const channel = supabase
      .channel('trips-bookings')
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings' },
        (payload) => {
          const updated = payload.new as any;
          if (!ids.has(updated.id)) return;
          setActiveBookings((prev) => {
            const next = prev.map((b) => (b.id === updated.id ? { ...b, ...updated } : b));
            if (updated.status === 'completed' || updated.status === 'cancelled') {
              return next.filter((b) => b.id !== updated.id);
            }
            return next;
          });
          if (updated.status === 'completed' && activeBookings[selectedIndex]?.id === updated.id) {
            router.replace({ pathname: '/valeter/jobs/complete', params: { jobId: updated.id } });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleRefresh = async () => {
    setTripsRefreshing(true);
    await loadAllActiveBookings();
    setTripsRefreshing(false);
  };

  const assertNoOtherActiveJob = async (currentBookingId: string) => {
    if (!user?.id) return;

    const { data, error } = await supabase
      .from('bookings')
      .select('id,status')
      .eq('valeter_id', user.id)
      .in('status', ACTIVE_STATUSES)
      .neq('id', currentBookingId)
      .order('request_sent_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;

    if (data?.id) {
      throw new Error(
        `You already have another active job (${data.status}). Finish it first before starting service on this one.`
      );
    }
  };

  const updateStatus = async (newStatus: JobStatus, bookingId?: string) => {
    if (!user?.id) return;
    await hapticFeedback('medium');

    const idToUpdate = bookingId ?? activeJob?.id;
    if (!idToUpdate) return;

    try {
      if (newStatus === 'in_progress') {
        await assertNoOtherActiveJob(idToUpdate);
      }

      const { error } = await supabase
        .from('bookings')
        .update({ status: newStatus })
        .eq('id', idToUpdate);

      if (error) throw error;
      setActiveBookings((prev) =>
        prev.map((b) => (b.id === idToUpdate ? { ...b, status: newStatus } : b))
      );
    } catch (error: any) {
      const pgCode = error?.code || error?.details?.code;
      if (
        pgCode === '23505' ||
        String(error?.message || '').toLowerCase().includes('duplicate key value') ||
        String(error?.message || '').includes('ux_active_job_per_valeter')
      ) {
        return;
      }
    }
  };

  const getStatusProgress = (s?: JobStatus): number => {
    const st = s ?? status;
    switch (st) {
      case 'pending_payment': return 20;
      case 'payment_processing': return 30;
      case 'confirmed': return 40;
      case 'en_route': return 60;
      case 'arrived': return 80;
      case 'in_progress': return 90;
      case 'completed': return 100;
      default: return 0;
    }
  };

  const getStatusMessage = (s?: JobStatus): string => {
    const st = s ?? status;
    switch (st) {
      case 'pending_payment': return 'Waiting for customer payment';
      case 'payment_processing': return 'Payment processing';
      case 'confirmed': return 'Paid - Ready to start';
      case 'en_route': return 'On the way to location';
      case 'arrived': return 'Arrived at location';
      case 'in_progress': return 'Service in progress';
      case 'completed': return 'Service completed';
      default: return 'Tracking job';
    }
  };

  const handleCallChat = (booking?: any) => {
    const b = booking ?? activeJob;
    const locked = b?.status === 'pending_payment' || b?.status === 'payment_processing';
    if (locked) {
      hapticFeedback('light');
      Alert.alert('Unlocks after payment', 'Chat / Call becomes available once the customer has paid.');
      return;
    }
    hapticFeedback('light');
    const name = b?.customer_name ?? customerName ?? 'Customer';
    const phone = (b?.customer_phone ?? customerPhone)?.trim() ?? '';
    const vehicle = [b?.vehicle_registration, b?.vehicle_make, b?.vehicle_model, b?.vehicle_type].filter(Boolean).join(' ') || '';
    router.push({
      pathname: '/chat-screen' as any,
      params: {
        recipientId: b?.user_id ?? '',
        recipientName: name,
        recipientType: 'customer',
        phone,
        vehicle,
        bookingStatus: (b?.status ?? '')?.replace(/_/g, ' ') ?? '',
      },
    });
  };

  const handleCancelBooking = (booking?: any) => {
    hapticFeedback('light');
    const b = booking ?? activeJob;
    const idToCancel = b?.id;
    if (!idToCancel) return;
    Alert.alert(
      'Cancel booking',
      'Cancel this booking? You will be removed from this job.',
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, cancel',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('bookings')
                .update({ status: 'cancelled', valeter_id: null })
                .eq('id', idToCancel);
              if (error) throw error;
              setActiveBookings((prev) => {
                const next = prev.filter((x) => x.id !== idToCancel);
                if (next.length === 0) setTimeout(() => router.replace('/valeter/jobs'), 0);
                return next;
              });
              setSelectedIndex((i) => Math.min(i, Math.max(0, activeBookings.length - 2)));
              Alert.alert('Cancelled', 'Booking cancelled.');
            } catch (e: any) {
              Alert.alert('Error', e?.message ?? 'Failed to cancel booking.');
            }
          },
        },
      ]
    );
  };

  const handleCancelAll = () => {
    if (activeBookings.length === 0) return;
    hapticFeedback('light');
    Alert.alert(
      'Cancel all trips',
      `Cancel all ${activeBookings.length} active trip(s)?`,
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, cancel all',
          style: 'destructive',
          onPress: async () => {
            try {
              const ids = activeBookings.map((b) => b.id).filter(Boolean);
              if (ids.length === 0) {
                setActiveBookings([]);
                setSelectedIndex(0);
                router.replace('/valeter/jobs');
                return;
              }
              const { error } = await supabase
                .from('bookings')
                .update({ status: 'cancelled', valeter_id: null })
                .in('id', ids);
              if (error) throw error;
              setActiveBookings([]);
              setSelectedIndex(0);
              router.replace('/valeter/jobs');
              Alert.alert('Cancelled', 'All trips cancelled.');
            } catch (e: any) {
              Alert.alert('Error', e?.message ?? 'Failed to cancel trips.');
            }
          },
        },
      ]
    );
  };

  const getNextAction = (booking?: any): { label: string; action: () => void | Promise<void> } | null => {
    const b = booking ?? activeJob;
    const st = b?.status ?? status;
    switch (st) {
      case 'pending_payment':
      case 'payment_processing':
        return null;
      case 'confirmed':
        return {
          label: 'Start Journey',
          action: async () => {
            await updateStatus('en_route', b?.id);
            if (b?.location_lat != null && b?.location_lng != null) {
              openInAppNavigation(
                b.location_lat,
                b.location_lng,
                b.location_address ?? undefined,
                b?.id
              );
              Alert.alert(
                'Navigation started',
                'Use in-app turn-by-turn, or return here and tap "Mark Arrived" when you arrive.',
                [{ text: 'OK' }]
              );
            }
          },
        };
      case 'en_route':
        return { label: 'Mark Arrived', action: () => updateStatus('arrived', b?.id) };
      case 'arrived':
        return { label: 'Start Service', action: () => updateStatus('in_progress', b?.id) };
      case 'in_progress':
        return { label: 'Complete Service', action: () => updateStatus('completed', b?.id) };
      default:
        return null;
    }
  };

  const nextAction = getNextAction();
  const mapSelectedJob = activeBookings[selectedIndex] ?? null;

  // Rotate empty-state tip every 12s when no active trips
  useEffect(() => {
    if (activeBookings.length > 0) return;
    const t = setInterval(() => setEmptyTipIndex((i) => (i + 1) % 4), 12000);
    return () => clearInterval(t);
  }, [activeBookings.length]);

  // Soft pulse on CTA when no active trips
  useEffect(() => {
    if (activeBookings.length > 0) return;
    const pulse = Animated.loop(
      Animated.sequence([
        Animated.timing(ctaPulseAnim, { toValue: 1.03, duration: 1200, useNativeDriver: true }),
        Animated.timing(ctaPulseAnim, { toValue: 1, duration: 1200, useNativeDriver: true }),
      ])
    );
    pulse.start();
    return () => pulse.stop();
  }, [activeBookings.length, ctaPulseAnim]);

  // Fetch real area stats (peak times, avg wait) when no trips and we have location
  useEffect(() => {
    if (activeBookings.length > 0) return;
    const lat = userLocation?.latitude ?? valeterLocation?.lat ?? region.latitude;
    const lng = userLocation?.longitude ?? valeterLocation?.lng ?? region.longitude;
    let cancelled = false;
    fetchAreaStats(lat, lng).then((s) => {
      if (!cancelled) setAreaStats(s);
    });
    return () => { cancelled = true; };
  }, [activeBookings.length, userLocation?.latitude, userLocation?.longitude, valeterLocation?.lat, valeterLocation?.lng, region.latitude, region.longitude]);

  // Fetch nearby online valeters count for "X nearby" badge
  useEffect(() => {
    if (activeBookings.length > 0) return;
    const lat = userLocation?.latitude ?? valeterLocation?.lat;
    const lng = userLocation?.longitude ?? valeterLocation?.lng;
    if (lat == null || lng == null) return;
    let cancelled = false;
    (async () => {
      try {
        const { data } = await supabase
          .from('valeter_presence')
          .select('user_id, last_lat, last_lng')
          .eq('is_online', true)
          .not('last_lat', 'is', null)
          .not('last_lng', 'is', null);
        const deg = 0.03; // ~3km
        const nearby = (data ?? []).filter(
          (r: any) =>
            r.last_lat >= lat - deg && r.last_lat <= lat + deg &&
            r.last_lng >= lng - deg && r.last_lng <= lng + deg
        ).length;
        if (!cancelled) setNearbyValetersCount(nearby);
      } catch {
        if (!cancelled) setNearbyValetersCount(null);
      }
    })();
    return () => { cancelled = true; };
  }, [activeBookings.length, userLocation?.latitude, userLocation?.longitude, valeterLocation?.lat, valeterLocation?.lng]);

  // Subtle idle camera drift when no active trips (Apple Maps style)
  useEffect(() => {
    if (activeBookings.length > 0) return;
    let step = 1;
    const interval = setInterval(() => {
      setRegion((prev) => {
        const delta = 0.00012;
        return {
          ...prev,
          latitude: prev.latitude + (step ? delta : -delta),
          longitude: prev.longitude + (step ? delta * 0.7 : -delta * 0.7),
        };
      });
      step = step ? 0 : 1;
    }, 3200);
    return () => clearInterval(interval);
  }, [activeBookings.length]);

  const isLight = theme.mode === 'light';
  const pageBg = theme.background;
  const primaryColor = theme.primary;
  const quickAccessButtonStyle = {
    backgroundColor: isLight ? `${primaryColor}22` : `${primaryColor}2B`,
    borderWidth: 0,
  };
  const statusOnlineBg = theme.statusOnlineCardBg ?? 'rgba(16,185,129,0.2)';
  const statusOnlineAccent = theme.statusOnlineAccent ?? '#10B981';
  const emptyCtaColors = isLight ? [theme.primary, theme.primaryAlt] : [TRIPS_ACCENT, '#0D9488'];

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: pageBg[0] }]} edges={[]}>
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} backgroundColor="transparent" translucent />
      <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />
      <ScrollView
        style={styles.content}
        contentContainerStyle={{ flex: 1 }}
        refreshControl={
          <RefreshControl refreshing={tripsRefreshing} onRefresh={handleRefresh} tintColor={primaryColor} />
        }
        showsVerticalScrollIndicator={false}
      >
        <Animated.View style={[StyleSheet.absoluteFill, { opacity: fadeAnim }]}>
        <View style={styles.mapContainer}>
          <MapView
            ref={mapRef}
            style={styles.map}
            region={region}
            showsUserLocation={true}
            showsMyLocationButton={false}
            mapType="standard"
            customMapStyle={mode === 'dark' || isLight ? DARK_MAP_STYLE : undefined}
            userInterfaceStyle="dark"
            mapPadding={{ top: 0, bottom: height * 0.45, left: 0, right: 0 }}
            loadingEnabled={true}
            loadingIndicatorColor={primaryColor}
            followsUserLocation={false}
            userLocationPriority="high"
            userLocationUpdateInterval={5000}
            onMapReady={() => {
              if (activeBookings.length > 0 || valeterLocation || userLocation) {
                setTimeout(() => fitMapToShowUserAndCustomer(), 300);
              }
            }}
          >
            {(userLocation ?? valeterLocation) && (
              <Marker
                coordinate={userLocation
                  ? { latitude: userLocation.latitude, longitude: userLocation.longitude }
                  : { latitude: valeterLocation!.lat, longitude: valeterLocation!.lng }
                }
                anchor={{ x: 0.5, y: 0.5 }}
                tracksViewChanges={false}
              >
                <Animated.View style={[styles.valeterMarker, { transform: [{ scale: markerPulse }] }]}>
                  <View style={[styles.valeterMarkerGlow, { backgroundColor: colors.SKY }]} />
                  <View style={[styles.valeterMarkerShadow, { backgroundColor: primaryColor }]} />
                  <Image
                    source={VALETER_MAP_ICON}
                    style={styles.valeterMarkerImage}
                    resizeMode="contain"
                  />
                </Animated.View>
              </Marker>
            )}
            {mapSelectedJob != null && mapSelectedJob.location_lat != null && mapSelectedJob.location_lng != null && (
              <Marker
                coordinate={{
                  latitude: mapSelectedJob.location_lat,
                  longitude: mapSelectedJob.location_lng,
                }}
                anchor={{ x: 0.5, y: 0.5 }}
                tracksViewChanges={false}
              >
                <Animated.View
                  style={[
                    styles.markerContainer,
                    { transform: [{ scale: markerPulse }] },
                  ]}
                >
                  <View style={styles.marker}>
                    <Image
                      source={VALETER_MAP_ICON}
                      style={styles.carMarkerImage}
                      resizeMode="contain"
                    />
                  </View>
                </Animated.View>
              </Marker>
            )}
          </MapView>
          {/* Recenter button — bottom right on map */}
          <View style={[styles.recenterButtonContainer, { top: HEADER_CONTENT_OFFSET + 56 }]} pointerEvents="box-none">
            <TouchableOpacity
              onPress={handleRecenter}
              style={[styles.recenterButton, isLight && styles.recenterButtonLight]}
              activeOpacity={0.85}
            >
              <Ionicons name="locate" size={22} color={primaryColor} />
            </TouchableOpacity>
          </View>
          {/* Map controls: online status + cancel-all (when has trips) */}
          <View style={[styles.mapControlsOverlay, { top: HEADER_CONTENT_OFFSET + 12 }]} pointerEvents="box-none">
            <View
              style={[
                styles.mapOnlinePill,
                !isOnline && styles.mapOnlinePillOffline,
                isLight && {
                  backgroundColor: isOnline ? statusOnlineBg : 'rgba(156,163,175,0.2)',
                },
              ]}
            >
              <View style={[styles.mapOnlineDot, { backgroundColor: isOnline ? statusOnlineAccent : '#9CA3AF' }]} />
              <Text style={[styles.mapOnlineLabel, isLight && { color: theme.textPrimary }]}>{isOnline ? 'Online' : 'Offline'}</Text>
            </View>
            {activeBookings.length > 0 && (
              <TouchableOpacity onPress={handleCancelAll} style={[styles.cancelAllButton, isLight && styles.cancelAllButtonLight]} activeOpacity={0.85}>
                <View style={styles.cancelAllIconWrap}>
                  <Ionicons name="trash-outline" size={18} color="#FFFFFF" />
                </View>
                <Text style={styles.cancelAllLabel}>Cancel all</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Brand watermark — subtle, top corner */}
        <View style={styles.brandWatermark} pointerEvents="none">
          <Image source={APP_ICON} style={styles.brandWatermarkImage} resizeMode="contain" />
        </View>
        <View style={styles.headerOverlay}>
          <AppHeader title="Trips" accountType="valeter" lowOpacity />
        </View>

        {tripsLoading && (
          <View style={styles.loadingOverlay} pointerEvents="none">
            <ActivityIndicator size="large" color={primaryColor} />
            <Text style={[styles.loadingOverlayText, isLight && { color: theme.textPrimary }]}>Loading trips…</Text>
          </View>
        )}

        {!tripsLoading && activeBookings.length === 0 ? (
          <View style={[styles.emptyContainer, { bottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 48 }]}>
            <BlurView intensity={isLight ? 32 : 60} tint={isLight ? 'light' : 'dark'} style={[styles.emptyCardTrips, styles.emptyCardCompact, isLight && { shadowColor: theme.shadowColor }]}>
              <View style={[styles.emptyCardTripsBg, isLight && { backgroundColor: `${primaryColor}08` }]} />
              <View style={[styles.emptyCardTripsBorder]} />
              <View style={styles.emptyContent}>
                <Ionicons name="car-outline" size={48} color={primaryColor} style={{ opacity: 0.8, marginBottom: 8 }} />
                <Text style={[styles.emptyTitle, styles.emptyTitleCompact, isLight && styles.emptyTitleLight]}>No active jobs</Text>
                <Text style={[styles.emptyMicroPrompt, isLight && styles.emptyMicroPromptLight]}>
                  Your accepted jobs will appear here. Tap below to see available jobs.
                </Text>
                <TouchableOpacity
                  onPress={() => { hapticFeedback('light'); router.push('/valeter/jobs' as any); }}
                  activeOpacity={0.85}
                  style={styles.emptyCtaButton}
                >
                  <LinearGradient colors={emptyCtaColors} style={styles.emptyCtaGradient}>
                    <Ionicons name="briefcase-outline" size={18} color="#FFFFFF" />
                    <Text style={styles.emptyCtaLabel}>View jobs</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </BlurView>
          </View>
        ) : !tripsLoading && activeBookings.length > 0 ? (
          <Animated.View
            style={[
              styles.cardContainer,
              {
                opacity: fadeAnim,
                bottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom,
              },
            ]}
          >
            <FlatList
              ref={listRef}
              data={activeBookings}
              keyExtractor={(item) => item.id}
              horizontal
              pagingEnabled
              showsHorizontalScrollIndicator={false}
              snapToInterval={cardWidth}
              snapToAlignment="start"
              decelerationRate="fast"
              getItemLayout={(_, index) => ({ length: cardWidth, offset: cardWidth * index, index })}
              onMomentumScrollEnd={(e: NativeSyntheticEvent<NativeScrollEvent>) => {
                const i = Math.round(e.nativeEvent.contentOffset.x / cardWidth);
                setSelectedIndex(i);
                const b = activeBookings[i];
                if (b?.location_lat != null && b?.location_lng != null) {
                  const newRegion: Region = {
                    latitude: b.location_lat,
                    longitude: b.location_lng,
                    latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
                    longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
                  };
                  setRegion(newRegion);
                  mapRef.current?.animateToRegion(newRegion, 400);
                }
              }}
              renderItem={({ item: booking }) => {
                const st = booking.status as JobStatus;
                const nextAction = getNextAction(booking);
                return (
                  <View style={[styles.cardSlide, { width: cardWidth }]}>
                    <ProBookingCard
                      stripColor={primaryColor}
                      intensity={isLight ? 24 : 40}
                      compact
                      style={[styles.trackingCardPremium, isLight && { shadowColor: theme.shadowColor, shadowOpacity: 0.22 }]}
                    >
                      <LinearGradient
                        colors={isLight ? [`${primaryColor}18`, `${primaryColor}08`] : ['rgba(135,206,235,0.12)', 'rgba(135,206,235,0.06)']}
                        style={StyleSheet.absoluteFill}
                      />
                      <View style={styles.trackingCardGradient}>
                        <View style={styles.trackingStatusBar}>
                          {[20, 40, 60, 80, 100].map((p, i) => (
                            <React.Fragment key={p}>
                              <View style={[styles.trackingStatusDot, getStatusProgress(st) >= p && [styles.trackingStatusDotDone, { backgroundColor: primaryColor }]]} />
                              {i < 4 && <View style={[styles.trackingStatusLine, getStatusProgress(st) >= p + 20 && [styles.trackingStatusLineDone, { backgroundColor: primaryColor }]]} />}
                            </React.Fragment>
                          ))}
                        </View>
                        <View style={styles.trackingHeader}>
                          <View style={styles.trackingHeaderLeft}>
                            <StatusBadge status={st} size="medium" />
                            <Text style={[styles.statusMessage, isLight && { color: primaryColor }]} numberOfLines={1}>{getStatusMessage(st)}</Text>
                          </View>
                          <TouchableOpacity
                            onPress={() => { hapticFeedback('light'); setInfoModalBooking(booking); setInfoModalVisible(true); }}
                            style={styles.infoBox}
                            activeOpacity={0.8}
                          >
                            <View style={[styles.infoBoxInner, isLight && styles.infoBoxInnerLight]}>
                              <Ionicons name="information-circle-outline" size={22} color={primaryColor} />
                            </View>
                          </TouchableOpacity>
                        </View>

                        <View style={styles.progressRow}>
                          <View style={styles.progressRingWrap}>
                            <AnimatedProgress progress={getStatusProgress(st)} size={88} strokeWidth={7} percentageFontSize={16} color={primaryColor} colorCycle={[colors.SKY, '#10B981', '#8B5CF6', '#F59E0B']} />
                          </View>
                        </View>

                        <View style={[styles.jobInfo, isLight && styles.jobInfoLight]}>
                          <View style={styles.infoRow}>
                            <Ionicons name="water-outline" size={18} color={primaryColor} />
                            <Text style={[styles.infoText, isLight && styles.infoTextLight]} numberOfLines={1}>
                              {getServiceDisplayName(booking.service_type, booking.service_name)}
                            </Text>
                          </View>
                          {booking.customer_name && (
                            <View style={styles.infoRow}>
                              <Ionicons name="person-outline" size={18} color={primaryColor} />
                              <Text style={[styles.infoText, isLight && styles.infoTextLight]} numberOfLines={1}>{booking.customer_name}</Text>
                            </View>
                          )}
                          <View style={styles.infoRow}>
                            <Ionicons name="location-outline" size={18} color={primaryColor} />
                            <Text style={[styles.infoText, isLight && styles.infoTextLight]} numberOfLines={2}>{booking.location_address || '—'}</Text>
                          </View>
                          {(booking.vehicle_registration || booking.vehicle_type || booking.vehicle_make || booking.vehicle_model) && (
                            <View style={styles.infoRow}>
                              <Ionicons name="car-sport-outline" size={18} color={primaryColor} />
                              <View style={styles.vehicleInfoContainer}>
                                {booking.vehicle_registration && (
                                  <Text style={styles.vehicleRegistration}>{booking.vehicle_registration}</Text>
                                )}
                                <Text style={[styles.infoText, isLight && styles.infoTextLight]} numberOfLines={1}>
                                  {[booking.vehicle_make, booking.vehicle_model, booking.vehicle_type].filter(Boolean).join(' ')}
                                </Text>
                              </View>
                            </View>
                          )}
                          <View style={styles.infoRow}>
                            <Ionicons name="cash-outline" size={18} color={primaryColor} />
                            <Text style={[styles.infoText, isLight && styles.infoTextLight]}>£{booking.price?.toFixed(2) || '0.00'}</Text>
                          </View>
                        </View>

                        {nextAction && (
                          <TouchableOpacity
                            onPress={nextAction.action}
                            style={styles.actionButton}
                            activeOpacity={0.8}
                          >
                            <LinearGradient
                              colors={isLight ? [primaryColor, theme.primaryAlt ?? primaryColor] : [colors.SKY, '#60A5FA']}
                              style={styles.actionGradient}
                            >
                              <Text style={styles.actionText}>{nextAction.label}</Text>
                              <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                            </LinearGradient>
                          </TouchableOpacity>
                        )}
                      </View>
                    </ProBookingCard>
                  </View>
                );
              }}
            />
            {activeBookings.length > 1 && (
              <View style={styles.pageIndicator}>
                {activeBookings.map((_, i) => (
                  <View
                    key={i}
                    style={[
                      styles.pageDot,
                      i === selectedIndex && [styles.pageDotActive, { backgroundColor: primaryColor }],
                    ]}
                  />
                ))}
              </View>
            )}
          </Animated.View>
        ) : null}

        {/* Info modal – customer design, UI colours */}
        <Modal visible={infoModalVisible} transparent animationType="fade" onRequestClose={() => { setInfoModalVisible(false); setInfoModalBooking(null); }}>
          <Pressable style={styles.infoModalOverlay} onPress={() => { setInfoModalVisible(false); setInfoModalBooking(null); }}>
            {infoModalBooking && (
              <Pressable
                style={[
                  styles.infoModalContent,
                  { backgroundColor: isLight ? (theme.cardBackground ?? '#F1F5F9') : (theme.background?.[0] ?? '#1E293B') },
                ]}
                onPress={(e) => e.stopPropagation()}
              >
                <View style={styles.infoModalHeader}>
                  <Text style={[styles.infoModalTitle, { color: theme.textPrimary ?? '#F9FAFB' }]}>Job details</Text>
                  <TouchableOpacity onPress={() => { setInfoModalVisible(false); setInfoModalBooking(null); }} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}>
                    <Ionicons name="close" size={24} color={theme.textSecondary ?? '#94A3B8'} />
                  </TouchableOpacity>
                </View>
                <View style={styles.infoModalBody}>
                  <View style={styles.infoRowModal}>
                    <Ionicons name="water-outline" size={18} color={primaryColor} />
                    <Text style={[styles.infoTextModal, { color: theme.textSecondary ?? '#E5E7EB' }]} numberOfLines={2}>
                      {getServiceDisplayName(infoModalBooking.service_type, infoModalBooking.service_name)}
                    </Text>
                  </View>
                  {infoModalBooking.user_id && (
                    <View style={styles.infoRowModal}>
                      <Ionicons name="person-outline" size={18} color={primaryColor} />
                      <Text style={[styles.infoTextModal, { color: theme.textSecondary ?? '#E5E7EB' }]} numberOfLines={1}>{infoModalBooking.customer_name ?? 'Customer'}</Text>
                    </View>
                  )}
                  <View style={styles.infoRowModal}>
                    <Ionicons name="location-outline" size={18} color={primaryColor} />
                    <Text style={[styles.infoTextModal, { color: theme.textSecondary ?? '#E5E7EB' }]} numberOfLines={2}>{infoModalBooking.location_address || '—'}</Text>
                  </View>
                  {(infoModalBooking.vehicle_registration || infoModalBooking.vehicle_type || infoModalBooking.vehicle_make || infoModalBooking.vehicle_model) && (
                    <View style={styles.infoRowModal}>
                      <Ionicons name="car-sport-outline" size={18} color={primaryColor} />
                      <Text style={[styles.infoTextModal, { color: theme.textSecondary ?? '#E5E7EB' }]} numberOfLines={1}>
                        {[infoModalBooking.vehicle_registration, infoModalBooking.vehicle_make, infoModalBooking.vehicle_model, infoModalBooking.vehicle_type].filter(Boolean).join(' ')}
                      </Text>
                    </View>
                  )}
                  <View style={styles.infoRowModal}>
                    <Ionicons name="cash-outline" size={18} color={primaryColor} />
                    <Text style={[styles.infoTextModal, { color: theme.textSecondary ?? '#E5E7EB' }]}>£{infoModalBooking.price?.toFixed(2) || '0.00'}</Text>
                  </View>
                  <View style={styles.infoModalProgress}>
                    <Text style={[styles.infoModalProgressLabel, { color: theme.textSecondary ?? '#94A3B8' }]}>Progress</Text>
                    <AnimatedProgress progress={getStatusProgress(infoModalBooking.status)} size={80} strokeWidth={6} percentageFontSize={14} color={primaryColor} colorCycle={[colors.SKY, '#10B981', '#8B5CF6', '#F59E0B']} />
                  </View>
                </View>
                <TouchableOpacity style={[styles.infoModalDone, { backgroundColor: primaryColor }]} onPress={() => { setInfoModalVisible(false); setInfoModalBooking(null); }} activeOpacity={0.9}>
                  <Text style={styles.infoModalDoneText}>Close</Text>
                </TouchableOpacity>
              </Pressable>
            )}
          </Pressable>
        </Modal>
        </Animated.View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  content: {
    flex: 1,
  },
  mapControlsOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    zIndex: 10,
  },
  mapControlsRightRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  mapControlsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  mapOnlinePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 0,
  },
  mapOnlinePillOffline: {
    backgroundColor: 'rgba(156,163,175,0.25)',
  },
  mapOnlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  mapOnlineLabel: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '600',
  },
  nearbyBadge: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(125,211,252,0.2)',
    borderWidth: 0,
  },
  nearbyBadgeLight: {
    backgroundColor: 'rgba(91,143,168,0.25)',
  },
  nearbyBadgeText: {
    color: 'rgba(249,250,251,0.95)',
    fontSize: 12,
    fontWeight: '600',
  },
  nearbyBadgeTextLight: { color: '#7DD3FC' },
  tripsBadgeContainer: {
    position: 'absolute',
    right: 12,
    alignItems: 'flex-end',
    gap: 6,
    zIndex: 5,
  },
  tripsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(0,0,0,0.6)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  tripsBadgeDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  tripsBadgeText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  cancelAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 20,
    backgroundColor: 'rgba(239,68,68,0.85)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.25)',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.25,
    shadowRadius: 3,
  },
  cancelAllButtonLight: {
    backgroundColor: 'rgba(239,68,68,0.9)',
    borderColor: 'rgba(255,255,255,0.35)',
  },
  cancelAllIconWrap: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: 'rgba(0,0,0,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelAllLabel: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '700',
  },
  mapControlsRight: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  brandWatermark: {
    position: 'absolute',
    top: 56,
    right: 16,
    zIndex: 5,
    opacity: 0.15,
  },
  brandWatermarkImage: {
    width: 32,
    height: 32,
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 100,
    backgroundColor: 'transparent',
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
    zIndex: 15,
  },
  loadingOverlayText: {
    color: '#F9FAFB',
    fontSize: 14,
    marginTop: 12,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  recenterButtonContainer: {
    position: 'absolute',
    right: 16,
    zIndex: 20,
  },
  recenterButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  recenterButtonLight: {
    backgroundColor: 'rgba(125,211,252,0.35)',
    borderColor: 'rgba(125,211,252,0.5)',
  },
  refreshButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  mapContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  mapActionButtons: {
    position: 'absolute',
    right: 16,
    zIndex: 100,
    gap: 10,
  },
  mapActionBtn: { width: 48, height: 48 },
  mapActionBtnInner: {
    width: '100%',
    height: '100%',
    borderRadius: 24,
    backgroundColor: 'rgba(15,23,42,0.85)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapActionBtnInnerDisabled: {
    backgroundColor: 'rgba(100,116,139,0.25)',
  },
  mapActionBtnCancel: {
    backgroundColor: 'rgba(239,68,68,0.15)',
  },
  valeterMarker: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  valeterMarkerGlow: {
    position: 'absolute',
    width: 52,
    height: 52,
    borderRadius: 26,
    opacity: 0.35,
  },
  valeterMarkerShadow: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: colors.SKY,
    opacity: 0.3,
  },
  valeterMarkerImage: {
    width: 36,
    height: 36,
    borderRadius: 18,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  marker: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
  },
  carMarkerImage: {
    width: 28,
    height: 28,
  },
  ghostMarker: {
    width: 24,
    height: 24,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  ghostMarkerImage: {
    width: 20,
    height: 20,
  },
  jobCardBackground: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(135,206,235,0.18)',
    borderRadius: 20,
  },
  jobCardBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.5)',
    pointerEvents: 'none',
  },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 16,
  },
  cardSlide: {
    paddingHorizontal: 0,
  },
  pageIndicator: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    marginTop: 12,
  },
  pageDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  pageDotActive: {
    backgroundColor: colors.SKY,
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  trackingCardPremium: {
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 0,
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
  },
  trackingCardBlur: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 24,
  },
  trackingCardGradient: {
    padding: 22,
  },
  trackingStatusBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingHorizontal: 2,
  },
  trackingStatusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: 'rgba(135,206,235,0.3)',
  },
  trackingStatusDotDone: {
    backgroundColor: colors.SKY,
  },
  trackingStatusLine: {
    flex: 1,
    height: 3,
    backgroundColor: 'rgba(135,206,235,0.2)',
    marginHorizontal: 3,
    borderRadius: 2,
  },
  trackingStatusLineDone: {
    backgroundColor: colors.SKY,
  },
  trackingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    gap: 10,
  },
  trackingHeaderLeft: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    minWidth: 0,
  },
  infoBox: { width: 42, height: 42 },
  infoBoxInner: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoBoxInnerLight: {
    backgroundColor: 'rgba(91,143,168,0.2)',
  },
  statusMessage: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    flex: 1,
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 14,
    paddingHorizontal: 4,
  },
  progressRingWrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconButton: {
    alignItems: 'center',
    minWidth: 52,
  },
  iconButtonInner: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 2,
  },
  iconButtonCancel: {
    backgroundColor: 'rgba(239,68,68,0.15)',
  },
  iconButtonInnerSmall: {
    width: 36,
    height: 36,
    borderRadius: 18,
  },
  iconButtonLabelSmall: {
    fontSize: 12,
  },
  iconButtonLabel: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 14,
    fontWeight: '600',
  },
  iconButtonLabelLight: {
    color: '#7DD3FC',
  },
  iconButtonLocked: { opacity: 0.7 },
  iconButtonInnerLocked: { backgroundColor: 'rgba(255,255,255,0.06)' },
  iconButtonLabelLocked: { color: 'rgba(249,250,251,0.5)' },
  jobInfo: {
    gap: 10,
    marginBottom: 14,
    paddingTop: 14,
    borderTopWidth: 0,
  },
  jobInfoLight: {
    borderTopColor: 'rgba(91,143,168,0.4)',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoText: {
    color: '#E5E7EB',
    fontSize: 16,
    flex: 1,
  },
  infoTextLight: {
    color: '#7DD3FC',
  },
  vehicleInfoContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flexWrap: 'wrap',
  },
  vehicleRegistration: {
    color: colors.SKY,
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 1,
    fontFamily: 'monospace',
  },
  actionButton: {
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: colors.SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  actionGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 36,
    gap: 10,
  },
  actionText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  infoModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  infoModalContent: {
    width: '100%',
    maxWidth: 340,
    borderRadius: 20,
    padding: 20,
    borderWidth: 0,
  },
  infoModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  infoModalTitle: {
    fontSize: 18,
    fontWeight: '800',
  },
  infoModalBody: { gap: 12, marginBottom: 20 },
  infoRowModal: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  infoTextModal: { fontSize: 14, flex: 1 },
  infoModalProgress: {
    alignItems: 'center',
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 0,
  },
  infoModalProgressLabel: {
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 8,
  },
  infoModalDone: {
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
    marginTop: 16,
  },
  infoModalDoneText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: colors.SKY,
    fontSize: 14,
  },
  emptyContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    padding: 20,
  },
  emptyCard: {
    padding: 40,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 0,
    backgroundColor: 'rgba(135,206,235,0.12)',
    elevation: 8,
    shadowColor: colors.SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    position: 'relative',
  },
  emptyContent: {
    alignItems: 'center',
  },
  searchingSpinner: {
    marginBottom: 4,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 8,
    marginBottom: 4,
  },
  emptyTitleLight: { color: '#7DD3FC' },
  emptyMicroPrompt: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 14,
    fontWeight: '600',
    marginTop: 4,
    marginBottom: 2,
    textAlign: 'center',
  },
  emptyMicroPromptLight: { color: 'rgba(125,211,252,0.95)' },
  contextChipsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
    paddingHorizontal: 4,
  },
  contextChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: 'rgba(20,184,166,0.15)',
    borderWidth: 0,
  },
  contextChipLight: {
    backgroundColor: 'rgba(91,143,168,0.2)',
  },
  contextChipText: {
    color: 'rgba(249,250,251,0.95)',
    fontSize: 12,
    fontWeight: '600',
  },
  contextChipTextLight: { color: '#7DD3FC' },
  emptySubtitle: {
    color: TRIPS_ACCENT,
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 12,
    opacity: 0.95,
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 12,
  },
  emptyTextLight: { color: 'rgba(249,250,251,0.85)' },
  emptyNudgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 8,
  },
  emptyNudgeIcon: {
    width: 22,
  },
  emptyNudgeText: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 13,
    flex: 1,
  },
  emptyNudgeTextLight: {
    color: 'rgba(125,211,252,0.95)',
  },
  emptyCtaButton: {
    marginTop: 10,
    marginBottom: 8,
    borderRadius: 14,
    overflow: 'hidden',
    alignSelf: 'stretch',
    maxWidth: 280,
  },
  emptyCtaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 24,
  },
  emptyCtaLabel: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
  emptyCardCompact: {
    padding: 24,
  },
  emptyTitleCompact: { fontSize: 18, marginTop: 4 },
  emptySubtitleCompact: { fontSize: 13, marginBottom: 8 },
  emptyNudgeTextCompact: { fontSize: 12 },
  emptyCardTrips: {
    padding: 24,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 0,
    backgroundColor: 'rgba(20,184,166,0.1)',
    elevation: 8,
    shadowColor: TRIPS_ACCENT,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    position: 'relative',
  },
  emptyCardTripsBg: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(20,184,166,0.12)',
    borderRadius: 20,
  },
  emptyCardTripsBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 0,
    pointerEvents: 'none',
  },
  lastTripPreview: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 16,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(20,184,166,0.2)',
    borderWidth: 0,
  },
  lastTripText: {
    color: 'rgba(249,250,251,0.95)',
    fontSize: 14,
    fontWeight: '600',
  },
});
