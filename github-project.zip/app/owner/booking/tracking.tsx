import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  ActivityIndicator,
  Image,
  Modal,
  Pressable,
  Platform,
  Linking,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams, useFocusEffect } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import ProBookingCard from '../../../src/components/booking/ProBookingCard';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import { CUSTOMER_MAP_ICON, HUB_MAP_ICON, VALETER_MAP_ICON } from '../../../src/constants/mapIcons';

const DEFAULT_MAP_REGION: Region = {
  latitude: 51.5074,
  longitude: -0.1278,
  latitudeDelta: 0.005,
  longitudeDelta: 0.005,
};

const SKY = colors.SKY ?? '#38BDF8';
const { width } = Dimensions.get('window');
const CARD_WIDTH = width - 48;

// Bubble configs for "washing" state – float inside the tracking card
const BUBBLE_CONFIG = [
  { size: 8, left: 12, top: 75 }, { size: 6, left: 28, top: 85 }, { size: 10, left: 50, top: 70 },
  { size: 7, left: 72, top: 80 }, { size: 9, left: 88, top: 65 }, { size: 6, left: 18, top: 55 },
  { size: 8, left: 45, top: 90 }, { size: 7, left: 65, top: 60 }, { size: 10, left: 82, top: 72 },
  { size: 6, left: 35, top: 78 }, { size: 8, left: 55, top: 85 }, { size: 7, left: 90, top: 55 },
];

type BookingStatus =
  | 'pending_valeter_acceptance'
  | 'pending_payment'
  | 'confirmed'
  | 'valeter_assigned'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

type BookingRow = {
  id: string;
  status: BookingStatus;
  service_type: string;
  service_name?: string | null;
  price: number | string | null;
  location_address?: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
  valeter_id?: string | null;
  location_id?: string | null;
};

type WashHub = {
  id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
};

export default function BookingTracking() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const insets = useSafeAreaInsets();

  const bookingId = typeof params.bookingId === 'string' ? params.bookingId : undefined;

  const [booking, setBooking] = useState<BookingRow | null>(null);
  const [valeterName, setValeterName] = useState<string>('Valeter');
  const [status, setStatus] = useState<BookingStatus>('pending_payment');
  const [valeterLocation, setValeterLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [washHub, setWashHub] = useState<WashHub | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const [markingArrived, setMarkingArrived] = useState(false);
  const [infoModalVisible, setInfoModalVisible] = useState(false);
  const [showCompletedConfetti, setShowCompletedConfetti] = useState(false);

  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [liveRegion, setLiveRegion] = useState<Region | null>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const bubbleAnims = useRef(
    BUBBLE_CONFIG.map(() => ({ y: new Animated.Value(0) }))
  ).current;
  const bubbleLoopsRef = useRef<Animated.CompositeAnimation[]>([]);
  const bookingChannelRef = useRef<any>(null);
  const presenceChannelRef = useRef<any>(null);
  const presenceValeterIdRef = useRef<string | null>(null);

  const markerPulseLoopRef = useRef<Animated.CompositeAnimation | null>(null);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(markerPulse, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    );
    markerPulseLoopRef.current = loop;
    loop.start();
    return () => {
      if (markerPulseLoopRef.current) {
        markerPulseLoopRef.current.stop();
        markerPulseLoopRef.current = null;
      }
    };
  }, []);

  // Floating bubbles when status is in_progress (washing)
  useEffect(() => {
    if (status !== 'in_progress') {
      bubbleLoopsRef.current.forEach((loop) => loop.stop());
      bubbleLoopsRef.current = [];
      return;
    }
    bubbleAnims.forEach((b, i) => b.y.setValue(0));
    bubbleLoopsRef.current = bubbleAnims.map((b, i) =>
      Animated.loop(
        Animated.sequence([
          Animated.timing(b.y, {
            toValue: -280,
            duration: 2800 + i * 180,
            useNativeDriver: true,
          }),
          Animated.timing(b.y, { toValue: 0, duration: 0, useNativeDriver: true }),
        ])
      )
    );
    bubbleLoopsRef.current.forEach((loop) => loop.start());
    return () => {
      bubbleLoopsRef.current.forEach((loop) => loop.stop());
      bubbleLoopsRef.current = [];
    };
  }, [status]);

  useEffect(() => {
    if (!bookingId) return;

    const start = async () => {
      await loadBooking();
      subscribeToBooking();
    };

    start();

    return () => {
      if (bookingChannelRef.current) supabase.removeChannel(bookingChannelRef.current);
      if (presenceChannelRef.current) supabase.removeChannel(presenceChannelRef.current);
      bookingChannelRef.current = null;
      presenceChannelRef.current = null;
      presenceValeterIdRef.current = null;
    };
  }, [bookingId]);

  // Poll for updates every 4s - ensures tracking updates even if Realtime is delayed
  useEffect(() => {
    if (!bookingId || !booking) return;
    if (status === 'completed' || status === 'cancelled') return;

    const interval = setInterval(() => loadBooking(), 4000);
    return () => clearInterval(interval);
  }, [bookingId, booking?.id, status]);

  // Refetch immediately when screen gains focus (e.g. returning from payment)
  useFocusEffect(
    React.useCallback(() => {
      if (bookingId) loadBooking();
    }, [bookingId])
  );

  const loadBooking = async () => {
    if (!bookingId) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', bookingId)
        .single();

      if (error) throw error;

      const row = data as BookingRow;
      setBooking(row);
      setStatus(row.status);

      if (row.valeter_id) {
        const profile = await fetchProfileById(row.valeter_id);
        setValeterName(profile?.full_name || 'Valeter');
        ensurePresenceSubscription(row.valeter_id);
        await loadValeterPresenceOnce(row.valeter_id);
      } else {
        setValeterName('Valeter');
      }

      if (row.location_id) {
        await loadWashHub(row.location_id);
      }

      updateMapRegion(row);
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const subscribeToBooking = () => {
    if (!bookingId || bookingChannelRef.current) return;

    const channel = supabase
      .channel(`booking-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        async (payload) => {
          const updated = payload.new as BookingRow;
          setBooking(updated);
          setStatus(updated.status);

          if (updated.valeter_id) {
            const profile = await fetchProfileById(updated.valeter_id);
            setValeterName(profile?.full_name || 'Valeter');
            ensurePresenceSubscription(updated.valeter_id);
            await loadValeterPresenceOnce(updated.valeter_id);
          }

          if (updated.location_id && !washHub) {
            await loadWashHub(updated.location_id);
          }

          if (updated.status === 'completed') {
            setShowCompletedConfetti(true);
          }

          if (updated.status === 'cancelled') {
            setTimeout(() => router.replace('/'), 700);
          }

          updateMapRegion(updated);
        }
      )
      .subscribe();

    bookingChannelRef.current = channel;
  };

  const ensurePresenceSubscription = (valeterId: string) => {
    if (presenceValeterIdRef.current === valeterId && presenceChannelRef.current) return;
    if (presenceChannelRef.current) {
      supabase.removeChannel(presenceChannelRef.current);
      presenceChannelRef.current = null;
    }
    presenceValeterIdRef.current = valeterId;

    const channel = supabase
      .channel(`valeter-presence-${valeterId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${valeterId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          if (updated?.last_lat && updated?.last_lng) {
            setValeterLocation({ latitude: updated.last_lat, longitude: updated.last_lng });
          }
        }
      )
      .subscribe();

    presenceChannelRef.current = channel;
  };

  const loadValeterPresenceOnce = async (valeterId: string) => {
    try {
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', valeterId)
        .maybeSingle();

      if (error) return;
      if (data?.last_lat && data?.last_lng) {
        setValeterLocation({ latitude: data.last_lat, longitude: data.last_lng });
      }
    } catch {}
  };

  const loadWashHub = async (locationId: string) => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, latitude, longitude')
        .eq('id', locationId)
        .maybeSingle();

      if (error) throw error;
      if (data && data.latitude && data.longitude) {
        setWashHub({
          id: data.id,
          name: data.name || 'Wash Hub',
          address: data.address,
          latitude: data.latitude,
          longitude: data.longitude,
        });
      }
    } catch (error) {
      console.error('Error loading wash hub:', error);
    }
  };

  const updateMapRegion = (bookingData: BookingRow) => {
    const points: Array<{ latitude: number; longitude: number }> = [];

    if (bookingData.location_lat && bookingData.location_lng) {
      points.push({ latitude: bookingData.location_lat, longitude: bookingData.location_lng });
    }
    if (valeterLocation) {
      points.push(valeterLocation);
    }
    if (washHub?.latitude && washHub?.longitude) {
      points.push({ latitude: washHub.latitude, longitude: washHub.longitude });
    }

    if (points.length === 0 && bookingData.location_lat && bookingData.location_lng) {
      setRegion({
        latitude: bookingData.location_lat,
        longitude: bookingData.location_lng,
        latitudeDelta: 0.002,
        longitudeDelta: 0.002,
      });
      return;
    }

    if (points.length > 0) {
      const lats = points.map((p) => p.latitude);
      const lngs = points.map((p) => p.longitude);
      const minLat = Math.min(...lats);
      const maxLat = Math.max(...lats);
      const minLng = Math.min(...lngs);
      const maxLng = Math.max(...lngs);
      const latPadding = (maxLat - minLat) * 0.3;
      const lngPadding = (maxLng - minLng) * 0.3;

      setRegion({
        latitude: (minLat + maxLat) / 2,
        longitude: (minLng + maxLng) / 2,
        latitudeDelta: Math.max(0.002, maxLat - minLat + latPadding * 2),
        longitudeDelta: Math.max(0.002, maxLng - minLng + lngPadding * 2),
      });
    }
  };

  useEffect(() => {
    if (booking) updateMapRegion(booking);
  }, [booking, valeterLocation, washHub]);

  useEffect(() => {
    if (liveCoords) {
      setLiveRegion({
        latitude: liveCoords.latitude,
        longitude: liveCoords.longitude,
        latitudeDelta: 0.002,
        longitudeDelta: 0.002,
      });
    } else {
      Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced })
        .then((loc) => {
          setLiveRegion({
            latitude: loc.coords.latitude,
            longitude: loc.coords.longitude,
            latitudeDelta: 0.002,
            longitudeDelta: 0.002,
          });
        })
        .catch(() => {});
    }
  }, [liveCoords]);

  const canCancel = status !== 'completed' && status !== 'cancelled' && status !== 'pending_payment';

  const cancelBooking = async () => {
    if (!bookingId || !user?.id || !canCancel) return;
    try {
      setCancelling(true);
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_at: new Date().toISOString(),
          cancelled_by: 'customer',
          cancellation_reason: 'Cancelled by customer',
        })
        .eq('id', bookingId);

      if (error) throw error;
      setStatus('cancelled');
    } catch (e) {
      console.warn('[BookingTracking] cancelBooking error', e);
      Alert.alert('Could not cancel', 'Please try again in a moment.');
    } finally {
      setCancelling(false);
    }
  };

  const handleMarkArrived = async () => {
    if (!bookingId || !washHub) return;
    try {
      setMarkingArrived(true);
      const { error } = await supabase
        .from('bookings')
        .update({ status: 'arrived' })
        .eq('id', bookingId);
      if (error) throw error;
      setStatus('arrived');
      hapticFeedback('medium');
    } catch (e) {
      console.warn('[BookingTracking] handleMarkArrived error', e);
      Alert.alert('Could not update', 'Please try again.');
    } finally {
      setMarkingArrived(false);
    }
  };

  const showArrivedButton =
    washHub &&
    ['confirmed', 'valeter_assigned', 'en_route', 'scheduled'].includes(status);

  /** Wash hub: customer has arrived or wash in progress – hide navigate, disable cancel on ring */
  const washHubArrivedOrInProgress = washHub && (status === 'arrived' || status === 'in_progress');

  const onPressCancel = () => {
    Alert.alert(
      'Cancel booking?',
      'This will cancel your booking. If a valeter is already on the way, you may still be charged depending on your policy.',
      [
        { text: 'Keep booking', style: 'cancel' },
        { text: 'Cancel booking', style: 'destructive', onPress: cancelBooking },
      ]
    );
  };

  const getStatusProgress = (): number => {
    switch (status) {
      case 'pending_valeter_acceptance':
      case 'pending_payment':
        return 20;
      case 'confirmed':
        return 40;
      case 'en_route':
        return 60;
      case 'arrived':
        return 80;
      case 'in_progress':
        return 90;
      case 'completed':
        return 100;
      case 'cancelled':
        return 100;
      default:
        return 0;
    }
  };

  const getStages = (): { label: string; done: boolean; current: boolean; icon: 'checkmark-circle' | 'car' | 'location' | 'water' | 'sparkles' }[] => {
    const s = status;
    return [
      { label: 'Accepted', done: !['pending_valeter_acceptance', 'pending_payment'].includes(s), current: ['confirmed', 'valeter_assigned'].includes(s), icon: 'checkmark-circle' },
      { label: 'En route', done: ['arrived', 'in_progress', 'completed'].includes(s), current: s === 'en_route', icon: 'car' },
      { label: 'Arrived', done: ['in_progress', 'completed'].includes(s), current: s === 'arrived', icon: 'location' },
      { label: 'Washing', done: s === 'completed', current: s === 'in_progress', icon: 'water' },
      { label: 'Done', done: s === 'completed', current: s === 'completed', icon: 'sparkles' },
    ];
  };

  const getStageProgressPercent = (): number => {
    const stages = getStages();
    const doneCount = stages.filter(s => s.done).length;
    const currentIndex = stages.findIndex(s => s.current);
    if (currentIndex >= 0) return (currentIndex + 0.5) * 25;
    return doneCount * 25;
  };

  const getStatusMessage = (): string => {
    switch (status) {
      case 'pending_valeter_acceptance':
        return 'Waiting for valeter to accept';
      case 'pending_payment':
        return 'Waiting for payment';
      case 'confirmed':
        return 'Valeter assigned – Ready to start';
      case 'en_route':
        return washHub ? 'Heading to wash hub' : 'Valeter on the way to you';
      case 'arrived':
        return washHub ? 'At wash hub' : 'Valeter has arrived';
      case 'in_progress':
        return washHub ? 'Vehicle being washed' : 'Service in progress';
      case 'completed':
        return 'Service completed';
      case 'cancelled':
        return 'Booking cancelled';
      default:
        return 'Tracking your booking';
    }
  };

  type StepCardConfig = {
    stepTitle: string;
    stepSubtitle: string;
    stepIcon: 'time-outline' | 'wallet-outline' | 'checkmark-circle' | 'car' | 'location' | 'water' | 'sparkles';
    stepAccent: string;
  };

  const getStepCardConfig = (): StepCardConfig => {
    switch (status) {
      case 'pending_valeter_acceptance':
        return {
          stepTitle: 'Waiting for acceptance',
          stepSubtitle: 'A valeter will confirm your booking shortly',
          stepIcon: 'time-outline',
          stepAccent: '#F59E0B',
        };
      case 'pending_payment':
        return {
          stepTitle: 'Pay to confirm',
          stepSubtitle: 'Complete payment to lock in your booking',
          stepIcon: 'wallet-outline',
          stepAccent: '#F59E0B',
        };
      case 'confirmed':
      case 'valeter_assigned':
        return {
          stepTitle: 'Accepted',
          stepSubtitle: `${valeterName} is assigned – getting ready to head your way`,
          stepIcon: 'checkmark-circle',
          stepAccent: '#8B5CF6',
        };
      case 'en_route':
        return {
          stepTitle: 'On the way',
          stepSubtitle: washHub ? 'Heading to the wash hub' : `${valeterName} is on the way to you`,
          stepIcon: 'car',
          stepAccent: SKY,
        };
      case 'arrived':
        return {
          stepTitle: 'Arrived',
          stepSubtitle: washHub ? 'At the wash hub – tap "I\'ve arrived" when you\'re there' : `${valeterName} has arrived at your location`,
          stepIcon: 'location',
          stepAccent: '#10B981',
        };
      case 'in_progress':
        return {
          stepTitle: 'Washing',
          stepSubtitle: 'Your vehicle is being cleaned right now',
          stepIcon: 'water',
          stepAccent: '#0EA5E9',
        };
      case 'completed':
        return {
          stepTitle: 'All done',
          stepSubtitle: 'Service completed – rate your experience',
          stepIcon: 'sparkles',
          stepAccent: '#10B981',
        };
      case 'cancelled':
        return {
          stepTitle: 'Cancelled',
          stepSubtitle: 'This booking was cancelled',
          stepIcon: 'checkmark-circle',
          stepAccent: '#64748B',
        };
      default:
        return {
          stepTitle: 'Tracking',
          stepSubtitle: getStatusMessage(),
          stepIcon: 'car',
          stepAccent: SKY,
        };
    }
  };

  const getRingColorForStep = (): string => {
    switch (status) {
      case 'pending_valeter_acceptance':
      case 'pending_payment':
        return '#F59E0B';
      case 'confirmed':
      case 'valeter_assigned':
        return '#8B5CF6';
      case 'en_route':
        return SKY;
      case 'arrived':
        return '#10B981';
      case 'in_progress':
        return '#0EA5E9';
      case 'completed':
        return '#10B981';
      case 'cancelled':
        return '#64748B';
      default:
        return SKY;
    }
  };

  const stepCard = getStepCardConfig();
  const ringColor = getRingColorForStep();

  const mapRegion = booking ? region : liveRegion;
  const hasMapRegion = mapRegion != null;
  const isLoading = !booking && !!bookingId;

  const locationDisplay = washHub ? washHub.name : (booking?.location_address || '—');

  return (
    <SafeAreaView style={styles.container} edges={[] as any}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
      <View style={{ flex: 1 }}>
      <View style={StyleSheet.absoluteFill}>
      <MapView
        style={StyleSheet.absoluteFill}
        region={mapRegion ?? DEFAULT_MAP_REGION}
        showsUserLocation={true}
        mapType={Platform.OS === 'ios' ? 'mutedStandard' : 'standard'}
        mapPadding={{ top: 0, bottom: 0, left: 0, right: 0 }}
      >
          {/* Customer / job location marker */}
          {booking?.location_lat && booking?.location_lng && (
            <Marker
              coordinate={{
                latitude: booking.location_lat,
                longitude: booking.location_lng,
              }}
              title="Your Location"
            >
              <View style={styles.markerContainer}>
                <View style={styles.marker}>
                  <Image
                    source={CUSTOMER_MAP_ICON}
                    style={styles.carMarkerImage}
                    resizeMode="contain"
                  />
                </View>
              </View>
            </Marker>
          )}

          {/* Valeter location marker */}
          {valeterLocation && (
            <Marker coordinate={valeterLocation} title={valeterName}>
              <Animated.View
                style={[styles.markerContainer, { transform: [{ scale: markerPulse }] }]}
              >
                <View style={styles.valeterMarker}>
                  <Image
                    source={VALETER_MAP_ICON}
                    style={styles.valeterMarkerImage}
                    resizeMode="contain"
                  />
                </View>
                <View style={styles.markerPulse} />
              </Animated.View>
            </Marker>
          )}

          {/* Wash hub marker */}
          {washHub?.latitude && washHub?.longitude && (
            <Marker
              coordinate={{ latitude: washHub.latitude, longitude: washHub.longitude }}
              title={washHub.name}
            >
              <View style={styles.markerContainer}>
                <View style={styles.hubMarker}>
                  <Image
                    source={HUB_MAP_ICON}
                    style={styles.hubMarkerImage}
                    resizeMode="contain"
                  />
                </View>
              </View>
            </Marker>
          )}
      </MapView>
      </View>

      {/* Chat & Cancel floating on map – on-demand tracking (no navigate) */}
      {booking && (
        <View style={[styles.mapActionButtons, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + 16 }]} pointerEvents="box-none">
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              if (bookingId) router.push({ pathname: '/chat-screen', params: { bookingId } } as any);
            }}
            style={styles.mapActionBtn}
            activeOpacity={0.85}
          >
            <View style={styles.mapActionBtnInner}>
              <Ionicons name="chatbubble-ellipses-outline" size={24} color={SKY} />
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              if (canCancel && !washHubArrivedOrInProgress) onPressCancel();
            }}
            disabled={!canCancel || cancelling || washHubArrivedOrInProgress}
            style={[styles.mapActionBtn, (!canCancel || washHubArrivedOrInProgress) && styles.mapActionBtnDisabled]}
            activeOpacity={0.85}
          >
            <View style={[styles.mapActionBtnInner, (!canCancel || washHubArrivedOrInProgress) && styles.mapActionBtnInnerDisabled]}>
              {cancelling ? (
                <ActivityIndicator size="small" color="#EF4444" />
              ) : (
                <Ionicons name="close-circle-outline" size={24} color={canCancel && !washHubArrivedOrInProgress ? '#EF4444' : '#64748B'} />
              )}
            </View>
          </TouchableOpacity>
        </View>
      )}

      <View style={styles.headerOverlay}>
        <AppHeader
          title="Tracking"
          subtitle="Your wash in progress"
          showBack
          onBack={() => { hapticFeedback('light'); router.back(); }}
          rightAction={
            <TouchableOpacity
              onPress={() => router.replace('/')}
              style={styles.headerExitButton}
              activeOpacity={0.7}
            >
              <Ionicons name="close" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          }
        />
      </View>

      {isLoading ? (
        <View style={styles.emptyOverlay}>
          <ProBookingCard stripColor={SKY} style={styles.emptyCard}>
            <View style={styles.emptyContent}>
              <ActivityIndicator size="small" color={SKY} />
              <Text style={styles.loadingText}>Loading booking…</Text>
            </View>
          </ProBookingCard>
        </View>
      ) : !booking ? (
        <View style={styles.emptyOverlay}>
          <ProBookingCard stripColor={SKY} style={styles.emptyCard}>
            <View style={styles.emptyContent}>
              <Ionicons name="navigate-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
              <Text style={styles.emptyTitle}>No Active Booking</Text>
              <Text style={styles.emptyText}>
                We couldn't find an active booking to track. Head to the home screen to book a wash.
              </Text>
              <TouchableOpacity
                style={styles.backButton}
                onPress={() => router.replace('/')}
                activeOpacity={0.8}
              >
                <LinearGradient colors={[SKY, '#60A5FA']} style={styles.backButtonGradient}>
                  <Text style={styles.backButtonText}>Go to Dashboard</Text>
                  <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </ProBookingCard>
        </View>
      ) : (
        <Animated.View
          style={[
            styles.cardContainer,
            {
              opacity: fadeAnim,
              bottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
            },
          ]}
        >
          <View style={styles.cardWrapper}>
            <ProBookingCard stripColor={SKY} intensity={35}>
              <View style={styles.trackingCard}>
              <LinearGradient
                colors={[colors.SKY + '06', colors.SKY + '03', 'transparent']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
              {/* Card header: step icon, title, subtitle */}
              <View style={styles.cardTopRow}>
                <View style={[styles.stepIconWrap, { backgroundColor: stepCard.stepAccent + '18' }]}>
                  <Ionicons name={stepCard.stepIcon} size={28} color={stepCard.stepAccent} />
                </View>
                <View style={styles.cardHeaderText}>
                  <Text style={styles.stepServiceLabel} numberOfLines={1}>
                    {getServiceDisplayName(booking.service_type, booking.service_name)}
                  </Text>
                  <Text style={[styles.stepTitle, { color: stepCard.stepAccent }]} numberOfLines={1}>
                    {stepCard.stepTitle}
                  </Text>
                  <Text style={styles.stepSubtitle} numberOfLines={2}>
                    {stepCard.stepSubtitle}
                  </Text>
                </View>
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    setInfoModalVisible(true);
                  }}
                  style={styles.infoBox}
                  activeOpacity={0.8}
                >
                  <View style={styles.infoBoxInner}>
                    <Ionicons name="information-circle-outline" size={22} color={SKY} />
                  </View>
                </TouchableOpacity>
              </View>

              {/* Status ring – centered, chat/cancel on map */}
              <View style={styles.ringRow}>
                <View style={styles.ringCenter}>
                  <AnimatedProgress progress={getStatusProgress()} size={80} strokeWidth={8} color={ringColor} colorCycle={[SKY, '#10B981', '#8B5CF6', '#F59E0B']} />
                </View>
              </View>

              {/* Navigate – wash hub only (customer travelling to hub); hidden for on-demand */}
              {washHub && (booking?.location_lat != null && booking?.location_lng != null) && !washHubArrivedOrInProgress && (
                <TouchableOpacity
                    onPress={async () => {
                    await hapticFeedback('light');
                    const lat = booking!.location_lat;
                    const lng = booking!.location_lng;
                    const url = Platform.select({
                      ios: `maps://app?daddr=${lat},${lng}`,
                      default: `https://www.google.com/maps/dir/?api=1&destination=${lat},${lng}`,
                    });
                    Linking.openURL(url).catch(() => {});
                  }}
                  style={styles.navigateButton}
                  activeOpacity={0.9}
                >
                  <LinearGradient
                    colors={[SKY, '#0EA5E9']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={styles.navigateButtonGradient}
                  >
                    <Ionicons name="navigate" size={20} color="#FFFFFF" />
                    <Text style={styles.navigateButtonText}>Navigate to location</Text>
                  </LinearGradient>
                </TouchableOpacity>
              )}

              {/* Payment button when pending */}
              {status === 'pending_payment' && (
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('medium');
                    if (bookingId) {
                      router.push({ pathname: '/owner/booking', params: { bookingId } } as any);
                    }
                  }}
                  style={styles.payButton}
                  activeOpacity={0.9}
                >
                  <LinearGradient
                    colors={[SKY, '#0EA5E9']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={styles.payButtonGradient}
                  >
                    <Ionicons name="wallet" size={20} color="#FFFFFF" />
                    <Text style={styles.payButtonText}>Pay £{Number(booking.price ?? 0).toFixed(2)}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              )}

              {/* Wash hub: "I've arrived" button (cancel stays on right of progress ring only) */}
              {showArrivedButton && (
                <TouchableOpacity
                  onPress={handleMarkArrived}
                  disabled={markingArrived}
                  style={styles.arrivedButton}
                  activeOpacity={0.9}
                >
                  <LinearGradient
                    colors={['#10B981', '#059669']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={styles.arrivedButtonGradient}
                  >
                    {markingArrived ? (
                      <ActivityIndicator size="small" color="#FFFFFF" />
                    ) : (
                      <>
                        <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                        <Text style={styles.arrivedButtonText}>I've arrived</Text>
                      </>
                    )}
                  </LinearGradient>
                </TouchableOpacity>
              )}

              {/* Floating bubbles when washing (in_progress) */}
              {status === 'in_progress' && (
                <View style={StyleSheet.absoluteFill} pointerEvents="none">
                  {BUBBLE_CONFIG.map((bubble, i) => (
                    <Animated.View
                      key={i}
                      style={[
                        styles.bubble,
                        {
                          width: bubble.size,
                          height: bubble.size,
                          borderRadius: bubble.size / 2,
                          left: `${bubble.left}%`,
                          top: `${bubble.top}%`,
                          transform: [{ translateY: bubbleAnims[i].y }],
                        },
                      ]}
                    />
                  ))}
                </View>
              )}

              {/* Progress steps – border at bottom of card */}
              <View style={styles.cardProgressStrip}>
                <View style={styles.cardProgressTrack}>
                  <View
                    style={[
                      styles.cardProgressFill,
                      { width: `${getStageProgressPercent()}%`, backgroundColor: ringColor },
                    ]}
                  />
                </View>
                <View style={styles.cardProgressDots}>
                  {getStages().map((stage, i) => (
                    <View
                      key={i}
                      style={[
                        styles.cardProgressDot,
                        stage.done && styles.cardProgressDotDone,
                        stage.current && styles.cardProgressDotCurrent,
                      ]}
                    >
                      {stage.done ? (
                        <Ionicons name="checkmark" size={8} color="#FFFFFF" />
                      ) : null}
                    </View>
                  ))}
              </View>
            </View>

              </View>
            </ProBookingCard>
          </View>
        </Animated.View>
      )}

      {booking && (
        <>
          <Modal visible={showCompletedConfetti} transparent animationType="fade">
            <Pressable style={styles.modalOverlay} onPress={() => { setShowCompletedConfetti(false); router.replace('/'); }}>
              <Pressable style={styles.infoModalContent} onPress={(e) => e.stopPropagation()}>
                <Text style={styles.infoModalTitle}>Boom! Your car is super clean</Text>
                <TouchableOpacity style={styles.infoModalDone} onPress={() => { setShowCompletedConfetti(false); router.replace('/'); }} activeOpacity={0.9}>
                  <Text style={styles.infoModalDoneText}>Back to home</Text>
                </TouchableOpacity>
              </Pressable>
            </Pressable>
          </Modal>
          <Modal
              visible={infoModalVisible}
              transparent
              animationType="fade"
              onRequestClose={() => setInfoModalVisible(false)}
            >
              <Pressable style={styles.modalOverlay} onPress={() => setInfoModalVisible(false)}>
                <Pressable style={styles.infoModalContent} onPress={(e) => e.stopPropagation()}>
                  <View style={styles.infoModalHeader}>
                    <Text style={styles.infoModalTitle}>Booking Details</Text>
                    <TouchableOpacity
                      onPress={() => setInfoModalVisible(false)}
                      hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                    >
                      <Ionicons name="close" size={24} color="#94A3B8" />
                    </TouchableOpacity>
                  </View>
                  <View style={styles.infoModalBody}>
                    <View style={styles.infoRow}>
                      <Ionicons name="water-outline" size={18} color={SKY} />
                      <Text style={styles.infoText}>
                        {getServiceDisplayName(booking.service_type, booking.service_name)}
                      </Text>
                    </View>
                    {booking.valeter_id && (
                      <View style={styles.infoRow}>
                        <Ionicons name="person-outline" size={18} color={SKY} />
                        <Text style={styles.infoText}>{valeterName}</Text>
                      </View>
                    )}
                    <View style={styles.infoRow}>
                      <Ionicons name={washHub ? 'business-outline' : 'location-outline'} size={18} color={SKY} />
                      <Text style={styles.infoText}>{locationDisplay}</Text>
                    </View>
                    <View style={styles.infoRow}>
                      <Ionicons name="cash-outline" size={18} color={SKY} />
                      <Text style={styles.infoText}>£{Number(booking.price ?? 0).toFixed(2)}</Text>
                    </View>
                    <View style={styles.infoModalProgress}>
                      <Text style={styles.infoModalProgressLabel}>Progress</Text>
                      <AnimatedProgress progress={getStatusProgress()} size={80} />
                    </View>
                  </View>
                  {status === 'pending_payment' && (
                    <TouchableOpacity
                      onPress={() => {
                        setInfoModalVisible(false);
                        if (bookingId) {
                          router.push({ pathname: '/owner/booking', params: { bookingId } } as any);
                        }
                      }}
                      style={styles.infoModalPayButton}
                      activeOpacity={0.9}
                    >
                      <LinearGradient
                        colors={[SKY, '#0EA5E9']}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 0 }}
                        style={styles.infoModalPayGradient}
                      >
                        <Ionicons name="wallet" size={20} color="#FFFFFF" />
                        <Text style={styles.infoModalPayText}>Pay £{Number(booking.price ?? 0).toFixed(2)}</Text>
                      </LinearGradient>
                    </TouchableOpacity>
                  )}
                  <TouchableOpacity
                    onPress={() => setInfoModalVisible(false)}
                    style={[styles.infoModalDone, status === 'pending_payment' && { marginTop: 8 }]}
                    activeOpacity={0.9}
                  >
                    <Text style={styles.infoModalDoneText}>Close</Text>
                  </TouchableOpacity>
                </Pressable>
              </Pressable>
            </Modal>
        </>
      )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
  },
  bubble: {
    position: 'absolute',
    backgroundColor: 'rgba(255,255,255,0.45)',
    shadowColor: '#fff',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.4,
    shadowRadius: 2,
    elevation: 1,
  },
  cardProgressStrip: {
    borderTopWidth: 0,
    borderTopColor: 'rgba(135,206,235,0.2)',
    paddingTop: 10,
    marginTop: 12,
    paddingHorizontal: 4,
    paddingBottom: 4,
  },
  cardProgressTrack: {
    height: 2,
    backgroundColor: 'rgba(148,163,184,0.25)',
    borderRadius: 1,
    overflow: 'hidden',
    marginBottom: 8,
  },
  cardProgressFill: {
    height: '100%',
    borderRadius: 1,
  },
  cardProgressDots: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 2,
  },
  cardProgressDot: {
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: 'rgba(100,116,139,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardProgressDotDone: {
    backgroundColor: '#10B981',
  },
  cardProgressDotCurrent: {
    backgroundColor: SKY,
  },
  headerProgressStrip: {
    paddingHorizontal: 24,
    paddingTop: 4,
    paddingBottom: 6,
    backgroundColor: 'rgba(10,25,41,0.75)',
  },
  headerProgressTrack: {
    height: 2,
    backgroundColor: 'rgba(148,163,184,0.25)',
    borderRadius: 1,
    overflow: 'hidden',
    marginBottom: 6,
  },
  headerProgressFill: {
    height: '100%',
    borderRadius: 1,
  },
  headerProgressDots: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingHorizontal: 2,
  },
  headerProgressDot: {
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: 'rgba(100,116,139,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerProgressDotDone: {
    backgroundColor: '#10B981',
  },
  headerProgressDotCurrent: {
    backgroundColor: SKY,
  },
  headerExitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderWidth: 0,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(10, 25, 41, 0.7)',
  },
  loadingText: {
    color: SKY,
    fontSize: 16,
    marginTop: 12,
    textAlign: 'center',
  },
  emptyOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    padding: 20,
  },
  emptyCard: {
    padding: 40,
    maxWidth: 400,
    alignSelf: 'center',
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 20,
  },
  backButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    marginTop: 8,
  },
  backButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 28,
    gap: 8,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  marker: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#EF4444',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  valeterMarker: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  hubMarker: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#10B981',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  markerPulse: {
    position: 'absolute',
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: SKY,
    opacity: 0.3,
  },
  carMarkerImage: {
    width: 28,
    height: 28,
  },
  valeterMarkerImage: {
    width: 24,
    height: 24,
  },
  hubMarkerImage: {
    width: 24,
    height: 24,
  },
  mapActionButtons: {
    position: 'absolute',
    right: 16,
    zIndex: 100,
    gap: 10,
  },
  mapActionBtn: {
    width: 48,
    height: 48,
  },
  mapActionBtnDisabled: {
    opacity: 0.6,
  },
  mapActionBtnInner: {
    width: '100%',
    height: '100%',
    borderRadius: 24,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.35)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapActionBtnInnerDisabled: {
    backgroundColor: 'rgba(100,116,139,0.25)',
    borderColor: 'rgba(100,116,139,0.3)',
  },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  cardWrapper: {
    width: '100%',
    maxWidth: CARD_WIDTH,
    position: 'relative',
  },
  trackingCard: {
    padding: 16,
    overflow: 'hidden',
    borderRadius: 20,
  },
  cardTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
    minWidth: 0,
  },
  cardHeaderText: {
    flex: 1,
    minWidth: 0,
  },
  ringRow: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 12,
  },
  ringCenter: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  stagesWrapper: {
    marginTop: 16,
    width: '100%',
    maxWidth: 260,
    alignSelf: 'center',
  },
  stagesTrack: {
    height: 4,
    backgroundColor: 'rgba(148,163,184,0.2)',
    borderRadius: 2,
    overflow: 'hidden',
    marginBottom: 14,
  },
  stagesTrackFill: {
    height: '100%',
    borderRadius: 2,
  },
  stagesRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  stageItem: {
    flex: 1,
    alignItems: 'center',
    minWidth: 0,
  },
  stageDotWrap: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(100,116,139,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
    borderWidth: 0,
    borderColor: 'transparent',
  },
  stageDotWrapDone: {
    backgroundColor: '#10B981',
    borderWidth: 0,
    borderColor: 'transparent',
  },
  stageDotWrapCurrent: {
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderColor: SKY,
    borderWidth: 0,
  },
  stageDotCheck: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  stageDotIcon: {
    justifyContent: 'center',
    alignItems: 'center',
    opacity: 0.8,
  },
  stageDotIconCurrent: {
    opacity: 1,
  },
  stageLabelWrap: {
    paddingHorizontal: 4,
    paddingVertical: 4,
    borderRadius: 8,
  },
  stageLabelWrapCurrent: {
    backgroundColor: SKY + '20',
  },
  stageLabel: {
    fontSize: 11,
    fontWeight: '600',
    color: '#64748B',
    textAlign: 'center',
  },
  stageLabelDone: {
    color: '#10B981',
    fontWeight: '700',
  },
  stageLabelCurrent: {
    color: SKY,
    fontWeight: '800',
    fontSize: 12,
  },
  ringSideButton: {
    width: 44,
    height: 44,
  },
  ringSideButtonDisabled: {
    opacity: 0.5,
  },
  ringSideButtonInner: {
    width: '100%',
    height: '100%',
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.35)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ringSideButtonInnerDisabled: {
    backgroundColor: 'rgba(100,116,139,0.2)',
    borderColor: 'rgba(100,116,139,0.3)',
  },
  payButton: {
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 8,
  },
  payButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 10,
  },
  payButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  navigateButton: {
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 8,
  },
  navigateButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 10,
  },
  navigateButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  arrivedButton: {
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 8,
  },
  arrivedButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 10,
  },
  arrivedButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  trackingIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  trackingIcon: {
    width: 24,
    height: 24,
  },
  stepIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 12,
    borderWidth: 0,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  stepServiceLabel: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 4,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  stepTitle: {
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 4,
  },
  stepSubtitle: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
    lineHeight: 18,
  },
  trackingServiceName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 4,
  },
  trackingStatusMessage: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '500',
  },
  infoBox: {
    width: 40,
    height: 40,
  },
  infoBoxInner: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    backgroundColor: SKY + '15',
    borderWidth: 0,
    borderColor: SKY + '30',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  infoModalContent: {
    width: '100%',
    maxWidth: 340,
    backgroundColor: '#1E293B',
    borderRadius: 20,
    padding: 20,
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  infoModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  infoModalTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  infoModalBody: {
    gap: 12,
    marginBottom: 20,
  },
  infoModalProgress: {
    alignItems: 'center',
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 0,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  infoModalProgressLabel: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 8,
  },
  infoModalPayButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 8,
  },
  infoModalPayGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 20,
    gap: 8,
  },
  infoModalPayText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  infoModalDone: {
    backgroundColor: SKY,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  infoModalDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
  },
  cancelButton: {
    borderRadius: 12,
    backgroundColor: 'rgba(239,68,68,0.9)',
    borderWidth: 0,
    borderColor: 'rgba(239,68,68,0.5)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 20,
    gap: 8,
    marginTop: 12,
  },
  cancelButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: 'bold',
  },
});
