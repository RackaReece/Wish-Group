import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  ScrollView,
  Dimensions,
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Marker, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { geocodeAddress } from '../../../src/utils/geocode';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { customerTheme } from '../../../src/constants/customerTheme';
import { serviceOptions } from '../../../src/constants/serviceOptions';
import { DARK_MAP_STYLE } from '../../../src/constants/mapStyles';
import AppHeader from '../../../src/components/shared/AppHeader';
import ProBookingCard from '../../../src/components/booking/ProBookingCard';

const { width } = Dimensions.get('window');
const CARD_PADDING = 20;
const SKY = '#38BDF8';
const GOLD = '#FBBF24';

type WashOption = (typeof serviceOptions)[number];

export default function WashBookingScreen() {
  const { user } = useAuth();
  const params = useLocalSearchParams<{
    isRepeat?: string;
    address?: string;
    latitude?: string;
    longitude?: string;
    serviceType?: string;
    serviceName?: string;
    price?: string;
    needsTimeSlot?: string;
  }>();
  const mapRef = useRef<MapView>(null);

  const isRepeat = params.isRepeat === '1';
  const needsTimeSlot = params.needsTimeSlot === '1';

  const [locationInput, setLocationInput] = useState(params.address ?? '');
  const [locationCoords, setLocationCoords] = useState<{ lat: number; lng: number; address: string } | null>(
    params.latitude && params.longitude && params.address
      ? {
          lat: parseFloat(params.latitude),
          lng: parseFloat(params.longitude),
          address: params.address,
        }
      : null
  );
  const [geocoding, setGeocoding] = useState(false);
  const [region, setRegion] = useState<Region | null>(
    params.latitude && params.longitude
      ? {
          latitude: parseFloat(params.latitude),
          longitude: parseFloat(params.longitude),
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        }
      : null
  );
  const [useCurrentLocation, setUseCurrentLocation] = useState(false);
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string | null>(null);

  const [selectedWash, setSelectedWash] = useState<WashOption | null>(null);
  const [selectedValeter, setSelectedValeter] = useState<{ id: string; name: string; rating: number; eta: string } | null>(null);
  const [nearbyValeters, setNearbyValeters] = useState<Array<{ id: string; name: string; rating: number; eta: string }>>([]);

  const loadCurrentLocation = useCallback(async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Location permission is required to find valeters near you.');
        return;
      }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = { lat: loc.coords.latitude, lng: loc.coords.longitude };
      const rev = await Location.reverseGeocodeAsync(coords);
      const addr = rev?.[0]
        ? [rev[0].street, rev[0].city, rev[0].postalCode, rev[0].country].filter(Boolean).join(', ')
        : `${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)}`;
      setLocationCoords({ ...coords, address: addr || 'Current location' });
      setLocationInput(addr || '');
      setUseCurrentLocation(true);
      const r: Region = {
        latitude: coords.lat,
        longitude: coords.lng,
        latitudeDelta: 0.02,
        longitudeDelta: 0.02,
      };
      setRegion(r);
      mapRef.current?.animateToRegion(r, 400);
    } catch (e) {
      console.warn('Current location error:', e);
      Alert.alert('Error', 'Could not get your location.');
    }
  }, []);

  const handleGeocode = useCallback(async () => {
    const trimmed = locationInput.trim();
    if (!trimmed) return;
    setGeocoding(true);
    try {
      const result = await geocodeAddress(trimmed);
      if (result) {
        setLocationCoords({
          lat: result.latitude,
          lng: result.longitude,
          address: result.address,
        });
        setUseCurrentLocation(false);
        const r: Region = {
          latitude: result.latitude,
          longitude: result.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        };
        setRegion(r);
        mapRef.current?.animateToRegion(r, 400);
      } else {
        Alert.alert('Location not found', 'Could not find that address or postcode. Try a different format.');
      }
    } catch (e) {
      Alert.alert('Error', 'Could not look up location.');
    } finally {
      setGeocoding(false);
    }
  }, [locationInput]);

  useEffect(() => {
    if (!isRepeat || !locationCoords) loadCurrentLocation();
  }, [loadCurrentLocation, isRepeat, locationCoords]);

  useEffect(() => {
    if (isRepeat && params.serviceName) {
      const match = serviceOptions.find((o) => o.name.toLowerCase() === params.serviceName?.toLowerCase());
      if (match) setSelectedWash(match);
    }
  }, [isRepeat, params.serviceName]);

  useEffect(() => {
    if (!locationCoords) return;
    const valeters = [
      { id: 'v1', name: 'Alex M.', rating: 4.9, eta: '~15 min' },
      { id: 'v2', name: 'Jamie L.', rating: 4.8, eta: '~20 min' },
      { id: 'v3', name: 'Sam K.', rating: 4.7, eta: '~25 min' },
    ];
    setNearbyValeters(valeters);
    if (isRepeat && valeters[0]) setSelectedValeter(valeters[0]);
  }, [locationCoords, isRepeat]);

  const effectiveRegion: Region = region ?? {
    latitude: 54,
    longitude: -2,
    latitudeDelta: 8,
    longitudeDelta: 8,
  };

  const canProceed = isRepeat
    ? locationCoords && (needsTimeSlot ? selectedTimeSlot : true)
    : locationCoords && selectedWash && selectedValeter;

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <LinearGradient colors={customerTheme.backgroundGradient as [string, string]} style={StyleSheet.absoluteFill} />
      <AppHeader title="Book a service" accountType="customer" showBack onBack={() => router.back()} />

      {/* Wash | Detailing toggle — under header */}
      <View style={styles.serviceToggleWrap}>
        <TouchableOpacity
          style={[styles.serviceToggleBtn, styles.serviceToggleActive]}
          onPress={() => {}}
          activeOpacity={1}
        >
          <Ionicons name="water-outline" size={18} color="#FFF" />
          <Text style={styles.serviceToggleTextActive}>Wash</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={styles.serviceToggleBtn}
          onPress={async () => {
            await hapticFeedback('light');
            router.replace('/owner/booking/detailing' as any);
          }}
        >
          <Ionicons name="diamond-outline" size={18} color="rgba(255,255,255,0.65)" />
          <Text style={styles.serviceToggleText}>Detailing</Text>
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView
        style={styles.keyboard}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 0}
      >
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Repeat summary */}
          {isRepeat && (selectedWash || params.serviceName) && (
            <View style={styles.repeatSummary}>
              <View style={styles.repeatBadge}>
                <Ionicons name="repeat" size={14} color="#10B981" />
                <Text style={styles.repeatBadgeText}>Repeating your last booking</Text>
              </View>
              <View style={styles.repeatSummaryRow}>
                <Text style={styles.repeatService}>{params.serviceName || selectedWash?.name || 'Wash'}</Text>
                {params.price != null && (
                  <Text style={styles.repeatPrice}>£{Number(params.price).toFixed(2)}</Text>
                )}
              </View>
            </View>
          )}

          {/* Location picker card */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>
              {isRepeat ? 'Confirm your location' : 'Where should we wash your car?'}
            </Text>
            <ProBookingCard stripColor={SKY} intensity={32} style={styles.locationCard}>
              <LinearGradient
                colors={['rgba(56,189,248,0.2)', 'rgba(30,64,175,0.25)']}
                style={styles.locationCardGradient}
              >
                <View style={styles.locationInputRow}>
                  <View style={styles.locationIconWrap}>
                    <Ionicons name="location" size={22} color={SKY} />
                  </View>
                  <TextInput
                    style={styles.locationInput}
                    placeholder="Enter postcode or full address"
                    placeholderTextColor="rgba(255,255,255,0.45)"
                    value={locationInput}
                    onChangeText={setLocationInput}
                    onSubmitEditing={handleGeocode}
                    returnKeyType="search"
                  />
                  <TouchableOpacity
                    style={styles.useCurrentBtn}
                    onPress={async () => {
                      await hapticFeedback('light');
                      loadCurrentLocation();
                    }}
                  >
                    <Ionicons name="navigate" size={18} color={SKY} />
                    <Text style={styles.useCurrentText}>Use current</Text>
                  </TouchableOpacity>
                </View>
                <TouchableOpacity
                  style={[styles.searchBtn, geocoding && styles.searchBtnDisabled]}
                  onPress={async () => {
                    await hapticFeedback('light');
                    handleGeocode();
                  }}
                  disabled={geocoding || !locationInput.trim()}
                >
                  {geocoding ? (
                    <ActivityIndicator size="small" color="#FFF" />
                  ) : (
                    <>
                      <Ionicons name="search" size={18} color="#FFF" />
                      <Text style={styles.searchBtnText}>Find on map</Text>
                    </>
                  )}
                </TouchableOpacity>
                <View style={styles.mapWrap}>
                  <MapView
                    ref={mapRef}
                    style={styles.miniMap}
                    region={effectiveRegion}
                    customMapStyle={DARK_MAP_STYLE}
                    mapType="standard"
                    scrollEnabled={false}
                    zoomEnabled={false}
                    pitchEnabled={false}
                    rotateEnabled={false}
                  >
                    {locationCoords && (
                      <Marker
                        coordinate={{ latitude: locationCoords.lat, longitude: locationCoords.lng }}
                        anchor={{ x: 0.5, y: 0.5 }}
                      >
                        <View style={styles.markerPin}>
                          <Ionicons name="car" size={16} color="#FFF" />
                        </View>
                      </Marker>
                    )}
                  </MapView>
                  <View style={styles.mapOverlay} pointerEvents="none">
                    <View style={styles.mapLabel}>
                      <Ionicons name="car" size={12} color={SKY} />
                      <Text style={styles.mapLabelText} numberOfLines={1}>
                        {locationCoords?.address || 'Enter address above'}
                      </Text>
                    </View>
                  </View>
                </View>
              </LinearGradient>
            </ProBookingCard>
          </View>

          {/* Wash selection - premium cards (skip when repeat) */}
          {!isRepeat && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Choose your wash</Text>
            <View style={styles.washGrid}>
              {serviceOptions.slice(0, 4).map((opt) => {
                const isSelected = selectedWash?.id === opt.id;
                return (
                  <TouchableOpacity
                    key={opt.id}
                    style={[styles.washCard, isSelected && styles.washCardSelected]}
                    onPress={async () => {
                      await hapticFeedback('light');
                      setSelectedWash(opt);
                    }}
                    activeOpacity={0.85}
                  >
                    <LinearGradient
                      colors={
                        isSelected
                          ? [opt.colors[0], opt.colors[1]]
                          : ['rgba(255,255,255,0.06)', 'rgba(255,255,255,0.03)']
                      }
                      style={[styles.washCardGradient, isSelected && styles.washCardGradientSelected]}
                    >
                      <View style={[styles.washIconCircle, { backgroundColor: isSelected ? 'rgba(255,255,255,0.25)' : `${opt.colors[0]}40` }]}>
                        <Ionicons name={opt.icon as any} size={24} color={isSelected ? '#FFF' : opt.colors[0]} />
                      </View>
                      <Text style={[styles.washName, isSelected && styles.washNameSelected]}>{opt.name}</Text>
                      <Text style={styles.washDesc} numberOfLines={1}>{opt.desc}</Text>
                      <View style={styles.washMeta}>
                        <Text style={[styles.washPrice, { color: isSelected ? '#FFF' : opt.colors[0] }]}>£{opt.price}</Text>
                        <Text style={styles.washDur}>{opt.dur}</Text>
                      </View>
                    </LinearGradient>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>
          )}

          {/* Time slot step for hub repeat */}
          {isRepeat && needsTimeSlot && locationCoords && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Select a time slot</Text>
              <View style={styles.timeSlotRow}>
                {['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'].map((slot) => {
                  const isSelected = selectedTimeSlot === slot;
                  return (
                    <TouchableOpacity
                      key={slot}
                      style={[styles.timeSlotBtn, isSelected && styles.timeSlotBtnSelected]}
                      onPress={async () => {
                        await hapticFeedback('light');
                        setSelectedTimeSlot(slot);
                      }}
                    >
                      <Text style={[styles.timeSlotText, isSelected && styles.timeSlotTextSelected]}>{slot}</Text>
                    </TouchableOpacity>
                  );
                })}
              </View>
            </View>
          )}

          {/* Valeter selection - premium card (skip when repeat) */}
          {!isRepeat && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Select your valeter</Text>
            {nearbyValeters.map((v) => {
              const isSelected = selectedValeter?.id === v.id;
              return (
                <TouchableOpacity
                  key={v.id}
                  style={[styles.valeterCard, isSelected && styles.valeterCardSelected]}
                  onPress={async () => {
                    await hapticFeedback('light');
                    setSelectedValeter(v);
                  }}
                  activeOpacity={0.9}
                >
                  <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} />
                  <LinearGradient
                    colors={isSelected ? ['rgba(56,189,248,0.3)', 'rgba(30,64,175,0.35)'] : ['rgba(255,255,255,0.05)', 'rgba(255,255,255,0.02)']}
                    style={styles.valeterCardInner}
                  >
                    <View style={[styles.valeterAvatar, isSelected && styles.valeterAvatarSelected]}>
                      <Text style={styles.valeterAvatarText}>{v.name.charAt(0)}</Text>
                    </View>
                    <View style={styles.valeterInfo}>
                      <Text style={[styles.valeterName, isSelected && styles.valeterNameSelected]}>{v.name}</Text>
                      <View style={styles.valeterMeta}>
                        <View style={styles.valeterRating}>
                          <Ionicons name="star" size={14} color={GOLD} />
                          <Text style={styles.valeterRatingText}>{v.rating}</Text>
                        </View>
                        <Text style={styles.valeterEta}>{v.eta}</Text>
                      </View>
                    </View>
                    {isSelected && (
                      <View style={styles.valeterCheck}>
                        <Ionicons name="checkmark-circle" size={28} color={SKY} />
                      </View>
                    )}
                  </LinearGradient>
                </TouchableOpacity>
              );
            })}
          </View>
          )}

          <View style={{ height: 120 }} />
        </ScrollView>

        {/* Bottom CTA */}
        <View style={styles.ctaWrap}>
          <LinearGradient colors={['rgba(15,23,42,0.95)', 'rgba(15,23,42,0.98)']} style={StyleSheet.absoluteFill} />
          <TouchableOpacity
            style={[styles.ctaBtn, !canProceed && styles.ctaBtnDisabled]}
            onPress={async () => {
              if (!canProceed) return;
              await hapticFeedback('medium');
              router.back();
            }}
            disabled={!canProceed}
          >
            <LinearGradient
              colors={canProceed ? [SKY, '#2563EB'] : ['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.1)']}
              style={styles.ctaGradient}
            >
              <Text style={styles.ctaText}>{isRepeat ? 'Confirm & pay' : 'Continue to time slot'}</Text>
              <Ionicons name="arrow-forward" size={20} color="#FFF" />
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  keyboard: { flex: 1 },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: CARD_PADDING, paddingTop: 12 },

  repeatSummary: {
    marginBottom: 20,
    padding: 16,
    borderRadius: 16,
    backgroundColor: 'rgba(16,185,129,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  repeatBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 10,
  },
  repeatBadgeText: { color: '#10B981', fontSize: 13, fontWeight: '700' },
  repeatSummaryRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  repeatService: { color: '#F9FAFB', fontSize: 16, fontWeight: '700' },
  repeatPrice: { color: '#10B981', fontSize: 18, fontWeight: '800' },
  timeSlotRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  timeSlotBtn: {
    paddingVertical: 12,
    paddingHorizontal: 18,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 0,
  },
  timeSlotBtnSelected: {
    backgroundColor: 'rgba(56,189,248,0.3)',
    borderWidth: 0,
  },
  timeSlotText: { color: 'rgba(255,255,255,0.9)', fontSize: 15, fontWeight: '600' },
  timeSlotTextSelected: { color: '#FFF', fontWeight: '700' },
  section: { marginBottom: 24 },
  sectionTitle: {
    fontSize: 17,
    fontWeight: '800',
    color: '#F9FAFB',
    marginBottom: 12,
    letterSpacing: 0.2,
  },

  locationCard: {
    borderRadius: 28,
    overflow: 'hidden',
    borderWidth: 0,
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
  },
  locationCardGradient: {
    padding: 16,
    borderRadius: 28,
    gap: 12,
  },
  locationInputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  locationIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(56,189,248,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  locationInput: {
    flex: 1,
    height: 48,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.08)',
    paddingHorizontal: 16,
    fontSize: 16,
    color: '#F9FAFB',
    fontWeight: '600',
  },
  useCurrentBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(56,189,248,0.15)',
  },
  useCurrentText: { color: SKY, fontSize: 13, fontWeight: '700' },
  searchBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(56,189,248,0.4)',
  },
  searchBtnDisabled: { opacity: 0.7 },
  searchBtnText: { color: '#FFF', fontSize: 16, fontWeight: '700' },
  mapWrap: {
    height: 160,
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  miniMap: { ...StyleSheet.absoluteFillObject },
  mapOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    padding: 10,
    backgroundColor: 'rgba(0,0,0,0.5)',
  },
  mapLabel: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  mapLabelText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  markerPin: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },

  washGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  washCard: {
    width: (width - CARD_PADDING * 2 - 12) / 2,
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 0,
  },
  washCardSelected: {
    borderWidth: 0,
    elevation: 12,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
  },
  washCardGradient: {
    padding: 16,
    borderRadius: 18,
    minHeight: 140,
  },
  washCardGradientSelected: {
    borderWidth: 0,
  },
  washIconCircle: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  washName: {
    fontSize: 16,
    fontWeight: '800',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  washNameSelected: { color: '#FFF' },
  washDesc: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.65)',
    marginBottom: 8,
  },
  washMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  washPrice: { fontSize: 18, fontWeight: '800' },
  washDur: { fontSize: 11, color: 'rgba(255,255,255,0.5)' },

  valeterCard: {
    borderRadius: 18,
    overflow: 'hidden',
    marginBottom: 10,
    borderWidth: 0,
  },
  valeterCardSelected: {
    borderWidth: 0,
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
  },
  valeterCardInner: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 18,
  },
  valeterAvatar: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: 'rgba(56,189,248,0.25)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 14,
  },
  valeterAvatarSelected: {
    backgroundColor: 'rgba(56,189,248,0.5)',
    borderWidth: 0,
  },
  valeterAvatarText: {
    fontSize: 20,
    fontWeight: '800',
    color: '#FFF',
  },
  valeterInfo: { flex: 1 },
  valeterName: {
    fontSize: 17,
    fontWeight: '800',
    color: '#F9FAFB',
    marginBottom: 4,
  },
  valeterNameSelected: { color: '#FFF' },
  valeterMeta: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  valeterRating: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  valeterRatingText: { color: GOLD, fontSize: 14, fontWeight: '700' },
  valeterEta: { color: 'rgba(255,255,255,0.7)', fontSize: 13, fontWeight: '600' },
  valeterCheck: { marginLeft: 8 },

  ctaWrap: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: CARD_PADDING,
    paddingTop: 16,
    paddingBottom: 34,
  },
  ctaBtn: { borderRadius: 18, overflow: 'hidden' },
  ctaBtnDisabled: { opacity: 0.8 },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 18,
    paddingHorizontal: 24,
  },
  ctaText: { color: '#FFF', fontSize: 18, fontWeight: '800' },
});
