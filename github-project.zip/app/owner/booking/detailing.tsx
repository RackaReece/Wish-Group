import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Alert,
  StatusBar,
  ScrollView,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Marker, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { customerTheme } from '../../../src/constants/customerTheme';
import { detailingServiceOptions } from '../../../src/constants/serviceOptions';
import { DARK_MAP_STYLE } from '../../../src/constants/mapStyles';
import ProBookingCard from '../../../src/components/booking/ProBookingCard';

const { width, height } = Dimensions.get('window');
const AMBER = '#F59E0B';
const GOLD = '#FBBF24';

type DetailingOption = (typeof detailingServiceOptions)[number];

export default function DetailingBookingScreen() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{
    isRepeat?: string;
    address?: string;
    latitude?: string;
    longitude?: string;
    serviceType?: string;
    serviceName?: string;
    price?: string;
    needsTimeSlot?: string;
  }>();
  const mapRef = useRef<MapView>(null);

  const isRepeat = params.isRepeat === '1';
  const needsTimeSlot = params.needsTimeSlot === '1';

  const [locationCoords, setLocationCoords] = useState<{ lat: number; lng: number; address: string } | null>(
    params.latitude && params.longitude && params.address
      ? {
          lat: parseFloat(params.latitude),
          lng: parseFloat(params.longitude),
          address: params.address,
        }
      : null
  );
  const [region, setRegion] = useState<Region | null>(
    params.latitude && params.longitude
      ? {
          latitude: parseFloat(params.latitude),
          longitude: parseFloat(params.longitude),
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        }
      : null
  );
  const [selectedTimeSlot, setSelectedTimeSlot] = useState<string | null>(null);
  const [geocoding, setGeocoding] = useState(false);

  const [selectedDetail, setSelectedDetail] = useState<DetailingOption | null>(null);
  const [selectedValeter, setSelectedValeter] = useState<{ id: string; name: string; rating: number; eta: string; specialty?: string } | null>(null);
  const [nearbyValeters, setNearbyValeters] = useState<Array<{ id: string; name: string; rating: number; eta: string; specialty?: string }>>([]);

  const loadCurrentLocation = useCallback(async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Location permission is required to find detailers near you.');
        return;
      }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = { lat: loc.coords.latitude, lng: loc.coords.longitude };
      setGeocoding(true);
      const rev = await Location.reverseGeocodeAsync(coords);
      const addr = rev?.[0]
        ? [rev[0].street, rev[0].city, rev[0].postalCode, rev[0].country].filter(Boolean).join(', ')
        : `${coords.lat.toFixed(4)}, ${coords.lng.toFixed(4)}`;
      setLocationCoords({ ...coords, address: addr || 'Current location' });
      const r: Region = {
        latitude: coords.lat,
        longitude: coords.lng,
        latitudeDelta: 0.02,
        longitudeDelta: 0.02,
      };
      setRegion(r);
      mapRef.current?.animateToRegion(r, 400);
    } catch (e) {
      console.warn('Current location error:', e);
      Alert.alert('Error', 'Could not get your location.');
    } finally {
      setGeocoding(false);
    }
  }, []);

  const reverseGeocode = useCallback(async (lat: number, lng: number) => {
    try {
      const rev = await Location.reverseGeocodeAsync({ latitude: lat, longitude: lng });
      const addr = rev?.[0]
        ? [rev[0].street, rev[0].city, rev[0].postalCode, rev[0].country].filter(Boolean).join(', ')
        : `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
      return addr;
    } catch {
      return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
    }
  }, []);

  const handleMapPress = useCallback(
    async (e: { nativeEvent: { coordinate: { latitude: number; longitude: number } } }) => {
      await hapticFeedback('light');
      const { latitude, longitude } = e.nativeEvent.coordinate;
      setGeocoding(true);
      const addr = await reverseGeocode(latitude, longitude);
      setLocationCoords({ lat: latitude, lng: longitude, address: addr });
      setGeocoding(false);
    },
    [reverseGeocode]
  );

  const handleMarkerDragEnd = useCallback(
    async (e: { nativeEvent: { coordinate: { latitude: number; longitude: number } } }) => {
      const { latitude, longitude } = e.nativeEvent.coordinate;
      setGeocoding(true);
      const addr = await reverseGeocode(latitude, longitude);
      setLocationCoords({ lat: latitude, lng: longitude, address: addr });
      setGeocoding(false);
    },
    [reverseGeocode]
  );

  useEffect(() => {
    if (!isRepeat || !locationCoords) loadCurrentLocation();
  }, [loadCurrentLocation, isRepeat, locationCoords]);

  useEffect(() => {
    if (isRepeat && params.serviceName) {
      const match = detailingServiceOptions.find((o) => o.name.toLowerCase() === params.serviceName?.toLowerCase());
      if (match) setSelectedDetail(match);
    }
  }, [isRepeat, params.serviceName]);

  useEffect(() => {
    if (!locationCoords) return;
    const valeters = [
      { id: 'd1', name: 'Marcus T.', rating: 4.95, eta: '~20 min', specialty: 'Paint correction' },
      { id: 'd2', name: 'Elena V.', rating: 4.9, eta: '~25 min', specialty: 'Full detail' },
      { id: 'd3', name: 'David R.', rating: 4.85, eta: '~30 min', specialty: 'Ceramic coating' },
    ];
    setNearbyValeters(valeters);
    if (isRepeat && valeters[0]) setSelectedValeter(valeters[0]);
  }, [locationCoords, isRepeat]);

  const effectiveRegion: Region = region ?? {
    latitude: 54,
    longitude: -2,
    latitudeDelta: 8,
    longitudeDelta: 8,
  };

  const canProceed = isRepeat
    ? locationCoords && (needsTimeSlot ? selectedTimeSlot : true)
    : locationCoords && selectedDetail && selectedValeter;

  const handleClose = () => {
    hapticFeedback('light');
    router.back();
  };

  const handleContinue = async () => {
    if (!canProceed) return;
    await hapticFeedback('medium');
    router.back();
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <LinearGradient colors={customerTheme.backgroundGradient as [string, string]} style={StyleSheet.absoluteFill} />

      {/* Full-screen map */}
      <MapView
        ref={mapRef}
        style={styles.map}
        region={effectiveRegion}
        onRegionChangeComplete={setRegion}
        onPress={handleMapPress}
        customMapStyle={DARK_MAP_STYLE}
        mapType="standard"
        showsUserLocation={true}
        showsMyLocationButton={false}
        mapPadding={{ top: 0, bottom: height * 0.45, left: 0, right: 0 }}
      >
        {locationCoords && (
          <Marker
            coordinate={{ latitude: locationCoords.lat, longitude: locationCoords.lng }}
            anchor={{ x: 0.5, y: 1 }}
            draggable
            onDragEnd={handleMarkerDragEnd}
          >
            <View style={styles.markerPin}>
              <View style={styles.markerGlow} />
              <View style={styles.markerInner}>
                <Ionicons name="diamond" size={20} color="#FFF" />
              </View>
            </View>
          </Marker>
        )}
      </MapView>

      {/* Top bar: Back + Select Location + actions */}
      <View style={[styles.topBar, { paddingTop: insets.top + 8 }]}>
        {/* Wash | Detailing toggle — under header */}
        <View style={styles.serviceToggleWrap}>
          <TouchableOpacity
            style={styles.serviceToggleBtn}
            onPress={async () => {
              await hapticFeedback('light');
              router.replace('/owner/booking' as any);
            }}
          >
            <Ionicons name="water-outline" size={18} color="rgba(255,255,255,0.65)" />
            <Text style={styles.serviceToggleText}>Wash</Text>
          </TouchableOpacity>
          <TouchableOpacity
            style={[styles.serviceToggleBtn, styles.serviceToggleActive]}
            onPress={() => {}}
            activeOpacity={1}
          >
            <Ionicons name="diamond-outline" size={18} color="#FFF" />
            <Text style={styles.serviceToggleTextActive}>Detailing</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.topBarRow}>
          <TouchableOpacity style={styles.backBtn} onPress={handleClose}>
            <Ionicons name="chevron-back" size={24} color="#FFF" />
          </TouchableOpacity>
          <View style={styles.selectLocationBtn}>
            <Ionicons name="location" size={20} color={AMBER} />
            <Text style={styles.selectLocationText} numberOfLines={1}>
              {locationCoords ? locationCoords.address : 'Select location on map'}
            </Text>
          </View>
          <View style={styles.topBarActions}>
            <TouchableOpacity
              style={styles.topBarIconBtn}
              onPress={loadCurrentLocation}
              disabled={geocoding}
            >
              {geocoding ? (
                <ActivityIndicator size="small" color={AMBER} />
              ) : (
                <Ionicons name="locate" size={22} color={AMBER} />
              )}
            </TouchableOpacity>
            <TouchableOpacity style={styles.topBarIconBtn} onPress={handleClose}>
              <Ionicons name="close" size={24} color="rgba(255,255,255,0.9)" />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      {/* Bottom card overlay */}
      <View style={[styles.cardOverlay, { bottom: insets.bottom + 24 }]}>
        <ProBookingCard stripColor={AMBER} intensity={60} style={styles.cardBlur}>
          <LinearGradient
            colors={['rgba(251,191,36,0.15)', 'rgba(180,83,9,0.2)']}
            style={styles.cardGradient}
          >
            {/* Context chips */}
            <View style={styles.chipsRow}>
              <View style={styles.chip}>
                <Text style={styles.chipText}>{nearbyValeters.length} detailers nearby</Text>
              </View>
              <View style={styles.chip}>
                <Text style={styles.chipText}>Nearest: ~20 min</Text>
              </View>
            </View>

            {/* Repeat summary */}
            {isRepeat && (selectedDetail || params.serviceName) && (
              <View style={styles.repeatSummary}>
                <Ionicons name="repeat" size={14} color="#10B981" />
                <Text style={styles.repeatText}>
                  {params.serviceName || selectedDetail?.name || 'Detailing'} • £{Number(params.price || selectedDetail?.price || 0).toFixed(2)}
                </Text>
              </View>
            )}

            {/* Service selection */}
            {!isRepeat && (
              <View style={styles.section}>
                <Text style={styles.sectionLabel}>Service</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.serviceScroll}>
                  {detailingServiceOptions.map((opt) => {
                    const isSelected = selectedDetail?.id === opt.id;
                    return (
                      <TouchableOpacity
                        key={opt.id}
                        style={[styles.servicePill, isSelected && styles.servicePillSelected]}
                        onPress={async () => {
                          await hapticFeedback('light');
                          setSelectedDetail(opt);
                        }}
                      >
                        <Ionicons name={opt.icon as any} size={18} color={isSelected ? '#FFF' : opt.colors[0]} />
                        <Text style={[styles.servicePillText, isSelected && styles.servicePillTextSelected]} numberOfLines={1}>
                          {opt.name}
                        </Text>
                        <Text style={[styles.servicePillPrice, { color: isSelected ? 'rgba(255,255,255,0.9)' : opt.colors[0] }]}>
                          £{opt.price}
                        </Text>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>
                {selectedDetail && (
                  <View style={styles.serviceDisclaimerWrap}>
                    <Text style={styles.serviceDescText}>{selectedDetail.desc}</Text>
                    {selectedDetail.disclaimer ? (
                      <Text style={styles.serviceDisclaimerText}>{selectedDetail.disclaimer}</Text>
                    ) : null}
                  </View>
                )}
              </View>
            )}

            {/* Valeter selection */}
            {!isRepeat && (
              <View style={styles.section}>
                <Text style={styles.sectionLabel}>Detailer</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.valeterScroll}>
                  {nearbyValeters.map((v) => {
                    const isSelected = selectedValeter?.id === v.id;
                    return (
                      <TouchableOpacity
                        key={v.id}
                        style={[styles.valeterPill, isSelected && styles.valeterPillSelected]}
                        onPress={async () => {
                          await hapticFeedback('light');
                          setSelectedValeter(v);
                        }}
                      >
                        <View style={[styles.valeterAvatar, isSelected && styles.valeterAvatarSelected]}>
                          <Text style={styles.valeterAvatarText}>{v.name.charAt(0)}</Text>
                        </View>
                        <Text style={[styles.valeterName, isSelected && styles.valeterNameSelected]} numberOfLines={1}>{v.name}</Text>
                        <View style={styles.valeterMeta}>
                          <Ionicons name="star" size={12} color={GOLD} />
                          <Text style={styles.valeterRating}>{v.rating}</Text>
                          <Text style={styles.valeterEta}>{v.eta}</Text>
                        </View>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>
              </View>
            )}

            {/* Time slot (repeat) */}
            {isRepeat && needsTimeSlot && locationCoords && (
              <View style={styles.section}>
                <Text style={styles.sectionLabel}>Time slot</Text>
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.timeSlotScroll}>
                  {['09:00', '10:00', '11:00', '14:00', '15:00', '16:00'].map((slot) => {
                    const isSelected = selectedTimeSlot === slot;
                    return (
                      <TouchableOpacity
                        key={slot}
                        style={[styles.timeSlotPill, isSelected && styles.timeSlotPillSelected]}
                        onPress={async () => {
                          await hapticFeedback('light');
                          setSelectedTimeSlot(slot);
                        }}
                      >
                        <Text style={[styles.timeSlotText, isSelected && styles.timeSlotTextSelected]}>{slot}</Text>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>
              </View>
            )}

            {/* CTA */}
            <TouchableOpacity
              style={[styles.ctaBtn, !canProceed && styles.ctaBtnDisabled]}
              onPress={handleContinue}
              disabled={!canProceed}
            >
              <LinearGradient
                colors={canProceed ? [AMBER, '#D97706'] : ['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.1)']}
                style={styles.ctaGradient}
              >
                <Text style={styles.ctaText}>{isRepeat ? 'Confirm & pay' : 'Continue to time slot'}</Text>
                <Ionicons name="arrow-forward" size={20} color="#FFF" />
              </LinearGradient>
            </TouchableOpacity>
          </LinearGradient>
        </ProBookingCard>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  map: { ...StyleSheet.absoluteFillObject },

  topBar: {
    position: 'absolute',
    left: 0,
    right: 0,
    zIndex: 10,
    paddingHorizontal: 16,
  },
  backBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(15,23,42,0.85)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  topBarRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  selectLocationBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 14,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1,
    borderColor: 'rgba(251,191,36,0.35)',
  },
  selectLocationText: {
    flex: 1,
    color: 'rgba(255,255,255,0.95)',
    fontSize: 15,
    fontWeight: '600',
  },
  topBarActions: {
    flexDirection: 'row',
    gap: 8,
  },
  topBarIconBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(15,23,42,0.85)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },

  headerOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    zIndex: 5,
  },

  markerPin: {
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  markerGlow: {
    position: 'absolute',
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: AMBER,
    opacity: 0.35,
  },
  markerInner: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: AMBER,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 3,
    borderColor: '#FFF',
  },

  cardOverlay: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 100,
  },
  cardBlur: {
    borderRadius: 28,
    overflow: 'hidden',
    borderWidth: 0,
  },
  cardGradient: {
    padding: 18,
    borderRadius: 28,
  },

  chipsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  chip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
    backgroundColor: 'rgba(251,191,36,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(251,191,36,0.35)',
  },
  chipText: {
    color: 'rgba(255,255,255,0.95)',
    fontSize: 12,
    fontWeight: '600',
  },

  repeatSummary: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.15)',
  },
  repeatText: {
    color: '#10B981',
    fontSize: 14,
    fontWeight: '700',
    flex: 1,
  },

  section: { marginBottom: 14 },
  sectionLabel: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 8,
  },
  serviceScroll: { gap: 10, paddingRight: 8 },
  servicePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 0,
  },
  servicePillSelected: {
    backgroundColor: 'rgba(251,191,36,0.35)',
    borderWidth: 0,
  },
  servicePillText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    fontWeight: '600',
  },
  servicePillTextSelected: { color: '#FFF' },
  servicePillPrice: {
    fontSize: 13,
    fontWeight: '800',
  },
  serviceDisclaimerWrap: {
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
  },
  serviceDescText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 12,
    lineHeight: 18,
    marginBottom: 4,
  },
  serviceDisclaimerText: {
    color: 'rgba(251,191,36,0.95)',
    fontSize: 11,
    lineHeight: 16,
    fontStyle: 'italic',
  },

  valeterScroll: { gap: 10, paddingRight: 8 },
  valeterPill: {
    alignItems: 'center',
    width: 90,
    paddingVertical: 12,
    paddingHorizontal: 10,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 0,
  },
  valeterPillSelected: {
    backgroundColor: 'rgba(251,191,36,0.25)',
    borderWidth: 0,
  },
  valeterAvatar: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(251,191,36,0.25)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 6,
  },
  valeterAvatarSelected: {
    backgroundColor: 'rgba(251,191,36,0.5)',
    borderWidth: 2,
    borderColor: AMBER,
  },
  valeterAvatarText: {
    color: '#FFF',
    fontSize: 16,
    fontWeight: '800',
  },
  valeterName: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 2,
  },
  valeterNameSelected: { color: '#FFF' },
  valeterMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  valeterRating: {
    color: GOLD,
    fontSize: 12,
    fontWeight: '700',
  },
  valeterEta: {
    color: 'rgba(255,255,255,0.65)',
    fontSize: 11,
  },

  timeSlotScroll: { gap: 10, paddingRight: 8 },
  timeSlotPill: {
    paddingVertical: 12,
    paddingHorizontal: 18,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 0,
  },
  timeSlotPillSelected: {
    backgroundColor: 'rgba(251,191,36,0.35)',
    borderWidth: 0,
  },
  timeSlotText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 15,
    fontWeight: '600',
  },
  timeSlotTextSelected: { color: '#FFF', fontWeight: '700' },

  ctaBtn: {
    borderRadius: 16,
    overflow: 'hidden',
    marginTop: 8,
  },
  ctaBtnDisabled: { opacity: 0.75 },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 16,
    paddingHorizontal: 24,
  },
  ctaText: {
    color: '#FFF',
    fontSize: 17,
    fontWeight: '800',
  },
});
