import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  ScrollView,
  StatusBar,
} from 'react-native';
import { router } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { Video, ResizeMode } from 'expo-av';

const { width, height } = Dimensions.get('window');

type SlideRole = 'valeter' | 'business';

interface Slide {
  id: number;
  role: SlideRole;
  title: string;
  subtitle: string;
  description: string;
  iconName: keyof typeof Ionicons.glyphMap;
  color: string;
}

const slides: Slide[] = [
  // Valeter qualities (1–4)
  {
    id: 1,
    role: 'valeter',
    title: 'Flexible Work',
    subtitle: 'For Valeters',
    description: 'Set your own schedule and work when it suits you. No fixed shifts—you’re in control.',
    iconName: 'calendar-outline',
    color: '#7DD3FC',
  },
  {
    id: 2,
    role: 'valeter',
    title: 'Earn What You Deserve',
    subtitle: 'Fair Pay',
    description: 'Keep the majority of what you earn. Transparent pricing and prompt payouts.',
    iconName: 'cash-outline',
    color: '#4ADE80',
  },
  {
    id: 3,
    role: 'valeter',
    title: 'Professional Tools',
    subtitle: 'Built for You',
    description: 'App, live tracking, and support designed so you can deliver a premium service.',
    iconName: 'construct-outline',
    color: '#A78BFA',
  },
  {
    id: 4,
    role: 'valeter',
    title: 'Build Your Reputation',
    subtitle: 'Grow Your Clientele',
    description: 'Reviews and repeat customers help you stand out and get more bookings.',
    iconName: 'star-outline',
    color: '#FBBF24',
  },
  // Business qualities (5–8)
  {
    id: 5,
    role: 'business',
    title: 'Manage Your Locations',
    subtitle: 'For Businesses',
    description: 'Add your sites, set services and availability, and accept bookings in one place.',
    iconName: 'location-outline',
    color: '#60A5FA',
  },
  {
    id: 6,
    role: 'business',
    title: 'Build Your Team',
    subtitle: 'Invite Valeters',
    description: 'Invite professional valeters to your locations and assign jobs with ease.',
    iconName: 'people-outline',
    color: '#F59E0B',
  },
  {
    id: 7,
    role: 'business',
    title: 'Bookings & Orders',
    subtitle: 'Stay in Control',
    description: 'Accept, track, and manage bookings in real time. Never miss a job.',
    iconName: 'list-outline',
    color: '#34D399',
  },
  {
    id: 8,
    role: 'business',
    title: 'Grow Your Business',
    subtitle: 'Scale with Data',
    description: 'Earnings, analytics, and insights to help you grow and optimise.',
    iconName: 'trending-up-outline',
    color: '#A78BFA',
  },
];

export default function OnboardingScreen() {
  const insets = useSafeAreaInsets();
  const [currentSlide, setCurrentSlide] = useState(0);
  const scrollViewRef = useRef<ScrollView>(null);

  const progressAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(progressAnim, {
        toValue: (currentSlide + 1) / slides.length,
        duration: 300,
        useNativeDriver: false,
      }),
    ]).start();
  }, [currentSlide]);

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      const next = currentSlide + 1;
      setCurrentSlide(next);
      scrollViewRef.current?.scrollTo({ x: next * width, animated: true });
    } else {
      handleGetStarted();
    }
  };

  const handleSkip = () => {
    handleGetStarted();
  };

  const handleGetStarted = async () => {
    try {
      await AsyncStorage.setItem('onboarding_seen', 'true');
      router.replace('/auth/login');
    } catch (error) {
      console.error('Error saving onboarding status:', error);
      router.replace('/auth/login');
    }
  };

  const handleScroll = (event: { nativeEvent: { contentOffset: { x: number } } }) => {
    const index = Math.round(event.nativeEvent.contentOffset.x / width);
    if (index >= 0 && index < slides.length && index !== currentSlide) {
      setCurrentSlide(index);
    }
  };

  const slide = slides[currentSlide];

  return (
    <View style={styles.container}>
      <Video
        source={require('./assets/business.mp4')}
        style={StyleSheet.absoluteFill}
        shouldPlay
        isLooping
        isMuted
        resizeMode={ResizeMode.COVER}
      />
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <LinearGradient
          colors={['rgba(10,25,41,0.6)', 'rgba(15,23,42,0.75)', 'rgba(10,25,41,0.85)']}
          style={StyleSheet.absoluteFill}
        />
      </View>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />

      {/* Header: progress + skip */}
      <View style={[styles.header, { paddingTop: insets.top + 12 }]}>
        <View style={styles.progressBar}>
          <Animated.View
            style={[
              styles.progressFill,
              {
                width: progressAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: ['0%', '100%'],
                }),
              },
            ]}
          />
        </View>
        <TouchableOpacity onPress={handleSkip} style={styles.skipButton} activeOpacity={0.7}>
          <Text style={styles.skipText}>Skip</Text>
        </TouchableOpacity>
      </View>

      {/* Slides */}
      <ScrollView
        ref={scrollViewRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        style={styles.scrollView}
      >
        {slides.map((s, index) => (
          <View key={s.id} style={[styles.slide, { width }]}>
            <View style={styles.badge}>
              <Text style={[styles.badgeText, { color: s.color }]}>
                {s.role === 'valeter' ? 'For Valeters' : 'For Businesses'}
              </Text>
            </View>
            <View style={[styles.iconRing, { borderColor: s.color + '50' }]}>
              <View style={[styles.iconInner, { backgroundColor: s.color + '20' }]}>
                <Ionicons name={s.iconName} size={48} color={s.color} />
              </View>
            </View>
            <Text style={styles.title}>{s.title}</Text>
            <Text style={styles.subtitle}>{s.subtitle}</Text>
            <Text style={styles.description}>{s.description}</Text>
          </View>
        ))}
      </ScrollView>

      {/* Dots + CTA */}
      <View style={[styles.footer, { paddingBottom: insets.bottom + 24 }]}>
        <View style={styles.dots}>
          {slides.map((_, index) => (
            <View
              key={index}
              style={[
                styles.dot,
                index === currentSlide && styles.dotActive,
                index === currentSlide && { backgroundColor: slide.color },
              ]}
            />
          ))}
        </View>
        <TouchableOpacity
          style={[styles.ctaButton, { backgroundColor: slide.color }]}
          onPress={handleNext}
          activeOpacity={0.85}
        >
          <Text style={styles.ctaText}>
            {currentSlide === slides.length - 1 ? 'Get Started' : 'Next'}
          </Text>
          <Ionicons
            name={currentSlide === slides.length - 1 ? 'checkmark' : 'arrow-forward'}
            size={20}
            color="#0A1929"
          />
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 16,
    gap: 12,
  },
  progressBar: {
    flex: 1,
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#7DD3FC',
    borderRadius: 2,
  },
  skipButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  skipText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 15,
    fontWeight: '600',
  },
  scrollView: {
    flex: 1,
  },
  slide: {
    flex: 1,
    paddingHorizontal: 32,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: 20,
  },
  badge: {
    paddingHorizontal: 14,
    paddingVertical: 6,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.08)',
    marginBottom: 28,
  },
  badgeText: {
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  iconRing: {
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 2,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 28,
  },
  iconInner: {
    width: 88,
    height: 88,
    borderRadius: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontFamily: 'Rubik_600SemiBold',
    fontSize: 26,
    color: '#FFFFFF',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontFamily: 'Rubik_500Medium',
    fontSize: 16,
    color: 'rgba(255,255,255,0.7)',
    textAlign: 'center',
    marginBottom: 14,
  },
  description: {
    fontFamily: 'Rubik_400Regular',
    fontSize: 15,
    color: 'rgba(255,255,255,0.75)',
    textAlign: 'center',
    lineHeight: 22,
    paddingHorizontal: 8,
  },
  footer: {
    paddingHorizontal: 24,
    paddingTop: 24,
    alignItems: 'center',
  },
  dots: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 20,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.25)',
  },
  dotActive: {
    width: 24,
  },
  ctaButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 28,
    minWidth: 200,
  },
  ctaText: {
    fontFamily: 'Rubik_600SemiBold',
    fontSize: 17,
    color: '#0A1929',
    letterSpacing: 0.2,
  },
});
