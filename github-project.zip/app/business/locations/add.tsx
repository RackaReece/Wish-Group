// app/business/locations/add.tsx – Add New Location (same UI as manage location [id].tsx)
import React, { useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  ImageBackground,
  Dimensions,
  Animated,
  Switch,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';

import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_HEIGHT, HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import { getTextColors, getIconColors } from '../../../src/constants/themeColors';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const HERO_H = Math.round(width * 0.52);

// ----- Opening hours (aligned with [id].tsx) -----
type DayKey = 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun';
const DAYS: Array<{ key: DayKey; label: string; idx: number }> = [
  { key: 'mon', label: 'Mon', idx: 0 },
  { key: 'tue', label: 'Tue', idx: 1 },
  { key: 'wed', label: 'Wed', idx: 2 },
  { key: 'thu', label: 'Thu', idx: 3 },
  { key: 'fri', label: 'Fri', idx: 4 },
  { key: 'sat', label: 'Sat', idx: 5 },
  { key: 'sun', label: 'Sun', idx: 6 },
];

type OpeningHourState = { isOpen: boolean; openTime: string; closeTime: string; slotMinutes: number };
const defaultOpeningHours = (): Record<DayKey, OpeningHourState> => ({
  mon: { isOpen: true, openTime: '09:00', closeTime: '17:00', slotMinutes: 30 },
  tue: { isOpen: true, openTime: '09:00', closeTime: '17:00', slotMinutes: 30 },
  wed: { isOpen: true, openTime: '09:00', closeTime: '17:00', slotMinutes: 30 },
  thu: { isOpen: true, openTime: '09:00', closeTime: '17:00', slotMinutes: 30 },
  fri: { isOpen: true, openTime: '09:00', closeTime: '17:00', slotMinutes: 30 },
  sat: { isOpen: false, openTime: '09:00', closeTime: '13:00', slotMinutes: 30 },
  sun: { isOpen: false, openTime: '09:00', closeTime: '13:00', slotMinutes: 30 },
});

const isValidHHMM = (s: string) => /^([01]\d|2[0-3]):([0-5]\d)$/.test((s || '').trim());
const pad2 = (n: number) => String(n).padStart(2, '0');
const hhmmToMinutes = (s: string) => {
  if (!isValidHHMM(s)) return null;
  const [h, m] = s.split(':').map((x) => Number(x));
  return h * 60 + m;
};
const minutesToHHMM = (mins: number) => {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${pad2(h)}:${pad2(m)}`;
};
const buildSlots = (openHHMM: string, closeHHMM: string, slotMinutes: number) => {
  const open = hhmmToMinutes(openHHMM);
  const close = hhmmToMinutes(closeHHMM);
  if (open === null || close === null) return [];
  if (slotMinutes <= 0) return [];
  if (close <= open) return [];
  const out: string[] = [];
  for (let t = open; t + slotMinutes <= close; t += slotMinutes) {
    out.push(minutesToHHMM(t));
  }
  return out;
};

// ----- Tier definitions (same as [id].tsx with gradient) -----
const TIER_DEFS = [
  { key: 'bronze', name: 'Bronze Wash', icon: 'layers-outline' as const, color: '#CD7F32', gradient: ['#CD7F32', '#B87333'] },
  { key: 'silver', name: 'Silver Wash', icon: 'star-outline' as const, color: '#C0C0C0', gradient: ['#C0C0C0', '#A8A8A8'] },
  { key: 'gold', name: 'Gold Wash', icon: 'trophy' as const, color: '#FFD700', gradient: ['#FFD700', '#FFA500'] },
  { key: 'platinum', name: 'Platinum Wash', icon: 'diamond' as const, color: '#E5E4E2', gradient: ['#E5E4E2', '#D3D3D3'] },
];

type TierPriceState = { price: string; duration: string };
const defaultTierPrices = (): Record<string, TierPriceState> =>
  Object.fromEntries(TIER_DEFS.map((t) => [t.key, { price: '', duration: '30' }]));

export default function AddLocationScreen() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { theme: businessTheme } = useAccountTheme();
  const theme = businessTheme ?? getAccountTheme('business', 'light');
  const textColors = getTextColors(theme);
  const placeholderColor = textColors.placeholder;
  const fadeAnim = useRef(new Animated.Value(1)).current;

  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [coverUri, setCoverUri] = useState<string | null>(null);
  const [openingHours, setOpeningHours] = useState<Record<DayKey, OpeningHourState>>(defaultOpeningHours());
  const [tierPrices, setTierPrices] = useState<Record<string, TierPriceState>>(defaultTierPrices());
  const [ecoWashing, setEcoWashing] = useState(false);
  const [detailingOffered, setDetailingOffered] = useState(false);
  const [saving, setSaving] = useState(false);

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  const pickImage = async (kind: 'cover') => {
    try {
      await hapticFeedback('light');
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permission needed', 'Allow photo access to add an image.');
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsEditing: true,
        aspect: [16, 9],
        quality: 0.85,
      });
      if (result.canceled || !result.assets?.[0]?.uri) return;
      setCoverUri(result.assets[0].uri);
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Could not open photo library');
    }
  };

  const validateOpeningHours = (): string | null => {
    for (const d of DAYS) {
      const s = openingHours[d.key];
      if (!s.isOpen) continue;
      if (!isValidHHMM(s.openTime) || !isValidHHMM(s.closeTime))
        return `${d.label}: use HH:MM (e.g. 09:00)`;
      const openM = hhmmToMinutes(s.openTime)!;
      const closeM = hhmmToMinutes(s.closeTime)!;
      if (closeM <= openM) return `${d.label}: close must be after open`;
      const slot = s.slotMinutes;
      if (!Number.isFinite(slot) || slot < 5 || slot > 240) return `${d.label}: slot 5–240 min`;
    }
    return null;
  };

  const handleAdd = async () => {
    if (!name.trim() || !address.trim()) {
      Alert.alert('Required', 'Please enter location name and full address.');
      return;
    }
    if (!isOrgUser || !organizationId) {
      Alert.alert('Error', 'Business account is not linked to an organization.');
      return;
    }
    const hoursErr = validateOpeningHours();
    if (hoursErr) {
      Alert.alert('Opening hours', hoursErr);
      return;
    }

    try {
      setSaving(true);
      await hapticFeedback('medium');

      const { data: locRow, error: locErr } = await supabase
        .from('car_wash_locations')
        .insert({
          name: name.trim(),
          address: address.trim(),
          organization_id: organizationId,
          latitude: null,
          longitude: null,
          is_active: true,
          status: 'active',
        })
        .select('id')
        .single();

      if (locErr) throw locErr;
      const locationId = (locRow as { id: string })?.id;
      if (!locationId) throw new Error('Location not created');

      if (ecoWashing || detailingOffered) {
        try {
          await supabase
            .from('car_wash_locations')
            .update({
              ...(ecoWashing && { eco_washing: true }),
              ...(detailingOffered && { detailing_offered: true }),
            })
            .eq('id', locationId);
        } catch (_) {
          // Columns may not exist
        }
      }

      try {
        const payload = DAYS.map((d) => {
          const s = openingHours[d.key];
          return {
            location_id: locationId,
            day_of_week: d.idx,
            is_open: !!s.isOpen,
            open_time: s.isOpen ? s.openTime : null,
            close_time: s.isOpen ? s.closeTime : null,
            slot_minutes: s.slotMinutes || 30,
          };
        });
        await supabase.from('location_opening_hours').upsert(payload, {
          onConflict: 'location_id,day_of_week',
        });
      } catch (e) {
        console.warn('Opening hours save failed (table may not exist):', e);
      }

      try {
        const inserts = TIER_DEFS.map((t) => {
          const state = tierPrices[t.key] || { price: '', duration: '30' };
          const price = state.price.trim() ? parseFloat(state.price) : null;
          const duration = state.duration.trim() && /^\d+$/.test(state.duration) ? parseInt(state.duration, 10) : null;
          return {
            location_id: locationId,
            service_name: t.name,
            is_enabled: true,
            price: Number.isFinite(price) && price != null ? price : null,
            duration_minutes: duration,
          };
        });
        await supabase.from('location_services').insert(inserts);
      } catch (e) {
        console.warn('Location services insert failed (table may not exist):', e);
      }

      Alert.alert('Success', 'Location added. You can add photos and more details on the location page.', [
        { text: 'OK', onPress: () => router.replace(`/business/locations/${locationId}` as any) },
      ]);
    } catch (err: any) {
      console.error('Error adding location:', err);
      Alert.alert('Error', err?.message ?? 'Failed to add location');
    } finally {
      setSaving(false);
    }
  };

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background[0] }]} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <AppHeader
        title="New location"
        subtitle="Add name, address & pricing"
        onBack={() => router.back()}
        accountType="business"
      />

      <KeyboardAvoidingView
        style={{ flex: 1 }}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? insets.top + HEADER_HEIGHT : 0}
      >
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={[
            styles.scrollContent,
            {
              paddingTop: HEADER_CONTENT_OFFSET,
              paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24,
            },
          ]}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          keyboardDismissMode="on-drag"
        >
          {/* Hero (same as manage location) */}
          <Animated.View style={[styles.heroWrap, { opacity: fadeAnim }]}>
            <ImageBackground
              source={coverUri ? { uri: coverUri } : undefined}
              style={styles.hero}
              imageStyle={styles.heroImg}
            >
              {!coverUri && (
                <LinearGradient colors={['rgba(0,0,0,0.35)', 'rgba(0,0,0,0.65)']} style={StyleSheet.absoluteFill} />
              )}
              <View style={styles.heroTopRow}>
                <View style={styles.heroBadge}>
                  <Ionicons name="image-outline" size={16} color="#F9FAFB" />
                  <Text style={styles.heroBadgeText}>{coverUri ? 'Header photo' : 'No header photo'}</Text>
                </View>
                <TouchableOpacity onPress={() => pickImage('cover')} style={styles.heroBtn} activeOpacity={0.85}>
                  <Ionicons name={coverUri ? 'refresh' : 'add'} size={18} color="#fff" />
                  <Text style={styles.heroBtnText}>{coverUri ? 'Change' : 'Add'}</Text>
                </TouchableOpacity>
              </View>
              <View style={styles.heroBottom}>
                <Text style={styles.heroTitle} numberOfLines={1}>
                  {name || 'New location'}
                </Text>
                <Text style={styles.heroSubtitle} numberOfLines={1}>
                  {address || 'Enter name and address'}
                </Text>
              </View>
            </ImageBackground>
          </Animated.View>

          {/* Location Details (same card as [id]) */}
          <Animated.View style={{ opacity: fadeAnim }}>
            <Text style={styles.sectionTitle}>Location Details</Text>
            <GlassCard style={styles.card} accountType="business">
              <View style={styles.field}>
                <Text style={styles.label}>Location name</Text>
                <GlassCard style={styles.inputCard} accountType="business">
                  <TextInput
                    value={name}
                    onChangeText={setName}
                    placeholder="e.g., Main Car Wash Hub"
                    placeholderTextColor={placeholderColor}
                    style={styles.input}
                  />
                </GlassCard>
              </View>
              <View style={styles.field}>
                <Text style={styles.label}>Address</Text>
                <GlassCard style={styles.inputCard} accountType="business">
                  <TextInput
                    value={address}
                    onChangeText={setAddress}
                    placeholder="Enter full address"
                    placeholderTextColor={placeholderColor}
                    style={[styles.input, styles.textArea]}
                    multiline
                    numberOfLines={3}
                  />
                </GlassCard>
              </View>
              <View style={styles.rowBetween}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>Eco washing</Text>
                  <Text style={styles.miniText}>Marks this location as eco-friendly for customers.</Text>
                </View>
                <Switch
                  value={ecoWashing}
                  onValueChange={async (v) => {
                    await hapticFeedback('light');
                    setEcoWashing(v);
                  }}
                />
              </View>
              <View style={{ height: 10 }} />
              <View style={styles.rowBetween}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>Detailing offered</Text>
                  <Text style={styles.miniText}>Turn on to show detailing options + pricing.</Text>
                </View>
                <Switch
                  value={detailingOffered}
                  onValueChange={async (v) => {
                    await hapticFeedback('light');
                    setDetailingOffered(v);
                  }}
                />
              </View>
            </GlassCard>
          </Animated.View>

          {/* Opening Hours (same UI as [id]) */}
          <Animated.View style={{ opacity: fadeAnim, marginTop: 22 }}>
            <Text style={styles.sectionTitle}>Opening Hours</Text>
            <GlassCard style={styles.card} accountType="business">
              <Text style={styles.miniText}>
                Set opening/closing times per day. The customer app can then generate{' '}
                <Text style={{ fontWeight: '900' }}>30 minute</Text> slots (or whatever you set).
              </Text>
              <View style={{ height: 12 }} />
              <View style={{ gap: 10 }}>
                {DAYS.map((d) => {
                  const s = openingHours[d.key];
                  const slots = s.isOpen ? buildSlots(s.openTime, s.closeTime, s.slotMinutes) : [];
                  return (
                    <View key={d.key} style={styles.hoursRow}>
                      <View style={styles.hoursTop}>
                        <View style={styles.row}>
                          <View style={styles.dayPill}>
                            <Text style={styles.dayPillText}>{d.label}</Text>
                          </View>
                          <Text style={styles.label}>{s.isOpen ? 'Open' : 'Closed'}</Text>
                        </View>
                        <Switch
                          value={s.isOpen}
                          onValueChange={async (v) => {
                            await hapticFeedback('light');
                            setOpeningHours((prev) => ({
                              ...prev,
                              [d.key]: { ...prev[d.key], isOpen: v },
                            }));
                          }}
                        />
                      </View>
                      {s.isOpen ? (
                        <>
                          <View style={styles.hoursInputs}>
                            <View style={{ flex: 1 }}>
                              <Text style={styles.inlineLabel}>Open</Text>
                              <GlassCard style={styles.inlineInputCard} accountType="business">
                                <TextInput
                                  value={s.openTime}
                                  onChangeText={(t) =>
                                    setOpeningHours((prev) => ({ ...prev, [d.key]: { ...prev[d.key], openTime: t } }))
                                  }
                                  placeholder="09:00"
                                  placeholderTextColor={placeholderColor}
                                  style={styles.inlineInput}
                                />
                              </GlassCard>
                            </View>
                            <View style={{ flex: 1 }}>
                              <Text style={styles.inlineLabel}>Close</Text>
                              <GlassCard style={styles.inlineInputCard} accountType="business">
                                <TextInput
                                  value={s.closeTime}
                                  onChangeText={(t) =>
                                    setOpeningHours((prev) => ({ ...prev, [d.key]: { ...prev[d.key], closeTime: t } }))
                                  }
                                  placeholder="17:00"
                                  placeholderTextColor={placeholderColor}
                                  style={styles.inlineInput}
                                />
                              </GlassCard>
                            </View>
                            <View style={{ width: 110 }}>
                              <Text style={styles.inlineLabel}>Slot (min)</Text>
                              <GlassCard style={styles.inlineInputCard} accountType="business">
                                <TextInput
                                  value={String(s.slotMinutes)}
                                  onChangeText={(t) => {
                                    const n = Number((t || '').replace(/[^\d]/g, ''));
                                    setOpeningHours((prev) => ({
                                      ...prev,
                                      [d.key]: {
                                        ...prev[d.key],
                                        slotMinutes: Number.isFinite(n) && n > 0 ? n : prev[d.key].slotMinutes,
                                      },
                                    }));
                                  }}
                                  placeholder="30"
                                  placeholderTextColor={placeholderColor}
                                  keyboardType="number-pad"
                                  style={styles.inlineInput}
                                />
                              </GlassCard>
                            </View>
                          </View>
                          <View style={styles.slotPreviewRow}>
                            <View style={styles.serviceChip}>
                              <Text style={styles.serviceChipText}>Creates {slots.length} slots</Text>
                            </View>
                            {slots.length > 0 ? (
                              <Text style={[styles.miniText, { flex: 1, textAlign: 'right' }]} numberOfLines={1}>
                                {slots.slice(0, 4).join(', ')}
                                {slots.length > 4 ? ' …' : ''}
                              </Text>
                            ) : (
                              <Text style={[styles.miniText, { flex: 1, textAlign: 'right' }]}>Check times</Text>
                            )}
                          </View>
                        </>
                      ) : null}
                    </View>
                  );
                })}
              </View>
            </GlassCard>
          </Animated.View>

          {/* Tier Pricing (same cards as [id]) */}
          <Animated.View style={{ opacity: fadeAnim, marginTop: 22 }}>
            <Text style={styles.sectionTitle}>Tier Pricing</Text>
            <GlassCard style={styles.card} accountType="business">
              <View style={{ gap: 10 }}>
                {TIER_DEFS.map((tier) => {
                  const state = tierPrices[tier.key] ?? { price: '', duration: '30' };
                  const priceNum = state.price.trim() ? parseFloat(state.price) : null;
                  const durationNum = state.duration.trim() && /^\d+$/.test(state.duration) ? parseInt(state.duration, 10) : null;
                  return (
                    <GlassCard key={tier.key} style={styles.tierCard} accountType="business">
                      <LinearGradient
                        colors={[`${tier.color}18`, `${tier.color}08`, 'rgba(255,255,255,0.02)']}
                        style={StyleSheet.absoluteFill}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 1 }}
                      />
                      <View style={styles.tierCardHeader}>
                        <View style={[styles.tierIconWrapper, { backgroundColor: `${tier.color}25` }]}>
                          <Ionicons name={tier.icon} size={22} color={tier.color} />
                        </View>
                        <View style={styles.tierHeaderText}>
                          <Text style={[styles.tierName, { color: tier.color }]}>{tier.name}</Text>
                          <View style={styles.tierPillsRow}>
                            <View style={[styles.tierPill, { backgroundColor: `${tier.color}22`, borderColor: `${tier.color}35` }]}>
                              <Ionicons name="cash" size={14} color={tier.color} />
                              <Text style={[styles.tierPillText, { color: tier.color }]}>
                                £{priceNum != null && Number.isFinite(priceNum) ? priceNum.toFixed(2) : '0.00'}
                              </Text>
                            </View>
                            <View style={[styles.tierPill, { backgroundColor: `${tier.color}22`, borderColor: `${tier.color}35` }]}>
                              <Ionicons name="time" size={14} color={tier.color} />
                              <Text style={[styles.tierPillText, { color: tier.color }]}>
                                {durationNum != null ? `${durationNum}m` : '—'}
                              </Text>
                            </View>
                          </View>
                        </View>
                      </View>
                      <View style={styles.tierInputsRow}>
                        <View style={styles.tierInputGroup}>
                          <View style={styles.tierInputLabel}>
                            <Ionicons name="cash-outline" size={14} color="rgba(249,250,251,0.6)" />
                            <Text style={styles.tierInputLabelText}>Price (Small)</Text>
                          </View>
                          <BlurView intensity={40} tint="dark" style={styles.tierInputBlur}>
                            <TextInput
                              value={state.price}
                              placeholder="0.00"
                              placeholderTextColor={placeholderColor}
                              keyboardType="decimal-pad"
                              style={styles.tierInput}
                              onChangeText={(txt) => {
                                const filtered = txt.replace(/[^0-9.]/g, '').replace(/(\..*)\./g, '$1');
                                setTierPrices((prev) => ({
                                  ...prev,
                                  [tier.key]: { ...(prev[tier.key] ?? { price: '', duration: '30' }), price: filtered },
                                }));
                              }}
                            />
                          </BlurView>
                        </View>
                        <View style={styles.tierInputGroup}>
                          <View style={styles.tierInputLabel}>
                            <Ionicons name="time-outline" size={14} color="rgba(249,250,251,0.6)" />
                            <Text style={styles.tierInputLabelText}>Duration</Text>
                          </View>
                          <BlurView intensity={40} tint="dark" style={styles.tierInputBlur}>
                            <TextInput
                              value={state.duration}
                              placeholder="30"
                              placeholderTextColor={placeholderColor}
                              keyboardType="number-pad"
                              style={styles.tierInput}
                              onChangeText={(txt) => {
                                const filtered = txt.replace(/[^0-9]/g, '').slice(0, 3);
                                setTierPrices((prev) => ({
                                  ...prev,
                                  [tier.key]: { ...(prev[tier.key] ?? { price: '', duration: '30' }), duration: filtered },
                                }));
                              }}
                            />
                          </BlurView>
                        </View>
                      </View>
                    </GlassCard>
                  );
                })}
              </View>
              <View style={{ height: 10 }} />
              <Text style={styles.miniText}>
                Set price (Small) and duration per wash tier. These are the fixed tiers customers will see.
              </Text>
            </GlassCard>
          </Animated.View>

          <View style={{ height: 14 }} />
          <TouchableOpacity
            onPress={handleAdd}
            disabled={saving}
            style={[styles.primaryBtn, saving && { opacity: 0.7 }]}
            activeOpacity={0.85}
          >
            <LinearGradient colors={[theme.primary, theme.primaryAlt]} style={styles.primaryBtnGrad}>
              {saving ? (
                <ActivityIndicator size="small" color="#fff" />
              ) : (
                <>
                  <Ionicons name="add-circle" size={20} color="#fff" />
                  <Text style={styles.primaryBtnText}>Add location</Text>
                </>
              )}
            </LinearGradient>
          </TouchableOpacity>
          <View style={{ height: 28 }} />
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: colors.BG },
  scrollView: { flex: 1 },
  scrollContent: { padding: 20 },

  heroWrap: {
    marginBottom: 18,
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  hero: {
    height: HERO_H,
    width: '100%',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  heroImg: { borderRadius: 22 },
  heroTopRow: {
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  heroBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: 'rgba(0,0,0,0.35)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  heroBadgeText: { color: '#F9FAFB', fontSize: 12, fontWeight: '800' },
  heroBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 999,
    backgroundColor: 'rgba(0,0,0,0.40)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  heroBtnText: { color: '#F9FAFB', fontSize: 12, fontWeight: '900' },
  heroBottom: {
    padding: 14,
    backgroundColor: 'rgba(0,0,0,0.40)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.10)',
  },
  heroTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '900' },
  heroSubtitle: { color: 'rgba(249,250,251,0.78)', fontSize: 12, marginTop: 4, fontWeight: '700' },

  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 12,
  },
  card: { padding: 16 },
  field: { gap: 8, marginBottom: 12 },
  label: { color: 'rgba(249,250,251,0.85)', fontSize: 13, fontWeight: '700' },
  miniText: { color: 'rgba(249,250,251,0.65)', fontSize: 12, lineHeight: 18 },
  inputCard: { padding: 0, overflow: 'hidden' },
  input: { color: '#F9FAFB', fontSize: 16, padding: 14, minHeight: 48 },
  textArea: { minHeight: 92, textAlignVertical: 'top' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  rowBetween: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 10 },

  primaryBtn: { borderRadius: 16, overflow: 'hidden' },
  primaryBtnGrad: {
    paddingVertical: 14,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  primaryBtnText: { color: '#fff', fontSize: 14, fontWeight: '800' },

  hoursRow: {
    padding: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.14)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    gap: 10,
  },
  hoursTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  dayPill: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
  },
  dayPillText: { color: '#F9FAFB', fontSize: 12, fontWeight: '900' },
  hoursInputs: { flexDirection: 'row', gap: 10, alignItems: 'flex-end' },
  inlineLabel: { color: 'rgba(249,250,251,0.6)', fontSize: 11, fontWeight: '900', marginBottom: 6 },
  inlineInputCard: { padding: 0, overflow: 'hidden' },
  inlineInput: { color: '#F9FAFB', fontSize: 14, paddingVertical: 10, paddingHorizontal: 12 },
  slotPreviewRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  serviceChip: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
    alignSelf: 'flex-start',
  },
  serviceChipText: { color: 'rgba(249,250,251,0.85)', fontSize: 12, fontWeight: '800' },

  tierCard: {
    padding: 16,
    borderRadius: 18,
    overflow: 'hidden',
    marginBottom: 0,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  tierCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 14,
  },
  tierIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tierHeaderText: { flex: 1 },
  tierName: { fontSize: 17, fontWeight: '800', marginBottom: 6, letterSpacing: 0.2 },
  tierPillsRow: { flexDirection: 'row', gap: 8 },
  tierPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1,
  },
  tierPillText: { fontSize: 13, fontWeight: '700' },
  tierInputsRow: { flexDirection: 'row', gap: 10 },
  tierInputGroup: { flex: 1 },
  tierInputLabel: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  tierInputLabelText: { color: 'rgba(249,250,251,0.7)', fontSize: 12, fontWeight: '600' },
  tierInputBlur: {
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  tierInput: {
    color: '#F9FAFB',
    fontSize: 15,
    paddingVertical: 10,
    paddingHorizontal: 12,
    fontWeight: '700',
  },
});
