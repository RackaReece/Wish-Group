import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import LoadingView from '../../src/components/shared/LoadingView';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING, getMetricCardWidth } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { getTextColors, getIconColors } from '../../src/constants/themeColors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;

export default function BusinessAnalytics() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const theme = businessTheme ?? getAccountTheme('business', 'light');
  const textColors = getTextColors(theme);
  const iconColors = getIconColors(theme);
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    setLoading(false);
  }, [user?.id]);

  if (loading) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <AppHeader
        title="Analytics"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[
          styles.scrollContent, 
          { 
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
          }
        ]}
      >
        {/* Overview Stats - Horizontal Scroll */}
        <View style={styles.statsSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Key Metrics</Text>
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.statsScrollContainer}
          >
            <Animated.View 
              style={[
                { opacity: fadeAnim },
                {
                  transform: [
                    {
                      translateX: fadeAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [20, 0],
                      }),
                    },
                  ],
                },
              ]}
            >
              <GlassCard style={styles.statCard} accountType="business">
                <LinearGradient
                  colors={['rgba(96,217,255,0.20)', 'rgba(59,197,232,0.12)', 'rgba(0,0,0,0.05)']}
                  style={styles.statGradient}
                >
                  <View style={styles.statIconWrapper}>
                    <LinearGradient
                      colors={['rgba(125,211,252,0.35)', 'rgba(91,195,235,0.25)']}
                      style={styles.statIconGradient}
                    >
                      <Ionicons name="trending-up" size={26} color={theme.primary} />
                    </LinearGradient>
                  </View>
                  <View style={styles.statTextContainer}>
                    <Text style={styles.statValue}>£0</Text>
                    <Text style={styles.statLabel}>Total Revenue</Text>
                  </View>
                </LinearGradient>
              </GlassCard>
            </Animated.View>

            <Animated.View 
              style={[
                { opacity: fadeAnim },
                {
                  transform: [
                    {
                      translateX: fadeAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [20, 0],
                      }),
                    },
                  ],
                },
              ]}
            >
              <GlassCard style={styles.statCard} accountType="business">
                <LinearGradient
                  colors={['rgba(16,185,129,0.20)', 'rgba(5,150,105,0.12)', 'rgba(0,0,0,0.05)']}
                  style={styles.statGradient}
                >
                  <View style={[styles.statIconWrapper, styles.statIconWrapperGreen]}>
                    <LinearGradient
                      colors={['rgba(16,185,129,0.35)', 'rgba(5,150,105,0.25)']}
                      style={styles.statIconGradient}
                    >
                      <Ionicons name="calendar" size={26} color="#10B981" />
                    </LinearGradient>
                  </View>
                  <View style={styles.statTextContainer}>
                    <Text style={styles.statValue}>0</Text>
                    <Text style={styles.statLabel}>Total Bookings</Text>
                  </View>
                </LinearGradient>
              </GlassCard>
            </Animated.View>

            <Animated.View 
              style={[
                { opacity: fadeAnim },
                {
                  transform: [
                    {
                      translateX: fadeAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [20, 0],
                      }),
                    },
                  ],
                },
              ]}
            >
              <GlassCard style={styles.statCard} accountType="business">
                <LinearGradient
                  colors={['rgba(125,211,252,0.20)', 'rgba(30,58,138,0.12)', 'rgba(0,0,0,0.05)']}
                  style={styles.statGradient}
                >
                  <View style={[styles.statIconWrapper, styles.statIconWrapperBlue]}>
                    <LinearGradient
                      colors={['rgba(125,211,252,0.35)', 'rgba(30,58,138,0.25)']}
                      style={styles.statIconGradient}
                    >
                      <Ionicons name="people" size={26} color={theme.primary} />
                    </LinearGradient>
                  </View>
                  <View style={styles.statTextContainer}>
                    <Text style={styles.statValue}>0</Text>
                    <Text style={styles.statLabel}>Active Valeters</Text>
                  </View>
                </LinearGradient>
              </GlassCard>
            </Animated.View>

            <Animated.View 
              style={[
                { opacity: fadeAnim },
                {
                  transform: [
                    {
                      translateX: fadeAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [20, 0],
                      }),
                    },
                  ],
                },
              ]}
            >
              <GlassCard style={styles.statCard} accountType="business">
                <LinearGradient
                  colors={['rgba(251,191,36,0.20)', 'rgba(245,158,11,0.12)', 'rgba(0,0,0,0.05)']}
                  style={styles.statGradient}
                >
                  <View style={[styles.statIconWrapper, styles.statIconWrapperYellow]}>
                    <LinearGradient
                      colors={['rgba(251,191,36,0.35)', 'rgba(245,158,11,0.25)']}
                      style={styles.statIconGradient}
                    >
                      <Ionicons name="star" size={26} color="#FBBF24" />
                    </LinearGradient>
                  </View>
                  <View style={styles.statTextContainer}>
                    <Text style={styles.statValue}>0.0</Text>
                    <Text style={styles.statLabel}>Avg Rating</Text>
                  </View>
                </LinearGradient>
              </GlassCard>
            </Animated.View>
          </ScrollView>
        </View>

        {/* Charts Section */}
        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Revenue Trends</Text>
          <GlassCard style={styles.emptyCard} accountType="business">
            <View style={styles.emptyContent}>
              <Ionicons name="bar-chart-outline" size={40} color={theme.primary} style={{ opacity: 0.6 }} />
              <Text style={styles.emptyTitle}>No data yet</Text>
              <Text style={styles.emptyText}>
                Revenue charts will appear here as your business grows
              </Text>
            </View>
          </GlassCard>
        </Animated.View>

        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Booking Trends</Text>
          <GlassCard style={styles.emptyCard} accountType="business">
            <View style={styles.emptyContent}>
              <Ionicons name="trending-up-outline" size={40} color={theme.primary} style={{ opacity: 0.6 }} />
              <Text style={styles.emptyTitle}>No data yet</Text>
              <Text style={styles.emptyText}>
                Booking trends will be displayed here once you have bookings
              </Text>
            </View>
          </GlassCard>
        </Animated.View>

        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Valeter Performance</Text>
          <GlassCard style={styles.emptyCard} accountType="business">
            <View style={styles.emptyContent}>
              <Ionicons name="people-outline" size={40} color={theme.primary} style={{ opacity: 0.6 }} />
              <Text style={styles.emptyTitle}>No data yet</Text>
              <Text style={styles.emptyText}>
                Valeter performance metrics will appear here
              </Text>
            </View>
          </GlassCard>
        </Animated.View>

        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Location Breakdown</Text>
          <GlassCard style={styles.emptyCard} accountType="business">
            <View style={styles.emptyContent}>
              <Ionicons name="location-outline" size={24} color={theme.primary} style={{ opacity: 0.6 }} />
              <Text style={styles.emptyTitle}>No data yet</Text>
              <Text style={styles.emptyText}>
                Revenue breakdown by location will be shown here
              </Text>
            </View>
          </GlassCard>
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 24,
  },
  statsSection: {
    marginBottom: 14,
  },
  sectionHeader: {
    marginBottom: 12,
  },
  statsScrollContainer: {
    paddingRight: 20,
    gap: 14,
  },
  statCard: {
    width: Math.min(width * 0.75, 280),
    padding: 0,
    overflow: 'hidden',
    borderRadius: 22,
    marginRight: 14,
  },
  statGradient: {
    padding: 20,
    minHeight: 140,
    justifyContent: 'space-between',
  },
  statIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 16,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(96,217,255,0.3)',
  },
  statIconWrapperGreen: {
    borderColor: 'rgba(16,185,129,0.3)',
  },
  statIconWrapperBlue: {
    borderColor: 'rgba(59,130,246,0.3)',
  },
  statIconWrapperYellow: {
    borderColor: 'rgba(251,191,36,0.3)',
  },
  statIconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  statTextContainer: {
    gap: 6,
  },
  statValue: {
    color: '#F9FAFB',
    fontSize: 32,
    fontWeight: '900',
    letterSpacing: -0.5,
    lineHeight: 36,
  },
  statLabel: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  section: {
    marginBottom: 14,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 12,
    letterSpacing: 0.2,
  },
  emptyCard: {
    ...CARD_SIZES.large,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginTop: 8,
    marginBottom: 8,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
});
