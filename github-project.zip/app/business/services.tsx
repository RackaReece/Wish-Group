import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Switch,
  ActivityIndicator,
  Alert,
  Animated,
  ScrollView,
  LayoutAnimation,
  UIManager,
  Platform,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import LoadingView from '../../src/components/shared/LoadingView';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { getAccountTheme, AccountTheme } from '../../src/constants/accountThemes';
import { getTextColors, getIconColors, getTextStylesWithColors } from '../../src/constants/themeColors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { WASH_DEFINITIONS, getVehicleSizeAdjustmentGBP } from '../../src/pricing/pricingEngine';
import { ICON_TEXT_LAYOUT } from '../../src/constants/cardSizes';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const SKY = colors.SKY;

type FilterTab = 'all' | 'standard' | 'eco';

const TIER_ICONS: Record<string, string> = {
  BRONZE: 'water-outline',
  SILVER: 'sparkles-outline',
  GOLD: 'diamond-outline',
  PLATINUM: 'star-outline',
};

const TIER_DURATION: Record<string, string> = {
  BRONZE: '15–20 min',
  SILVER: '25–30 min',
  GOLD: '45–60 min',
  PLATINUM: '2–3 hrs',
};

interface Service {
  id: string;
  name: string;
  enabled: boolean;
  price?: number;
  priceFrom?: number;
  priceTo?: number;
  description?: string;
  washDefinitionId?: string;
}

function ServiceCard({
  service,
  onToggle,
  theme,
  ts,
}: {
  service: Service;
  onToggle: (id: string) => void;
  theme: AccountTheme;
  ts: ReturnType<typeof getTextStylesWithColors>;
}) {
  const washDef = WASH_DEFINITIONS.find(w => w.id === service.washDefinitionId);
  const isEco = washDef?.isEco ?? false;
  const tier = washDef?.tier ?? 'BRONZE';
  const iconName = isEco ? 'leaf' : (TIER_ICONS[tier] ?? 'car-outline');
  const duration = TIER_DURATION[tier] ?? '';

  const gradientColors = service.enabled
    ? (isEco
        ? ['rgba(16,185,129,0.12)', 'rgba(16,185,129,0.04)', 'rgba(255,255,255,0.02)']
        : ['rgba(125,211,252,0.1)', 'rgba(125,211,252,0.03)', 'rgba(255,255,255,0.02)'])
    : ['rgba(255,255,255,0.06)', 'rgba(255,255,255,0.02)'];
  return (
    <GlassCard style={styles.serviceCard} accountType="business">
      <LinearGradient
        colors={gradientColors as [string, string, ...string[]]}
        style={StyleSheet.absoluteFill}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      />
      <View style={styles.serviceContent}>
        <View style={styles.serviceInfo}>
          <View style={styles.serviceHeader}>
            <View style={[styles.iconCircle, { backgroundColor: getTierGradient(tier, isEco) }]}>
              <Ionicons
                name={iconName as any}
                size={20}
                color={isEco ? '#10B981' : getTierIconColor(tier)}
              />
            </View>
            <View style={styles.serviceTitleBlock}>
              <View style={styles.serviceTitleRow}>
                <Text style={[ts.cardTitle, { flex: 1 }]}>{service.name}</Text>
                <View style={styles.badgeRow}>
                  {isEco ? (
                    <View style={styles.ecoBadge}>
                      <Ionicons name="leaf" size={10} color="#10B981" />
                      <Text style={styles.ecoBadgeText}>Eco</Text>
                    </View>
                  ) : null}
                  <View style={[styles.tierBadge, { backgroundColor: getTierColor(tier) }]}>
                    <Text style={styles.tierBadgeText}>{tier}</Text>
                  </View>
                </View>
              </View>
              {service.description ? (
                <Text style={ts.bodySmall} numberOfLines={2}>
                  {service.description}
                </Text>
              ) : null}
              {duration ? (
                <View style={styles.durationRow}>
                  <Ionicons name="time-outline" size={12} color="rgba(249,250,251,0.55)" />
                  <Text style={ts.captionMedium}>{duration}</Text>
                </View>
              ) : null}
            </View>
          </View>
          <View style={styles.priceRangeContainer}>
            <View style={styles.priceRangeHeader}>
              <Ionicons name="wallet-outline" size={15} color={theme.primary} />
              <Text style={styles.priceRangeLabel}>Price Range</Text>
            </View>
            <View style={styles.priceRangeValues}>
              <View style={styles.priceBox}>
                <Text style={styles.priceFromLabel}>From</Text>
                <Text style={[styles.priceFrom, { color: theme.primary }]}>
                  £{service.priceFrom?.toFixed(2) || '0.00'}
                </Text>
              </View>
              <View style={styles.priceSeparatorLine} />
              <View style={styles.priceBox}>
                <Text style={styles.priceToLabel}>To</Text>
                <Text style={[styles.priceTo, { color: theme.primary }]}>
                  £{service.priceTo?.toFixed(2) || '0.00'}
                </Text>
              </View>
            </View>
            <Text style={styles.priceNote}>
              Small to XL vehicles • Distance & peak time may apply
            </Text>
          </View>
        </View>
        <View style={styles.switchContainer}>
          <Switch
            value={service.enabled}
            onValueChange={() => onToggle(service.id)}
            trackColor={{ false: 'rgba(255,255,255,0.15)', true: theme.primary }}
            thumbColor={service.enabled ? '#FFFFFF' : '#9CA3AF'}
            ios_backgroundColor="rgba(255,255,255,0.15)"
          />
          <Text style={[styles.switchLabel, !service.enabled && styles.switchLabelDisabled]}>
            {service.enabled ? 'Active' : 'Inactive'}
          </Text>
        </View>
      </View>
    </GlassCard>
  );
}

export default function BusinessServices() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const theme = businessTheme ?? getAccountTheme('business', 'light');
  const textColors = getTextColors(theme);
  const iconColors = getIconColors(theme);
  const ts = getTextStylesWithColors(theme);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [services, setServices] = useState<Service[]>([]);
  const [filter, setFilter] = useState<FilterTab>('all');
  const [showPricingInfo, setShowPricingInfo] = useState(false);

  const filteredServices = services.filter(s => {
    const washDef = WASH_DEFINITIONS.find(w => w.id === s.washDefinitionId);
    if (filter === 'standard') return !washDef?.isEco;
    if (filter === 'eco') return washDef?.isEco;
    return true;
  });

  const activeCount = services.filter(s => s.enabled).length;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadServices();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadServices = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      // Convert WASH_DEFINITIONS to Service format for business configuration
      // Only include mobile wash services (not physical location only)
      const washServices: Service[] = WASH_DEFINITIONS
        .filter(wash => wash.isMobile) // Only mobile services
        .map((wash, index) => {
          // Calculate price range: SMALL (base) to XL (base + max adjustment)
          const basePrice = wash.basePriceSmallGBP;
          const smallPrice = basePrice; // SMALL = base price
          const xlPrice = basePrice + getVehicleSizeAdjustmentGBP('XL'); // XL = base + £7
          
          return {
            id: wash.id,
            name: wash.label,
            enabled: true, // Default to enabled
            price: basePrice, // Base price for small vehicle (for compatibility)
            priceFrom: smallPrice,
            priceTo: xlPrice,
            description: wash.description,
            washDefinitionId: wash.id,
          };
        });
      
      // Try to load saved service configurations from database
      // For now, use the wash definitions as default
      setServices(washServices);
    } catch (error) {
      console.error('Error loading services:', error);
      Alert.alert('Error', 'Failed to load services');
    } finally {
      setLoading(false);
    }
  };

  const toggleService = async (serviceId: string) => {
    if (!user?.id) return;
    try {
      await hapticFeedback('light');
      LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
      setServices(prev =>
        prev.map(s => (s.id === serviceId ? { ...s, enabled: !s.enabled } : s))
      );

      // Save to database
      // This would update your organization_services table
      // await supabase.from('organization_services').upsert({...});
    } catch (error) {
      console.error('Error toggling service:', error);
      Alert.alert('Error', 'Failed to update service');
    }
  };

  const selectFilter = (f: FilterTab) => {
    hapticFeedback('light');
    setFilter(f);
  };

  const handleSave = async () => {
    if (!user?.id) return;
    try {
      setSaving(true);
      await hapticFeedback('medium');
      // Save all service configurations
      Alert.alert('Success', 'Services configuration saved successfully');
    } catch (error) {
      console.error('Error saving services:', error);
      Alert.alert('Error', 'Failed to save services configuration');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <AppHeader
        title="Services"
        accountType="business"
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
          },
        ]}
        showsVerticalScrollIndicator={false}
        bounces={true}
        overScrollMode="always"
        decelerationRate="fast"
        removeClippedSubviews={Platform.OS === 'android'}
        keyboardShouldPersistTaps="handled"
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <View style={styles.headerSection}>
            <Text style={[ts.pageTitle, { marginBottom: 8 }]}>Services & Pricing</Text>
            <Text style={ts.pageSubtitle}>
              Manage wash services, set availability, and view pricing ranges
            </Text>
          </View>

          {/* Stats card */}
          <GlassCard style={styles.statsCard} accountType="business">
            <LinearGradient
              colors={['rgba(135,206,235,0.15)', 'rgba(135,206,235,0.05)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.statsRow}>
              <View style={styles.statItem}>
                <Ionicons name="car-outline" size={24} color={theme.primary} />
                <Text style={ts.statValue}>{activeCount}/{services.length}</Text>
                <Text style={ts.statLabel}>Active</Text>
              </View>
              <View style={styles.statDivider} />
              <View style={styles.statItem}>
                <Ionicons name="cash-outline" size={24} color={colors.iconAccent.money} />
                <Text style={ts.statValue}>
                  £{services.length ? Math.min(...services.map(s => s.priceFrom ?? 0)).toFixed(0) : '0'}+
                </Text>
                <Text style={ts.statLabel}>Starting from</Text>
              </View>
            </View>
          </GlassCard>

          {/* Filter tabs */}
          <View style={styles.filterRow}>
            {(['all', 'standard', 'eco'] as const).map((f) => (
              <TouchableOpacity
                key={f}
                style={[styles.filterTab, filter === f && styles.filterTabActive]}
                onPress={() => selectFilter(f)}
                activeOpacity={0.8}
              >
                {f === 'eco' && <Ionicons name="leaf" size={14} color={filter === f ? '#FFF' : '#10B981'} style={{ marginRight: 4 }} />}
                <Text style={[styles.filterTabText, filter === f && styles.filterTabTextActive]}>
                  {f === 'all' ? 'All' : f === 'standard' ? 'Standard' : 'Eco'}
                </Text>
              </TouchableOpacity>
            ))}
          </View>

          {/* Pricing info expandable */}
          <TouchableOpacity
            style={styles.pricingInfoTrigger}
            onPress={() => {
              hapticFeedback('light');
              setShowPricingInfo(!showPricingInfo);
            }}
            activeOpacity={0.8}
          >
            <View style={styles.pricingInfoTriggerInner}>
              <Ionicons name="information-circle-outline" size={20} color={theme.primary} />
              <Text style={styles.pricingInfoTriggerText}>How pricing works</Text>
              <Ionicons
                name={showPricingInfo ? 'chevron-up' : 'chevron-down'}
                size={18}
                color="rgba(249,250,251,0.6)"
              />
            </View>
          </TouchableOpacity>

          {showPricingInfo && (
            <GlassCard style={styles.pricingInfoCard} accountType="business">
              <LinearGradient
                colors={['rgba(59,130,246,0.08)', 'rgba(59,130,246,0.02)']}
                style={StyleSheet.absoluteFill}
              />
              <View style={styles.pricingInfoContent}>
                <Text style={[ts.sectionTitle, { marginBottom: 4 }]}>Pricing breakdown</Text>
                <View style={styles.pricingInfoRow}>
                  <Ionicons name="car-outline" size={16} color={theme.primary} />
                  <Text style={[ts.bodySmall, { flex: 1 }]}>
                    Vehicle size: Small (£0) → Medium (+£2) → Large (+£4) → XL (+£7)
                  </Text>
                </View>
                <View style={styles.pricingInfoRow}>
                  <Ionicons name="navigate-outline" size={16} color={theme.primary} />
                  <Text style={ts.bodySmall}>
                    Distance: First 4 miles included, then £0.50/mile
                  </Text>
                </View>
                <View style={styles.pricingInfoRow}>
                  <Ionicons name="time-outline" size={16} color={theme.primary} />
                  <Text style={[ts.bodySmall, { flex: 1 }]}>
                    Peak: +10% weekday 4–7pm, +15% weekends
                  </Text>
                </View>
              </View>
            </GlassCard>
          )}

          <View style={styles.servicesList}>
            {filteredServices.map((service) => (
              <ServiceCard key={service.id} service={service} onToggle={toggleService} theme={theme} ts={ts} />
            ))}
          </View>

          <TouchableOpacity
            style={[styles.saveButton, saving && styles.saveButtonDisabled]}
            onPress={handleSave}
            disabled={saving}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={[theme.primary, theme.primaryAlt]}
              style={styles.saveButtonGradient}
            >
              {saving ? (
                <ActivityIndicator size="small" color="#FFFFFF" />
              ) : (
                <>
                  <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                  <Text style={styles.saveButtonText}>Save Changes</Text>
                </>
              )}
            </LinearGradient>
          </TouchableOpacity>
        </Animated.View>
      </ScrollView>
    </SafeAreaView>
  );
}

// Helper functions for tier styling
const getTierColor = (tier: string): string => {
  switch (tier) {
    case 'BRONZE':
      return 'rgba(205,127,50,0.25)';
    case 'SILVER':
      return 'rgba(192,192,192,0.25)';
    case 'GOLD':
      return 'rgba(255,215,0,0.2)';
    case 'PLATINUM':
      return 'rgba(229,228,226,0.25)';
    default:
      return 'rgba(255,255,255,0.1)';
  }
};

const getTierGradient = (tier: string, isEco: boolean): string => {
  if (isEco) return 'rgba(16,185,129,0.2)';
  switch (tier) {
    case 'BRONZE':
      return 'rgba(205,127,50,0.25)';
    case 'SILVER':
      return 'rgba(192,192,192,0.2)';
    case 'GOLD':
      return 'rgba(255,215,0,0.22)';
    case 'PLATINUM':
      return 'rgba(229,228,226,0.3)';
    default:
      return 'rgba(135,206,235,0.2)';
  }
};

const getTierIconColor = (tier: string): string => {
  switch (tier) {
    case 'BRONZE':
      return '#CD7F32';
    case 'SILVER':
      return '#C0C0C0';
    case 'GOLD':
      return '#FBBF24';
    case 'PLATINUM':
      return '#E5E4E2';
    default:
      return colors.SKY;
  }
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: isSmallScreen ? 14 : 16,
    flexGrow: 1,
  },
  content: {
    gap: 16,
  },
  headerSection: {
    marginBottom: 12,
  },
  statsCard: {
    marginBottom: 12,
    padding: 14,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
  },
  statItem: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  statDivider: {
    width: 1,
    height: 32,
    backgroundColor: 'rgba(255,255,255,0.12)',
  },
  filterRow: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 16,
  },
  filterTab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  filterTabActive: {
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderColor: 'rgba(135,206,235,0.5)',
  },
  filterTabText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    fontWeight: '600',
  },
  filterTabTextActive: {
    color: '#F9FAFB',
  },
  pricingInfoTrigger: {
    marginBottom: 12,
  },
  pricingInfoTriggerInner: {
    ...ICON_TEXT_LAYOUT.row,
    paddingVertical: 10,
    paddingHorizontal: 14,
  },
  pricingInfoTriggerText: {
    flex: 1,
    color: 'rgba(249,250,251,0.8)',
    fontSize: 14,
    fontWeight: '600',
  },
  pricingInfoCard: {
    marginBottom: 12,
    padding: 12,
  },
  pricingInfoContent: {
    gap: 10,
  },
  pricingInfoRow: {
    ...ICON_TEXT_LAYOUT.row,
  },
  servicesList: {
    gap: 10,
  },
  serviceCard: {
    borderRadius: 18,
    padding: 0,
    marginBottom: 10,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.06)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 5,
  },
  serviceContent: {
    padding: 16,
    gap: 10,
  },
  serviceInfo: {
    flex: 1,
    gap: 8,
  },
  serviceHeader: {
    ...ICON_TEXT_LAYOUT.itemRow,
  },
  iconCircle: {
    width: 40,
    height: 40,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
  },
  serviceTitleBlock: {
    flex: 1,
    gap: 6,
  },
  serviceTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    gap: 8,
  },
  badgeRow: {
    ...ICON_TEXT_LAYOUT.row,
  },
  ecoBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(16,185,129,0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.25)',
  },
  ecoBadgeText: {
    color: '#10B981',
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  tierBadge: {
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  tierBadgeText: {
    color: '#F9FAFB',
    fontSize: 9,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  priceRangeContainer: {
    padding: 12,
    borderRadius: 14,
    backgroundColor: 'rgba(125,211,252,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(125,211,252,0.12)',
    gap: 8,
  },
  priceRangeHeader: {
    ...ICON_TEXT_LAYOUT.row,
  },
  priceRangeLabel: {
    color: 'rgba(249,250,251,0.70)',
    fontSize: 13,
    fontWeight: '600',
  },
  priceRangeValues: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  priceBox: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  priceFromLabel: {
    color: 'rgba(249,250,251,0.60)',
    fontSize: 11,
    fontWeight: '600',
  },
  priceFrom: {
    color: SKY,
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  priceSeparatorLine: {
    width: 1,
    height: 30,
    backgroundColor: 'rgba(255,255,255,0.15)',
  },
  priceToLabel: {
    color: 'rgba(249,250,251,0.60)',
    fontSize: 11,
    fontWeight: '600',
  },
  priceTo: {
    color: SKY,
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  priceNote: {
    color: 'rgba(249,250,251,0.60)',
    fontSize: 11,
    fontWeight: '500',
    textAlign: 'center',
    marginTop: 2,
  },
  durationRow: {
    ...ICON_TEXT_LAYOUT.row,
  },
  switchContainer: {
    alignItems: 'center',
    gap: 8,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.08)',
  },
  switchLabel: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '700',
  },
  switchLabelDisabled: {
    color: 'rgba(249,250,251,0.50)',
  },
  saveButton: {
    marginTop: 10,
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  saveButtonDisabled: {
    opacity: 0.6,
  },
  saveButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 16,
    paddingHorizontal: 24,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
});

