import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import LoadingView from '../../src/components/shared/LoadingView';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors, CARD_BORDER_RADIUS } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { getTextColors, getIconColors, getTextStylesWithColors } from '../../src/constants/themeColors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const SKY = colors.SKY;

interface TimeEntry {
  id: string;
  valeterName: string;
  date: string;
  clockIn: string;
  clockOut?: string;
  totalHours?: number;
  status: 'active' | 'completed';
}

export default function BusinessTimeTracking() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const theme = businessTheme ?? getAccountTheme('business', 'light');
  const textColors = getTextColors(theme);
  const iconColors = getIconColors(theme);
  const ts = getTextStylesWithColors(theme);
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [timeEntries, setTimeEntries] = useState<TimeEntry[]>([]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadTimeEntries();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadTimeEntries = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      // Load time tracking entries from database
      const { data, error } = await supabase
        .from('time_tracking')
        .select('*')
        .eq('organization_id', user.id)
        .order('date', { ascending: false })
        .limit(50);

      if (error) {
        if (error.code === 'PGRST205' || (error.message && error.message.includes('time_tracking'))) {
          console.warn('[TimeTracking] time_tracking table not in schema; showing empty list.');
        } else {
          console.error('Error loading time entries:', error);
        }
        setTimeEntries([]);
        setLoading(false);
        return;
      }

      // Transform database records to TimeEntry format
      const entries: TimeEntry[] = (data || []).map((entry: any) => ({
        id: entry.id,
        valeterName: entry.valeter_name || 'Unknown',
        date: entry.date || new Date().toISOString().split('T')[0],
        clockIn: entry.clock_in || '',
        clockOut: entry.clock_out || undefined,
        totalHours: entry.total_hours || undefined,
        status: entry.status || 'completed',
      }));

      setTimeEntries(entries);
    } catch (error) {
      console.error('Error loading time entries:', error);
      setTimeEntries([]);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <AppHeader
        title="Time"
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[
          styles.scrollContent, 
          { 
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
          }
        ]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <Text style={[ts.sectionTitle, { marginBottom: 4 }]}>Today's Time Entries</Text>
          <Text style={[ts.sectionSubtitle, { marginBottom: SPACING.xl }]}>
            Monitor valeter attendance and working hours
          </Text>

          {timeEntries.length === 0 ? (
            <GlassCard style={styles.emptyCard} accountType="business">
              <View style={styles.emptyContent}>
                <Ionicons name="time-outline" size={40} color="#7DD3FC" style={{ opacity: 0.6 }} />
                <Text style={[ts.emptyTitle, { marginTop: 8, marginBottom: 6 }]}>No time entries yet</Text>
                <Text style={[ts.bodySmall, { textAlign: 'center' }]}>
                  Time tracking data will appear here when valeters clock in
                </Text>
              </View>
            </GlassCard>
          ) : (
            <View style={styles.entriesList}>
              {timeEntries.map((entry) => (
                <GlassCard key={entry.id} style={styles.entryCard} accountType="business">
                  <View style={styles.entryContent}>
                    <View style={styles.entryHeader}>
                      <View style={styles.entryInfo}>
                        <Text style={styles.valeterName}>{entry.valeterName}</Text>
                        <Text style={styles.entryDate}>{entry.date}</Text>
                      </View>
                      <View
                        style={[
                          styles.statusBadge,
                          { backgroundColor: entry.status === 'active' ? 'rgba(16,185,129,0.15)' : 'rgba(135,206,235,0.15)' },
                        ]}
                      >
                        <Text
                          style={[
                            styles.statusText,
                            { color: entry.status === 'active' ? '#10B981' : '#7DD3FC' },
                          ]}
                        >
                          {entry.status === 'active' ? 'Active' : 'Completed'}
                        </Text>
                      </View>
                    </View>
                    <View style={styles.timeRow}>
                      <View style={styles.timeItem}>
                        <Ionicons name="log-in-outline" size={16} color="#7DD3FC" />
                        <Text style={styles.timeLabel}>Clock In</Text>
                        <Text style={styles.timeValue}>{entry.clockIn}</Text>
                      </View>
                      {entry.clockOut && (
                        <View style={styles.timeItem}>
                          <Ionicons name="log-out-outline" size={16} color="#7DD3FC" />
                          <Text style={styles.timeLabel}>Clock Out</Text>
                          <Text style={styles.timeValue}>{entry.clockOut}</Text>
                        </View>
                      )}
                      {entry.totalHours && (
                        <View style={styles.timeItem}>
                          <Ionicons name="time" size={16} color="#7DD3FC" />
                          <Text style={styles.timeLabel}>Total</Text>
                          <Text style={styles.timeValue}>{entry.totalHours}h</Text>
                        </View>
                      )}
                    </View>
                  </View>
                </GlassCard>
              ))}
            </View>
          )}
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  loadingText: {
    color: '#7DD3FC',
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: isSmallScreen ? 14 : 16,
  },
  content: {
    gap: SPACING.lg,
  },
  entriesList: {
    gap: SPACING.md,
  },
  entryCard: {
    ...CARD_SIZES.medium,
    borderRadius: CARD_BORDER_RADIUS,
    overflow: 'hidden',
  },
  entryContent: {
    padding: CARD_SIZES.medium.padding,
    gap: SPACING.md,
  },
  entryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  entryInfo: {
    flex: 1,
    gap: 2,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  entryDate: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
  },
  statusBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusText: {
    fontSize: 11,
    fontWeight: '600',
  },
  timeRow: {
    flexDirection: 'row',
    gap: SPACING.lg,
    paddingTop: SPACING.sm,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  timeItem: {
    flex: 1,
    gap: 4,
  },
  timeLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 11,
  },
  timeValue: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  emptyCard: {
    ...CARD_SIZES.large,
    borderRadius: CARD_BORDER_RADIUS,
    overflow: 'hidden',
  },
  emptyContent: {
    alignItems: 'center',
    padding: CARD_SIZES.large.padding,
  },
});

