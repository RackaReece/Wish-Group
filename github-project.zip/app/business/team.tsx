import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  TextInput,
  Alert,
  Platform,
  ScrollView,
  RefreshControl,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import LoadingView from '../../src/components/shared/LoadingView';
import GlassCard from '../../src/components/booking/GlassCard';
import StatusDot from '../../src/components/shared/StatusDot';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { getTextColors, getIconColors } from '../../src/constants/themeColors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;

interface Valeter {
  id: string;
  name: string;
  email: string;
  phone?: string;
  is_online: boolean;
  total_jobs?: number;
  rating?: number;
  location_assignment?: string;
  role?: string;
  clocked_in?: boolean;
  created_at: string;
}

type ProfileRow = {
  id: string;
  name: string | null;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  created_at: string | null;
  user_type: string | null;
  organization_id: string | null;
};

type PresenceRow = {
  user_id: string;
  is_online: boolean | null;
};

type BookingStatRow = {
  id: string;
  rating: number | null;
};

export default function BusinessTeam() {
  const { user } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const theme = businessTheme ?? getAccountTheme('business', 'light');
  const textColors = getTextColors(theme);
  const iconColors = getIconColors(theme);
  const placeholderColor = textColors.placeholder;
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [valeters, setValeters] = useState<Valeter[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterLocation, setFilterLocation] = useState<string | null>(null);

  const [removingId, setRemovingId] = useState<string | null>(null);

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (isOrgUser && organizationId) {
      loadValeters();
    } else {
      setValeters([]);
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, user?.userType, organizationId]);

  const normalizeName = (v: ProfileRow) =>
    (v.full_name ?? '').trim() || (v.name ?? '').trim() || 'Valeter';

  const normalizeEmail = (v: ProfileRow) => (v.email ?? '').trim() || 'no-email@unknown';

  const mapProfileToValeter = async (v: ProfileRow): Promise<Valeter> => {
    const displayName = normalizeName(v);
    const email = normalizeEmail(v);

    const { data: presenceData } = await supabase
      .from('valeter_presence')
      .select('user_id, is_online')
      .eq('user_id', v.id)
      .maybeSingle();

    const presence = (presenceData as PresenceRow | null) ?? null;

    // Optimized: Limit to recent bookings for faster loading
    const { data: statsData } = await supabase
      .from('bookings')
      .select('id, rating')
      .eq('valeter_id', v.id)
      .eq('status', 'completed')
      .order('created_at', { ascending: false })
      .limit(50);

    const stats = (statsData || []) as BookingStatRow[];
    const totalJobs = stats.length;
    const avgRating =
      totalJobs > 0 ? stats.reduce((acc, s) => acc + (s.rating || 0), 0) / totalJobs : 0;

    return {
      id: v.id,
      name: displayName,
      email,
      phone: (v.phone ?? '').trim() || undefined,
      created_at: v.created_at ?? new Date().toISOString(),
      is_online: !!presence?.is_online,
      total_jobs: totalJobs,
      rating: avgRating,
      location_assignment: undefined,
      role: 'valeter',
      clocked_in: false,
    };
  };

  const loadValeters = async () => {
    if (!isOrgUser || !organizationId) return;

    try {
      setLoading(true);

      const { data, error } = await supabase
        .from('profiles')
        .select('id, name, full_name, email, phone, created_at, user_type, organization_id')
        .eq('organization_id', organizationId)
        .ilike('user_type', 'valeter%')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const rows = (data || []) as ProfileRow[];
      const valeterData: Valeter[] = await Promise.all(rows.map(mapProfileToValeter));
      setValeters(valeterData);
    } catch (error) {
      console.error('Error loading valeters:', error);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await loadValeters();
    setRefreshing(false);
  };

  const navigateToInvite = async () => {
    await hapticFeedback('light');
    router.push('/business/team/invite');
  };

  const removeValeterFromOrg = async (valeter: Valeter) => {
    if (!organizationId) return;

    Alert.alert(
      'Remove from team?',
      `${valeter.name}\nThis will unassign them from your business.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            try {
              setRemovingId(valeter.id);
              await hapticFeedback('light');

              const { error } = await supabase
                .from('profiles')
                .update({ organization_id: null })
                .eq('id', valeter.id);

              if (error) throw error;

              await hapticFeedback('success');

              await loadValeters();
            } catch (e) {
              console.error('Error removing valeter:', e);
              await hapticFeedback('error');
              Alert.alert('Could not remove', 'Something went wrong. Please try again.');
            } finally {
              setRemovingId(null);
            }
          },
        },
      ],
      { cancelable: true }
    );
  };

  const filteredValeters = valeters.filter((valeter) => {
    const q = searchQuery.trim().toLowerCase();
    const matchesSearch =
      !q || valeter.name.toLowerCase().includes(q) || valeter.email.toLowerCase().includes(q);

    const matchesLocation = !filterLocation || valeter.location_assignment === filterLocation;

    return matchesSearch && matchesLocation;
  });

  if (loading) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  if (!isOrgUser || !organizationId) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Members" accountType="business" />
        <View style={styles.loadingContainer}>
          <Ionicons name="alert-circle-outline" size={42} color={iconColors.primary} style={{ opacity: 0.85 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320, color: textColors.primary }]}>
            This business account isn’t linked to an organization yet.
            {'\n'}Log out and back in, or contact support.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <AppHeader
        title="Members"
        subtitle="Manage your valeters"
        accountType="business"
        rightAction={
          <TouchableOpacity onPress={navigateToInvite} style={styles.inviteButton}>
            <Ionicons name="person-add" size={22} color={iconColors.primary} />
          </TouchableOpacity>
        }
        scrollY={scrollY}
        enableScrollAnimation={true}
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
          useNativeDriver: false,
        })}
        scrollEventThrottle={16}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />
        }
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 16,
          },
        ]}
      >
        {/* Search */}
        <View style={styles.searchWrap}>
          <BlurView intensity={40} tint="dark" style={styles.searchBlur}>
            <Ionicons name="search" size={18} color={SKY} style={styles.searchIcon} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search by name or email..."
              placeholderTextColor={placeholderColor}
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </BlurView>
        </View>

        {/* Quick actions */}
        <View style={styles.quickActions}>
          <TouchableOpacity onPress={navigateToInvite} style={styles.quickActionButton} activeOpacity={0.85}>
            <GlassCard style={styles.quickActionCard} accountType="business">
              <LinearGradient colors={[`${SKY}30`, `${SKY}12`]} style={StyleSheet.absoluteFill} />
              <View style={styles.quickActionContent}>
                <View style={styles.quickActionIconWrap}>
                  <Ionicons name="person-add" size={22} color={SKY} />
                </View>
                <Text style={styles.quickActionText}>Add Valeter</Text>
              </View>
            </GlassCard>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={async () => { await hapticFeedback('light'); router.push('/business/team/requests'); }}
            style={styles.quickActionButton}
            activeOpacity={0.85}
          >
            <GlassCard style={styles.quickActionCard} accountType="business">
              <LinearGradient colors={['rgba(245,158,11,0.2)', 'rgba(245,158,11,0.08)']} style={StyleSheet.absoluteFill} />
              <View style={styles.quickActionContent}>
                <View style={[styles.quickActionIconWrap, { backgroundColor: 'rgba(245,158,11,0.25)' }]}>
                  <Ionicons name="mail-unread-outline" size={22} color="#F59E0B" />
                </View>
                <Text style={styles.quickActionText}>Requests</Text>
              </View>
            </GlassCard>
          </TouchableOpacity>
        </View>

        {/* Stats */}
        <View style={styles.statsRow}>
          <GlassCard style={styles.statCard} accountType="business">
            <LinearGradient colors={[`${SKY}25`, `${SKY}10`]} style={StyleSheet.absoluteFill} />
            <View style={styles.statIconWrap}>
              <Ionicons name="people" size={20} color={SKY} />
            </View>
            <Text style={styles.statValue}>{valeters.length}</Text>
            <Text style={styles.statLabel}>Total</Text>
          </GlassCard>
          <GlassCard style={styles.statCard} accountType="business">
            <LinearGradient colors={['rgba(16,185,129,0.25)', 'rgba(16,185,129,0.1)']} style={StyleSheet.absoluteFill} />
            <View style={[styles.statIconWrap, { backgroundColor: 'rgba(16,185,129,0.25)' }]}>
              <Ionicons name="radio-button-on" size={18} color="#10B981" />
            </View>
            <Text style={styles.statValue}>{valeters.filter((v) => v.is_online).length}</Text>
            <Text style={styles.statLabel}>Online</Text>
          </GlassCard>
          <GlassCard style={styles.statCard} accountType="business">
            <LinearGradient colors={['rgba(245,158,11,0.2)', 'rgba(245,158,11,0.08)']} style={StyleSheet.absoluteFill} />
            <View style={[styles.statIconWrap, { backgroundColor: 'rgba(245,158,11,0.25)' }]}>
              <Ionicons name="time" size={18} color="#F59E0B" />
            </View>
            <Text style={styles.statValue}>{valeters.filter((v) => v.clocked_in).length}</Text>
            <Text style={styles.statLabel}>Clocked In</Text>
          </GlassCard>
        </View>

        {filteredValeters.length === 0 ? (
          <GlassCard style={styles.emptyCard} accountType="business">
            <LinearGradient colors={[`${SKY}08`, 'transparent']} style={StyleSheet.absoluteFill} />
            <View style={styles.emptyContent}>
              <View style={styles.emptyIconWrap}>
                <Ionicons name="people-outline" size={52} color={SKY} style={{ opacity: 0.6 }} />
              </View>
              <Text style={styles.emptyTitle}>
                {searchQuery ? 'No valeters found' : 'No team members yet'}
              </Text>
              <Text style={styles.emptyText}>
                {searchQuery ? 'Try a different search term' : 'Invite valeters to join your business and manage them here.'}
              </Text>
              {!searchQuery && (
                <>
                  <TouchableOpacity onPress={navigateToInvite} style={styles.primaryCta} activeOpacity={0.85}>
                    <Ionicons name="person-add" size={20} color="#FFFFFF" />
                    <Text style={styles.primaryCtaText}>Add Valeter</Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={async () => { await hapticFeedback('light'); router.push('/business/team/requests'); }} style={styles.secondaryCta} activeOpacity={0.85}>
                    <Text style={styles.secondaryCtaText}>View requests</Text>
                    <Ionicons name="chevron-forward" size={16} color={SKY} />
                  </TouchableOpacity>
                </>
              )}
            </View>
          </GlassCard>
        ) : (
          <View style={styles.teamSection}>
            <View style={styles.sectionHeader}>
              <View style={styles.sectionHeaderIcon}>
                <Ionicons name="people" size={20} color={SKY} />
              </View>
              <Text style={styles.sectionTitle}>Members</Text>
              <View style={styles.sectionBadge}>
                <Text style={styles.sectionBadgeText}>{filteredValeters.length}</Text>
              </View>
            </View>

            <View style={styles.valeterList}>
              {filteredValeters.map((valeter, index) => (
                <Animated.View
                  key={valeter.id}
                  style={[styles.valeterCardWrap, { opacity: fadeAnim }]}
                >
                  <GlassCard style={styles.valeterCard} accountType="business">
                    <LinearGradient
                      colors={
                        valeter.is_online
                          ? ['rgba(16,185,129,0.12)', 'rgba(16,185,129,0.05)']
                          : valeter.clocked_in
                            ? ['rgba(245,158,11,0.12)', 'rgba(245,158,11,0.05)']
                            : ['rgba(135,206,235,0.08)', 'rgba(135,206,235,0.03)']
                      }
                      style={StyleSheet.absoluteFill}
                    />
                    <View style={styles.valeterHeader}>
                      <View style={[styles.valeterAvatar, valeter.is_online && styles.valeterAvatarOnline]}>
                        <Text style={styles.valeterInitial}>{(valeter.name || 'V').charAt(0).toUpperCase()}</Text>
                      </View>
                      <View style={styles.valeterInfo}>
                        <View style={styles.valeterNameRow}>
                          <Text style={styles.valeterName} numberOfLines={1}>{valeter.name}</Text>
                          {valeter.role && (
                            <View style={styles.roleBadge}>
                              <Text style={styles.roleText}>{valeter.role}</Text>
                            </View>
                          )}
                        </View>
                        <Text style={styles.valeterEmail} numberOfLines={1} ellipsizeMode="tail">{valeter.email}</Text>
                        {valeter.phone ? <Text style={styles.valeterPhone}>{valeter.phone}</Text> : null}
                        <View style={styles.statusRow}>
                          <StatusDot
                            status={valeter.is_online ? 'available' : valeter.clocked_in ? 'busy' : 'offline'}
                            size={10}
                            pulseOnChange={true}
                          />
                          <Text style={styles.statusText}>
                            {valeter.is_online ? 'Online' : valeter.clocked_in ? 'Clocked in' : 'Offline'}
                          </Text>
                        </View>
                      </View>
                      <TouchableOpacity
                        onPress={() => removeValeterFromOrg(valeter)}
                        disabled={removingId === valeter.id}
                        style={[styles.removeBtn, removingId === valeter.id && { opacity: 0.6 }]}
                        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                      >
                        {removingId === valeter.id ? (
                          <ActivityIndicator size="small" color="#FFFFFF" />
                        ) : (
                          <Ionicons name="trash-outline" size={18} color="#FFFFFF" />
                        )}
                      </TouchableOpacity>
                    </View>
                    <View style={styles.valeterStats}>
                      <View style={styles.statItem}>
                        <Ionicons name="car-outline" size={14} color={SKY} />
                        <Text style={styles.statItemText}>{valeter.total_jobs ?? 0} jobs</Text>
                      </View>
                      {valeter.rating != null && valeter.rating > 0 && (
                        <View style={styles.statItem}>
                          <Ionicons name="star" size={14} color="#F59E0B" />
                          <Text style={styles.statItemText}>{valeter.rating.toFixed(1)}</Text>
                        </View>
                      )}
                      <View style={styles.statItem}>
                        <Ionicons name={valeter.clocked_in ? 'time' : 'time-outline'} size={14} color={SKY} />
                        <Text style={styles.statItemText}>{valeter.clocked_in ? 'Clocked in' : '—'}</Text>
                      </View>
                    </View>
                  </GlassCard>
                </Animated.View>
              ))}
            </View>
          </View>
        )}
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 24,
  },
  loadingText: { color: SKY, fontSize: 14 },

  inviteButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },

  scrollView: { flex: 1 },
  scrollContent: { padding: 16 },

  searchWrap: { marginBottom: 14 },
  searchBlur: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(255,255,255,0.06)',
    paddingHorizontal: 14,
    paddingVertical: 12,
  },
  searchIcon: { marginRight: 10 },
  searchInput: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '500',
    paddingVertical: 4,
  },

  quickActions: { flexDirection: 'row', gap: 10, marginBottom: 14 },
  quickActionButton: { flex: 1 },
  quickActionCard: { position: 'relative', overflow: 'hidden', borderRadius: 16, borderWidth: 1.5, borderColor: 'rgba(135,206,235,0.2)' },
  quickActionContent: { padding: 16, alignItems: 'center', gap: 10 },
  quickActionIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  quickActionText: { color: '#F9FAFB', fontSize: 13, fontWeight: '700' },

  statsRow: { flexDirection: 'row', gap: 10, marginBottom: 16 },
  statCard: {
    flex: 1,
    padding: 14,
    borderRadius: 16,
    alignItems: 'center',
    position: 'relative',
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.15)',
  },
  statIconWrap: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  statValue: { color: '#F9FAFB', fontSize: 22, fontWeight: '800', marginBottom: 2 },
  statLabel: { color: 'rgba(249,250,251,0.65)', fontSize: 11, fontWeight: '600' },

  teamSection: { marginTop: 4 },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    gap: 10,
  },
  sectionHeaderIcon: {
    width: 38,
    height: 38,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '800', flex: 1 },
  sectionBadge: {
    backgroundColor: 'rgba(135,206,235,0.3)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 10,
  },
  sectionBadgeText: { color: '#F9FAFB', fontSize: 13, fontWeight: '800' },
  valeterList: { gap: 10 },
  valeterCardWrap: { width: '100%' },
  valeterCard: {
    padding: 16,
    borderRadius: 18,
    position: 'relative',
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  valeterHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: 14, marginBottom: 10 },
  valeterAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.35)',
  },
  valeterAvatarOnline: { borderColor: 'rgba(16,185,129,0.5)', backgroundColor: 'rgba(16,185,129,0.2)' },
  valeterInitial: { color: SKY, fontSize: 20, fontWeight: '800' },
  valeterInfo: { flex: 1, minWidth: 0 },
  valeterNameRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4, flexWrap: 'wrap' },
  valeterName: { color: '#F9FAFB', fontSize: 17, fontWeight: '800', flex: 1 },
  roleBadge: {
    backgroundColor: 'rgba(135,206,235,0.2)',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  roleText: { color: SKY, fontSize: 10, fontWeight: '700', textTransform: 'uppercase' },
  valeterEmail: { color: 'rgba(249,250,251,0.75)', fontSize: 13, marginBottom: 2 },
  valeterPhone: { color: 'rgba(249,250,251,0.6)', fontSize: 12, marginBottom: 4 },
  statusRow: { flexDirection: 'row', alignItems: 'center', gap: 6, marginTop: 4 },
  statusText: { color: 'rgba(249,250,251,0.65)', fontSize: 12, fontWeight: '600' },
  removeBtn: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(239,68,68,0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(220,38,38,0.5)',
  },
  valeterStats: {
    flexDirection: 'row',
    gap: 16,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.12)',
  },
  statItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  statItemText: { color: 'rgba(249,250,251,0.75)', fontSize: 13, fontWeight: '600' },

  emptyCard: { padding: 32, position: 'relative', overflow: 'hidden', borderRadius: 20, borderWidth: 1.5, borderColor: 'rgba(135,206,235,0.2)' },
  emptyContent: { alignItems: 'center' },
  emptyIconWrap: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  emptyTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: '800', marginBottom: 8, textAlign: 'center' },
  emptyText: { color: 'rgba(249,250,251,0.7)', fontSize: 15, textAlign: 'center', lineHeight: 22, marginBottom: 14 },
  primaryCta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    backgroundColor: SKY,
    paddingHorizontal: 20,
    paddingVertical: 14,
    borderRadius: 14,
    marginBottom: 12,
  },
  primaryCtaText: { color: '#FFFFFF', fontSize: 15, fontWeight: '800' },
  secondaryCta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 10,
    paddingHorizontal: 16,
  },
  secondaryCtaText: { color: SKY, fontSize: 14, fontWeight: '700' },
});
