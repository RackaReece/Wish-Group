import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Image,
  Linking,
  Modal,
  Pressable,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Region } from 'react-native-maps';
import { HUB_MAP_ICON, CUSTOMER_MAP_ICON } from '../../../src/constants/mapIcons';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import ProBookingCard from '../../../src/components/booking/ProBookingCard';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import LoadingView from '../../../src/components/shared/LoadingView';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { colors } from '../../../src/constants/colors';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import { getIconColors } from '../../../src/constants/themeColors';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import { DARK_MAP_STYLE } from '../../../src/constants/mapStyles';

const SKY = colors.SKY;
const BG = colors.BG;
const { width, height } = Dimensions.get('window');

const CONFETTI_COLORS = ['#FFD700', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8'];
const CONFETTI_COUNT = 50;
const CLOSE_ZOOM_DELTA = 0.01;

type BookingStatus =
  | 'pending_business_acceptance'
  | 'pending_valeter_acceptance'
  | 'pending_payment'
  | 'confirmed'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export default function BusinessBookingTracking() {
  const params = useLocalSearchParams<{ bookingId: string }>();
  const bookingId = params.bookingId;
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { theme: businessTheme } = useAccountTheme();
  const theme = businessTheme ?? getAccountTheme('business', 'light');
  const isDarkMap = theme.mode === 'dark';
  const iconColors = getIconColors(theme);

  const [booking, setBooking] = useState<any | null>(null);
  const [hubLocation, setHubLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [status, setStatus] = useState<BookingStatus>('confirmed');
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: CLOSE_ZOOM_DELTA,
    longitudeDelta: CLOSE_ZOOM_DELTA,
  });
  const [customerPhone, setCustomerPhone] = useState<string | null>(null);
  const [showCompletedOverlay, setShowCompletedOverlay] = useState(false);
  const [infoModalVisible, setInfoModalVisible] = useState(false);
  const [cancelling, setCancelling] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const overlayScale = useRef(new Animated.Value(0.8)).current;
  const overlayOpacity = useRef(new Animated.Value(0)).current;
  const confettiParticles = useRef(
    Array.from({ length: CONFETTI_COUNT }, () => ({
      x: Math.random() * width,
      delay: Math.random() * 400,
      duration: 2000 + Math.random() * 1500,
      color: CONFETTI_COLORS[Math.floor(Math.random() * CONFETTI_COLORS.length)],
      size: 6 + Math.random() * 8,
      startY: -20,
    }))
  ).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, [markerPulse]);

  useEffect(() => {
    if (!bookingId) return;
    loadBooking();
  }, [bookingId]);

  useEffect(() => {
    if (!bookingId) return;
    const channel = supabase
      .channel(`booking-${bookingId}`)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `id=eq.${bookingId}` }, (payload) => {
        const next = (payload.new as any)?.status;
        if (next) setStatus(next as BookingStatus);
      })
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [bookingId]);

  const loadBooking = async () => {
    if (!bookingId) return;
    try {
      const { data: bookingData, error: bookingError } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', bookingId)
        .single();

      if (bookingError || !bookingData) {
        Alert.alert('Error', 'Booking not found');
        router.back();
        return;
      }

      setBooking(bookingData);
      setStatus((bookingData.status as BookingStatus) || 'confirmed');

      const locLat = bookingData.location_lat ?? bookingData.customer_lat;
      const locLng = bookingData.location_lng ?? bookingData.customer_lng;
      if (locLat != null && locLng != null) {
        setRegion({
          latitude: Number(locLat),
          longitude: Number(locLng),
          latitudeDelta: CLOSE_ZOOM_DELTA,
          longitudeDelta: CLOSE_ZOOM_DELTA,
        });
      }

      if (bookingData.user_id) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('phone')
          .eq('id', bookingData.user_id)
          .maybeSingle();
        setCustomerPhone((profile as any)?.phone ?? null);
      }

      const orgId = (bookingData as any).organization_id ?? user?.organizationId ?? null;
      if (orgId) {
        const { data: locData } = await supabase
          .from('car_wash_locations')
          .select('latitude, longitude')
          .eq('organization_id', orgId)
          .not('latitude', 'is', null)
          .limit(1)
          .maybeSingle();
        if (locData && (locData as any).latitude != null) {
          setHubLocation({
            lat: Number((locData as any).latitude),
            lng: Number((locData as any).longitude),
          });
        }
      }
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Failed to load booking');
      router.back();
    }
  };

  const getStatusProgress = (): number => {
    switch (status) {
      case 'pending_business_acceptance':
      case 'pending_valeter_acceptance':
      case 'pending_payment':
        return 10;
      case 'confirmed':
        return 25;
      case 'en_route':
        return 50;
      case 'arrived':
        return 70;
      case 'in_progress':
        return 90;
      case 'completed':
        return 100;
      case 'cancelled':
        return 0;
      default:
        return 20;
    }
  };

  const getStatusMessage = (): string => {
    switch (status) {
      case 'pending_payment':
        return 'Waiting for payment';
      case 'confirmed':
        return 'Confirmed – customer may be on the way';
      case 'en_route':
        return 'Customer en route';
      case 'arrived':
        return 'Customer arrived – wash can start';
      case 'in_progress':
        return 'Wash in progress';
      case 'completed':
        return 'Wash completed';
      case 'cancelled':
        return 'Booking cancelled';
      default:
        return 'Tracking booking';
    }
  };

  const chatCallLocked = status === 'pending_payment';

  const handleChat = () => {
    if (chatCallLocked) {
      hapticFeedback('light');
      Alert.alert('Unlocks after payment', 'Chat becomes available once the customer has paid.');
      return;
    }
    hapticFeedback('light');
    if (!booking?.user_id) {
      Alert.alert('No customer', 'This booking has no customer linked to open chat.');
      return;
    }
    router.push({
      pathname: '/chat-screen',
      params: {
        recipientId: booking.user_id,
        recipientName: booking.customer_name ?? 'Customer',
        recipientType: 'customer',
        phone: customerPhone ?? '',
        bookingId: bookingId ?? '',
        bookingStatus: status ?? '',
      },
    });
  };

  const canCancel = status !== 'completed' && status !== 'cancelled' && status !== 'pending_payment';
  const handleCancel = () => {
    hapticFeedback('light');
    if (!canCancel) return;
    Alert.alert(
      'Cancel booking',
      'Cancel this booking? The customer will be notified.',
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, cancel',
          style: 'destructive',
          onPress: async () => {
            if (!bookingId) return;
            setCancelling(true);
            const { error } = await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', bookingId);
            if (error) Alert.alert('Error', error.message);
            else {
              setStatus('cancelled');
              Alert.alert('Cancelled', 'Booking cancelled.');
            }
            setCancelling(false);
          },
        },
      ]
    );
  };

  const updateStatus = async (newStatus: BookingStatus) => {
    if (!bookingId) return;
    await hapticFeedback('medium');
    try {
      const { error } = await supabase.from('bookings').update({ status: newStatus }).eq('id', bookingId);
      if (error) throw error;
      setStatus(newStatus);
      if (newStatus === 'completed') setShowCompletedOverlay(true);
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Failed to update status');
    }
  };

  useEffect(() => {
    if (!showCompletedOverlay) return;
    overlayScale.setValue(0.8);
    overlayOpacity.setValue(0);
    Animated.parallel([
      Animated.timing(overlayOpacity, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.spring(overlayScale, { toValue: 1, tension: 60, friction: 8, useNativeDriver: true }),
    ]).start();
  }, [showCompletedOverlay]);

  const fallAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!showCompletedOverlay) return;
    fallAnim.setValue(0);
    Animated.timing(fallAnim, { toValue: 1, duration: 3200, useNativeDriver: true }).start();
  }, [showCompletedOverlay]);

  const dismissCompletedOverlay = () => {
    setShowCompletedOverlay(false);
    router.back();
  };

  const getNextAction = (): { label: string; action: () => void } | null => {
    switch (status) {
      case 'confirmed':
        return { label: 'Mark customer arrived', action: () => updateStatus('arrived') };
      case 'arrived':
        return { label: 'Start wash', action: () => updateStatus('in_progress') };
      case 'in_progress':
        return { label: 'Mark complete', action: () => updateStatus('completed') };
      default:
        return null;
    }
  };

  const nextAction = getNextAction();

  const customerCoords = useMemo(() => {
    if (!booking) return null;
    const lat = booking.location_lat ?? booking.customer_lat;
    const lng = booking.location_lng ?? booking.customer_lng;
    if (lat == null || lng == null) return null;
    return { latitude: Number(lat), longitude: Number(lng) };
  }, [booking]);

  if (!bookingId) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: theme.background[0] }]}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <View style={styles.centerContent}>
          <Text style={styles.errorText}>No booking selected</Text>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={styles.backBtnText}>Go back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (!booking) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: theme.background[0] }]}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Tracking" accountType="business" />
        <LoadingView style={styles.loadingWrap} />
      </SafeAreaView>
    );
  }

  const mapRegion: Region = customerCoords
    ? { ...region, latitude: customerCoords.latitude, longitude: customerCoords.longitude }
    : region;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {/* Completed overlay with confetti */}
      <Modal visible={showCompletedOverlay} transparent animationType="none">
        <Pressable style={styles.overlayBackdrop} onPress={dismissCompletedOverlay}>
          <View style={StyleSheet.absoluteFill} pointerEvents="none">
            {confettiParticles.map((p, i) => (
              <Animated.View
                key={i}
                pointerEvents="none"
                style={[
                  styles.confettiPiece,
                  {
                    left: p.x,
                    top: p.startY,
                    width: p.size,
                    height: p.size * 1.2,
                    backgroundColor: p.color,
                    borderRadius: p.size > 10 ? 2 : 1,
                  },
                  {
                    transform: [
                      {
                        translateY: fallAnim.interpolate({
                          inputRange: [0, Math.max(0.02, i / CONFETTI_COUNT), 1],
                          outputRange: [0, 0, height + 60],
                        }),
                      },
                    ],
                  },
                ]}
              />
            ))}
          </View>
          <Pressable style={styles.overlayContent} onPress={(e) => e.stopPropagation()}>
            <Animated.View style={[styles.boomCard, { opacity: overlayOpacity, transform: [{ scale: overlayScale }] }]}>
              <LinearGradient colors={['rgba(56,189,248,0.35)', 'rgba(15,23,42,0.98)']} style={styles.boomCardGradient}>
                <Text style={styles.boomTitle}>Boom!</Text>
                <Text style={styles.boomSubtitle}>Onto the next customer!</Text>
                <TouchableOpacity style={styles.boomButton} onPress={dismissCompletedOverlay} activeOpacity={0.85}>
                  <LinearGradient colors={[SKY, theme.primary]} style={styles.boomButtonGradient}>
                    <Text style={styles.boomButtonText}>Back to bookings</Text>
                    <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                  </LinearGradient>
                </TouchableOpacity>
              </LinearGradient>
            </Animated.View>
          </Pressable>
        </Pressable>
      </Modal>

      <View style={styles.mapWrapper}>
        <MapView
          style={styles.map}
          region={mapRegion}
          mapType="standard"
          customMapStyle={isDarkMap ? DARK_MAP_STYLE : undefined}
          showsUserLocation={false}
          mapPadding={{ top: 0, bottom: 160, left: 0, right: 0 }}
        >
          {hubLocation && (
            <Marker coordinate={{ latitude: hubLocation.lat, longitude: hubLocation.lng }} anchor={{ x: 0.5, y: 0.5 }} tracksViewChanges={false}>
              <View style={styles.hubMarker}>
                <Image source={HUB_MAP_ICON} style={styles.hubMarkerImage} resizeMode="contain" />
              </View>
            </Marker>
          )}
          {customerCoords && (
            <Marker coordinate={customerCoords} anchor={{ x: 0.5, y: 0.5 }} tracksViewChanges={false}>
              <Animated.View style={[styles.customerMarker, { transform: [{ scale: markerPulse }] }]}>
                <Image source={CUSTOMER_MAP_ICON} style={styles.carMarkerImage} resizeMode="contain" />
              </Animated.View>
            </Marker>
          )}
        </MapView>

        <View style={styles.headerOverlay}>
          <AppHeader title="Tracking" accountType="business" />
        </View>

        {/* Chat & Cancel floating on map */}
        {booking && (
          <View style={[styles.mapActionButtons, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + 16 }]} pointerEvents="box-none">
            <TouchableOpacity onPress={handleChat} style={styles.mapActionBtn} activeOpacity={0.85}>
              <View style={[styles.mapActionBtnInner, chatCallLocked && styles.mapActionBtnInnerDisabled]}>
                <Ionicons name="chatbubble-ellipses-outline" size={24} color={chatCallLocked ? '#64748B' : SKY} />
              </View>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={handleCancel}
              disabled={!canCancel || cancelling}
              style={[styles.mapActionBtn, (!canCancel || cancelling) && styles.mapActionBtnDisabled]}
              activeOpacity={0.85}
            >
              <View style={[styles.mapActionBtnInner, (!canCancel || cancelling) && styles.mapActionBtnInnerDisabled]}>
                {cancelling ? (
                  <ActivityIndicator size="small" color="#EF4444" />
                ) : (
                  <Ionicons name="close-circle-outline" size={24} color={canCancel ? '#EF4444' : '#64748B'} />
                )}
              </View>
            </TouchableOpacity>
          </View>
        )}

        <Animated.View
          style={[
            styles.cardContainer,
            {
              opacity: fadeAnim,
              bottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
            },
          ]}
        >
          <ProBookingCard stripColor={SKY} intensity={60} style={styles.trackingCard}>
            <LinearGradient colors={['rgba(125,211,252,0.35)', 'rgba(30,58,138,0.4)']} style={styles.trackingCardGradient}>
              <View style={styles.cardTopRow}>
                <View style={styles.trackingHeaderCompact}>
                  <StatusBadge status={status as any} size="small" />
                  <Text style={styles.statusMessageCompact} numberOfLines={1}>{getStatusMessage()}</Text>
                </View>
                <TouchableOpacity onPress={() => { hapticFeedback('light'); setInfoModalVisible(true); }} style={styles.infoBox} activeOpacity={0.8}>
                  <View style={styles.infoBoxInner}>
                    <Ionicons name="information-circle-outline" size={22} color={SKY} />
                  </View>
                </TouchableOpacity>
              </View>

              <View style={styles.ringRow}>
                <AnimatedProgress
                  progress={getStatusProgress()}
                  size={72}
                  strokeWidth={6}
                  color={SKY}
                  colorCycle={[SKY, '#10B981', '#8B5CF6', '#F59E0B']}
                  percentageFontSize={14}
                />
              </View>

              {nextAction && (
                <TouchableOpacity style={styles.nextActionButton} onPress={nextAction.action} activeOpacity={0.8}>
                  <LinearGradient colors={[SKY, theme.primary]} style={styles.nextActionGradient}>
                    <Text style={styles.nextActionText}>{nextAction.label}</Text>
                    <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                  </LinearGradient>
                </TouchableOpacity>
              )}
            </LinearGradient>
          </ProBookingCard>
        </Animated.View>

        {/* Job info modal */}
        {booking && (
          <Modal visible={infoModalVisible} transparent animationType="fade" onRequestClose={() => setInfoModalVisible(false)}>
            <Pressable style={styles.modalOverlay} onPress={() => setInfoModalVisible(false)}>
              <Pressable style={styles.infoModalContent} onPress={(e) => e.stopPropagation()}>
                <View style={styles.infoModalHeader}>
                  <Text style={styles.infoModalTitle}>Booking details</Text>
                  <TouchableOpacity onPress={() => setInfoModalVisible(false)} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}>
                    <Ionicons name="close" size={24} color="#94A3B8" />
                  </TouchableOpacity>
                </View>
                <View style={styles.infoModalBody}>
                  <View style={styles.infoRow}>
                    <Ionicons name="person-outline" size={18} color={SKY} />
                    <Text style={styles.infoText}>{booking.customer_name ?? 'Customer'}</Text>
                  </View>
                  <View style={styles.infoRow}>
                    <Ionicons name="location-outline" size={18} color={SKY} />
                    <Text style={styles.infoText} numberOfLines={2}>{booking.location_address ?? '—'}</Text>
                  </View>
                  {booking.service_name && (
                    <View style={styles.infoRow}>
                      <Ionicons name="water-outline" size={18} color={SKY} />
                      <Text style={styles.infoText}>{booking.service_name}</Text>
                    </View>
                  )}
                  <View style={styles.infoModalProgress}>
                    <Text style={styles.infoModalProgressLabel}>Progress</Text>
                    <AnimatedProgress progress={getStatusProgress()} size={64} strokeWidth={6} color={SKY} percentageFontSize={12} />
                  </View>
                </View>
                <TouchableOpacity onPress={() => setInfoModalVisible(false)} style={styles.infoModalDone} activeOpacity={0.9}>
                  <Text style={styles.infoModalDoneText}>Close</Text>
                </TouchableOpacity>
              </Pressable>
            </Pressable>
          </Modal>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  mapWrapper: { flex: 1 },
  map: { ...StyleSheet.absoluteFillObject },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 100,
  },
  hubMarker: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  hubMarkerImage: { width: 40, height: 40 },
  customerMarker: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  carMarkerImage: { width: 40, height: 40 },
  loadingWrap: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 10 },
  loadingText: { color: SKY, fontSize: 14 },
  centerContent: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 16 },
  errorText: { color: '#F9FAFB', fontSize: 16 },
  backBtn: { paddingVertical: 12, paddingHorizontal: 24, backgroundColor: SKY, borderRadius: 12 },
  backBtnText: { color: '#FFF', fontWeight: '700' },
  cardContainer: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 100,
  },
  trackingCard: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.25)',
    elevation: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 14,
  },
  trackingCardGradient: { padding: 12 },
  cardTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  trackingHeaderCompact: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    minWidth: 0,
  },
  statusMessageCompact: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
    minWidth: 0,
  },
  infoBox: { width: 40, height: 40 },
  infoBoxInner: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    backgroundColor: SKY + '15',
    borderWidth: 0,
    borderColor: SKY + '30',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ringRow: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  mapActionButtons: {
    position: 'absolute',
    right: 16,
    zIndex: 100,
    gap: 10,
  },
  mapActionBtn: { width: 48, height: 48 },
  mapActionBtnDisabled: { opacity: 0.6 },
  mapActionBtnInner: {
    width: '100%',
    height: '100%',
    borderRadius: 24,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.35)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapActionBtnInnerDisabled: {
    backgroundColor: 'rgba(100,116,139,0.25)',
    borderColor: 'rgba(100,116,139,0.3)',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  infoModalContent: {
    width: '100%',
    maxWidth: 340,
    backgroundColor: '#1E293B',
    borderRadius: 20,
    padding: 20,
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  infoModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  infoModalTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  infoModalBody: { gap: 12, marginBottom: 20 },
  infoModalProgress: {
    alignItems: 'center',
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 0,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  infoModalProgressLabel: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 8,
  },
  infoModalDone: {
    backgroundColor: SKY,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  infoModalDoneText: { color: '#fff', fontSize: 16, fontWeight: '700' },
  statusBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingHorizontal: 4,
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: 'rgba(135,206,235,0.3)',
  },
  statusDotDone: { backgroundColor: SKY },
  statusLine: {
    flex: 1,
    height: 3,
    backgroundColor: 'rgba(135,206,235,0.2)',
    marginHorizontal: 2,
    borderRadius: 2,
  },
  statusLineDone: { backgroundColor: SKY },
  trackingHeader: { alignItems: 'center', marginBottom: 12 },
  statusMessage: { color: '#F9FAFB', fontSize: 15, fontWeight: '600', textAlign: 'center' },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
    paddingHorizontal: 8,
  },
  actionIcons: { flexDirection: 'row', gap: 20, alignItems: 'center' },
  iconButton: { alignItems: 'center' },
  iconButtonInner: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
  },
  iconButtonCancel: { backgroundColor: 'rgba(239,68,68,0.15)' },
  iconButtonLabel: { color: 'rgba(249,250,251,0.85)', fontSize: 12, fontWeight: '600' },
  iconButtonLocked: { opacity: 0.7 },
  iconButtonInnerLocked: { backgroundColor: 'rgba(255,255,255,0.06)' },
  iconButtonLabelLocked: { color: 'rgba(249,250,251,0.5)' },
  jobInfo: {
    gap: 8,
    paddingTop: 12,
    marginBottom: 12,
    borderTopWidth: 0,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  infoText: { color: '#E5E7EB', fontSize: 14, flex: 1 },
  nextActionButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  nextActionGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 8,
  },
  nextActionText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  overlayBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.65)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  overlayContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  confettiPiece: {
    position: 'absolute',
  },
  boomCard: {
    width: width - 48,
    maxWidth: 320,
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.4)',
    elevation: 24,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
  },
  boomCardGradient: {
    padding: 32,
    alignItems: 'center',
  },
  boomTitle: {
    fontSize: 42,
    fontWeight: '900',
    color: '#FFFFFF',
    marginBottom: 8,
    letterSpacing: 1,
  },
  boomSubtitle: {
    fontSize: 18,
    fontWeight: '700',
    color: SKY,
    marginBottom: 28,
    textAlign: 'center',
  },
  boomButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  boomButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 28,
    gap: 8,
  },
  boomButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
