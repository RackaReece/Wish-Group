import React, { useEffect, useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ActivityIndicator,
  Alert,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, router } from 'expo-router';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import LoadingView from '../../../src/components/shared/LoadingView';
import GlassCard from '../../../src/components/booking/GlassCard';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import { colors } from '../../../src/constants/colors';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import { getTextColors, getIconColors } from '../../../src/constants/themeColors';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';

const SKY = colors.SKY;

type BookingDetails = {
  id: string;
  status: string;
  service_name: string | null;
  wash_type?: string | null;
  location_address: string | null;
  scheduled_at: string | null;
  created_at: string;
  price: number | null;
  user_id?: string | null;
  customer_name?: string | null;
  customer_review?: string | null;
};

function isMissingColumnErr(err: any) {
  const code = String(err?.code || '');
  const msg = String(err?.message || '').toLowerCase();
  return code === '42703' || msg.includes('does not exist') || msg.includes('column');
}

function getMissingColumn(message?: string | null): string | null {
  const m = (message || '').match(/column\s+bookings\.([a-zA-Z0-9_]+)\s+does\s+not\s+exist/i);
  return m?.[1] ?? null;
}

const isPendingStatus = (status: string) =>
  ['pending', 'pending_business_acceptance'].includes(status.toLowerCase());

export default function BusinessBookingDetails() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { theme: businessTheme } = useAccountTheme();
  const theme = businessTheme ?? getAccountTheme('business', 'light');
  const textColors = getTextColors(theme);
  const iconColors = getIconColors(theme);

  const [booking, setBooking] = useState<BookingDetails | null>(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);

  useEffect(() => {
    if (id) loadBooking();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const canCancel = useMemo(() => {
    if (!booking) return false;
    const s = booking.status.toLowerCase();
    return s !== 'cancelled' && s !== 'completed';
  }, [booking]);

  const loadBooking = async () => {
    try {
      setLoading(true);

      const baseFields = [
        'id',
        'status',
        'service_name',
        'wash_type',
        'location_address',
        'scheduled_at',
        'scheduled_time',
        'created_at',
        'price',
        'user_id',
        'customer_name',
        'customer_review',
      ];

      let fields = [...baseFields];

      for (let i = 0; i < 10; i++) {
        const { data, error } = await supabase
          .from('bookings')
          .select(fields.join(','))
          .eq('id', id)
          .maybeSingle();

        if (!error && data) {
          const row = data as unknown as Record<string, unknown>;
          const scheduledAt = (row.scheduled_at ?? row.scheduled_time ?? null) as string | null;
          setBooking({
            id: String(row.id ?? ''),
            status: String(row.status ?? 'unknown'),
            service_name: (row.service_name as string | null) ?? null,
            wash_type: (row.wash_type as string | null) ?? null,
            location_address: (row.location_address as string | null) ?? null,
            scheduled_at: scheduledAt,
            created_at: String(row.created_at ?? ''),
            price: (row.price as number | null) ?? null,
            user_id: (row.user_id as string | null) ?? null,
            customer_name: (row.customer_name as string | null) ?? null,
            customer_review: (row.customer_review as string | null) ?? null,
          });
          return;
        }

        if (isMissingColumnErr(error)) {
          const missing = getMissingColumn(error?.message);
          if (missing && fields.includes(missing)) {
            fields = fields.filter(f => f !== missing);
            continue;
          }
        }

        throw error;
      }

      throw new Error('Failed to load booking');
    } catch (err: any) {
      console.error('[BookingDetails] load error:', err);
      Alert.alert('Error', err?.message || 'Failed to load booking');
    } finally {
      setLoading(false);
    }
  };

  const acceptBooking = async () => {
    if (!booking) return;

    try {
      setActionLoading(true);
      await hapticFeedback('medium');

      const { error } = await supabase
        .from('bookings')
        .update({ status: 'confirmed' })
        .eq('id', booking.id);

      if (error) throw error;

      setBooking({ ...booking, status: 'confirmed' });
      Alert.alert('Accepted', 'Booking has been accepted');
    } catch (err: any) {
      console.error('[BookingDetails] accept error:', err);
      Alert.alert('Error', err?.message || 'Failed to accept booking');
    } finally {
      setActionLoading(false);
    }
  };

  const cancelBooking = async () => {
    if (!booking) return;

    Alert.alert(
      'Cancel booking',
      'Are you sure you want to cancel this booking?',
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, cancel',
          style: 'destructive',
          onPress: async () => {
            try {
              setActionLoading(true);
              await hapticFeedback('medium');

              const { error } = await supabase
                .from('bookings')
                .update({ status: 'cancelled' })
                .eq('id', booking.id);

              if (error) throw error;

              Alert.alert('Cancelled', 'The booking has been cancelled.');
              router.back();
            } catch (err: any) {
              console.error('[BookingDetails] cancel error:', err);
              Alert.alert('Error', err?.message || 'Failed to cancel booking');
            } finally {
              setActionLoading(false);
            }
          },
        },
      ]
    );
  };

  const speakToCustomer = async () => {
    await hapticFeedback('light');
    if (!booking?.user_id) {
      Alert.alert('No customer', 'This booking has no customer linked to open chat.');
      return;
    }
    router.push({
      pathname: '/chat-screen',
      params: {
        recipientId: booking.user_id,
        recipientName: booking.customer_name ?? 'Customer',
        recipientType: 'customer',
        bookingId: booking.id,
        bookingStatus: booking.status ?? '',
      },
    });
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <LoadingView style={[styles.loading, { flex: 1 }]} />
      </View>
    );
  }

  if (!booking) return null;

  const serviceDisplay = booking.service_name || booking.wash_type || 'Service';
  const customerDisplay = booking.customer_name || 'Customer';

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <AppHeader
        title="Booking"
        accountType="business"
        leftAction={
          <TouchableOpacity onPress={() => router.back()}>
            <Ionicons name="arrow-back" size={22} color={iconColors.primary} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.content,
          { paddingTop: HEADER_CONTENT_OFFSET + 16 }, // ✅ HEADER FIX
        ]}
      >
        <GlassCard
          accountType="business"
          style={styles.card}
          intensity={60}
          gradientColors={['rgba(125,211,252,0.35)', 'rgba(30,58,138,0.4)']}
        >
          <View style={styles.headerRow}>
            <Text style={styles.customerName}>{customerDisplay}</Text>
            <StatusBadge status={booking.status as any} />
          </View>

          <InfoRow icon="briefcase" value={serviceDisplay} iconColor={iconColors.secondary} />
          {booking.location_address && <InfoRow icon="location" value={booking.location_address} iconColor={iconColors.secondary} />}
          {booking.scheduled_at && (
            <InfoRow icon="time" value={new Date(booking.scheduled_at).toLocaleString()} iconColor={iconColors.secondary} />
          )}
          {booking.price !== null && (
            <InfoRow icon="cash" value={`£${Number(booking.price).toFixed(2)}`} iconColor={iconColors.secondary} />
          )}
        </GlassCard>

        <View style={styles.actions}>
          <TouchableOpacity style={styles.actionPrimaryWrap} onPress={speakToCustomer} activeOpacity={0.85}>
            <LinearGradient
              colors={[SKY, '#0EA5E9']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.actionPrimaryGradient}
            >
              <View style={styles.actionPrimaryInner}>
                <View style={styles.actionPrimaryIconWrap}>
                  <Ionicons name="chatbubble-ellipses" size={22} color="#FFFFFF" />
                </View>
                <View style={styles.actionPrimaryTextWrap}>
                  <Text style={styles.actionPrimaryText}>Speak to customer</Text>
                  <Text style={styles.actionPrimarySubtext}>Message or view profile</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="rgba(255,255,255,0.9)" />
              </View>
            </LinearGradient>
          </TouchableOpacity>

          {isPendingStatus(booking.status) && (
            <TouchableOpacity style={styles.actionAccept} onPress={acceptBooking}>
              <Ionicons name="checkmark-circle" size={18} color="#FFFFFF" />
              <Text style={styles.actionAcceptText}>Accept booking</Text>
            </TouchableOpacity>
          )}

          {canCancel && (
            <TouchableOpacity style={styles.actionDanger} onPress={cancelBooking}>
              <Ionicons name="close-circle" size={18} color="#fff" />
              <Text style={styles.actionDangerText}>Cancel booking</Text>
            </TouchableOpacity>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

function InfoRow({ icon, value, iconColor }: { icon: any; value: string; iconColor?: string }) {
  return (
    <View style={styles.row}>
      <Ionicons name={icon} size={16} color={iconColor ?? SKY} />
      <Text style={styles.text}>{value}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  loading: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 10 },
  loadingText: { color: SKY },

  content: { paddingHorizontal: 18, paddingBottom: 24 },

  card: { padding: 16, gap: 10 },

  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },

  customerName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    flex: 1,
    marginRight: 10,
  },

  row: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  text: { color: 'rgba(249,250,251,0.8)', fontSize: 14, flex: 1 },

  actions: { marginTop: 14, gap: 10 },

  actionPrimaryWrap: {
    borderRadius: 20,
    overflow: 'hidden',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 8,
  },
  actionPrimaryGradient: {
    borderRadius: 20,
    paddingVertical: 16,
    paddingHorizontal: 18,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  actionPrimaryInner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  actionPrimaryIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionPrimaryTextWrap: { flex: 1 },
  actionPrimaryText: { color: '#FFFFFF', fontWeight: '800', fontSize: 16 },
  actionPrimarySubtext: { color: 'rgba(255,255,255,0.85)', fontSize: 12, marginTop: 2, fontWeight: '500' },

  actionAccept: {
    backgroundColor: '#22C55E',
    borderRadius: 24,
    paddingVertical: 14,
    flexDirection: 'row',
    gap: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionAcceptText: { color: '#FFFFFF', fontWeight: '800' },

  actionDanger: {
    backgroundColor: '#EF4444',
    borderRadius: 24,
    paddingVertical: 14,
    flexDirection: 'row',
    gap: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionDangerText: { color: '#fff', fontWeight: '800' },
});
