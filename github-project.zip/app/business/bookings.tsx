import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Image,
  Platform,
  Modal,
  Pressable,
} from 'react-native';
import DateTimePicker from '@react-native-community/datetimepicker';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Marker, Circle, Region } from 'react-native-maps';
import { HUB_MAP_ICON, CUSTOMER_MAP_ICON } from '../../src/constants/mapIcons';
import { router, useLocalSearchParams } from 'expo-router';
import * as Location from 'expo-location';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET, HEADER_HEIGHT } from '../../src/components/shared/AppHeader';
import LoadingView from '../../src/components/shared/LoadingView';
import EmptyState from '../../src/components/shared/EmptyState';
import ErrorView from '../../src/components/shared/ErrorView';
import GlassCard from '../../src/components/booking/GlassCard';
import ProBookingCard from '../../src/components/booking/ProBookingCard';
import StatusBadge from '../../src/components/booking/StatusBadge';
import { colors, CARD_BORDER_RADIUS, SKY_BLUE_BORDER } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { typography } from '../../src/constants/typography';
import { getTextColors, getIconColors } from '../../src/constants/themeColors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { useGlobalTheme } from '../../src/components/shared/GlobalThemeContext';
import { DARK_MAP_STYLE } from '../../src/constants/mapStyles';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width, height } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const BUSINESS_PRIMARY = getAccountTheme('business').primary;
const CLOSE_ZOOM_DELTA = 0.01;
const MIN_BOUNDS_DELTA = 0.012;

interface BookingUI {
  id: string;
  user_id?: string | null;
  customer_name: string;
  customer_profile_picture?: string | null;
  customer_lat?: number | null;
  customer_lng?: number | null;
  service_type: string;
  location_address: string | null;
  location_id?: string | null;
  location_lat: number | null;
  location_lng: number | null;
  scheduled_time: string | null;
  status: string;
  assigned_valeter_name: string | null;
  created_at: string;
  customer_on_way?: boolean;
  cancelled?: boolean;
  has_report?: boolean;
  vehicle_type?: string | null;
  vehicle_info?: string | null;
  vehicle_registration?: string | null;
  vehicle_make?: string | null;
  vehicle_model?: string | null;
}

type RawBookingRow = {
  id: string;
  status?: string | null;
  created_at: string;

  // optional columns (may or may not exist)
  customer_name?: string | null;
  service_type?: string | null;
  location_address?: string | null;
  valeter_id?: string | null;

  // time column (unknown name) — we’ll read it dynamically
  [key: string]: any;
};

function getMissingColumn(message?: string | null): string | null {
  const m = (message || '').match(/column\s+bookings\.([a-zA-Z0-9_]+)\s+does\s+not\s+exist/i);
  return m?.[1] ?? null;
}

/**
 * Your DB uses an enum booking_status.
 * This error happens when we pass a value that enum doesn't support.
 * So we MUST NOT send unknown status values in a SQL filter.
 *
 * We'll *try* a status filter, and if Postgres rejects it (22P02),
 * we retry WITHOUT filtering by status and then filter client-side.
 */
const STATUS_CANDIDATES_TO_TRY = [
  // Include all statuses that should show in business list (DB enum may use these).
  'pending',
  'scheduled',
  'pending_business_acceptance',
  'pending_valeter_acceptance',
  'pending_payment',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
  'in_progress',
  'completed',
  'cancelled',
  'valeter_timeout',
];

const TIME_CANDIDATES = [
  'scheduled_at',
  'scheduled_for',
  'scheduled_time',
  'start_time',
  'start_at',
  'booking_time',
  'booked_for',
  'date_time',
  'datetime',
  'scheduled_datetime',
];

export default function BusinessBookings() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams();
  const { theme: businessTheme } = useAccountTheme();
  const { mode } = useGlobalTheme();
  const theme = businessTheme ?? getAccountTheme('business', 'light');
  const textColors = getTextColors(theme);
  const iconColors = getIconColors(theme);

  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const mapRef = useRef<MapView>(null);
  const scrollViewRef = useRef<any>(null);

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, [markerPulse]);

  const [bookings, setBookings] = useState<BookingUI[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState(false);
  const [filterStatus, setFilterStatus] = useState<string | null>(null);
  const [businessLocation, setBusinessLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: CLOSE_ZOOM_DELTA,
    longitudeDelta: CLOSE_ZOOM_DELTA,
  });
  const [selectedBookingIndex, setSelectedBookingIndex] = useState(0);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [locationPermission, setLocationPermission] = useState<Location.PermissionStatus | null>(null);
  const [initialRegion, setInitialRegion] = useState<Region | null>(null);
  const [amendBooking, setAmendBooking] = useState<BookingUI | null>(null);
  const [amendDate, setAmendDate] = useState<Date>(() => new Date());
  const [showAmendModal, setShowAmendModal] = useState(false);
  const [savingAmend, setSavingAmend] = useState(false);
  const [showAmendDatePicker, setShowAmendDatePicker] = useState(Platform.OS === 'ios');

  const cardWidth = width - 40;
  const cardSpacing = 20;

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  // Request location permission and get user location (non-fatal: simulator may not have location)
  useEffect(() => {
    const requestLocationPermission = async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        setLocationPermission(status);

        if (status === 'granted') {
          try {
            const location = await Location.getCurrentPositionAsync({
              accuracy: Location.Accuracy.High,
            });
            setUserLocation({
              latitude: location.coords.latitude,
              longitude: location.coords.longitude,
            });
            setRegion({
              latitude: location.coords.latitude,
              longitude: location.coords.longitude,
              latitudeDelta: CLOSE_ZOOM_DELTA,
              longitudeDelta: CLOSE_ZOOM_DELTA,
            });
          } catch (_locErr) {
            // Cannot obtain location (e.g. simulator, no GPS) – leave userLocation null, map still works
          }
        }
      } catch (_permErr) {
        // Permission request failed – leave permission state as-is
      }
    };

    requestLocationPermission().catch(() => {});
  }, []);

  // Watch user location for live updates
  useEffect(() => {
    if (locationPermission !== 'granted') return;
    
    const subscription = Location.watchPositionAsync(
      {
        accuracy: Location.Accuracy.High,
        distanceInterval: 100, // Update every 100 meters
        timeInterval: 30000, // Or every 30 seconds
      },
      (location) => {
        setUserLocation({
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        });
      }
    );

    return () => {
      subscription.then(sub => sub.remove());
    };
  }, [locationPermission]);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }).start();

    if (isOrgUser && organizationId) {
      loadBusinessLocation();
      loadBookings();
    } else {
      setBookings([]);
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [organizationId, isOrgUser, filterStatus]);

  // Subscribe to real-time customer location updates
  useEffect(() => {
    if (!isOrgUser || !organizationId || bookings.length === 0) return;

    const customerIds = bookings
      .map(b => b.user_id)
      .filter(Boolean) as string[];

    if (customerIds.length === 0) return;

    // Subscribe to profile location updates for customers with bookings
    const channel = supabase
      .channel('customer-locations-updates')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: `id=in.(${customerIds.join(',')})`,
        },
        (payload) => {
          const updated = payload.new as any;
          const customerId = updated.id;
          const newLat = updated.current_latitude || updated.latitude;
          const newLng = updated.current_longitude || updated.longitude;

          if (newLat && newLng && customerId) {
            // Update booking with new customer location
            setBookings((prev) =>
              prev.map((booking) => {
                if (booking.user_id === customerId) {
                  return {
                    ...booking,
                    customer_lat: newLat,
                    customer_lng: newLng,
                  };
                }
                return booking;
              })
            );
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [bookings, isOrgUser, organizationId]);

  // Load business location from car_wash_locations
  const loadBusinessLocation = async () => {
    if (!isOrgUser || !organizationId) return;
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('latitude, longitude')
        .eq('organization_id', organizationId)
        .not('latitude', 'is', null)
        .not('longitude', 'is', null)
        .limit(1)
        .single();

      if (!error && data?.latitude && data?.longitude) {
        setBusinessLocation({ lat: data.latitude, lng: data.longitude });
        const newRegion = {
          latitude: data.latitude,
          longitude: data.longitude,
          latitudeDelta: CLOSE_ZOOM_DELTA,
          longitudeDelta: CLOSE_ZOOM_DELTA,
        };
        setRegion(newRegion);
        if (!initialRegion) {
          setInitialRegion(newRegion);
        }
      }
    } catch (error) {
      console.error('Error loading business location:', error);
    }
  };

  const handleDeleteBooking = async (bookingId: string) => {
    Alert.alert(
      'Delete Booking',
      'Are you sure you want to delete this booking? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await hapticFeedback('medium');
              const { error } = await supabase.from('bookings').delete().eq('id', bookingId);

              if (error) throw error;

              setBookings((prev) => prev.filter((b) => b.id !== bookingId));
            } catch (error: any) {
              console.error('Error deleting booking:', error);
              Alert.alert('Error', error?.message || 'Failed to delete booking');
            }
          },
        },
      ]
    );
  };

  const handleDeleteAllBookings = async () => {
    if (bookings.length === 0) return;

    Alert.alert(
      'Delete All Bookings',
      `Are you sure you want to delete all ${bookings.length} booking${bookings.length !== 1 ? 's' : ''}? This action cannot be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete All',
          style: 'destructive',
          onPress: async () => {
            try {
              await hapticFeedback('medium');
              const bookingIds = bookings.map((b) => b.id);
              const { error } = await supabase.from('bookings').delete().in('id', bookingIds);

              if (error) throw error;

              setBookings([]);
            } catch (error: any) {
              console.error('Error deleting all bookings:', error);
              Alert.alert('Error', error?.message || 'Failed to delete all bookings');
            }
          },
        },
      ]
    );
  };

  const loadBookings = async () => {
    if (!isOrgUser || !organizationId) return;

    try {
      setLoading(true);
      setLoadError(false);

      // 1) Fetch org locations
      const { data: locations, error: locErr } = await supabase
        .from('car_wash_locations')
        .select('id, address')
        .eq('organization_id', organizationId);

      if (locErr) throw locErr;

      const locationIds = (locations || []).map((l: any) => l.id).filter(Boolean);
      const locationAddresses = (locations || [])
        .map((l: any) => (typeof l.address === 'string' ? l.address.trim() : ''))
        .filter((a: string) => a.length > 0);

      if (locationIds.length === 0 && locationAddresses.length === 0) {
        setBookings([]);
        return;
      }

      // 2) Fetch bookings: same logic as orders.tsx — by location_id when available, else by location_address
      const { rows, resolvedTimeField } = await fetchBookingsForOrgLocations(locationIds, locationAddresses);

      // 3) Resolve valeter names if valeter_id exists
      const valeterIds = Array.from(new Set(rows.map(r => r.valeter_id).filter(Boolean))) as string[];
      const profileMap = new Map<string, string>();

      if (valeterIds.length > 0) {
        const { data: profiles, error: profErr } = await supabase
          .from('profiles')
          .select('id, full_name, name')
          .in('id', valeterIds);

        if (profErr) {
          console.warn('[BusinessBookings] valeter name lookup error:', profErr.message);
        } else {
          (profiles || []).forEach((p: any) => {
            profileMap.set(p.id, (p.full_name || p.name || 'Valeter') as string);
          });
        }
      }

      // 4) Fetch vehicle information and customer profile pictures
      const customerIds = Array.from(new Set(rows.map(r => r.user_id).filter(Boolean))) as string[];
      const vehicleMap = new Map<string, { registration?: string; make?: string; model?: string; type?: string }>();
      const customerProfileMap = new Map<string, string | null>();
      let customerProfilesData: any[] = [];

      if (customerIds.length > 0) {
        try {
          // Fetch vehicles
          const { data: vehicles, error: vehicleErr } = await supabase
            .from('customer_vehicles')
            .select('user_id, registration, make, model, type')
            .in('user_id', customerIds)
            .eq('is_default', true);

          if (vehicleErr) {
            console.warn('[BusinessBookings] vehicle lookup error:', vehicleErr.message);
          } else {
            (vehicles || []).forEach((v: any) => {
              vehicleMap.set(v.user_id, {
                registration: v.registration || undefined,
                make: v.make || undefined,
                model: v.model || undefined,
                type: v.type || undefined,
              });
            });
          }

          let profilesData: any[] | null = null;
          const profileSelects = ['id, full_name, name, profile_picture', 'id, full_name, name'];
          for (const sel of profileSelects) {
            const { data, error: profileErr } = await supabase
              .from('profiles')
              .select(sel)
              .in('id', customerIds);
            if (!profileErr) {
              profilesData = data;
              break;
            }
            if (profileErr?.code === '42703') continue;
            console.warn('[BusinessBookings] customer profile lookup error:', profileErr.message);
            break;
          }
          if (profilesData) {
            customerProfilesData = profilesData;
            customerProfilesData.forEach((p: any) => {
              const profilePic = p.profile_picture ?? null;
              customerProfileMap.set(p.id, profilePic);
            });
          }
        } catch (error) {
          console.warn('[BusinessBookings] customer data lookup failed:', error);
        }
      }

      const customerNameMap = new Map<string, string>();
      const customerLocationMap = new Map<string, { lat: number; lng: number }>();
      customerProfilesData.forEach((p: any) => {
        const name = (p.full_name || p.name || 'Customer') as string;
        if (p.id) customerNameMap.set(p.id, name);
        const lat = p.latitude;
        const lng = p.longitude;
        if (lat != null && lng != null && p.id) {
          customerLocationMap.set(p.id, { lat: Number(lat), lng: Number(lng) });
        }
      });

      const enriched: BookingUI[] = rows.map((b) => {
        const scheduledValue =
          resolvedTimeField && b[resolvedTimeField] ? String(b[resolvedTimeField]) : null;

        const status = String(b.status ?? 'unknown');
        const vehicleData = b.user_id ? vehicleMap.get(b.user_id) : null;
        const customerProfilePic = b.user_id ? customerProfileMap.get(b.user_id) || null : null;
        const customerLoc = b.user_id ? customerLocationMap.get(b.user_id) : null;
        const customerName = b.user_id ? customerNameMap.get(b.user_id) || 'Customer' : 'Customer';

        return {
          id: b.id,
          user_id: b.user_id ?? null,
          customer_name: customerName,
          customer_profile_picture: customerProfilePic,
          customer_lat: customerLoc?.lat ?? null,
          customer_lng: customerLoc?.lng ?? null,
          service_type: (b.service_type || 'Service') as string,
          location_address: b.location_address ?? null,
          location_id: b.location_id ?? null,
          location_lat: b.location_lat ?? null,
          location_lng: b.location_lng ?? null,
          scheduled_time: scheduledValue,
          status,
          assigned_valeter_name: b.valeter_id ? profileMap.get(b.valeter_id) || null : null,
          created_at: b.created_at,
          customer_on_way: status === 'in_progress',
          cancelled: status === 'cancelled',
          has_report: false,
          vehicle_type: b.vehicle_type || vehicleData?.type || null,
          vehicle_info: b.vehicle_info || null,
          vehicle_registration: vehicleData?.registration || null,
          vehicle_make: vehicleData?.make || null,
          vehicle_model: vehicleData?.model || null,
        };
      });

      // Exclude cancelled so they don't show on the bookings page
      const activeEnriched = enriched.filter((b) => b.status !== 'cancelled');
      // Filter client-side: once a job is at 100% (completed) it moves to Orders — exclude from default list
      let filtered: BookingUI[];
      if (filterStatus === 'in_progress') {
        filtered = activeEnriched.filter((b) => b.status === 'en_route' || b.status === 'in_progress');
      } else if (filterStatus === 'completed') {
        filtered = activeEnriched.filter((b) => b.status === 'completed');
      } else if (filterStatus) {
        filtered = activeEnriched.filter((b) => b.status === filterStatus);
      } else {
        filtered = activeEnriched.filter((b) => b.status !== 'completed');
      }
      setBookings(filtered);

      // Update map region - prioritize business location, then bookings
      if (businessLocation) {
        const bookingsWithLocation = filtered.filter(b => b.location_lat && b.location_lng);
        if (bookingsWithLocation.length > 0) {
          // Include business location in bounds calculation
          const allLats = [businessLocation.lat, ...bookingsWithLocation.map(b => b.location_lat!)];
          const allLngs = [businessLocation.lng, ...bookingsWithLocation.map(b => b.location_lng!)];
          const minLat = Math.min(...allLats);
          const maxLat = Math.max(...allLats);
          const minLng = Math.min(...allLngs);
          const maxLng = Math.max(...allLngs);
          
          setRegion({
            latitude: (minLat + maxLat) / 2,
            longitude: (minLng + maxLng) / 2,
            latitudeDelta: Math.max((maxLat - minLat) * 1.5, MIN_BOUNDS_DELTA),
            longitudeDelta: Math.max((maxLng - minLng) * 1.5, MIN_BOUNDS_DELTA),
          });
        } else {
          // Just center on business location
          setRegion({
            latitude: businessLocation.lat,
            longitude: businessLocation.lng,
            latitudeDelta: CLOSE_ZOOM_DELTA,
            longitudeDelta: CLOSE_ZOOM_DELTA,
          });
        }
      } else {
        // Fallback to bookings only
        const bookingsWithLocation = filtered.filter(b => b.location_lat && b.location_lng);
        if (bookingsWithLocation.length > 0) {
          const lats = bookingsWithLocation.map(b => b.location_lat!);
          const lngs = bookingsWithLocation.map(b => b.location_lng!);
          const minLat = Math.min(...lats);
          const maxLat = Math.max(...lats);
          const minLng = Math.min(...lngs);
          const maxLng = Math.max(...lngs);
          
          const newRegion = {
            latitude: (minLat + maxLat) / 2,
            longitude: (minLng + maxLng) / 2,
            latitudeDelta: Math.max((maxLat - minLat) * 1.5, MIN_BOUNDS_DELTA),
            longitudeDelta: Math.max((maxLng - minLng) * 1.5, MIN_BOUNDS_DELTA),
          };
          setRegion(newRegion);
          if (!initialRegion) {
            setInitialRegion(newRegion);
          }
        }
      }

      // Update map region based on bookings with locations
      const bookingsWithLocation = filtered.filter(b => b.location_lat && b.location_lng);
      if (bookingsWithLocation.length > 0) {
        const lats = bookingsWithLocation.map(b => b.location_lat!);
        const lngs = bookingsWithLocation.map(b => b.location_lng!);
        const minLat = Math.min(...lats);
        const maxLat = Math.max(...lats);
        const minLng = Math.min(...lngs);
        const maxLng = Math.max(...lngs);
        
        const newRegion = {
          latitude: (minLat + maxLat) / 2,
          longitude: (minLng + maxLng) / 2,
          latitudeDelta: Math.max((maxLat - minLat) * 1.5, MIN_BOUNDS_DELTA),
          longitudeDelta: Math.max((maxLng - minLng) * 1.5, MIN_BOUNDS_DELTA),
        };
        setRegion(newRegion);
        if (!initialRegion) {
          setInitialRegion(newRegion);
        }
      }
      
      if (filtered.length > 0) {
        setSelectedBookingIndex(0);
      }
    } catch (error: any) {
      console.error('Error loading bookings:', error);
      setLoadError(true);
    } finally {
      setLoading(false);
    }
  };

  /**
   * Fetch bookings for org locations. Same logic as orders.tsx: filter by location_id when
   * available; fallback to location_address if location_id column is missing or empty.
   */
  const fetchBookingsForOrgLocations = async (
    locationIds: string[],
    locationAddresses: string[]
  ): Promise<{ rows: RawBookingRow[]; resolvedTimeField: string | null }> => {
    const baseFields = ['id', 'created_at', 'status', 'location_address', 'location_id', 'location_lat', 'location_lng', 'service_type', 'valeter_id', 'vehicle_type', 'vehicle_info', 'user_id'];
    const timeAttempts = [...TIME_CANDIDATES, null] as (string | null)[];
    let mutableBaseFields = [...baseFields];
    const columnsToOmit = new Set<string>();

    const runQuery = async (
      uniqueFields: string[],
      locationFilter: (q: any) => any,
      useStatusFilter: boolean
    ): Promise<{ data: RawBookingRow[]; error: any }> => {
      let q = supabase
        .from('bookings')
        .select(uniqueFields.join(','))
        .order('created_at', { ascending: false })
        .limit(200);
      q = locationFilter(q);
      if (useStatusFilter) {
        q = q.in('status', STATUS_CANDIDATES_TO_TRY as any);
      }
      const { data, error } = await q;
      return { data: (data || []) as unknown as RawBookingRow[], error };
    };

    for (const timeField of timeAttempts) {
      const fields = timeField ? [...mutableBaseFields, timeField] : [...mutableBaseFields];
      const uniqueFields = Array.from(new Set(fields)).filter((f) => !columnsToOmit.has(f));

      // 1) Try location_id first (same as orders.tsx)
      if (locationIds.length > 0) {
        const byId = (q: any) => q.in('location_id', locationIds);
        let res = await runQuery(uniqueFields, byId, true);
        if (res.error?.code === '22P02' && /enum\s+booking_status/i.test(res.error?.message || '')) {
          res = await runQuery(uniqueFields, byId, false);
        }
        if (!res.error) {
          return { rows: res.data, resolvedTimeField: timeField };
        }
        if (res.error?.code === '42703') {
          const missing = getMissingColumn(res.error?.message);
          if (missing) {
            columnsToOmit.add(missing);
            mutableBaseFields = mutableBaseFields.filter((f) => f !== missing);
            continue; // try next time field or same query without missing column
          }
        }
        const missing = getMissingColumn(res.error?.message);
        if (missing) {
          columnsToOmit.add(missing);
          if (mutableBaseFields.includes(missing)) {
            mutableBaseFields = mutableBaseFields.filter((f) => f !== missing);
          }
          continue;
        }
        throw res.error;
      }

      // 2) Fallback: by location_address (when no location_ids or location_id column missing)
      if (locationAddresses.length === 0) {
        return { rows: [], resolvedTimeField: timeField };
      }
      const byAddress = (q: any) => q.in('location_address', locationAddresses as any);
      let res = await runQuery(uniqueFields, byAddress, true);
      if (res.error?.code === '22P02' && /enum\s+booking_status/i.test(res.error?.message || '')) {
        res = await runQuery(uniqueFields, byAddress, false);
      }
      if (!res.error) {
        return { rows: res.data, resolvedTimeField: timeField };
      }
      if (res.error?.code === '42703') {
        const missing = getMissingColumn(res.error?.message);
        if (missing) {
          columnsToOmit.add(missing);
          mutableBaseFields = mutableBaseFields.filter((f) => f !== missing);
          continue;
        }
      }
      const missing = getMissingColumn(res.error?.message);
      if (missing) {
        columnsToOmit.add(missing);
        if (mutableBaseFields.includes(missing)) {
          mutableBaseFields = mutableBaseFields.filter((f) => f !== missing);
        }
        continue;
      }
      throw res.error;
    }

    return { rows: [], resolvedTimeField: null };
  };

  // NOTE: These are UI filters. If your DB enum uses different labels,
  // update these values to match what's actually stored in bookings.status.
  const statusFilters = [
    { label: 'All', value: null, icon: 'list' as const, color: theme.primary },
    { label: 'Pending', value: 'pending_business_acceptance', icon: 'time-outline' as const, color: '#FBBF24' },
    { label: 'In Progress', value: 'in_progress', icon: 'play-circle-outline' as const, color: theme.primary },
    { label: 'Completed', value: 'completed', icon: 'checkmark-done-circle' as const, color: '#8B5CF6' },
  ];

  // Calculate time until booking (UI only - no backend)
  const getTimeUntilBooking = (scheduledTime: string | null): { minutes: number; text: string; isUrgent: boolean } | null => {
    if (!scheduledTime) return null;
    const now = new Date();
    const scheduled = new Date(scheduledTime);
    const diffMs = scheduled.getTime() - now.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 0) return { minutes: diffMins, text: 'Overdue', isUrgent: true };
    if (diffMins < 5) return { minutes: diffMins, text: `${diffMins} min`, isUrgent: true };
    if (diffMins < 60) return { minutes: diffMins, text: `${diffMins} min`, isUrgent: false };
    const hours = Math.floor(diffMins / 60);
    return { minutes: diffMins, text: `${hours}h ${diffMins % 60}m`, isUrgent: false };
  };

  // Calculate ETA (estimated time of arrival) - UI only
  const getETA = (booking: BookingUI): string | null => {
    if (!booking.scheduled_time) return null;
    const timeUntil = getTimeUntilBooking(booking.scheduled_time);
    if (!timeUntil) return null;
    return timeUntil.text;
  };

  // Sync map with selected booking
  useEffect(() => {
    if (bookings.length > 0 && selectedBookingIndex < bookings.length) {
      const selectedBooking = bookings[selectedBookingIndex];
      if (selectedBooking.location_lat && selectedBooking.location_lng) {
        const newRegion: Region = {
          latitude: selectedBooking.location_lat,
          longitude: selectedBooking.location_lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        };
        setRegion(newRegion);
        mapRef.current?.animateToRegion(newRegion, 500);
      }
    }
  }, [selectedBookingIndex, bookings]);

  // Scroll to selected booking when index changes
  useEffect(() => {
    if (scrollViewRef.current && bookings.length > 0 && selectedBookingIndex < bookings.length) {
      const scrollX = selectedBookingIndex * (cardWidth + cardSpacing);
      scrollViewRef.current.scrollTo({
        x: scrollX,
        animated: true,
      });
    }
  }, [selectedBookingIndex, bookings.length]);

  const handleScroll = (event: any) => {
    const scrollPosition = event.nativeEvent.contentOffset.x;
    const newIndex = Math.round(scrollPosition / (cardWidth + cardSpacing));
    
    if (newIndex >= 0 && newIndex < bookings.length && newIndex !== selectedBookingIndex) {
      setSelectedBookingIndex(newIndex);
    }
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (bookings.length > 0 && selectedBookingIndex < bookings.length) {
      const selectedBooking = bookings[selectedBookingIndex];
      if (selectedBooking.location_lat && selectedBooking.location_lng) {
        const newRegion: Region = {
          latitude: selectedBooking.location_lat,
          longitude: selectedBooking.location_lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        };
        setRegion(newRegion);
        mapRef.current?.animateToRegion(newRegion, 500);
      }
    } else if (initialRegion) {
      setRegion(initialRegion);
      mapRef.current?.animateToRegion(initialRegion, 500);
    } else if (userLocation) {
      const newRegion: Region = {
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      };
      setRegion(newRegion);
      mapRef.current?.animateToRegion(newRegion, 500);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  if (loadError) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <ErrorView
          message="Failed to load bookings"
          onRetry={() => {
            setLoadError(false);
            loadBookings();
          }}
          style={styles.loadingContainer}
        />
      </View>
    );
  }

  if (!isOrgUser || !organizationId) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Bookings" accountType="business" />
        <View style={styles.loadingContainer}>
          <Ionicons name="alert-circle-outline" size={42} color={iconColors.primary} style={{ opacity: 0.85 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320, color: textColors.primary }]}>
            This business account isn’t linked to an organization yet.
            {'\n'}Log out and back in, or contact support.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  const handleCancelBooking = async (bookingId: string) => {
    try {
      const { error } = await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', bookingId);
      if (error) throw error;
      setBookings((prev) => prev.filter((b) => b.id !== bookingId));
      if (selectedBookingIndex >= bookings.length - 1) setSelectedBookingIndex(Math.max(0, bookings.length - 2));
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Failed to cancel booking');
    }
  };

  const handleSaveAmendSlot = async () => {
    if (!amendBooking) return;
    setSavingAmend(true);
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ scheduled_at: amendDate.toISOString() })
        .eq('id', amendBooking.id);
      if (error) throw error;
      setBookings((prev) =>
        prev.map((b) =>
          b.id === amendBooking.id ? { ...b, scheduled_time: amendDate.toISOString() } : b
        )
      );
      setShowAmendModal(false);
      setAmendBooking(null);
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Failed to update slot time');
    } finally {
      setSavingAmend(false);
    }
  };

  // Render booking card component (similar to valeter job card)
  const renderBookingCard = (booking: BookingUI) => {
    const timeUntil = getTimeUntilBooking(booking.scheduled_time);
    const eta = getETA(booking);
    const isUrgent = timeUntil?.isUrgent || false;

    const goToTracking = () => {
      router.push({ pathname: '/business/bookings/tracking', params: { bookingId: booking.id } } as any);
    };

    return (
      <ProBookingCard onPress={goToTracking} stripColor={SKY} intensity={60}>
          <LinearGradient
            colors={['rgba(125,211,252,0.35)', 'rgba(30,58,138,0.4)']}
            style={[StyleSheet.absoluteFill, styles.jobCardBackground]}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          />

          {/* Header */}
          <View style={styles.bookingCardHeader}>
            <View style={styles.bookingCardHeaderContent}>
              <View style={styles.servicePreviewIcon}>
                {booking.customer_profile_picture ? (
                  <Image 
                    source={{ uri: booking.customer_profile_picture }} 
                    style={styles.customerProfileImage}
                    resizeMode="cover"
                  />
                ) : (
                  <Ionicons name="person" size={12} color={theme.primary} />
                )}
              </View>
              <View style={styles.bookingCardHeaderText}>
                <Text style={styles.bookingCardTitle} numberOfLines={1}>
                  {booking.customer_name}
                </Text>
                <Text style={styles.bookingCardService}>{booking.service_type}</Text>
              </View>
            </View>
            <View style={styles.bookingCardHeaderRight}>
              <StatusBadge status={booking.status as any} size="small" />
            </View>
          </View>

          {/* Details */}
          <View style={styles.bookingCardDetails}>
            {booking.location_address && (
              <View style={styles.bookingDetailRow}>
                <Ionicons name="location-outline" size={16} color={theme.primary} />
                <Text style={styles.bookingDetailText} numberOfLines={2}>
                  {booking.location_address}
                </Text>
              </View>
            )}

            {booking.scheduled_time && (
              <View style={styles.bookingDetailRow}>
                <Ionicons name="time-outline" size={16} color={theme.primary} />
                <Text style={[styles.bookingDetailText, isUrgent && styles.urgentText]}>
                  {new Date(booking.scheduled_time).toLocaleString('en-GB', {
                    day: 'numeric',
                    month: 'short',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                  {eta && ` • ETA: ${eta}`}
                </Text>
              </View>
            )}

            {booking.status === 'en_route' && (
              <View style={styles.bookingDetailRow}>
                <Ionicons name="car" size={16} color="#10B981" />
                <Text style={styles.enRouteText}>Customer en route to car wash</Text>
              </View>
            )}

            {/* Vehicle Information */}
            {(booking.vehicle_registration || booking.vehicle_type || booking.vehicle_make || booking.vehicle_model) && (
              <View style={styles.bookingDetailRow}>
                <Ionicons name="car-sport-outline" size={16} color={theme.primary} />
                <View style={styles.vehicleInfoContainer}>
                  {booking.vehicle_registration && (
                    <Text style={styles.vehicleRegistration}>{booking.vehicle_registration}</Text>
                  )}
                  {(booking.vehicle_make || booking.vehicle_model || booking.vehicle_type) && (
                    <Text style={styles.bookingDetailText}>
                      {[booking.vehicle_make, booking.vehicle_model, booking.vehicle_type].filter(Boolean).join(' ')}
                    </Text>
                  )}
                </View>
              </View>
            )}

            {timeUntil && timeUntil.isUrgent && (
              <View style={styles.bookingDetailRow}>
                <Ionicons name="alert-circle" size={16} color="#F59E0B" />
                <Text style={styles.urgentText}>
                  {timeUntil.minutes < 0 ? 'Overdue' : `${timeUntil.minutes} minutes until booking`}
                </Text>
              </View>
            )}

            {booking.assigned_valeter_name && (
              <View style={styles.bookingDetailRow}>
                <Ionicons name="person-outline" size={16} color={theme.primary} />
                <Text style={styles.bookingDetailText}>{booking.assigned_valeter_name}</Text>
              </View>
            )}
          </View>

          {/* Live Booking Location Card - Show 5 minutes before booking */}
          {(() => {
            const timeUntil = getTimeUntilBooking(booking.scheduled_time);
            const isWithin5Minutes = timeUntil && timeUntil.minutes <= 5 && timeUntil.minutes >= 0;
            const customerLocation = booking.customer_lat && booking.customer_lng 
              ? { lat: booking.customer_lat, lng: booking.customer_lng }
              : null;
            const bookingLocation = booking.location_lat && booking.location_lng
              ? { lat: booking.location_lat, lng: booking.location_lng }
              : null;

            // Calculate distance if both locations exist
            let distanceKm = null;
            if (customerLocation && bookingLocation) {
              const R = 6371; // Earth's radius in km
              const dLat = (bookingLocation.lat - customerLocation.lat) * Math.PI / 180;
              const dLon = (bookingLocation.lng - customerLocation.lng) * Math.PI / 180;
              const a = 
                Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(customerLocation.lat * Math.PI / 180) * Math.cos(bookingLocation.lat * Math.PI / 180) *
                Math.sin(dLon/2) * Math.sin(dLon/2);
              const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
              distanceKm = R * c;
            }

            if (isWithin5Minutes && customerLocation) {
              return (
                <ProBookingCard stripColor="#10B981" intensity={60} style={styles.liveBookingCard}>
                  <LinearGradient
                    colors={['rgba(125,211,252,0.35)', 'rgba(30,58,138,0.4)']}
                    style={[StyleSheet.absoluteFill, styles.liveBookingCardBackground]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                  />
                  <View style={styles.liveBookingCardContent}>
                    <View style={styles.liveBookingCardHeader}>
                      <View style={styles.liveIndicator}>
                        <View style={styles.liveIndicatorDot} />
                        <Text style={styles.liveIndicatorText}>LIVE</Text>
                      </View>
                      <Ionicons name="navigate" size={20} color="#10B981" />
                    </View>
                    <Text style={styles.liveBookingCardTitle}>Customer Location</Text>
                    {distanceKm !== null && (
                      <View style={styles.liveDistanceContainer}>
                        <Ionicons name="location" size={18} color="#10B981" />
                        <Text style={styles.liveDistanceText}>
                          {distanceKm < 1 
                            ? `${Math.round(distanceKm * 1000)}m away` 
                            : `${distanceKm.toFixed(1)}km away`}
                        </Text>
                      </View>
                    )}
                    <View style={styles.liveTrackingRow}>
                      <Ionicons name="pulse" size={14} color="#10B981" />
                      <Text style={styles.liveTrackingText}>Live tracking active • Updates every 30s</Text>
                    </View>
                  </View>
                </ProBookingCard>
              );
            }
            return null;
          })()}

          {/* Track the wash – primary CTA (opens map tracking page) */}
          <TouchableOpacity style={styles.trackWashButton} onPress={goToTracking} activeOpacity={0.8}>
            <LinearGradient colors={[SKY, theme.primary]} style={styles.trackWashGradient}>
              <Ionicons name="navigate" size={20} color="#FFFFFF" />
              <Text style={styles.trackWashText}>Track the wash</Text>
            </LinearGradient>
          </TouchableOpacity>

          {/* Cancel | Amend time slot */}
          <View style={styles.bookingCardFooter}>
            <TouchableOpacity
              style={styles.bookingCardFooterLink}
              onPress={async () => {
                await hapticFeedback('light');
                Alert.alert('Cancel booking', 'Cancel this booking? The customer will be notified.', [
                  { text: 'No', style: 'cancel' },
                  { text: 'Yes, cancel', style: 'destructive', onPress: () => handleCancelBooking(booking.id) },
                ]);
              }}
            >
              <Ionicons name="close-circle-outline" size={16} color={iconColors.secondary} />
              <Text style={styles.bookingCardFooterLinkText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={styles.bookingCardFooterLink}
              onPress={async () => {
                await hapticFeedback('light');
                const current = booking.scheduled_time ? new Date(booking.scheduled_time) : new Date();
                setAmendDate(current);
                setAmendBooking(booking);
                setShowAmendModal(true);
                setShowAmendDatePicker(Platform.OS === 'ios');
              }}
            >
              <Ionicons name="time-outline" size={16} color={iconColors.secondary} />
              <Text style={styles.bookingCardFooterLinkText}>Amend time slot</Text>
            </TouchableOpacity>
          </View>
      </ProBookingCard>
    );
  };

  // Render map function
  const renderMap = () => {
    if (loading) {
      return (
        <View style={styles.mapContainer}>
          <LoadingView style={styles.mapLoadingContainer} />
        </View>
      );
    }

    return (
      <View style={styles.mapContainer}>
        <MapView
          ref={mapRef}
          style={styles.map}
          region={region}
          showsUserLocation={true}
          showsMyLocationButton={true}
          mapType="standard"
          customMapStyle={mode === 'dark' ? DARK_MAP_STYLE : undefined}
          mapPadding={{ top: 0, bottom: height * 0.4, left: 0, right: 0 }}
          loadingEnabled={true}
          loadingIndicatorColor={theme.primary}
          followsUserLocation={true}
          userLocationPriority="high"
          userLocationUpdateInterval={5000}
        >
          {/* Car wash hub / business location marker (cleaning.png) */}
          {businessLocation && (
            <Marker
              coordinate={{
                latitude: businessLocation.lat,
                longitude: businessLocation.lng,
              }}
              anchor={{ x: 0.5, y: 0.5 }}
              tracksViewChanges={false}
            >
              <View style={styles.businessLocationMarker}>
                <Image source={HUB_MAP_ICON} style={styles.hubMarkerImage} resizeMode="contain" />
              </View>
            </Marker>
          )}

          {/* Blue areas: recent booking locations (most recent first, up to 15) */}
          {bookings
            .filter((b) => b.location_lat != null && b.location_lng != null)
            .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime())
            .slice(0, 15)
            .map((booking) => (
              <Circle
                key={`area-${booking.id}`}
                center={{
                  latitude: booking.location_lat!,
                  longitude: booking.location_lng!,
                }}
                radius={180}
                fillColor="rgba(96, 165, 250, 0.22)"
                strokeColor="rgba(96, 165, 250, 0.5)"
                strokeWidth={1.5}
                zIndex={0}
              />
            ))}

          {/* Valeter/job Markers (en route or in progress) */}
          {bookings.filter(b => b.location_lat && b.location_lng && (b.status === 'en_route' || b.status === 'in_progress')).map((booking, index) => {
            const isSelected = index === selectedBookingIndex;
            const isEnRoute = booking.status === 'en_route';
            return (
              <Marker
                key={booking.id}
                coordinate={{
                  latitude: booking.location_lat!,
                  longitude: booking.location_lng!,
                }}
                anchor={{ x: 0.5, y: 0.5 }}
                tracksViewChanges={false}
              >
                <Animated.View style={[styles.mapMarkerPin, isSelected && styles.mapMarkerPinSelected, isEnRoute && styles.enRouteMarker, { transform: [{ scale: markerPulse }] }]}>
                  <Image
                    source={CUSTOMER_MAP_ICON}
                    style={styles.carMarkerImage}
                    resizeMode="contain"
                  />
                </Animated.View>
              </Marker>
            );
          })}
        </MapView>
      </View>
    );
  };

  // Render booking cards with horizontal scrolling
  const renderBookingCards = () => {
    if (loading) {
      return (
        <View style={styles.cardsLoadingContainer}>
          <LoadingView />
        </View>
      );
    }

    if (bookings.length === 0) {
      return (
        <View style={[styles.emptyContainer, { paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12 }]}>
          <EmptyState
            icon="calendar-outline"
            title="No Bookings Available"
            subtitle={
              filterStatus
                ? `No ${statusFilters.find((f) => f.value === filterStatus)?.label.toLowerCase()} bookings`
                : 'Bookings will appear here as customers book your services'
            }
            iconColor={iconColors.primary ?? theme.primary}
          />
        </View>
      );
    }

    return (
      <View style={[styles.bookingCardContainer, { paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12 }]}>
        <View style={styles.deleteAllContainer}>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              handleDeleteAllBookings();
            }}
            style={styles.deleteAllButton}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={['rgba(239,68,68,0.9)', 'rgba(185,28,28,0.85)']}
              style={styles.deleteAllIconWrapper}
            >
              <Ionicons name="trash-outline" size={18} color="#FFFFFF" />
            </LinearGradient>
            <Text style={styles.deleteAllText}>Delete all</Text>
          </TouchableOpacity>
        </View>
        <ScrollView
          ref={scrollViewRef}
          horizontal
          pagingEnabled={false}
          showsHorizontalScrollIndicator={false}
          onScroll={handleScroll}
          scrollEventThrottle={16}
          contentContainerStyle={styles.scrollContentCards}
          snapToInterval={cardWidth + cardSpacing}
          decelerationRate="fast"
          snapToAlignment="start"
        >
          {bookings.map((booking, index) => (
            <View key={booking.id} style={styles.bookingCardScrollItem}>
              {renderBookingCard(booking)}
            </View>
          ))}
        </ScrollView>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {/* Amend time slot overlay: booking schedule + update job time */}
      <Modal visible={showAmendModal} transparent animationType="fade">
        <Pressable
          style={styles.amendOverlay}
          onPress={() => !savingAmend && setShowAmendModal(false)}
        >
          <Pressable style={styles.amendModalBox} onPress={(e) => e.stopPropagation()}>
            <View style={styles.amendModalHeader}>
              <Text style={styles.amendModalTitle}>Amend time slot</Text>
              <TouchableOpacity
                onPress={() => setShowAmendModal(false)}
                hitSlop={12}
                disabled={savingAmend}
              >
                <Ionicons name="close" size={24} color={iconColors.secondary} />
              </TouchableOpacity>
            </View>
            {amendBooking && (
              <>
                <View style={styles.amendBookingSummary}>
                  <Text style={styles.amendSummaryLabel}>Booking</Text>
                  <Text style={styles.amendSummaryText}>{amendBooking.customer_name} • {amendBooking.service_type}</Text>
                  {amendBooking.location_address && (
                    <Text style={[styles.amendSummaryText, styles.amendSummarySub]} numberOfLines={1}>
                      {amendBooking.location_address}
                    </Text>
                  )}
                </View>
                <View style={styles.amendScheduleSection}>
                  <Text style={styles.amendSummaryLabel}>New date & time</Text>
                  {Platform.OS === 'android' && (
                    <TouchableOpacity
                      style={styles.amendDateButton}
                      onPress={() => setShowAmendDatePicker(true)}
                    >
                      <Ionicons name="calendar-outline" size={20} color={iconColors.primary} />
                      <Text style={styles.amendDateButtonText}>
                        {amendDate.toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' })}
                      </Text>
                    </TouchableOpacity>
                  )}
                  {(showAmendDatePicker || Platform.OS === 'ios') && (
                    <DateTimePicker
                      value={amendDate}
                      mode="datetime"
                      display={Platform.OS === 'ios' ? 'spinner' : 'default'}
                      onChange={(_, d) => {
                        if (d) setAmendDate(d);
                        if (Platform.OS === 'android') setShowAmendDatePicker(false);
                      }}
                      minimumDate={new Date()}
                    />
                  )}
                </View>
                <View style={styles.amendModalActions}>
                  <TouchableOpacity
                    style={styles.amendCancelButton}
                    onPress={() => setShowAmendModal(false)}
                    disabled={savingAmend}
                  >
                    <Text style={styles.amendCancelButtonText}>Cancel</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.amendSaveButton}
                    onPress={handleSaveAmendSlot}
                    disabled={savingAmend}
                  >
                    {savingAmend ? (
                      <Text style={styles.amendSaveButtonText}>Saving…</Text>
                    ) : (
                      <>
                        <Ionicons name="checkmark" size={18} color="#FFFFFF" />
                        <Text style={styles.amendSaveButtonText}>Update job</Text>
                      </>
                    )}
                  </TouchableOpacity>
                </View>
              </>
            )}
          </Pressable>
        </Pressable>
      </Modal>

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
          },
        ]}
      >
        {renderMap()}
        <View style={styles.headerOverlay}>
          <AppHeader
            title="Bookings"
            rightAction={
              <View style={styles.headerActions}>
                <TouchableOpacity
                  onPress={handleRecenter}
                  style={styles.recenterButton}
                >
                  <Ionicons name="locate" size={20} color={theme.primary} />
                </TouchableOpacity>
                <TouchableOpacity onPress={async () => {
                  await hapticFeedback('light');
                  loadBookings();
                }} style={styles.refreshButton}>
                  <Ionicons name="refresh" size={20} color={theme.primary} />
                </TouchableOpacity>
              </View>
            }
            accountType="business"
          />
        </View>
        {renderBookingCards()}
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },

  loadingContainer: { 
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center', 
    gap: 10, 
    paddingHorizontal: 24 
  },
  loadingText: { 
    fontFamily: 'Rubik_500Medium',
    color: SKY, 
    fontSize: 14,
    letterSpacing: 0,
  },

  amendOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  amendModalBox: {
    width: '100%',
    maxWidth: 400,
    backgroundColor: BG,
    borderRadius: CARD_BORDER_RADIUS,
    borderWidth: 0,
    borderColor: SKY_BLUE_BORDER,
    padding: 20,
  },
  amendModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  amendModalTitle: {
    fontFamily: 'Rubik_600SemiBold',
    fontSize: 18,
    color: SKY,
  },
  amendBookingSummary: {
    marginBottom: 16,
    paddingVertical: 12,
    paddingHorizontal: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
  },
  amendSummaryLabel: {
    fontFamily: 'Rubik_500Medium',
    fontSize: 12,
    color: 'rgba(255,255,255,0.6)',
    marginBottom: 4,
  },
  amendSummaryText: {
    fontFamily: 'Rubik_500Medium',
    fontSize: 14,
    color: SKY,
  },
  amendSummarySub: {
    fontSize: 12,
    marginTop: 2,
    opacity: 0.9,
  },
  amendScheduleSection: {
    marginBottom: 20,
  },
  amendDateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 12,
  },
  amendDateButtonText: {
    fontFamily: 'Rubik_500Medium',
    fontSize: 15,
    color: SKY,
  },
  amendModalActions: {
    flexDirection: 'row',
    gap: 12,
    justifyContent: 'flex-end',
  },
  amendCancelButton: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  amendCancelButtonText: {
    fontFamily: 'Rubik_500Medium',
    fontSize: 15,
    color: SKY,
  },
  amendSaveButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    backgroundColor: BUSINESS_PRIMARY,
  },
  amendSaveButtonText: {
    fontFamily: 'Rubik_600SemiBold',
    fontSize: 15,
    color: '#FFFFFF',
  },

  scrollView: { flex: 1 },
  scrollContent: { padding: 18, paddingBottom: 24 },
  scrollContentCards: { paddingHorizontal: 20 },

  filtersSection: {
    marginBottom: 14,
    paddingVertical: 8,
  },
  filtersContainer: {
    flexGrow: 0,
  },
  filtersContent: {
    gap: 10,
    paddingRight: 20,
    paddingLeft: 0,
    paddingVertical: 4,
  },
  filterButton: {
    marginRight: 0,
  },
  filterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.2)',
    minHeight: 40,
    position: 'relative',
    shadowColor: 'transparent',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0,
    shadowRadius: 4,
    elevation: 2,
  },
  filterChipActive: {
    borderWidth: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.12,
    shadowRadius: 6,
    elevation: 4,
  },
  filterIconContainer: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  filterText: {
    fontFamily: 'Rubik_600SemiBold',
    fontSize: 13,
    letterSpacing: -0.1,
    lineHeight: 18,
  },
  filterTextActive: {
    fontFamily: 'Rubik_700Bold',
  },
  activeIndicator: {
    position: 'absolute',
    bottom: 0,
    left: '50%',
    marginLeft: -16,
    width: 32,
    height: 2.5,
    borderRadius: 2,
  },

  emptyContainer: {
    position: 'absolute',
    bottom: 20,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
  emptyCardScrollItem: {
    width: width - 40,
    marginHorizontal: 20,
  },
  emptyCard: {
    padding: 48,
    borderRadius: CARD_BORDER_RADIUS,
    minHeight: 260,
    overflow: 'hidden',
    borderWidth: 0,
    borderColor: SKY_BLUE_BORDER,
    position: 'relative',
  },
  emptyContent: { 
    alignItems: 'center',
    gap: 8,
  },
  emptyTitle: { 
    fontFamily: 'Rubik_600SemiBold',
    color: '#F9FAFB', 
    fontSize: 20, 
    marginTop: 10, 
    marginBottom: 8,
    letterSpacing: -0.2,
  },
  emptyText: { 
    fontFamily: 'Rubik_400Regular',
    color: 'rgba(249,250,251,0.7)', 
    fontSize: 14, 
    textAlign: 'center', 
    lineHeight: 22,
    letterSpacing: 0,
  },

  bookingsList: { 
    gap: 16,
  },
  bookingCard: { 
    padding: 14,
    borderRadius: CARD_BORDER_RADIUS,
    marginBottom: 4,
    overflow: 'hidden',
  },

  bookingHeader: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'flex-start', 
    marginBottom: 12,
  },
  bookingInfo: { 
    flex: 1,
    gap: 6,
  },
  headerRight: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 10,
  },
  deleteButton: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: 'rgba(239,68,68,0.85)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 0,
    borderColor: 'rgba(220,38,38,0.6)',
  },
  deleteButtonInner: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(220,38,38,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  customerName: { 
    fontFamily: 'Rubik_600SemiBold',
    color: '#F9FAFB', 
    fontSize: 17, 
    marginBottom: 2,
    letterSpacing: -0.2,
    lineHeight: 22,
  },
  serviceType: { 
    fontFamily: 'Rubik_500Medium',
    color: 'rgba(249,250,251,0.75)', 
    fontSize: 13,
    letterSpacing: 0,
  },

  bookingDetails: { 
    gap: 8, 
    marginBottom: 12,
    paddingVertical: 10,
    borderTopWidth: 0,
    borderBottomWidth: 1,
    borderColor: 'rgba(135,206,235,0.1)',
  },
  detailRow: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 10,
  },
  detailText: { 
    fontFamily: 'Rubik_400Regular',
    color: 'rgba(249,250,251,0.8)', 
    fontSize: 14, 
    flex: 1,
    letterSpacing: 0,
    lineHeight: 20,
  },

  bookingActions: { 
    paddingTop: 0,
  },
  actionButton: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 4,
  },
  actionText: { 
    fontFamily: 'Rubik_600SemiBold',
    color: SKY, 
    fontSize: 15,
    letterSpacing: 0.1,
  },
  deleteAllContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    paddingHorizontal: 20,
    marginBottom: 12,
  },
  deleteAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 18,
    backgroundColor: 'rgba(239,68,68,0.85)',
    borderWidth: 0,
    borderColor: 'rgba(220,38,38,0.6)',
  },
  deleteAllIconWrapper: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    justifyContent: 'center',
  },
  deleteAllText: { 
    fontFamily: 'Rubik_600SemiBold',
    color: '#FFFFFF', 
    fontSize: 14,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  mapContainer: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 0,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  marker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: BUSINESS_PRIMARY,
    borderWidth: 0,
    borderColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    backgroundColor: 'transparent',
    elevation: 10,
  },
  content: {
    flex: 1,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  refreshButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  mapLoadingContainer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  mapLoadingText: {
    color: SKY,
    fontSize: 14,
    marginTop: 12,
  },
  mapMarkerPin: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapMarkerPinSelected: {
    transform: [{ scale: 1.15 }],
  },
  carMarkerImage: {
    width: 40,
    height: 40,
  },
  bookingCardContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
  bookingCardScrollItem: {
    width: width - 40,
    marginRight: 20,
  },
  bookingCardWrapper: {
    width: '100%',
    borderRadius: CARD_BORDER_RADIUS,
    overflow: 'hidden',
  },
  bookingCardBlur: {
    padding: 20,
    paddingBottom: 24,
    minHeight: 200,
    borderRadius: CARD_BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 0,
    borderColor: SKY_BLUE_BORDER,
    backgroundColor: 'transparent',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
  },
  jobCardBackground: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: CARD_BORDER_RADIUS,
    overflow: 'hidden',
  },
  jobCardBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: CARD_BORDER_RADIUS,
    borderWidth: 0,
    pointerEvents: 'none',
  },
  bookingCardHeader: {
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  bookingCardHeaderContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
  },
  servicePreviewIcon: {
    width: 28,
    height: 28,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.3)',
    overflow: 'hidden',
  },
  customerProfileImage: {
    width: 28,
    height: 28,
    borderRadius: 8,
  },
  bookingCardHeaderText: {
    flex: 1,
  },
  bookingCardTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    flex: 1,
  },
  bookingCardService: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 14,
    marginTop: 4,
  },
  bookingCardHeaderRight: {
    alignItems: 'flex-end',
  },
  bookingCardDetails: {
    gap: 8,
    marginBottom: 16,
  },
  bookingDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  bookingDetailText: {
    color: '#F9FAFB',
    fontSize: 14,
    flex: 1,
  },
  urgentText: {
    color: '#F59E0B',
    fontWeight: '600',
  },
  trackWashButton: {
    width: '100%',
    marginTop: 14,
    borderRadius: CARD_BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  trackWashGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 20,
    gap: 8,
  },
  trackWashText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  bookingCardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 20,
    marginTop: 12,
    paddingTop: 10,
    borderTopWidth: 0,
    borderTopColor: 'rgba(135,206,235,0.25)',
  },
  bookingCardFooterLink: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  bookingCardFooterLinkText: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 13,
    fontWeight: '600',
  },
  bookingCardActions: {
    width: '100%',
    marginTop: 8,
  },
  viewButton: {
    borderRadius: CARD_BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
  },
  viewButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
  },
  viewButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  liveBookingCard: {
    marginTop: 8,
    borderRadius: CARD_BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 0,
    borderColor: 'rgba(16,185,129,0.4)',
    position: 'relative',
  },
  liveBookingCardBackground: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: CARD_BORDER_RADIUS,
    overflow: 'hidden',
  },
  liveBookingCardBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: CARD_BORDER_RADIUS,
    borderWidth: 0,
    borderColor: 'rgba(16,185,129,0.4)',
    pointerEvents: 'none',
  },
  liveBookingCardContent: {
    padding: 16,
    zIndex: 1,
  },
  liveBookingCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  liveIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 0,
    borderColor: 'rgba(16,185,129,0.4)',
  },
  liveIndicatorDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  liveIndicatorText: {
    color: '#10B981',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  liveBookingCardTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 12,
  },
  liveDistanceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.1)',
  },
  liveDistanceText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  liveTrackingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
  },
  liveTrackingText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '500',
  },
  cardsLoadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  businessLocationMarker: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  hubMarkerImage: {
    width: 40,
    height: 40,
  },
  enRouteMarker: {
    opacity: 1,
  },
  enRouteText: {
    color: '#10B981',
    fontSize: 14,
    fontWeight: '600',
  },
  vehicleInfoContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  vehicleRegistration: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 1,
    fontFamily: 'monospace',
  },
});
