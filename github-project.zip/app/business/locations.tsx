import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Pressable,
  Dimensions,
  Animated,
  ActivityIndicator,
  ScrollView,
  Alert,
  Image,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET, HEADER_HEIGHT } from '../../src/components/shared/AppHeader';
import LoadingView from '../../src/components/shared/LoadingView';
import EmptyState from '../../src/components/shared/EmptyState';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors, CARD_BORDER_RADIUS, SKY_BLUE_BORDER } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { getTextColors, getIconColors } from '../../src/constants/themeColors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import * as ImagePicker from 'expo-image-picker';
import { DARK_MAP_STYLE } from '../../src/constants/mapStyles';
import { HUB_MAP_ICON } from '../../src/constants/mapIcons';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width, height } = Dimensions.get('window');
const CLOSE_ZOOM_DELTA = 0.01;
const MIN_BOUNDS_DELTA = 0.012;
const BG = colors.BG;
const SKY = colors.SKY;
const BUSINESS_PRIMARY = getAccountTheme('business').primary;
const STATS_SIDEBAR_WIDTH = Math.min(width * 0.82, 320);

interface Location {
  id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  status?: string | null;
  is_active?: boolean | null;
  created_at: string;
  header_image_url?: string | null;
  photo_url?: string | null;
  display_open_time?: string | null;
  display_close_time?: string | null;
  rating?: number;
  washesThisWeek?: number;
  revenueThisWeek?: number;
}

export default function BusinessLocations() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const theme = businessTheme ?? getAccountTheme('business', 'light');
  const isDarkMap = theme.mode === 'dark';
  const textColors = getTextColors(theme);
  const iconColors = getIconColors(theme);
  const iconAccent = colors.iconAccent;

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const mapRef = useRef<MapView>(null);
  const scrollViewRef = useRef<any>(null);

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, [markerPulse]);

  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLocationIndex, setSelectedLocationIndex] = useState(0);
  const [bookingsToday, setBookingsToday] = useState(0);
  const [revenueToday, setRevenueToday] = useState(0);
  const [avgRating, setAvgRating] = useState(0);
  const [showStatsSidebar, setShowStatsSidebar] = useState(false);
  const sidebarAnim = useRef(new Animated.Value(0)).current;
  const [initialRegion, setInitialRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: CLOSE_ZOOM_DELTA,
    longitudeDelta: CLOSE_ZOOM_DELTA,
  });
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: CLOSE_ZOOM_DELTA,
    longitudeDelta: CLOSE_ZOOM_DELTA,
  });
  // UI-only: local cover/profile URIs from image picker (no backend)
  const [localLocationImages, setLocalLocationImages] = useState<Record<string, { coverUri?: string; profileUri?: string }>>({});

  const cardWidth = width - 40;
  const cardSpacing = 20;

  // ✅ Use the org id, not the user id
  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  // Sync map with selected location
  useEffect(() => {
    if (locations.length > 0 && selectedLocationIndex < locations.length) {
      const selectedLocation = locations[selectedLocationIndex];
      if (selectedLocation.latitude && selectedLocation.longitude) {
        const newRegion: Region = {
          latitude: selectedLocation.latitude,
          longitude: selectedLocation.longitude,
          latitudeDelta: CLOSE_ZOOM_DELTA,
          longitudeDelta: CLOSE_ZOOM_DELTA,
        };
        setRegion(newRegion);
        mapRef.current?.animateToRegion(newRegion, 500);
      }
    }
  }, [selectedLocationIndex, locations]);

  // Scroll to selected location when index changes
  useEffect(() => {
    if (scrollViewRef.current && locations.length > 0 && selectedLocationIndex < locations.length) {
      const scrollX = selectedLocationIndex * (cardWidth + cardSpacing);
      scrollViewRef.current.scrollTo({
        x: scrollX,
        animated: true,
      });
    }
  }, [selectedLocationIndex, locations.length, cardWidth, cardSpacing]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    // Only load locations when we have a valid org context
    if (isOrgUser && organizationId) {
      loadLocations();
    } else {
      setLocations([]);
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, user?.userType, organizationId]);

  const getValeterIds = async (): Promise<string[]> => {
    if (!organizationId) return [];
    try {
      const { data: valeters, error: valErr } = await supabase
        .from('profiles')
        .select('id')
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      if (valErr) throw valErr;
      return (valeters || []).map((v: any) => v.id) as string[];
    } catch (error) {
      console.error('Error loading valeter IDs:', error);
      return [];
    }
  };

  const loadLocationStats = async (locationId: string): Promise<{ rating: number; washesThisWeek: number; revenueThisWeek: number }> => {
    try {
      const valeterIds = await getValeterIds();
      if (valeterIds.length === 0) {
        return { rating: 0, washesThisWeek: 0, revenueThisWeek: 0 };
      }

      // Get bookings for this location (we'll need to match by address or location_id if available)
      // For now, we'll get all bookings and filter by location if we have location_id in bookings
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);

      // Try to get bookings by location_id first, then fallback to address matching
      const { data: bookings, error: bookingsError } = await supabase
        .from('bookings')
        .select('id, price, status, rating, location_address, location_id')
        .in('valeter_id', valeterIds)
        .gte('created_at', weekAgo.toISOString());

      if (bookingsError) {
        console.warn('Error loading location stats:', bookingsError);
        return { rating: 0, washesThisWeek: 0, revenueThisWeek: 0 };
      }

      // Get location details to match by address
      const { data: locationData } = await supabase
        .from('car_wash_locations')
        .select('address')
        .eq('id', locationId)
        .maybeSingle();

      const locationAddress = locationData?.address;

      // Filter bookings for this location (by location_id or address match)
      const locationBookings = (bookings || []).filter((b: any) => {
        if (b.location_id === locationId) return true;
        if (locationAddress && b.location_address && 
            b.location_address.toLowerCase().includes(locationAddress.toLowerCase())) {
          return true;
        }
        return false;
      });

      const completed = locationBookings.filter((b: any) => b.status === 'completed');
      const washesThisWeek = completed.length;
      
      const revenueThisWeek = completed.reduce((sum: number, b: any) => {
        const price = Number(b.price || 0);
        return sum + (Number.isFinite(price) ? price : 0);
      }, 0);

      // Calculate average rating
      const ratings = completed
        .map((b: any) => Number(b.rating))
        .filter((r: number) => Number.isFinite(r) && r > 0);
      
      const rating = ratings.length > 0
        ? ratings.reduce((sum: number, r: number) => sum + r, 0) / ratings.length
        : 0;

      return {
        rating: Math.round(rating * 10) / 10,
        washesThisWeek,
        revenueThisWeek: Math.round(revenueThisWeek),
      };
    } catch (error) {
      console.error('Error loading location stats:', error);
      return { rating: 0, washesThisWeek: 0, revenueThisWeek: 0 };
    }
  };

  const loadLocations = async () => {
    if (!isOrgUser || !organizationId) return;

    try {
      setLoading(true);
      const baseFields = ['id', 'name', 'address', 'latitude', 'longitude', 'status', 'is_active', 'created_at'];
      const optionalCols = ['header_image_url', 'photo_url'];
      let fields = [...baseFields, ...optionalCols];
      let loadedLocations: Location[] = [];
      for (let attempt = 0; attempt < 5; attempt++) {
        const { data, error } = await supabase
          .from('car_wash_locations')
          .select(fields.join(','))
          .eq('organization_id', organizationId)
          .order('created_at', { ascending: false });
        if (!error && data != null) {
          loadedLocations = (data as Location[]) || [];
          break;
        }
        if (error?.code === '42703' && error?.message) {
          const match = error.message.match(/column\s+(?:car_wash_locations\.)?([a-zA-Z0-9_]+)\s+does\s+not\s+exist/i) ||
            error.message.match(/column\s+"[^"]*"\.([a-zA-Z0-9_]+)\s+does\s+not\s+exist/i);
          const missing = match?.[1];
          if (missing && fields.includes(missing)) {
            fields = fields.filter((f) => f !== missing);
            continue;
          }
        }
        throw error;
      }

      // Attach opening hours (Monday = day 0) for display if table exists
      try {
        const ids = loadedLocations.map((l) => l.id).filter(Boolean);
        if (ids.length > 0) {
          const { data: hoursRows } = await supabase
            .from('location_opening_hours')
            .select('location_id, open_time, close_time, is_open')
            .in('location_id', ids)
            .eq('day_of_week', 0);
          const hoursByLocation = new Map<string, { open_time: string | null; close_time: string | null; is_open: boolean }>();
          (hoursRows || []).forEach((r: any) => {
            hoursByLocation.set(r.location_id, {
              open_time: r.open_time ?? null,
              close_time: r.close_time ?? null,
              is_open: !!r.is_open,
            });
          });
          loadedLocations = loadedLocations.map((loc) => {
            const h = hoursByLocation.get(loc.id);
            return {
              ...loc,
              display_open_time: h?.is_open ? h.open_time : null,
              display_close_time: h?.is_open ? h.close_time : null,
            };
          });
        }
      } catch (_) {
        // location_opening_hours table may not exist
      }

      const locationsWithStats = await Promise.all(
        loadedLocations.map(async (location) => {
          const stats = await loadLocationStats(location.id);
          return { ...location, ...stats };
        })
      );

      setLocations(locationsWithStats);

      // Update map region to show all locations
      const locationsWithCoords = loadedLocations.filter(l => l.latitude && l.longitude);
      if (locationsWithCoords.length > 0) {
        const lats = locationsWithCoords.map(l => l.latitude!);
        const lngs = locationsWithCoords.map(l => l.longitude!);
        const minLat = Math.min(...lats);
        const maxLat = Math.max(...lats);
        const minLng = Math.min(...lngs);
        const maxLng = Math.max(...lngs);
        
        const newRegion = {
          latitude: (minLat + maxLat) / 2,
          longitude: (minLng + maxLng) / 2,
          latitudeDelta: Math.max((maxLat - minLat) * 1.5, MIN_BOUNDS_DELTA),
          longitudeDelta: Math.max((maxLng - minLng) * 1.5, MIN_BOUNDS_DELTA),
        };
        setRegion(newRegion);
        setInitialRegion(newRegion);
      }
    } catch (error: any) {
      console.error('Error loading locations:', error);
      Alert.alert('Error', error?.message || 'Failed to load locations');
    } finally {
      setLoading(false);
    }
  };

  // Refetch locations when returning from Add Location page
  useFocusEffect(
    useCallback(() => {
      if (isOrgUser && organizationId) {
        loadLocations();
      }
    }, [organizationId, isOrgUser])
  );

  useEffect(() => {
    Animated.timing(sidebarAnim, {
      toValue: showStatsSidebar ? 1 : 0,
      duration: 250,
      useNativeDriver: true,
    }).start();
  }, [showStatsSidebar, sidebarAnim]);

  const openStatsSidebar = useCallback(async () => {
    await hapticFeedback('light');
    setShowStatsSidebar(true);
  }, []);
  const closeStatsSidebar = useCallback(async () => {
    await hapticFeedback('light');
    setShowStatsSidebar(false);
  }, []);

  if (loading) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  // If they somehow reached this screen without an org context, give a clear message
  if (!isOrgUser || !organizationId) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Locations" accountType="business" />
        <View style={styles.loadingContainer}>
          <Ionicons name="alert-circle-outline" size={42} color={iconColors.primary} style={{ opacity: 0.85 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This business account isn’t linked to an organization yet.
            {'\n'}If you think this is wrong, log out and back in.
          </Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }}
            style={[styles.addButton, { marginTop: 10 }]}
          >
            <Ionicons name="arrow-back" size={20} color={iconColors.primary} />
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const handleToggleLocationStatus = async (locationId: string, currentStatus: boolean) => {
    try {
      await hapticFeedback('medium');
      const newStatus = !currentStatus;

      const { error } = await supabase
        .from('car_wash_locations')
        .update({ 
          is_active: newStatus,
          status: newStatus ? 'active' : 'inactive'
        })
        .eq('id', locationId)
        .eq('organization_id', organizationId!);

      if (error) throw error;

      // Update local state
      setLocations(prev => prev.map(loc => 
        loc.id === locationId ? { ...loc, is_active: newStatus, status: newStatus ? 'active' : 'inactive' } : loc
      ));
      
      Alert.alert(
        newStatus ? 'Location Opened' : 'Location Closed',
        newStatus 
          ? 'This location is now open for bookings.'
          : 'This location is now closed. Customers cannot book at this location.'
      );
    } catch (error: any) {
      console.error('Error toggling location status:', error);
      Alert.alert('Error', error?.message || 'Failed to update location status');
    }
  };

  const formatTime = (t: string | null | undefined) => {
    if (!t || typeof t !== 'string') return null;
    const s = t.trim();
    if (!s) return null;
    return s.length === 5 ? s : s.length === 4 && s.indexOf(':') === -1 ? `${s.slice(0, 2)}:${s.slice(2)}` : s;
  };

  const pickImageForLocation = async (locationId: string, kind: 'cover' | 'profile') => {
    try {
      await hapticFeedback('light');
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permission needed', 'Allow photo access to add an image.');
        return;
      }
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ['images'],
        allowsEditing: kind === 'profile',
        aspect: kind === 'profile' ? [1, 1] : undefined,
        quality: 0.8,
      });
      if (result.canceled || !result.assets?.[0]?.uri) return;
      const uri = result.assets[0].uri;
      setLocalLocationImages((prev) => ({
        ...prev,
        [locationId]: {
          ...prev[locationId],
          [kind === 'cover' ? 'coverUri' : 'profileUri']: uri,
        },
      }));
    } catch (e: any) {
      console.warn('Image picker:', e);
      Alert.alert('Error', e?.message ?? 'Could not open photo library');
    }
  };

  const renderLocationCard = (location: Location) => {
    const isOpen = location.is_active !== false;
    const addressParts = location.address?.split(',') || [];
    const streetName = addressParts[0]?.trim() || location.address || 'Address not set';
    const local = localLocationImages[location.id];
    const coverUri = local?.coverUri ?? location.header_image_url ?? location.photo_url ?? null;
    const profileUri = local?.profileUri ?? location.photo_url ?? location.header_image_url ?? null;
    const openStr = formatTime(location.display_open_time);
    const closeStr = formatTime(location.display_close_time);
    const hoursLabel = openStr && closeStr ? `${openStr} – ${closeStr}` : openStr || closeStr ? (openStr || closeStr) : null;

    return (
      <View style={styles.locationCardWrapper}>
        <BlurView intensity={60} tint="dark" style={styles.locationCardBlur}>
          <View style={styles.jobCardBackground} />

          {/* Cover image — placeholder + upload (UI only) */}
          <TouchableOpacity
            style={styles.locationCardCoverWrap}
            activeOpacity={0.9}
            onPress={() => pickImageForLocation(location.id, 'cover')}
          >
            {coverUri ? (
              <Image source={{ uri: coverUri }} style={styles.locationCardCover} resizeMode="cover" />
            ) : (
              <LinearGradient
                colors={['rgba(125,211,252,0.35)', 'rgba(30,58,138,0.4)']}
                style={StyleSheet.absoluteFill}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              />
            )}
            <View style={styles.locationCardCoverOverlay} />
            {!coverUri && (
              <View style={styles.locationCardCoverPlaceholder}>
                <Ionicons name="image-outline" size={32} color="rgba(255,255,255,0.9)" />
                <Text style={styles.locationCardCoverPlaceholderText}>Add cover photo</Text>
              </View>
            )}
          </TouchableOpacity>

          {/* Content: profile pic (pin) + name/address/hours + delete */}
          <View style={styles.locationCardBody}>
            <View style={styles.locationCardProfileRow}>
              <TouchableOpacity
                style={styles.locationCardProfileWrap}
                activeOpacity={0.8}
                onPress={() => pickImageForLocation(location.id, 'profile')}
              >
                {profileUri ? (
                  <Image source={{ uri: profileUri }} style={styles.locationCardProfileImg} resizeMode="cover" />
                ) : (
                  <View style={styles.locationCardProfilePlaceholder}>
                    <Ionicons name="image-outline" size={24} color={theme.primary} />
                    <Text style={styles.locationCardProfilePlaceholderText}>Photo</Text>
                  </View>
                )}
              </TouchableOpacity>
              <View style={styles.locationCardInfo}>
                <Text style={styles.locationCardTitle} numberOfLines={1}>{location.name}</Text>
                <Text style={styles.locationCardAddress} numberOfLines={1}>{streetName}</Text>
                {hoursLabel ? (
                  <View style={styles.locationCardHoursRow}>
                    <Ionicons name="time-outline" size={12} color="rgba(249,250,251,0.7)" />
                    <Text style={styles.locationCardHours}>{hoursLabel}</Text>
                  </View>
                ) : null}
                <TouchableOpacity
                  onPress={() => handleToggleLocationStatus(location.id, isOpen)}
                  style={styles.statusToggleButton}
                  activeOpacity={0.8}
                >
                  <View style={[styles.statusPill, isOpen && styles.statusPillOpen]}>
                    <View style={[styles.statusDot, isOpen && styles.statusDotOpen]} />
                    <Text style={[styles.statusText, isOpen && styles.statusTextOpen]}>
                      {isOpen ? 'OPEN' : 'CLOSED'}
                    </Text>
                  </View>
                </TouchableOpacity>
              </View>
              <TouchableOpacity
                onPress={async (e: any) => {
                  e?.stopPropagation?.();
                  await hapticFeedback('light');
                  handleDeleteLocation(location.id);
                }}
                style={styles.locationCardDeleteBtn}
                activeOpacity={0.7}
              >
                <Ionicons name="trash-outline" size={20} color="#EF4444" />
              </TouchableOpacity>
            </View>
          </View>

          {/* Action Buttons */}
          <View style={styles.locationCardActions}>
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                router.push({ pathname: '/business/bookings', params: { locationId: location.id } } as any);
              }}
              style={[styles.actionButton, styles.viewBookingsButton]}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={[theme.primary, theme.primaryAlt]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.actionButtonGradient}
              >
                <Ionicons name="calendar" size={18} color="#FFFFFF" />
                <Text style={styles.actionButtonText}>View Bookings</Text>
              </LinearGradient>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                router.push(`/business/locations/${location.id}` as any);
              }}
              style={[styles.actionButton, styles.manageButton]}
              activeOpacity={0.8}
            >
              <BlurView intensity={40} tint="dark" style={styles.manageButtonBlur}>
                <View style={styles.manageButtonBackground} />
                <Ionicons name="settings" size={18} color={iconColors.primary} />
                <Text style={styles.manageButtonText}>Manage</Text>
              </BlurView>
            </TouchableOpacity>
          </View>
        </BlurView>
      </View>
    );
  };

  // Render map with location markers
  const renderMap = () => {
    if (loading) {
      return (
        <View style={styles.mapContainer}>
          <LoadingView style={styles.mapLoadingContainer} />
        </View>
      );
    }

    return (
      <View style={styles.mapContainer}>
        <MapView
          ref={mapRef}
          style={styles.map}
          region={region}
          showsUserLocation={false}
          showsMyLocationButton={false}
          mapType="standard"
          customMapStyle={isDarkMap ? DARK_MAP_STYLE : undefined}
          mapPadding={{ top: 0, bottom: height * 0.4, left: 0, right: 0 }}
          loadingEnabled={true}
          loadingIndicatorColor={theme.primary}
          followsUserLocation={false}
        >
          {locations.filter(l => l.latitude && l.longitude).map((location, index) => {
            const isSelected = index === selectedLocationIndex;
            return (
              <Marker
                key={location.id}
                coordinate={{
                  latitude: location.latitude!,
                  longitude: location.longitude!,
                }}
                anchor={{ x: 0.5, y: 0.5 }}
                tracksViewChanges={false}
              >
                <Animated.View style={[styles.locationMarker, isSelected && styles.locationMarkerSelected, { transform: [{ scale: markerPulse }] }]}>
                  <Image
                    source={HUB_MAP_ICON}
                    style={styles.spongeMarkerImage}
                    resizeMode="contain"
                  />
                </Animated.View>
              </Marker>
            );
          })}
        </MapView>
      </View>
    );
  };

  const handleScroll = (event: any) => {
    const scrollPosition = event.nativeEvent.contentOffset.x;
    const newIndex = Math.round(scrollPosition / (cardWidth + cardSpacing));
    
    if (newIndex >= 0 && newIndex < locations.length && newIndex !== selectedLocationIndex) {
      setSelectedLocationIndex(newIndex);
    }
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    const selected = locations.length > 0 && selectedLocationIndex < locations.length ? locations[selectedLocationIndex] : null;
    if (selected?.latitude != null && selected?.longitude != null) {
      const newRegion: Region = {
        latitude: selected.latitude,
        longitude: selected.longitude,
        latitudeDelta: CLOSE_ZOOM_DELTA,
        longitudeDelta: CLOSE_ZOOM_DELTA,
      };
      setRegion(newRegion);
      mapRef.current?.animateToRegion(newRegion, 500);
    } else if (initialRegion) {
      setRegion(initialRegion);
      mapRef.current?.animateToRegion(initialRegion, 500);
    }
  };

  const handleDeleteLocation = async (locationId: string) => {
    Alert.alert(
      'Delete Location',
      'Are you sure you want to delete this location? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await hapticFeedback('medium');

              const { error } = await supabase
                .from('car_wash_locations')
                .delete()
                .eq('id', locationId)
                .eq('organization_id', organizationId!);

              if (error) throw error;

              await loadLocations();
              Alert.alert('Success', 'Location deleted');
            } catch (error: any) {
              console.error('Error deleting location:', error);
              Alert.alert('Error', error?.message || 'Failed to delete location');
            }
          },
        },
      ]
    );
  };

  const selectedLocation = locations.length > 0 && locations[selectedLocationIndex] ? locations[selectedLocationIndex] : null;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
        {renderMap()}
        
        <View style={styles.headerOverlay}>
          <AppHeader
            title="Locations"
            rightAction={
              <View style={styles.headerActions}>
                <TouchableOpacity
                  onPress={handleRecenter}
                  style={styles.headerActionButton}
                >
                  <Ionicons name="locate" size={20} color={theme.primary} />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    router.push('/business/locations/add');
                  }}
                  style={styles.headerActionButton}
                >
                  <Ionicons name="add" size={24} color={theme.primary} />
                </TouchableOpacity>
              </View>
            }
            accountType="business"
          />
        </View>

        {/* Floating info icon - opens stats sidebar */}
        <TouchableOpacity
          onPress={openStatsSidebar}
          style={[styles.statsFloatingButton, { top: insets.top + HEADER_HEIGHT + 12 }]}
          activeOpacity={0.8}
        >
          <BlurView intensity={40} tint="dark" style={styles.statsFloatingButtonBlur}>
            <Ionicons name="information-circle" size={28} color={theme.primary} />
          </BlurView>
        </TouchableOpacity>

        {/* Stats sidebar - slides in from right */}
        {showStatsSidebar && (
          <Pressable style={StyleSheet.absoluteFill} onPress={closeStatsSidebar}>
            <Animated.View
              style={[
                StyleSheet.absoluteFill,
                styles.statsSidebarBackdrop,
                { opacity: sidebarAnim.interpolate({ inputRange: [0, 1], outputRange: [0, 0.6] }) },
              ]}
            />
          </Pressable>
        )}
        <Animated.View
          pointerEvents={showStatsSidebar ? 'auto' : 'none'}
            style={[
            styles.statsSidebarPanel,
            {
              transform: [
                { translateX: sidebarAnim.interpolate({ inputRange: [0, 1], outputRange: [STATS_SIDEBAR_WIDTH, 0] }) },
              ],
            },
          ]}
        >
          <BlurView intensity={80} tint="dark" style={[styles.statsSidebarBlur, { paddingTop: (insets?.top ?? 44) + 8 }]}>
            <View style={styles.statsSidebarHeader}>
              <Text style={styles.statsSidebarTitle}>Stats</Text>
              <TouchableOpacity onPress={closeStatsSidebar} style={styles.statsSidebarCloseBtn} activeOpacity={0.7}>
                <Ionicons name="close" size={24} color={iconColors.primary} />
              </TouchableOpacity>
            </View>
            <View style={styles.statsSidebarContent}>
              {locations.length > 0 && selectedLocation ? (
                <>
                  <BlurView intensity={20} tint="dark" style={styles.statsSidebarStatBox}>
                    <View style={styles.locationStatBoxContent}>
                      <Ionicons name="calendar-outline" size={20} color={iconAccent.primary} />
                      <Text style={styles.locationStatLabel}>Bookings Today</Text>
                      <Text style={styles.locationStatValue}>{bookingsToday}</Text>
                    </View>
                  </BlurView>
                  <BlurView intensity={20} tint="dark" style={styles.statsSidebarStatBox}>
                    <View style={styles.locationStatBoxContent}>
                      <Ionicons name="wallet-outline" size={20} color={iconAccent.money} />
                      <Text style={styles.locationStatLabel}>Revenue</Text>
                      <Text style={styles.locationStatValue}>£{revenueToday}</Text>
                    </View>
                  </BlurView>
                  <BlurView intensity={20} tint="dark" style={styles.statsSidebarStatBox}>
                    <View style={styles.locationStatBoxContent}>
                      <Ionicons name="star-outline" size={20} color={iconAccent.highlight} />
                      <Text style={styles.locationStatLabel}>Avg Rating</Text>
                      <Text style={styles.locationStatValue}>{selectedLocation.rating?.toFixed(1) || '0.0'}</Text>
                    </View>
                  </BlurView>
                  {selectedLocation.washesThisWeek != null && (
                    <BlurView intensity={20} tint="dark" style={styles.statsSidebarStatBox}>
                      <View style={styles.locationStatBoxContent}>
                        <Ionicons name="water-outline" size={20} color={theme.primary} />
                        <Text style={styles.locationStatLabel}>Washes this week</Text>
                        <Text style={styles.locationStatValue}>{selectedLocation.washesThisWeek}</Text>
                      </View>
                    </BlurView>
                  )}
                </>
              ) : (
                <Text style={styles.statsSidebarEmpty}>Select a location to see stats</Text>
              )}
            </View>
          </BlurView>
        </Animated.View>

          {locations.length > 1 && (
            <View style={styles.headerIndicatorContainer}>
              {locations.map((location, index) => (
                <View
                  key={location.id || `indicator-${index}`}
                  style={[
                    styles.headerIndicatorDot,
                    index === selectedLocationIndex && styles.headerIndicatorDotActive,
                  ]}
                />
              ))}
            </View>
          )}
        </Animated.View>

        {/* Location Cards - Horizontal Scrolling */}
        {locations.length === 0 ? (
          <View style={[styles.emptyContainer, { paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12 }]}>
            <EmptyState
              icon="location-outline"
              title="No locations yet"
              subtitle="Add your first physical location to start accepting bookings at your business"
              actionLabel="Add location"
              onAction={() => router.push('/business/locations/add')}
              iconColor={theme.primary ?? SKY}
            />
          </View>
        ) : (
          <View style={[styles.locationCardContainer, { paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12 }]}>
            <ScrollView
              ref={scrollViewRef}
              horizontal
              pagingEnabled={false}
              showsHorizontalScrollIndicator={false}
              onScroll={handleScroll}
              scrollEventThrottle={16}
              contentContainerStyle={styles.scrollContent}
              snapToInterval={cardWidth + cardSpacing}
              decelerationRate="fast"
              snapToAlignment="start"
            >
              {locations.map((location, index) => (
                <View key={location.id} style={styles.locationCardScrollItem}>
                  {renderLocationCard(location)}
                </View>
              ))}
            </ScrollView>
          </View>
        )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 24,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  addButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 24,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    minHeight: 400,
  },
  emptyCard: {
    padding: 40,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '600',
    marginTop: 10,
    marginBottom: 12,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 14,
  },
  addFirstButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addFirstButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 32,
  },
  addFirstButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
  locationsList: {
    gap: 16,
  },
  locationCard: {
    padding: 16,
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    marginBottom: 12,
  },
  locationIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  locationInfo: {
    flex: 1,
  },
  locationName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 6,
  },
  locationAddress: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    lineHeight: 20,
  },
  locationFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  content: {
    flex: 1,
  },
  mapContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  mapLoadingContainer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  mapLoadingText: {
    color: SKY,
    fontSize: 14,
    marginTop: 12,
  },
  locationMarker: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'transparent',
    borderWidth: 0,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  spongeMarkerImage: {
    width: 40,
    height: 40,
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    backgroundColor: 'transparent',
    elevation: 10,
  },
  statsFloatingButton: {
    position: 'absolute',
    right: 16,
    zIndex: 999,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
  },
  statsFloatingButtonBlur: {
    width: 44,
    height: 44,
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 0,
    borderColor: 'rgba(255,255,255,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  statsSidebarBackdrop: {
    backgroundColor: '#000',
    zIndex: 1001,
  },
  statsSidebarPanel: {
    position: 'absolute',
    right: 0,
    top: 0,
    bottom: 0,
    width: STATS_SIDEBAR_WIDTH,
    zIndex: 1002,
    elevation: 12,
    shadowColor: '#000',
    shadowOffset: { width: -4, height: 0 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
  },
  statsSidebarBlur: {
    flex: 1,
    paddingHorizontal: 20,
    paddingBottom: 24,
    borderLeftWidth: 1,
    borderLeftColor: 'rgba(255,255,255,0.08)',
  },
  statsSidebarHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  statsSidebarTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
  },
  statsSidebarCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statsSidebarContent: {
    gap: 12,
  },
  statsSidebarStatBox: {
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 0,
    borderColor: 'rgba(255,255,255,0.06)',
  },
  statsSidebarEmpty: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 14,
    textAlign: 'center',
    marginTop: 20,
  },
  locationCardContainer: {
    position: 'absolute',
    bottom: 20,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
  locationCardScrollItem: {
    width: width - 40,
    marginRight: 20,
  },
  locationCardWrapper: {
    width: '100%',
    borderRadius: CARD_BORDER_RADIUS,
    overflow: 'hidden',
  },
  locationCardBlur: {
    padding: 0,
    paddingBottom: 20,
    minHeight: 200,
    borderRadius: CARD_BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 0,
    borderColor: SKY_BLUE_BORDER,
    backgroundColor: 'transparent',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
  },
  locationCardCoverWrap: {
    height: 100,
    width: '100%',
    backgroundColor: 'rgba(30,58,138,0.5)',
    overflow: 'hidden',
  },
  locationCardCover: {
    width: '100%',
    height: '100%',
  },
  locationCardCoverOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.25)',
  },
  locationCardCoverPlaceholder: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 6,
  },
  locationCardCoverPlaceholderText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 12,
    fontWeight: '600',
  },
  locationCardBody: {
    paddingHorizontal: 16,
    paddingTop: 12,
  },
  locationCardProfileRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  locationCardProfileWrap: {
    width: 52,
    height: 52,
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 0,
    borderColor: 'rgba(125,211,252,0.4)',
    backgroundColor: 'rgba(30,58,138,0.4)',
  },
  locationCardProfileImg: {
    width: '100%',
    height: '100%',
  },
  locationCardProfilePlaceholder: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 2,
  },
  locationCardProfilePlaceholderText: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 10,
    fontWeight: '600',
  },
  locationCardInfo: {
    flex: 1,
    minWidth: 0,
  },
  locationCardTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 2,
  },
  locationCardAddress: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 13,
    marginBottom: 6,
  },
  locationCardHoursRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginBottom: 8,
  },
  locationCardHours: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  locationCardDeleteBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(239,68,68,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  statusBadgeSmall: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
  },
  statusDotSmall: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  statusTextSmall: {
    fontSize: 12,
    fontWeight: '600',
  },
  locationStatsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    gap: 10,
    marginTop: 12,
    marginBottom: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.08)',
  },
  locationStatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  locationStatText: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 12,
    fontWeight: '600',
  },
  locationStatEmoji: {
    fontSize: 12,
  },
  locationStatusSection: {
    marginBottom: 0,
  },
  statusToggleButton: {
    alignSelf: 'flex-start',
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: 'rgba(239,68,68,0.2)',
    borderWidth: 0,
    borderColor: 'rgba(239,68,68,0.3)',
  },
  statusPillOpen: {
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderColor: 'rgba(16,185,129,0.3)',
  },
  statusDotOpen: {
    backgroundColor: '#10B981',
  },
  statusTextOpen: {
    color: '#10B981',
  },
  locationCardActions: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 16,
    paddingHorizontal: 16,
  },
  actionButton: {
    flex: 1,
    borderRadius: 14,
    overflow: 'hidden',
  },
  viewBookingsButton: {
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
  },
  actionButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    gap: 4,
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  manageButton: {
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  manageButtonBlur: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    gap: 4,
    borderRadius: 14,
    backgroundColor: 'transparent',
    position: 'relative',
  },
  manageButtonBackground: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 14,
  },
  manageButtonText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  headerIndicatorContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
    paddingBottom: 12,
  },
  headerIndicatorDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  headerIndicatorDotActive: {
    width: 24,
    backgroundColor: SKY,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  headerActionButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  locationMarkerSelected: {
    transform: [{ scale: 1.1 }],
    borderWidth: 0,
  },
  inputContainer: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 0,
    borderColor: 'rgba(135,206,235,0.2)',
    minHeight: 50,
  },
  popupOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.75)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  popupContent: {
    width: '100%',
    maxWidth: 400,
    maxHeight: '80%',
    borderRadius: 24,
    overflow: 'hidden',
  },
  popupBlur: {
    padding: 0,
    borderRadius: 24,
    overflow: 'visible',
    borderWidth: 0,
    backgroundColor: 'transparent',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
  },
  jobCardBackground: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 24,
  },
  jobCardBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 24,
    borderWidth: 0,
    pointerEvents: 'none',
  },
  popupCloseButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  popupCoverContainer: {
    width: '100%',
    height: 200,
    overflow: 'hidden',
  },
  popupCoverImage: {
    width: '100%',
    height: '100%',
  },
  popupBody: {
    padding: 24,
    gap: 16,
  },
  popupTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  popupDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  popupDetailText: {
    color: '#F9FAFB',
    fontSize: 15,
    flex: 1,
  },
  popupStatusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
  },
  popupStatusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  popupStatusText: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 14,
    fontWeight: '600',
  },
  popupViewButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    marginTop: 8,
  },
  popupViewButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
  },
  popupViewButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  locationStatsUnderHeader: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 100, // Above map but below header overlay (1000)
    flexDirection: 'row',
    gap: 10,
    backgroundColor: 'transparent',
    paddingRight: 8, // Space for close button
  },
  locationStatBox: {
    flex: 1,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 0,
    borderColor: 'rgba(255,255,255,0.05)',
  },
  statsCloseButton: {
    position: 'absolute',
    top: -6,
    right: -6,
    zIndex: 200,
  },
  statsCloseButtonBlur: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 0,
    borderColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  locationStatBoxContent: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    padding: 12,
  },
  locationStatLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 11,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  locationStatValue: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  mapStatText: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '600',
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
  },
});
