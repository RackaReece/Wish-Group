import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  RefreshControl,
  Linking,
  Platform,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_HEIGHT } from '../../src/components/shared/AppHeader';
import LoadingView from '../../src/components/shared/LoadingView';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { getTextColors, getIconColors, getBackgroundColors } from '../../src/constants/themeColors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const SKY = colors.SKY;
const BG = colors.BG;

const PLATFORM_FEE_PERCENT = 20;

type OrderRow = {
  id: string;
  status: string;
  customer_name: string | null;
  service_name: string | null;
  location_address: string | null;
  location_id: string | null;
  location_name: string | null;
  location_phone: string | null;
  location_email: string | null;
  vehicle_type: string | null;
  vehicle_info: string | null;
  scheduled_at: string | null;
  completed_at: string | null;
  price: number | null;
  created_at: string;
  payment_method: string | null;
};

type ReceiptBusinessDetails = {
  name: string;
  address: string | null;
  phone: string | null;
  email: string | null;
};

type ViewMode = 'by_site' | 'receipt_summary';

function getMissingColumn(message?: string | null): string | null {
  const m = (message || '').match(/column\s+bookings\.([a-zA-Z0-9_]+)\s+does\s+not\s+exist/i);
  return m?.[1] ?? null;
}

function receiptHtml(order: OrderRow, business: ReceiptBusinessDetails): string {
  const date = order.completed_at || order.scheduled_at || order.created_at;
  const dateStr = date ? new Date(date).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }) : '—';
  const total = order.price ?? 0;
  const washSubtotal = total / (1 + PLATFORM_FEE_PERCENT / 100);
  const platformFee = total - washSubtotal;
  const carDisplay = [order.vehicle_info, order.vehicle_type].filter(Boolean).join(' · ') || '—';
  const paymentDisplay = order.payment_method || 'Card (Stripe)';

  const bizLines: string[] = [];
  if (business.address) bizLines.push(`<p class="biz-line">${escapeHtml(business.address)}</p>`);
  if (business.phone) bizLines.push(`<p class="biz-line">Tel: ${escapeHtml(business.phone)}</p>`);
  if (business.email) bizLines.push(`<p class="biz-line">${escapeHtml(business.email)}</p>`);
  const businessBlock = bizLines.length ? `<div class="business-details">${bizLines.join('')}</div>` : '';

  const siteLines: string[] = [];
  if (order.location_name || order.location_address) {
    siteLines.push(`<p class="biz-line"><strong>Site:</strong> ${escapeHtml(order.location_name || order.location_address || '—')}</p>`);
    if (order.location_address && order.location_address !== (order.location_name || '')) {
      siteLines.push(`<p class="biz-line">${escapeHtml(order.location_address)}</p>`);
    }
    if (order.location_phone) siteLines.push(`<p class="biz-line">Tel: ${escapeHtml(order.location_phone)}</p>`);
    if (order.location_email) siteLines.push(`<p class="biz-line">${escapeHtml(order.location_email)}</p>`);
  }
  const siteBlock = siteLines.length ? `<div class="business-details">${siteLines.join('')}</div>` : '';

  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 24px; color: #1e293b; max-width: 420px; margin: 0 auto; }
    h1 { font-size: 22px; margin: 0 0 4px; color: #0f172a; }
    .sub { font-size: 12px; color: #64748b; margin-bottom: 16px; }
    .business-details { font-size: 12px; color: #475569; margin-bottom: 20px; line-height: 1.5; }
    .biz-line { margin: 2px 0; }
    .receipt-title { font-size: 14px; font-weight: 700; color: #0f172a; margin: 16px 0 8px; padding-bottom: 4px; border-bottom: 1px solid #e2e8f0; }
    table { width: 100%; border-collapse: collapse; margin: 12px 0; font-size: 14px; }
    th { text-align: left; font-size: 11px; text-transform: uppercase; color: #64748b; padding: 6px 0; border-bottom: 1px solid #e2e8f0; width: 38%; }
    td { padding: 6px 0; border-bottom: 1px solid #f1f5f9; }
    .cost-table th { width: 60%; }
    .cost-table td { text-align: right; }
    .total-row { font-weight: 700; font-size: 16px; padding-top: 10px; border-top: 2px solid #0f172a; }
    .total-row td { border-bottom: none; padding-bottom: 0; }
    .receipt-footer { font-size: 11px; color: #94a3b8; margin-top: 24px; }
  </style>
</head>
<body>
  <h1>${escapeHtml(business.name || 'Just Wish Group Ltd')}</h1>
  ${businessBlock}
  ${siteBlock}
  <p class="receipt-title">Receipt</p>
  <table>
    <tr><th>Order ID</th><td>${order.id.slice(0, 8).toUpperCase()}</td></tr>
    <tr><th>Date</th><td>${dateStr}</td></tr>
    <tr><th>Customer</th><td>${escapeHtml(order.customer_name || 'Customer')}</td></tr>
    <tr><th>Car / vehicle</th><td>${escapeHtml(carDisplay)}</td></tr>
    <tr><th>Service</th><td>${escapeHtml(order.service_name || 'Wash')}</td></tr>
    <tr><th>Payment method</th><td>${escapeHtml(paymentDisplay)}</td></tr>
  </table>
  <table class="cost-table">
    <tr><th>Wash</th><td>£${washSubtotal.toFixed(2)}</td></tr>
    <tr><th>Platform fee (${PLATFORM_FEE_PERCENT}%)</th><td>£${platformFee.toFixed(2)}</td></tr>
    <tr class="total-row"><th>Total paid</th><td>£${total.toFixed(2)}</td></tr>
  </table>
  <p class="receipt-footer">Thank you for your business.</p>
</body>
</html>
  `.trim();
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function formatOrderDate(order: OrderRow): string {
  const date = order.completed_at || order.scheduled_at || order.created_at;
  if (!date) return '—';
  return new Date(date).toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
}

export default function BusinessOrders() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const theme = businessTheme ?? getAccountTheme('business', 'light');
  const textColors = getTextColors(theme);
  const iconColors = getIconColors(theme);
  const bgColors = getBackgroundColors(theme);

  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [businessName, setBusinessName] = useState('Just Wish Group Ltd');
  const [businessDetails, setBusinessDetails] = useState<ReceiptBusinessDetails>({ name: 'Just Wish Group Ltd', address: null, phone: null, email: null });
  const [generatingPdf, setGeneratingPdf] = useState<string | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('by_site');
  const [locationNames, setLocationNames] = useState<Map<string, { name: string | null; address: string | null; phone: string | null; email: string | null }>>(new Map());

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  const loadOrders = useCallback(async () => {
    if (!organizationId || !isOrgUser) {
      setOrders([]);
      setLoading(false);
      return;
    }
    try {
      const { data: locations } = await supabase
        .from('car_wash_locations')
        .select('id, address, name, phone, email')
        .eq('organization_id', organizationId);

      const locationIds = (locations || []).map((l: any) => l.id).filter(Boolean);
      const locationMap = new Map<string, { address: string | null; name: string | null; phone: string | null; email: string | null }>();
      (locations || []).forEach((l: any) => {
        if (l.id) locationMap.set(l.id, { address: l.address ?? null, name: l.name ?? null, phone: l.phone ?? null, email: l.email ?? null });
      });
      setLocationNames(locationMap);

      if (locationIds.length === 0) {
        setOrders([]);
      } else {
        const optionalColumns = ['customer_name', 'service_name', 'scheduled_at', 'scheduled_time', 'completed_at', 'price', 'location_id', 'location_address', 'vehicle_type', 'vehicle_info', 'payment_method'];
        let selectList = 'id, status, created_at';
        for (const col of optionalColumns) {
          selectList += `, ${col}`;
        }
        let rows: any[] = [];
        let fields = selectList.split(', ').map((s) => s.trim());
        for (let attempt = 0; attempt < 12; attempt++) {
          const { data, error } = await supabase
            .from('bookings')
            .select(fields.join(','))
            .in('location_id', locationIds)
            .eq('status', 'completed')
            .order('created_at', { ascending: false });
          if (!error && data != null) {
            rows = data;
            break;
          }
          if (error?.code === '42703') {
            const missing = getMissingColumn(error?.message);
            if (missing && fields.includes(missing)) {
              fields = fields.filter((f) => f !== missing);
              continue;
            }
          }
          throw error;
        }
        const mapped: OrderRow[] = rows.map((r: any) => {
          const loc = r.location_id ? locationMap.get(r.location_id) : null;
          const locationAddress = r.location_address ?? loc?.address ?? null;
          return {
            id: r.id,
            status: r.status ?? 'completed',
            customer_name: r.customer_name ?? 'Customer',
            service_name: r.service_name ?? null,
            location_address: locationAddress,
            location_id: r.location_id ?? null,
            location_name: loc?.name ?? null,
            location_phone: loc?.phone ?? null,
            location_email: loc?.email ?? null,
            vehicle_type: r.vehicle_type ?? null,
            vehicle_info: r.vehicle_info ?? null,
            scheduled_at: r.scheduled_at ?? r.scheduled_time ?? null,
            completed_at: r.completed_at ?? null,
            price: r.price ?? null,
            created_at: r.created_at ?? '',
            payment_method: r.payment_method ?? null,
          };
        });
        setOrders(mapped);
      }

      const { data: org } = await supabase
        .from('organizations')
        .select('name, address, phone, email')
        .eq('id', organizationId)
        .maybeSingle();
      if (org) {
        const o = org as any;
        if (o.name) setBusinessName(o.name);
        setBusinessDetails({
          name: o.name || 'Just Wish Group Ltd',
          address: o.address ?? null,
          phone: o.phone ?? null,
          email: o.email ?? null,
        });
      }
    } catch (e) {
      console.error(e);
      setOrders([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [organizationId, isOrgUser]);

  useEffect(() => {
    loadOrders();
  }, [loadOrders]);

  const ordersBySite = useMemo(() => {
    const map = new Map<string, OrderRow[]>();
    for (const order of orders) {
      const key = order.location_id || order.location_address || 'unknown';
      if (!map.has(key)) map.set(key, []);
      map.get(key)!.push(order);
    }
    return Array.from(map.entries()).map(([key, items]) => {
      const first = items[0];
      const loc = first?.location_id ? locationNames.get(first.location_id) : null;
      const siteLabel = (first?.location_id && loc?.name) ? loc.name : (first?.location_address || 'Unknown site');
      return { siteKey: key, siteLabel, orders: items };
    });
  }, [orders, locationNames]);

  const onRefresh = () => {
    setRefreshing(true);
    loadOrders();
  };

  const viewReceipt = async (order: OrderRow) => {
    await hapticFeedback('light');
    setGeneratingPdf(order.id);
    try {
      const html = receiptHtml(order, businessDetails);
      const { uri } = await Print.printToFileAsync({
        html,
        width: 400,
        base64: false,
      });
      const canShare = await Sharing.isAvailableAsync();
      if (canShare) {
        await Sharing.shareAsync(uri, { mimeType: 'application/pdf', UTI: '.pdf' });
      } else {
        if (Platform.OS === 'web') {
          window.open(uri, '_blank');
        } else {
          await Linking.openURL(uri);
        }
      }
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Could not generate receipt');
    } finally {
      setGeneratingPdf(null);
    }
  };

  const renderOrderCard = (order: OrderRow, compact?: boolean) => (
    <GlassCard key={order.id} style={compact ? styles.orderCardCompact : styles.orderCard} accountType="business">
      <View style={styles.orderRow}>
        <View style={styles.orderMain}>
          <Text style={[styles.orderCustomer, { color: textColors.primary }]} numberOfLines={1}>{order.customer_name || 'Customer'}</Text>
          <Text style={[styles.orderService, { color: textColors.secondary }]} numberOfLines={1}>{order.service_name || 'Wash'}</Text>
          <Text style={[styles.orderDate, { color: textColors.muted }]}>{formatOrderDate(order)}</Text>
        </View>
        <View style={styles.orderRight}>
          <Text style={[styles.orderPrice, { color: theme.primary }]}>£{(order.price ?? 0).toFixed(2)}</Text>
          <TouchableOpacity
            style={[styles.receiptBtn, { shadowColor: theme.primary }]}
            onPress={() => viewReceipt(order)}
            disabled={generatingPdf === order.id}
            activeOpacity={0.8}
          >
            <LinearGradient colors={[theme.primary, theme.primaryAlt ?? theme.primary]} style={styles.receiptBtnGrad}>
              {generatingPdf === order.id ? (
                <ActivityIndicator size="small" color="#FFF" />
              ) : (
                <>
                  <Ionicons name="document-text" size={18} color="#FFFFFF" />
                  <Text style={styles.receiptBtnText}>Receipt</Text>
                </>
              )}
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>
    </GlassCard>
  );

  const viewToggleBtnActiveStyle = { backgroundColor: `${theme.primary}35`, borderColor: theme.primary };
  const viewToggleTextStyle = { color: textColors.secondary, fontSize: 14, fontWeight: '600' as const };
  const viewToggleTextActiveStyle = { color: textColors.primary, fontWeight: '700' as const };
  const viewToggleBtnStyle = {
    backgroundColor: bgColors.card ?? 'rgba(255,255,255,0.08)',
    borderColor: bgColors.cardBorder ?? 'rgba(255,255,255,0.12)',
  };

  if (!isOrgUser || !organizationId) {
    return (
      <SafeAreaView style={[styles.container, { backgroundColor: theme.background[0] }]} edges={[]}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Completed Washes" accountType="business" />
        <View style={styles.centerContent}>
          <Ionicons name="document-text-outline" size={48} color={iconColors.secondary} style={{ opacity: 0.7 }} />
          <Text style={[styles.emptyText, { color: textColors.primary }]}>Link your organization to view completed washes.</Text>
          <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: theme.primary }]}>
            <Text style={styles.backBtnText}>Go back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={[styles.container, { backgroundColor: theme.background[0] }]} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
      <AppHeader title="Completed Washes" accountType="business" />
      {loading ? (
        <LoadingView style={styles.loadingWrap} />
      ) : orders.length === 0 ? (
        <View style={styles.centerContent}>
          <Ionicons name="car-outline" size={64} color={theme.primary} style={{ opacity: 0.5 }} />
          <Text style={[styles.emptyTitle, { color: textColors.primary }]}>No completed washes yet</Text>
          <Text style={[styles.emptyText, { color: textColors.secondary }]}>Completed bookings will appear here by site, with receipt options.</Text>
          <TouchableOpacity onPress={() => router.back()} style={[styles.backBtn, { backgroundColor: theme.primary }]}>
            <Text style={styles.backBtnText}>Back to profile</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <View style={[styles.contentBelowHeader, { paddingTop: insets.top + HEADER_HEIGHT + 12 }]}>
          <View style={styles.viewToggleWrap}>
            <TouchableOpacity
              style={[styles.viewToggleBtn, viewToggleBtnStyle, viewMode === 'by_site' && viewToggleBtnActiveStyle]}
              onPress={() => { hapticFeedback('light'); setViewMode('by_site'); }}
              activeOpacity={0.8}
            >
              <Ionicons name="location" size={18} color={viewMode === 'by_site' ? textColors.primary : textColors.muted} />
              <Text style={[viewToggleTextStyle, viewMode === 'by_site' && viewToggleTextActiveStyle]}>By site</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.viewToggleBtn, viewToggleBtnStyle, viewMode === 'receipt_summary' && viewToggleBtnActiveStyle]}
              onPress={() => { hapticFeedback('light'); setViewMode('receipt_summary'); }}
              activeOpacity={0.8}
            >
              <Ionicons name="receipt-outline" size={18} color={viewMode === 'receipt_summary' ? textColors.primary : textColors.muted} />
              <Text style={[viewToggleTextStyle, viewMode === 'receipt_summary' && viewToggleTextActiveStyle]}>Receipt summary</Text>
            </TouchableOpacity>
          </View>
          <ScrollView
            style={styles.scroll}
            contentContainerStyle={[styles.scrollContent, { paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24 }]}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />}
            showsVerticalScrollIndicator={false}
          >
            {viewMode === 'by_site' ? (
              ordersBySite.map(({ siteKey, siteLabel, orders: siteOrders }) => (
                <View key={siteKey} style={styles.siteSection}>
                  <View style={styles.siteSectionHeader}>
                    <Ionicons name="business-outline" size={18} color={theme.primary} />
                    <Text style={[styles.siteSectionTitle, { color: textColors.primary }]} numberOfLines={2}>{siteLabel}</Text>
                    <Text style={[styles.siteSectionCount, { color: textColors.muted }]}>{siteOrders.length} wash{siteOrders.length !== 1 ? 'es' : ''}</Text>
                  </View>
                  {siteOrders.map((order) => renderOrderCard(order, false))}
                </View>
              ))
            ) : (
              <View style={styles.receiptSummaryList}>
                {orders.map((order) => renderOrderCard(order, true))}
              </View>
            )}
          </ScrollView>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  contentBelowHeader: { flex: 1 },
  scroll: { flex: 1 },
  scrollContent: { padding: 20, paddingTop: 16 },
  loadingWrap: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 14 },
  centerContent: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24, gap: 12 },
  emptyTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: '700' },
  emptyText: { color: 'rgba(249,250,251,0.8)', fontSize: 14, textAlign: 'center' },
  backBtn: { marginTop: 10, paddingVertical: 12, paddingHorizontal: 22, backgroundColor: SKY, borderRadius: 12 },
  backBtnText: { color: '#FFF', fontWeight: '700', fontSize: 15 },
  viewToggleWrap: { flexDirection: 'row', paddingHorizontal: 20, paddingTop: 12, paddingBottom: 8, gap: 10 },
  viewToggleBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  viewToggleBtnActive: { backgroundColor: 'rgba(135,206,235,0.35)', borderColor: SKY },
  viewToggleText: { color: 'rgba(249,250,251,0.8)', fontSize: 14, fontWeight: '600' },
  viewToggleTextActive: { color: '#F9FAFB', fontWeight: '700' },
  siteSection: { marginBottom: 20 },
  siteSectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 10,
    paddingVertical: 6,
    paddingHorizontal: 4,
  },
  siteSectionTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '700', flex: 1 },
  siteSectionCount: { color: 'rgba(249,250,251,0.6)', fontSize: 13 },
  receiptSummaryList: { gap: 0 },
  orderCard: { marginBottom: 10, padding: 14, zIndex: 1, elevation: 2 },
  orderCardCompact: { marginBottom: 8, padding: 12, zIndex: 1, elevation: 2 },
  orderRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 10 },
  orderMain: { flex: 1, minWidth: 0 },
  orderCustomer: { color: '#F9FAFB', fontSize: 17, fontWeight: '700', marginBottom: 4 },
  orderService: { color: 'rgba(249,250,251,0.85)', fontSize: 14, marginBottom: 4 },
  orderDate: { color: 'rgba(249,250,251,0.6)', fontSize: 12 },
  orderRight: { alignItems: 'flex-end', gap: 10 },
  orderPrice: { color: SKY, fontSize: 18, fontWeight: '700' },
  receiptBtn: { borderRadius: 12, overflow: 'hidden', elevation: 4, shadowColor: SKY, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.3, shadowRadius: 6 },
  receiptBtnGrad: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 10, paddingHorizontal: 16, gap: 6 },
  receiptBtnText: { color: '#FFFFFF', fontSize: 14, fontWeight: '700' },
});
