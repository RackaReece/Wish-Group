import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  Image,
  StatusBar,
  Animated,
  Linking,
  Modal,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { chatService, ChatMessageExtended, ChatConversation } from '../src/utils/ChatService';
import { hapticFeedback } from '../src/services/HapticFeedbackService';
import { supabase } from '../src/lib/supabase';
import { colors } from '../src/constants/colors';
import { customerTheme } from '../src/constants/customerTheme';
import GlassCard from '../src/components/booking/GlassCard';
import Avatar from '../src/components/shared/Avatar';

const SKY = colors.SKY;

type CustomerProfileCard = {
  vehicleDisplay: string;
  washesCount: number;
  customerRating: number | null;
  memberSince: string | null;
  phone: string;
};

export default function ChatScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{
    recipientId?: string;
    recipientName?: string;
    recipientType?: string;
    recipientImage?: string;
    phone?: string;
    vehicle?: string;
    bookingId?: string;
    bookingStatus?: string;
  }>();
  const { user } = useAuth();

  const recipientId = params.recipientId ?? '';
  const recipientName = params.recipientName ?? 'Customer';
  const recipientType = (params.recipientType ?? 'customer') as 'customer' | 'valeter';
  const recipientImage = params.recipientImage ?? '';
  const phone = params.phone ?? '';
  const vehicle = params.vehicle ?? '';
  const bookingStatus = params.bookingStatus ?? '';

  const [conversation, setConversation] = useState<ChatConversation | null>(null);
  const [messages, setMessages] = useState<ChatMessageExtended[]>([]);
  const [inputText, setInputText] = useState('');
  const [sending, setSending] = useState(false);
  const [customerProfile, setCustomerProfile] = useState<CustomerProfileCard | null>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const scrollRef = useRef<ScrollView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const currentUserId = user?.id ?? '';
  const currentUserName = (user as any)?.name ?? (user as any)?.email ?? 'You';

  const customerId = recipientType === 'customer' ? recipientId : currentUserId;
  const valeterId = recipientType === 'valeter' ? recipientId : currentUserId;
  const customerName = recipientType === 'customer' ? recipientName : currentUserName;
  const valeterName = recipientType === 'valeter' ? recipientName : currentUserName;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 350,
      useNativeDriver: true,
    }).start();
  }, []);

  // Load full customer profile when chatting with a customer (e.g. business speaking to customer)
  useEffect(() => {
    if (recipientType !== 'customer' || !recipientId) {
      setCustomerProfile(null);
      return;
    }
    let cancelled = false;
    (async () => {
      try {
        const [vehiclesRes, bookingsRes] = await Promise.all([
          supabase
            .from('customer_vehicles')
            .select('make, model, color, type')
            .eq('user_id', recipientId)
            .order('is_default', { ascending: false }),
          supabase
            .from('bookings')
            .select('id, rating, created_at, status')
            .eq('user_id', recipientId),
        ]);
        if (cancelled) return;

        let vehicleDisplay = vehicle || 'No vehicle';
        if (vehiclesRes.data && vehiclesRes.data.length > 0) {
          const v = vehiclesRes.data[0];
          const parts = [v.make, v.model].filter(Boolean);
          if (v.color) parts.push(v.color);
          vehicleDisplay = parts.length > 0 ? parts.join(' • ') : (v.type || vehicleDisplay);
        }

        const bookings = bookingsRes.data || [];
        const completed = bookings.filter((b: { status: string }) => b.status === 'completed');
        const washesCount = completed.length;
        const withRating = completed.filter((b: { rating?: number | null }) => b.rating != null);
        const customerRating =
          withRating.length > 0
            ? withRating.reduce((s: number, b: { rating?: number | null }) => s + (Number(b.rating) || 0), 0) / withRating.length
            : null;

        let memberSince: string | null = null;
        if (bookings.length > 0) {
          const withDate = bookings.filter((b: { created_at?: string }) => b.created_at);
          if (withDate.length > 0) {
            const earliest = withDate.reduce((a: { created_at: string }, b: { created_at: string }) =>
              a.created_at <= b.created_at ? a : b
            );
            memberSince = earliest.created_at;
          }
        }

        setCustomerProfile({
          vehicleDisplay,
          washesCount,
          customerRating: customerRating != null ? Math.round(customerRating * 10) / 10 : null,
          memberSince,
          phone: phone || '',
        });
      } catch (e) {
        if (!cancelled) setCustomerProfile(null);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [recipientType, recipientId, phone, vehicle]);

  useEffect(() => {
    if (!currentUserId || !recipientId) return;

    let conv = chatService.getConversationByParticipants(currentUserId, recipientId);
    if (!conv) {
      conv = chatService.createConversation(customerId, valeterId, customerName, valeterName);
    }
    setConversation(conv);
    setMessages(chatService.getMessages(conv.id));
    chatService.markMessagesAsRead(conv.id, currentUserId);

    const onMessage = (msg: ChatMessageExtended) => {
      if (msg.conversationId === conv!.id) {
        setMessages(prev => [...prev, msg]);
        setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
      }
    };
    chatService.addMessageListener(onMessage);
    return () => {
      chatService.removeListeners();
    };
  }, [currentUserId, recipientId, customerId, valeterId, customerName, valeterName]);

  const handleSend = async () => {
    const text = inputText.trim();
    if (!text || !conversation || !currentUserId || sending) return;

    setSending(true);
    setInputText('');
    hapticFeedback('light');

    try {
      await chatService.sendMessage(
        conversation.id,
        currentUserId,
        currentUserName,
        text,
        'text'
      );
      setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 150);
    } catch (e) {
      console.error('Send message error:', e);
    } finally {
      setSending(false);
    }
  };

  const handleBack = () => {
    hapticFeedback('light');
    router.back();
  };

  const handleCall = () => {
    hapticFeedback('light');
    const number = phone || customerProfile?.phone;
    if (number) Linking.openURL(`tel:${number}`).catch(() => {});
  };

  const formatTime = (d: Date) => {
    const date = d instanceof Date ? d : new Date(d);
    const now = new Date();
    const isToday = date.toDateString() === now.toDateString();
    if (isToday) {
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' }) + ' ' +
      date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  const isSent = (msg: ChatMessageExtended) => msg.senderId === currentUserId;
  const canCall = !!(phone || customerProfile?.phone);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <KeyboardAvoidingView
        style={styles.flex}
        behavior={Platform.OS === 'ios' ? 'padding' : undefined}
        keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
      >
        {/* Header – higher up: back + tappable card with customer name; tap opens details overlay */}
        <Animated.View style={[styles.headerRowWrap, { opacity: fadeAnim, paddingTop: insets.top + 4, paddingBottom: 10, paddingHorizontal: 12 }]}>
          <TouchableOpacity onPress={handleBack} style={styles.headerBackBtn} hitSlop={12}>
            <Ionicons name="chevron-back" size={28} color="#FFFFFF" />
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.headerCardTouchable}
            activeOpacity={0.9}
            onPress={() => { hapticFeedback('light'); setShowDetailsModal(true); }}
          >
            <GlassCard style={styles.proCardAsHeader} accountType="customer">
              <BlurView intensity={40} tint="dark" style={StyleSheet.absoluteFill} />
              <LinearGradient colors={[SKY + '18', SKY + '08', 'transparent']} style={StyleSheet.absoluteFill} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} />
              <View style={styles.proCardInner}>
                <View style={styles.proAvatarWrap}>
                  {recipientImage ? (
                    <Avatar imageUri={recipientImage} size={48} accentColor={SKY} />
                  ) : (
                    <Avatar size={48} accentColor={SKY} />
                  )}
                </View>
                <View style={styles.proInfo}>
                  <Text style={styles.proName} numberOfLines={1}>{recipientName}</Text>
                  <Text style={styles.proSubtitle} numberOfLines={1}>
                    {recipientType === 'customer' ? 'Customer' : 'Valeter'}
                    {vehicle ? ` • ${vehicle}` : ''}
                  </Text>
                  <Text style={styles.tapForDetails}>Tap for details</Text>
                </View>
              </View>
            </GlassCard>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => { hapticFeedback('light'); handleCall(); }}
            style={[styles.headerCallBtn, !canCall && styles.headerCallBtnDisabled]}
            disabled={!canCall}
          >
            <Ionicons name="call" size={22} color={canCall ? '#FFFFFF' : 'rgba(255,255,255,0.4)'} />
          </TouchableOpacity>
        </Animated.View>

        {/* Details overlay – popup card when header is pressed */}
        <Modal visible={showDetailsModal} transparent animationType="fade">
          <Pressable style={styles.detailsOverlay} onPress={() => setShowDetailsModal(false)}>
            <Pressable style={styles.detailsCardWrap} onPress={e => e.stopPropagation()}>
              <GlassCard style={styles.detailsCard} accountType="customer">
                <BlurView intensity={60} tint="dark" style={StyleSheet.absoluteFill} />
                <LinearGradient colors={[SKY + '22', SKY + '10', 'transparent']} style={StyleSheet.absoluteFill} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} />
                <View style={styles.detailsCardHeader}>
                  <Text style={styles.detailsCardTitle}>{recipientName}</Text>
                  <TouchableOpacity onPress={() => setShowDetailsModal(false)} style={styles.detailsCloseBtn}>
                    <Ionicons name="close" size={24} color="#F9FAFB" />
                  </TouchableOpacity>
                </View>
                {recipientType === 'customer' && customerProfile ? (
                  <View style={styles.detailsCardBody}>
                    <View style={styles.profileCardRow}>
                      <View style={styles.profileCardIconWrap}>
                        <Ionicons name="car-sport" size={20} color={SKY} />
                      </View>
                      <Text style={styles.profileCardLabel}>Vehicle</Text>
                      <Text style={styles.profileCardValue} numberOfLines={1}>{customerProfile.vehicleDisplay}</Text>
                    </View>
                    <View style={styles.profileCardRow}>
                      <View style={styles.profileCardIconWrap}>
                        <Ionicons name="water" size={20} color={SKY} />
                      </View>
                      <Text style={styles.profileCardLabel}>Washes</Text>
                      <Text style={styles.profileCardValue}>{customerProfile.washesCount}</Text>
                    </View>
                    <View style={styles.profileCardRow}>
                      <View style={styles.profileCardIconWrap}>
                        <Ionicons name="star" size={20} color={SKY} />
                      </View>
                      <Text style={styles.profileCardLabel}>Customer rating</Text>
                      <Text style={styles.profileCardValue}>
                        {customerProfile.customerRating != null ? `${customerProfile.customerRating} ★` : '—'}
                      </Text>
                    </View>
                    {customerProfile.memberSince && (
                      <View style={styles.profileCardRow}>
                        <View style={styles.profileCardIconWrap}>
                          <Ionicons name="calendar" size={20} color={SKY} />
                        </View>
                        <Text style={styles.profileCardLabel}>Time on app</Text>
                        <Text style={styles.profileCardValue}>
                          Member since {new Date(customerProfile.memberSince).toLocaleDateString(undefined, { month: 'short', year: 'numeric' })}
                        </Text>
                      </View>
                    )}
                    {customerProfile.phone ? (
                      <View style={styles.profileCardRow}>
                        <View style={styles.profileCardIconWrap}>
                          <Ionicons name="call" size={20} color={SKY} />
                        </View>
                        <Text style={styles.profileCardLabel}>Phone</Text>
                        <TouchableOpacity onPress={() => { setShowDetailsModal(false); handleCall(); }}>
                          <Text style={[styles.profileCardValue, styles.profileCardValueLink]}>{customerProfile.phone}</Text>
                        </TouchableOpacity>
                      </View>
                    ) : null}
                  </View>
                ) : (
                  <View style={styles.detailsCardBody}>
                    {vehicle ? (
                      <View style={styles.profileCardRow}>
                        <View style={styles.profileCardIconWrap}>
                          <Ionicons name="car-outline" size={20} color={SKY} />
                        </View>
                        <Text style={styles.profileCardLabel}>Vehicle</Text>
                        <Text style={styles.profileCardValue} numberOfLines={1}>{vehicle}</Text>
                      </View>
                    ) : null}
                    {phone ? (
                      <View style={styles.profileCardRow}>
                        <View style={styles.profileCardIconWrap}>
                          <Ionicons name="call" size={20} color={SKY} />
                        </View>
                        <Text style={styles.profileCardLabel}>Phone</Text>
                        <TouchableOpacity onPress={() => { setShowDetailsModal(false); handleCall(); }}>
                          <Text style={[styles.profileCardValue, styles.profileCardValueLink]}>{phone}</Text>
                        </TouchableOpacity>
                      </View>
                    ) : null}
                    {!vehicle && !phone && (
                      <Text style={styles.detailsNoExtra}>No extra details</Text>
                    )}
                  </View>
                )}
              </GlassCard>
            </Pressable>
          </Pressable>
        </Modal>

        {/* Messages – same layout as customer chat: avatar + bubble (received), bubble + avatar (sent) */}
        <ScrollView
          ref={scrollRef}
          style={styles.scroll}
          contentContainerStyle={[styles.scrollContent, { paddingBottom: insets.bottom + 80 }]}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: false })}
          keyboardShouldPersistTaps="handled"
        >
          {messages.length === 0 && (
            <View style={styles.emptyWrap}>
              <View style={styles.emptyIconWrap}>
                <Ionicons name="chatbubbles-outline" size={40} color={SKY} style={{ opacity: 0.8 }} />
              </View>
              <Text style={styles.emptyTitle}>Start the conversation</Text>
              <Text style={styles.emptySub}>Say hello or ask about the booking</Text>
            </View>
          )}
          {messages.map((msg) => (
            <View
              key={msg.id}
              style={[styles.messageRow, isSent(msg) ? styles.messageRowCustomer : styles.messageRowPro]}
            >
              {!isSent(msg) ? (
                <>
                  {recipientImage ? (
                    <Avatar imageUri={recipientImage} size={32} accentColor={SKY} />
                  ) : (
                    <Avatar size={32} accentColor={SKY} />
                  )}
                  <View style={[styles.bubble, styles.bubblePro]}>
                    <Text style={styles.bubbleText}>{msg.message}</Text>
                    <Text style={styles.bubbleTime}>{formatTime(msg.timestamp)}</Text>
                  </View>
                </>
              ) : (
                <>
                  <View style={[styles.bubble, styles.bubbleCustomer]}>
                    <Text style={styles.bubbleText}>{msg.message}</Text>
                    <Text style={styles.bubbleTime}>{formatTime(msg.timestamp)}</Text>
                  </View>
                  <View style={styles.customerAvatarWrap}>
                    <Image source={require('./assets/car.png')} style={styles.customerAvatar} resizeMode="contain" />
                  </View>
                </>
              )}
            </View>
          ))}
        </ScrollView>

        {/* Input – floating card */}
        <View style={[styles.inputFloatingWrap, { paddingBottom: insets.bottom + 16 }]}>
          <View style={styles.inputFloatingCard}>
            <TextInput
              style={styles.input}
              placeholder="Message…"
              placeholderTextColor="#64748B"
              value={inputText}
              onChangeText={setInputText}
              multiline
              maxLength={1000}
              editable={!sending}
              onSubmitEditing={handleSend}
              returnKeyType="send"
            />
            <TouchableOpacity
              onPress={handleSend}
              disabled={!inputText.trim() || sending}
              style={[styles.sendBtn, !inputText.trim() && styles.sendBtnDisabled]}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={inputText.trim() ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
                style={styles.sendBtnGradient}
              >
                <Ionicons name="send" size={20} color="#FFFFFF" />
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  flex: { flex: 1 },
  headerRowWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  headerBackBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.12)',
  },
  headerCardTouchable: { flex: 1, minWidth: 0 },
  headerCallBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(16,185,129,0.9)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  headerCallBtnDisabled: {
    backgroundColor: 'rgba(255,255,255,0.1)',
  },
  proCardAsHeader: {
    padding: 12,
    paddingRight: 16,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: SKY + '30',
  },
  proCardInner: { flexDirection: 'row', alignItems: 'center' },
  proAvatarWrap: { marginRight: 12 },
  proAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    borderWidth: 2,
    borderColor: SKY,
  },
  proAvatarPlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: SKY + '25',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  proInfo: { flex: 1, minWidth: 0 },
  proName: { color: '#F9FAFB', fontSize: 17, fontWeight: '800', marginBottom: 2 },
  proSubtitle: { color: '#94A3B8', fontSize: 13, marginBottom: 2 },
  tapForDetails: { color: SKY, fontSize: 11, opacity: 0.9 },
  detailsOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  detailsCardWrap: { width: '100%', maxWidth: 360 },
  detailsCard: {
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: SKY + '40',
    padding: 0,
  },
  detailsCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 20,
    paddingBottom: 12,
  },
  detailsCardTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: '800', flex: 1 },
  detailsCloseBtn: { padding: 4 },
  detailsCardBody: { padding: 16, paddingTop: 0, gap: 14 },
  detailsNoExtra: { color: '#94A3B8', fontSize: 14, textAlign: 'center', paddingVertical: 16 },
  profileCardRow: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  profileCardIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: SKY + '25',
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileCardLabel: { color: '#94A3B8', fontSize: 13, fontWeight: '600', minWidth: 110 },
  profileCardValue: { color: '#F1F5F9', fontSize: 14, fontWeight: '700', flex: 1 },
  profileCardValueLink: { color: SKY },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 12 },
  emptyWrap: { alignItems: 'center', justifyContent: 'center', paddingVertical: 48 },
  emptyIconWrap: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: SKY + '25',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  emptyTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '800', marginBottom: 6 },
  emptySub: { color: '#94A3B8', fontSize: 14 },
  messageRow: { flexDirection: 'row', alignItems: 'flex-end', gap: 8, marginVertical: 6 },
  messageRowPro: { justifyContent: 'flex-start' },
  messageRowCustomer: { justifyContent: 'flex-end' },
  msgAvatar: { width: 32, height: 32, borderRadius: 16 },
  msgAvatarPlaceholder: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: SKY + '30',
    justifyContent: 'center',
    alignItems: 'center',
  },
  bubble: {
    maxWidth: '78%',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 18,
  },
  bubblePro: {
    backgroundColor: 'rgba(30,41,59,0.9)',
    borderBottomLeftRadius: 4,
    borderWidth: 1,
    borderColor: SKY + '25',
  },
  bubbleCustomer: {
    backgroundColor: SKY + '35',
    borderBottomRightRadius: 4,
    borderWidth: 1,
    borderColor: SKY + '50',
  },
  bubbleText: { color: '#F1F5F9', fontSize: 15, lineHeight: 20 },
  bubbleTime: { color: '#94A3B8', fontSize: 11, marginTop: 4 },
  customerAvatarWrap: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: SKY + '25',
    borderWidth: 1,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  customerAvatar: { width: 22, height: 22 },
  inputFloatingWrap: {
    paddingHorizontal: 16,
    paddingTop: 10,
    backgroundColor: 'transparent',
  },
  inputFloatingCard: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
    backgroundColor: 'rgba(30,41,59,0.95)',
    borderRadius: 24,
    paddingLeft: 18,
    paddingRight: 8,
    paddingVertical: 8,
    minHeight: 48,
    maxHeight: 100,
    borderWidth: 1,
    borderColor: SKY + '30',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
    elevation: 8,
  },
  input: {
    flex: 1,
    minHeight: 36,
    maxHeight: 84,
    paddingVertical: 10,
    paddingHorizontal: 4,
    color: '#F1F5F9',
    fontSize: 15,
  },
  sendBtn: { width: 44, height: 44, borderRadius: 22, overflow: 'hidden' },
  sendBtnDisabled: { opacity: 0.6 },
  sendBtnGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
