import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  KeyboardAvoidingView,
  Platform,
  Alert,
  StatusBar,
  Image,
  LayoutAnimation,
  UIManager,
  ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Video, ResizeMode, AVPlaybackStatus } from 'expo-av';
import { router, useNavigation } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import * as AppleAuthentication from 'expo-apple-authentication';

if (Platform.OS === 'android') {
  if (UIManager.setLayoutAnimationEnabledExperimental) {
    UIManager.setLayoutAnimationEnabledExperimental(true);
  }
}

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

export default function SignupScreen() {
  const { register, /* @ts-ignore */ registerWithApple } = useAuth();
  const navigation = useNavigation();

  const [userType, setUserType] = useState<'organization' | 'valeter'>('valeter');
  const [formData, setFormData] = useState({ name: '', email: '', password: '', confirmPassword: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);
  const [emailAuthVisible, setEmailAuthVisible] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [step, setStep] = useState(0); // 0: Name/Email, 1: Password
  const formSlideAnim = useRef(new Animated.Value(0)).current; // 0 for step 0, -width for step 1

  // Animations
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const videoRef = useRef<Video>(null);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 800, useNativeDriver: true }),
    ]).start();
  }, []);

  const handlePlaybackStatusUpdate = (status: AVPlaybackStatus) => {
    if (!status.isLoaded || !videoRef.current) return;
    if (status.didJustFinish) {
      videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      return;
    }
    if (status.durationMillis != null && status.positionMillis != null) {
      const remaining = status.durationMillis - status.positionMillis;
      if (remaining < 500 && remaining > 0) {
        videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      }
    }
  };

  useEffect(() => {
    (async () => {
      try {
        const available = Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  const updateFormData = (field: keyof typeof formData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setError(null);
  };

  const isValidEmail = (e: string) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test((e || '').trim());
  const canContinueStep0 = formData.name.trim().length > 0 && formData.email.trim().length > 0 && isValidEmail(formData.email);
  const passwordsMatch = formData.password === formData.confirmPassword;
  const passwordLongEnough = formData.password.length >= 6;
  const hasNumber = /\d/.test(formData.password);
  const hasLetter = /[a-zA-Z]/.test(formData.password);
  const passwordStrong = formData.password.length >= 6 && hasNumber && hasLetter;
  const canSubmitStep1 = passwordLongEnough && passwordsMatch;

  const validateForm = () => {
    if (!formData.name?.trim() || !formData.email?.trim() || !formData.password) {
      setError('Please fill in all required fields');
      return false;
    }
    if (!isValidEmail(formData.email)) {
      setError('Please enter a valid email address');
      return false;
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return false;
    }
    if (formData.password !== formData.confirmPassword) {
      setError('Passwords do not match');
      return false;
    }
    return true;
  };

  const handleSignup = async () => {
    if (!validateForm()) return;

    await hapticFeedback('medium');
    setIsLoading(true);
    setError(null);

    try {
      const success = await register({
        email: formData.email,
        name: formData.name,
        userType,
        password: formData.password,
        isVerified: false,
        verificationType: 'none',
        totalWashes: 0,
        tier: 'bronze',
        tierPoints: 0,
      } as any);

      if (success) {
        Alert.alert('Success!', 'Account created! Please verify your email.', [
          { text: 'OK', onPress: () => router.replace('/auth/login') },
        ]);
      } else {
        setError('Failed to create account. Please try again.');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to create account. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleSignup = async () => {
    try {
      hapticFeedback('light');
      const cred = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      if (typeof registerWithApple === 'function') {
        const ok = await registerWithApple(cred, { userType });
        if (!ok) {
          Alert.alert('Apple Sign Up Failed', 'Could not create your account with Apple.');
          return;
        }
      } else {
        Alert.alert(
          'Apple Sign Up',
          'Apple credential received. Wire this to your backend via registerWithApple to finish sign up.'
        );
        return;
      }

      router.replace('/auth/login');
    } catch (error: any) {
      if (error?.code === 'ERR_CANCELED') return;
      Alert.alert('Apple Sign Up Failed', error?.message || 'Please try again.');
    }
  };

  const handleUserTypeChange = (type: 'organization' | 'valeter') => {
    setUserType(type);
    hapticFeedback('light');
  };

  const toggleEmailAuth = () => {
    hapticFeedback('light');
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setEmailAuthVisible(!emailAuthVisible);
    // Reset step when closing/opening
    if (!emailAuthVisible) {
      setStep(0);
      formSlideAnim.setValue(0);
    }
  };

  const handleContinue = () => {
    if (!formData.name || !formData.email) {
      setError('Please fill in your name and email');
      hapticFeedback('error');
      return;
    }
    if (!formData.email.includes('@')) {
      setError('Please enter a valid email address');
      hapticFeedback('error');
      return;
    }
    
    setError(null);
    hapticFeedback('light');
    setStep(1);
    Animated.timing(formSlideAnim, {
      toValue: -(width - 40), // Slide left by screen width minus padding
      duration: 300,
      useNativeDriver: true,
    }).start();
  };

  const handleBack = () => {
    setError(null);
    hapticFeedback('light');
    setStep(0);
    Animated.timing(formSlideAnim, {
      toValue: 0,
      duration: 300,
      useNativeDriver: true,
    }).start();
  };

  const handleLogin = () => {
    hapticFeedback('light');
    if (navigation.canGoBack()) {
      router.back();
    } else {
      router.replace('/auth/login');
    }
  };

  return (
    <View style={styles.root}>
      <Video
        ref={videoRef}
        source={require('../assets/business.mp4')}
        style={StyleSheet.absoluteFill}
        resizeMode={ResizeMode.COVER}
        shouldPlay
        isLooping
        isMuted
        progressUpdateIntervalMillis={30}
        onPlaybackStatusUpdate={handlePlaybackStatusUpdate}
      />
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <LinearGradient
          colors={['rgba(10,25,41,0.01)', 'rgba(10,25,41,0.2)', 'rgba(10,25,41,0.7)']}
          style={StyleSheet.absoluteFill}
        />
      </View>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      {/* Top Right Sign In */}
      <View style={styles.topRightContainer}>
        <TouchableOpacity onPress={handleLogin} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Text style={styles.topRightText}>Sign in</Text>
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.keyboardView}>
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          bounces={false}
          keyboardShouldPersistTaps="handled"
        >
          {/* Logo Section */}
          <View style={styles.logoSection}>
            <View style={styles.logoContainer}>
              <LinearGradient
                colors={['rgba(255,255,255,0.12)', 'rgba(255,255,255,0.06)', 'transparent']}
                style={styles.logoGradient}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              />
              <Image source={require('../assets/icon.png')} style={styles.logoImage} resizeMode="cover" fadeDuration={0} />
            </View>
            <Text style={styles.welcomeText}>Create account</Text>
            <Text style={styles.subtitleText}>Join Wish a Wash today</Text>
          </View>

          <Animated.View
            style={[
              styles.animatedContent,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            {/* User Type Selector - same as login */}
            <View style={styles.userTypeContainer}>
              <View style={styles.userTypeSwitcher}>
                <TouchableOpacity
                  style={[styles.userTypeButton, userType === 'valeter' && styles.userTypeButtonActive]}
                  onPress={() => handleUserTypeChange('valeter')}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.userTypeButtonText, userType === 'valeter' && styles.userTypeButtonTextActive]}>
                    Valeter
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.userTypeButton, userType === 'organization' && styles.userTypeButtonActive]}
                  onPress={() => handleUserTypeChange('organization')}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.userTypeButtonText, userType === 'organization' && styles.userTypeButtonTextActive]}>
                    Business
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* Signup Form */}
            <View style={styles.formCard}>
              <TouchableOpacity onPress={toggleEmailAuth} style={styles.emailAuthToggle} activeOpacity={0.7}>
                <Text style={styles.emailAuthToggleText}>
                  {emailAuthVisible ? 'Hide Email Sign Up' : 'Sign up with Email'}
                </Text>
                <Ionicons
                  name={emailAuthVisible ? 'chevron-up' : 'chevron-down'}
                  size={20}
                  color="rgba(255,255,255,0.7)"
                />
              </TouchableOpacity>

              {emailAuthVisible && (
                <View style={{ overflow: 'hidden' }}>
                  <Animated.View
                    style={{
                      flexDirection: 'row',
                      width: (width - 40) * 2,
                      transform: [{ translateX: formSlideAnim }],
                    }}
                  >
                    {/* Step 1: Name & Email */}
                    <View style={{ width: width - 40, paddingHorizontal: 0, marginRight: 40 }}>
                      <View style={styles.inputWrapper}>
                        <BlurView intensity={Platform.OS === 'ios' ? 40 : 24} tint="dark" style={StyleSheet.absoluteFill} />
                        <View style={styles.inputIconContainer}>
                          <Ionicons name="person-outline" size={20} color="rgba(255,255,255,0.6)" style={styles.inputIcon} />
                        </View>
                        <TextInput
                          style={styles.input}
                          placeholder={userType === 'organization' ? 'Business name' : 'Full name'}
                          placeholderTextColor="rgba(255, 255, 255, 0.45)"
                          value={formData.name}
                          onChangeText={(v) => updateFormData('name', v)}
                          autoCapitalize="words"
                        />
                      </View>

                      <View style={styles.inputWrapper}>
                        <BlurView intensity={Platform.OS === 'ios' ? 40 : 24} tint="dark" style={StyleSheet.absoluteFill} />
                        <View style={styles.inputIconContainer}>
                          <Ionicons name="mail-outline" size={20} color="rgba(255,255,255,0.6)" style={styles.inputIcon} />
                        </View>
                        <TextInput
                          style={styles.input}
                          placeholder="Email address"
                          placeholderTextColor="rgba(255, 255, 255, 0.45)"
                          value={formData.email}
                          onChangeText={(v) => updateFormData('email', v)}
                          keyboardType="email-address"
                          autoCapitalize="none"
                          autoCorrect={false}
                        />
                      </View>

                      {error && step === 0 && (
                        <View style={styles.errorContainer}>
                          <Ionicons name="warning" size={18} color="#FCA5A5" style={{ marginRight: 8 }} />
                          <Text style={styles.errorText}>{error}</Text>
                        </View>
                      )}

                      <TouchableOpacity
                        style={[styles.signupButton, !canContinueStep0 && styles.signupButtonDisabled]}
                        onPress={handleContinue}
                        disabled={!canContinueStep0}
                        activeOpacity={0.8}
                      >
                        <LinearGradient
                          colors={['#237AE6', '#1d64c7']}
                          style={StyleSheet.absoluteFill}
                          start={{ x: 0, y: 0 }}
                          end={{ x: 1, y: 1 }}
                        />
                        <Text style={styles.signupButtonText}>Continue</Text>
                      </TouchableOpacity>
                    </View>

                    {/* Step 2: Password */}
                    <View style={{ width: width - 40, paddingHorizontal: 0 }}>
                      <View style={[styles.inputWrapper, styles.passwordWrapper]}>
                        <BlurView intensity={Platform.OS === 'ios' ? 40 : 24} tint="dark" style={StyleSheet.absoluteFill} />
                        <TextInput
                          style={styles.passwordInput}
                          placeholder="Password (min. 6 characters)"
                          placeholderTextColor="rgba(255, 255, 255, 0.45)"
                          value={formData.password}
                          onChangeText={(v) => updateFormData('password', v)}
                          secureTextEntry={!showPassword}
                        />
                        <TouchableOpacity
                          style={styles.passwordToggle}
                          activeOpacity={0.7}
                          onPress={() => setShowPassword(!showPassword)}
                        >
                          <Ionicons
                            name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                            size={22}
                            color="rgba(255,255,255,0.7)"
                          />
                        </TouchableOpacity>
                      </View>
                      <Text style={styles.passwordHint}>
                        {formData.password.length > 0 && !passwordStrong
                          ? 'Use 6+ characters with a letter and number for a stronger password'
                          : 'Use 6+ characters; include a letter and number for strength'}
                      </Text>

                      <View style={[styles.inputWrapper, styles.passwordWrapper, { marginTop: 12 }]}>
                        <BlurView intensity={Platform.OS === 'ios' ? 40 : 24} tint="dark" style={StyleSheet.absoluteFill} />
                        <TextInput
                          style={styles.passwordInput}
                          placeholder="Confirm password"
                          placeholderTextColor="rgba(255, 255, 255, 0.45)"
                          value={formData.confirmPassword}
                          onChangeText={(v) => updateFormData('confirmPassword', v)}
                          secureTextEntry={!showConfirmPassword}
                        />
                        <TouchableOpacity
                          style={styles.passwordToggle}
                          activeOpacity={0.7}
                          onPress={() => setShowConfirmPassword(!showConfirmPassword)}
                        >
                          <Ionicons
                            name={showConfirmPassword ? 'eye-off-outline' : 'eye-outline'}
                            size={22}
                            color="rgba(255,255,255,0.7)"
                          />
                        </TouchableOpacity>
                      </View>
                      {formData.confirmPassword.length > 0 && !passwordsMatch && (
                        <Text style={styles.inlineError}>Passwords do not match</Text>
                      )}

                      {error && step === 1 && (
                        <View style={styles.errorContainer}>
                          <Ionicons name="warning" size={18} color="#FCA5A5" style={{ marginRight: 8 }} />
                          <Text style={styles.errorText}>{error}</Text>
                        </View>
                      )}

                      <View style={{ flexDirection: 'row', gap: 10 }}>
                        <TouchableOpacity
                          style={styles.backButton}
                          onPress={handleBack}
                          activeOpacity={0.8}
                        >
                          <Ionicons name="arrow-back" size={24} color="#FFF" />
                        </TouchableOpacity>

                        <TouchableOpacity
                          style={[styles.signupButton, { flex: 1 }, (isLoading || !canSubmitStep1) && styles.signupButtonDisabled]}
                          onPress={handleSignup}
                          disabled={isLoading || !canSubmitStep1}
                          activeOpacity={0.8}
                        >
                          <LinearGradient
                            colors={['#237AE6', '#1d64c7']}
                            style={StyleSheet.absoluteFill}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 1 }}
                          />
                          <Text style={styles.signupButtonText}>
                            {isLoading ? 'Creating...' : 'Create account'}
                          </Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                  </Animated.View>
                </View>
              )}

              {isAppleAvailable && (
                <>
                  <View style={styles.dividerContainer}>
                    <View style={styles.dividerLine} />
                    <Text style={styles.dividerText}>or continue with</Text>
                    <View style={styles.dividerLine} />
                  </View>

                  <AppleAuthentication.AppleAuthenticationButton
                    buttonType={AppleAuthentication.AppleAuthenticationButtonType.SIGN_UP}
                    buttonStyle={AppleAuthentication.AppleAuthenticationButtonStyle.WHITE}
                    cornerRadius={16}
                    style={styles.appleButton}
                    onPress={handleAppleSignup}
                  />
                </>
              )}

              <View style={styles.termsContainer}>
                <Text style={styles.termsText}>
                  By creating an account, you agree to our <Text style={styles.termsLink}>Terms of Service</Text> and{' '}
                  <Text style={styles.termsLink}>Privacy Policy</Text>
                </Text>
              </View>
            </View>

            {/* Sign In Link Removed from bottom */}
            {/* <View style={styles.loginContainer}>
              <Text style={styles.loginText}>Already have an account?</Text>
              <TouchableOpacity onPress={handleLogin} activeOpacity={0.7}>
                <Text style={styles.loginLink}>Sign in</Text>
              </TouchableOpacity>
            </View> */}

            <View style={styles.footer}>
              <Text style={styles.footerText}>Wish a Wash v1.0.0</Text>
              <Text style={styles.footerText}>© 2025 All rights reserved</Text>
            </View>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0A1929' },
  keyboardView: { flex: 1 },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    paddingTop: Platform.OS === 'ios' ? 100 : 80, // Increased top padding
    paddingBottom: 120, // Significantly increased bottom padding to prevent cutoff
    paddingHorizontal: 0, // Remove horizontal padding from scroll view to let slide container take full width
  },
  animatedContent: {
    width: '100%',
    paddingHorizontal: 20, // Add padding here instead
  },

  logoSection: {
    alignItems: 'center',
    marginBottom: 30, // Reduced from 40
    marginTop: 50, // Reduced from 60
  },
  logoContainer: {
    width: 110, // Reduced from 140
    height: 110, // Reduced from 140
    marginBottom: 20, // Reduced from 24
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 24, // Reduced from 30
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.1)',
    position: 'relative',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 }, // Reduced from 10
    shadowOpacity: 0.5,
    shadowRadius: 12, // Reduced from 15
    elevation: 10, // Reduced from 12
    // backgroundColor: '#000', // Removed to prevent black box before image loads
  },
  logoGradient: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 24, // Reduced from 30
  },
  logoInnerGlow: {
    position: 'absolute',
    top: -16, // Reduced from -20
    left: -16,
    right: -16,
    bottom: -16,
    borderRadius: 28, // Reduced from 36
    backgroundColor: 'rgba(74,158,255,0.2)',
    shadowColor: '#4A9EFF',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 24, // Reduced from 30
  },
  logoImage: {
    width: '100%',
    height: '100%',
    zIndex: 1,
    borderRadius: 22, // Reduced from 28
  },
  welcomeText: {
    fontSize: 22,
    fontWeight: '800',
    color: '#FFFFFF',
    marginBottom: 6,
    letterSpacing: -0.3,
    textShadowColor: 'rgba(0,0,0,0.35)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
  subtitleText: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.88)',
    fontWeight: '600',
    letterSpacing: 0.2,
  },

  userTypeContainer: {
    marginBottom: 20, // Reduced from 24
  },
  userTypeSwitcher: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 999,
    padding: 3,
    gap: 3,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    alignSelf: 'center',
    width: '60%', // Reduced from 65%
  },
  userTypeButton: {
    flex: 1,
    paddingVertical: 6, // Reduced from 8
    paddingHorizontal: 16, // Reduced from 20
    borderRadius: 999,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
  },
  userTypeButtonActive: {
    backgroundColor: '#237AE6',
    shadowColor: '#237AE6',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 4,
    elevation: 4,
  },
  userTypeButtonText: {
    fontSize: 13, // Reduced from 14
    fontWeight: '600',
    color: 'rgba(255,255,255,0.7)',
  },
  userTypeButtonTextActive: {
    color: '#FFFFFF',
    fontWeight: '700',
    textShadowColor: 'rgba(74,158,255,0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },

  formCard: {
    marginBottom: 16, // Reduced from 20
  },
  emailAuthToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10, // Reduced from 12
    marginBottom: 14, // Reduced from 16
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  emailAuthToggleText: {
    fontSize: 14, // Reduced from 15
    color: '#FFFFFF',
    fontWeight: '600',
    marginRight: 8,
  },
  inputWrapper: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 14,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    position: 'relative',
    minHeight: 48,
  },
  inputIconContainer: {
    paddingLeft: 16, // Reduced from 18
    justifyContent: 'center',
    alignItems: 'center',
  },
  inputIcon: {
    marginRight: 0,
  },
  input: {
    flex: 1,
    paddingVertical: 14, // Reduced from 18
    paddingHorizontal: 16, // Reduced from 18
    paddingLeft: 10, // Reduced from 12
    fontSize: 14, // Reduced from 15
    color: '#FFFFFF',
    fontWeight: '500',
  },
  passwordWrapper: {
    borderColor: 'rgba(255,255,255,0.35)',
    borderWidth: 1.5,
  },
  passwordInput: {
    flex: 1,
    paddingVertical: 14, // Reduced from 18
    paddingHorizontal: 16, // Reduced from 18
    paddingRight: 44, // Reduced from 50
    fontSize: 14, // Reduced from 15
    color: '#FFFFFF',
    fontWeight: '500',
  },
  passwordToggle: {
    position: 'absolute',
    right: 12, // Reduced from 16
    padding: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(239, 68, 68, 0.15)',
    borderRadius: 10, // Reduced from 12
    padding: 10, // Reduced from 12
    marginBottom: 12, // Reduced from 14
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.3)',
  },
  errorText: { flex: 1, color: '#FCA5A5', fontSize: 13, fontWeight: '600' }, // Reduced from 14
  passwordHint: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.6)',
    marginTop: 6,
    marginLeft: 4,
  },
  inlineError: {
    fontSize: 12,
    color: 'rgba(248,113,113,0.95)',
    marginTop: 4,
    marginLeft: 4,
  },

  signupButton: {
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    overflow: 'hidden',
    position: 'relative',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    shadowColor: '#237AE6',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.45,
    shadowRadius: 10,
    elevation: 8,
  },
  signupButtonDisabled: { opacity: 0.6 },
  signupButtonText: {
    fontSize: 15,
    fontWeight: '700',
    color: '#FFFFFF',
    letterSpacing: 0.3,
    zIndex: 1,
    textShadowColor: 'rgba(0,0,0,0.2)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
  },
  backButton: {
    flex: 0.35,
    backgroundColor: 'rgba(255,255,255,0.12)',
    borderRadius: 14,
    paddingVertical: 14,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },

  dividerContainer: { flexDirection: 'row', alignItems: 'center', marginVertical: 14 }, // Reduced from 16
  dividerLine: { flex: 1, height: 1, backgroundColor: 'rgba(255,255,255,0.2)' },
  dividerText: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 11, // Reduced from 12
    fontWeight: '400',
    marginHorizontal: 10, // Reduced from 12
  },

  appleButton: { width: '100%', height: 44, marginBottom: 14 }, // Reduced height from 48, margin from 16

  termsContainer: { marginTop: 2 },
  termsText: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.6)',
    textAlign: 'center',
    lineHeight: 16,
  },
  termsLink: { 
    color: '#60D9FF', 
    fontWeight: '600',
    textShadowColor: 'rgba(96,217,255,0.2)',
    textShadowOffset: { width: 0, height: 0.5 },
    textShadowRadius: 1,
  },

  loginContainer: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginBottom: 12 },
  loginText: { 
    fontSize: 15, 
    color: 'rgba(255,255,255,0.9)', 
    marginRight: 6, 
    fontWeight: '600' 
  },
  loginLink: { 
    fontSize: 15, 
    color: '#60D9FF', 
    fontWeight: '700',
    textShadowColor: 'rgba(96,217,255,0.3)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
  },

  footer: { alignItems: 'center', marginTop: 10 },
  footerText: { fontSize: 11, color: 'rgba(255,255,255,0.4)', marginBottom: 2, fontWeight: '400' },
  topRightContainer: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 60 : 45,
    right: 25,
    zIndex: 10,
  },
  topRightText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '600',
    opacity: 0.9,
  },
});
