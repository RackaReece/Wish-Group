import React, { useEffect, useState, useRef } from 'react';
import { Animated } from 'react-native';
import { Stack } from 'expo-router';
import LoadingScreen from '../../src/components/LoadingScreen';

export default function AuthLayout() {
  const [showSplash, setShowSplash] = useState(true);
  const splashOpacity = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const minSplashMs = 1800;
    const fadeOutMs = 400;
    const timer = setTimeout(() => {
      Animated.timing(splashOpacity, {
        toValue: 0,
        duration: fadeOutMs,
        useNativeDriver: true,
      }).start(() => setShowSplash(false));
    }, minSplashMs);
    return () => clearTimeout(timer);
  }, [splashOpacity]);

  if (showSplash) {
    return (
      <Animated.View style={{ flex: 1, opacity: splashOpacity }}>
        <LoadingScreen message="Loading..." />
      </Animated.View>
    );
  }

  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="login" />
      <Stack.Screen name="signup" />
    </Stack>
  );
}
