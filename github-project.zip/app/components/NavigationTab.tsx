import React, { useMemo, useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Platform,
  Modal,
  Pressable,
  Animated,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname, useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { supabase } from '../../src/lib/supabase';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { getIconColors, getTextColors } from '../../src/constants/themeColors';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import GlassCard from '../../src/components/booking/GlassCard';
import { useGlobalTheme } from '../../src/components/shared/GlobalThemeContext';
import { useValeterNavState } from '../../src/contexts/ValeterNavStateContext';
const TAB_BAR_HEIGHT = 72;
const BAR_MARGIN_H = 20;
const BAR_RADIUS = 36;

// Light blue for nav tab icons in light mode (valeter/business)
const LIGHT_MODE_NAV_ICON = '#7DD3FC';

// Business: individual floating icons (no shared bar)
const FLOATING_ICON_SIZE = 52;
const FLOATING_ICON_RADIUS = FLOATING_ICON_SIZE / 2;
const FLOATING_ICON_GAP = 10;

// Used by screens to pad content above the bar (valeter pill = 64; business icons ~54)
const TAB_BAR_TOTAL_HEIGHT = 64;
export { TAB_BAR_TOTAL_HEIGHT };

type IoniconsName = keyof typeof Ionicons.glyphMap;

interface Tab {
  name: string;
  iconName: IoniconsName;
  route: string;
}

const getTabs = (userType?: string): Tab[] => {
  if (userType === 'valeter') {
    return [
      { name: 'Home', iconName: 'home', route: '/valeter/valeter-dashboard' },
      { name: 'Jobs', iconName: 'briefcase', route: '/valeter/jobs' },
      { name: 'Trips', iconName: 'navigate', route: '/valeter/trips' },
      { name: 'Schedule', iconName: 'time', route: '/valeter/settings/working-hours' },
      { name: 'Profile', iconName: 'person', route: '/valeter/profile/valeter-profile' },
    ];
  }

  if (userType === 'organization') {
    return [
      { name: 'Home', iconName: 'home', route: '/business/dashboard' },
      { name: 'Locations', iconName: 'location', route: '/business/locations' },
      { name: 'Bookings', iconName: 'calendar', route: '/business/bookings' },
      { name: 'Members', iconName: 'people', route: '/business/team' },
      { name: 'Profile', iconName: 'person', route: '/business/profile' },
    ];
  }

  // Owner/customer pages removed – no tabs for customer
  return [];
};

const getActiveIndex = (pathname: string, tabs: Tab[]): number => {
  if (pathname.includes('/booking')) {
    const bookIndex = tabs.findIndex((t) => t.route.includes('/booking'));
    return bookIndex >= 0 ? bookIndex : 0;
  }

  if (pathname.includes('/rewards')) {
    const rewardsIndex = tabs.findIndex((t) => t.route === '/rewards' || t.route.includes('rewards'));
    return rewardsIndex >= 0 ? rewardsIndex : 0;
  }

  if (pathname.includes('/valeter/jobs')) {
    const jobsIndex = tabs.findIndex((t) => t.route === '/valeter/jobs');
    return jobsIndex >= 0 ? jobsIndex : 0;
  }

  if (pathname.includes('/valeter/trips')) {
    const tripsIndex = tabs.findIndex((t) => t.route === '/valeter/trips');
    return tripsIndex >= 0 ? tripsIndex : 0;
  }

  if (pathname.includes('/valeter/settings/working-hours')) {
    const scheduleIndex = tabs.findIndex((t) => t.route === '/valeter/settings/working-hours');
    return scheduleIndex >= 0 ? scheduleIndex : 0;
  }
  if (pathname.includes('/valeter/settings/distance-covering')) {
    const radiusIndex = tabs.findIndex((t) => t.route === '/valeter/settings/distance-covering');
    return radiusIndex >= 0 ? radiusIndex : 0;
  }

  if (pathname.includes('/valeter/profile/valeter-profile') || pathname.includes('/valeter/valeter-profile')) {
    const profileIndex = tabs.findIndex((t) => t.route === '/valeter/profile/valeter-profile');
    return profileIndex >= 0 ? profileIndex : 0;
  }

  if (pathname.includes('/business/dashboard')) {
    const homeIndex = tabs.findIndex((t) => t.route === '/business/dashboard');
    return homeIndex >= 0 ? homeIndex : 0;
  }
  if (pathname.includes('/business/locations')) {
    const locationsIndex = tabs.findIndex((t) => t.route === '/business/locations');
    return locationsIndex >= 0 ? locationsIndex : 0;
  }
  if (pathname.includes('/business/bookings')) {
    const bookingsIndex = tabs.findIndex((t) => t.route === '/business/bookings');
    return bookingsIndex >= 0 ? bookingsIndex : 0;
  }
  if (pathname.includes('/business/team')) {
    const teamIndex = tabs.findIndex((t) => t.route === '/business/team');
    return teamIndex >= 0 ? teamIndex : 0;
  }
  if (pathname.includes('/business/profile')) {
    const profileIndex = tabs.findIndex((t) => t.route === '/business/profile');
    return profileIndex >= 0 ? profileIndex : 0;
  }

  for (let i = 0; i < tabs.length; i++) {
    if (pathname === tabs[i].route || pathname.startsWith(tabs[i].route + '/')) return i;
  }

  return 0;
};

export default function NavigationTab() {
  const { mode } = useGlobalTheme();
  const pathname = usePathname();
  const router = useRouter();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const valeterNavState = useValeterNavState();
  const tripsGlowAnim = useRef(new Animated.Value(1)).current;

  const isBusinessRoute =
    pathname.includes('/business/') ||
    pathname.includes('/Business/') ||
    pathname.includes('/organisation/') ||
    pathname.includes('/Organization/');
  const businessTheme = isBusinessRoute ? getAccountTheme('business') : null;

  const isCustomerRoute = pathname.includes('/owner/') || pathname.includes('/customer');
  const customerTheme = isCustomerRoute ? getAccountTheme('customer') : null;

  const accountTypeForBubbles: 'customer' | 'valeter' | 'business' = useMemo(() => {
    if (pathname.includes('/valeter/')) return 'valeter';
    if (isBusinessRoute) return 'business';
    return 'customer';
  }, [pathname, isBusinessRoute]);

  // Get the theme for the current account type (matches header logic)
  const currentTheme = useMemo(() => {
    if (pathname.includes('/valeter/')) return getAccountTheme('valeter', mode);
    if (isBusinessRoute) return getAccountTheme('business', mode);
    return getAccountTheme('customer', mode);
  }, [pathname, isBusinessRoute, mode]);

  const tabs = useMemo(() => {
    const userType = user?.userType;

    if (pathname.includes('/owner/') || pathname.includes('/customer')) return [];
    if (pathname.includes('/valeter/')) return getTabs('valeter');
    if (isBusinessRoute) return getTabs('organization');

    const safeUserType: 'customer' | 'valeter' | 'organization' =
      userType === 'valeter' ? 'valeter'
      : userType === 'organization' || (userType as string) === 'business' ? 'organization'
      : 'customer';

    if (userType === 'valeter' && !pathname.includes('/valeter/') && !pathname.includes('/driver/')) {
      return getTabs('customer');
    }

    return getTabs(safeUserType);
  }, [user?.userType, user?.email, pathname, isBusinessRoute]);

  const activeIndex = useMemo(() => getActiveIndex(pathname, tabs), [pathname, tabs]);

  const accent = currentTheme?.primary || colors.navActive;
  const iconColors = currentTheme ? getIconColors(currentTheme) : { active: colors.navActive, inactive: 'rgba(255,255,255,0.65)' };
  const textColors = currentTheme ? getTextColors(currentTheme) : { primary: '#F9FAFB', secondary: 'rgba(255,255,255,0.8)' };

  // Use same colors as cards for nav tab (match card look)
  const cardGradient = currentTheme?.cardBackgroundGradient || currentTheme?.headerBackground || currentTheme?.background || ['rgba(30,58,138,0.6)', 'rgba(15,23,42,0.5)'];


  const searchParams = useLocalSearchParams();
  const isTripsPage = pathname.includes('/business/bookings') && searchParams.filter === 'in_progress';

  const shouldHideTab = useMemo(() => {
    const hideRoutes = [
      '/auth/',
      '/onboarding',
      '/customer-onboarding',
      '/organisation/organization-onboarding',
      '/chat-screen',
    ];
    return hideRoutes.some((route) => pathname.includes(route)) || isTripsPage;
  }, [pathname, isTripsPage]);

  const isProfileTab = (tab: Tab) => tab.name === 'Profile';
  const isTripsTab = (tab: Tab) => tab.name === 'Trips' && tab.route === '/valeter/trips';

  const inactiveIcon = iconColors.inactive;

  // Trips tab: pulse glow when active trip
  useEffect(() => {
    if (!valeterNavState?.hasActiveTrips) return;
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(tripsGlowAnim, { toValue: 1.15, duration: 800, useNativeDriver: true }),
        Animated.timing(tripsGlowAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [valeterNavState?.hasActiveTrips, tripsGlowAnim]);

  useEffect(() => {
    const loadProfilePicture = async () => {
      if (!user?.id) return;

      try {
        if (user.profilePicture) {
          setProfilePicture(user.profilePicture);
          return;
        }

        if (user.userType === 'organization' || (user.userType as string) === 'business') {
          const { data: profileData, error: profileError } = await supabase
            .from('profiles')
            .select('avatar_url, profile_picture')
            .eq('id', user.id)
            .maybeSingle();

          if (!profileError && profileData) {
            const picUrl = (profileData as any).avatar_url || (profileData as any).profile_picture;
            if (picUrl) {
              setProfilePicture(picUrl);
              return;
            }
          }

          const { data: orgData, error: orgError } = await supabase
            .from('organizations')
            .select('*')
            .eq('id', user.id)
            .maybeSingle();

          if (!orgError && orgData && (orgData as any).logo) {
            setProfilePicture((orgData as any).logo);
            return;
          }
        } else {
          const tableName = user.userType === 'valeter' ? 'valeter_profiles' : 'customer_profiles';
          const { data, error } = await supabase
            .from(tableName)
            .select('avatar_url, profile_picture')
            .eq('user_id', user.id)
            .maybeSingle();

          if (!error && data) {
            const picUrl = (data as any).avatar_url || (data as any).profile_picture;
            if (picUrl) setProfilePicture(picUrl);
          }
        }
      } catch (error) {
        console.error('[NavigationTab] Error loading profile picture:', error);
      }
    };

    loadProfilePicture();
  }, [user?.id, user?.profilePicture, user?.userType]);

  const bottomPad = Math.max(insets.bottom, 10);

  if (shouldHideTab || tabs.length === 0) return null;

  const isLightMode = currentTheme?.mode === 'light';
  const isValeterLight = pathname.includes('/valeter/') && isLightMode;
  const isBusinessLight = pathname.includes('/business/') && isLightMode;
  // Valeter light with dark bottom: dark bar + white text/icons; business light: sky-tinted bar + light blue icons; else dark bar
  const valeterLightDarkBottom = isValeterLight && (currentTheme as { navBarBottomDark?: string })?.navBarBottomDark;
  const useDarkBar = (isLightMode && !isValeterLight && !isBusinessLight) || valeterLightDarkBottom;
  const navBarTint = useDarkBar ? 'dark' : (isValeterLight && !valeterLightDarkBottom || isBusinessLight ? 'light' : 'dark');
  const navBarGradient = valeterLightDarkBottom
    ? [(currentTheme as { navBarBottomDark?: string }).navBarBottomDark!, (currentTheme as { navBarBottomDark?: string }).navBarBottomDark!]
    : isValeterLight && !valeterLightDarkBottom
      ? (currentTheme?.cardBackgroundGradient ?? [currentTheme?.navBarBackground ?? '#FFFFFF', currentTheme?.navBarBackground ?? '#FFFFFF'])
      : isBusinessLight
        ? (currentTheme?.headerBackground ?? ['rgba(125,211,252,0.28)', 'rgba(30,58,138,0.24)'])
        : useDarkBar
          ? ['rgba(15,23,42,0.94)', 'rgba(30,41,59,0.92)']
          : (currentTheme?.cardBackgroundGradient || currentTheme?.headerBackground || currentTheme?.background || ['rgba(30,58,138,0.6)', 'rgba(15,23,42,0.5)']);
  const navInactiveIcon = useDarkBar ? 'rgba(255,255,255,0.8)' : (isBusinessLight ? 'rgba(125,211,252,0.85)' : (isLightMode ? (iconColors.inactive || LIGHT_MODE_NAV_ICON) : iconColors.inactive));
  const navActiveIcon = useDarkBar ? '#FFFFFF' : (isBusinessLight ? (accent || '#7DD3FC') : (isLightMode ? (accent || LIGHT_MODE_NAV_ICON) : accent));
  const navActiveGlow = isValeterLight ? (currentTheme?.navActiveGlow ?? accent) : accent;
  const floatingIconBaseBg = isLightMode ? 'rgba(15,23,42,0.18)' : 'rgba(0,0,0,0.35)';

  const isValeterRoute = pathname.includes('/valeter/');
  const isTripsTabActive = pathname.includes('/valeter/trips');
  // Softer accent for Trips tab when active — reduces visual competition with main CTA
  const tripsTabSoftAccent = 'rgba(148,197,219,0.95)';
  // Dark mode: use original navy card gradient; light mode: use header gradient
  const navBlueGradient = isValeterRoute && !isLightMode
    ? (currentTheme?.cardBackgroundGradient || ['rgba(37,99,235,0.5)', 'rgba(30,58,138,0.45)'])
    : (currentTheme?.headerBackground || ['rgba(37,99,235,0.45)', 'rgba(30,58,138,0.35)']) as [string, string];

  return (
    <View pointerEvents="box-none" style={styles.screenWrap}>
      <View pointerEvents="none" style={[styles.underlay, { top: 0, bottom: 0 }]} />

      {/* Valeter light mode: floating icons with notification bell colours */}
      {isValeterRoute && isLightMode ? (
        <View style={[styles.floatingRow, { marginBottom: bottomPad, paddingHorizontal: BAR_MARGIN_H }]}>
          {tabs.map((tab, index) => {
            const isActive = index === activeIndex;
            const handleTabPress = async () => {
              if (isActive) return;
              await hapticFeedback('light');
              router.push(tab.route as any);
            };
            return (
              <TouchableOpacity
                key={tab.route}
                onPress={handleTabPress}
                activeOpacity={0.85}
                disabled={isActive}
                style={styles.floatingIconTouch}
                accessibilityLabel={`Go to ${tab.name}`}
                accessibilityRole="button"
              >
                <View
                  style={[
                    styles.floatingIconCircle,
                    { backgroundColor: floatingIconBaseBg },
                    {
                      borderColor: isActive ? (isTripsTab(tab) && pathname.includes('/valeter/trips') ? 'rgba(148,197,219,0.9)' : '#60A5FA') : 'rgba(96,165,250,0.35)',
                      shadowColor: isActive ? (isTripsTab(tab) && pathname.includes('/valeter/trips') ? 'rgba(148,197,219,0.5)' : '#60A5FA') : 'rgba(59,130,246,0.2)',
                      shadowOpacity: isActive ? (isTripsTab(tab) && pathname.includes('/valeter/trips') ? 0.28 : 0.4) : 0.15,
                      shadowRadius: isActive ? 10 : 8,
                      shadowOffset: { width: 0, height: 4 },
                      elevation: isActive ? 12 : 8,
                    },
                    isActive && styles.floatingIconCircleActive,
                  ]}
                >
                  <BlurView
                    intensity={Platform.OS === 'ios' ? (isTripsTab(tab) && pathname.includes('/valeter/trips') && isActive ? 42 : 35) : (isTripsTab(tab) && pathname.includes('/valeter/trips') && isActive ? 35 : 28)}
                    tint="light"
                    style={StyleSheet.absoluteFill}
                  >
                    <LinearGradient
                      colors={
                        isActive
                          ? isTripsTab(tab) && pathname.includes('/valeter/trips')
                            ? ['rgba(148,197,219,0.4)', 'rgba(148,197,219,0.25)']
                            : ['rgba(96,165,250,0.5)', 'rgba(59,130,246,0.35)']
                          : ['rgba(96,165,250,0.25)', 'rgba(59,130,246,0.18)']
                      }
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 1 }}
                      style={StyleSheet.absoluteFill}
                    />
                  </BlurView>
                  <View style={StyleSheet.absoluteFill} pointerEvents="none">
                    <View style={[styles.floatingIconInner, { borderColor: isValeterLight ? 'rgba(125,211,252,0.35)' : 'rgba(59,130,246,0.2)' }]} />
                  </View>
                  {isTripsTab(tab) && valeterNavState ? (
                    <Animated.View style={[styles.floatingIcon, valeterNavState.hasActiveTrips && { transform: [{ scale: tripsGlowAnim }] }]}>
                      <Ionicons
                        name={valeterNavState.hasActiveTrips ? 'navigate' : 'navigate-outline'}
                        size={isActive ? 24 : 22}
                        color={isActive ? '#FFFFFF' : (navInactiveIcon || LIGHT_MODE_NAV_ICON)}
                      />
                      {valeterNavState.hasNewJobOffer && (
                        <View style={[styles.tripsNewJobDot, { backgroundColor: '#10B981' }]} />
                      )}
                    </Animated.View>
                  ) : (
                    <Ionicons
                      name={tab.iconName}
                      size={isActive ? 24 : 22}
                      color={isActive ? '#FFFFFF' : (navInactiveIcon || LIGHT_MODE_NAV_ICON)}
                      style={styles.floatingIcon}
                    />
                  )}
                </View>
              </TouchableOpacity>
            );
          })}
        </View>
      ) : (
        /* Valeter dark + Business: individual floating icons */
        <View style={[styles.floatingRow, { marginBottom: bottomPad, paddingHorizontal: BAR_MARGIN_H }]}>
          {tabs.map((tab, index) => {
            const isActive = index === activeIndex;
            const useLightBlur = !useDarkBar && (isValeterLight || (isBusinessRoute && isLightMode));

            const handleTabPress = async () => {
              if (isActive) return;
              await hapticFeedback('light');
              router.push(tab.route as any);
            };

            return (
              <TouchableOpacity
                key={tab.route}
                onPress={handleTabPress}
                activeOpacity={0.85}
                disabled={isActive}
                style={styles.floatingIconTouch}
                accessibilityLabel={`Go to ${tab.name}`}
                accessibilityRole="button"
              >
                <View
                  style={[
                    styles.floatingIconCircle,
                    { backgroundColor: floatingIconBaseBg },
                    useDarkBar && { borderColor: 'rgba(255,255,255,0.3)' },
                    !useDarkBar && isValeterLight && { borderColor: 'rgba(11,60,93,0.2)' },
                    isActive && [
                      styles.floatingIconCircleActive,
                      {
                        borderColor: isTripsTab(tab) && isTripsTabActive ? tripsTabSoftAccent : accent,
                        shadowColor: isTripsTab(tab) && isTripsTabActive ? tripsTabSoftAccent : (isValeterLight ? navActiveGlow : accent),
                        shadowOpacity: isTripsTab(tab) && isTripsTabActive ? 0.3 : (isValeterLight ? 0.5 : 0.45),
                      },
                      isValeterLight && !(isTripsTab(tab) && isTripsTabActive) && { shadowRadius: 10 },
                    ],
                  ]}
                >
                  <BlurView
                    intensity={Platform.OS === 'ios' ? (useLightBlur ? 60 : (useDarkBar ? 50 : (isTripsTab(tab) && isTripsTabActive ? 55 : 28))) : (useLightBlur ? 50 : (useDarkBar ? 45 : (isTripsTab(tab) && isTripsTabActive ? 48 : 22)))}
                    tint={navBarTint}
                    style={StyleSheet.absoluteFill}
                  >
                    <LinearGradient
                      colors={
                        isActive
                          ? isTripsTab(tab) && isTripsTabActive
                            ? ['rgba(148,197,219,0.35)', 'rgba(148,197,219,0.2)']
                            : [`${accent}40`, `${accent}25`]
                          : [navBarGradient[0], navBarGradient[1] || navBarGradient[0]]
                      }
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 1 }}
                      style={StyleSheet.absoluteFill}
                    />
                  </BlurView>
                  <View style={StyleSheet.absoluteFill} pointerEvents="none">
                    <View style={[styles.floatingIconInner, { borderColor: useDarkBar ? 'rgba(255,255,255,0.18)' : (isValeterLight ? 'rgba(11,60,93,0.12)' : (currentTheme?.cardBorder || currentTheme?.glassBorder || 'rgba(255,255,255,0.14)')) }]} />
                  </View>
                  {isTripsTab(tab) && valeterNavState ? (
                    <Animated.View
                      style={[
                        styles.floatingIcon,
                        valeterNavState.hasActiveTrips && { transform: [{ scale: tripsGlowAnim }] },
                      ]}
                    >
                      <Ionicons
                        name={valeterNavState.hasActiveTrips ? 'navigate' : 'navigate-outline'}
                        size={isActive ? 24 : 22}
                        color={isActive ? navActiveIcon : navInactiveIcon}
                      />
                      {valeterNavState.hasNewJobOffer && (
                        <View style={[styles.tripsNewJobDot, { backgroundColor: '#10B981' }]} />
                      )}
                    </Animated.View>
                  ) : (
                    <Ionicons
                      name={tab.iconName}
                      size={isActive ? 24 : 22}
                      color={isActive ? navActiveIcon : navInactiveIcon}
                      style={styles.floatingIcon}
                    />
                  )}
                </View>
              </TouchableOpacity>
            );
          })}
        </View>
      )}

    </View>
  );
}

const styles = StyleSheet.create({
  screenWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    zIndex: 9999,
    elevation: 30,
  },

  // ✅ Full screen background underlay
  underlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    backgroundColor: 'transparent',
  },


  /* Valeter dark: improved pill bar */
  navPillWrap: {
    width: '100%',
    alignItems: 'center',
  },
  navPillBar: {
    width: '100%',
    maxWidth: 400,
    height: 64,
    borderRadius: 32,
    overflow: 'hidden',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    paddingHorizontal: 8,
    shadowColor: '#2563EB',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 16,
    elevation: 16,
  },
  navPillBarLight: {
    shadowColor: '#60A5FA',
    shadowOpacity: 0.4,
  },
  navPillInner: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 32,
  },
  navPillRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    flex: 1,
    zIndex: 2,
  },
  navPillTab: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    paddingHorizontal: 4,
    position: 'relative',
  },
  navPillTabActivePill: {
    position: 'absolute',
    width: 44,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.2)',
    zIndex: 0,
  },
  navPillTabActivePillLight: {
    backgroundColor: 'rgba(255,255,255,0.28)',
  },
  navPillLabel: {
    fontSize: 10,
    fontWeight: '700',
    marginTop: 2,
    letterSpacing: 0.2,
  },
  tripsNewJobDotOnPill: {
    position: 'absolute',
    top: -2,
    right: '50%',
    marginRight: -14,
  },

  // Business: individual floating icons
  floatingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    gap: FLOATING_ICON_GAP,
  },
  floatingIconTouch: {
    padding: 4,
  },
  floatingIconCircle: {
    width: FLOATING_ICON_SIZE,
    height: FLOATING_ICON_SIZE,
    borderRadius: FLOATING_ICON_RADIUS,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.18,
    shadowRadius: 14,
    elevation: 10,
  },
  floatingIconCircleActive: {
    borderWidth: 1.5,
    shadowOpacity: 0.5,
    shadowRadius: 18,
    elevation: 18,
    transform: [{ scale: 1.04 }],
  },
  floatingIconInner: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: FLOATING_ICON_RADIUS,
    borderWidth: 1,
    opacity: 0.7,
  },
  floatingIcon: {
    zIndex: 2,
  },
  tripsNewJobDot: {
    position: 'absolute',
    top: -2,
    right: -2,
    width: 8,
    height: 8,
    borderRadius: 4,
    borderWidth: 1.5,
    borderColor: 'rgba(0,0,0,0.2)',
    zIndex: 3,
  },

  bar: {
    height: TAB_BAR_HEIGHT,
    marginHorizontal: BAR_MARGIN_H,
    overflow: 'hidden',
    justifyContent: 'center',
    backgroundColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 28,
  },

  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
    borderRadius: BAR_RADIUS,
  },

  glowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 8,
  },


  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  tab: {
    height: TAB_BAR_HEIGHT,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 1,
    minWidth: 60,
  },

  iconContainer: {
    position: 'relative',
    marginBottom: 4,
    alignItems: 'center',
    justifyContent: 'center',
    width: 26,
    height: 26,
    borderRadius: 13,
  },
  
  iconContainerActive: {
    // No border needed - the capsule provides the highlight
  },

  icon: {
    zIndex: 2,
  },

  iconActive: {
    transform: [{ scale: 1.05 }],
    shadowColor: '#7DD3FC',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
  },
  
  iconActiveValeter: {
    // Enhanced glow for valeter and business icons
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 12,
    transform: [{ scale: 1.1 }],
  },

  iconGlow: {
    position: 'absolute',
    width: 28,
    height: 28,
    borderRadius: 14,
    zIndex: 1,
    opacity: 0.4,
  },
  
  iconGlowValeter: {
    // Subtle glow for valeter and business - just around icon
    width: 30,
    height: 30,
    borderRadius: 15,
    opacity: 0.5,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 8,
  },

  labelLayout: {
    marginTop: 2,
    textAlign: 'center' as const,
    width: '100%',
    paddingHorizontal: 1,
  },

  labelActive: {
    fontFamily: 'Rubik_700Bold',
    letterSpacing: 0.4,
  },

  avatarWrap: {
    width: 28,
    height: 28,
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.25)',
    marginBottom: 4,
    backgroundColor: 'rgba(255,255,255,0.08)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 4,
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },

  avatarWrapActive: {
    borderWidth: 2.5,
    borderColor: '#7DD3FC',
    shadowColor: '#7DD3FC',
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 6,
  },

  avatarBorder: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    borderRadius: 14,
    borderWidth: 0,
    zIndex: 1,
    pointerEvents: 'none',
  },

  avatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
    zIndex: 0,
    resizeMode: 'cover',
  },

  avatarGlow: {
    position: 'absolute',
    top: -3,
    left: -3,
    right: -3,
    bottom: -3,
    borderRadius: 14,
    zIndex: -1,
    opacity: 0.5,
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    justifyContent: 'flex-end',
  },

  actionSheetContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  actionSheet: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingTop: 12,
    paddingBottom: 24,
    paddingHorizontal: 0,
    marginHorizontal: 0,
  },
  actionSheetHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.35)',
    alignSelf: 'center',
    marginBottom: 16,
  },
  actionSheetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  actionSheetTitle: {
    fontSize: 20,
    fontWeight: '900',
    color: '#F9FAFB',
    letterSpacing: 0.3,
  },
  actionSheetSubtitle: {
    fontSize: 13,
    color: 'rgba(249,250,251,0.6)',
    marginTop: 2,
    fontWeight: '500',
  },
  actionSheetClose: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  actionSheetContent: {
    paddingHorizontal: 20,
    gap: 12,
  },
  actionSheetItem: {
    marginBottom: 0,
  },
  actionSheetItemCard: {
    padding: 18,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  actionSheetIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionSheetItemText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '800',
    color: '#F9FAFB',
    letterSpacing: 0.2,
  },
});
