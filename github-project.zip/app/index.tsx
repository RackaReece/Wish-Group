// app/index.tsx
import React, { useEffect, useState } from 'react';
import { View } from 'react-native';
import { useRouter, useRootNavigationState } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../src/providers/enhanced-auth-context';

type UserType = 'customer' | 'valeter' | 'business' | 'organization' | undefined;

export default function Index() {
  const router = useRouter();
  const navReady = useRootNavigationState()?.key != null;
  const { user, isLoading, authReady } = useAuth();

  const [seenOnboarding, setSeenOnboarding] = useState<string | null>(null);
  const [onboardingCheckDone, setOnboardingCheckDone] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem('onboarding_seen')
      .then((v) => {
        setSeenOnboarding(v ?? null);
        setOnboardingCheckDone(true);
      })
      .catch(() => {
        setSeenOnboarding(null);
        setOnboardingCheckDone(true);
      });
  }, []);

  useEffect(() => {
    if (!navReady || !onboardingCheckDone) return;

    // 1) Show onboarding first (before login) if user hasn't seen it
    if (seenOnboarding !== 'true') {
      router.replace('/onboarding');
      return;
    }

    // 2) Onboarding already seen – now check auth
    if (!authReady || isLoading) return;

    if (!user) {
      router.replace('/auth/login');
      return;
    }

    const userType = user?.userType as UserType;

    // 3) Logged in → go to dashboards (no separate account-type onboarding)
    if (userType === 'valeter') {
      router.replace('/valeter/valeter-dashboard');
      return;
    }
    if (userType === 'organization') {
      router.replace('/business/dashboard');
      return;
    }

    router.replace('/auth/login');
  }, [navReady, onboardingCheckDone, seenOnboarding, authReady, isLoading, user, router]);

  // Root BootProvider shows LoadingScreen during boot/auth; no full-screen loader here
  return <View style={{ flex: 1 }} />;
}