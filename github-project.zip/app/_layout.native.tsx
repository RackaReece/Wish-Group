// app/_layout.native.tsx – Root layout for iOS/Android (with Stripe); splash uses LoadingScreen during boot.
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider } from '../src/providers/enhanced-auth-context';
import { BootProvider } from '../src/contexts/BootContext';
import { LogBox, Text, TextInput } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';
import { StripeProvider } from '@stripe/stripe-react-native';
import NavigationTab from './components/NavigationTab';
import { GlobalThemeProvider } from '../src/components/shared/GlobalThemeContext';

(async () => {
  try {
    await SplashScreen.preventAutoHideAsync();
  } catch (e) {
    console.warn('[Splash] preventAutoHideAsync error:', e);
  }
})();

LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
  'AsyncStorage has been extracted from react-native',
]);

const rubikDefault = { fontFamily: 'Rubik_400Regular' };
const TextAny = Text as React.ComponentType<any> & { defaultProps?: { style?: object } };
const TextInputAny = TextInput as React.ComponentType<any> & { defaultProps?: { style?: object } };
if (TextAny.defaultProps == null) TextAny.defaultProps = {};
TextAny.defaultProps.style = rubikDefault;
if (TextInputAny.defaultProps == null) TextInputAny.defaultProps = {};
TextInputAny.defaultProps.style = rubikDefault;

export default function RootLayoutNative() {
  return (
    <StripeProvider
      publishableKey="pk_test_51S3OQLGYkpu3JDyWrHRRw6kvG9t4BNGpCiFVDAUeQCptnXAFJYnNEyWyv1HJG7XYsOd7Io4qYAn9T4deCcYUu2zC00O9yRUMdU"
      merchantIdentifier="merchant.com.wishawash"
      urlScheme="waw"
    >
      <AuthProvider>
        <BootProvider>
          <GlobalThemeProvider initialMode="dark">
            <StatusBar style="light" backgroundColor="#1E3A8A" />
            <Stack
              screenOptions={{
                headerShown: false,
                contentStyle: { backgroundColor: '#0A1929' },
                animation: 'fade',
                animationDuration: 400,
                gestureEnabled: true,
              }}
            />
            <NavigationTab />
          </GlobalThemeProvider>
        </BootProvider>
      </AuthProvider>
    </StripeProvider>
  );
}
