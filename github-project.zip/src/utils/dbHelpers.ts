/**
 * Shared helpers for Supabase/DB error handling.
 */

/** Detect if a Supabase error indicates a missing table or schema issue. */
export function isMissingTableErr(err: unknown): boolean {
  const msg = String((err as { message?: string })?.message ?? '').toLowerCase();
  return (
    msg.includes('does not exist') ||
    msg.includes('relation') ||
    msg.includes('schema cache')
  );
}
