/**
 * Fallback directions provider using OSRM public API.
 * Returns the same shape as expo-mapkit-directions (MapKitRouteResult) so the
 * navigation screen can use in-app turn-by-turn when MapKit isn't available
 * (Android, or iOS in Expo Go).
 */

const OSRM_BASE = 'https://router.project-osrm.org/route/v1/driving';

export interface RouteStep {
  instruction: string;
  distanceMeters: number;
  polylineEndIndex: number;
}

export interface MapKitRouteResult {
  polyline: { latitude: number; longitude: number }[];
  steps: RouteStep[];
  distanceMeters: number;
  expectedTravelTimeSeconds: number;
}

function formatManeuver(maneuver: { type?: string; modifier?: string }, name?: string): string {
  const type = maneuver?.type ?? '';
  const modifier = maneuver?.modifier ?? '';
  const street = name?.trim() ? ` on ${name}` : '';
  if (type === 'depart') return `Head to destination${street}`;
  if (type === 'arrive') return 'Arrive at destination';
  if (type === 'turn') {
    const dir = modifier ? `${modifier} ` : '';
    return `Turn ${dir}${street}`.trim();
  }
  if (type === 'continue' && modifier) return `Continue ${modifier}${street}`.trim();
  if (name) return name;
  return 'Continue';
}

/** Find index in polyline (array of {lat,lng}) closest to [lng, lat] */
function closestPointIndex(
  polyline: { latitude: number; longitude: number }[],
  lng: number,
  lat: number
): number {
  let best = 0;
  let bestD = 1e30;
  for (let i = 0; i < polyline.length; i++) {
    const p = polyline[i];
    const d = (p.longitude - lng) ** 2 + (p.latitude - lat) ** 2;
    if (d < bestD) {
      bestD = d;
      best = i;
    }
  }
  return best;
}

export async function getDirectionsOSRM(
  fromLat: number,
  fromLng: number,
  toLat: number,
  toLng: number
): Promise<MapKitRouteResult | null> {
  // OSRM expects lon,lat
  const coords = `${fromLng},${fromLat};${toLng},${toLat}`;
  const url = `${OSRM_BASE}/${coords}?overview=full&geometries=geojson&steps=true`;

  try {
    const res = await fetch(url);
    if (!res.ok) return null;
    const data = await res.json();
    if (data.code !== 'Ok' || !data.routes?.[0]) return null;

    const route = data.routes[0];
    const geom = route.geometry?.coordinates;
    if (!Array.isArray(geom) || geom.length === 0) return null;

    const polyline = geom.map(([lng, lat]: number[]) => ({ latitude: lat, longitude: lng }));

    const legs = route.legs ?? [];
    const steps: RouteStep[] = [];
    for (const leg of legs) {
      const stepList = leg.steps ?? [];
      for (const s of stepList) {
        const coord = s.geometry?.coordinates;
        const lastCoord = Array.isArray(coord) && coord.length > 0 ? coord[coord.length - 1] : null;
        const [lng, lat] = lastCoord ?? [toLng, toLat];
        const endIndex = closestPointIndex(polyline, lng, lat);
        steps.push({
          instruction: formatManeuver(s.maneuver ?? {}, s.name),
          distanceMeters: Math.round(s.distance ?? 0),
          polylineEndIndex: endIndex,
        });
      }
    }

    const distanceMeters = Math.round(route.distance ?? 0);
    const expectedTravelTimeSeconds = Math.round(route.duration ?? 0);

    return {
      polyline,
      steps: steps.length > 0 ? steps : [{ instruction: 'Drive to destination', distanceMeters, polylineEndIndex: polyline.length - 1 }],
      distanceMeters,
      expectedTravelTimeSeconds,
    };
  } catch {
    return null;
  }
}
