import type { Ionicons } from '@expo/vector-icons';

/** Relative time for job request (e.g. "Just now", "5 mins ago") */
export function formatRelativeTime(dateString: string): string {
  const now = new Date();
  const date = new Date(dateString);
  const diffMs = now.getTime() - date.getTime();
  const diffMins = Math.floor(diffMs / (1000 * 60));
  const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
  const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins} ${diffMins === 1 ? 'min' : 'mins'} ago`;
  if (diffHours < 24) return `${diffHours} ${diffHours === 1 ? 'hour' : 'hours'} ago`;
  if (diffDays < 7) return `${diffDays} ${diffDays === 1 ? 'day' : 'days'} ago`;
  return date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
}

/** Style for "Requested X ago" based on age (urgent = amber, stale = faded) */
export function getTimeRequestedColor(dateString: string): { color: string; opacity?: number } {
  const now = new Date();
  const date = new Date(dateString);
  const diffMs = now.getTime() - date.getTime();
  const diffHours = diffMs / (1000 * 60 * 60);

  if (diffHours < 1) return { color: '#F59E0B' };
  if (diffHours < 24) return { color: '#94A3B8' };
  return { color: '#64748B', opacity: 0.7 };
}

/** Urgency hint text for list cards */
export function getUrgencySignal(job: {
  distance?: number | null;
  request_sent_at: string;
}): string | null {
  if (job.distance != null && job.distance < 5) return 'Priority job • Nearby';
  if (job.distance != null && job.distance < 10) return 'Likely to be accepted fast';
  const daysAgo = Math.floor(
    (Date.now() - new Date(job.request_sent_at).getTime()) / (1000 * 60 * 60 * 24)
  );
  if (daysAgo > 1) return 'Customer ready to pay';
  return null;
}

/** Tier color from service display name */
export function getTierColor(primaryColor: string, serviceDisplay: string): string {
  if (serviceDisplay.includes('Bronze')) return '#CD7F32';
  if (serviceDisplay.includes('Silver')) return '#C0C0C0';
  if (serviceDisplay.includes('Gold')) return '#FFD700';
  if (serviceDisplay.includes('Platinum')) return '#E5E4E2';
  return primaryColor;
}

/** Tier icon from service display name */
export function getTierIcon(serviceDisplay: string): keyof typeof Ionicons.glyphMap {
  if (serviceDisplay.includes('Bronze')) return 'layers-outline';
  if (serviceDisplay.includes('Silver')) return 'star-outline';
  if (serviceDisplay.includes('Gold')) return 'trophy';
  if (serviceDisplay.includes('Platinum')) return 'diamond';
  return 'car-outline';
}
