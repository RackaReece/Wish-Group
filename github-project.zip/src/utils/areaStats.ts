import { supabase } from '../lib/supabase';

/** ~11 km per 0.1 deg at mid-latitudes */
const DEG_RADIUS = 0.08;
const DAYS_LOOKBACK = 30;

export type AreaStats = {
  peakStartHour: number;
  peakEndHour: number;
  peakLabel: string;
  avgWaitMinsLow: number;
  avgWaitMinsHigh: number;
};

const DEFAULT_STATS: AreaStats = {
  peakStartHour: 16,
  peakEndHour: 19,
  peakLabel: '4–7pm',
  avgWaitMinsLow: 3,
  avgWaitMinsHigh: 8,
};

function formatPeakLabel(start: number, end: number): string {
  const s = start <= 12 ? `${start}am` : `${start - 12}pm`;
  const e = end <= 12 ? `${end}am` : `${end - 12}pm`;
  return `${s}–${e}`;
}

/**
 * Fetch real area-based stats from recent bookings near (lat, lng):
 * - Peak window: 2-hour block with most bookings (from scheduled_at or created_at).
 * - Avg wait: derived from job frequency (busier area = lower wait), clamped 2–45 mins.
 */
export async function fetchAreaStats(lat: number, lng: number): Promise<AreaStats> {
  try {
    const since = new Date();
    since.setDate(since.getDate() - DAYS_LOOKBACK);
    const sinceIso = since.toISOString();

    const { data: rows, error } = await supabase
      .from('bookings')
      .select('created_at, scheduled_at, location_lat, location_lng')
      .gte('location_lat', lat - DEG_RADIUS)
      .lte('location_lat', lat + DEG_RADIUS)
      .gte('location_lng', lng - DEG_RADIUS)
      .lte('location_lng', lng + DEG_RADIUS)
      .gte('created_at', sinceIso)
      .limit(500);

    if (error || !rows?.length) return DEFAULT_STATS;

    // Use scheduled_at when available, else created_at
    const hours: number[] = [];
    for (const r of rows) {
      const at = (r as any).scheduled_at || (r as any).created_at;
      if (!at) continue;
      const d = new Date(at);
      hours.push(d.getHours());
    }
    if (hours.length === 0) return DEFAULT_STATS;

    // Peak: find 2-hour window with most bookings
    const bucket = new Array(24).fill(0);
    hours.forEach((h) => { bucket[h] += 1; });
    let bestStart = 16;
    let bestSum = 0;
    for (let start = 0; start < 24; start++) {
      const end = Math.min(start + 2, 24);
      let sum = 0;
      for (let i = start; i < end; i++) sum += bucket[i];
      if (sum > bestSum) {
        bestSum = sum;
        bestStart = start;
      }
    }
    const peakEndHour = Math.min(bestStart + 2, 24);
    const peakLabel = formatPeakLabel(bestStart, peakEndHour);

    // Avg wait: jobs per hour in window -> implied wait (busier = lower wait)
    const totalHours = DAYS_LOOKBACK * 24;
    const jobsPerHour = hours.length / totalHours;
    const avgWaitMins = Math.round(60 / Math.max(jobsPerHour, 0.15));
    const clamped = Math.min(45, Math.max(2, avgWaitMins));
    const spread = Math.max(1, Math.floor(clamped * 0.25));
    const avgWaitMinsLow = Math.max(2, clamped - spread);
    const avgWaitMinsHigh = Math.min(45, clamped + spread);

    return {
      peakStartHour: bestStart,
      peakEndHour,
      peakLabel,
      avgWaitMinsLow,
      avgWaitMinsHigh,
    };
  } catch {
    return DEFAULT_STATS;
  }
}

/**
 * Urgency copy for peak: "Peak now — X–Y" or "Peak demand starts in Nh Nm (X–Y)".
 */
export function getPeakUrgencyText(stats?: AreaStats | null): string {
  const s = stats ?? DEFAULT_STATS;
  const now = new Date();
  const hour = now.getHours();
  const min = now.getMinutes();
  const { peakStartHour, peakEndHour, peakLabel } = s;

  if (hour >= peakStartHour && hour < peakEndHour) return `Peak now — ${peakLabel}`;
  if (hour >= peakEndHour) return `Next peak tomorrow ${peakLabel}`;

  const minsUntil = (peakStartHour - hour) * 60 - min;
  const h = Math.floor(minsUntil / 60);
  const m = minsUntil % 60;
  if (h > 0) return `Peak demand starts in ${h}h ${m}m (${peakLabel})`;
  return `Peak demand starts in ${m}m (${peakLabel})`;
}
