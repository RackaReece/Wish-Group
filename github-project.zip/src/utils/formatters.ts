/**
 * Shared formatters for consistent display across the app.
 */

/** Format a number as money (2 decimal places). Accepts number or string. */
export function formatMoney(n: unknown): string {
  const v = typeof n === 'string' ? Number(n) : typeof n === 'number' ? n : 0;
  return Number.isFinite(v) ? Number(v).toFixed(2) : '0.00';
}
