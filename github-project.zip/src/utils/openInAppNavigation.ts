import { Platform } from 'react-native';
import { router } from 'expo-router';
import { isAvailable } from 'expo-mapkit-directions';
import { openTurnByTurnNavigation } from './openTurnByTurnNavigation';

/**
 * Opens in-app turn-by-turn navigation (iOS MapKit) when available;
 * otherwise falls back to external Apple/Google Maps.
 */
export function openInAppNavigation(
  latitude: number,
  longitude: number,
  address?: string | null,
  jobId?: string | null
): void {
  if (Platform.OS === 'ios' && isAvailable()) {
    router.push({
      pathname: '/valeter/navigation',
      params: {
        destinationLat: String(latitude),
        destinationLng: String(longitude),
        ...(address ? { address: address } : {}),
        ...(jobId ? { jobId } : {}),
      },
    });
  } else {
    openTurnByTurnNavigation(latitude, longitude, address ?? undefined);
  }
}
