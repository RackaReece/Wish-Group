import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  TouchableOpacity,
  Animated,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { useBusinessNewBooking } from '../../contexts/BusinessNewBookingContext';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { getTextColors, getIconColors } from '../../constants/themeColors';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { colors } from '../../constants/colors';

const SKY = colors.SKY;

function formatScheduledTime(iso: string | null): string {
  if (!iso) return '';
  try {
    const d = new Date(iso);
    return d.toLocaleString('en-GB', { dateStyle: 'short', timeStyle: 'short' });
  } catch {
    return iso;
  }
}

function DetailRow({ icon, label, value }: { icon: string; label: string; value: string | null }) {
  if (value == null || value === '') return null;
  const { theme } = useAccountTheme();
  const iconColors = getIconColors(theme);
  const textColors = getTextColors(theme);
  return (
    <View style={styles.detailRow}>
      <Ionicons name={icon as any} size={18} color={iconColors.primary} style={styles.detailIcon} />
      <Text style={[styles.detailLabel, { color: textColors.tertiary }]}>{label}</Text>
      <Text style={[styles.detailValue, { color: textColors.primary }]} numberOfLines={2}>{value}</Text>
    </View>
  );
}

export default function NewBookingOverlay() {
  const { showOverlay, newBooking, dismissOverlay, goToBooking, goToTracking } = useBusinessNewBooking();
  const { theme } = useAccountTheme();
  const textColors = getTextColors(theme);
  const iconColors = getIconColors(theme);
  const accent = theme.primary || SKY;

  const scaleAnim = useRef(new Animated.Value(0.9)).current;
  const opacityAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (showOverlay && newBooking) {
      scaleAnim.setValue(0.9);
      opacityAnim.setValue(0);
      Animated.parallel([
        Animated.spring(scaleAnim, { toValue: 1, useNativeDriver: true, friction: 8, tension: 80 }),
        Animated.timing(opacityAnim, { toValue: 1, duration: 250, useNativeDriver: true }),
      ]).start();
    }
  }, [showOverlay, newBooking]);

  if (!showOverlay || !newBooking) return null;

  const vehicleLine = [newBooking.vehicleMake, newBooking.vehicleModel, newBooking.vehicleType].filter(Boolean).join(' ') || null;

  return (
    <Modal visible={showOverlay} transparent animationType="fade" statusBarTranslucent>
      <Pressable style={styles.backdrop} onPress={dismissOverlay}>
        <Animated.View style={[styles.cardWrap, { opacity: opacityAnim, transform: [{ scale: scaleAnim }]}]}>
          <Pressable onPress={(e) => e.stopPropagation()}>
            <BlurView intensity={Platform.OS === 'ios' ? 70 : 60} tint="dark" style={styles.blur}>
              <LinearGradient
                colors={[`${accent}30`, 'rgba(30,58,138,0.5)']}
                style={StyleSheet.absoluteFill}
              />
              <View style={styles.inner}>
                <TouchableOpacity
                  hitSlop={16}
                  onPress={async () => { await hapticFeedback('light'); dismissOverlay(); }}
                  style={styles.closeBtn}
                >
                  <Ionicons name="close" size={24} color={textColors.primary} />
                </TouchableOpacity>

                <View style={styles.emojiRow}>
                  <Text style={styles.emoji}>🎉</Text>
                </View>
                <Text style={[styles.title, { color: textColors.primary }]}>Bingo!</Text>
                <Text style={[styles.subtitle, { color: textColors.secondary }]}>
                  There's a car on the way!
                </Text>

                <View style={styles.detailsCard}>
                  <DetailRow icon="person-outline" label="Customer" value={newBooking.customerName} />
                  <DetailRow icon="car-sport-outline" label="Vehicle" value={newBooking.vehicleRegistration || vehicleLine} />
                  {vehicleLine && newBooking.vehicleRegistration && (
                    <DetailRow icon="car-outline" label="Make/Model" value={vehicleLine} />
                  )}
                  <DetailRow icon="construct-outline" label="Service" value={newBooking.serviceType} />
                  {newBooking.locationAddress && (
                    <DetailRow icon="location-outline" label="Address" value={newBooking.locationAddress} />
                  )}
                  {newBooking.scheduledTime && (
                    <DetailRow icon="calendar-outline" label="Scheduled" value={formatScheduledTime(newBooking.scheduledTime)} />
                  )}
                </View>

                <View style={styles.actions}>
                  <TouchableOpacity
                    onPress={async () => { await hapticFeedback('medium'); goToTracking(); }}
                    activeOpacity={0.9}
                    style={styles.primaryBtnWrap}
                  >
                    <LinearGradient
                      colors={[accent, theme.primaryAlt || accent]}
                      style={styles.primaryBtn}
                    >
                      <Ionicons name="navigate" size={20} color="#FFFFFF" />
                      <Text style={styles.primaryBtnText}>Track booking</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={async () => { await hapticFeedback('light'); goToBooking(); }}
                    style={[styles.secondaryBtn, { borderColor: accent }]}
                    activeOpacity={0.85}
                  >
                    <Ionicons name="calendar" size={20} color={iconColors.primary} />
                    <Text style={[styles.secondaryBtnText, { color: textColors.primary }]}>View all bookings</Text>
                  </TouchableOpacity>
                </View>
              </View>
            </BlurView>
          </Pressable>
        </Animated.View>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  cardWrap: {
    width: '100%',
    maxWidth: 360,
  },
  blur: {
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(125,211,252,0.5)',
  },
  inner: {
    padding: 24,
    paddingTop: 20,
  },
  closeBtn: {
    position: 'absolute',
    top: 16,
    right: 16,
    zIndex: 10,
  },
  emojiRow: {
    alignItems: 'center',
    marginBottom: 8,
  },
  emoji: {
    fontSize: 48,
  },
  title: {
    fontSize: 28,
    fontWeight: '900',
    textAlign: 'center',
    letterSpacing: 0.5,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 20,
    paddingHorizontal: 8,
  },
  detailsCard: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  detailIcon: {
    marginRight: 10,
  },
  detailLabel: {
    fontSize: 13,
    fontWeight: '600',
    width: 80,
  },
  detailValue: {
    flex: 1,
    fontSize: 14,
    fontWeight: '700',
  },
  actions: {
    gap: 12,
  },
  primaryBtnWrap: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  primaryBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  primaryBtnText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
  },
  secondaryBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 14,
    borderRadius: 16,
    borderWidth: 1.5,
  },
  secondaryBtnText: {
    fontSize: 16,
    fontWeight: '700',
  },
});
