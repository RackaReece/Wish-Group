import React from 'react';
import { TouchableOpacity, View, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

interface GradientNotificationBellProps {
  count?: number;
  onPress?: () => void;
  loading?: boolean;
  accentColor?: string;
  disabled?: boolean;
}

export default function GradientNotificationBell({
  onPress,
  loading = false,
  accentColor = '#7DD3FC',
  disabled = false,
}: GradientNotificationBellProps) {
  return (
    <TouchableOpacity
      activeOpacity={0.85}
      onPress={onPress}
      disabled={disabled || loading}
      style={styles.wrapper}
    >
      <View style={styles.bellWrapper}>
        <LinearGradient
          colors={['rgba(135,206,235,0.35)', 'rgba(14,165,233,0.35)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.bellContainer}
        >
          <Ionicons
            name={loading ? 'notifications-off' : 'notifications-outline'}
            size={22}
            color={accentColor}
          />
        </LinearGradient>
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    marginLeft: 8,
  },
  bellWrapper: {},
  bellContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
