import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Platform,
  Dimensions,
  Animated,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { IconChevronBack, IconPerson, IconLocation, IconTrophy, IconNotifications } from '../icons';
import { router } from 'expo-router';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { AccountType, getAccountTheme } from '../../constants/accountThemes';
import { useAccountTheme } from './AccountThemeProvider';
import { getTextColors, getIconColors } from '../../constants/themeColors';
import Avatar from './Avatar';
import { textStyles } from '../../constants/typography';

const { width } = Dimensions.get('window');
const HEADER_MARGIN_H = 20;
const HEADER_RADIUS = 24;

// Header content heights (not including safe area or padding)
export const HEADER_CONTENT_HEIGHT = 64;
export const DASHBOARD_HEADER_CONTENT_HEIGHT = 88;
// Total header heights including padding (for calculating page padding)
// Formula: top padding (12/16) + content height + bottom padding (16/20)
export const HEADER_HEIGHT = 12 + HEADER_CONTENT_HEIGHT + 16; // = 92
export const DASHBOARD_HEADER_HEIGHT = 16 + DASHBOARD_HEADER_CONTENT_HEIGHT + 20; // = 124

// Standard spacing to position content directly beneath the header.
// Account for floating header: safe area + margin (8) + header height + spacing (40)
export const HEADER_CONTENT_OFFSET = HEADER_HEIGHT + 40; // Safe area + 8 margin + header + 40 spacing
export const DASHBOARD_HEADER_CONTENT_OFFSET = DASHBOARD_HEADER_HEIGHT + 40; // Safe area + 8 margin + header + 40 spacing

interface AppHeaderProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  leftAction?: React.ReactNode;
  rightAction?: React.ReactNode;
  variant?: 'default' | 'dashboard';
  accountType?: AccountType;
  showBack?: boolean;
  points?: number;
  businessName?: string;
  businessAddress?: string;
  businessRating?: number;
  showOnlineStatus?: boolean;
  onlineStatusAnim?: Animated.Value;
  profilePicture?: string | null | undefined;
  notificationCount?: number;
  onNotificationPress?: () => void;
  todayRevenue?: number;
  todayJobs?: number;
  lastJob?: string | null;
  isOnline?: boolean;
  AnimatedCounter?: React.ComponentType<{ value: number; style?: any }>;
  scrollY?: Animated.Value;
  enableScrollAnimation?: boolean;
  /** When true (e.g. map pages), header uses lower opacity for valeter light mode */
  lowOpacity?: boolean;
  /** When true, header uses profile-page styling (notification bell colours for valeter) */
  isProfilePage?: boolean;
}

export default function AppHeader({
  title,
  subtitle,
  onBack,
  leftAction,
  rightAction,
  variant = 'default',
  accountType,
  showBack = true,
  points,
  businessName,
  businessAddress,
  businessRating,
  showOnlineStatus = false,
  onlineStatusAnim,
  profilePicture,
  notificationCount,
  onNotificationPress,
  todayRevenue,
  todayJobs,
  lastJob,
  isOnline,
  AnimatedCounter,
  scrollY,
  enableScrollAnimation,
  lowOpacity,
  isProfilePage,
}: AppHeaderProps) {
  const insets = useSafeAreaInsets();
  
  const contextTheme = useAccountTheme();
  const theme = accountType 
    ? getAccountTheme(accountType, contextTheme.mode)
    : contextTheme.theme;
  
  const textColors = getTextColors(theme);
  const iconColors = getIconColors(theme);
  const isLightMode = theme.mode === 'light';

  // Header color scheme
  const isValeter = accountType === 'valeter';
  const isBusiness = accountType === 'business';
  // Valeter light: match card colour (same as cards)
  const valeterLightHeaderGradient: [string, string] = (theme.cardBackgroundGradient ?? ['rgba(91,143,168,0.4)', 'rgba(26,47,74,0.5)']) as [string, string];
  const valeterLightHeaderBorder = theme.cardBorder ?? 'rgba(91,143,168,0.5)';
  // Business light: customer UI / sky blue header
  const businessLightHeaderGradient: [string, string] = (theme.headerBackground ?? ['rgba(125,211,252,0.35)', 'rgba(30,58,138,0.25)']) as [string, string];
  const businessLightHeaderBorder = theme.glassBorder ?? 'rgba(125,211,252,0.5)';
  // Dark mode: profile uses refined blue glass; else dashboard gradient
  const valeterDarkProfileGradient: [string, string] = ['rgba(96,165,250,0.4)', 'rgba(59,130,246,0.3)'];
  const dashboardDarkHeaderGradient: [string, string] = ['rgba(37,99,235,0.4)', 'rgba(37,99,235,0.25)'];
  const headerGradient = isValeter && isLightMode
    ? (lowOpacity ? ['rgba(91,143,168,0.2)', 'rgba(26,47,74,0.12)'] : valeterLightHeaderGradient)
    : (isValeter && !isLightMode && isProfilePage)
      ? valeterDarkProfileGradient
      : (isBusiness && isLightMode)
        ? (lowOpacity ? ['rgba(125,211,252,0.18)', 'rgba(30,58,138,0.14)'] : businessLightHeaderGradient)
        : (isBusiness && !isLightMode)
          ? (theme.headerBackground ?? dashboardDarkHeaderGradient)
          : (isLightMode
            ? ['rgba(248,250,252,0.92)', 'rgba(226,232,240,0.88)']
            : (theme.headerBackground ?? dashboardDarkHeaderGradient));
  const headerTextColors = isValeter || isBusiness
    ? (isLightMode
      ? { primary: '#F9FAFB', secondary: 'rgba(249,250,251,0.9)', tertiary: 'rgba(249,250,251,0.8)', muted: 'rgba(249,250,251,0.7)', disabled: 'rgba(249,250,251,0.5)' }
      : { primary: '#F8FAFC', secondary: 'rgba(248,250,252,0.9)', tertiary: 'rgba(248,250,252,0.8)', muted: 'rgba(248,250,252,0.7)', disabled: 'rgba(248,250,252,0.5)' })
    : (isLightMode ? textColors : { primary: '#F8FAFC', secondary: 'rgba(248,250,252,0.9)', tertiary: 'rgba(248,250,252,0.8)', muted: 'rgba(248,250,252,0.7)', disabled: 'rgba(248,250,252,0.5)' });
  const headerIconPrimary = (isValeter && isLightMode) || (isBusiness && isLightMode) ? '#F9FAFB' : (isValeter ? '#F8FAFC' : (isLightMode ? (theme.textPrimary ?? '#0F172A') : '#F8FAFC'));
  const accent = theme.primary || colors.navActive;
  // Dark mode: match dashboard (blue border/glow); light: valeter, business (sky), or slate
  const dashboardDarkHeaderBorder = 'rgba(59,130,246,0.3)';
  const dashboardDarkHeaderGlow = 'rgba(59,130,246,0.5)';
  const headerBorderColor = (isValeter && isLightMode) ? valeterLightHeaderBorder : (isBusiness && isLightMode) ? businessLightHeaderBorder : (isLightMode ? 'rgba(148,163,184,0.4)' : dashboardDarkHeaderBorder);
  const headerGlowColor = (isValeter && isLightMode) ? 'rgba(59,130,246,0.6)' : (isBusiness && isLightMode) ? 'rgba(125,211,252,0.6)' : (isLightMode ? 'rgba(59,130,246,0.5)' : dashboardDarkHeaderGlow);

  const handleBack = async () => {
    await hapticFeedback('light');
    if (onBack) {
      onBack();
    } else {
      router.back();
    }
  };

  const isDashboard = variant === 'dashboard';
  const headerContentHeight = isDashboard ? DASHBOARD_HEADER_CONTENT_HEIGHT : HEADER_CONTENT_HEIGHT;
  // Valeter-style: greeting + name + location (no status box in header)
  const businessHeaderValeterStyle = isDashboard && !!businessName;
  const greeting =
    new Date().getHours() < 12 ? 'Good morning' : new Date().getHours() < 17 ? 'Good afternoon' : 'Good evening';

  const headerWidth = width - HEADER_MARGIN_H * 2;
  // Dashboard variant gets more rounded corners and is full width (not floating)
  const borderRadius = isDashboard ? 28 : HEADER_RADIUS;
  const finalWidth = isDashboard ? width : headerWidth;
  const finalMarginTop = isDashboard ? insets.top : insets.top + 8;
  const finalMarginHorizontal = isDashboard ? 0 : HEADER_MARGIN_H;

  return (
    <>
      <StatusBar barStyle={(isValeter && isLightMode) || (isBusiness && isLightMode) ? "light-content" : (isLightMode ? "dark-content" : "light-content")} backgroundColor="transparent" translucent />
      <View style={[styles.wrapper, { marginHorizontal: finalMarginHorizontal }]}>
        <View
          style={[
            styles.container,
            { 
              width: finalWidth,
              borderRadius: borderRadius,
              marginTop: finalMarginTop,
              marginHorizontal: finalMarginHorizontal,
            },
          ]}
        >
          <BlurView
            intensity={Platform.OS === 'ios' ? (lowOpacity && ((isValeter || isBusiness) && isLightMode) ? 15 : 25) : (lowOpacity && ((isValeter || isBusiness) && isLightMode) ? 12 : 20)}
            tint={(isBusiness && isLightMode) ? "dark" : (isLightMode ? "light" : "dark")}
            style={StyleSheet.absoluteFill}
          >
            {/* Same gradient as cards */}
            <LinearGradient
              colors={[headerGradient[0], headerGradient[1] || headerGradient[0]]}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
            {/* Subtle accent overlay */}
            <View style={StyleSheet.absoluteFill} pointerEvents="none">
              <LinearGradient
                colors={(isBusiness && isLightMode) ? ['rgba(125,211,252,0.08)', 'transparent'] : (isLightMode ? ['rgba(59,130,246,0.1)', 'transparent'] : ['rgba(125,211,252,0.12)', 'transparent'])}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={StyleSheet.absoluteFill}
              />
            </View>
          </BlurView>

          {/* Glass stroke */}
          <View style={[styles.glassStroke, { 
            borderColor: headerBorderColor,
            borderRadius: borderRadius,
          }]} />

          {/* Accent glow at top */}
          <View style={[styles.glowLine, { 
            backgroundColor: headerGlowColor,
            shadowColor: accent,
          }]} />

          <View style={[styles.content, { 
            paddingTop: isDashboard ? 16 : 12,
            minHeight: headerContentHeight,
            paddingBottom: isDashboard ? 20 : 16,
          }]}>
            {/* Left: back (if any) + profile picture or placeholder only on dashboard */}
            <View style={styles.leftSection}>
              {showBack && (
                <TouchableOpacity
                  onPress={handleBack}
                  style={styles.backButton}
                  activeOpacity={0.7}
                >
                  <IconChevronBack size={22} color={headerIconPrimary} />
                </TouchableOpacity>
              )}
              {isDashboard && (
                <Avatar
                  imageUri={profilePicture}
                  size="medium"
                  accentColor={headerIconPrimary}
                  mirror={accountType === 'business'}
                />
              )}
            </View>

            {/* Center: title / name / subtitle – valeter-style for business dashboard (no status box) */}
            <View style={styles.centerSection}>
            <View style={styles.titleContainer}>
              {isDashboard && businessName ? (
                <>
                  <>
                    <Text style={[styles.headerGreeting, { color: headerTextColors.tertiary }]}>{greeting}</Text>
                    <Text
                      style={[styles.headerName, { color: headerTextColors.primary }]}
                      numberOfLines={1}
                      ellipsizeMode="tail"
                    >
                      {businessName}
                    </Text>
                    {businessAddress && (
                      <View style={styles.headerLocationRow}>
                        <IconLocation size={12} color={headerIconPrimary} style={{ marginRight: 4 }} />
                        <Text
                          style={[styles.headerLocationText, { color: headerTextColors.secondary }]}
                          numberOfLines={1}
                          ellipsizeMode="tail"
                        >
                          {businessAddress}
                        </Text>
                      </View>
                    )}
                  </>
                </>
              ) : (
                <>
                  <Text 
                    style={[
                      styles.title,
                      isDashboard && styles.titleDashboard,
                      { color: headerTextColors.primary }
                    ]} 
                    numberOfLines={1} 
                    ellipsizeMode="tail"
                  >
                    {title || ' '}
                  </Text>
                  {subtitle && (
                    <Text 
                      style={[styles.subtitle, { color: headerTextColors.secondary }]} 
                      numberOfLines={1} 
                      ellipsizeMode="tail"
                    >
                      {subtitle}
                    </Text>
                  )}
                </>
              )}
            </View>
            </View>

            {/* Right: online status (valeter) + notification bell + rightAction */}
            <View style={styles.rightSection}>
              {showOnlineStatus && (
                <View
                  style={[
                    styles.onlineStatusContainer,
                    !isOnline && styles.onlineStatusContainerOffline,
                    isLightMode && theme.statusOnlineCardBg && isOnline && {
                      backgroundColor: theme.statusOnlineCardBg,
                      borderColor: `${theme.statusOnlineAccent ?? '#22C55E'}55`,
                    },
                    isLightMode && !isOnline && { backgroundColor: 'rgba(156,163,175,0.2)', borderColor: 'rgba(156,163,175,0.35)' },
                  ]}
                >
                  <View style={[styles.onlineStatusDot, { backgroundColor: isOnline ? (theme.statusOnlineAccent ?? '#10B981') : '#9CA3AF' }]} />
                  <Text style={[styles.onlineStatusLabel, { color: headerTextColors.primary }]}>
                    {isOnline ? 'Online' : 'Offline'}
                  </Text>
                </View>
              )}
              {isDashboard && points !== undefined && (
                <View style={styles.pointsBadge}>
                  <IconTrophy size={14} color="#FFD700" />
                  <Text style={styles.pointsText}>{points} pts</Text>
                </View>
              )}
              {(onNotificationPress != null) && (
                <TouchableOpacity
                  onPress={onNotificationPress}
                  activeOpacity={0.8}
                  style={styles.bellButton}
                >
                  <View style={styles.bellButtonInner}>
                    <IconNotifications size={22} color={headerIconPrimary} />
                  </View>
                </TouchableOpacity>
              )}
              {rightAction && (
                <View style={styles.rightActionContainer}>
                  {rightAction}
                </View>
              )}
            </View>
          </View>
        </View>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    alignItems: 'center',
    pointerEvents: 'box-none',
  },
  container: {
    overflow: 'hidden',
    backgroundColor: 'transparent',
    marginHorizontal: HEADER_MARGIN_H,
    shadowColor: 'rgba(15,23,42,0.4)',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.32,
    shadowRadius: 20,
    elevation: 24,
  },
  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
  },
  glowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 6,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 16,
    zIndex: 200,
    elevation: 12,
    position: 'relative',
  },
  leftSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    zIndex: 200,
  },
  centerSection: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    minWidth: 0,
    paddingHorizontal: 8,
    zIndex: 200,
  },
  profilePlaceholder: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(148,163,184,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
    flexShrink: 0,
  },
  titleContainer: {
    width: '100%',
    gap: 2,
    minWidth: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    ...textStyles.sectionTitle,
    letterSpacing: 0.3,
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
    includeFontPadding: false,
    lineHeight: 22,
  },
  titleDashboard: {
    ...textStyles.pageTitle,
    lineHeight: 28,
    textAlign: 'center',
  },
  headerGreeting: {
    ...textStyles.captionSemiBold,
    letterSpacing: 0.2,
    marginBottom: 2,
    textAlign: 'center',
  },
  headerName: {
    ...textStyles.cardTitle,
    fontSize: 22,
    lineHeight: 26,
    letterSpacing: -0.3,
    marginBottom: 4,
    textAlign: 'center',
  },
  headerLocationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerLocationText: {
    ...textStyles.captionMedium,
    flex: 1,
    textAlign: 'center',
  },
  subtitle: {
    ...textStyles.bodySmallMedium,
    fontSize: 13,
    opacity: 0.9,
    marginTop: 1,
    textAlign: 'center',
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
    includeFontPadding: false,
  },
  rightSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    justifyContent: 'flex-end',
    zIndex: 200,
    elevation: 12,
  },
  bellButton: {
    padding: 6,
  },
  bellButtonInner: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  pointsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255, 215, 0, 0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 215, 0, 0.3)',
  },
  pointsText: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.2,
    fontFamily: 'Rubik_600SemiBold',
  },
  businessInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
  },
  businessAddress: {
    fontSize: 12,
    fontWeight: '500',
    opacity: 0.9,
    flex: 1,
    fontFamily: 'Rubik_500Medium',
  },
  businessRating: {
    fontSize: 12,
    fontWeight: '600',
    fontFamily: 'Rubik_600SemiBold',
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 6,
    gap: 6,
    flexWrap: 'wrap',
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statText: {
    fontSize: 12,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.9)',
    fontFamily: 'Rubik_600SemiBold',
  },
  statValue: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
    fontFamily: 'Rubik_600SemiBold',
  },
  statSeparator: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.5)',
    marginHorizontal: 2,
    fontFamily: 'Rubik_400Regular',
  },
  statWithIcon: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  lastJobText: {
    fontSize: 11,
    fontWeight: '500',
    color: 'rgba(255,255,255,0.7)',
    marginTop: 4,
    fontFamily: 'Rubik_500Medium',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 6,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(107,114,128,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(107,114,128,0.3)',
    alignSelf: 'center',
  },
  statusBadgeOnline: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderColor: 'rgba(16,185,129,0.3)',
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  statusText: {
    fontSize: 11,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.9)',
    fontFamily: 'Rubik_600SemiBold',
  },
  onlineStatusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
    marginRight: 8,
  },
  onlineStatusContainerOffline: {
    backgroundColor: 'rgba(156,163,175,0.2)',
    borderColor: 'rgba(156,163,175,0.35)',
  },
  onlineStatusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 3,
  },
  onlineStatusLabel: {
    fontSize: 12,
    fontWeight: '600',
  },
  onlineStatusIcon: {
    marginLeft: 2,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 3,
  },
  profilePictureWrapper: {
    position: 'relative',
    borderRadius: 20,
    overflow: 'visible',
  },
  profilePictureContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    overflow: 'hidden',
    position: 'relative',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  profileGradient: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    opacity: 0.3,
  },
  profilePicture: {
    width: '100%',
    height: '100%',
    borderRadius: 20,
  },
  profilePictureBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.25)',
    pointerEvents: 'none',
  },
  headerBellBadge: {
    position: 'absolute',
    top: -2,
    right: -2,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: '#EF4444',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.5)',
    zIndex: 10,
    shadowColor: '#EF4444',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.6,
    shadowRadius: 3,
    elevation: 6,
  },
  headerBellBadgeText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.2,
    fontFamily: 'Rubik_700Bold',
  },
  rightActionContainer: {
    // Spacing handled by rightSection gap
  },
});

