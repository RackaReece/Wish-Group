import React, { useEffect, useRef } from 'react';
import { View, Image, StyleSheet, Animated } from 'react-native';

const ICON_SIZE = 96;
const ROUNDED_RADIUS = 24;

interface LoadingViewProps {
  /** Optional style for the outer container (e.g. flex: 1 to fill screen) */
  style?: object;
}

export default function LoadingView({ style }: LoadingViewProps) {
  const pulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const anim = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 0.92, duration: 600, useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 1, duration: 600, useNativeDriver: true }),
      ])
    );
    anim.start();
    return () => anim.stop();
  }, [pulse]);

  return (
    <View style={[styles.container, style]} accessibilityLabel="Loading" accessibilityState={{ busy: true }}>
      <Animated.View style={[styles.iconWrap, { transform: [{ scale: pulse }] }]}>
        <Image
          source={require('../../../app/assets/icon.png')}
          style={styles.icon}
          resizeMode="cover"
          accessibilityRole="image"
        />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconWrap: {
    width: ICON_SIZE,
    height: ICON_SIZE,
    borderRadius: ROUNDED_RADIUS,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  icon: {
    width: ICON_SIZE,
    height: ICON_SIZE,
  },
});
