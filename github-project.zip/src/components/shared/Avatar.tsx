import React from 'react';
import { View, Image, StyleSheet, StyleProp, ViewStyle } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

type AvatarSize = 'small' | 'medium' | 'large' | number;

const SIZES: Record<string, number> = {
  small: 28,
  medium: 40,
  large: 56,
};

function getSize(size: AvatarSize): number {
  return typeof size === 'number' ? size : SIZES[size] ?? 40;
}

interface AvatarProps {
  /** Image URI (remote or local). When null/undefined, shows placeholder icon. */
  imageUri?: string | null;
  size?: AvatarSize;
  /** Accent color for placeholder icon and border when no image. Defaults to #7DD3FC. */
  accentColor?: string;
  style?: StyleProp<ViewStyle>;
  /** Optional: mirror image (e.g. for business logo). */
  mirror?: boolean;
  accessibilityLabel?: string;
}

export default function Avatar({
  imageUri,
  size = 'medium',
  accentColor = '#7DD3FC',
  style,
  mirror = false,
  accessibilityLabel,
}: AvatarProps) {
  const dim = getSize(size);

  return (
    <View
      style={[styles.wrapper, { width: dim, height: dim, borderRadius: dim / 2 }, style]}
      accessibilityLabel={accessibilityLabel ?? (imageUri ? 'Profile photo' : 'Profile placeholder')}
      accessibilityRole="image"
    >
      <View style={[styles.container, { width: dim, height: dim, borderRadius: dim / 2 }]}>
        {imageUri ? (
          <>
            <LinearGradient
              colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.1)']}
              style={StyleSheet.absoluteFill}
            />
            <Image
              source={{ uri: imageUri }}
              style={[
                styles.image,
                { width: dim, height: dim, borderRadius: dim / 2 },
                mirror && { transform: [{ scaleX: -1 }] },
              ]}
              resizeMode="cover"
            />
            <View style={[styles.border, { borderRadius: dim / 2, borderColor: 'rgba(255,255,255,0.25)' }]} />
          </>
        ) : (
          <View style={[styles.placeholder, { backgroundColor: accentColor + '25' }]}>
            <Ionicons name="person" size={dim * 0.5} color={accentColor} />
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    overflow: 'visible',
  },
  container: {
    overflow: 'hidden',
    position: 'relative',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  image: {
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  border: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 2,
    pointerEvents: 'none',
  },
  placeholder: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
});
