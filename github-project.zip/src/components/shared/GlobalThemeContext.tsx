import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { Appearance } from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { ThemeMode } from '../../constants/accountThemes';

const THEME_STORAGE_KEY = '@waw_theme_mode';

interface GlobalThemeContextValue {
  mode: ThemeMode;
  setMode: (mode: ThemeMode) => void;
  toggleMode: () => void;
}

const GlobalThemeContext = createContext<GlobalThemeContextValue | undefined>(undefined);

/** Supports light/dark and system preference; persists user choice. */
export function GlobalThemeProvider({ children, initialMode = 'dark' }: { children: ReactNode; initialMode?: ThemeMode }) {
  const [mode, setModeState] = useState<ThemeMode>(initialMode);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    let isMounted = true;
    (async () => {
      try {
        const stored = await AsyncStorage.getItem(THEME_STORAGE_KEY);
        const system = Appearance.getColorScheme() ?? 'dark';
        const resolved: ThemeMode = stored === 'light' || stored === 'dark' ? stored : system;
        if (isMounted) {
          setModeState(resolved);
          setHydrated(true);
        }
      } catch {
        if (isMounted) {
          setModeState(Appearance.getColorScheme() ?? initialMode);
          setHydrated(true);
        }
      }
    })();
    return () => { isMounted = false; };
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    const sub = Appearance.addChangeListener(({ colorScheme }) => {
      // Only apply system change when user hasn't set an explicit preference
      AsyncStorage.getItem(THEME_STORAGE_KEY).then((stored) => {
        if (stored !== 'light' && stored !== 'dark' && (colorScheme === 'light' || colorScheme === 'dark')) {
          setModeState(colorScheme);
        }
      });
    });
    return () => sub.remove();
  }, [hydrated]);

  const setMode = (newMode: ThemeMode) => {
    setModeState(newMode);
    AsyncStorage.setItem(THEME_STORAGE_KEY, newMode).catch(() => {});
  };

  const toggleMode = () => {
    const next: ThemeMode = mode === 'light' ? 'dark' : 'light';
    setModeState(next);
    AsyncStorage.setItem(THEME_STORAGE_KEY, next).catch(() => {});
  };

  return (
    <GlobalThemeContext.Provider value={{ mode, setMode, toggleMode }}>
      {children}
    </GlobalThemeContext.Provider>
  );
}

export function useGlobalTheme(): GlobalThemeContextValue {
  const context = useContext(GlobalThemeContext);
  if (!context) {
    return {
      mode: 'dark',
      setMode: () => {},
      toggleMode: () => {},
    };
  }
  return context;
}
