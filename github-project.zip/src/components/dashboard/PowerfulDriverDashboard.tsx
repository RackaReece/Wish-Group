// app/valeter/PowerfulDriverDashboard.tsx
import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  StatusBar,
  ScrollView,
  Alert,
  ActivityIndicator,
  RefreshControl,
  Platform,
  Image,
  FlatList,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../providers/enhanced-auth-context';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import * as Location from 'expo-location';
import { supabase } from '../../lib/supabase';
import GradientNotificationBell from '../shared/GradientNotificationBell';
import BubbleBackground from '../shared/BubbleBackground';
import useLiveLocation from '../../hooks/useLiveLocation';
import { colors } from '../../constants/colors';
import { getAccountTheme } from '../../constants/accountThemes';
import { useAccountTheme } from '../shared/AccountThemeProvider';
import { ValeterStatsService, ValeterPerformanceStats } from '../../services/ValeterStatsService';
import GlassCard from '../booking/GlassCard';
import { DASHBOARD_HEADER_CONTENT_OFFSET } from '../shared/AppHeader';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

interface JobRequest {
  id: string;
  serviceName: string;
  distance: number;
  price: number;
  customerName: string;
  address: string;
  timeRemaining: number;
}

interface TodayStats {
  hoursOnline: string;
  jobsCompleted: number;
  earnings: number;
}

/** Animated count-up text for stats */
const CountUpNumber = ({
  value,
  prefix = '',
  suffix = '',
  decimals = 0,
  duration = 650,
  style,
}: {
  value: number;
  prefix?: string;
  suffix?: string;
  decimals?: number;
  duration?: number;
  style?: any;
}) => {
  const anim = useRef(new Animated.Value(0)).current;
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    anim.stopAnimation();
    anim.setValue(0);
    const listenerId = anim.addListener(({ value: v }) => setDisplay(v));
    Animated.timing(anim, { toValue: value, duration, useNativeDriver: false }).start(() => {
      anim.removeListener(listenerId);
      setDisplay(value);
    });
    return () => anim.removeListener(listenerId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  const shown = useMemo(() => Number(display).toFixed(decimals), [display, decimals]);
  return <Text style={style}>{`${prefix}${shown}${suffix}`}</Text>;
};

export default function PowerfulDriverDashboard() {
  const { user } = useAuth();
  const { theme } = useAccountTheme();
  const insets = useSafeAreaInsets();
  const pageBg = theme.background;
  const primaryColor = theme.primary;
  const isLight = theme.mode === 'light';
  const statusOnlineBg = theme.statusOnlineCardBg ?? 'rgba(16,185,129,0.2)';
  const statusOnlineAccent = theme.statusOnlineAccent ?? '#10B981';

  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [recentBookings, setRecentBookings] = useState<any[]>([]);
  const [isOnline, setIsOnline] = useState(false);
  const [loadingPresence, setLoadingPresence] = useState(true);
  const [toggling, setToggling] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const [jobRequests, setJobRequests] = useState<JobRequest[]>([]);
  const [todayStats, setTodayStats] = useState<TodayStats>({
    hoursOnline: '0h 0m',
    jobsCompleted: 0,
    earnings: 0,
  });

  const [valeterStats, setValeterStats] = useState<ValeterPerformanceStats | null>(null);
  const [loadingStats, setLoadingStats] = useState(true);

  const [profileName, setProfileName] = useState<string>('Valeter');
  const [workingRadius, setWorkingRadius] = useState<number>(10);

  const { coords, cityLabel, addressLine, loading: locationLoading, refresh } = useLiveLocation();

  const scrollY = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const headerHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [insets.top + 64, insets.top + 56],
    extrapolate: 'clamp',
  });
  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 80, 160],
    outputRange: [1, 0.95, 0.9],
    extrapolate: 'clamp',
  });

  // Fade in animation on mount
  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 800,
      useNativeDriver: true,
    }).start();
  }, []);

  // Pulsing animation for online indicator
  useEffect(() => {
    if (isOnline) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
        ])
      ).start();
    } else {
      pulseAnim.setValue(1);
    }
  }, [isOnline, pulseAnim]);

  const loadValeterName = async (userId: string) => {
    // 1) valeter_profiles.full_name (primary - saved from profile page)
    try {
      const { data: vp } = await supabase
        .from('valeter_profiles')
        .select('full_name')
        .eq('user_id', userId)
        .maybeSingle();

      const name = (vp?.full_name || '').trim();
      if (name) return name;
    } catch {}

    // 2) profiles.full_name (fallback)
    try {
      const { data: p } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', userId)
        .maybeSingle();

      const name = (p?.full_name || '').trim();
      if (name) return name;
    } catch {}

    // 3) auth context / fallback
    const maybe = (user?.name || '').trim();
    if (maybe) return maybe;

    return 'Valeter';
  };

  const loadWorkingRadius = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('valeter_profiles')
        .select('working_radius')
        .eq('user_id', userId)
        .maybeSingle();

      if (error) {
        console.warn('[valeter_profiles] working_radius read error', error);
        return;
      }

      const r = Number(data?.working_radius);
      if (Number.isFinite(r) && r > 0) setWorkingRadius(r);
      else setWorkingRadius(10);
    } catch (e) {
      console.warn('[valeter_profiles] working_radius read crash', e);
      setWorkingRadius(10);
    }
  };

  // Load initial online status + subscribe to realtime
  useEffect(() => {
    if (!user?.id) return;
    let mounted = true;

    (async () => {
      setLoadingPresence(true);

      // ✅ Name at top should be the valeter's name
      const name = await loadValeterName(user.id);
      if (mounted) setProfileName(name);

      // ✅ Working radius from DB
      await loadWorkingRadius(user.id);

      // Load profile picture - check both valeter_profiles and documents table
      const [profileRes, docRes] = await Promise.all([
        supabase
          .from('valeter_profiles')
          .select('profile_photo_url')
          .eq('user_id', user.id)
          .maybeSingle(),
        supabase
          .from('valeter_documents')
          .select('file_url, status')
          .eq('user_id', user.id)
          .eq('type', 'profile_photo')
          .maybeSingle(),
      ]);
      
      if (mounted) {
        const profilePhotoUrl = profileRes.data?.profile_photo_url || 
          (docRes.data?.status === 'approved' ? docRes.data.file_url : null);
        
        if (profilePhotoUrl) {
          setProfilePicture(profilePhotoUrl);
        }
      }

      // Load valeter's last 5 jobs (most recent by updated_at)
      const { data: bookingsData } = await supabase
        .from('bookings')
        .select('id, service_name, status, price, scheduled_at, completed_at, location_address, customer_id')
        .eq('valeter_id', user.id)
        .order('updated_at', { ascending: false })
        .limit(5);
      
      if (mounted && bookingsData) {
        setRecentBookings(bookingsData);
      }

      // presence
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('is_online')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!mounted) return;
      if (error) console.warn('[presence] read error', error);

      setIsOnline(!!data?.is_online);
      setLoadingPresence(false);
    })();

    const channel = supabase
      .channel('presence-self')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const row: any = payload.new ?? payload.old;
          if (row && typeof row.is_online === 'boolean') setIsOnline(row.is_online);
        }
      )
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  // Subscribe to job requests for this valeter
  useEffect(() => {
    if (!user?.id || !isOnline) return;

    const channel = supabase
      .channel('job-requests')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${user.id}`,
        },
        (payload) => {
          const booking: any = payload.new;
          if (booking.status === 'pending_valeter_acceptance') {
            const newRequest: JobRequest = {
              id: booking.id,
              serviceName: booking.service_name || 'Car Wash',
              distance: 0,
              price: Number(booking.price),
              customerName: 'Customer',
              address: booking.location_address || '',
              timeRemaining: 300,
            };
            setJobRequests((prev) => [...prev, newRequest]);
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${user.id}`,
        },
        (payload) => {
          const booking: any = payload.new;
          if (booking.status !== 'pending_valeter_acceptance') {
            setJobRequests((prev) => prev.filter((r) => r.id !== booking.id));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, isOnline]);

  // Countdown timer for job requests
  useEffect(() => {
    if (jobRequests.length === 0) return;

    const interval = setInterval(() => {
      setJobRequests((prev) =>
        prev
          .map((req) => {
            if (req.timeRemaining <= 1) {
              handleJobTimeout(req.id);
              return { ...req, timeRemaining: 0 };
            }
            return { ...req, timeRemaining: req.timeRemaining - 1 };
          })
          .filter((req) => req.timeRemaining > 0)
      );
    }, 1000);

    return () => clearInterval(interval);
  }, [jobRequests]);

  const goOnlineWithLocation = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Location permission is required to go online so customers can find you.');
      throw new Error('location-permission-denied');
    }
    const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    const lat = Number(loc.coords.latitude.toFixed(6));
    const lng = Number(loc.coords.longitude.toFixed(6));

    const { error } = await supabase.rpc('update_my_presence', {
      p_is_online: true,
      p_last_lat: lat,
      p_last_lng: lng,
    });
    if (error) throw error;
  };

  const goOffline = async () => {
    const { error } = await supabase.rpc('set_online', { p_is_online: false });
    if (error) throw error;
  };

  const toggleOnline = async () => {
    try {
      if (!user?.id) return;
      setToggling(true);
      await hapticFeedback('medium');

      if (!isOnline) await goOnlineWithLocation();
      else await goOffline();

      setIsOnline(!isOnline);
    } catch (e) {
      console.error('[presence] toggle error', e);
      Alert.alert('Error', 'Could not update your online status. Try again.');
    } finally {
      setToggling(false);
    }
  };

  const handleAcceptJob = async (jobId: string) => {
    try {
      await hapticFeedback('medium');
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'confirmed',
          valeter_response_at: new Date().toISOString(),
        })
        .eq('id', jobId);

      if (error) throw error;

      Alert.alert("Job Accepted", "Customer will complete payment. You'll be notified when ready.");
      setJobRequests((prev) => prev.filter((r) => r.id !== jobId));
      router.push({ pathname: '/valeter/jobs/tracking', params: { jobId } });
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to accept job');
    }
  };

  const handleDeclineJob = async (jobId: string) => {
    try {
      await hapticFeedback('light');
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'valeter_declined',
          valeter_response_at: new Date().toISOString(),
        })
        .eq('id', jobId);

      if (error) throw error;
      setJobRequests((prev) => prev.filter((r) => r.id !== jobId));
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to decline job');
    }
  };

  const handleJobTimeout = async (jobId: string) => {
    try {
      await supabase.from('bookings').update({ status: 'valeter_timeout' }).eq('id', jobId);
    } catch (e) {
      console.error('Timeout update failed:', e);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Load valeter stats
  useEffect(() => {
    if (!user?.id) return;

    const loadStats = async () => {
      try {
        setLoadingStats(true);
        const stats = await ValeterStatsService.getValeterStats(user.id);
        setValeterStats(stats);
      } catch (error) {
        console.error('Error loading valeter stats:', error);
      } finally {
        setLoadingStats(false);
      }
    };

    loadStats();
  }, [user?.id]);

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      if (user?.id) {
        const stats = await ValeterStatsService.getValeterStats(user.id);
        setValeterStats(stats);
        await loadWorkingRadius(user.id); // keep dashboard in sync
        const name = await loadValeterName(user.id);
        setProfileName(name);
      }
      await new Promise((resolve) => setTimeout(resolve, 700));
    } finally {
      setRefreshing(false);
    }
  };

  return (
    <View style={[styles.container, { backgroundColor: pageBg[0] }]}>
      <StatusBar barStyle={isLight ? 'dark-content' : 'light-content'} backgroundColor="transparent" translucent />
      <LinearGradient colors={pageBg} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />
      <SafeAreaView style={StyleSheet.absoluteFill} edges={['top']}>
        {/* Floating Premium Animated Header */}
        <View style={styles.headerWrapper}>
          <Animated.View
            style={[
              styles.header,
              {
                height: headerHeight,
                opacity: headerOpacity,
                marginTop: insets.top + 4,
                width: width - 40,
              },
            ]}
          >
            <BlurView intensity={Platform.OS === 'ios' ? 50 : 40} tint={isLight ? 'light' : 'dark'} style={StyleSheet.absoluteFill}>
              <LinearGradient
                colors={theme.headerBackground ?? (isLight ? ['rgba(125,211,252,0.4)', 'rgba(125,211,252,0.25)'] : ['rgba(37,99,235,0.4)', 'rgba(37,99,235,0.25)'])}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={StyleSheet.absoluteFill}
              />
              <View style={StyleSheet.absoluteFill} pointerEvents="none">
                <LinearGradient
                  colors={isLight ? ['rgba(125,211,252,0.2)', 'transparent'] : ['rgba(59,130,246,0.15)', 'transparent']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 0, y: 1 }}
                  style={StyleSheet.absoluteFill}
                />
              </View>
            </BlurView>

            <View style={[styles.glassStroke, { borderColor: theme.glassBorder ?? (isLight ? 'rgba(125,211,252,0.4)' : 'rgba(59,130,246,0.3)'), borderRadius: 24 }]} />
            <View style={[styles.glowLine, { backgroundColor: isLight ? 'rgba(125,211,252,0.5)' : 'rgba(59,130,246,0.5)', shadowColor: primaryColor }]} />

            <View style={styles.headerContent}>
              <View style={styles.headerTop}>
                {/* Left: profile pic only */}
                {profilePicture ? (
                  <TouchableOpacity
                    onPress={() => router.push('/valeter/profile/valeter-profile')}
                    style={styles.profilePictureContainer}
                  >
                    <Image source={{ uri: profilePicture }} style={styles.profilePicture} />
                  </TouchableOpacity>
                ) : (
                  <View style={styles.profilePicturePlaceholder}>
                    <Ionicons name="person" size={20} color={primaryColor} />
                  </View>
                )}

                {/* Center: greeting, name, then location under the name */}
                <View style={styles.headerCenter}>
                  <Text style={styles.greeting}>
                    {new Date().getHours() < 12
                      ? 'Good morning'
                      : new Date().getHours() < 17
                        ? 'Good afternoon'
                        : 'Good evening'}
                  </Text>
                  <Text style={styles.userName} numberOfLines={1}>
                    {profileName || 'Valeter'}
                  </Text>
                  <View style={styles.locationRow}>
                    <Ionicons name="location" size={12} color={primaryColor} />
                    <Text style={styles.locationText} numberOfLines={1}>
                      {cityLabel || addressLine || 'Location unavailable'}
                    </Text>
                  </View>
                </View>

                {/* Right */}
                <View style={styles.headerActions}>
                  <GradientNotificationBell
                    count={jobRequests.length}
                    onPress={() => router.push('/valeter/notifications')}
                  />
                </View>
              </View>

            </View>
          </Animated.View>
        </View>

        <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        contentContainerStyle={{
          paddingTop: DASHBOARD_HEADER_CONTENT_OFFSET - 4,
          paddingBottom: 18,
        }}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl tintColor={primaryColor} refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <Animated.View style={{ opacity: fadeAnim }}>
          {/* Job Requests - right under header when requests come in */}
          {jobRequests.length > 0 && (
            <View style={styles.jobQueueSection}>
              <View style={styles.jobQueueHeader}>
                <View style={styles.badgeContainer}>
                  <View style={styles.badge}>
                    <Text style={styles.badgeText}>{jobRequests.length}</Text>
                  </View>
                  <Text style={styles.jobQueueTitle}>New Job Requests</Text>
                </View>
              </View>

              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.jobQueueContainer}
                snapToInterval={width - 40}
                decelerationRate="fast"
                pagingEnabled={false}
              >
                {jobRequests.map((request) => (
                  <GlassCard key={request.id} style={styles.jobRequestCard} accountType="valeter">
                    <LinearGradient
                      colors={isLight ? ['rgba(125,211,252,0.25)', 'rgba(125,211,252,0.2)'] : ['rgba(59,130,246,0.25)', 'rgba(37,99,235,0.3)']}
                      style={styles.jobRequestGradient}
                    >
                      <View style={styles.jobRequestHeader}>
                        <View style={styles.jobRequestInfo}>
                          <View style={styles.jobRequestTitleRow}>
                            <Ionicons name="water" size={18} color="#BFDBFE" />
                            <Text style={styles.jobRequestService}>{request.serviceName}</Text>
                          </View>
                          <View style={styles.jobRequestDetailsRow}>
                            <View style={styles.jobRequestDetailItem}>
                              <Ionicons name="location" size={14} color="#93C5FD" />
                              <Text style={styles.jobRequestDetails}>{request.distance.toFixed(1)}mi away</Text>
                            </View>
                            <View style={styles.jobRequestDetailItem}>
                              <Ionicons name="cash" size={14} color="#93C5FD" />
                              <Text style={styles.jobRequestDetails}>£{request.price}</Text>
                            </View>
                          </View>
                          <Text style={styles.jobRequestAddress} numberOfLines={2}>
                            {request.address}
                          </Text>
                        </View>

                        <View style={styles.jobRequestTimerContainer}>
                          <LinearGradient
                            colors={['rgba(239,68,68,0.9)', 'rgba(220,38,38,0.9)']}
                            style={styles.jobRequestTimer}
                          >
                            <Ionicons name="time" size={14} color="#FFFFFF" />
                            <Text style={styles.jobRequestTimerText}>{formatTime(request.timeRemaining)}</Text>
                          </LinearGradient>
                        </View>
                      </View>

                      <View style={styles.jobRequestActions}>
                        <TouchableOpacity
                          style={styles.acceptButton}
                          onPress={() => handleAcceptJob(request.id)}
                          activeOpacity={0.8}
                        >
                          <LinearGradient
                            colors={['#10B981', '#059669']}
                            style={styles.jobActionGradient}
                          >
                            <Ionicons name="checkmark-circle" size={16} color="#FFFFFF" />
                            <Text style={styles.jobRequestButtonText}>Accept</Text>
                          </LinearGradient>
                        </TouchableOpacity>

                        <TouchableOpacity
                          style={styles.declineButton}
                          onPress={() => handleDeclineJob(request.id)}
                          activeOpacity={0.8}
                        >
                          <View style={styles.declineButtonInner}>
                            <Ionicons name="close-circle" size={16} color="#EF4444" />
                            <Text style={styles.declineButtonText}>Decline</Text>
                          </View>
                        </TouchableOpacity>
                      </View>
                    </LinearGradient>
                  </GlassCard>
                ))}
              </ScrollView>
            </View>
          )}

          {/* Online Toggle Section */}
          <View style={styles.onlineToggleSection}>
            <GlassCard style={styles.onlineToggleCard} accountType="valeter">
              <LinearGradient
                colors={isOnline ? (isLight ? [statusOnlineBg, `${statusOnlineAccent}30`] : ['rgba(16,185,129,0.2)', 'rgba(5,150,105,0.25)']) : ['rgba(107,114,128,0.2)', 'rgba(75,85,99,0.25)']}
                style={styles.onlineToggleGradient}
              >
                <View style={styles.onlineToggleContent}>
                  <Animated.View
                    style={[
                      styles.onlineIndicator,
                      {
                        backgroundColor: isOnline ? statusOnlineAccent : '#6B7280',
                        transform: [{ scale: pulseAnim }],
                      },
                    ]}
                  >
                    <View style={[styles.onlineInnerDot, { backgroundColor: isOnline ? (theme.statusOnlineAccent ? `${theme.statusOnlineAccent}CC` : '#34D399') : '#9CA3AF' }]} />
                  </Animated.View>
                  <View style={styles.onlineTextContainer}>
                    <View style={styles.onlineTitleRow}>
                      <Text style={styles.onlineTitle}>
                        {loadingPresence || toggling ? 'Updating...' : isOnline ? 'Online & Available' : 'Currently Offline'}
                      </Text>
                      {isOnline && !loadingPresence && !toggling && (
                        <View style={styles.liveBadge}>
                          <View style={styles.liveDot} />
                          <Text style={styles.liveText}>Live</Text>
                        </View>
                      )}
                    </View>
                    <Text style={styles.onlineSubtext}>
                      {isOnline ? 'Receiving job requests' : 'Tap to go online and start receiving jobs'}
                    </Text>
                  </View>
                  <TouchableOpacity
                    style={[styles.onlineToggleButton, { backgroundColor: isOnline ? (isLight ? `${statusOnlineAccent}40` : 'rgba(16,185,129,0.3)') : 'rgba(107,114,128,0.3)' }]}
                    onPress={toggleOnline}
                    disabled={loadingPresence || toggling}
                    activeOpacity={0.7}
                  >
                    {toggling ? (
                      <ActivityIndicator size="small" color={isOnline ? statusOnlineAccent : '#6B7280'} />
                    ) : (
                      <Ionicons name={isOnline ? 'checkmark-circle' : 'pause-circle'} size={22} color={isOnline ? statusOnlineAccent : '#6B7280'} />
                    )}
                  </TouchableOpacity>
                </View>
              </LinearGradient>
            </GlassCard>
          </View>

          {/* Premium Stats Section - Horizontal Scroll */}
          {!loadingStats && valeterStats && (
            <View style={styles.statsSection}>
              <View style={styles.performanceOverviewHeader}>
                <Text style={styles.performanceOverviewTitle}>Performance Overview</Text>
              </View>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.statsScrollContainer}
                snapToInterval={width * 0.45}
                decelerationRate="fast"
              >
                <GlassCard style={styles.statCardHorizontal} accountType="valeter">
                  <LinearGradient
                    colors={['rgba(135,206,235,0.15)', 'rgba(135,206,235,0.08)']}
                    style={styles.statCardGradient}
                  >
                    <View style={styles.statIconContainer}>
                      <Ionicons name="briefcase" size={22} color="#7DD3FC" />
                    </View>
                    <Text style={styles.statNumber}>{valeterStats.totalJobs}</Text>
                    <Text style={styles.statLabel}>Total Jobs</Text>
                    <Text style={styles.statChange}>All time</Text>
                  </LinearGradient>
                </GlassCard>

                <GlassCard style={styles.statCardHorizontal} accountType="valeter">
                  <LinearGradient
                    colors={['rgba(245,158,11,0.15)', 'rgba(245,158,11,0.08)']}
                    style={styles.statCardGradient}
                  >
                    <View style={styles.statIconContainer}>
                      <Ionicons name="wallet" size={22} color="#F59E0B" />
                    </View>
                    <Text style={styles.statNumber}>£{Number(valeterStats.totalEarnings || 0).toFixed(2)}</Text>
                    <Text style={styles.statLabel}>Total Earnings</Text>
                    <Text style={styles.statChange}>All time</Text>
                  </LinearGradient>
                </GlassCard>

                <GlassCard style={styles.statCardHorizontal} accountType="valeter">
                  <LinearGradient
                    colors={['rgba(245,158,11,0.15)', 'rgba(245,158,11,0.08)']}
                    style={styles.statCardGradient}
                  >
                    <View style={styles.statIconContainer}>
                      <Ionicons name="star" size={22} color="#F59E0B" />
                    </View>
                    <Text style={styles.statNumber}>
                      {valeterStats.averageRating > 0 ? valeterStats.averageRating.toFixed(1) : 'N/A'}
                    </Text>
                    <Text style={styles.statLabel}>Avg Rating</Text>
                    <Text style={styles.statChange}>Customer reviews</Text>
                  </LinearGradient>
                </GlassCard>

                <GlassCard style={styles.statCardHorizontal} accountType="valeter">
                  <LinearGradient
                    colors={['rgba(135,206,235,0.15)', 'rgba(135,206,235,0.08)']}
                    style={styles.statCardGradient}
                  >
                    <View style={styles.statIconContainer}>
                      <Ionicons name="calendar" size={22} color="#7DD3FC" />
                    </View>
                    <Text style={styles.statNumber}>{valeterStats.jobsThisMonth}</Text>
                    <Text style={styles.statLabel}>This Month</Text>
                    <Text style={styles.statChange}>Current period</Text>
                  </LinearGradient>
                </GlassCard>
              </ScrollView>
            </View>
          )}

          {/* Quick Actions - limited to primary CTA + schedule */}
          <View style={styles.quickActionsSection}>
            <Text style={styles.quickActionsTitle}>Quick Actions</Text>
            <View style={styles.quickActionsGrid}>
              <TouchableOpacity
                style={styles.quickActionCard}
                onPress={() => { hapticFeedback('light'); router.push('/valeter/jobs'); }}
                activeOpacity={0.8}
              >
                <GlassCard style={styles.quickActionCardInner} accountType="valeter">
                  <View style={styles.quickActionIconWrap}>
                    <Ionicons name="briefcase-outline" size={24} color="#7DD3FC" />
                  </View>
                  <Text style={styles.quickActionLabel}>View jobs</Text>
                </GlassCard>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.quickActionCard}
                onPress={() => { hapticFeedback('light'); router.push('/valeter/settings/working-hours'); }}
                activeOpacity={0.8}
              >
                <GlassCard style={styles.quickActionCardInner} accountType="valeter">
                  <View style={styles.quickActionIconWrap}>
                    <Ionicons name="time-outline" size={24} color="#7DD3FC" />
                  </View>
                  <Text style={styles.quickActionLabel}>Working hours</Text>
                </GlassCard>
              </TouchableOpacity>
            </View>
          </View>

          {/* Last 5 Jobs */}
          {recentBookings.length > 0 && (
            <View style={styles.recentBookingsSection}>
              <View style={styles.sectionHeaderRow}>
                <Text style={styles.sectionTitle}>Last 5 Jobs</Text>
                <TouchableOpacity onPress={() => router.push('/valeter/jobs')}>
                  <Text style={styles.seeAllText}>See All</Text>
                </TouchableOpacity>
              </View>
              <FlatList
                data={recentBookings}
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.bookingsList}
                keyExtractor={(item) => item.id}
                renderItem={({ item }) => (
                  <TouchableOpacity
                    onPress={() => {
                      const isPendingAcceptance = item.status === 'pending_valeter_acceptance';
                      router.push({
                        pathname: isPendingAcceptance ? '/valeter/jobs/accept' : '/valeter/jobs/tracking',
                        params: { jobId: item.id },
                      });
                    }}
                    style={styles.bookingCard}
                  >
                    <GlassCard style={styles.bookingCardInner} accountType="valeter">
                      <LinearGradient
                        colors={['rgba(135,206,235,0.12)', 'rgba(135,206,235,0.06)']}
                        style={styles.bookingGradient}
                      >
                        <View style={styles.bookingHeader}>
                          <View style={styles.bookingIconBox}>
                            <Ionicons name="car" size={20} color="#7DD3FC" />
                          </View>
                          <View style={[styles.bookingStatusBadge, {
backgroundColor: item.status === 'completed' ? 'rgba(16,185,129,0.2)' : (isLight ? 'rgba(125,211,252,0.25)' : 'rgba(59,130,246,0.2)'),
                            }]}>
                            <Text style={[styles.bookingStatusText, {
                              color: item.status === 'completed' ? '#10B981' : primaryColor,
                            }]}>
                              {item.status === 'completed' ? 'Completed' : item.status === 'in_progress' ? 'Active' : 'Confirmed'}
                            </Text>
                          </View>
                        </View>
                        <Text style={styles.bookingService} numberOfLines={1}>
                          {item.service_name || 'Car Wash'}
                        </Text>
                        <Text style={styles.bookingPrice}>
                          £{Number(item.price || 0).toFixed(2)}
                        </Text>
                        {(item.completed_at || item.scheduled_at) && (
                          <Text style={styles.bookingDate} numberOfLines={1}>
                            {new Date(item.completed_at || item.scheduled_at).toLocaleDateString('en-GB', {
                              day: 'numeric',
                              month: 'short',
                            })}
                          </Text>
                        )}
                      </LinearGradient>
                    </GlassCard>
                  </TouchableOpacity>
                )}
              />
            </View>
          )}
        </Animated.View>
        </Animated.ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { 
    flex: 1, 
    backgroundColor: '#0A1929',
  },

  /* Floating Premium Header */
  headerWrapper: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    alignItems: 'center',
    pointerEvents: 'box-none',
  },
  header: {
    borderRadius: 24,
    marginHorizontal: 20,
    backgroundColor: 'transparent',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 28,
  },
  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 0,
  },
  glowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 8,
  },
  headerContent: {
    flex: 1,
    paddingHorizontal: 16,
    paddingTop: 18,
    paddingBottom: 14,
    justifyContent: 'flex-start',
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: 10,
  },
  headerCenter: {
    flex: 1,
    minWidth: 0,
    justifyContent: 'center',
    paddingLeft: 10,
  },
  profilePictureContainer: {
    width: 52,
    height: 52,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 0,
    backgroundColor: 'rgba(135,206,235,0.1)',
    flexShrink: 0,
  },
  profilePicture: {
    width: '100%',
    height: '100%',
  },
  profilePicturePlaceholder: {
    width: 52,
    height: 52,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 0,
    flexShrink: 0,
  },
  headerLeft: { flex: 1, marginRight: 8 },
  greeting: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: isSmallScreen ? 11 : 12,
    marginBottom: 0,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  userName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 19 : 21,
    fontWeight: '600',
    marginBottom: 2,
    letterSpacing: -0.3,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  locationText: {
    color: '#7DD3FC',
    fontSize: isSmallScreen ? 11 : 12,
    fontWeight: '500',
    flex: 1,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },


  scrollView: { flex: 1 },

  /* Online Toggle Section */
  onlineToggleSection: {
    marginBottom: 14,
    marginTop: 4,
    paddingHorizontal: 20,
  },
  onlineToggleCard: {
    padding: 0,
    borderRadius: 20,
  },
  onlineToggleGradient: {
    padding: 14,
    borderRadius: 20,
  },
  onlineToggleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  onlineIndicator: {
    width: 34,
    height: 34,
    borderRadius: 17,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 0,
  },
  onlineInnerDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  onlineTextContainer: {
    flex: 1,
  },
  onlineTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 2,
  },
  onlineSubtext: {
    color: 'rgba(249,250,251,0.65)',
    fontSize: 12,
    fontWeight: '400',
  },
  onlineTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 2,
  },
  liveBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderWidth: 0,
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  liveText: {
    color: '#10B981',
    fontSize: 9,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  onlineToggleButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 0,
  },

  /* Quick Actions */
  quickActionsSection: {
    paddingHorizontal: 20,
    marginBottom: 14,
  },
  quickActionsTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 10,
    letterSpacing: -0.2,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  quickActionCard: {
    width: (width - 40 - 10) / 2,
    minWidth: 0,
  },
  quickActionCardInner: {
    padding: 12,
    borderRadius: 16,
    alignItems: 'center',
  },
  quickActionIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 6,
  },
  quickActionLabel: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },

  /* Premium Stats - Horizontal Scroll */
  statsSection: {
    marginBottom: 14,
    marginTop: 8,
  },
  performanceOverviewHeader: {
    paddingHorizontal: 20,
    marginBottom: 8,
  },
  performanceOverviewTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    letterSpacing: -0.2,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 10,
    marginTop: 0,
    marginHorizontal: 20,
    letterSpacing: -0.2,
  },
  statsScrollContainer: {
    paddingHorizontal: 20,
    paddingTop: 0,
    gap: 12,
  },
  statCardHorizontal: {
    width: width * 0.42,
    padding: 0,
    borderRadius: 20,
    marginRight: 12,
  },
  statCard: {
    padding: 0,
    borderRadius: 16,
  },
  statCardGradient: {
    padding: 14,
    borderRadius: 20,
  },
  statIconContainer: {
    marginBottom: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statNumber: {
    fontSize: isSmallScreen ? 21 : 23,
    fontWeight: '600',
    color: '#F9FAFB',
    marginBottom: 2,
    letterSpacing: -0.4,
  },
  statLabel: {
    fontSize: 12,
    color: '#7DD3FC',
    fontWeight: '600',
    marginBottom: 0,
  },
  statChange: {
    fontSize: 10,
    color: 'rgba(249,250,251,0.55)',
    fontWeight: '400',
  },

  /* Premium Job Queue */
  jobQueueSection: {
    marginBottom: 14,
    marginTop: 4,
  },
  jobQueueHeader: {
    paddingHorizontal: 20,
    marginBottom: 10,
    marginTop: 2,
  },
  badgeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  badge: {
    backgroundColor: '#EF4444',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    minWidth: 24,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#EF4444',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 3,
  },
  badgeText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '800',
  },
  jobQueueTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 17,
    fontWeight: '700',
    letterSpacing: -0.2,
  },
  jobQueueContainer: {
    paddingHorizontal: 20,
    gap: 10,
  },
  jobRequestCard: {
    width: width - 36,
    padding: 0,
    borderRadius: 16,
  },
  jobRequestGradient: {
    padding: 14,
    borderRadius: 16,
  },
  jobRequestHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 10,
    gap: 8,
  },
  jobRequestInfo: {
    flex: 1,
  },
  jobRequestTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  jobRequestService: {
    fontSize: 17,
    fontWeight: '800',
    color: '#F9FAFB',
    letterSpacing: -0.2,
  },
  jobRequestDetailsRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 8,
  },
  jobRequestDetailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  jobRequestDetails: {
    fontSize: 12,
    color: '#BFDBFE',
    fontWeight: '600',
  },
  jobRequestAddress: {
    fontSize: 12,
    color: 'rgba(249,250,251,0.65)',
    fontWeight: '500',
    lineHeight: 16,
  },
  jobRequestTimerContainer: {
    alignItems: 'flex-end',
  },
  jobRequestTimer: {
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    shadowColor: '#EF4444',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 3,
    elevation: 3,
  },
  jobRequestTimerText: {
    fontSize: 13,
    fontWeight: '800',
    color: '#FFFFFF',
  },
  jobRequestActions: {
    flexDirection: 'row',
    gap: 10,
  },
  acceptButton: {
    flex: 1,
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  jobActionGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    gap: 6,
  },
  declineButton: {
    flex: 1,
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 0,
  },
  declineButtonInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    gap: 6,
    backgroundColor: 'rgba(239,68,68,0.08)',
  },
  jobRequestButtonText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#FFFFFF',
  },
  declineButtonText: {
    fontSize: 13,
    fontWeight: '700',
    color: '#EF4444',
  },

  recentBookingsSection: {
    paddingHorizontal: 20,
    marginBottom: 16,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  seeAllText: {
    color: '#7DD3FC',
    fontSize: 14,
    fontWeight: '600',
  },
  bookingsList: {
    gap: 10,
    paddingRight: 20,
  },
  bookingCard: {
    width: width * 0.75,
  },
  bookingCardInner: {
    padding: 0,
    borderRadius: 16,
  },
  bookingGradient: {
    padding: 12,
    borderRadius: 16,
  },
  bookingHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  bookingIconBox: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  bookingStatusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  bookingStatusText: {
    fontSize: 11,
    fontWeight: '700',
  },
  bookingService: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 4,
  },
  bookingPrice: {
    color: '#7DD3FC',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 2,
  },
  bookingDate: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    fontWeight: '500',
  },
});
