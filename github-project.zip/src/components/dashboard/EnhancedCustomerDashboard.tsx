import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Easing,
  Dimensions,
  ScrollView,
  ActivityIndicator,
  StatusBar,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../providers/enhanced-auth-context';
import { supabase } from '../../lib/supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import GradientNotificationBell from '../shared/GradientNotificationBell';
import AppHeader, { DASHBOARD_HEADER_CONTENT_OFFSET } from '../shared/AppHeader';
import BubbleBackground from '../shared/BubbleBackground';
import useLiveLocation from '../../hooks/useLiveLocation';
import { customerTheme } from '../../constants/customerTheme';
import { colors } from '../../constants/colors';
import { COPY } from '../../constants/copy';
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import { bookingService } from '../../services/BookingService';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY;

const TIER_COLORS: Record<string, string> = {
  Bronze: '#CD7F32',
  Silver: '#C0C0C0',
  Gold: '#FFD700',
  Platinum: '#E5E4E2',
};

interface NearbyValeter {
  id: string;
  name: string;
  organization: string;
  rating: number;
  distance: number | null;
  isOnline: boolean;
}

interface LoyaltyData {
  points: number;
  tier: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  pointsToNextTier: number;
  nextReward?: string;
}

type DbBookingStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled' | 'en_route' | 'arrived';

type ActiveBooking = {
  id: string;
  status: DbBookingStatus;
  service_type: string;
  service_name: string | null;
  location_address: string | null;
  scheduled_at: string;
  price: number;
  valeter_name: string | null;
};

const ACTIVE_STATUSES: DbBookingStatus[] = ['scheduled', 'in_progress', 'en_route', 'arrived'];

/** True when customer can cancel: any time except when wash is in progress */
function canCancelBooking(booking: ActiveBooking): boolean {
  return booking.status !== 'in_progress';
}

/** True when tracking is meaningful: wash is in progress, valeter is on the way, or within 30 min of scheduled time */
function isTrackingAvailable(booking: ActiveBooking): boolean {
  if (['in_progress', 'en_route', 'arrived'].includes(booking.status)) return true;
  if (!booking.scheduled_at || booking.status !== 'scheduled') return false;
  const scheduled = new Date(booking.scheduled_at).getTime();
  const now = Date.now();
  const thirtyMinutes = 30 * 60 * 1000;
  return now <= scheduled && scheduled - now <= thirtyMinutes; // within 30 min of appointment
}

export default function EnhancedCustomerDashboard() {
  const { user } = useAuth();

  const [nearbyValeters, setNearbyValeters] = useState<NearbyValeter[]>([]);
  const [loading, setLoading] = useState(true);
  const [profileName, setProfileName] = useState<string>('');
  const [notificationCount, setNotificationCount] = useState(0);

  const [activeBooking, setActiveBooking] = useState<ActiveBooking | null>(null);
  const [activeBookingLoading, setActiveBookingLoading] = useState(false);

  // Still used by header points + notifications logic
  const [loyaltyData] = useState<LoyaltyData | null>({
    points: 850,
    tier: 'Silver',
    pointsToNextTier: 150,
    nextReward: '50 points = 10% off next wash',
  });

  const { refresh } = useLiveLocation();

  const notificationStatuses = useMemo(
    () => [
      'pending',
      'pending_valeter_acceptance',
      'pending_payment',
      'confirmed',
      'valeter_assigned',
      'en_route',
      'arrived',
      'in_progress',
      'scheduled',
      'completed',
      'cancelled',
    ],
    []
  );

  const refreshRef = useRef(refresh);
  useEffect(() => {
    refreshRef.current = refresh;
  }, [refresh]);

  useEffect(() => {
    const interval = setInterval(() => {
      refreshRef.current?.();
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const scrollY = useRef(new Animated.Value(0)).current;

  // Animated bubbles for header background
  const bubbleData = useRef(
    Array.from({ length: 8 }, (_, index) => {
      const random = Math.random();
      return {
        translateY: new Animated.Value(0),
        opacity: new Animated.Value(0.2 + random * 0.2),
        scale: new Animated.Value(0.6 + random * 0.3),
        size: 20 + random * 30,
        leftPosition: width * 0.6 + random * width * 0.3,
        delay: index * 800,
        duration: 12000 + random * 8000,
        startY: 120 + random * 40,
        endY: -60,
        initialOpacity: 0.2 + random * 0.2,
      };
    })
  ).current;

  useEffect(() => {
    bubbleData.forEach((bubble) => {
      bubble.translateY.setValue(bubble.startY);
      bubble.opacity.setValue(bubble.initialOpacity);

      Animated.parallel([
        Animated.loop(
          Animated.sequence([
            Animated.delay(bubble.delay),
            Animated.timing(bubble.translateY, {
              toValue: bubble.endY,
              duration: bubble.duration,
              useNativeDriver: true,
            }),
            Animated.timing(bubble.translateY, {
              toValue: bubble.startY,
              duration: 0,
              useNativeDriver: true,
            }),
          ])
        ),
        Animated.loop(
          Animated.sequence([
            Animated.timing(bubble.opacity, {
              toValue: 0.35,
              duration: bubble.duration / 3,
              easing: Easing.inOut(Easing.ease),
              useNativeDriver: true,
            }),
            Animated.timing(bubble.opacity, {
              toValue: 0.15,
              duration: bubble.duration / 3,
              easing: Easing.inOut(Easing.ease),
              useNativeDriver: true,
            }),
            Animated.timing(bubble.opacity, {
              toValue: bubble.initialOpacity,
              duration: bubble.duration / 3,
              easing: Easing.inOut(Easing.ease),
              useNativeDriver: true,
            }),
          ])
        ),
      ]).start();
    });
  }, [bubbleData]);

  const loadActiveBooking = async () => {
    if (!user?.id) return;

    try {
      setActiveBookingLoading(true);

      const { data, error } = await supabase
        .from('bookings')
        .select('id,status,service_type,service_name,location_address,scheduled_at,price,valeter_name')
        .eq('user_id', user.id)
        .in('status', ACTIVE_STATUSES as any)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        console.warn('[CustomerDashboard] loadActiveBooking error:', error);
        setActiveBooking(null);
        return;
      }

      if (!data) {
        setActiveBooking(null);
        return;
      }

      setActiveBooking({
        id: data.id,
        status: data.status as DbBookingStatus,
        service_type: data.service_type,
        service_name: data.service_name ?? null,
        location_address: data.location_address ?? null,
        scheduled_at: data.scheduled_at,
        price: Number(data.price ?? 0),
        valeter_name: data.valeter_name ?? null,
      });
    } catch (e) {
      console.warn('[CustomerDashboard] loadActiveBooking exception:', e);
      setActiveBooking(null);
    } finally {
      setActiveBookingLoading(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;

    loadActiveBooking();

    const channel = supabase
      .channel(`customer-active-booking-${user.id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        () => loadActiveBooking()
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        (payload) => {
          const updated = payload.new as any;

          if (activeBooking?.id && updated?.id === activeBooking.id) {
            const newStatus = updated.status as DbBookingStatus;

            if (newStatus === 'completed' || newStatus === 'cancelled') {
              setActiveBooking(null);
            } else {
              setActiveBooking((prev) =>
                prev
                  ? {
                      ...prev,
                      status: newStatus,
                      valeter_name: updated.valeter_name ?? prev.valeter_name,
                      price: Number(updated.price ?? prev.price),
                      service_name: updated.service_name ?? prev.service_name,
                      location_address: updated.location_address ?? prev.location_address,
                    }
                  : prev
              );
            }
            return;
          }

          loadActiveBooking();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, activeBooking?.id]);

  // Notifications count (unchanged)
  useEffect(() => {
    if (!user?.id) return;
    let isMounted = true;
    const DISMISSED_STORAGE_KEY = 'wishawash:dismissed-notifications-v1';

    const fetchVehicleReminders = async (
      userId: string
    ): Promise<Array<{ id: string; type: 'vehicle_reminder' }>> => {
      try {
        const { data: vehicles, error } = await supabase
          .from('customer_vehicles')
          .select('id,make,model,registration,tax_expiry,mot_expiry')
          .eq('user_id', userId);

        if (error || !vehicles) return [];

        const reminders: Array<{ id: string; type: 'vehicle_reminder' }> = [];
        const now = new Date();
        const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

        vehicles.forEach((vehicle) => {
          if (vehicle.tax_expiry) {
            const taxExpiry = new Date(vehicle.tax_expiry);
            if (taxExpiry <= thirtyDaysFromNow && taxExpiry >= now) {
              reminders.push({ id: `tax-reminder-${vehicle.id}`, type: 'vehicle_reminder' });
            }
          }
          if (vehicle.mot_expiry) {
            const motExpiry = new Date(vehicle.mot_expiry);
            if (motExpiry <= thirtyDaysFromNow && motExpiry >= now) {
              reminders.push({ id: `mot-reminder-${vehicle.id}`, type: 'vehicle_reminder' });
            }
          }
        });

        return reminders;
      } catch (error) {
        console.warn('[CustomerDashboard] Vehicle reminders error', error);
        return [];
      }
    };

    const fetchRewardNotifications = async (userId: string): Promise<Array<{ id: string; type: 'reward' }>> => {
      try {
        const { data: userData, error } = await supabase
          .from('users')
          .select('tier_points,tier')
          .eq('id', userId)
          .single();

        if (error || !userData) return [];

        const notifications: Array<{ id: string; type: 'reward' }> = [];
        const points = userData.tier_points || 0;
        const milestones = [500, 1000, 2000, 3000, 5000];
        const nextMilestone = milestones.find((m) => m > points);

        if (nextMilestone && points > 0) {
          const pointsNeeded = nextMilestone - points;
          if (pointsNeeded <= 100) {
            notifications.push({ id: `reward-milestone-${nextMilestone}`, type: 'reward' });
          }
        }

        return notifications;
      } catch (error) {
        console.warn('[CustomerDashboard] Reward notifications error', error);
        return [];
      }
    };

    const fetchNotificationCount = async () => {
      try {
        const [bookingsResult, vehicleReminders, rewardNotifications] = await Promise.all([
          supabase
            .from('bookings')
            .select(
              'id,status,service_name,service_type,price,created_at,updated_at,scheduled_at,time_slot,location_address,address,valeter_name'
            )
            .eq('user_id', user.id)
            .in('status', notificationStatuses as any)
            .order('created_at', { ascending: false })
            .limit(100),
          fetchVehicleReminders(user.id),
          fetchRewardNotifications(user.id),
        ]);

        if (!isMounted) return;

        const bookingNotifications: Array<{ id: string; type: 'booking' }> = [];
        if (!bookingsResult.error && bookingsResult.data) {
          bookingNotifications.push(
            ...bookingsResult.data.map((b) => ({
              id: `booking-${b.id}`,
              type: 'booking' as const,
            }))
          );
        }

        const allNotifications = [...bookingNotifications, ...vehicleReminders, ...rewardNotifications];

        try {
          const raw = await AsyncStorage.getItem(DISMISSED_STORAGE_KEY);
          const dismissedStore = raw ? JSON.parse(raw) : {};
          const dismissedIds = new Set(dismissedStore[user.id] || []);
          const visibleNotifications = allNotifications.filter((notif) => !dismissedIds.has(notif.id));
          setNotificationCount(visibleNotifications.length);
        } catch (storageError) {
          console.warn('[CustomerDashboard] Storage read error:', storageError);
          setNotificationCount(allNotifications.length);
        }
      } catch (error) {
        if (isMounted) {
          console.warn('[CustomerDashboard] Notification count exception:', error);
          setNotificationCount(0);
        }
      }
    };

    fetchNotificationCount();
    const interval = setInterval(fetchNotificationCount, 45000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [user?.id, notificationStatuses]);

  // Load profile name
  useEffect(() => {
    if (!user?.id) return;
    const loadProfileName = async () => {
      const { data: profileData } = await supabase.from('profiles').select('full_name').eq('id', user.id).maybeSingle();
      if (profileData) setProfileName(profileData.full_name || user.name || 'Customer');
      else setProfileName(user.name || 'Customer');
    };
    loadProfileName();
  }, [user?.id]);

  const loadNearbyValeters = async () => {
    if (!user?.id) return;
    try {
      const { data: presence, error: presErr } = await supabase.from('valeter_presence').select('user_id, is_online').eq('is_online', true);

      if (presErr) console.warn('[NearbyValeters] presence error:', presErr);
      if (!presence || presence.length === 0) {
        setNearbyValeters([]);
        return;
      }

      const ids = presence.map((p) => p.user_id);
      const { data: profiles } = await supabase.from('valeter_profiles').select('user_id, display_name, company_name').in('user_id', ids);

      const list: NearbyValeter[] = (presence || []).map((p) => {
        const profile = profiles?.find((pr) => pr.user_id === p.user_id);
        return {
          id: p.user_id,
          name: profile?.display_name || 'Valeter',
          organization: profile?.company_name || 'Independent',
          rating: 4.5,
          distance: null,
          isOnline: p.is_online,
        };
      });

      setNearbyValeters(list.slice(0, 8));
    } catch (e) {
      console.error('[NearbyValeters] load error:', e);
      setNearbyValeters([]);
    }
  };

  useEffect(() => {
    loadNearbyValeters();
    const interval = setInterval(loadNearbyValeters, 30000);
    return () => clearInterval(interval);
  }, [user?.id]);

  useEffect(() => {
    if (user?.id) {
      const timer = setTimeout(() => setLoading(false), 500);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, [user?.id]);

  const handleNotificationPress = () => {
    router.push('/owner/features/notifications' as any);
  };

  const handleResumeTracking = () => {
    if (!activeBooking?.id) return;
    if (!isTrackingAvailable(activeBooking)) {
      const scheduledStr = activeBooking.scheduled_at
        ? new Date(activeBooking.scheduled_at).toLocaleString('en-GB', {
            weekday: 'short',
            day: 'numeric',
            month: 'short',
            hour: '2-digit',
            minute: '2-digit',
          })
        : 'your appointment';
      Alert.alert(
        'Scheduled wash',
        `Your wash is scheduled for ${scheduledStr}. Tracking will be available closer to your appointment (within 30 minutes).`,
        [{ text: 'OK' }]
      );
      return;
    }
    router.push({
      pathname: '/owner/booking/tracking',
      params: { bookingId: activeBooking.id },
    } as any);
  };

  const handleAttemptNewBooking = (route: string) => {
    if (!activeBooking?.id) {
      router.push(route as any);
      return;
    }
    const canTrack = isTrackingAvailable(activeBooking);
    Alert.alert(
      'Active booking',
      canTrack
        ? 'You already have an active booking. You can resume tracking it now.'
        : 'You have a scheduled booking. Tracking will be available closer to your appointment.',
      [
        { text: 'Cancel', style: 'cancel' },
        ...(canTrack ? [{ text: 'Resume tracking', onPress: handleResumeTracking }] : [{ text: 'OK' }]),
      ]
    );
  };

  const handleCancelBooking = () => {
    if (!activeBooking?.id || !user?.id || !canCancelBooking(activeBooking)) return;
    Alert.alert(
      'Cancel booking',
      'Are you sure you want to cancel this booking? You may be charged a fee depending on our cancellation policy.',
      [
        { text: 'Keep booking', style: 'cancel' },
        { text: 'Cancel booking', style: 'destructive', onPress: confirmCancelBooking },
      ]
    );
  };

  const confirmCancelBooking = async () => {
    if (!activeBooking?.id || !user?.id) return;
    try {
      await bookingService.cancelBooking(activeBooking.id, user.id, { by: 'customer', reason: 'user_cancelled' });
      setActiveBooking(null);
    } catch (e) {
      console.warn('[CustomerDashboard] cancelBooking error:', e);
      Alert.alert('Error', 'Could not cancel booking. Please try again or contact support.');
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>{COPY.loading}</Text>
        </View>
      </SafeAreaView>
    );
  }

  const onlineCount = nearbyValeters.filter((v) => v.isOnline).length;

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={customerTheme.backgroundColor} />
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="customer" />

      <AppHeader
        title={profileName || user?.name || 'Customer'}
        subtitle={
          new Date().getHours() < 12
            ? 'Good morning!'
            : new Date().getHours() < 17
              ? 'Good afternoon!'
              : 'Good evening!'
        }
        variant="dashboard"
        accountType="customer"
        showBack={false}
        scrollY={scrollY}
        enableScrollAnimation={true}
        {...(loyaltyData?.points !== undefined && { points: loyaltyData.points })}
        rightAction={<GradientNotificationBell count={notificationCount} onPress={handleNotificationPress} />}
      />

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        contentContainerStyle={{
          paddingTop: DASHBOARD_HEADER_CONTENT_OFFSET,
          paddingBottom: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Gamification: Level progress */}
        {loyaltyData && (
          <View style={styles.gamifyProgressSection}>
            <View style={styles.gamifyProgressRow}>
              <View style={[styles.gamifyTierBadge, { backgroundColor: TIER_COLORS[loyaltyData.tier] || SKY }]}>
                <Ionicons name="trophy" size={14} color="#0A1929" />
                <Text style={styles.gamifyTierText}>{loyaltyData.tier}</Text>
              </View>
              <Text style={styles.gamifyPointsText}>{loyaltyData.points} pts</Text>
            </View>
            <View style={styles.gamifyProgressBarBg}>
              <View
                style={[
                  styles.gamifyProgressBarFill,
                  {
                    width: `${Math.min(
                      100,
                      loyaltyData.pointsToNextTier > 0
                        ? (loyaltyData.points / (loyaltyData.points + loyaltyData.pointsToNextTier)) * 100
                        : 100
                    )}%`,
                    backgroundColor: TIER_COLORS[loyaltyData.tier] || SKY,
                  },
                ]}
              />
            </View>
            {loyaltyData.nextReward && (
              <Text style={styles.gamifyNextReward}>{loyaltyData.nextReward}</Text>
            )}
          </View>
        )}

        {/* On-demand booking: premium card grid */}
        <View style={styles.bookingTilesSection}>
          <TouchableOpacity
            style={styles.bookingTilePremium}
            onPress={() => handleAttemptNewBooking('/owner/booking')}
            activeOpacity={0.88}
          >
            <LinearGradient
              colors={['rgba(56,189,248,0.35)', 'rgba(30,64,175,0.4)']}
              style={styles.bookingTileGradient}
            >
              <View style={styles.bookingTileGlow} />
              <View style={styles.bookingTileBadge}>
                <Ionicons name="sparkles" size={9} color="#FBBF24" />
                <Text style={styles.bookingTileBadgeText}>+15 pts</Text>
              </View>
              <View style={styles.bookingTileIconCircle}>
                <Ionicons name="water" size={28} color="#E0F2FE" />
              </View>
              <Text style={styles.bookingTileTitlePremium}>Wash</Text>
              <Text style={styles.bookingTileSubtitlePremium}>
                {activeBooking ? 'Active booking first' : 'Quick mobile wash'}
              </Text>
              <View style={styles.bookingTileCtaRow}>
                <Text style={styles.bookingTileCtaLabel}>Book now</Text>
                <Ionicons name="arrow-forward" size={18} color="#E0F2FE" />
              </View>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.bookingTilePremium}
            onPress={() => handleAttemptNewBooking('/owner/booking/detailing')}
            activeOpacity={0.88}
          >
            <LinearGradient
              colors={['rgba(251,191,36,0.28)', 'rgba(180,83,9,0.35)']}
              style={styles.bookingTileGradient}
            >
              <View style={[styles.bookingTileGlow, styles.bookingTileGlowGold]} />
              <View style={styles.bookingTileBadge}>
                <Ionicons name="star" size={9} color="#FEF3C7" />
                <Text style={styles.bookingTileBadgeText}>+25 pts</Text>
              </View>
              <View style={[styles.bookingTileIconCircle, styles.bookingTileIconCircleGold]}>
                <Ionicons name="diamond" size={28} color="#FEF3C7" />
              </View>
              <Text style={styles.bookingTileTitlePremium}>Detailing</Text>
              <Text style={styles.bookingTileSubtitlePremium}>
                {activeBooking ? 'Active booking first' : 'Deep clean & finish'}
              </Text>
              <View style={styles.bookingTileCtaRow}>
                <Text style={styles.bookingTileCtaLabel}>Book now</Text>
                <Ionicons name="arrow-forward" size={18} color="#FEF3C7" />
              </View>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Active booking – premium card */}
        {activeBookingLoading ? (
          <View style={styles.activeCardSection}>
            <View style={styles.activeCardSkeleton}>
              <ActivityIndicator size="small" color={SKY} />
              <Text style={styles.activeCardLoadingText}>Checking booking…</Text>
            </View>
          </View>
        ) : activeBooking ? (
          <View style={styles.activeCardSection}>
            <TouchableOpacity activeOpacity={0.92} onPress={handleResumeTracking} style={styles.activeCardPremium}>
              <LinearGradient
                colors={
                  ['in_progress', 'en_route', 'arrived'].includes(activeBooking.status)
                    ? ['rgba(16,185,129,0.2)', 'rgba(5,46,22,0.35)']
                    : ['rgba(56,189,248,0.18)', 'rgba(30,58,138,0.28)']
                }
                style={styles.activeCardPremiumGradient}
              >
                <View style={styles.activeCardPremiumTop}>
                  <View style={styles.activeCardPremiumServiceRow}>
                    <View
                      style={[
                        styles.activeCardPremiumIconWrap,
                        ['in_progress', 'en_route', 'arrived'].includes(activeBooking.status)
                          ? styles.activeCardPremiumIconWrapLive
                          : styles.activeCardPremiumIconWrapScheduled,
                      ]}
                    >
                      <Ionicons
                        name={isTrackingAvailable(activeBooking) ? 'navigate' : 'calendar'}
                        size={22}
                        color="#E0F2FE"
                      />
                    </View>
                    <View style={styles.activeCardPremiumServiceText}>
                      <Text style={styles.activeCardServicePremium} numberOfLines={1}>
                        {getServiceDisplayName(activeBooking.service_type, activeBooking.service_name)}
                      </Text>
                      <View
                        style={[
                          styles.activeCardStatusPill,
                          ['in_progress', 'en_route', 'arrived'].includes(activeBooking.status)
                            ? styles.activeCardStatusPillLive
                            : styles.activeCardStatusPillScheduled,
                        ]}
                      >
                        <View style={styles.activeCardStatusDot} />
                        <Text style={styles.activeCardStatusPillText}>
                          {activeBooking.status === 'in_progress'
                            ? 'In progress'
                            : activeBooking.status === 'en_route'
                              ? 'On the way'
                              : activeBooking.status === 'arrived'
                                ? 'Arrived'
                                : 'Scheduled'}
                        </Text>
                      </View>
                    </View>
                  </View>
                </View>
                {(!!activeBooking.valeter_name || !!activeBooking.location_address) && (
                  <View style={styles.activeCardPremiumMeta}>
                    {!!activeBooking.valeter_name && (
                      <View style={styles.activeCardMetaRow}>
                        <Ionicons name="person-outline" size={14} color={LIGHT_SKY} />
                        <Text style={styles.activeCardMetaTextPremium} numberOfLines={1}>{activeBooking.valeter_name}</Text>
                      </View>
                    )}
                    {!!activeBooking.location_address && (
                      <View style={styles.activeCardMetaRow}>
                        <Ionicons name="location-outline" size={14} color={LIGHT_SKY} />
                        <Text style={styles.activeCardMetaTextPremium} numberOfLines={1}>{activeBooking.location_address}</Text>
                      </View>
                    )}
                  </View>
                )}
                <View style={styles.activeCardPremiumFooter}>
                  <View style={styles.activeCardPriceBlock}>
                    <Text style={styles.activeCardPricePremium}>£{Number(activeBooking.price || 0).toFixed(2)}</Text>
                    <Text style={styles.activeCardEarnPremium}>+15 pts on completion</Text>
                  </View>
                  <View style={styles.activeCardActionsPremium}>
                    {canCancelBooking(activeBooking) && (
                      <TouchableOpacity
                        onPress={handleCancelBooking}
                        style={styles.activeCardCancelBtnPremium}
                        hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                      >
                        <Text style={styles.activeCardCancelTextPremium}>Cancel</Text>
                      </TouchableOpacity>
                    )}
                    <View style={styles.activeCardCtaPremium}>
                      <Text style={styles.activeCardCtaTextPremium}>
                        {isTrackingAvailable(activeBooking)
                          ? 'Track live'
                          : activeBooking.scheduled_at
                            ? new Date(activeBooking.scheduled_at).toLocaleDateString('en-GB', {
                                day: 'numeric',
                                month: 'short',
                                hour: '2-digit',
                                minute: '2-digit',
                              })
                            : 'View'}
                      </Text>
                      <Ionicons name="arrow-forward-circle" size={22} color={SKY} />
                    </View>
                  </View>
                </View>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        ) : null}

        {/* Live availability – premium card */}
        <View style={styles.availabilitySection}>
          <Text style={styles.sectionTitle}>Live near you</Text>
          <View style={styles.availabilityCardPremium}>
            <LinearGradient
              colors={['rgba(56,189,248,0.2)', 'rgba(30,58,138,0.25)']}
              style={styles.availabilityCardPremiumGradient}
            >
              <View style={styles.availabilityCardPremiumTop}>
                <View style={styles.availabilityIconCirclePremium}>
                  <Ionicons name="pulse" size={22} color={SKY} />
                </View>
                <View style={styles.availabilityCardPremiumText}>
                  <Text style={styles.availabilityCardTitlePremium}>Valeters online</Text>
                  <Text style={styles.availabilityCardSubtitlePremium}>{onlineCount} available now</Text>
                </View>
                {(() => {
                  const label =
                    onlineCount >= 6 ? 'Great' : onlineCount >= 3 ? 'Good' : onlineCount >= 1 ? 'Limited' : 'None';
                  const pillBg =
                    onlineCount >= 6 ? '#10B981' : onlineCount >= 3 ? '#3B82F6' : onlineCount >= 1 ? '#F59E0B' : '#EF4444';
                  return (
                    <View style={[styles.availabilityPillPremium, { backgroundColor: pillBg }]}>
                      <Text style={styles.availabilityPillPremiumText}>{label}</Text>
                    </View>
                  );
                })()}
              </View>
              <View style={styles.availabilityCardStatsPremium}>
                <View style={styles.availabilityStatPremium}>
                  <Text style={styles.availabilityStatPremiumLabel}>Est. wait</Text>
                  <Text style={styles.availabilityStatPremiumValue}>
                    {onlineCount >= 6 ? '~5–10m' : onlineCount >= 3 ? '~10–20m' : onlineCount >= 1 ? '~20–40m' : '—'}
                  </Text>
                </View>
                <View style={styles.availabilityStatDividerPremium} />
                <View style={styles.availabilityStatPremium}>
                  <Text style={styles.availabilityStatPremiumLabel}>Coverage</Text>
                  <Text style={styles.availabilityStatPremiumValue}>
                    {onlineCount >= 6 ? 'High' : onlineCount >= 3 ? 'Medium' : onlineCount >= 1 ? 'Low' : 'None'}
                  </Text>
                </View>
                <View style={styles.availabilityStatDividerPremium} />
                <View style={styles.availabilityStatPremium}>
                  <Text style={styles.availabilityStatPremiumLabel}>Live</Text>
                  <View style={styles.availabilityLiveDot} />
                </View>
              </View>
            </LinearGradient>
          </View>
        </View>
      </Animated.ScrollView>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: customerTheme.backgroundColor },
  loadingText: { color: LIGHT_SKY, fontSize: 16 },
  scrollView: { flex: 1 },

  gamifyProgressSection: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 14,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderWidth: 0,
  },
  gamifyProgressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  gamifyTierBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
  },
  gamifyTierText: {
    color: '#0A1929',
    fontSize: 12,
    fontWeight: '800',
  },
  gamifyPointsText: {
    color: LIGHT_SKY,
    fontSize: 13,
    fontWeight: '800',
  },
  gamifyProgressBarBg: {
    height: 6,
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.12)',
    overflow: 'hidden',
  },
  gamifyProgressBarFill: {
    height: '100%',
    borderRadius: 3,
  },
  gamifyNextReward: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 11,
    fontWeight: '600',
    marginTop: 8,
  },
  gamifyXpBadge: {
    position: 'absolute',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(255,215,0,0.25)',
    borderWidth: 0,
    zIndex: 2,
  },
  gamifyXpBadgeTopRight: {
    top: 12,
    right: 12,
  },
  gamifyXpBadgePremium: {
    backgroundColor: 'rgba(255,215,0,0.3)',
  },
  gamifyXpText: {
    color: '#FFD700',
    fontSize: 11,
    fontWeight: '800',
  },
  gamifyEarnBadge: {
    position: 'absolute',
    top: 12,
    left: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 0,
    zIndex: 2,
  },
  gamifyEarnText: {
    color: '#10B981',
    fontSize: 11,
    fontWeight: '700',
  },

  /* On-demand booking – premium tiles */
  bookingTilesSection: {
    flexDirection: 'row',
    gap: 14,
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginTop: 0,
    marginBottom: 20,
  },
  bookingTilePremium: {
    flex: 1,
    borderRadius: 20,
    overflow: 'hidden',
    minHeight: 160,
    elevation: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 14,
  },
  bookingTileGradient: {
    flex: 1,
    padding: 16,
    borderRadius: 20,
    borderWidth: 0,
    position: 'relative',
  },
  bookingTileGlow: {
    position: 'absolute',
    top: -20,
    right: -20,
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(56,189,248,0.2)',
  },
  bookingTileGlowGold: {
    backgroundColor: 'rgba(251,191,36,0.2)',
  },
  bookingTileBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    alignSelf: 'flex-end',
    marginBottom: 12,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  bookingTileBadgeText: {
    color: '#FBBF24',
    fontSize: 10,
    fontWeight: '800',
  },
  bookingTileIconCircle: {
    width: 48,
    height: 48,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 10,
  },
  bookingTileIconCircleGold: {
    backgroundColor: 'rgba(255,255,255,0.12)',
  },
  bookingTileTitlePremium: {
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
    letterSpacing: 0.2,
  },
  bookingTileSubtitlePremium: {
    color: 'rgba(248,250,252,0.8)',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 12,
  },
  bookingTileCtaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  bookingTileCtaLabel: {
    color: '#E0F2FE',
    fontSize: 13,
    fontWeight: '700',
  },

  /* Active booking – premium card */
  activeCardSection: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 20,
  },
  activeCardSkeleton: {
    borderRadius: 20,
    borderWidth: 0,
    backgroundColor: 'rgba(30,41,59,0.6)',
    padding: 24,
    alignItems: 'center',
  },
  activeCardLoadingText: {
    color: LIGHT_SKY,
    fontSize: 13,
    fontWeight: '600',
    marginTop: 10,
  },
  activeCardPremium: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 0,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
  },
  activeCardPremiumGradient: {
    padding: 18,
  },
  activeCardPremiumTop: {
    marginBottom: 12,
  },
  activeCardPremiumServiceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  activeCardPremiumIconWrap: {
    width: 52,
    height: 52,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeCardPremiumIconWrapLive: {
    backgroundColor: 'rgba(16,185,129,0.25)',
  },
  activeCardPremiumIconWrapScheduled: {
    backgroundColor: 'rgba(56,189,248,0.2)',
  },
  activeCardPremiumServiceText: { flex: 1 },
  activeCardServicePremium: {
    color: '#F8FAFC',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 6,
    letterSpacing: 0.2,
  },
  activeCardStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 999,
    alignSelf: 'flex-start',
  },
  activeCardStatusPillLive: {
    backgroundColor: 'rgba(16,185,129,0.3)',
  },
  activeCardStatusPillScheduled: {
    backgroundColor: 'rgba(56,189,248,0.25)',
  },
  activeCardStatusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#0A1929',
  },
  activeCardStatusPillText: {
    color: '#0A1929',
    fontSize: 12,
    fontWeight: '800',
  },
  activeCardPremiumMeta: {
    marginBottom: 14,
    gap: 8,
  },
  activeCardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  activeCardMetaTextPremium: {
    color: 'rgba(248,250,252,0.88)',
    fontSize: 14,
    fontWeight: '600',
    flex: 1,
  },
  activeCardPremiumFooter: {
    paddingTop: 14,
    borderTopWidth: 0,
  },
  activeCardPriceBlock: {
    marginBottom: 12,
  },
  activeCardPricePremium: {
    color: LIGHT_SKY,
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  activeCardEarnPremium: {
    color: 'rgba(16,185,129,0.95)',
    fontSize: 12,
    fontWeight: '700',
    marginTop: 2,
  },
  activeCardActionsPremium: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  activeCardCancelBtnPremium: {
    paddingVertical: 8,
    paddingHorizontal: 0,
  },
  activeCardCancelTextPremium: {
    color: '#EF4444',
    fontSize: 14,
    fontWeight: '700',
  },
  activeCardCtaPremium: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  activeCardCtaTextPremium: {
    color: SKY,
    fontSize: 15,
    fontWeight: '800',
  },

  /* Availability – premium card */
  availabilitySection: { marginBottom: 20 },
  sectionTitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 17 : 18,
    fontWeight: '800',
    marginBottom: 12,
    marginHorizontal: isSmallScreen ? 12 : 20,
  },
  availabilityCardPremium: {
    borderRadius: 20,
    overflow: 'hidden',
    marginHorizontal: isSmallScreen ? 12 : 20,
    borderWidth: 0,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 10,
  },
  availabilityCardPremiumGradient: {
    padding: 18,
  },
  availabilityCardPremiumTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    marginBottom: 14,
  },
  availabilityIconCirclePremium: {
    width: 48,
    height: 48,
    borderRadius: 16,
    backgroundColor: 'rgba(56,189,248,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  availabilityCardPremiumText: { flex: 1 },
  availabilityCardTitlePremium: {
    color: '#F8FAFC',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 2,
  },
  availabilityCardSubtitlePremium: {
    color: 'rgba(248,250,252,0.78)',
    fontSize: 13,
    fontWeight: '600',
  },
  availabilityPillPremium: {
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
  },
  availabilityPillPremiumText: {
    color: '#0A1929',
    fontSize: 11,
    fontWeight: '800',
  },
  availabilityCardStatsPremium: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.25)',
    borderRadius: 14,
    paddingVertical: 12,
    paddingHorizontal: 14,
  },
  availabilityStatPremium: { flex: 1, alignItems: 'center' },
  availabilityStatPremiumLabel: {
    color: 'rgba(248,250,252,0.65)',
    fontSize: 10,
    fontWeight: '700',
    marginBottom: 4,
  },
  availabilityStatPremiumValue: {
    color: LIGHT_SKY,
    fontSize: 14,
    fontWeight: '800',
  },
  availabilityStatDividerPremium: {
    width: 1,
    height: 32,
    backgroundColor: 'rgba(148,163,184,0.2)',
  },
  availabilityLiveDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
});
