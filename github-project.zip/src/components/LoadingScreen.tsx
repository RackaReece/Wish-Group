import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Dimensions,
  Easing,
  Image,
  Appearance,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getAccountTheme } from '../constants/accountThemes';
import type { ThemeMode } from '../constants/accountThemes';
import { colors } from '../constants/colors';
import { COPY } from '../constants/copy';

const { width } = Dimensions.get('window');
const THEME_STORAGE_KEY = '@waw_theme_mode';

interface LoadingScreenProps {
  message?: string;
  /** 0–1 progress for boot/splash loading bar. When provided, shows a determinate progress bar. */
  progress?: number;
}

export default function LoadingScreen({ message = COPY.loading, progress }: LoadingScreenProps) {
  const [mode, setMode] = useState<ThemeMode>('dark');
  const logoScale = useRef(new Animated.Value(1)).current;
  const loadingBarProgress = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    let mounted = true;
    (async () => {
      try {
        const stored = await AsyncStorage.getItem(THEME_STORAGE_KEY);
        const system = Appearance.getColorScheme() ?? 'dark';
        const resolved: ThemeMode = stored === 'light' || stored === 'dark' ? stored : system;
        if (mounted) setMode(resolved);
      } catch {
        if (mounted) setMode(Appearance.getColorScheme() ?? 'dark');
      }
    })();
    return () => { mounted = false; };
  }, []);

  const theme = getAccountTheme('business', mode);
  const isLight = mode === 'light';
  const bgColors = theme.background as [string, string];
  const primaryColor = theme.primary;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(logoScale, {
          toValue: 1.08,
          duration: 1400,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(logoScale, {
          toValue: 1,
          duration: 1400,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ])
    ).start();

    if (progress == null) {
      const animateLoadingBar = () => {
        loadingBarProgress.setValue(0);
        Animated.timing(loadingBarProgress, {
          toValue: 1,
          duration: 2500,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: false,
        }).start(() => animateLoadingBar());
      };
      animateLoadingBar();
    }
  }, [logoScale, loadingBarProgress, progress]);

  const indeterminateBarWidth = loadingBarProgress.interpolate({
    inputRange: [0, 1],
    outputRange: ['0%', '100%'],
  });

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={bgColors}
        style={StyleSheet.absoluteFill}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      />

      <View style={styles.content}>
        <Animated.View style={[styles.logoSection, { transform: [{ scale: logoScale }] }]}>
          <View style={[styles.logoContainer, isLight && styles.logoContainerLight]}>
            <LinearGradient
              colors={['rgba(255,255,255,0.1)', 'rgba(255,255,255,0.05)', 'transparent']}
              style={styles.logoGradient}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
            />
            <Image
              source={require('../../app/assets/icon.png')}
              style={styles.logoImage}
              resizeMode="cover"
              fadeDuration={0}
            />
          </View>
          <Text style={styles.brandTitle}>Wish a Wash</Text>
          <Text style={styles.brandSubtitle}>Your Wish Our Wash</Text>
        </Animated.View>

        <View style={styles.loadingBarContainer}>
          <View style={[styles.loadingBarBackground, { backgroundColor: isLight ? 'rgba(255,255,255,0.25)' : 'rgba(135,206,235,0.15)' }]}>
            {progress != null ? (
              <View
                style={[
                  styles.loadingBarFill,
                  { width: `${Math.min(100, Math.max(0, progress * 100))}%`, backgroundColor: primaryColor, shadowColor: primaryColor },
                ]}
              />
            ) : (
              <Animated.View
                style={[styles.loadingBarFill, { width: indeterminateBarWidth, backgroundColor: primaryColor, shadowColor: primaryColor }]}
              />
            )}
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  content: {
    alignItems: 'center',
    zIndex: 10,
    justifyContent: 'center',
    flex: 1,
  },
  logoSection: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logoContainer: {
    width: 140,
    height: 140,
    marginBottom: 24,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 30,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.1)',
    position: 'relative',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.5,
    shadowRadius: 15,
    elevation: 12,
  },
  logoContainerLight: {
    borderColor: 'rgba(255,255,255,0.25)',
    shadowOpacity: 0.35,
  },
  logoGradient: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 30,
  },
  logoImage: {
    width: '100%',
    height: '100%',
    zIndex: 1,
    borderRadius: 28,
  },
  brandTitle: {
    fontSize: 26,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 8,
    letterSpacing: -0.4,
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
  brandSubtitle: {
    fontSize: 16,
    color: colors.SKY,
    fontWeight: '500',
    letterSpacing: 0.2,
  },
  loadingBarContainer: {
    position: 'absolute',
    bottom: 60,
    width: width * 0.8,
    alignItems: 'center',
  },
  loadingBarBackground: {
    width: '100%',
    height: 6,
    borderRadius: 3,
    overflow: 'hidden',
  },
  loadingBarFill: {
    height: '100%',
    borderRadius: 3,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 8,
    elevation: 4,
  },
});
