/**
 * Alias for ProBookingCard so imports using the old name resolve.
 * Use ProBookingCard directly in new code.
 */
export { default } from './ProBookingCard';
