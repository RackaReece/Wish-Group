import React from 'react';
import { View, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import { colors } from '../../constants/colors';

const SKY = colors.SKY;
const CARD_RADIUS = 28;
const STRIP_WIDTH = 5;

export interface ProBookingCardProps {
  children: React.ReactNode;
  onPress?: () => void;
  style?: ViewStyle;
  contentStyle?: ViewStyle;
  /** Accent colour for strip and border. Default SKY. */
  stripColor?: string;
  /** Blur intensity. Default 28. */
  intensity?: number;
  /** Show the curved left strip. Default true. */
  showStrip?: boolean;
  /** Use tighter padding (12) to match customer/booking card size. Default false. */
  compact?: boolean;
}

/**
 * Same visual style as customer booking cards: BlurView, 28px radius,
 * curved left colour strip. For business and valeter (pro) UIs only.
 */
export default function ProBookingCard({
  children,
  onPress,
  style,
  contentStyle,
  stripColor = SKY,
  intensity = 28,
  showStrip = true,
  compact = false,
}: ProBookingCardProps) {
  const content = (
    <BlurView
      intensity={intensity}
      tint="dark"
      style={[styles.card, compact && styles.cardCompact]}
    >
      {showStrip && (
        <View style={[styles.strip, { backgroundColor: stripColor }]} />
      )}
      <View style={[styles.inner, contentStyle]}>{children}</View>
    </BlurView>
  );

  if (onPress) {
    return (
      <TouchableOpacity
        activeOpacity={0.9}
        onPress={onPress}
        style={[styles.touchable, style]}
      >
        {content}
      </TouchableOpacity>
    );
  }

  return <View style={[styles.wrapper, style]}>{content}</View>;
}

const styles = StyleSheet.create({
  wrapper: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
  },
  touchable: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
  },
  card: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
    borderWidth: 0,
    padding: 16,
  },
  cardCompact: {
    padding: 12,
  },
  strip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: STRIP_WIDTH,
    borderTopLeftRadius: CARD_RADIUS,
    borderBottomLeftRadius: CARD_RADIUS,
  },
  inner: {},
});
