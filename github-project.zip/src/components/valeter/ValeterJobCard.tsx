import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ViewStyle,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import {
  formatRelativeTime,
  getTimeRequestedColor,
  getUrgencySignal,
  getTierColor,
  getTierIcon,
} from '../../utils/valeterFormatters';
import { colors } from '../../constants/colors';
import ProBookingCard from '../booking/ProBookingCard';

export interface ValeterJobCardJob {
  id: string;
  service_type: string;
  service_name?: string;
  price: number;
  location_address: string;
  request_sent_at: string;
  customer_name?: string;
  customer_rating?: number;
  distance?: number | null;
  drive_time_minutes?: number | null;
  formatted_location?: string;
  assignedToValeter?: boolean;
  status?: string;
  vehicle_registration?: string | null;
  vehicle_make?: string | null;
  vehicle_model?: string | null;
  vehicle_type?: string | null;
}

type Variant = 'list' | 'accept';

interface ValeterJobCardProps {
  job: ValeterJobCardJob;
  variant: Variant;
  theme: { mode: 'light' | 'dark'; primary: string; textPrimary: string; textSecondary: string; cardBorder?: string };
  primaryColor: string;
  isLight: boolean;
  /** List: primary = Accept or View Trip; Accept screen: primary = Accept (with loading) */
  onPrimary?: () => void;
  /** List: Decline; Accept screen: Decline */
  onSecondary?: () => void;
  /** Accept screen: show loading on primary button */
  primaryLoading?: boolean;
  /** List: show payment pending strip when status is pending_payment */
  showStatusStrip?: boolean;
  style?: ViewStyle;
}

export default function ValeterJobCard({
  job,
  variant,
  theme,
  primaryColor,
  isLight,
  onPrimary,
  onSecondary,
  primaryLoading = false,
  showStatusStrip = true,
  style,
}: ValeterJobCardProps) {
  const serviceDisplay = getServiceDisplayName(job.service_type, job.service_name);
  const tierColor = getTierColor(primaryColor, serviceDisplay);
  const tierIcon = getTierIcon(serviceDisplay);
  const urgencySignal = getUrgencySignal(job);
  const timeRequestedColor = getTimeRequestedColor(job.request_sent_at);

  const isPendingPayment = job.status === 'pending_payment';
  const isAssigned = job.assignedToValeter === true;
  const isPendingAcceptance = job.status === 'pending_valeter_acceptance';

  const iconColor = isLight ? primaryColor : colors.SKY;

  const cardContent = (
    <>
      <View style={styles.header}>
        <View style={styles.headerContent}>
          <View style={[styles.serviceIcon, { backgroundColor: tierColor + '22' }]}>
            <Ionicons name={tierIcon} size={22} color={tierColor} />
          </View>
          <View style={styles.headerText}>
            <Text style={[styles.title, isLight && { color: theme.textPrimary }]} numberOfLines={1}>
              {serviceDisplay}
            </Text>
            {urgencySignal && variant === 'list' && (
              <Text style={styles.urgencySignal}>{urgencySignal}</Text>
            )}
          </View>
        </View>
        <Text style={[styles.price, isLight && { color: primaryColor }]}>
          £{job.price?.toFixed(2) ?? '0.00'}
        </Text>
      </View>

      <View style={styles.details}>
        <View style={styles.detailRow}>
          <Ionicons name="location-outline" size={20} color={iconColor} />
          <Text style={[styles.detailText, isLight && { color: theme.textSecondary }]} numberOfLines={2}>
            {job.formatted_location || job.location_address}
          </Text>
        </View>
        <View style={styles.detailRow}>
          <Ionicons name="time-outline" size={20} color={iconColor} />
          <Text style={[styles.detailText, styles.timeRequested, timeRequestedColor, isLight && { color: theme.textSecondary }]}>
            Requested {formatRelativeTime(job.request_sent_at)}
          </Text>
        </View>
            {job.distance != null && (
              <View style={styles.detailRow}>
                <Ionicons name="car-outline" size={20} color={iconColor} />
            <Text style={[styles.detailText, isLight && { color: theme.textSecondary }]}>
              {job.distance} mi away
              {job.drive_time_minutes != null ? ` • ${job.drive_time_minutes} min drive` : ''}
            </Text>
          </View>
        )}
        {job.customer_name && (
          <View style={styles.detailRow}>
            <Ionicons name="person-outline" size={16} color={iconColor} />
            <Text style={[styles.detailText, isLight && { color: theme.textSecondary }]}>
              {job.customer_name}
              {job.customer_rating != null && (
                <Text style={styles.ratingText}> • ⭐ {job.customer_rating.toFixed(1)}</Text>
              )}
            </Text>
          </View>
        )}
        {(job.vehicle_registration || job.vehicle_make || job.vehicle_model || job.vehicle_type) && (
          <View style={styles.detailRow}>
            <Ionicons name="car-sport-outline" size={16} color={iconColor} />
            <View style={styles.vehicleInfo}>
              {job.vehicle_registration && (
                <Text style={styles.vehicleReg}>{job.vehicle_registration}</Text>
              )}
              <Text style={[styles.detailText, isLight && { color: theme.textSecondary }]}>
                {[job.vehicle_make, job.vehicle_model, job.vehicle_type].filter(Boolean).join(' ')}
              </Text>
            </View>
          </View>
        )}
      </View>

      {showStatusStrip && isPendingPayment && (
        <View style={[styles.statusStrip, styles.statusStripLocked]}>
          <Ionicons name="lock-closed" size={14} color="#F59E0B" />
          <Text style={[styles.statusStripText, styles.lockedText]}>Payment pending</Text>
        </View>
      )}

      <View style={styles.actions}>
        {variant === 'accept' && (
          <>
            <TouchableOpacity
              onPress={onPrimary}
              style={styles.acceptButton}
              activeOpacity={0.8}
              disabled={primaryLoading}
            >
              <LinearGradient colors={['#10B981', '#059669']} style={styles.acceptGradient}>
                {primaryLoading ? (
                  <>
                    <ActivityIndicator color="#FFFFFF" size="small" />
                    <Text style={styles.acceptButtonText}>Accepting…</Text>
                  </>
                ) : (
                  <>
                    <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                    <Text style={styles.acceptButtonText}>Accept</Text>
                  </>
                )}
              </LinearGradient>
            </TouchableOpacity>
            <TouchableOpacity onPress={onSecondary} style={styles.declineButton} activeOpacity={0.8}>
              <Ionicons name="close-circle-outline" size={20} color="#EF4444" />
              <Text style={styles.declineButtonText}>Decline</Text>
            </TouchableOpacity>
          </>
        )}
        {variant === 'list' && (
          <>
            {isAssigned && !isPendingAcceptance && onPrimary && (
              <TouchableOpacity onPress={onPrimary} style={styles.viewButton} activeOpacity={0.8}>
                <LinearGradient colors={[colors.SKY, '#60A5FA']} style={styles.viewButtonGradient}>
                  <Ionicons name="navigate" size={20} color="#FFFFFF" />
                  <Text style={styles.viewButtonText}>View Trip</Text>
                </LinearGradient>
              </TouchableOpacity>
            )}
            {isPendingAcceptance && onPrimary && onSecondary && (
              <View style={styles.listActionsRow}>
                <TouchableOpacity onPress={onPrimary} style={styles.acceptButton} activeOpacity={0.8}>
                  <LinearGradient colors={['#10B981', '#059669']} style={styles.acceptGradient}>
                    <Ionicons name="checkmark-circle" size={24} color="#FFFFFF" />
                    <Text style={styles.acceptButtonText}>Accept</Text>
                  </LinearGradient>
                </TouchableOpacity>
                <TouchableOpacity onPress={onSecondary} style={styles.declineButton} activeOpacity={0.8}>
                  <Ionicons name="close-circle-outline" size={24} color="#EF4444" />
                  <Text style={styles.declineButtonText}>Decline</Text>
                </TouchableOpacity>
              </View>
            )}
            {isPendingPayment && (
              <View style={styles.pendingPaymentPill}>
                <Ionicons name="lock-closed" size={18} color="#F59E0B" />
                <Text style={styles.pendingPaymentPillText}>Payment required</Text>
              </View>
            )}
          </>
        )}
      </View>
    </>
  );

  return (
    <ProBookingCard
      stripColor={primaryColor}
      intensity={isLight ? 24 : 40}
      compact
      style={[styles.wrapper, style]}
    >
      {cardContent}
    </ProBookingCard>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    width: '100%',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  headerContent: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  serviceIcon: {
    width: 36,
    height: 36,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerText: {
    flex: 1,
  },
  title: {
    color: '#F9FAFB',
    fontSize: 19,
    fontWeight: '700',
  },
  urgencySignal: {
    color: '#94A3B8',
    fontSize: 14,
    marginTop: 2,
  },
  price: {
    color: colors.SKY,
    fontSize: 22,
    fontWeight: 'bold',
  },
  details: {
    gap: 10,
  },
  detailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  detailText: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 16,
    flex: 1,
  },
  timeRequested: {},
  ratingText: {
    color: '#FBBF24',
  },
  vehicleInfo: {
    flex: 1,
  },
  vehicleReg: {
    color: '#F9FAFB',
    fontWeight: '600',
    marginRight: 6,
  },
  statusStrip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingVertical: 5,
    paddingHorizontal: 8,
    borderRadius: 6,
    marginTop: 6,
    alignSelf: 'flex-start',
  },
  statusStripLocked: {
    backgroundColor: 'rgba(245,158,11,0.12)',
  },
  statusStripText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  lockedText: {
    color: '#F59E0B',
  },
  pendingPaymentPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 10,
    backgroundColor: 'rgba(245,158,11,0.12)',
    borderWidth: 0,
    alignSelf: 'flex-start',
  },
  pendingPaymentPillText: {
    color: '#F59E0B',
    fontSize: 15,
    fontWeight: '600',
  },
  actions: {
    marginTop: 12,
    gap: 10,
  },
  listActionsRow: {
    flexDirection: 'row',
    gap: 10,
    alignItems: 'center',
  },
  acceptButton: {
    flex: 1,
    borderRadius: 12,
    overflow: 'hidden',
  },
  acceptGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 20,
    gap: 8,
  },
  acceptButtonText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '700',
  },
  declineButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 20,
    borderWidth: 0,
    borderRadius: 12,
  },
  declineButtonText: {
    color: '#EF4444',
    fontSize: 17,
    fontWeight: '600',
  },
  viewButton: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  viewButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 20,
    gap: 8,
  },
  viewButtonText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '600',
  },
});
