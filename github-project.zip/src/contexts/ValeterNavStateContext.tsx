import React, { createContext, useContext, useCallback, useState, useEffect } from 'react';
import { useAuth } from '../providers/enhanced-auth-context';
import { supabase } from '../lib/supabase';

const ACTIVE_TRIP_STATUSES = ['confirmed', 'en_route', 'arrived', 'in_progress'];

type ValeterNavState = {
  hasActiveTrips: boolean;
  hasNewJobOffer: boolean;
  refresh: () => Promise<void>;
};

const ValeterNavStateContext = createContext<ValeterNavState | null>(null);

export function ValeterNavStateProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const [hasActiveTrips, setHasActiveTrips] = useState(false);
  const [hasNewJobOffer, setHasNewJobOffer] = useState(false);

  const refresh = useCallback(async () => {
    if (!user?.id) return;
    try {
      const [activeRes, pendingRes] = await Promise.all([
        supabase
          .from('bookings')
          .select('id')
          .eq('valeter_id', user.id)
          .in('status', ACTIVE_TRIP_STATUSES)
          .limit(1),
        supabase
          .from('bookings')
          .select('id')
          .eq('valeter_id', user.id)
          .eq('status', 'pending_valeter_acceptance')
          .limit(1),
      ]);
      setHasActiveTrips((activeRes.data?.length ?? 0) > 0);
      setHasNewJobOffer((pendingRes.data?.length ?? 0) > 0);
    } catch {
      setHasActiveTrips(false);
      setHasNewJobOffer(false);
    }
  }, [user?.id]);

  useEffect(() => {
    refresh();
    const channel = supabase
      .channel('valeter-nav-bookings')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${user?.id ?? ''}`,
        },
        () => { refresh(); }
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, refresh]);

  const value: ValeterNavState = {
    hasActiveTrips,
    hasNewJobOffer,
    refresh,
  };

  return (
    <ValeterNavStateContext.Provider value={value}>
      {children}
    </ValeterNavStateContext.Provider>
  );
}

export function useValeterNavState() {
  return useContext(ValeterNavStateContext);
}
