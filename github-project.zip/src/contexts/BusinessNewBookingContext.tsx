import React, { createContext, useContext, useState, useCallback, useEffect, useRef } from 'react';
import { router } from 'expo-router';
import { useAuth } from '../providers/enhanced-auth-context';
import { supabase } from '../lib/supabase';

export type NewBookingPayload = {
  id: string;
  customerName: string;
  serviceType: string;
  locationAddress: string | null;
  scheduledTime: string | null;
  vehicleRegistration: string | null;
  vehicleMake: string | null;
  vehicleModel: string | null;
  vehicleType: string | null;
  status: string;
};

type ContextValue = {
  newBooking: NewBookingPayload | null;
  showOverlay: boolean;
  dismissOverlay: () => void;
  goToBooking: () => void;
  goToTracking: () => void;
};

const BusinessNewBookingContext = createContext<ContextValue | null>(null);

export function BusinessNewBookingProvider({ children }: { children: React.ReactNode }) {
  const { user } = useAuth();
  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  const [newBooking, setNewBooking] = useState<NewBookingPayload | null>(null);
  const [showOverlay, setShowOverlay] = useState(false);
  const orgLocationIdsRef = useRef<Set<string>>(new Set());
  const orgAddressesRef = useRef<Set<string>>(new Set());
  const seenIdsRef = useRef<Set<string>>(new Set());

  const dismissOverlay = useCallback(() => {
    setShowOverlay(false);
    setNewBooking(null);
  }, []);

  const goToBooking = useCallback(() => {
    setShowOverlay(false);
    setNewBooking(null);
    setTimeout(() => router.push('/business/bookings' as any), 150);
  }, []);

  const goToTracking = useCallback(() => {
    const id = newBooking?.id;
    setShowOverlay(false);
    setNewBooking(null);
    if (id) {
      setTimeout(() => router.push({ pathname: '/business/bookings/tracking', params: { bookingId: id } } as any), 150);
    }
  }, [newBooking?.id]);

  // Fetch org location ids and addresses for filtering new bookings
  useEffect(() => {
    if (!isOrgUser || !organizationId) return;

    let mounted = true;
    (async () => {
      try {
        const { data: locations, error } = await supabase
          .from('car_wash_locations')
          .select('id, address')
          .eq('organization_id', organizationId);

        if (!mounted || error) return;

        const ids = new Set((locations || []).map((l: any) => l.id).filter(Boolean));
        const addresses = new Set(
          (locations || [])
            .map((l: any) => (typeof l?.address === 'string' ? l.address.trim() : ''))
            .filter((a: string) => a.length > 0)
        );
        orgLocationIdsRef.current = ids;
        orgAddressesRef.current = addresses;
      } catch {
        // ignore
      }
    })();
    return () => { mounted = false; };
  }, [organizationId, isOrgUser]);

  // Subscribe to new bookings (INSERT on bookings)
  useEffect(() => {
    if (!isOrgUser || !organizationId) return;

    const channel = supabase
      .channel('business-new-bookings')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'bookings',
        },
        async (payload: { new: Record<string, unknown> }) => {
          const row = payload?.new as Record<string, unknown>;
          if (!row?.id) return;

          const id = String(row.id);
          if (seenIdsRef.current.has(id)) return;
          seenIdsRef.current.add(id);

          // If we don't have location ids yet, fetch once
          if (orgLocationIdsRef.current.size === 0 && orgAddressesRef.current.size === 0) {
            try {
              const { data: locations } = await supabase
                .from('car_wash_locations')
                .select('id, address')
                .eq('organization_id', organizationId);
              const ids = new Set((locations || []).map((l: any) => l.id).filter(Boolean));
              const addrs = new Set(
                (locations || []).map((l: any) => (typeof l?.address === 'string' ? l.address.trim() : '')).filter((a: string) => a.length > 0)
              );
              orgLocationIdsRef.current = ids;
              orgAddressesRef.current = addrs;
            } catch {
              // ignore
            }
          }

          const locationId = row.location_id != null ? String(row.location_id) : null;
          const locationAddress = row.location_address != null ? String(row.location_address).trim() : null;
          const belongsToUs =
            (locationId && orgLocationIdsRef.current.has(locationId)) ||
            (locationAddress && orgAddressesRef.current.has(locationAddress));

          if (!belongsToUs) return;

          const userId = row.user_id != null ? String(row.user_id) : null;
          let customerName = (row.customer_name as string) || 'Customer';
          let vehicleRegistration: string | null = (row.vehicle_info as string) || null;
          let vehicleMake: string | null = (row.vehicle_type as string) || null;
          let vehicleModel: string | null = null;
          let vehicleType: string | null = (row.vehicle_type as string) || null;

          if (userId) {
            try {
              const [profRes, vehRes] = await Promise.all([
                supabase.from('profiles').select('full_name, name').eq('id', userId).maybeSingle(),
                supabase.from('customer_vehicles').select('registration, make, model, type').eq('user_id', userId).eq('is_default', true).maybeSingle(),
              ]);
              const p = profRes.data as { full_name?: string; name?: string } | null;
              if (p) customerName = (p.full_name || p.name || customerName) as string;
              const v = vehRes.data as { registration?: string; make?: string; model?: string; type?: string } | null;
              if (v) {
                vehicleRegistration = vehicleRegistration || v.registration || null;
                vehicleMake = vehicleMake || v.make || null;
                vehicleModel = v.model || null;
                vehicleType = vehicleType || v.type || null;
              }
            } catch {
              // use defaults
            }
          }

          const scheduledTime = row.scheduled_at ?? row.scheduled_time ?? null;
          setNewBooking({
            id,
            customerName,
            serviceType: (row.service_type as string) || 'Car wash',
            locationAddress: locationAddress || null,
            scheduledTime: scheduledTime != null ? String(scheduledTime) : null,
            vehicleRegistration,
            vehicleMake,
            vehicleModel,
            vehicleType,
            status: (row.status as string) || 'pending',
          });
          setShowOverlay(true);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [organizationId, isOrgUser]);

  const value: ContextValue = {
    newBooking,
    showOverlay,
    dismissOverlay,
    goToBooking,
    goToTracking,
  };

  return (
    <BusinessNewBookingContext.Provider value={value}>
      {children}
    </BusinessNewBookingContext.Provider>
  );
}

export function useBusinessNewBooking(): ContextValue {
  const ctx = useContext(BusinessNewBookingContext);
  if (!ctx) {
    return {
      newBooking: null,
      showOverlay: false,
      dismissOverlay: () => {},
      goToBooking: () => {},
      goToTracking: () => {},
    };
  }
  return ctx;
}
