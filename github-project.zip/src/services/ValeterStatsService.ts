import { supabase } from '../lib/supabase';

export interface ValeterPerformanceStats {
  totalJobs: number;
  experienceMonths: number;
  averageRating: number;
  totalEarnings: number;
  jobsThisMonth: number;
  customerReviews: number;
  onTimePercentage: number;
  cancellationRate: number;
}

export class ValeterStatsService {
  static async getValeterStats(userId: string): Promise<ValeterPerformanceStats> {
    try {
      const { data: jobs, error: jobsError } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', userId)
        .in('status', ['completed', 'cancelled']);

      if (jobsError) throw jobsError;

      const { data: valeterProfile, error: profileError } = await supabase
        .from('valeter_profiles')
        .select('created_at')
        .eq('user_id', userId)
        .maybeSingle();

      if (profileError || !valeterProfile) {
        return {
          totalJobs: 0,
          experienceMonths: 1,
          averageRating: 0,
          totalEarnings: 0,
          jobsThisMonth: 0,
          customerReviews: 0,
          onTimePercentage: 100,
          cancellationRate: 0,
        };
      }

      const completedJobs = jobs?.filter(job => job.status === 'completed') || [];
      const cancelledJobs = jobs?.filter(job => job.status === 'cancelled') || [];
      const totalJobs = completedJobs.length;
      const startDate = new Date(valeterProfile?.created_at || Date.now());
      const now = new Date();
      const experienceMonths = Math.max(
        1,
        Math.round((now.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24 * 30))
      );
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const jobsThisMonth = completedJobs.filter(job => {
        const jobDate = new Date(job.completed_at || job.created_at);
        return jobDate >= firstDayOfMonth;
      }).length;
      const jobsWithRatings = completedJobs.filter(job => job.rating != null);
      const customerReviews = jobsWithRatings.length;
      const averageRating = customerReviews > 0
        ? jobsWithRatings.reduce((sum, job) => sum + (Number(job.rating) || 0), 0) / customerReviews
        : 0;
      const onTimeJobs = completedJobs.filter(job => {
        if (!job.scheduled_at || !job.completed_at) return true;
        const diffMinutes = (new Date(job.completed_at).getTime() - new Date(job.scheduled_at).getTime()) / (1000 * 60);
        return Math.abs(diffMinutes) <= 15;
      }).length;
      const onTimePercentage = totalJobs > 0 ? Math.round((onTimeJobs / totalJobs) * 100) : 100;
      const totalBookings = jobs?.length || 0;
      const cancellationRate = totalBookings > 0 ? Math.round((cancelledJobs.length / totalBookings) * 100) : 0;
      const totalEarnings = completedJobs.reduce((sum, job) => sum + (Number(job.price) || 0), 0);

      return {
        totalJobs,
        experienceMonths,
        averageRating: Math.round(averageRating * 10) / 10,
        totalEarnings: Math.round(totalEarnings),
        jobsThisMonth,
        customerReviews,
        onTimePercentage,
        cancellationRate,
      };
    } catch (error) {
      return {
        totalJobs: 0,
        experienceMonths: 1,
        averageRating: 0,
        totalEarnings: 0,
        jobsThisMonth: 0,
        customerReviews: 0,
        onTimePercentage: 100,
        cancellationRate: 0,
      };
    }
  }

  static async updateEarnings(_userId: string, _amount: number): Promise<void> { return; }

  static async recordJobCompletion(userId: string, bookingId: string, _isOnTime: boolean): Promise<void> {
    try {
      await supabase
        .from('bookings')
        .update({ completed_at: new Date().toISOString(), status: 'completed' })
        .eq('id', bookingId)
        .eq('valeter_id', userId);
    } catch (_err: unknown) {
      void _err;
    }
  }
}

