/**
 * Stub for Live Activity (iOS Dynamic Island) updates.
 * No-op when not using native live activities; implement with expo or native modules when needed.
 */

export function startLiveActivity(_payload: { bookingId?: string; title?: string; eta?: string }): void {
  // No-op: implement with native Live Activity API when needed
}

export function updateLiveActivity(_payload: { bookingId?: string; title?: string; eta?: string; status?: string }): void {
  // No-op
}

export function endLiveActivity(_bookingId?: string): void {
  // No-op
}
