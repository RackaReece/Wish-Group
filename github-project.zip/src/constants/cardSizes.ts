import { Dimensions } from 'react-native';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

import { CARD_BORDER_RADIUS } from './colors';

export const CARD_SIZES = {
  small: {
    padding: 16,
    minHeight: 80,
    borderRadius: CARD_BORDER_RADIUS,
  },
  medium: {
    padding: 20,
    minHeight: 120,
    borderRadius: CARD_BORDER_RADIUS,
  },
  large: {
    padding: 24,
    minHeight: 160,
    borderRadius: CARD_BORDER_RADIUS,
  },
  fullWidth: {
    padding: 20,
    borderRadius: CARD_BORDER_RADIUS,
  },
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 10,
  lg: 14,
  xl: 18,
  xxl: 22,
  section: 24,
};

// Standard spacing – tight to reduce unnecessary whitespace
export const STANDARD_SPACING = {
  pagePadding: 16,
  pagePaddingBottom: 18,
  sectionMarginBottom: 10,
  sectionGap: 10,
  sectionGapSmall: 8,
  cardGap: 10,
  cardPadding: 12,
  cardPaddingMedium: 14,
  cardPaddingLarge: 18,
  cardBorderRadius: 20,
  cardBorderRadiusMedium: 22,
  cardBorderRadiusLarge: 24,
  contentGap: 8,
  contentGapLarge: 10,
  headerContentOffset: 28,
  inputMarginBottom: 8,
  inputPadding: 12,
  inputBorderRadius: 14,
  buttonPaddingVertical: 12,
  buttonPaddingHorizontal: 18,
  buttonBorderRadius: 12,
};

export const getMetricCardWidth = (columns: number = 2, gap: number = SPACING.md) => {
  const padding = isSmallScreen ? 32 : 40;
  return (width - padding - gap * (columns - 1)) / columns;
};

/**
 * Standardized icon + text alignment – use these for consistent positioning across the app.
 */
export const ICON_TEXT_LAYOUT = {
  /** Gap between icon and text in inline rows */
  gap: 8,
  /** Gap for section headers (icon + title) */
  sectionGap: 8,
  /** Gap for list/card item rows (icon + content) */
  itemGap: 12,
  /** Icon sizes by context */
  iconSize: {
    section: 16,
    listItem: 20,
    card: 18,
    small: 14,
  },
  /** Shared layout for icon + text row */
  row: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    gap: 8,
  },
  /** Section header with icon */
  sectionHeader: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    gap: 8,
  },
  /** Card/list item content row */
  itemRow: {
    flexDirection: 'row' as const,
    alignItems: 'center' as const,
    gap: 10,
  },
};