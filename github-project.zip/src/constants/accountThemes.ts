import { customerTheme } from './customerTheme';

export type AccountType = 'customer' | 'valeter' | 'business';

export type ThemeMode = 'light' | 'dark';

export interface AccountTheme {
  primary: string;
  primaryAlt: string;
  background: [string, string];
  headerBackground?: [string, string];
  glassBorder: string;
  glassBorderAlt?: string;
  accent: string;
  accentAlt: string;
  cardBackground?: string;
  cardBackgroundGradient?: [string, string];
  cardBorder?: string;
  textPrimary?: string;
  textSecondary?: string;
  textOnBackground?: string;
  iconPrimary?: string;
  mode?: ThemeMode;
  /** Light theme: status card (Online & Available) */
  statusOnlineCardBg?: string;
  statusOnlineAccent?: string;
  /** Light theme: bottom nav */
  navBarBackground?: string;
  /** Light theme: bottom nav dark bar (white text) */
  navBarBottomDark?: string;
  navActiveGlow?: string;
  /** Light theme: icon highlight (rating, alerts) */
  iconHighlight?: string;
  /** Light theme: soft shadows */
  shadowColor?: string;
  shadowOpacity?: number;
  shadowRadius?: number;
  /** Light theme: icon circle backgrounds */
  iconCircleBg?: string;
  iconCircleBgHighlight?: string;
}

const SKY_BLUE = '#7DD3FC';
const SKY_BLUE_BORDER = 'rgba(125,211,252,0.55)';

/** Valeter accent (cooler blue) */
const VALETER_BLUE = '#5B9FC9';
const VALETER_BLUE_ALT = '#4A8BB0';

/** Valeter header & nav – dashboard blue gradient */
const VALETER_HEADER_BACKGROUND: [string, string] = ['rgba(37,99,235,0.4)', 'rgba(37,99,235,0.25)'];

/** Valeter cards – nav blue (match header/nav) */
const VALETER_NAV_BLUE_BORDER = 'rgba(59,130,246,0.5)';
const VALETER_NAV_BLUE_CARD_GRADIENT: [string, string] = ['rgba(37,99,235,0.5)', 'rgba(30,58,138,0.45)'];

/** Valeter light theme – light blue icons, toggles and accents only (no dark blue) */
const VALETER_LIGHT_BLUE = '#7DD3FC';
const VALETER_LIGHT_BLUE_ALT = '#5BA3C7';
export const valeterLightTheme: AccountTheme = {
  primary: VALETER_LIGHT_BLUE,
  primaryAlt: VALETER_LIGHT_BLUE_ALT,
  background: ['#5B8FA8', '#1A2F4A'],
  headerBackground: ['rgba(125,211,252,0.4)', 'rgba(125,211,252,0.25)'],
  glassBorder: 'rgba(125,211,252,0.5)',
  cardBorder: 'rgba(125,211,252,0.5)',
  cardBackground: 'rgba(91,143,168,0.35)',
  cardBackgroundGradient: ['rgba(125,211,252,0.35)', 'rgba(26,47,74,0.5)'],
  accent: VALETER_LIGHT_BLUE,
  accentAlt: VALETER_LIGHT_BLUE_ALT,
  textPrimary: '#F9FAFB',
  textSecondary: 'rgba(249,250,251,0.9)',
  textOnBackground: '#E2E8F0',
  iconPrimary: VALETER_LIGHT_BLUE,
  mode: 'light',
  statusOnlineCardBg: 'rgba(16,185,129,0.2)',
  statusOnlineAccent: '#10B981',
  navBarBackground: 'rgba(26,47,74,0.25)',
  navBarBottomDark: '#1A2F4A',
  navActiveGlow: VALETER_LIGHT_BLUE,
  iconHighlight: VALETER_LIGHT_BLUE,
  shadowColor: 'rgba(26,47,74,0.3)',
  shadowOpacity: 0.28,
  shadowRadius: 12,
  iconCircleBg: 'rgba(125,211,252,0.28)',
  iconCircleBgHighlight: 'rgba(125,211,252,0.22)',
};

/** Business light theme – match valeter light mode colours */
export const businessLightTheme: AccountTheme = {
  ...valeterLightTheme,
};

export const accountThemes: Record<AccountType, AccountTheme> = {
  customer: {
    primary: SKY_BLUE,
    primaryAlt: '#5BA3C7',
    background: customerTheme.backgroundGradient,
    headerBackground: ['rgba(30,58,138,0.35)', 'rgba(30,58,138,0.25)'],
    glassBorder: 'rgba(125,211,252,0.5)',
    accent: SKY_BLUE,
    accentAlt: '#5BA3C7',
    mode: 'dark',
  },

  valeter: {
    primary: VALETER_BLUE,
    primaryAlt: VALETER_BLUE_ALT,
    background: ['#0f172a', '#020617'],
    headerBackground: VALETER_HEADER_BACKGROUND,
    glassBorder: VALETER_NAV_BLUE_BORDER,
    cardBorder: VALETER_NAV_BLUE_BORDER,
    cardBackgroundGradient: VALETER_NAV_BLUE_CARD_GRADIENT,
    accent: VALETER_BLUE,
    accentAlt: VALETER_BLUE_ALT,
    mode: 'dark',
  },

  business: {
    primary: SKY_BLUE,
    primaryAlt: '#5BA3C7',
    background: ['#0f172a', '#020617'],
    headerBackground: ['rgba(30,58,138,0.7)', 'rgba(15,23,42,0.6)'],
    glassBorder: 'rgba(125,211,252,0.55)',
    cardBorder: 'rgba(125,211,252,0.55)',
    cardBackgroundGradient: ['rgba(30,58,138,0.55)', 'rgba(15,23,42,0.4)'],
    accent: SKY_BLUE,
    accentAlt: '#5BA3C7',
    mode: 'dark',
  },
};

/** Returns theme for account; valeter and business support light mode. */
export const getAccountTheme = (accountType: AccountType, mode?: ThemeMode): AccountTheme => {
  if (accountType === 'valeter' && mode === 'light') return valeterLightTheme;
  if (accountType === 'business' && mode === 'light') return businessLightTheme;
  return accountThemes[accountType];
};
