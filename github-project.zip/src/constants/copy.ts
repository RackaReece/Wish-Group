/**
 * Shared copy for loading and common UI states.
 * Use these instead of inline strings for consistency and easier updates.
 */
export const COPY = {
  loading: 'Loading...',
  loadingDashboard: 'Loading dashboard...',
  loadingJob: 'Loading current job...',
  loadingBooking: 'Loading booking...',
} as const;
