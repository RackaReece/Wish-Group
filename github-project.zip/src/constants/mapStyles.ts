import type { Region } from 'react-native-maps';

/** Same zoom as customer app tracking – used for valeter and business map views. */
export const DEFAULT_MAP_ZOOM_DELTA = 0.005;

export const DEFAULT_MAP_REGION: Region = {
  latitude: 51.5074,
  longitude: -0.1278,
  latitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
  longitudeDelta: DEFAULT_MAP_ZOOM_DELTA,
};

/**
 * Map style JSON for react-native-maps customMapStyle.
 * Use in dark mode only; in light mode pass undefined for default light map.
 */
export const DARK_MAP_STYLE = [
  { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
  { featureType: 'administrative.locality', elementType: 'labels.text.fill', stylers: [{ color: '#d59563' }] },
  { featureType: 'poi', elementType: 'labels.text.fill', stylers: [{ color: '#d59563' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#263c3f' }] },
  { featureType: 'poi.park', elementType: 'labels.text.fill', stylers: [{ color: '#6b9a76' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#6b7689' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#5a6575' }] },
  { featureType: 'road', elementType: 'labels.text.fill', stylers: [{ color: '#9ca5b3' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#7d8a9a' }] },
  { featureType: 'road.highway', elementType: 'geometry.stroke', stylers: [{ color: '#6b7689' }] },
  { featureType: 'road.highway', elementType: 'labels.text.fill', stylers: [{ color: '#f3d19c' }] },
  { featureType: 'transit', elementType: 'geometry', stylers: [{ color: '#2f3948' }] },
  { featureType: 'transit.station', elementType: 'labels.text.fill', stylers: [{ color: '#d59563' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#7DD3FC' }] },
  { featureType: 'water', elementType: 'labels.text.fill', stylers: [{ color: '#5eb8e8' }] },
  { featureType: 'water', elementType: 'labels.text.stroke', stylers: [{ color: '#4a9fd4' }] },
];
