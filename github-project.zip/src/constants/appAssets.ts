/**
 * Central app assets for preload at boot. Used by BootContext so splash/loading show instantly.
 */
import { Asset } from 'expo-asset';

export const APP_LOGO_SOURCE = require('../../app/assets/icon.png');

/** Car marker / vehicle icon used on maps and booking flows (same as Wishv3 - root assets). */
export const CAR_IMAGE = require('../../assets/car.png');

/** Image-only assets to preload at boot. Videos are excluded to avoid memory spikes on launch. */
const BOOT_IMAGE_ASSETS = [
  require('../../app/assets/icon.png'),
  require('../../assets/cleaning.png'),
  require('../../assets/car.png'),
  require('../../app/assets/car-wash-2.png'),
];

let bootPreloadStarted = false;

/** Preload critical image assets at boot. */
export async function preloadBootAssets(): Promise<void> {
  if (bootPreloadStarted) return;
  bootPreloadStarted = true;
  const results = await Promise.allSettled(
    BOOT_IMAGE_ASSETS.map((mod) => Asset.fromModule(mod).downloadAsync())
  );
  if (__DEV__) {
    results.forEach((r, i) => {
      if (r.status === 'rejected') {
        console.warn(`Boot asset preload failed [${i}]:`, (r as PromiseRejectedResult).reason);
      }
    });
  }
}
