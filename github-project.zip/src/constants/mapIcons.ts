/**
 * Map marker icons.
 * - CUSTOMER_MAP_ICON (car.png): customer/vehicle on maps.
 * - HUB_MAP_ICON (cleaning.png): car wash hub / business location on maps.
 * - VALETER_MAP_ICON (icon.png): valeter / job destination on maps.
 */

// eslint-disable-next-line @typescript-eslint/no-require-imports
export const CUSTOMER_MAP_ICON = require('../../assets/car.png');

// eslint-disable-next-line @typescript-eslint/no-require-imports
export const HUB_MAP_ICON = require('../../assets/cleaning.png');

// eslint-disable-next-line @typescript-eslint/no-require-imports
export const VALETER_MAP_ICON = require('../../assets/icon.png');
