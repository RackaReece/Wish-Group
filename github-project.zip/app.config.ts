export default {
  name: "Wish a Washer",
  slug: "wish-a-washer",
  scheme: "waw",
  version: "1.0.0",
  orientation: "portrait",
  icon: "./app/assets/icon.png",
  userInterfaceStyle: "automatic",
  splash: {
    image: "./app/assets/icon.png",
    resizeMode: "contain",
    backgroundColor: "#0A1929" // Same as LoadingScreen / app background for consistent transition
  },
  assetBundlePatterns: [
    "**/*"
  ],
  experiments: { 
    typedRoutes: true,
    tsconfigPaths: true
  },
  ios: {
    supportsTablet: false,
    bundleIdentifier: "com.wishawasher.app",
    buildNumber: "5",
    infoPlist: {
      ITSAppUsesNonExemptEncryption: false,
      NSLocationWhenInUseUsageDescription: "We use your location to find nearby valeters and show your service location.",
      NSLocationAlwaysAndWhenInUseUsageDescription: "We use your location to provide real-time tracking and service updates.",
      NSCameraUsageDescription: "We use your camera to take photos of your vehicle for service documentation.",
      NSMicrophoneUsageDescription: "We use your microphone for voice booking and communication features.",
      NSPhotoLibraryUsageDescription: "We use your photo library to select vehicle photos for service documentation.",
      NSFaceIDUsageDescription: "We use Face ID to provide secure and quick login to your account.",
      UIBackgroundModes: ["location", "fetch", "remote-notification"],
      CFBundleDisplayName: "Wish a Washer"
    }
  },
  android: {
    package: "com.wishawasher.app",
    versionCode: 1,
    permissions: [
      "ACCESS_FINE_LOCATION",
      "ACCESS_COARSE_LOCATION",
      "CAMERA",
      "RECORD_AUDIO",
      "READ_EXTERNAL_STORAGE",
      "WRITE_EXTERNAL_STORAGE",
      "INTERNET",
      "ACCESS_NETWORK_STATE",
      "VIBRATE",
      "WAKE_LOCK"
    ],
    adaptiveIcon: {
      foregroundImage: "./app/assets/icon.png",
      backgroundColor: "#7DD3FC" // Sky blue base (gradient: cyan #7DD3FC → navy #1E3A8A → green #10B981)
    }
  },
  web: {
    favicon: "./app/assets/icon.png",
    bundler: "metro"
  },
  plugins: [
    "expo-router",
    "expo-location",
    "expo-notifications",
    "expo-image-picker",
    "expo-camera",
    "expo-media-library",
    "expo-file-system",
    "expo-apple-authentication",
    "expo-local-authentication"
  ],
  extra: {
    eas: {
      projectId: "90a8096b-21f7-4c99-bd76-9442d933e4e3"
    }
  }
};

