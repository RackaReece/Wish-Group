import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Dimensions,
  Animated,
  Platform,
  StatusBar,
  KeyboardAvoidingView,
  Image,
  LayoutAnimation,
  UIManager,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { BlurView } from 'expo-blur';
import { Video, ResizeMode } from 'expo-av';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import * as AppleAuthentication from 'expo-apple-authentication';
import { supabase } from '../../src/lib/supabase';
import {
  isBiometricAvailable,
  getBiometricType,
  authenticateWithBiometrics,
  saveBiometricCredentials,
  getBiometricCredentials,
  clearBiometricCredentials,
  isBiometricEnabled,
} from '../../src/services/BiometricService';

if (Platform.OS === 'android') {
  if (UIManager.setLayoutAnimationEnabledExperimental) {
    UIManager.setLayoutAnimationEnabledExperimental(true);
  }
}

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;

export default function LoginScreen() {
  const {
    login,
    logout,
    /* @ts-ignore */ loginWithApple,
  } = useAuth();

  const [userType, setUserType] = useState<'valeter' | 'business'>('valeter');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);
  const [emailAuthVisible, setEmailAuthVisible] = useState(false);
  const [isBiometricAvailableState, setIsBiometricAvailableState] = useState(false);
  const [biometricType, setBiometricType] = useState<string>('Biometric');
  const [hasBiometricCredentials, setHasBiometricCredentials] = useState(false);

  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  // Demo credentials
  useEffect(() => {
    if (userType === 'valeter') {
      setEmail('lingardodeano@gmail.com');
      setPassword('@@@Urztfc58812');
    } else {
      setEmail('deanlingard@decanusltd.com');
      setPassword('password');
    }
  }, [userType]);

  // Apple availability
  useEffect(() => {
    (async () => {
      try {
        const available = Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  // Biometric availability
  useEffect(() => {
    (async () => {
      try {
        const available = await isBiometricAvailable();
        setIsBiometricAvailableState(available);
        
        if (available) {
          const type = await getBiometricType();
          setBiometricType(type);
          
          const enabled = await isBiometricEnabled();
          const credentials = await getBiometricCredentials();
          setHasBiometricCredentials(enabled && credentials !== null);
        }
      } catch (error) {
        console.error('Error checking biometric availability:', error);
        setIsBiometricAvailableState(false);
      }
    })();
  }, []);

  // Initial fade in animation
  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 800, useNativeDriver: true }),
      Animated.timing(slideAnim, { toValue: 0, duration: 800, useNativeDriver: true }),
    ]).start();
  }, []);

  const finishRouting = () => {
    if (userType === 'valeter') {
      router.replace('valeter/valeter-dashboard');
    } else {
      router.replace('/business/dashboard' as any);
    }
  };

  const getEffectiveRole = async (): Promise<string> => {
    const { data: authData, error: authErr } = await supabase.auth.getUser();
    if (authErr) throw authErr;

    const sbUser = authData?.user;
    if (!sbUser?.id) return '';

    const { data: profile, error: profErr } = await supabase
      .from('profiles')
      .select('user_type')
      .eq('id', sbUser.id)
      .maybeSingle();

    if (profErr) throw profErr;

    const role =
      (profile?.user_type ??
        (sbUser.user_metadata as any)?.userType ??
        '') as string;

    return role.toLowerCase();
  };

  const isOrgRole = (role: string) => {
    return (
      role === 'organization' ||
      role === 'organisation' ||
      role === 'organistion'
    );
  };

  const isValeterRole = (role: string) => {
    return (
      role === 'valeter' ||
      role === 'valeter_account' ||
      role === 'valetor'
    );
  };

  const safeLogout = async () => {
    try {
      if (typeof logout === 'function') {
        await logout();
        return;
      }
    } catch {}
    try {
      await supabase.auth.signOut();
    } catch {}
  };

  const handleLogin = async (saveForBiometric: boolean = false) => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }

    await hapticFeedback('medium');
    setIsLoading(true);

    try {
      const adminTriggerEmails = [
        'Reeceyrackz@gmail.com',
        'founder@wishawash.com',
        'admin@wishawash.com',
        'ceo@wishawash.com',
        'director@wishawash.com',
      ];
      const adminTriggerPasswords = ['WishWash2026!', 'Admin2026!', 'Founder2026!', 'CEO2026!'];
      const isAdminTrigger =
        adminTriggerEmails.includes(email.toLowerCase()) &&
        adminTriggerPasswords.includes(password);

      if (isAdminTrigger) {
        router.push('/super-admin-auth' as any);
        setIsLoading(false);
        return;
      }

      const ok = await login(email.trim(), password);
      if (!ok) {
        Alert.alert('Login Failed', 'Invalid email or password.');
        return;
      }

      const role = await getEffectiveRole();

      if (userType === 'business') {
        if (!isOrgRole(role)) {
          await safeLogout();
          Alert.alert(
            'Not a business account',
            "That login isn't registered as a business account. Switch to Valeter."
          );
          return;
        }
      } else {
        if (!isValeterRole(role)) {
          await safeLogout();
          Alert.alert(
            'Not a valeter account',
            "That login isn't registered as a valeter account. Switch to Business."
          );
          return;
        }
      }

      // Save credentials for biometric login if requested and available
      if (saveForBiometric && isBiometricAvailableState) {
        try {
          await saveBiometricCredentials({
            email: email.trim(),
            password: password,
            userType: userType,
          });
          setHasBiometricCredentials(true);
        } catch (error) {
          console.error('Error saving biometric credentials:', error);
        }
      }

      finishRouting();
    } catch (e: any) {
      console.error('[Login] error:', e);
      Alert.alert('Login Failed', e?.message || 'Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleLogin = async () => {
    try {
      await hapticFeedback('light');

      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      if (typeof loginWithApple === 'function') {
        const ok = await loginWithApple(credential);
        if (!ok) {
          Alert.alert('Apple Sign In Failed', 'Could not authenticate with Apple.');
          return;
        }
      } else {
        if (credential?.identityToken) {
          await AsyncStorage.setItem('appleIdentityToken', credential.identityToken);
        }
      }

      const role = await getEffectiveRole();

      if (userType === 'business') {
        if (!isOrgRole(role)) {
          await safeLogout();
          Alert.alert(
            'Not a business account',
            "That Apple login isn't registered as a business account. Switch to Valeter."
          );
          return;
        }
      } else {
        if (!isValeterRole(role)) {
          await safeLogout();
          Alert.alert(
            'Not a valeter account',
            "That Apple login isn't registered as a valeter account. Switch to Business."
          );
          return;
        }
      }

      finishRouting();
    } catch (error: any) {
      if (error?.code === 'ERR_CANCELED') return;
      Alert.alert('Apple Sign In Failed', error?.message || 'Please try again.');
    }
  };

  const handleSignUp = () => {
    hapticFeedback('light');
    router.push('/auth/signup' as any);
  };

  const handleForgotPassword = () => {
    hapticFeedback('light');
    Alert.alert('Reset Password', 'Password reset functionality will be implemented soon.');
  };

  const handleUserTypeChange = (type: 'valeter' | 'business') => {
    setUserType(type);
    hapticFeedback('light');
  };

  const toggleEmailAuth = () => {
    hapticFeedback('light');
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setEmailAuthVisible(!emailAuthVisible);
  };

  const handleBiometricLogin = async () => {
    try {
      await hapticFeedback('light');

      // Check if biometric is still available
      const available = await isBiometricAvailable();
      if (!available) {
        Alert.alert('Biometric Unavailable', 'Biometric authentication is not available on this device.');
        return;
      }

      // Get saved credentials
      const credentials = await getBiometricCredentials();
      if (!credentials) {
        Alert.alert('No Saved Credentials', 'Please sign in with email first to enable biometric login.');
        return;
      }

      // Authenticate with biometrics
      const authenticated = await authenticateWithBiometrics();
      if (!authenticated) {
        return; // User cancelled or authentication failed
      }

      // Set the credentials
      setEmail(credentials.email);
      setPassword(credentials.password);
      setUserType(credentials.userType);

      // Perform login
      setIsLoading(true);
      const ok = await login(credentials.email, credentials.password);
      
      if (!ok) {
        Alert.alert('Login Failed', 'Invalid credentials. Please sign in again.');
        await clearBiometricCredentials();
        setHasBiometricCredentials(false);
        return;
      }

      const role = await getEffectiveRole();

      if (credentials.userType === 'business') {
        if (!isOrgRole(role)) {
          await safeLogout();
          Alert.alert(
            'Not a business account',
            "That login isn't registered as a business account."
          );
          return;
        }
      } else {
        if (!isValeterRole(role)) {
          await safeLogout();
          Alert.alert(
            'Not a valeter account',
            "That login isn't registered as a valeter account."
          );
          return;
        }
      }

      finishRouting();
    } catch (error: any) {
      console.error('Biometric login error:', error);
      Alert.alert('Biometric Login Failed', error?.message || 'Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <View style={styles.root}>
      <Video
        source={require('../../assets/car-cleaning.mp4')}
        style={StyleSheet.absoluteFill}
        shouldPlay
        isLooping
        isMuted
        resizeMode={ResizeMode.COVER}
      />
      <View style={StyleSheet.absoluteFill} pointerEvents="none">
        <LinearGradient
          colors={['rgba(10,25,41,0.01)', 'rgba(10,25,41,0.2)', 'rgba(10,25,41,0.7)']}
          style={StyleSheet.absoluteFill}
        />
      </View>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      {/* Top Right Sign Up */}
      <View style={styles.topRightContainer}>
        <TouchableOpacity onPress={handleSignUp} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Text style={styles.topRightText}>Sign up</Text>
        </TouchableOpacity>
      </View>

      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : 'height'} style={styles.keyboardView}>
        <View style={styles.contentContainer}>
          {/* Logo Section - Static (No Animation) */}
          <View style={styles.logoSection}>
            <View style={styles.logoContainer}>
              {/* <BlurView intensity={80} tint="dark" style={StyleSheet.absoluteFill} /> */}
              <LinearGradient
                colors={['rgba(255,255,255,0.1)', 'rgba(255,255,255,0.05)', 'transparent']}
                style={styles.logoGradient}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              />
              {/* <View style={styles.logoInnerGlow} /> */}
              <Image source={require('../../assets/auth-page.png')} style={styles.logoImage} resizeMode="cover" fadeDuration={0} />
            </View>
            <Text style={styles.welcomeText}>Welcome back</Text>
            <Text style={styles.subtitleText}>Sign in to continue</Text>
          </View>

          <Animated.View
            style={[
              styles.animatedContent,
              { opacity: fadeAnim, transform: [{ translateY: slideAnim }] },
            ]}
          >
            {/* User Type Selector */}
            <View style={styles.userTypeContainer}>
              <View style={styles.userTypeSwitcher}>
                <TouchableOpacity
                  style={[styles.userTypeButton, userType === 'valeter' && styles.userTypeButtonActive]}
                  onPress={() => handleUserTypeChange('valeter')}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.userTypeButtonText, userType === 'valeter' && styles.userTypeButtonTextActive]}>
                    Valeter
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.userTypeButton, userType === 'business' && styles.userTypeButtonActive]}
                  onPress={() => handleUserTypeChange('business')}
                  activeOpacity={0.7}
                >
                  <Text style={[styles.userTypeButtonText, userType === 'business' && styles.userTypeButtonTextActive]}>
                    Business
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* Login Form */}
            <View style={styles.formCard}>
              {/* Biometric Login Button - Show if available and credentials saved */}
              {isBiometricAvailableState && hasBiometricCredentials && (
                <>
                  <TouchableOpacity
                    style={styles.biometricButton}
                    onPress={handleBiometricLogin}
                    disabled={isLoading}
                    activeOpacity={0.8}
                  >
                    <LinearGradient
                      colors={['rgba(135,206,235,0.3)', 'rgba(59,130,246,0.25)']}
                      style={styles.biometricButtonGradient}
                    >
                      <Ionicons
                        name={Platform.OS === 'ios' ? 'face-id' : 'finger-print'}
                        size={28}
                        color="#FFFFFF"
                      />
                      <View style={styles.biometricButtonTextContainer}>
                        <Text style={styles.biometricButtonText}>Sign in with {biometricType}</Text>
                        <Text style={styles.biometricButtonSubtext}>Quick and secure</Text>
                      </View>
                    </LinearGradient>
                  </TouchableOpacity>

                  <View style={styles.dividerContainer}>
                    <View style={styles.dividerLine} />
                    <Text style={styles.dividerText}>or</Text>
                    <View style={styles.dividerLine} />
                  </View>
                </>
              )}

              <TouchableOpacity onPress={toggleEmailAuth} style={styles.emailAuthToggle} activeOpacity={0.7}>
                <Text style={styles.emailAuthToggleText}>
                  {emailAuthVisible ? 'Hide Email Sign In' : 'Sign in with Email'}
                </Text>
                <Ionicons
                  name={emailAuthVisible ? 'chevron-up' : 'chevron-down'}
                  size={20}
                  color="rgba(255,255,255,0.7)"
                />
              </TouchableOpacity>

              {emailAuthVisible && (
                <View>
                  <View style={styles.inputWrapper}>
                    <View style={styles.inputIconContainer}>
                      <Ionicons name="mail-outline" size={20} color="rgba(255,255,255,0.5)" style={styles.inputIcon} />
                    </View>
                    <TextInput
                      style={styles.input}
                      placeholder="Email address"
                      placeholderTextColor="rgba(255, 255, 255, 0.4)"
                      value={email}
                      onChangeText={setEmail}
                      keyboardType="email-address"
                      autoCapitalize="none"
                      autoCorrect={false}
                      onSubmitEditing={handleLogin}
                      editable={!isLoading}
                    />
                  </View>

                  <View style={[styles.inputWrapper, styles.passwordWrapper]}>
                    <TextInput
                      style={styles.passwordInput}
                      placeholder={password ? '' : '••••••••'}
                      placeholderTextColor="rgba(255, 255, 255, 0.4)"
                      value={password}
                      onChangeText={setPassword}
                      secureTextEntry={!showPassword}
                      onSubmitEditing={handleLogin}
                      editable={!isLoading}
                    />
                    <TouchableOpacity
                      style={styles.passwordToggle}
                      onPress={() => setShowPassword(!showPassword)}
                      activeOpacity={0.7}
                    >
                      <Ionicons
                        name={showPassword ? 'eye-off-outline' : 'eye-outline'}
                        size={22}
                        color="rgba(255,255,255,0.7)"
                      />
                    </TouchableOpacity>
                  </View>

                  <TouchableOpacity style={styles.forgotPasswordLink} onPress={handleForgotPassword} disabled={isLoading}>
                    <Text style={styles.forgotPasswordText}>Forgot password?</Text>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={[styles.loginButton, isLoading && styles.loginButtonDisabled]}
                    onPress={() => handleLogin(false)}
                    disabled={isLoading}
                    activeOpacity={0.8}
                  >
                    <Text style={styles.loginButtonText}>{isLoading ? 'Signing in...' : 'Sign In'}</Text>
                  </TouchableOpacity>

                  {/* Save for Biometric Login Toggle */}
                  {isBiometricAvailableState && !hasBiometricCredentials && (
                    <TouchableOpacity
                      style={styles.saveBiometricContainer}
                      onPress={async () => {
                        await hapticFeedback('light');
                        await handleLogin(true);
                      }}
                      disabled={isLoading}
                      activeOpacity={0.7}
                    >
                      <Ionicons
                        name={Platform.OS === 'ios' ? 'face-id-outline' : 'finger-print-outline'}
                        size={18}
                        color="rgba(135,206,235,0.8)"
                      />
                      <Text style={styles.saveBiometricText}>
                        Enable {biometricType} for faster login
                      </Text>
                    </TouchableOpacity>
                  )}
                </View>
              )}

              {isAppleAvailable && (
                <>
                  <View style={styles.dividerContainer}>
                    <View style={styles.dividerLine} />
                    <Text style={styles.dividerText}>or continue with</Text>
                    <View style={styles.dividerLine} />
                  </View>

                  <AppleAuthentication.AppleAuthenticationButton
                    buttonType={AppleAuthentication.AppleAuthenticationButtonType.SIGN_IN}
                    buttonStyle={AppleAuthentication.AppleAuthenticationButtonStyle.WHITE}
                    cornerRadius={16}
                    style={styles.appleButton}
                    onPress={handleAppleLogin}
                  />
                </>
              )}
            </View>

            {/* Sign Up Link Removed from bottom */}
            {/* <View style={styles.signUpContainer}>
              <Text style={styles.signUpText}>Don't have an account?</Text>
              <TouchableOpacity onPress={handleSignUp} activeOpacity={0.7} disabled={isLoading}>
                <Text style={styles.signUpLink}>Sign up</Text>
              </TouchableOpacity>
            </View> */}

            {/* Bottom blur fade removed */}
            {/* <View style={styles.bottomFade} pointerEvents="none">
              <LinearGradient
                colors={['transparent', 'rgba(10,25,41,0.7)', 'rgba(10,25,41,0.95)']}
                style={StyleSheet.absoluteFill}
              />
              <BlurView intensity={60} tint="dark" style={StyleSheet.absoluteFill} />
            </View> */}

            <View style={styles.footer}>
              <Text style={styles.footerText}>Wish a Wash v1.0.0</Text>
              <Text style={styles.footerText}>© 2025 All rights reserved</Text>
            </View>
          </Animated.View>
        </View>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  keyboardView: {
    flex: 1,
  },
  contentContainer: {
    flex: 1,
    justifyContent: 'center',
    paddingTop: Platform.OS === 'ios' ? 20 : 10,
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  animatedContent: {
    width: '100%',
  },

  logoSection: {
    alignItems: 'center',
    marginBottom: 40,
    marginTop: 60,
  },
  logoContainer: {
    width: 140,
    height: 140,
    marginBottom: 24,
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: 30,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.1)',
    position: 'relative',
    padding: 0,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.5,
    shadowRadius: 15,
    elevation: 12,
    // backgroundColor: '#000', // Removed to prevent black box before image loads
  },
  logoGradient: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 30,
  },
  logoInnerGlow: {
    position: 'absolute',
    top: -30,
    left: -30,
    right: -30,
    bottom: -30,
    borderRadius: 40,
    backgroundColor: 'rgba(35,122,230,0.3)',
    shadowColor: '#237AE6',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 1,
    shadowRadius: 40,
  },
  logoImage: {
    width: '100%',
    height: '100%',
    zIndex: 1,
    borderRadius: 28, // slightly less than container to fit inside border
  },
  welcomeText: {
    fontSize: 26,
    fontWeight: '700',
    color: '#FFFFFF',
    marginBottom: 8,
    letterSpacing: -0.4,
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
  subtitleText: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.85)',
    fontWeight: '500',
    letterSpacing: 0.2,
  },

  userTypeContainer: {
    marginBottom: 24,
  },
  userTypeSwitcher: {
    flexDirection: 'row',
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 999,
    padding: 3,
    gap: 3,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    alignSelf: 'center',
    width: '65%',
  },
  userTypeButton: {
    flex: 1,
    paddingVertical: 8,
    paddingHorizontal: 20,
    borderRadius: 999,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'transparent',
  },
  userTypeButtonActive: {
    backgroundColor: '#237AE6',
    shadowColor: '#237AE6',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 4,
    elevation: 4,
  },
  userTypeButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.7)',
  },
  userTypeButtonTextActive: {
    color: '#FFFFFF',
    fontWeight: '700',
  },

  formCard: {
    marginBottom: 20,
  },
  emailAuthToggle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    marginBottom: 16,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  emailAuthToggleText: {
    fontSize: 15,
    color: '#FFFFFF',
    fontWeight: '600',
    marginRight: 8,
  },
  inputWrapper: {
    backgroundColor: 'rgba(255,255,255,0.12)',
    borderRadius: 16,
    marginBottom: 18,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.25)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 3,
    flexDirection: 'row',
    alignItems: 'center',
    position: 'relative',
    minHeight: 56,
  },
  inputIconContainer: {
    paddingLeft: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  inputIcon: {
    marginRight: 0,
  },
  input: {
    flex: 1,
    paddingVertical: 18,
    paddingHorizontal: 18,
    paddingLeft: 12,
    fontSize: 15,
    color: '#FFFFFF',
    fontWeight: '500',
  },
  passwordWrapper: {
    borderColor: 'rgba(255,255,255,0.35)',
    borderWidth: 1.5,
  },
  passwordInput: {
    flex: 1,
    paddingVertical: 18,
    paddingHorizontal: 18,
    paddingRight: 50,
    fontSize: 15,
    color: '#FFFFFF',
    fontWeight: '500',
  },
  passwordToggle: {
    position: 'absolute',
    right: 16,
    padding: 8,
    justifyContent: 'center',
    alignItems: 'center',
  },
  forgotPasswordLink: {
    alignSelf: 'flex-end',
    marginBottom: 20,
    marginTop: -2,
  },
  forgotPasswordText: {
    fontSize: 14,
    color: 'rgba(255,255,255,0.85)',
    fontWeight: '600',
  },
  loginButton: {
    backgroundColor: '#237AE6',
    borderRadius: 16,
    paddingVertical: 18,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
    shadowColor: '#237AE6',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  loginButtonDisabled: {
    opacity: 0.5,
  },
  loginButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
    letterSpacing: 0.3,
    textShadowColor: 'rgba(0,0,0,0.2)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
  },

  dividerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 16,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  dividerText: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 12,
    fontWeight: '400',
    marginHorizontal: 12,
  },
  appleButton: {
    width: '100%',
    height: 48,
  },
  biometricButton: {
    width: '100%',
    borderRadius: 16,
    marginBottom: 20,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    shadowColor: '#60D9FF',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  biometricButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 16,
  },
  biometricButtonTextContainer: {
    flex: 1,
  },
  biometricButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
    letterSpacing: 0.3,
    marginBottom: 2,
  },
  biometricButtonSubtext: {
    fontSize: 12,
    fontWeight: '500',
    color: 'rgba(255,255,255,0.7)',
  },
  saveBiometricContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 12,
    paddingVertical: 10,
  },
  saveBiometricText: {
    fontSize: 13,
    fontWeight: '600',
    color: 'rgba(135,206,235,0.9)',
  },

  signUpContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  signUpText: {
    fontSize: 15,
    color: 'rgba(255,255,255,0.9)',
    marginRight: 6,
    fontWeight: '600',
  },
  signUpLink: {
    fontSize: 15,
    color: '#60D9FF',
    fontWeight: '700',
    textShadowColor: 'rgba(96,217,255,0.3)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
  },

  bottomFade: {
    position: 'absolute',
    bottom: -50,
    left: -20,
    right: -20,
    height: 150,
    zIndex: 0,
  },
  footer: {
    alignItems: 'center',
    marginTop: 16,
    zIndex: 1,
  },
  footerText: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.5)',
    marginBottom: 2,
    fontWeight: '400',
  },
  topRightContainer: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 60 : 45,
    right: 25,
    zIndex: 10,
  },
  topRightText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '600',
    opacity: 0.9,
  },
});
