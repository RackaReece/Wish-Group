import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions,
  TouchableOpacity,
  Linking,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import AppHeader, { HEADER_HEIGHT } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

const CONTACT_EMAIL = 'support@wishawash.com';
const ONBOARDING_EMAIL = 'onboarding@wishawash.com';

export default function TermsAgreement() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  
  // Determine account type from user or route
  const accountType = user?.userType === 'valeter' ? 'valeter' 
    : user?.userType === 'organization' ? 'business' 
    : 'customer';
  const theme = getAccountTheme(accountType);
  
  const handleEmailPress = (email: string) => {
    Linking.openURL(`mailto:${email}`);
  };

  const navigateToTerms = () => {
    router.push('/terms-of-service');
  };

  const navigateToPrivacy = () => {
    router.push('/privacy-policy');
  };
  
  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />

      <AppHeader 
        title="Terms Agreement" 
        accountType={accountType}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: insets.top + HEADER_HEIGHT + 4 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <GlassCard style={styles.headerCard} accountType={accountType}>
          <View style={styles.headerIcon}>
            <Ionicons name="document-text" size={32} color={theme.primary} />
          </View>
          <Text style={styles.lastUpdated}>Last updated: {new Date().toLocaleDateString('en-GB', { 
            day: 'numeric', 
            month: 'long', 
            year: 'numeric' 
          })}</Text>
        </GlassCard>

        {/* Terms of Service Section */}
        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="document-text" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>Terms of Service</Text>
          </View>
          <Text style={styles.sectionText}>
            By using Wish a Wash, you agree to our Terms of Service. Please read the full terms carefully before using our platform.
          </Text>
          
          <TouchableOpacity 
            onPress={navigateToTerms}
            style={[styles.linkButton, { borderColor: theme.primary }]}
          >
            <Ionicons name="open-outline" size={16} color={theme.primary} />
            <Text style={[styles.linkText, { color: theme.primary }]}>View Full Terms of Service</Text>
            <Ionicons name="chevron-forward" size={16} color={theme.primary} />
          </TouchableOpacity>

          <View style={styles.summarySection}>
            <Text style={styles.summaryTitle}>Key Points:</Text>
            <View style={styles.bulletList}>
              <Text style={styles.bulletPoint}>• Wish a Wash is a technology platform connecting customers with independent service providers</Text>
              <Text style={styles.bulletPoint}>• We do not take responsibility for damage caused by service providers - claims must be directed to the service provider</Text>
              <Text style={styles.bulletPoint}>• Service providers are strictly prohibited from poaching customers outside the platform</Text>
              <Text style={styles.bulletPoint}>• Payments are processed securely through Stripe (PCI DSS Level 1 certified)</Text>
              <Text style={styles.bulletPoint}>• Free cancellation up to 2 hours before scheduled time</Text>
              <Text style={styles.bulletPoint}>• You must be at least 18 years old to use our service</Text>
            </View>
          </View>
        </GlassCard>

        {/* Privacy Policy Section */}
        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="shield-checkmark" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>Privacy Policy</Text>
          </View>
          <Text style={styles.sectionText}>
            We respect your privacy and are committed to protecting your personal data in accordance with UK GDPR and the Data Protection Act 2018.
          </Text>
          
          <TouchableOpacity 
            onPress={navigateToPrivacy}
            style={[styles.linkButton, { borderColor: theme.primary }]}
          >
            <Ionicons name="open-outline" size={16} color={theme.primary} />
            <Text style={[styles.linkText, { color: theme.primary }]}>View Full Privacy Policy</Text>
            <Ionicons name="chevron-forward" size={16} color={theme.primary} />
          </TouchableOpacity>

          <View style={styles.summarySection}>
            <Text style={styles.summaryTitle}>Key Points:</Text>
            <View style={styles.bulletList}>
              <Text style={styles.bulletPoint}>• We collect identity data, vehicle data, location data, payment data, and usage data</Text>
              <Text style={styles.bulletPoint}>• Data is stored securely using Supabase (PostgreSQL) with encryption at rest and in transit</Text>
              <Text style={styles.bulletPoint}>• Payment data is processed by Stripe - we never store full card details</Text>
              <Text style={styles.bulletPoint}>• We comply with UK GDPR and the Data Protection Act 2018</Text>
              <Text style={styles.bulletPoint}>• You have rights including access, rectification, erasure, and data portability</Text>
              <Text style={styles.bulletPoint}>• Data is retained for 7 years for legal and tax purposes</Text>
              <Text style={styles.bulletPoint}>• We share necessary information with service providers to facilitate bookings</Text>
              <Text style={styles.bulletPoint}>• We do not sell your personal data to third parties for marketing purposes</Text>
            </View>
          </View>
        </GlassCard>

        {/* Agreement Section */}
        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="checkmark-circle" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>Your Agreement</Text>
          </View>
          <Text style={styles.sectionText}>
            By creating an account and using Wish a Wash, you acknowledge that you have read, understood, and agree to be bound by:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• Our Terms of Service</Text>
            <Text style={styles.bulletPoint}>• Our Privacy Policy</Text>
          </View>
          <Text style={[styles.sectionText, { marginTop: 12 }]}>
            If you do not agree with any part of these terms, please do not use our service.
          </Text>
        </GlassCard>

        {/* Contact Section */}
        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="mail" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>Questions or Concerns?</Text>
          </View>
          <Text style={styles.sectionText}>
            If you have any questions about our Terms of Service or Privacy Policy, please contact us:
          </Text>
          <TouchableOpacity 
            onPress={() => handleEmailPress(CONTACT_EMAIL)}
            style={styles.emailButton}
          >
            <Ionicons name="mail-outline" size={16} color={theme.primary} />
            <Text style={[styles.emailText, { color: theme.primary }]}>{CONTACT_EMAIL}</Text>
          </TouchableOpacity>
          <Text style={[styles.sectionText, { marginTop: 16 }]}>
            For business onboarding or partnership inquiries:
          </Text>
          <TouchableOpacity 
            onPress={() => handleEmailPress(ONBOARDING_EMAIL)}
            style={styles.emailButton}
          >
            <Ionicons name="business-outline" size={16} color={theme.primary} />
            <Text style={[styles.emailText, { color: theme.primary }]}>{ONBOARDING_EMAIL}</Text>
          </TouchableOpacity>
        </GlassCard>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 16 : 20, gap: 16 },
  headerCard: {
    padding: 20,
    alignItems: 'center',
    marginBottom: 8,
  },
  headerIcon: {
    marginBottom: 12,
  },
  lastUpdated: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '500',
    textAlign: 'center',
  },
  sectionCard: {
    padding: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '600',
  },
  sectionText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    lineHeight: 22,
    fontWeight: '400',
  },
  linkButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 16,
    padding: 14,
    borderRadius: 12,
    borderWidth: 1,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  linkText: {
    flex: 1,
    fontSize: 15,
    fontWeight: '600',
  },
  summarySection: {
    marginTop: 20,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
  },
  summaryTitle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  bulletList: {
    marginTop: 8,
    gap: 8,
  },
  bulletPoint: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    lineHeight: 20,
    marginLeft: 4,
  },
  emailButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
    padding: 12,
    borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  emailText: {
    fontSize: 14,
    fontWeight: '600',
  },
});
