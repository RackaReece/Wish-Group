import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions,
  TouchableOpacity,
  Linking,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import AppHeader, { HEADER_HEIGHT } from '../src/components/shared/AppHeader';
import GlassCard from '../src/components/booking/GlassCard';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { getAccountTheme } from '../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

const CONTACT_EMAIL = 'support@wishawash.com';
const ONBOARDING_EMAIL = 'onboarding@wishawash.com';

export default function PrivacyPolicy() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  
  // Determine account type from user or route
  const accountType = user?.userType === 'valeter' ? 'valeter' 
    : user?.userType === 'organization' ? 'business' 
    : 'customer';
  const theme = getAccountTheme(accountType);
  
  const handleEmailPress = (email: string) => {
    Linking.openURL(`mailto:${email}`);
  };
  
  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />

      <AppHeader 
        title="Privacy Policy" 
        accountType={accountType}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: insets.top + HEADER_HEIGHT + 4 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <GlassCard style={styles.headerCard} accountType={accountType}>
          <View style={styles.headerIcon}>
            <Ionicons name="shield-checkmark" size={32} color={theme.primary} />
          </View>
          <Text style={styles.lastUpdated}>Last updated: {new Date().toLocaleDateString('en-GB', { 
            day: 'numeric', 
            month: 'long', 
            year: 'numeric' 
          })}</Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="information-circle" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>1. Introduction</Text>
          </View>
          <Text style={styles.sectionText}>
            Welcome to Wish a Wash. We respect your privacy and are committed to protecting your personal data in accordance with the UK General Data Protection Regulation (UK GDPR) and the Data Protection Act 2018.
          </Text>
          <Text style={[styles.sectionText, { marginTop: 12 }]}>
            This Privacy Policy explains how we collect, use, store, and protect your personal information when you use our technology platform and internet marketplace.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="document-text" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>2. Data We Collect</Text>
          </View>
          <Text style={styles.sectionText}>
            We collect the following categories of personal data:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Identity Data:</Text> Name, email address, phone number, date of birth</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Vehicle Data:</Text> Vehicle registration, make, model, type, and other vehicle details</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Location Data:</Text> Service location addresses, GPS coordinates for service delivery</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Payment Data:</Text> Payment card details (processed securely by Stripe - we do not store full card numbers)</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Usage Data:</Text> App interactions, booking history, preferences, device information</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Communication Data:</Text> Messages, reviews, ratings, and feedback</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Service Provider Data:</Text> Business information, certifications, insurance details (for service providers)</Text>
          </View>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="server" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>3. How We Store Your Data</Text>
          </View>
          <Text style={styles.sectionText}>
            Your personal data is stored securely using industry-standard practices:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Cloud Storage:</Text> Data is stored on secure cloud servers with encryption at rest</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Database:</Text> We use Supabase (PostgreSQL) for data storage, which is GDPR-compliant and hosted in secure data centres</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Encryption:</Text> All data is encrypted in transit using TLS/SSL and at rest using AES-256 encryption</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Payment Data:</Text> Payment information is processed and stored by Stripe, a PCI DSS Level 1 certified payment processor. We never store full card details on our servers</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Access Controls:</Text> Data access is restricted to authorised personnel only, with role-based access controls</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Backup & Recovery:</Text> Regular automated backups are performed with secure retention policies</Text>
          </View>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="settings" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>4. How We Use Your Data</Text>
          </View>
          <Text style={styles.sectionText}>
            We use your personal data for the following purposes:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• To provide and operate our technology platform and marketplace services</Text>
            <Text style={styles.bulletPoint}>• To process bookings, payments, and facilitate communication between users and service providers</Text>
            <Text style={styles.bulletPoint}>• To send service-related notifications, booking confirmations, and reminders</Text>
            <Text style={styles.bulletPoint}>• To verify service provider credentials and maintain platform safety</Text>
            <Text style={styles.bulletPoint}>• To improve our services, develop new features, and analyse usage patterns</Text>
            <Text style={styles.bulletPoint}>• To prevent fraud, abuse, and ensure platform security</Text>
            <Text style={styles.bulletPoint}>• To comply with legal obligations and respond to lawful requests</Text>
            <Text style={styles.bulletPoint}>• To send marketing communications (with your consent, which you can withdraw at any time)</Text>
          </View>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="share-social" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>5. Data Sharing & Third Parties</Text>
          </View>
          <Text style={styles.sectionText}>
            We may share your data with:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Service Providers:</Text> To facilitate bookings, we share necessary information (name, contact, vehicle details, location) with the valeter or car wash business providing the service</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Payment Processors:</Text> Stripe processes payments - see their privacy policy at stripe.com/privacy</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Cloud Service Providers:</Text> Supabase (database hosting) and other infrastructure providers under strict data processing agreements</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Legal Authorities:</Text> When required by law, court order, or to protect our rights and safety</Text>
          </View>
          <Text style={[styles.sectionText, { marginTop: 12 }]}>
            We do not sell your personal data to third parties for marketing purposes.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="shield-checkmark" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>6. GDPR Compliance</Text>
          </View>
          <Text style={styles.sectionText}>
            We are fully committed to compliance with the UK General Data Protection Regulation (UK GDPR) and the Data Protection Act 2018. Our compliance measures include:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• Lawful basis for processing: We process your data based on contract performance, legitimate interests, consent, and legal obligations</Text>
            <Text style={styles.bulletPoint}>• Data minimisation: We only collect data necessary for providing our services</Text>
            <Text style={styles.bulletPoint}>• Purpose limitation: Data is used only for specified, explicit purposes</Text>
            <Text style={styles.bulletPoint}>• Storage limitation: We retain data only for as long as necessary for the purposes outlined in this policy</Text>
            <Text style={styles.bulletPoint}>• Accuracy: We take steps to ensure your data is accurate and up-to-date</Text>
            <Text style={styles.bulletPoint}>• Security: Appropriate technical and organisational measures protect your data</Text>
            <Text style={styles.bulletPoint}>• Accountability: We maintain records of our data processing activities</Text>
          </View>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="person" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>7. Your Rights Under UK GDPR</Text>
          </View>
          <Text style={styles.sectionText}>
            You have the following rights regarding your personal data:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Right of Access:</Text> Request a copy of your personal data we hold</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Right to Rectification:</Text> Correct inaccurate or incomplete data</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Right to Erasure:</Text> Request deletion of your data (subject to legal obligations)</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Right to Restrict Processing:</Text> Limit how we use your data</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Right to Data Portability:</Text> Receive your data in a structured, machine-readable format</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Right to Object:</Text> Object to processing based on legitimate interests</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Right to Withdraw Consent:</Text> Withdraw consent for processing where consent is the legal basis</Text>
          </View>
          <Text style={[styles.sectionText, { marginTop: 12 }]}>
            To exercise these rights, contact us at the email addresses provided below. We will respond within one month.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="lock-closed" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>8. Data Security</Text>
          </View>
          <Text style={styles.sectionText}>
            We implement appropriate technical and organisational measures to protect your personal data:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• Encryption of data in transit (TLS/SSL) and at rest (AES-256)</Text>
            <Text style={styles.bulletPoint}>• Secure authentication and access controls</Text>
            <Text style={styles.bulletPoint}>• Regular security assessments and updates</Text>
            <Text style={styles.bulletPoint}>• Staff training on data protection</Text>
            <Text style={styles.bulletPoint}>• Incident response procedures</Text>
          </View>
          <Text style={[styles.sectionText, { marginTop: 12 }]}>
            However, no method of transmission over the internet or electronic storage is 100% secure. While we strive to protect your data, we cannot guarantee absolute security.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="time" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>9. Data Retention</Text>
          </View>
          <Text style={styles.sectionText}>
            We retain your personal data only for as long as necessary:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Account Data:</Text> While your account is active and for 7 years after account closure (for legal and tax purposes)</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Booking Data:</Text> 7 years from the date of booking (for dispute resolution and legal requirements)</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Payment Records:</Text> 7 years (as required by HMRC and financial regulations)</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.boldText}>Marketing Data:</Text> Until you withdraw consent or unsubscribe</Text>
          </View>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="mail" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>10. Contact & Data Protection Officer</Text>
          </View>
          <Text style={styles.sectionText}>
            For privacy-related inquiries, data subject requests, or to exercise your rights:
          </Text>
          <TouchableOpacity 
            onPress={() => handleEmailPress(CONTACT_EMAIL)}
            style={styles.emailButton}
          >
            <Ionicons name="mail-outline" size={16} color={theme.primary} />
            <Text style={[styles.emailText, { color: theme.primary }]}>{CONTACT_EMAIL}</Text>
          </TouchableOpacity>
          <Text style={[styles.sectionText, { marginTop: 16 }]}>
            For business onboarding or partnership inquiries:
          </Text>
          <TouchableOpacity 
            onPress={() => handleEmailPress(ONBOARDING_EMAIL)}
            style={styles.emailButton}
          >
            <Ionicons name="business-outline" size={16} color={theme.primary} />
            <Text style={[styles.emailText, { color: theme.primary }]}>{ONBOARDING_EMAIL}</Text>
          </TouchableOpacity>
          <Text style={[styles.sectionText, { marginTop: 16 }]}>
            You also have the right to lodge a complaint with the Information Commissioner's Office (ICO) if you believe your data protection rights have been violated. Visit ico.org.uk for more information.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="document" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>11. Changes to This Policy</Text>
          </View>
          <Text style={styles.sectionText}>
            We may update this Privacy Policy from time to time. We will notify you of significant changes via email or through the Platform. The "Last updated" date at the top indicates when this policy was last revised.
          </Text>
        </GlassCard>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 16 : 20, gap: 16 },
  headerCard: {
    padding: 20,
    alignItems: 'center',
    marginBottom: 8,
  },
  headerIcon: {
    marginBottom: 12,
  },
  lastUpdated: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '500',
    textAlign: 'center',
  },
  sectionCard: {
    padding: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '600',
  },
  sectionText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    lineHeight: 22,
    fontWeight: '400',
  },
  boldText: {
    fontWeight: '700',
  },
  bulletList: {
    marginTop: 12,
    gap: 8,
  },
  bulletPoint: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    lineHeight: 20,
    marginLeft: 4,
  },
  emailButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
    padding: 12,
    borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  emailText: {
    fontSize: 14,
    fontWeight: '600',
  },
});
