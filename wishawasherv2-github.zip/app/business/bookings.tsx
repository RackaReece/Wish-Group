import React, { useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Alert,
  Image,
  Platform,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Marker, Region } from 'react-native-maps';
import { router, useLocalSearchParams } from 'expo-router';
import * as Location from 'expo-location';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import StatusBadge from '../../src/components/booking/StatusBadge';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { typography } from '../../src/constants/typography';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width, height } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

interface BookingUI {
  id: string;
  user_id?: string | null;
  customer_name: string;
  customer_profile_picture?: string | null;
  customer_lat?: number | null;
  customer_lng?: number | null;
  service_type: string;
  location_address: string | null;
  location_id?: string | null;
  location_lat: number | null;
  location_lng: number | null;
  scheduled_time: string | null;
  status: string;
  assigned_valeter_name: string | null;
  created_at: string;
  customer_on_way?: boolean;
  cancelled?: boolean;
  has_report?: boolean;
  vehicle_type?: string | null;
  vehicle_info?: string | null;
  vehicle_registration?: string | null;
  vehicle_make?: string | null;
  vehicle_model?: string | null;
}

type RawBookingRow = {
  id: string;
  status?: string | null;
  created_at: string;

  // optional columns (may or may not exist)
  customer_name?: string | null;
  service_type?: string | null;
  location_address?: string | null;
  valeter_id?: string | null;

  // time column (unknown name) — we’ll read it dynamically
  [key: string]: any;
};

function getMissingColumn(message?: string | null): string | null {
  const m = (message || '').match(/column\s+bookings\.([a-zA-Z0-9_]+)\s+does\s+not\s+exist/i);
  return m?.[1] ?? null;
}

/**
 * Your DB uses an enum booking_status.
 * This error happens when we pass a value that enum doesn't support.
 * So we MUST NOT send unknown status values in a SQL filter.
 *
 * We'll *try* a status filter, and if Postgres rejects it (22P02),
 * we retry WITHOUT filtering by status and then filter client-side.
 */
const STATUS_CANDIDATES_TO_TRY = [
  // These are *app-level* expectations; DB may differ.
  'pending_business_acceptance',
  'pending_valeter_acceptance',
  'confirmed',
  'in_progress',
  'completed',
  'cancelled',
];

const TIME_CANDIDATES = [
  'scheduled_time',
  'scheduled_at',
  'scheduled_for',
  'start_time',
  'start_at',
  'booking_time',
  'booked_for',
  'date_time',
  'datetime',
  'scheduled_datetime',
];

export default function BusinessBookings() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams();

  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const mapRef = useRef<MapView>(null);
  const scrollViewRef = useRef<any>(null);

  const [bookings, setBookings] = useState<BookingUI[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterStatus, setFilterStatus] = useState<string | null>(null);
  const [businessLocation, setBusinessLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const [selectedBookingIndex, setSelectedBookingIndex] = useState(0);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [locationPermission, setLocationPermission] = useState<Location.PermissionStatus | null>(null);
  const [initialRegion, setInitialRegion] = useState<Region | null>(null);

  const cardWidth = width - 40;
  const cardSpacing = 20;

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  // Request location permission and get user location
  useEffect(() => {
    const requestLocationPermission = async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        setLocationPermission(status);
        
        if (status === 'granted') {
          const location = await Location.getCurrentPositionAsync({
            accuracy: Location.Accuracy.High,
          });
          setUserLocation({
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
          });
          
          // Update map region to show user location
          setRegion({
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
            latitudeDelta: 0.05,
            longitudeDelta: 0.05,
          });
        }
      } catch (error) {
        console.error('Error getting location:', error);
      }
    };
    
    requestLocationPermission();
  }, []);

  // Watch user location for live updates
  useEffect(() => {
    if (locationPermission !== 'granted') return;
    
    const subscription = Location.watchPositionAsync(
      {
        accuracy: Location.Accuracy.High,
        distanceInterval: 100, // Update every 100 meters
        timeInterval: 30000, // Or every 30 seconds
      },
      (location) => {
        setUserLocation({
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        });
      }
    );

    return () => {
      subscription.then(sub => sub.remove());
    };
  }, [locationPermission]);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }).start();

    if (isOrgUser && organizationId) {
      loadBusinessLocation();
      loadBookings();
    } else {
      setBookings([]);
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [organizationId, isOrgUser, filterStatus]);

  // Subscribe to real-time customer location updates
  useEffect(() => {
    if (!isOrgUser || !organizationId || bookings.length === 0) return;

    const customerIds = bookings
      .map(b => b.user_id)
      .filter(Boolean) as string[];

    if (customerIds.length === 0) return;

    // Subscribe to profile location updates for customers with bookings
    const channel = supabase
      .channel('customer-locations-updates')
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'profiles',
          filter: `id=in.(${customerIds.join(',')})`,
        },
        (payload) => {
          const updated = payload.new as any;
          const customerId = updated.id;
          const newLat = updated.current_latitude || updated.latitude;
          const newLng = updated.current_longitude || updated.longitude;

          if (newLat && newLng && customerId) {
            // Update booking with new customer location
            setBookings((prev) =>
              prev.map((booking) => {
                if (booking.user_id === customerId) {
                  return {
                    ...booking,
                    customer_lat: newLat,
                    customer_lng: newLng,
                  };
                }
                return booking;
              })
            );
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [bookings, isOrgUser, organizationId]);

  // Load business location from car_wash_locations
  const loadBusinessLocation = async () => {
    if (!isOrgUser || !organizationId) return;
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('latitude, longitude')
        .eq('organization_id', organizationId)
        .not('latitude', 'is', null)
        .not('longitude', 'is', null)
        .limit(1)
        .single();

      if (!error && data?.latitude && data?.longitude) {
        setBusinessLocation({ lat: data.latitude, lng: data.longitude });
        const newRegion = {
          latitude: data.latitude,
          longitude: data.longitude,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        };
        setRegion(newRegion);
        if (!initialRegion) {
          setInitialRegion(newRegion);
        }
      }
    } catch (error) {
      console.error('Error loading business location:', error);
    }
  };

  const handleDeleteBooking = async (bookingId: string) => {
    Alert.alert(
      'Delete Booking',
      'Are you sure you want to delete this booking? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await hapticFeedback('medium');
              const { error } = await supabase.from('bookings').delete().eq('id', bookingId);

              if (error) throw error;

              setBookings((prev) => prev.filter((b) => b.id !== bookingId));
            } catch (error: any) {
              console.error('Error deleting booking:', error);
              Alert.alert('Error', error?.message || 'Failed to delete booking');
            }
          },
        },
      ]
    );
  };

  const handleDeleteAllBookings = async () => {
    if (bookings.length === 0) return;

    Alert.alert(
      'Delete All Bookings',
      `Are you sure you want to delete all ${bookings.length} booking${bookings.length !== 1 ? 's' : ''}? This action cannot be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete All',
          style: 'destructive',
          onPress: async () => {
            try {
              await hapticFeedback('medium');
              const bookingIds = bookings.map((b) => b.id);
              const { error } = await supabase.from('bookings').delete().in('id', bookingIds);

              if (error) throw error;

              setBookings([]);
            } catch (error: any) {
              console.error('Error deleting all bookings:', error);
              Alert.alert('Error', error?.message || 'Failed to delete all bookings');
            }
          },
        },
      ]
    );
  };

  const loadBookings = async () => {
    if (!isOrgUser || !organizationId) return;

    try {
      setLoading(true);

      // 1) Fetch org locations
      const { data: locations, error: locErr } = await supabase
        .from('car_wash_locations')
        .select('id, address')
        .eq('organization_id', organizationId);

      if (locErr) throw locErr;

      const locationIds = (locations || []).map((l: any) => l.id).filter(Boolean);
      const locationAddresses = (locations || [])
        .map((l: any) => (typeof l.address === 'string' ? l.address.trim() : ''))
        .filter((a: string) => a.length > 0);

      // Check if a specific location_id is provided in params
      const locationIdParam = params.locationId as string | undefined;

      if (locationIds.length === 0 && locationAddresses.length === 0) {
        setBookings([]);
        return;
      }

      // 2) Fetch bookings safely (no enum assumptions)
      // If locationIdParam is provided, filter by location_id, otherwise use address matching
      const { rows, resolvedTimeField } = locationIdParam 
        ? await fetchBookingsForLocationId(locationIdParam)
        : await fetchBookingsForAddresses(locationAddresses, locationIds);

      // 3) Resolve valeter names if valeter_id exists
      const valeterIds = Array.from(new Set(rows.map(r => r.valeter_id).filter(Boolean))) as string[];
      const profileMap = new Map<string, string>();

      if (valeterIds.length > 0) {
        const { data: profiles, error: profErr } = await supabase
          .from('profiles')
          .select('id, full_name, name')
          .in('id', valeterIds);

        if (profErr) {
          console.warn('[BusinessBookings] valeter name lookup error:', profErr.message);
        } else {
          (profiles || []).forEach((p: any) => {
            profileMap.set(p.id, (p.full_name || p.name || 'Valeter') as string);
          });
        }
      }

      // 4) Fetch vehicle information and customer profile pictures
      const customerIds = Array.from(new Set(rows.map(r => r.user_id).filter(Boolean))) as string[];
      const vehicleMap = new Map<string, { registration?: string; make?: string; model?: string; type?: string }>();
      const customerProfileMap = new Map<string, string | null>();

      if (customerIds.length > 0) {
        try {
          // Fetch vehicles
          const { data: vehicles, error: vehicleErr } = await supabase
            .from('customer_vehicles')
            .select('user_id, registration, make, model, type')
            .in('user_id', customerIds)
            .eq('is_default', true);

          if (vehicleErr) {
            console.warn('[BusinessBookings] vehicle lookup error:', vehicleErr.message);
          } else {
            (vehicles || []).forEach((v: any) => {
              vehicleMap.set(v.user_id, {
                registration: v.registration || undefined,
                make: v.make || undefined,
                model: v.model || undefined,
                type: v.type || undefined,
              });
            });
          }

          // Fetch customer profile pictures and locations
          const { data: customerProfiles, error: profileErr } = await supabase
            .from('profiles')
            .select('id, avatar_url, profile_picture, logo, current_latitude, current_longitude, latitude, longitude')
            .in('id', customerIds);

          if (profileErr) {
            console.warn('[BusinessBookings] customer profile lookup error:', profileErr.message);
          } else {
            (customerProfiles || []).forEach((p: any) => {
              const profilePic = p.avatar_url || p.profile_picture || p.logo || null;
              customerProfileMap.set(p.id, profilePic);
            });
          }
        } catch (error) {
          console.warn('[BusinessBookings] customer data lookup failed:', error);
        }
      }

      // Create customer location map
      const customerLocationMap = new Map<string, { lat: number; lng: number }>();
      if (customerIds.length > 0 && customerProfiles) {
        (customerProfiles || []).forEach((p: any) => {
          const lat = p.current_latitude || p.latitude;
          const lng = p.current_longitude || p.longitude;
          if (lat && lng && p.id) {
            customerLocationMap.set(p.id, { lat, lng });
          }
        });
      }

      const enriched: BookingUI[] = rows.map((b) => {
        const scheduledValue =
          resolvedTimeField && b[resolvedTimeField] ? String(b[resolvedTimeField]) : null;

        const status = String(b.status ?? 'unknown');
        const vehicleData = b.user_id ? vehicleMap.get(b.user_id) : null;
        const customerProfilePic = b.user_id ? customerProfileMap.get(b.user_id) || null : null;
        const customerLoc = b.user_id ? customerLocationMap.get(b.user_id) : null;

        return {
          id: b.id,
          user_id: b.user_id ?? null,
          customer_name: (b.customer_name || 'Customer') as string,
          customer_profile_picture: customerProfilePic,
          customer_lat: customerLoc?.lat ?? null,
          customer_lng: customerLoc?.lng ?? null,
          service_type: (b.service_type || 'Service') as string,
          location_address: b.location_address ?? null,
          location_id: b.location_id ?? null,
          location_lat: b.location_lat ?? null,
          location_lng: b.location_lng ?? null,
          scheduled_time: scheduledValue,
          status,
          assigned_valeter_name: b.valeter_id ? profileMap.get(b.valeter_id) || null : null,
          created_at: b.created_at,
          customer_on_way: status === 'in_progress',
          cancelled: status === 'cancelled',
          has_report: false,
          vehicle_type: b.vehicle_type || vehicleData?.type || null,
          vehicle_info: b.vehicle_info || null,
          vehicle_registration: vehicleData?.registration || null,
          vehicle_make: vehicleData?.make || null,
          vehicle_model: vehicleData?.model || null,
        };
      });

      // Filter client-side (safe even if DB enum doesn't match our labels)
      let filtered = filterStatus ? enriched.filter((b) => b.status === filterStatus) : enriched;
      
      // Show customers en route when filter is null or 'in_progress'
      // En route means status is 'en_route' or customer is heading to car wash
      if (!filterStatus || filterStatus === 'in_progress') {
        // Include en_route status bookings
        filtered = enriched.filter((b) => 
          b.status === 'en_route' || 
          b.status === 'in_progress' || 
          (filterStatus ? b.status === filterStatus : true)
        );
      }
      
      setBookings(filtered);

      // Update map region - prioritize business location, then bookings
      if (businessLocation) {
        const bookingsWithLocation = filtered.filter(b => b.location_lat && b.location_lng);
        if (bookingsWithLocation.length > 0) {
          // Include business location in bounds calculation
          const allLats = [businessLocation.lat, ...bookingsWithLocation.map(b => b.location_lat!)];
          const allLngs = [businessLocation.lng, ...bookingsWithLocation.map(b => b.location_lng!)];
          const minLat = Math.min(...allLats);
          const maxLat = Math.max(...allLats);
          const minLng = Math.min(...allLngs);
          const maxLng = Math.max(...allLngs);
          
          setRegion({
            latitude: (minLat + maxLat) / 2,
            longitude: (minLng + maxLng) / 2,
            latitudeDelta: Math.max((maxLat - minLat) * 1.5, 0.05),
            longitudeDelta: Math.max((maxLng - minLng) * 1.5, 0.05),
          });
        } else {
          // Just center on business location
          setRegion({
            latitude: businessLocation.lat,
            longitude: businessLocation.lng,
            latitudeDelta: 0.05,
            longitudeDelta: 0.05,
          });
        }
      } else {
        // Fallback to bookings only
        const bookingsWithLocation = filtered.filter(b => b.location_lat && b.location_lng);
        if (bookingsWithLocation.length > 0) {
          const lats = bookingsWithLocation.map(b => b.location_lat!);
          const lngs = bookingsWithLocation.map(b => b.location_lng!);
          const minLat = Math.min(...lats);
          const maxLat = Math.max(...lats);
          const minLng = Math.min(...lngs);
          const maxLng = Math.max(...lngs);
          
          const newRegion = {
            latitude: (minLat + maxLat) / 2,
            longitude: (minLng + maxLng) / 2,
            latitudeDelta: Math.max((maxLat - minLat) * 1.5, 0.05),
            longitudeDelta: Math.max((maxLng - minLng) * 1.5, 0.05),
          };
          setRegion(newRegion);
          if (!initialRegion) {
            setInitialRegion(newRegion);
          }
        }
      }

      // Update map region based on bookings with locations
      const bookingsWithLocation = filtered.filter(b => b.location_lat && b.location_lng);
      if (bookingsWithLocation.length > 0) {
        const lats = bookingsWithLocation.map(b => b.location_lat!);
        const lngs = bookingsWithLocation.map(b => b.location_lng!);
        const minLat = Math.min(...lats);
        const maxLat = Math.max(...lats);
        const minLng = Math.min(...lngs);
        const maxLng = Math.max(...lngs);
        
        const newRegion = {
          latitude: (minLat + maxLat) / 2,
          longitude: (minLng + maxLng) / 2,
          latitudeDelta: Math.max((maxLat - minLat) * 1.5, 0.05),
          longitudeDelta: Math.max((maxLng - minLng) * 1.5, 0.05),
        };
        setRegion(newRegion);
        if (!initialRegion) {
          setInitialRegion(newRegion);
        }
      }
      
      if (filtered.length > 0) {
        setSelectedBookingIndex(0);
      }
    } catch (error: any) {
      console.error('Error loading bookings:', error);
      Alert.alert('Error', error?.message || 'Failed to load bookings');
    } finally {
      setLoading(false);
    }
  };

  /**
   * Fetch bookings matching location_id in a schema-safe way.
   */
  const fetchBookingsForLocationId = async (
    locationId: string
  ): Promise<{ rows: RawBookingRow[]; resolvedTimeField: string | null }> => {
    const baseFields = ['id', 'created_at', 'status', 'location_address', 'location_id', 'location_lat', 'location_lng', 'service_type', 'customer_name', 'valeter_id', 'vehicle_type', 'vehicle_info', 'user_id'];
    const timeAttempts = [...TIME_CANDIDATES, null] as (string | null)[];

    for (const timeField of timeAttempts) {
      const fields = timeField ? [...baseFields, timeField] : [...baseFields];
      const uniqueFields = Array.from(new Set(fields));

      const { data, error } = await supabase
        .from('bookings')
        .select(uniqueFields.join(','))
        .eq('location_id', locationId)
        .order('created_at', { ascending: false })
        .limit(100);

      if (!error) {
        return {
          rows: (data || []) as RawBookingRow[],
          resolvedTimeField: timeField,
        };
      }

      const missing = getMissingColumn(error?.message);
      if (error?.code === '42703' && missing) {
        if (baseFields.includes(missing)) {
          const idx = baseFields.indexOf(missing);
          if (idx >= 0) baseFields.splice(idx, 1);
          continue;
        }
        continue;
      }
    }

    return { rows: [], resolvedTimeField: null };
  };

  /**
   * Fetch bookings matching location_address in a schema-safe way.
   * - never touches customer_id
   * - never assumes scheduled_time exists
   * - never assumes our status values exist in DB enum (retries without status filter if rejected)
   */
  const fetchBookingsForAddresses = async (
    locationAddresses: string[],
    locationIds?: string[]
  ): Promise<{ rows: RawBookingRow[]; resolvedTimeField: string | null }> => {
    // Base select that *might* exist; we'll remove missing ones on the fly
    const baseFields = ['id', 'created_at', 'status', 'location_address', 'location_id', 'location_lat', 'location_lng', 'service_type', 'customer_name', 'valeter_id', 'vehicle_type', 'vehicle_info', 'user_id'];

    // Try time fields; if none exist, fetch without time field
    const timeAttempts = [...TIME_CANDIDATES, null] as (string | null)[];

    let lastErr: any = null;

    // If DB rejects our enum filter once, never try it again in this call
    let disableStatusFilter = false;

    for (const timeField of timeAttempts) {
      // Build select list
      const fields = timeField ? [...baseFields, timeField] : [...baseFields];

      // We might have removed some baseFields in prior loops; ensure uniqueness
      const uniqueFields = Array.from(new Set(fields));

      // Build query - try location_id first if available, then fallback to address
      let q = supabase
        .from('bookings')
        .select(uniqueFields.join(','))
        .order('created_at', { ascending: false })
        .limit(100);

      // Filter by location_id if available, otherwise use address
      if (locationIds && locationIds.length > 0) {
        q = q.in('location_id', locationIds);
      } else if (locationAddresses.length > 0) {
        q = q.in('location_address', locationAddresses as any);
      }

      // Try to pre-filter by status ONLY if not disabled (but this may be rejected by enum)
      if (!disableStatusFilter) {
        q = q.in('status', STATUS_CANDIDATES_TO_TRY as any);
      }

      const { data, error } = await q;

      if (!error) {
        return {
          rows: (data || []) as RawBookingRow[],
          resolvedTimeField: timeField,
        };
      }

      lastErr = error;

      // 🔥 Enum rejection: "invalid input value for enum booking_status"
      // Postgres error code 22P02 -> retry WITHOUT status filter
      if (error?.code === '22P02' && /enum\s+booking_status/i.test(error?.message || '')) {
        disableStatusFilter = true;
        // retry same timeField immediately without status filter
        let q2 = supabase
          .from('bookings')
          .select(uniqueFields.join(','))
          .order('created_at', { ascending: false })
          .limit(100);

        if (locationIds && locationIds.length > 0) {
          q2 = q2.in('location_id', locationIds);
        } else if (locationAddresses.length > 0) {
          q2 = q2.in('location_address', locationAddresses as any);
        }

        const { data: data2, error: err2 } = await q2;

        if (!err2) {
          return {
            rows: (data2 || []) as RawBookingRow[],
            resolvedTimeField: timeField,
          };
        }

        lastErr = err2;
        // continue loop (maybe missing columns too)
      }

      // Missing column? Try next combination.
      const missing = getMissingColumn(error?.message);
      if (error?.code === '42703' && missing) {
        // If the missing column is one of the base fields, remove it and retry this timeField
        if (baseFields.includes(missing)) {
          const idx = baseFields.indexOf(missing);
          if (idx >= 0) baseFields.splice(idx, 1);
          // retry same timeField after removing missing base field
          continue;
        }

        // If missing is the timeField, move on
        continue;
      }

      // Non-schema error -> throw
      throw error;
    }

    throw lastErr ?? new Error('Failed to load bookings');
  };

  // NOTE: These are UI filters. If your DB enum uses different labels,
  // update these values to match what's actually stored in bookings.status.
  const statusFilters = [
    { label: 'All', value: null, icon: 'list' as const, color: businessTheme.primary },
    { label: 'Pending', value: 'pending_business_acceptance', icon: 'time-outline' as const, color: '#FBBF24' },
    { label: 'In Progress', value: 'in_progress', icon: 'play-circle-outline' as const, color: businessTheme.primary },
    { label: 'Completed', value: 'completed', icon: 'checkmark-done-circle' as const, color: '#8B5CF6' },
  ];

  // Calculate time until booking (UI only - no backend)
  const getTimeUntilBooking = (scheduledTime: string | null): { minutes: number; text: string; isUrgent: boolean } | null => {
    if (!scheduledTime) return null;
    const now = new Date();
    const scheduled = new Date(scheduledTime);
    const diffMs = scheduled.getTime() - now.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    
    if (diffMins < 0) return { minutes: diffMins, text: 'Overdue', isUrgent: true };
    if (diffMins < 5) return { minutes: diffMins, text: `${diffMins} min`, isUrgent: true };
    if (diffMins < 60) return { minutes: diffMins, text: `${diffMins} min`, isUrgent: false };
    const hours = Math.floor(diffMins / 60);
    return { minutes: diffMins, text: `${hours}h ${diffMins % 60}m`, isUrgent: false };
  };

  // Calculate ETA (estimated time of arrival) - UI only
  const getETA = (booking: BookingUI): string | null => {
    if (!booking.scheduled_time) return null;
    const timeUntil = getTimeUntilBooking(booking.scheduled_time);
    if (!timeUntil) return null;
    return timeUntil.text;
  };

  // Sync map with selected booking
  useEffect(() => {
    if (bookings.length > 0 && selectedBookingIndex < bookings.length) {
      const selectedBooking = bookings[selectedBookingIndex];
      if (selectedBooking.location_lat && selectedBooking.location_lng) {
        const newRegion: Region = {
          latitude: selectedBooking.location_lat,
          longitude: selectedBooking.location_lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        };
        setRegion(newRegion);
        mapRef.current?.animateToRegion(newRegion, 500);
      }
    }
  }, [selectedBookingIndex, bookings]);

  // Scroll to selected booking when index changes
  useEffect(() => {
    if (scrollViewRef.current && bookings.length > 0 && selectedBookingIndex < bookings.length) {
      const scrollX = selectedBookingIndex * (cardWidth + cardSpacing);
      scrollViewRef.current.scrollTo({
        x: scrollX,
        animated: true,
      });
    }
  }, [selectedBookingIndex, bookings.length]);

  const handleScroll = (event: any) => {
    const scrollPosition = event.nativeEvent.contentOffset.x;
    const newIndex = Math.round(scrollPosition / (cardWidth + cardSpacing));
    
    if (newIndex >= 0 && newIndex < bookings.length && newIndex !== selectedBookingIndex) {
      setSelectedBookingIndex(newIndex);
    }
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (bookings.length > 0 && selectedBookingIndex < bookings.length) {
      const selectedBooking = bookings[selectedBookingIndex];
      if (selectedBooking.location_lat && selectedBooking.location_lng) {
        const newRegion: Region = {
          latitude: selectedBooking.location_lat,
          longitude: selectedBooking.location_lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        };
        setRegion(newRegion);
        mapRef.current?.animateToRegion(newRegion, 500);
      }
    } else if (initialRegion) {
      setRegion(initialRegion);
      mapRef.current?.animateToRegion(initialRegion, 500);
    } else if (userLocation) {
      const newRegion: Region = {
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      };
      setRegion(newRegion);
      mapRef.current?.animateToRegion(newRegion, 500);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Bookings" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading bookings...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!isOrgUser || !organizationId) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Bookings" accountType="business" />
        <View style={styles.loadingContainer}>
          <Ionicons name="alert-circle-outline" size={42} color={SKY} style={{ opacity: 0.85 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This business account isn’t linked to an organization yet.
            {'\n'}Log out and back in, or contact support.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  // Render booking card component (similar to valeter job card)
  const renderBookingCard = (booking: BookingUI) => {
    const timeUntil = getTimeUntilBooking(booking.scheduled_time);
    const eta = getETA(booking);
    const isUrgent = timeUntil?.isUrgent || false;

    return (
      <View style={styles.bookingCardWrapper}>
        <BlurView intensity={60} tint="dark" style={styles.bookingCardBlur}>
          <View style={styles.jobCardBackground} />
          <View style={[styles.jobCardBorder, { borderColor: 'rgba(135,206,235,0.3)' }]} />
          
          {/* Header */}
          <View style={styles.bookingCardHeader}>
            <View style={styles.bookingCardHeaderContent}>
              <View style={styles.servicePreviewIcon}>
                {booking.customer_profile_picture ? (
                  <Image 
                    source={{ uri: booking.customer_profile_picture }} 
                    style={styles.customerProfileImage}
                    resizeMode="cover"
                  />
                ) : (
                  <Ionicons name="person" size={12} color={businessTheme.primary} />
                )}
              </View>
              <View style={styles.bookingCardHeaderText}>
                <Text style={styles.bookingCardTitle} numberOfLines={1}>
                  {booking.customer_name}
                </Text>
                <Text style={styles.bookingCardService}>{booking.service_type}</Text>
              </View>
            </View>
            <View style={styles.bookingCardHeaderRight}>
              <StatusBadge status={booking.status as any} size="small" />
            </View>
          </View>

          {/* Details */}
          <View style={styles.bookingCardDetails}>
            {booking.location_address && (
              <View style={styles.bookingDetailRow}>
                <Ionicons name="location-outline" size={16} color={SKY} />
                <Text style={styles.bookingDetailText} numberOfLines={2}>
                  {booking.location_address}
                </Text>
              </View>
            )}

            {booking.scheduled_time && (
              <View style={styles.bookingDetailRow}>
                <Ionicons name="time-outline" size={16} color={SKY} />
                <Text style={[styles.bookingDetailText, isUrgent && styles.urgentText]}>
                  {new Date(booking.scheduled_time).toLocaleString('en-GB', {
                    day: 'numeric',
                    month: 'short',
                    hour: '2-digit',
                    minute: '2-digit',
                  })}
                  {eta && ` • ETA: ${eta}`}
                </Text>
              </View>
            )}

            {booking.status === 'en_route' && (
              <View style={styles.bookingDetailRow}>
                <Ionicons name="car" size={16} color="#10B981" />
                <Text style={styles.enRouteText}>Customer en route to car wash</Text>
              </View>
            )}

            {/* Vehicle Information */}
            {(booking.vehicle_registration || booking.vehicle_type || booking.vehicle_make || booking.vehicle_model) && (
              <View style={styles.bookingDetailRow}>
                <Ionicons name="car-sport-outline" size={16} color={SKY} />
                <View style={styles.vehicleInfoContainer}>
                  {booking.vehicle_registration && (
                    <Text style={styles.vehicleRegistration}>{booking.vehicle_registration}</Text>
                  )}
                  {(booking.vehicle_make || booking.vehicle_model || booking.vehicle_type) && (
                    <Text style={styles.bookingDetailText}>
                      {[booking.vehicle_make, booking.vehicle_model, booking.vehicle_type].filter(Boolean).join(' ')}
                    </Text>
                  )}
                </View>
              </View>
            )}

            {timeUntil && timeUntil.isUrgent && (
              <View style={styles.bookingDetailRow}>
                <Ionicons name="alert-circle" size={16} color="#F59E0B" />
                <Text style={styles.urgentText}>
                  {timeUntil.minutes < 0 ? 'Overdue' : `${timeUntil.minutes} minutes until booking`}
                </Text>
              </View>
            )}

            {booking.assigned_valeter_name && (
              <View style={styles.bookingDetailRow}>
                <Ionicons name="person-outline" size={16} color={SKY} />
                <Text style={styles.bookingDetailText}>{booking.assigned_valeter_name}</Text>
              </View>
            )}
          </View>

          {/* Live Booking Location Card - Show 5 minutes before booking */}
          {(() => {
            const timeUntil = getTimeUntilBooking(booking.scheduled_time);
            const isWithin5Minutes = timeUntil && timeUntil.minutes <= 5 && timeUntil.minutes >= 0;
            const customerLocation = booking.customer_lat && booking.customer_lng 
              ? { lat: booking.customer_lat, lng: booking.customer_lng }
              : null;
            const bookingLocation = booking.location_lat && booking.location_lng
              ? { lat: booking.location_lat, lng: booking.location_lng }
              : null;

            // Calculate distance if both locations exist
            let distanceKm = null;
            if (customerLocation && bookingLocation) {
              const R = 6371; // Earth's radius in km
              const dLat = (bookingLocation.lat - customerLocation.lat) * Math.PI / 180;
              const dLon = (bookingLocation.lng - customerLocation.lng) * Math.PI / 180;
              const a = 
                Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(customerLocation.lat * Math.PI / 180) * Math.cos(bookingLocation.lat * Math.PI / 180) *
                Math.sin(dLon/2) * Math.sin(dLon/2);
              const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
              distanceKm = R * c;
            }

            if (isWithin5Minutes && customerLocation) {
              return (
                <BlurView intensity={60} tint="dark" style={styles.liveBookingCard}>
                  <View style={styles.liveBookingCardBackground} />
                  <View style={styles.liveBookingCardBorder} />
                  <View style={styles.liveBookingCardContent}>
                    <View style={styles.liveBookingCardHeader}>
                      <View style={styles.liveIndicator}>
                        <View style={styles.liveIndicatorDot} />
                        <Text style={styles.liveIndicatorText}>LIVE</Text>
                      </View>
                      <Ionicons name="navigate" size={20} color="#10B981" />
                    </View>
                    <Text style={styles.liveBookingCardTitle}>Customer Location</Text>
                    {distanceKm !== null && (
                      <View style={styles.liveDistanceContainer}>
                        <Ionicons name="location" size={18} color="#10B981" />
                        <Text style={styles.liveDistanceText}>
                          {distanceKm < 1 
                            ? `${Math.round(distanceKm * 1000)}m away` 
                            : `${distanceKm.toFixed(1)}km away`}
                        </Text>
                      </View>
                    )}
                    <View style={styles.liveTrackingRow}>
                      <Ionicons name="pulse" size={14} color="#10B981" />
                      <Text style={styles.liveTrackingText}>Live tracking active • Updates every 30s</Text>
                    </View>
                  </View>
                </BlurView>
              );
            }
            return null;
          })()}
        </BlurView>
      </View>
    );
  };

  // Render map function
  const renderMap = () => {
    if (loading) {
      return (
        <View style={styles.mapContainer}>
          <View style={styles.mapLoadingContainer}>
            <ActivityIndicator size="large" color={SKY} />
            <Text style={styles.mapLoadingText}>Loading map...</Text>
          </View>
        </View>
      );
    }

    return (
      <View style={styles.mapContainer}>
        <MapView
          ref={mapRef}
          style={styles.map}
          region={region}
          showsUserLocation={true}
          showsMyLocationButton={true}
          mapType="standard"
          mapPadding={{ top: 0, bottom: height * 0.4, left: 0, right: 0 }}
          loadingEnabled={true}
          loadingIndicatorColor={SKY}
          followsUserLocation={true}
          userLocationPriority="high"
          userLocationUpdateInterval={5000}
        >
          {/* Business Location Marker */}
          {businessLocation && (
            <Marker
              coordinate={{
                latitude: businessLocation.lat,
                longitude: businessLocation.lng,
              }}
              anchor={{ x: 0.5, y: 0.5 }}
            >
              <View style={styles.businessLocationMarker}>
                <View style={styles.businessLocationPin}>
                  <Ionicons name="business" size={24} color="#FFFFFF" />
                </View>
              </View>
            </Marker>
          )}

          {/* Customer Markers (en route or in progress) */}
          {bookings.filter(b => b.location_lat && b.location_lng && (b.status === 'en_route' || b.status === 'in_progress')).map((booking, index) => {
            const isSelected = index === selectedBookingIndex;
            const isEnRoute = booking.status === 'en_route';
            return (
              <Marker
                key={booking.id}
                coordinate={{
                  latitude: booking.location_lat!,
                  longitude: booking.location_lng!,
                }}
                anchor={{ x: 0.5, y: 0.5 }}
              >
                <View style={[styles.mapMarkerPin, isSelected && styles.mapMarkerPinSelected, isEnRoute && styles.enRouteMarker]}>
                  <Image
                    source={require('../../assets/car.png')}
                    style={styles.carMarkerImage}
                    resizeMode="contain"
                  />
                </View>
              </Marker>
            );
          })}
        </MapView>
      </View>
    );
  };

  // Render booking cards with horizontal scrolling
  const renderBookingCards = () => {
    if (loading) {
      return (
        <View style={styles.cardsLoadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading bookings...</Text>
        </View>
      );
    }

    if (bookings.length === 0) {
      return (
        <View style={styles.emptyContainer}>
          <BlurView intensity={60} tint="dark" style={styles.emptyCard}>
            <View style={styles.jobCardBackground} />
            <View style={[styles.jobCardBorder, { borderColor: 'rgba(135,206,235,0.3)' }]} />
            <View style={styles.emptyContent}>
              <Ionicons name="calendar-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
              <Text style={styles.emptyTitle}>No Bookings Available</Text>
              <Text style={styles.emptyText}>
                {filterStatus
                  ? `No ${statusFilters.find((f) => f.value === filterStatus)?.label.toLowerCase()} bookings`
                  : 'Bookings will appear here as customers book your services'}
              </Text>
            </View>
          </BlurView>
        </View>
      );
    }

    return (
      <View style={[styles.bookingCardContainer, { paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20 }]}>
        <ScrollView
          ref={scrollViewRef}
          horizontal
          pagingEnabled={false}
          showsHorizontalScrollIndicator={false}
          onScroll={handleScroll}
          scrollEventThrottle={16}
          contentContainerStyle={styles.scrollContent}
          snapToInterval={cardWidth + cardSpacing}
          decelerationRate="fast"
          snapToAlignment="start"
        >
          {bookings.map((booking, index) => (
            <View key={booking.id} style={styles.bookingCardScrollItem}>
              {renderBookingCard(booking)}
            </View>
          ))}
        </ScrollView>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      
      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
          },
        ]}
      >
        {renderMap()}
        <View style={styles.headerOverlay}>
          <AppHeader
            title="Bookings"
            rightAction={
              <View style={styles.headerActions}>
                <TouchableOpacity
                  onPress={handleRecenter}
                  style={styles.recenterButton}
                >
                  <Ionicons name="locate" size={20} color={SKY} />
                </TouchableOpacity>
                <TouchableOpacity onPress={async () => {
                  await hapticFeedback('light');
                  loadBookings();
                }} style={styles.refreshButton}>
                  <Ionicons name="refresh" size={20} color={SKY} />
                </TouchableOpacity>
              </View>
            }
            accountType="business"
          />
          {/* Booking indicator dots under header */}
          {bookings.length > 1 && (
            <View style={styles.headerIndicatorContainer}>
              {bookings.map((booking, index) => (
                <View
                  key={booking.id || `indicator-${index}`}
                  style={[
                    styles.headerIndicatorDot,
                    index === selectedBookingIndex && styles.headerIndicatorDotActive,
                  ]}
                />
              ))}
            </View>
          )}
        </View>
        {renderBookingCards()}
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },

  loadingContainer: { 
    flex: 1, 
    justifyContent: 'center', 
    alignItems: 'center', 
    gap: 12, 
    paddingHorizontal: 24 
  },
  loadingText: { 
    fontFamily: 'Rubik_500Medium',
    color: SKY, 
    fontSize: 14,
    letterSpacing: 0,
  },

  scrollView: { flex: 1 },
  scrollContent: { padding: 20, paddingBottom: 40 },

  filtersSection: {
    marginBottom: 24,
    paddingVertical: 8,
  },
  filtersContainer: {
    flexGrow: 0,
  },
  filtersContent: {
    gap: 12,
    paddingRight: 20,
    paddingLeft: 0,
    paddingVertical: 4,
  },
  filterButton: {
    marginRight: 0,
  },
  filterChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.2)',
    minHeight: 40,
    position: 'relative',
    shadowColor: 'transparent',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0,
    shadowRadius: 4,
    elevation: 2,
  },
  filterChipActive: {
    borderWidth: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.12,
    shadowRadius: 6,
    elevation: 4,
  },
  filterIconContainer: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  filterText: {
    fontFamily: 'Rubik_600SemiBold',
    fontSize: 13,
    letterSpacing: -0.1,
    lineHeight: 18,
  },
  filterTextActive: {
    fontFamily: 'Rubik_700Bold',
  },
  activeIndicator: {
    position: 'absolute',
    bottom: 0,
    left: '50%',
    marginLeft: -16,
    width: 32,
    height: 2.5,
    borderRadius: 2,
  },

  emptyContainer: { 
    flex: 1, 
    justifyContent: 'center', 
    minHeight: 300, 
    marginTop: 8 
  },
  emptyCard: { 
    padding: 48,
    borderRadius: 24,
  },
  emptyContent: { 
    alignItems: 'center',
    gap: 8,
  },
  emptyTitle: { 
    fontFamily: 'Rubik_600SemiBold',
    color: '#F9FAFB', 
    fontSize: 20, 
    marginTop: 20, 
    marginBottom: 8,
    letterSpacing: -0.2,
  },
  emptyText: { 
    fontFamily: 'Rubik_400Regular',
    color: 'rgba(249,250,251,0.7)', 
    fontSize: 14, 
    textAlign: 'center', 
    lineHeight: 22,
    letterSpacing: 0,
  },

  bookingsList: { 
    gap: 16,
  },
  bookingCard: { 
    padding: 14,
    borderRadius: 16,
    marginBottom: 4,
  },

  bookingHeader: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    alignItems: 'flex-start', 
    marginBottom: 12,
  },
  bookingInfo: { 
    flex: 1,
    gap: 6,
  },
  headerRight: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 12,
  },
  deleteButton: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: 'rgba(239,68,68,0.85)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(220,38,38,0.6)',
  },
  deleteButtonInner: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(220,38,38,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  customerName: { 
    fontFamily: 'Rubik_600SemiBold',
    color: '#F9FAFB', 
    fontSize: 17, 
    marginBottom: 2,
    letterSpacing: -0.2,
    lineHeight: 22,
  },
  serviceType: { 
    fontFamily: 'Rubik_500Medium',
    color: 'rgba(249,250,251,0.75)', 
    fontSize: 13,
    letterSpacing: 0,
  },

  bookingDetails: { 
    gap: 8, 
    marginBottom: 12,
    paddingVertical: 10,
    borderTopWidth: 1,
    borderBottomWidth: 1,
    borderColor: 'rgba(135,206,235,0.1)',
  },
  detailRow: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 10,
  },
  detailText: { 
    fontFamily: 'Rubik_400Regular',
    color: 'rgba(249,250,251,0.8)', 
    fontSize: 14, 
    flex: 1,
    letterSpacing: 0,
    lineHeight: 20,
  },

  bookingActions: { 
    paddingTop: 0,
  },
  actionButton: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 4,
  },
  actionText: { 
    fontFamily: 'Rubik_600SemiBold',
    color: SKY, 
    fontSize: 15,
    letterSpacing: 0.1,
  },
  deleteAllContainer: {
    alignItems: 'flex-end',
    marginBottom: 16,
  },
  deleteAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 18,
    backgroundColor: 'rgba(239,68,68,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(220,38,38,0.6)',
  },
  deleteAllIconWrapper: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(220,38,38,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  deleteAllText: { 
    fontFamily: 'Rubik_600SemiBold',
    color: '#FFFFFF', 
    fontSize: 14,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  mapContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: '50%',
    zIndex: 0,
  },
  map: {
    flex: 1,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  marker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: businessTheme.primary,
    borderWidth: 3,
    borderColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    backgroundColor: 'transparent',
    elevation: 10,
  },
  content: {
    flex: 1,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  refreshButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  headerIndicatorContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
    paddingBottom: 12,
  },
  headerIndicatorDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  headerIndicatorDotActive: {
    width: 24,
    backgroundColor: SKY,
  },
  mapContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  mapLoadingContainer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  mapLoadingText: {
    color: SKY,
    fontSize: 14,
    marginTop: 12,
  },
  mapMarkerPin: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  mapMarkerPinSelected: {
    transform: [{ scale: 1.15 }],
  },
  carMarkerImage: {
    width: 40,
    height: 40,
  },
  bookingCardContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
  scrollContent: {
    paddingHorizontal: 20,
  },
  bookingCardScrollItem: {
    width: width - 40,
    marginRight: 20,
  },
  bookingCardWrapper: {
    width: '100%',
    overflow: 'visible',
  },
  bookingCardBlur: {
    padding: 20,
    paddingBottom: 24,
    minHeight: 200,
    borderRadius: 20,
    overflow: 'visible',
    borderWidth: 1,
    backgroundColor: 'transparent',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
  },
  jobCardBackground: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: 20,
  },
  jobCardBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
    pointerEvents: 'none',
  },
  bookingCardHeader: {
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  bookingCardHeaderContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  servicePreviewIcon: {
    width: 28,
    height: 28,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    overflow: 'hidden',
  },
  customerProfileImage: {
    width: 28,
    height: 28,
    borderRadius: 8,
  },
  bookingCardHeaderText: {
    flex: 1,
  },
  bookingCardTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    flex: 1,
  },
  bookingCardService: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 14,
    marginTop: 4,
  },
  bookingCardHeaderRight: {
    alignItems: 'flex-end',
  },
  bookingCardDetails: {
    gap: 8,
    marginBottom: 16,
  },
  bookingDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  bookingDetailText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
  },
  urgentText: {
    color: '#F59E0B',
    fontWeight: '600',
  },
  bookingCardActions: {
    width: '100%',
    marginTop: 16,
  },
  viewButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
  },
  viewButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
  },
  viewButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  liveBookingCard: {
    marginTop: 16,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(16,185,129,0.3)',
    position: 'relative',
  },
  liveBookingCardBackground: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderRadius: 16,
  },
  liveBookingCardBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 16,
    borderWidth: 1.5,
    borderColor: 'rgba(16,185,129,0.3)',
    pointerEvents: 'none',
  },
  liveBookingCardContent: {
    padding: 16,
    zIndex: 1,
  },
  liveBookingCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  liveIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.4)',
  },
  liveIndicatorDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  liveIndicatorText: {
    color: '#10B981',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  liveBookingCardTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 12,
  },
  liveDistanceContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.1)',
  },
  liveDistanceText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  liveTrackingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
  },
  liveTrackingText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '500',
  },
  cardsLoadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyCard: {
    padding: 40,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
  },
  businessLocationMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  businessLocationPin: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: businessTheme.primary,
    borderWidth: 3,
    borderColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  enRouteMarker: {
    borderWidth: 3,
    borderColor: '#10B981',
  },
  enRouteText: {
    color: '#10B981',
    fontSize: 14,
    fontWeight: '600',
  },
  vehicleInfoContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  vehicleRegistration: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 1,
    fontFamily: 'monospace',
  },
});
