import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Linking,
  Alert,
  Dimensions,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

const WHATSAPP_NUMBER = '+447960944743';
const EMAIL = 'info@wishawashapp.com';

const faqs = [
  {
    id: 'getting-started',
    question: 'How do I get started as a business?',
    answer: 'Once you\'ve created your business account, you can start by adding your locations, configuring your services, and setting up your team. Visit the Settings page to manage your business profile and locations.',
  },
  {
    id: 'locations',
    question: 'How do I add or manage locations?',
    answer: 'Go to Settings > Manage Locations to add new locations or edit existing ones. You can set the address, coordinates, and status for each location.',
  },
  {
    id: 'team',
    question: 'How do I manage my team?',
    answer: 'Navigate to Settings > Team Management to invite valeters, view team requests, and manage your team members. You can approve or reject team requests from there.',
  },
  {
    id: 'bookings',
    question: 'How do I view and manage bookings?',
    answer: 'Go to the Bookings page from your dashboard to see all active, completed, and cancelled bookings. You can filter by status and view detailed information for each booking.',
  },
  {
    id: 'earnings',
    question: 'How do I view my earnings?',
    answer: 'Visit Settings > Earnings & Payouts to see your revenue, payout history, and payment information. You can track your earnings by day, week, or month.',
  },
  {
    id: 'issues',
    question: 'What if I have a problem or issue?',
    answer: 'You can report issues from Settings > Reports & Issues. For urgent matters, contact us directly via WhatsApp or email.',
  },
];

export default function BusinessHelp() {
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const [expandedFaq, setExpandedFaq] = useState<string | null>(null);

  React.useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();
  }, []);

  const handleWhatsApp = async () => {
    await hapticFeedback('light');
    const url = `https://wa.me/${WHATSAPP_NUMBER.replace(/[^0-9]/g, '')}`;
    try {
      const canOpen = await Linking.canOpenURL(url);
      if (canOpen) {
        await Linking.openURL(url);
      } else {
        Alert.alert('Error', 'WhatsApp is not installed on this device.');
      }
    } catch (error) {
      console.error('Error opening WhatsApp:', error);
    }
  };

  const handleEmail = async () => {
    await hapticFeedback('light');
    const url = `mailto:${EMAIL}?subject=Business Support Request`;
    try {
      await Linking.openURL(url);
    } catch (error) {
      console.error('Error opening email:', error);
    }
  };

  const toggleFaq = async (id: string) => {
    await hapticFeedback('light');
    setExpandedFaq(expandedFaq === id ? null : id);
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <SafeAreaView style={styles.container} edges={['top']}>
        <AppHeader
          title="Help & Support"
          scrollY={scrollY}
          enableScrollAnimation={true}
          accountType="business"
          onBack={() => router.back()}
        />

        <Animated.ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
            useNativeDriver: false,
          })}
          scrollEventThrottle={16}
          contentContainerStyle={[
            styles.scrollContent,
            {
              paddingTop: HEADER_CONTENT_OFFSET,
              paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
            },
          ]}
        >
          {/* Contact Section */}
          <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
            <Text style={styles.sectionTitle}>Get in Touch</Text>
            <Text style={styles.sectionDescription}>
              Need help? Contact our support team via email or WhatsApp.
            </Text>

            <View style={styles.contactContainer}>
              <TouchableOpacity
                onPress={handleEmail}
                activeOpacity={0.9}
                style={styles.contactCardWrapper}
              >
                <GlassCard style={styles.contactCard} accountType="business" borderColor={`${SKY}40`}>
                  <View style={styles.contactContent}>
                    <View style={[styles.contactIconWrapper, { backgroundColor: `${SKY}25` }]}>
                      <Ionicons name="mail" size={24} color={SKY} />
                    </View>
                    <View style={styles.contactTextContainer}>
                      <Text style={styles.contactLabel}>Email Support</Text>
                      <Text style={styles.contactValue}>{EMAIL}</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color={SKY} />
                  </View>
                </GlassCard>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={handleWhatsApp}
                activeOpacity={0.9}
                style={styles.contactCardWrapper}
              >
                <GlassCard style={styles.contactCard} accountType="business" borderColor="rgba(37,211,102,0.4)">
                  <View style={styles.contactContent}>
                    <View style={[styles.contactIconWrapper, { backgroundColor: 'rgba(37,211,102,0.25)' }]}>
                      <Ionicons name="logo-whatsapp" size={24} color="#25D366" />
                    </View>
                    <View style={styles.contactTextContainer}>
                      <Text style={styles.contactLabel}>WhatsApp Support</Text>
                      <Text style={styles.contactValue}>{WHATSAPP_NUMBER}</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color="#25D366" />
                  </View>
                </GlassCard>
              </TouchableOpacity>
            </View>
          </Animated.View>

          {/* FAQs Section */}
          <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
            <Text style={styles.sectionTitle}>Frequently Asked Questions</Text>
            <Text style={styles.sectionDescription}>
              Find answers to common questions about using Wish a Wash.
            </Text>

            <View style={styles.faqContainer}>
              {faqs.map((faq, index) => {
                const isExpanded = expandedFaq === faq.id;
                return (
                  <TouchableOpacity
                    key={faq.id}
                    onPress={() => toggleFaq(faq.id)}
                    activeOpacity={0.9}
                    style={styles.faqCardWrapper}
                  >
                    <GlassCard style={styles.faqCard} accountType="business" borderColor={`${SKY}30`}>
                      <View style={styles.faqHeader}>
                        <Text style={styles.faqQuestion}>{faq.question}</Text>
                        <Ionicons
                          name={isExpanded ? 'chevron-up' : 'chevron-down'}
                          size={20}
                          color={SKY}
                        />
                      </View>
                      {isExpanded && (
                        <View style={styles.faqAnswerContainer}>
                          <Text style={styles.faqAnswer}>{faq.answer}</Text>
                        </View>
                      )}
                    </GlassCard>
                  </TouchableOpacity>
                );
              })}
            </View>
          </Animated.View>

          <View style={{ height: 22 }} />
        </Animated.ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 8,
    letterSpacing: 0.2,
  },
  sectionDescription: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    marginBottom: 20,
    lineHeight: 20,
  },
  contactContainer: {
    gap: 12,
  },
  contactCardWrapper: {
    marginBottom: 0,
  },
  contactCard: {
    padding: 16,
  },
  contactContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  contactIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  contactTextContainer: {
    flex: 1,
  },
  contactLabel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  contactValue: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 13,
  },
  faqContainer: {
    gap: 12,
  },
  faqCardWrapper: {
    marginBottom: 0,
  },
  faqCard: {
    padding: 16,
  },
  faqHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  faqQuestion: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '600',
    lineHeight: 22,
  },
  faqAnswerContainer: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  faqAnswer: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 14,
    lineHeight: 20,
  },
});
