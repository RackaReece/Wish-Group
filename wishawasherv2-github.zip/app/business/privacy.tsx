import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Switch,
  ActivityIndicator,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const businessTheme = getAccountTheme('business');

interface PrivacySetting {
  id: string;
  label: string;
  description: string;
  enabled: boolean;
  category: 'data' | 'visibility' | 'security';
}

export default function BusinessPrivacy() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [settings, setSettings] = useState<PrivacySetting[]>([]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadSettings();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadSettings = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      // Load privacy settings from database
      const defaultSettings: PrivacySetting[] = [
        {
          id: 'profile_visibility',
          label: 'Public Profile',
          description: 'Allow your business profile to be visible to customers',
          enabled: true,
          category: 'visibility',
        },
        {
          id: 'location_sharing',
          label: 'Location Sharing',
          description: 'Share your business locations with customers',
          enabled: true,
          category: 'visibility',
        },
        {
          id: 'analytics_sharing',
          label: 'Analytics Data',
          description: 'Share anonymised analytics data to improve services',
          enabled: true,
          category: 'data',
        },
        {
          id: 'marketing_emails',
          label: 'Marketing Communications',
          description: 'Receive marketing emails and promotional offers',
          enabled: false,
          category: 'data',
        },
        {
          id: 'two_factor',
          label: 'Two-Factor Authentication',
          description: 'Add an extra layer of security to your account',
          enabled: false,
          category: 'security',
        },
        {
          id: 'session_timeout',
          label: 'Auto Logout',
          description: 'Automatically log out after period of inactivity',
          enabled: true,
          category: 'security',
        },
      ];
      setSettings(defaultSettings);
    } catch (error) {
      console.error('Error loading privacy settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleSetting = async (settingId: string) => {
    if (!user?.id) return;
    try {
      await hapticFeedback('light');
      setSettings(prev =>
        prev.map(s => (s.id === settingId ? { ...s, enabled: !s.enabled } : s))
      );

      // Save to database
      // await supabase.from('business_privacy_settings').upsert({...});
    } catch (error) {
      console.error('Error toggling setting:', error);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'data':
        return 'shield';
      case 'visibility':
        return 'eye';
      case 'security':
        return 'lock-closed';
      default:
        return 'settings';
    }
  };

  const groupedSettings = settings.reduce((acc, setting) => {
    if (!acc[setting.category]) {
      acc[setting.category] = [];
    }
    acc[setting.category].push(setting);
    return acc;
  }, {} as Record<string, PrivacySetting[]>);

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Privacy Settings" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#87CEEB" />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Privacy Settings"
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[
          styles.scrollContent, 
          { 
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          }
        ]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Privacy & Security</Text>
          <Text style={styles.sectionSubtitle}>
            Control how your business information is shared and protected
          </Text>

          {Object.entries(groupedSettings).map(([category, categorySettings]) => (
            <View key={category} style={styles.categorySection}>
              <View style={styles.categoryHeader}>
                <Ionicons
                  name={getCategoryIcon(category) as any}
                  size={18}
                  color="#87CEEB"
                />
                <Text style={styles.categoryTitle}>
                  {category.charAt(0).toUpperCase() + category.slice(1)}
                </Text>
              </View>

              <View style={styles.settingsList}>
                {categorySettings.map((setting) => (
                  <GlassCard key={setting.id} style={styles.settingCard} accountType="business">
                    <View style={styles.settingContent}>
                      <View style={styles.settingInfo}>
                        <Text style={styles.settingLabel}>{setting.label}</Text>
                        <Text style={styles.settingDescription}>{setting.description}</Text>
                      </View>
                      <Switch
                        value={setting.enabled}
                        onValueChange={() => toggleSetting(setting.id)}
                        trackColor={{ false: 'rgba(255,255,255,0.1)', true: '#87CEEB' }}
                        thumbColor={setting.enabled ? '#FFFFFF' : '#6B7280'}
                        ios_backgroundColor="rgba(255,255,255,0.1)"
                      />
                    </View>
                  </GlassCard>
                ))}
              </View>
            </View>
          ))}

          <GlassCard style={styles.infoCard} accountType="business">
            <View style={styles.infoContent}>
              <Ionicons name="information-circle" size={20} color="#87CEEB" />
              <Text style={styles.infoText}>
                Your privacy is important to us. We never share your personal information with third parties without your consent.
              </Text>
            </View>
          </GlassCard>
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: '#87CEEB',
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: isSmallScreen ? 16 : 20,
  },
  content: {
    gap: SPACING.xl,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 12,
  },
  sectionSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    marginBottom: SPACING.lg,
  },
  categorySection: {
    gap: SPACING.md,
  },
  categoryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    marginBottom: SPACING.xs,
  },
  categoryTitle: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '700',
  },
  settingsList: {
    gap: SPACING.sm,
  },
  settingCard: {
    ...CARD_SIZES.small,
  },
  settingContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: CARD_SIZES.small.padding,
  },
  settingInfo: {
    flex: 1,
    gap: 2,
    marginRight: SPACING.md,
  },
  settingLabel: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '600',
  },
  settingDescription: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    lineHeight: 16,
    marginTop: 2,
  },
  infoCard: {
    ...CARD_SIZES.medium,
    marginTop: SPACING.md,
  },
  infoContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: SPACING.md,
    padding: CARD_SIZES.medium.padding,
  },
  infoText: {
    flex: 1,
    color: 'rgba(249,250,251,0.9)',
    fontSize: 13,
    lineHeight: 18,
  },
});

