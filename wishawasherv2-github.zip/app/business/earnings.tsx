import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING, getMetricCardWidth } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

// Format currency in UK format
const formatCurrency = (amount: number): string => {
  return new Intl.NumberFormat('en-GB', {
    style: 'currency',
    currency: 'GBP',
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
};

interface EarningsSummary {
  totalEarnings: number;
  thisMonth: number;
  lastMonth: number;
  pendingPayouts: number;
  nextPayoutDate?: string;
}

export default function BusinessEarnings() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [earnings, setEarnings] = useState<EarningsSummary>({
    totalEarnings: 0,
    thisMonth: 0,
    lastMonth: 0,
    pendingPayouts: 0,
  });

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadEarnings();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadEarnings = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      // Load earnings data from database
      // This would query your earnings/payouts table
      setEarnings({
        totalEarnings: 12500,
        thisMonth: 3200,
        lastMonth: 2800,
        pendingPayouts: 1200,
        nextPayoutDate: '2026-01-31',
      });
    } catch (error) {
      console.error('Error loading earnings:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Earnings & Payouts" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Earnings & Payouts"
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          },
        ]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          {/* Summary Cards - Horizontal Scroll */}
          <View style={styles.summarySection}>
            <View style={styles.sectionHeader}>
              <Ionicons name="stats-chart" size={18} color={businessTheme.primary} />
              <Text style={styles.sectionHeaderTitle}>Earnings Overview</Text>
            </View>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.summaryScrollContent}
            >
              <Animated.View
                style={[
                  { opacity: fadeAnim },
                  {
                    transform: [
                      {
                        translateX: fadeAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [20, 0],
                        }),
                      },
                    ],
                  },
                ]}
              >
                <GlassCard style={styles.summaryCard} accountType="business">
                  <LinearGradient
                    colors={['rgba(96,217,255,0.20)', 'rgba(59,197,232,0.12)', 'rgba(0,0,0,0.05)']}
                    style={styles.summaryGradient}
                  >
                    <View style={styles.summaryIconWrapper}>
                      <LinearGradient
                        colors={['rgba(96,217,255,0.35)', 'rgba(59,197,232,0.25)']}
                        style={styles.summaryIconGradient}
                      >
                        <Ionicons name="wallet-outline" size={26} color="#60D9FF" />
                      </LinearGradient>
                    </View>
                    <View style={styles.summaryTextContainer}>
                      <Text style={styles.summaryValue}>{formatCurrency(earnings.totalEarnings)}</Text>
                      <Text style={styles.summaryLabel}>Total Earnings</Text>
                    </View>
                  </LinearGradient>
                </GlassCard>
              </Animated.View>

              <Animated.View
                style={[
                  { opacity: fadeAnim },
                  {
                    transform: [
                      {
                        translateX: fadeAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [20, 0],
                        }),
                      },
                    ],
                  },
                ]}
              >
                <GlassCard style={styles.summaryCard} accountType="business">
                  <LinearGradient
                    colors={['rgba(16,185,129,0.20)', 'rgba(5,150,105,0.12)', 'rgba(0,0,0,0.05)']}
                    style={styles.summaryGradient}
                  >
                    <View style={[styles.summaryIconWrapper, styles.summaryIconWrapperGreen]}>
                      <LinearGradient
                        colors={['rgba(16,185,129,0.35)', 'rgba(5,150,105,0.25)']}
                        style={styles.summaryIconGradient}
                      >
                        <Ionicons name="calendar" size={26} color="#10B981" />
                      </LinearGradient>
                    </View>
                    <View style={styles.summaryTextContainer}>
                      <Text style={styles.summaryValue}>{formatCurrency(earnings.thisMonth)}</Text>
                      <Text style={styles.summaryLabel}>This Month</Text>
                    </View>
                  </LinearGradient>
                </GlassCard>
              </Animated.View>

              <Animated.View
                style={[
                  { opacity: fadeAnim },
                  {
                    transform: [
                      {
                        translateX: fadeAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [20, 0],
                        }),
                      },
                    ],
                  },
                ]}
              >
                <GlassCard style={styles.summaryCard} accountType="business">
                  <LinearGradient
                    colors={['rgba(251,191,36,0.20)', 'rgba(245,158,11,0.12)', 'rgba(0,0,0,0.05)']}
                    style={styles.summaryGradient}
                  >
                    <View style={[styles.summaryIconWrapper, styles.summaryIconWrapperYellow]}>
                      <LinearGradient
                        colors={['rgba(251,191,36,0.35)', 'rgba(245,158,11,0.25)']}
                        style={styles.summaryIconGradient}
                      >
                        <Ionicons name="time" size={26} color="#FBBF24" />
                      </LinearGradient>
                    </View>
                    <View style={styles.summaryTextContainer}>
                      <Text style={styles.summaryValue}>{formatCurrency(earnings.pendingPayouts)}</Text>
                      <Text style={styles.summaryLabel}>Pending Payouts</Text>
                    </View>
                  </LinearGradient>
                </GlassCard>
              </Animated.View>
            </ScrollView>
          </View>

          {/* Payout Information - Redesigned */}
          <GlassCard style={styles.infoCard} accountType="business">
            <LinearGradient
              colors={[`${businessTheme.primary}33`, `${businessTheme.primaryAlt}1F`, 'rgba(0,0,0,0.05)']}
              style={styles.infoGradient}
            >
              <View style={styles.infoIconWrapper}>
                <LinearGradient
                  colors={[`${businessTheme.primary}59`, `${businessTheme.primaryAlt}40`]}
                  style={styles.infoIconGradient}
                >
                  <Ionicons name="wallet-outline" size={28} color={businessTheme.primary} />
                </LinearGradient>
              </View>
              <View style={styles.infoTextWrapper}>
                <Text style={styles.infoTitle}>Next Payout</Text>
                {earnings.nextPayoutDate ? (
                  <>
                    <Text style={styles.infoValue}>
                      {new Date(earnings.nextPayoutDate).toLocaleDateString('en-GB', {
                        day: 'numeric',
                        month: 'long',
                        year: 'numeric',
                      })}
                    </Text>
                    <Text style={styles.infoSubtext}>
                      Payouts are processed monthly on the last day
                    </Text>
                  </>
                ) : (
                  <Text style={styles.infoText}>No scheduled payout</Text>
                )}
              </View>
            </LinearGradient>
          </GlassCard>

          {/* Payout History */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Payout History</Text>
            <GlassCard style={styles.emptyCard} accountType="business">
              <View style={styles.emptyContent}>
                <Ionicons name="receipt-outline" size={40} color={SKY} style={{ opacity: 0.6 }} />
                <Text style={styles.emptyTitle}>No payout history yet</Text>
                <Text style={styles.emptyText}>
                  Your payout history will appear here after your first payment
                </Text>
              </View>
            </GlassCard>
          </View>
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: isSmallScreen ? 16 : 20,
  },
  content: {
    gap: SPACING.xl,
  },
  summarySection: {
    marginBottom: 24,
    gap: 12,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 4,
  },
  sectionHeaderTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  summaryScrollContent: {
    gap: 14,
    paddingRight: 20,
    paddingLeft: 4,
  },
  summaryCard: {
    width: Math.min(width * 0.75, 280),
    padding: 0,
    overflow: 'hidden',
    borderRadius: 22,
    marginRight: 14,
  },
  summaryGradient: {
    padding: 18,
    minHeight: 130,
    justifyContent: 'space-between',
  },
  summaryIconWrapper: {
    width: 52,
    height: 52,
    borderRadius: 14,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
    borderWidth: 1,
    borderColor: 'rgba(96,217,255,0.3)',
  },
  summaryIconWrapperGreen: {
    borderColor: 'rgba(16,185,129,0.3)',
  },
  summaryIconWrapperYellow: {
    borderColor: 'rgba(251,191,36,0.3)',
  },
  summaryIconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  summaryTextContainer: {
    gap: 6,
  },
  summaryValue: {
    color: '#F9FAFB',
    fontSize: 28,
    fontWeight: '900',
    letterSpacing: -0.5,
    lineHeight: 32,
  },
  summaryLabel: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  infoCard: {
    ...CARD_SIZES.medium,
    padding: 0,
    overflow: 'hidden',
    borderRadius: 20,
  },
  infoGradient: {
    padding: 20,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 16,
    minHeight: 120,
  },
  infoIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 16,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: `${businessTheme.primary}4D`,
    flexShrink: 0,
  },
  infoIconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoTextWrapper: {
    flex: 1,
    gap: 8,
  },
  infoTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.3,
    marginBottom: 4,
  },
  infoValue: {
    color: businessTheme.primary,
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  infoSubtext: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    lineHeight: 18,
    marginTop: 2,
  },
  infoText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    lineHeight: 20,
  },
  section: {
    gap: SPACING.md,
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 12,
  },
  emptyCard: {
    ...CARD_SIZES.large,
  },
  emptyContent: {
    alignItems: 'center',
    padding: CARD_SIZES.large.padding,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
});

