import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Alert,
  RefreshControl,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { DASHBOARD_HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import BusinessNotificationDropdown from '../../src/components/shared/BusinessNotificationDropdown';
import GradientNotificationBell from '../../src/components/shared/GradientNotificationBell';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

interface Location {
  id: string;
  name: string;
  address: string | null;
  is_active?: boolean | null;
  status?: string | null;
}

interface LiveBooking {
  id: string;
  time: string;
  service: string;
  price: number;
  status: string;
  customerName?: string;
  vehicle_registration?: string | null;
  vehicle_make?: string | null;
  vehicle_model?: string | null;
  vehicle_type?: string | null;
  location_address?: string | null;
}

type BookingStatus =
  | 'pending_valeter_acceptance'
  | 'confirmed'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

const clamp = (v: number, min: number, max: number) => Math.max(min, Math.min(max, v));

// Animated counter component
const AnimatedCounter = ({ value, style }: { value: number; style?: any }) => {
  const [displayValue, setDisplayValue] = useState(0);
  const animValue = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(animValue, {
      toValue: value,
      duration: 800,
      useNativeDriver: false,
    }).start();

    const listener = animValue.addListener(({ value: v }) => {
      setDisplayValue(Math.round(v));
    });

    return () => animValue.removeListener(listener);
  }, [value]);

  return <Text style={style}>{displayValue}</Text>;
};

export default function BusinessDashboard() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const livePulseAnim = useRef(new Animated.Value(1)).current;
  const shimmerAnim = useRef(new Animated.Value(0)).current;

  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [businessName, setBusinessName] = useState<string>('');
  const [businessAddress, setBusinessAddress] = useState<string>('');
  const [notificationCount, setNotificationCount] = useState<number>(0);
  const [showNotificationDropdown, setShowNotificationDropdown] = useState(false);
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [isOnline] = useState(true); // Online/Offline status
  const [liveBookings, setLiveBookings] = useState<LiveBooking[]>([]);
  const [lastJob, setLastJob] = useState<{ time: string; service: string } | null>(null);
  const [nextBooking, setNextBooking] = useState<{ time: string; service: string } | null>(null);
  const [lastWeekBookings, setLastWeekBookings] = useState(0);

  const [stats, setStats] = useState({
    totalLocations: 0,
    activeBookings: 0,
    valetersOnline: 0,
    todayRevenue: 0,
    todayJobs: 0,
    totalRevenue: 0,
    completionRate: 0,
    averageRating: 0,
    bookingsThisWeek: 0,
  });

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    // Pulsing animation for live indicator
    const pulseAnimation = Animated.loop(
      Animated.sequence([
        Animated.timing(livePulseAnim, {
          toValue: 1.3,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(livePulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    );
    pulseAnimation.start();

    // Shimmer animation
    const shimmerAnimation = Animated.loop(
      Animated.sequence([
        Animated.timing(shimmerAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(shimmerAnim, {
          toValue: 0,
          duration: 2000,
          useNativeDriver: true,
        }),
      ])
    );
    shimmerAnimation.start();

    if (isOrgUser && organizationId) {
      loadData();
      fetchNotificationCount();

      const interval = setInterval(() => {
        fetchNotificationCount();
        loadTodayData();
      }, 120000); // Update every 2 minutes
      return () => clearInterval(interval);
    } else {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [organizationId, isOrgUser]);

  const loadData = async () => {
    if (!organizationId) return;

    try {
      setLoading(true);

      // Phase 1: Load critical data first
      const [locs, orgData] = await Promise.all([
        loadLocations(),
        loadOrganizationData(),
        loadProfilePicture(),
      ]);

      if (orgData) {
        setBusinessName(orgData.name || '');
        setBusinessAddress(orgData.address || '');
      }

      setStats(prev => ({
        ...prev,
        totalLocations: locs.length,
      }));

      // Phase 2: Load non-critical data in background
      Promise.all([
        calculateBusinessRating(),
        loadBookingMetrics(),
        loadTeamCount(),
        loadTodayData(),
        loadLiveBookings(),
        loadLastJob(),
        loadNextBooking(),
        loadLastWeekBookings(),
      ]).then(([rating, bookingMetrics, teamCount, todayData, bookings, lastJobData, nextBookingData, lastWeek]) => {
        setStats(prev => ({
          ...prev,
          activeBookings: bookingMetrics.activeBookings,
          valetersOnline: teamCount,
          completionRate: bookingMetrics.completionRate,
          averageRating: rating,
          bookingsThisWeek: bookingMetrics.bookingsThisWeek,
          todayRevenue: todayData.revenue,
          todayJobs: todayData.jobs,
        }));
        setLiveBookings(bookings);
        setLastJob(lastJobData);
        setNextBooking(nextBookingData);
        setLastWeekBookings(lastWeek);
      }).catch((error) => {
        console.error('Error loading secondary data:', error);
      });
    } catch (error: any) {
      console.error('Error loading business data:', error);
      Alert.alert('Error', error?.message || 'Failed to load dashboard');
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    if (!organizationId) return;
    setRefreshing(true);
    await hapticFeedback('light');
    try {
      await Promise.all([
        loadData(),
        fetchNotificationCount(),
      ]);
    } catch (error) {
      console.error('Error refreshing dashboard:', error);
    } finally {
      setRefreshing(false);
    }
  };

  const loadLocations = async (): Promise<Location[]> => {
    if (!organizationId) return [];
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, is_active, status')
        .eq('organization_id', organizationId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      const list = (data || []) as Location[];
      setLocations(list);
      return list;
    } catch (error) {
      console.error('Error loading locations:', error);
      return [];
    }
  };

  const loadOrganizationData = async () => {
    if (!organizationId) return null;
    try {
      const { data, error } = await supabase
        .from('organizations')
        .select('name, address')
        .eq('id', organizationId)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        console.error('Error loading organization data:', error);
        return null;
      }
      return data;
    } catch (error) {
      console.error('Error loading organization data:', error);
      return null;
    }
  };

  const loadProfilePicture = async () => {
    if (!organizationId) return;
    try {
      // Try to get logo/profile picture - query only columns that might exist
      const { data, error } = await supabase
        .from('organizations')
        .select('logo, profile_picture')
        .eq('id', organizationId)
        .maybeSingle();

      if (error) {
        // Silently fail if columns don't exist - this is expected
        if (error.code === '42703') {
          // Column doesn't exist - ignore
          return;
        }
        // For other errors, also silently fail
        return;
      }

      if (data) {
        // Try multiple possible column names for logo
        const logoUrl = (data.logo ?? data.profile_picture ?? '') as string;
        if (logoUrl) {
          setProfilePicture(logoUrl);
        }
      }
    } catch (error) {
      // Silently fail - profile picture is optional
      console.debug('Profile picture load failed:', error);
    }
  };

  const getValeterIds = async (): Promise<string[]> => {
    if (!organizationId) return [];
    try {
      const { data: valeters, error: valErr } = await supabase
        .from('profiles')
        .select('id')
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      if (valErr) throw valErr;
      return (valeters || []).map((v: any) => v.id) as string[];
    } catch (error) {
      console.error('Error loading valeter IDs:', error);
      return [];
    }
  };

  const loadTodayData = async () => {
    if (!organizationId) return { revenue: 0, jobs: 0 };
    try {
      const valeterIds = await getValeterIds();
      if (valeterIds.length === 0) return { revenue: 0, jobs: 0 };

      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('id, price, status, scheduled_at')
        .in('valeter_id', valeterIds)
        .gte('scheduled_at', today.toISOString())
        .lt('scheduled_at', tomorrow.toISOString());

      if (error) throw error;

      const completed = (bookings || []).filter((b: any) => b.status === 'completed');
      const revenue = completed.reduce((sum: number, b: any) => {
        const price = Number(b.price || 0);
        return sum + (Number.isFinite(price) ? price : 0);
      }, 0);

      return { revenue: Math.round(revenue), jobs: completed.length };
    } catch (error) {
      console.error('Error loading today data:', error);
      return { revenue: 0, jobs: 0 };
    }
  };

  const loadLiveBookings = async (): Promise<LiveBooking[]> => {
    if (!organizationId) return [];
    try {
      // First, get active locations
      const { data: locations, error: locErr } = await supabase
        .from('car_wash_locations')
        .select('address, is_active, status')
        .eq('organization_id', organizationId);

      if (locErr) throw locErr;
      
      // Only get active locations
      const activeLocations = (locations || []).filter(
        (l: any) => l.is_active !== false && l.status !== 'inactive'
      );
      
      const locationAddresses = activeLocations
        .map((l: any) => (typeof l.address === 'string' ? l.address.trim() : ''))
        .filter((a: string) => a.length > 0);

      if (locationAddresses.length === 0) return [];

      const valeterIds = await getValeterIds();
      if (valeterIds.length === 0) return [];

      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('id, scheduled_at, service_type, price, status, user_id, location_address, vehicle_type, vehicle_info')
        .in('valeter_id', valeterIds)
        .in('location_address', locationAddresses)
        .in('status', ['confirmed', 'in_progress', 'pending_valeter_acceptance', 'en_route', 'arrived'])
        .order('scheduled_at', { ascending: true })
        .limit(10);

      if (error) throw error;

      // Fetch customer names
      const customerIds = Array.from(new Set((bookings || []).map((b: any) => b.user_id).filter(Boolean))) as string[];
      const customerMap = new Map<string, string>();
      
      if (customerIds.length > 0) {
        try {
          const { data: profiles } = await supabase
            .from('profiles')
            .select('id, full_name, name')
            .in('id', customerIds);

          (profiles || []).forEach((p: any) => {
            customerMap.set(p.id, (p.full_name || p.name || 'Customer') as string);
          });
        } catch (err) {
          console.warn('Error fetching customer names:', err);
        }
      }

      // Fetch vehicle information
      const vehicleMap = new Map<string, { registration?: string; make?: string; model?: string; type?: string }>();
      if (customerIds.length > 0) {
        try {
          const { data: vehicles } = await supabase
            .from('customer_vehicles')
            .select('user_id, registration, make, model, type')
            .in('user_id', customerIds)
            .eq('is_default', true);

          (vehicles || []).forEach((v: any) => {
            vehicleMap.set(v.user_id, {
              registration: v.registration || undefined,
              make: v.make || undefined,
              model: v.model || undefined,
              type: v.type || undefined,
            });
          });
        } catch (err) {
          console.warn('Error fetching vehicle info:', err);
        }
      }

      return (bookings || []).map((b: any) => {
        const date = new Date(b.scheduled_at);
        const timeStr = date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
        const vehicleData = b.user_id ? vehicleMap.get(b.user_id) : null;
        
        return {
          id: b.id,
          time: timeStr,
          service: b.service_type || 'Car wash',
          price: Number(b.price || 0),
          status: b.status,
          customerName: b.user_id ? (customerMap.get(b.user_id) || 'Customer') : 'Customer',
          vehicle_registration: vehicleData?.registration || null,
          vehicle_make: vehicleData?.make || null,
          vehicle_model: vehicleData?.model || null,
          vehicle_type: b.vehicle_type || vehicleData?.type || null,
          location_address: b.location_address || null,
        };
      });
    } catch (error) {
      console.error('Error loading live bookings:', error);
      return [];
    }
  };

  const loadLastJob = async (): Promise<{ time: string; service: string } | null> => {
    if (!organizationId) return null;
    try {
      const valeterIds = await getValeterIds();
      if (valeterIds.length === 0) return null;

      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('completed_at, service_type')
        .in('valeter_id', valeterIds)
        .eq('status', 'completed')
        .not('completed_at', 'is', null)
        .order('completed_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;
      if (!bookings) return null;

      const completedAt = new Date(bookings.completed_at);
      const now = new Date();
      const diffMs = now.getTime() - completedAt.getTime();
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
      const diffMins = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));

      let timeStr: string;
      if (diffHours > 0) {
        timeStr = `Completed ${diffHours}hr${diffHours > 1 ? 's' : ''} ago`;
      } else if (diffMins > 0) {
        timeStr = `Completed ${diffMins}min ago`;
      } else {
        timeStr = 'Just completed';
      }

      return {
        time: timeStr,
        service: bookings.service_type || 'Car wash',
      };
    } catch (error) {
      console.error('Error loading last job:', error);
      return null;
    }
  };

  const loadNextBooking = async (): Promise<{ time: string; service: string } | null> => {
    if (!organizationId) return null;
    try {
      const valeterIds = await getValeterIds();
      if (valeterIds.length === 0) return null;

      const now = new Date();
      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('scheduled_at, service_type')
        .in('valeter_id', valeterIds)
        .in('status', ['confirmed', 'pending_valeter_acceptance'])
        .gte('scheduled_at', now.toISOString())
        .order('scheduled_at', { ascending: true })
        .limit(1)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') throw error;
      if (!bookings) return null;

      const scheduledAt = new Date(bookings.scheduled_at);
      const timeStr = scheduledAt.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });

      return {
        time: timeStr,
        service: bookings.service_type || 'Car wash',
      };
    } catch (error) {
      console.error('Error loading next booking:', error);
      return null;
    }
  };

  const loadLastWeekBookings = async (): Promise<number> => {
    if (!organizationId) return 0;
    try {
      const valeterIds = await getValeterIds();
      if (valeterIds.length === 0) return 0;

      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      const twoWeeksAgo = new Date(weekAgo);
      twoWeeksAgo.setDate(twoWeeksAgo.getDate() - 7);

      const { count, error } = await supabase
        .from('bookings')
        .select('id', { count: 'exact', head: true })
        .in('valeter_id', valeterIds)
        .gte('created_at', twoWeeksAgo.toISOString())
        .lt('created_at', weekAgo.toISOString());

      if (error) throw error;
      return count || 0;
    } catch (error) {
      console.error('Error loading last week bookings:', error);
      return 0;
    }
  };

  const loadBookingMetrics = async () => {
    if (!organizationId) {
      return { activeBookings: 0, bookingsThisWeek: 0, completionRate: 0 };
    }

    const valeterIds = await getValeterIds();
    if (valeterIds.length === 0) {
      return { activeBookings: 0, bookingsThisWeek: 0, completionRate: 0 };
    }

    const weekAgo = new Date();
    weekAgo.setDate(weekAgo.getDate() - 7);

    const { data: bookings, error } = await supabase
      .from('bookings')
      .select('id, status, created_at')
      .in('valeter_id', valeterIds)
      .order('created_at', { ascending: false })
      .limit(200);

    if (error) throw error;

    const rows = (bookings || []) as { id: string; status: BookingStatus; created_at: string }[];

    const ACTIVE_STATUSES = new Set<BookingStatus>([
      'confirmed',
      'in_progress',
      'pending_valeter_acceptance',
    ]);
    const COMPLETE_STATUSES = new Set<BookingStatus>(['completed']);
    const CANCEL_STATUSES = new Set<BookingStatus>(['cancelled']);

    const activeBookings = rows.filter((b) => ACTIVE_STATUSES.has(b.status)).length;

    const bookingsThisWeek = rows.filter((b) => {
      const t = new Date(b.created_at).getTime();
      return Number.isFinite(t) && t >= weekAgo.getTime();
    }).length;

    const completed = rows.filter((b) => COMPLETE_STATUSES.has(b.status)).length;
    const cancelled = rows.filter((b) => CANCEL_STATUSES.has(b.status)).length;
    const finished = completed + cancelled;

    const completionRate = finished > 0 ? Math.round((completed / finished) * 100) : 0;

    return { activeBookings, bookingsThisWeek, completionRate };
  };

  const loadTeamCount = async (): Promise<number> => {
    if (!organizationId) return 0;

    try {
      const { count, error } = await supabase
        .from('profiles')
        .select('id', { count: 'exact', head: true })
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      if (error) throw error;
      return count || 0;
    } catch (e) {
      console.warn('Error loading team count:', e);
      return 0;
    }
  };

  const fetchNotificationCount = async () => {
    if (!organizationId) return;

    try {
      const valeterIds = await getValeterIds();

      let newBookingsCount = 0;
      if (valeterIds.length > 0) {
        const { data: bookings, error: bookingsError } = await supabase
          .from('bookings')
          .select('id')
          .in('valeter_id', valeterIds)
          .in('status', [
            'pending',
            'pending_valeter_acceptance',
            'pending_payment',
            'confirmed',
            'in_progress',
            'completed',
            'cancelled',
            'valeter_assigned',
          ]);
        
        if (bookingsError) {
          console.error('[NotificationCount] Error fetching bookings:', bookingsError);
        }
        
        newBookingsCount = bookings?.length || 0;
      }

      const { count: teamRequestsCount, error: teamRequestsError } = await supabase
        .from('team_requests')
        .select('id', { count: 'exact', head: true })
        .eq('organization_id', organizationId)
        .eq('status', 'pending')
        .limit(10);

      if (teamRequestsError) {
        console.error('[NotificationCount] Error fetching team requests:', teamRequestsError);
      }

      const totalCount = newBookingsCount + (teamRequestsCount || 0);
      setNotificationCount(totalCount);
    } catch (error) {
      console.error('Error fetching notification count:', error);
      setNotificationCount(0);
    }
  };

  const calculateBusinessRating = async (): Promise<number> => {
    if (!organizationId) return 0;
    try {
      const { data: valeters, error: valetersError } = await supabase
        .from('profiles')
        .select('id')
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      if (valetersError) throw valetersError;
      if (!valeters || valeters.length === 0) return 0;

      const valeterIds = valeters.map((v: any) => v.id);

      const { data: bookings, error: bookingsError } = await supabase
        .from('bookings')
        .select('rating, status, valeter_id')
        .in('valeter_id', valeterIds)
        .eq('status', 'completed')
        .not('rating', 'is', null)
        .order('created_at', { ascending: false })
        .limit(100);

      if (bookingsError) throw bookingsError;
      if (!bookings || bookings.length === 0) return 0;

      const ratings = bookings
        .map((b: any) => Number(b.rating))
        .filter((r: number) => Number.isFinite(r) && r > 0);

      if (ratings.length === 0) return 0;

      const average = ratings.reduce((sum: number, r: number) => sum + r, 0) / ratings.length;
      return Math.round(average * 10) / 10;
    } catch (error) {
      console.error('Error calculating business rating:', error);
      return 0;
    }
  };


  if (loading) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="business" />
        <SafeAreaView style={styles.container} edges={['top']}>
          <AppHeader title="Dashboard" showBack={false} accountType="business" />
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={businessTheme.primary} />
            <Text style={styles.loadingText}>Loading business data...</Text>
          </View>
        </SafeAreaView>
      </View>
    );
  }

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 17) return 'Good afternoon';
    return 'Good evening';
  };

  const weeklyStreakDiff = stats.bookingsThisWeek - lastWeekBookings;

  return (
    <View style={styles.container}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <SafeAreaView style={styles.container} edges={['top']}>

      <AppHeader
        title={businessName || 'Business Overview'}
        subtitle={
          businessAddress ||
          (() => {
            const greeting = getGreeting();
            const firstNamePart = user?.name ? `, ${user.name.split(' ')[0]}` : '';
            return greeting + firstNamePart;
          })()
        }
        variant="dashboard"
        accountType="business"
        showBack={false}
        businessName={businessName}
        businessAddress={businessAddress}
        businessRating={stats.averageRating}
        showOnlineStatus={true}
        onlineStatusAnim={livePulseAnim}
        profilePicture={profilePicture || undefined}
        todayRevenue={stats.todayRevenue}
        todayJobs={stats.todayJobs}
        lastJob={lastJob ? lastJob.time : null}
        isOnline={isOnline}
        AnimatedCounter={AnimatedCounter}
        rightAction={
          <GradientNotificationBell
            count={notificationCount}
            onPress={async () => {
              await hapticFeedback('light');
              setShowNotificationDropdown(true);
            }}
          />
        }
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
          useNativeDriver: false,
        })}
        scrollEventThrottle={32}
        refreshControl={
          <RefreshControl
            tintColor={SKY}
            refreshing={refreshing ?? false}
            onRefresh={onRefresh}
          />
        }
        contentContainerStyle={[
          styles.scrollContent,
          { 
            paddingTop: DASHBOARD_HEADER_CONTENT_OFFSET - 8,
            paddingBottom: 130 + insets.bottom,
          },
        ]}
      >
        {/* Live Bookings - Only show when there are bookings */}
        {liveBookings.length > 0 && (
        <Animated.View style={[styles.bookingsFeedSection, { opacity: fadeAnim }]}>
          <View style={styles.sectionTitleRow}>
            <View style={styles.sectionTitleWithIcon}>
              <Ionicons name="location" size={16} color={businessTheme.primary} />
              <Text style={styles.sectionTitle}>Live Bookings</Text>
            </View>
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                router.push('/business/bookings');
              }}
            >
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>
            <View style={styles.liveBookingsContainer}>
              {liveBookings.slice(0, 3).map((booking) => {
                const isActive = booking.status === 'in_progress' || booking.status === 'en_route' || booking.status === 'arrived';
                
                let statusText: string;
                if (booking.status === 'in_progress') {
                  statusText = 'In Progress';
                } else if (booking.status === 'en_route') {
                  statusText = 'En Route';
                } else if (booking.status === 'arrived') {
                  statusText = 'Arrived';
                } else if (booking.status === 'confirmed') {
                  statusText = 'Confirmed';
                } else {
                  statusText = 'Pending';
                }
                
                return (
                    <GlassCard 
                    key={booking.id}
                    style={styles.bookingItemCompact} 
                      accountType="business"
                    borderColor={isActive ? 'rgba(59,130,246,0.2)' : 'rgba(255,255,255,0.08)'}
                  >
                    <View style={styles.bookingItemContentCompact}>
                      <View style={styles.bookingRowCompact}>
                        <View style={styles.bookingInfoCompact}>
                          <Text style={styles.bookingCustomerNameCompact} numberOfLines={1}>
                            {booking.customerName || 'Customer'}
                          </Text>
                          <Text style={styles.bookingServiceCompact}>{booking.service}</Text>
                          </View>
                        <View style={[styles.bookingStatusBadgeCompact, isActive && styles.bookingStatusActiveCompact]}>
                          {isActive && <View style={styles.bookingStatusDotCompact} />}
                          <Text style={styles.bookingStatusTextCompact}>{statusText}</Text>
                        </View>
                      </View>
                      <View style={styles.bookingRowCompact}>
                        <View style={styles.bookingMetaCompact}>
                          <Ionicons name="time-outline" size={12} color="rgba(249,250,251,0.6)" />
                          <Text style={styles.bookingMetaText}>{booking.time}</Text>
                        </View>
                        {booking.location_address && (
                          <>
                            <Text style={styles.bookingMetaSeparator}>•</Text>
                            <View style={styles.bookingMetaCompact}>
                              <Ionicons name="location-outline" size={12} color="rgba(249,250,251,0.6)" />
                              <Text style={styles.bookingMetaText} numberOfLines={1}>
                                {booking.location_address.split(',')[0]}
                              </Text>
                            </View>
                          </>
                        )}
                        <View style={styles.bookingPriceCompact}>
                          <Text style={styles.bookingPriceTextCompact}>£{booking.price.toFixed(2)}</Text>
                          </View>
                        </View>
                    </View>
                  </GlassCard>
                );
              })}
            </View>
          </Animated.View>
        )}

        {/* Quick Actions - Show when no live bookings */}
        {liveBookings.length === 0 && (
          <Animated.View style={[styles.quickActionsSection, { opacity: fadeAnim }]}>
            <View style={styles.sectionTitleRow}>
              <View style={styles.sectionTitleWithIcon}>
                <Ionicons name="flash" size={16} color={businessTheme.primary} />
                <Text style={styles.sectionTitle}>Quick Actions</Text>
                          </View>
                          </View>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.quickActionsScrollContainer}
            >
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  router.push('/business/time-tracking');
                }}
              >
                <GlassCard style={styles.quickActionCard} accountType="business">
                  <View style={styles.quickActionContent}>
                    <View style={[styles.quickActionIcon, { backgroundColor: 'rgba(139,92,246,0.15)' }]}>
                      <Ionicons name="time-outline" size={24} color="#8B5CF6" />
                        </View>
                    <Text style={styles.quickActionLabel}>Schedules</Text>
                  </View>
                </GlassCard>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  router.push('/business/analytics');
                }}
              >
                <GlassCard style={styles.quickActionCard} accountType="business">
                  <View style={styles.quickActionContent}>
                    <View style={[styles.quickActionIcon, { backgroundColor: 'rgba(6,182,212,0.15)' }]}>
                      <Ionicons name="stats-chart-outline" size={24} color="#06B6D4" />
                            </View>
                    <Text style={styles.quickActionLabel}>Analytics</Text>
                          </View>
                </GlassCard>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  router.push('/business/earnings');
                }}
              >
                <GlassCard style={styles.quickActionCard} accountType="business">
                  <View style={styles.quickActionContent}>
                    <View style={[styles.quickActionIcon, { backgroundColor: 'rgba(16,185,129,0.15)' }]}>
                      <Ionicons name="wallet-outline" size={24} color="#10B981" />
                          </View>
                    <Text style={styles.quickActionLabel}>Earnings</Text>
                  </View>
                </GlassCard>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  router.push('/business/services');
                }}
              >
                <GlassCard style={styles.quickActionCard} accountType="business">
                  <View style={styles.quickActionContent}>
                    <View style={[styles.quickActionIcon, { backgroundColor: 'rgba(245,158,11,0.15)' }]}>
                      <Ionicons name="construct-outline" size={24} color="#F59E0B" />
                          </View>
                    <Text style={styles.quickActionLabel}>Services</Text>
                        </View>
                </GlassCard>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  router.push('/business/settings');
                }}
              >
                <GlassCard style={styles.quickActionCard} accountType="business">
                  <View style={styles.quickActionContent}>
                    <View style={[styles.quickActionIcon, { backgroundColor: 'rgba(107,114,128,0.15)' }]}>
                      <Ionicons name="settings-outline" size={24} color="#6B7280" />
                    </View>
                    <Text style={styles.quickActionLabel}>Settings</Text>
                      </View>
                    </GlassCard>
                  </TouchableOpacity>

              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  router.push('/business/notifications');
                }}
              >
                <GlassCard style={styles.quickActionCard} accountType="business">
                  <View style={styles.quickActionContent}>
                    <View style={[styles.quickActionIcon, { backgroundColor: 'rgba(236,72,153,0.15)' }]}>
                      <Ionicons name="notifications-outline" size={24} color="#EC4899" />
                    </View>
                    <Text style={styles.quickActionLabel} numberOfLines={1}>Notifications</Text>
                  </View>
                </GlassCard>
              </TouchableOpacity>
            </ScrollView>
        </Animated.View>
        )}

        {/* Key Metrics - Horizontal Scroll */}
        <Animated.View style={[styles.metricsSection, { opacity: fadeAnim }]}>
          <View style={styles.sectionTitleRow}>
            <View style={styles.sectionTitleWithIcon}>
              <Ionicons name="stats-chart" size={16} color={businessTheme.primary} />
              <Text style={styles.sectionTitle}>Key Metrics</Text>
            </View>
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.metricsScrollContainer}
          >
            {/* Weekly Bookings Card */}
            <GlassCard style={styles.metricCardHorizontal} accountType="business">
              <View style={styles.metricCardContent}>
                <View style={styles.metricCardLeft}>
                  <View style={styles.metricIcon}>
                    <Ionicons name="calendar" size={20} color={businessTheme.primary} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.metricLabel}>This Week</Text>
                    <Text style={styles.metricValue}>
                      <AnimatedCounter value={stats.bookingsThisWeek} style={styles.metricNumber} />
                    </Text>
                    <Text style={styles.metricSubtext}>Bookings</Text>
                    {weeklyStreakDiff !== 0 && (
                      <View style={styles.metricTrendRow}>
                        <Ionicons 
                          name={weeklyStreakDiff > 0 ? "arrow-up" : "arrow-down"} 
                          size={10} 
                          color={weeklyStreakDiff > 0 ? "#10B981" : "rgba(239,68,68,0.8)"} 
                        />
                        <Text style={[styles.metricTrend, weeklyStreakDiff > 0 && styles.metricTrendUp]}>
                          {Math.abs(weeklyStreakDiff)} from last week
                        </Text>
                      </View>
                    )}
                  </View>
                </View>
              </View>
            </GlassCard>

            {/* Completion Rate Card */}
            <GlassCard style={styles.metricCardHorizontal} accountType="business">
              <View style={styles.metricCardContent}>
                <View style={styles.metricCardLeft}>
                  <View style={styles.metricIcon}>
                    <Ionicons name="checkmark-done" size={20} color={businessTheme.primary} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.metricLabel}>Completion Rate</Text>
                    <Text style={styles.metricValue}>
                      <Text style={styles.metricNumber}>{Math.round(stats.completionRate)}</Text>
                      <Text style={styles.metricPercent}>%</Text>
                    </Text>
                    <View style={styles.completionBarContainer}>
                      <View style={styles.completionBarTrack}>
                        <View
                          style={[
                            styles.completionBarFill,
                            {
                              width: `${clamp(stats.completionRate, 0, 100)}%`,
                            },
                          ]}
                        />
                      </View>
                    </View>
                  </View>
                </View>
              </View>
            </GlassCard>

            {/* Team Availability Card */}
            <GlassCard style={styles.metricCardHorizontal} accountType="business">
              <LinearGradient
                colors={['rgba(16,185,129,0.2)', 'rgba(16,185,129,0.1)']}
                style={StyleSheet.absoluteFill}
              />
              <View style={styles.metricCardContent}>
                <View style={styles.metricCardLeft}>
                  <View style={styles.metricIcon}>
                    <Ionicons name="people" size={20} color={businessTheme.primary} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={styles.metricLabel}>Team Online</Text>
                    <Text style={styles.metricValue}>
                      <AnimatedCounter value={stats.valetersOnline} style={styles.metricNumber} />
                    </Text>
                    <Text style={styles.metricSubtext}>Valeters available</Text>
                  </View>
                </View>
              </View>
            </GlassCard>
          </ScrollView>
        </Animated.View>

        {/* Locations Summary - Enhanced */}
        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <View style={styles.sectionHeader}>
            <View style={styles.sectionTitleWithIcon}>
              <Ionicons name="location" size={16} color={businessTheme.primary} />
              <Text style={styles.sectionTitle}>Your Locations</Text>
            </View>
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                router.push('/business/locations');
              }}
            >
              <Text style={styles.viewAllText}>View All</Text>
            </TouchableOpacity>
          </View>

          {locations.length === 0 ? (
            <GlassCard style={styles.emptyCard} accountType="business">
              <View style={styles.emptyContent}>
                <Ionicons name="location-outline" size={48} color={SKY} style={{ opacity: 0.5 }} />
                <Text style={styles.emptyTitle}>No locations yet</Text>
                <Text style={styles.emptyText}>
                  Add your first physical location to start accepting bookings
                </Text>
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('medium');
                    router.push('/business/locations');
                  }}
                  style={styles.addButton}
                  activeOpacity={0.85}
                >
                  <LinearGradient colors={['#10B981', '#059669']} style={styles.addButtonGradient}>
                    <Ionicons name="add" size={20} color="#FFFFFF" />
                    <Text style={styles.addButtonText}>Add Location</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </GlassCard>
          ) : (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.locationsScrollContainer}
            >
              {locations.map((location, index) => {
                const isActive = location.is_active !== false && location.status !== 'inactive';
                const isClosed = location.is_active === false || location.status === 'inactive';
                
                let borderColor: string;
                if (isClosed) {
                  borderColor = 'rgba(239,68,68,0.3)';
                } else if (isActive) {
                  borderColor = 'rgba(16,185,129,0.2)';
                } else {
                  borderColor = 'rgba(255,255,255,0.15)';
                }
                
                let gradientColors: string[];
                if (isClosed) {
                  gradientColors = ['rgba(239,68,68,0.1)', 'rgba(239,68,68,0.05)'];
                } else if (isActive) {
                  gradientColors = ['rgba(16,185,129,0.08)', 'rgba(16,185,129,0.02)'];
                } else {
                  gradientColors = ['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.02)'];
                }
                
                return (
                <Animated.View
                  key={location.id}
                  style={[
                    { opacity: fadeAnim },
                    {
                      transform: [
                        {
                          translateX: fadeAnim.interpolate({
                            inputRange: [0, 1],
                            outputRange: [20 + index * 10, 0],
                          }),
                        },
                      ],
                    },
                  ]}
                >
                  <GlassCard
                    onPress={async () => {
                      await hapticFeedback('light');
                      router.push(`/business/locations/${location.id}` as any);
                    }}
                    style={styles.locationCard}
                    accountType="business"
                    borderColor={borderColor}
                  >
                    <LinearGradient
                      colors={gradientColors}
                      style={StyleSheet.absoluteFill}
                    />
                    <View style={styles.locationContent}>
                      <View style={styles.locationHeader}>
                        <View style={styles.locationIconWrapper}>
                          <Ionicons name="location" size={20} color="rgba(255,255,255,0.7)" />
                        </View>
                        {isClosed ? (
                          <Ionicons name="close-circle" size={20} color="#EF4444" />
                        ) : (
                          <View style={[styles.locationStatusBadge, isActive && styles.locationStatusLive]}>
                            <View 
                            style={[
                              styles.locationStatusDot,
                              {
                                  backgroundColor: isActive ? '#10B981' : '#6B7280',
                              },
                            ]}
                          />
                            <Text style={styles.locationStatusText}>
                              {isActive ? 'Open' : 'Offline'}
                            </Text>
                        </View>
                        )}
                      </View>
                      <View style={styles.locationInfo}>
                        <Text style={styles.locationName} numberOfLines={1}>
                          {location.name}
                        </Text>
                        <View style={styles.locationStats}>
                          <View style={styles.locationStatWithIcon}>
                            <Ionicons name="star" size={12} color="#FBBF24" />
                            <Text style={styles.locationStat}>
                              {stats.averageRating.toFixed(1)}
                            </Text>
                          </View>
                          <Text style={styles.locationStatSeparator}>•</Text>
                          <View style={styles.locationStatWithIcon}>
                            <Ionicons name="time-outline" size={12} color="rgba(249,250,251,0.8)" />
                            <Text style={styles.locationStat}>
                              Avg 32m
                            </Text>
                          </View>
                          <Text style={styles.locationStatSeparator}>•</Text>
                          <View style={styles.locationStatWithIcon}>
                            <Ionicons name="wallet-outline" size={12} color="rgba(249,250,251,0.8)" />
                            <Text style={styles.locationStat}>
                              £{stats.todayRevenue} today
                            </Text>
                          </View>
                        </View>
                        <Text style={styles.locationNextBooking}>
                          Next booking: {nextBooking ? nextBooking.time : 'None'}
                        </Text>
                      </View>
                    </View>
                  </GlassCard>
                </Animated.View>
                );
              })}
            </ScrollView>
          )}
        </Animated.View>
      </Animated.ScrollView>

      <BusinessNotificationDropdown
        visible={showNotificationDropdown}
        onClose={() => setShowNotificationDropdown(false)}
        organizationId={organizationId}
      />
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: '#F9FAFB', fontSize: 14, fontWeight: '600' },

  scrollView: { flex: 1 },
  scrollContent: { padding: 16, paddingBottom: 40 },



  // Bookings Feed
  bookingsFeedSection: { marginBottom: 16 },
  quickActionsSection: { marginBottom: 16 },
  quickActionsScrollContainer: {
    paddingRight: 16,
    gap: 12,
  },
  quickActionCard: {
    width: 110,
    height: 100,
    borderRadius: 16,
    overflow: 'hidden',
    padding: 12,
  },
  quickActionContent: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  quickActionIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  quickActionLabel: {
    color: '#F9FAFB',
    fontSize: 11,
    fontWeight: '600',
    textAlign: 'center',
  },
  bookingsScrollContainer: {
    paddingRight: 16,
    gap: 10,
  },
  bookingItemLarge: {
    width: width * 0.9,
    maxWidth: 400,
    marginRight: 10,
    borderRadius: 12,
    overflow: 'hidden',
    padding: 18,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  bookingItemContentLarge: {
    gap: 12,
    zIndex: 1,
  },
  bookingHeaderLarge: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  bookingTimeLarge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  bookingTimeTextLarge: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 13,
    fontWeight: '600',
    marginLeft: 4,
  },
  bookingStatusBadgeLarge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 5,
    borderRadius: 6,
    backgroundColor: 'rgba(107,114,128,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(107,114,128,0.2)',
  },
  bookingStatusActiveLarge: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderColor: 'rgba(16,185,129,0.25)',
  },
  bookingStatusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  bookingStatusTextLarge: {
    color: '#F9FAFB',
    fontSize: 11,
    fontWeight: '600',
    letterSpacing: 0.3,
    textTransform: 'uppercase',
  },
  bookingMainInfo: {
    gap: 4,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.06)',
  },
  bookingCustomerName: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 2,
  },
  bookingServiceLarge: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 13,
    fontWeight: '500',
  },
  bookingVehicleInfo: {
    paddingVertical: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.06)',
  },
  bookingVehicleDetails: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  bookingVehicleReg: {
    color: businessTheme.primary,
    fontSize: 13,
    fontWeight: '600',
    letterSpacing: 0.5,
    marginBottom: 2,
  },
  bookingVehicleModel: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    fontWeight: '500',
  },
  bookingLocationRow: {
    paddingTop: 8,
    paddingBottom: 4,
  },
  bookingLocationText: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 12,
    fontWeight: '500',
  },
  bookingFooter: {
    flexDirection: 'row',
    alignItems: 'baseline',
    justifyContent: 'space-between',
    paddingTop: 12,
    marginTop: 8,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.06)',
  },
  bookingPriceLabel: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 11,
    fontWeight: '500',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  bookingPriceLarge: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    letterSpacing: -0.5,
  },
  liveBookingsContainer: {
    gap: 10,
  },
  bookingItemCompact: {
    borderRadius: 10,
    overflow: 'hidden',
    padding: 14,
    borderWidth: 1,
    marginBottom: 8,
  },
  bookingItemContentCompact: {
    gap: 10,
  },
  bookingRowCompact: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  bookingInfoCompact: {
    flex: 1,
    gap: 2,
  },
  bookingCustomerNameCompact: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
  },
  bookingServiceCompact: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    fontWeight: '500',
  },
  bookingStatusBadgeCompact: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 6,
    backgroundColor: 'rgba(107,114,128,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(107,114,128,0.2)',
  },
  bookingStatusActiveCompact: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderColor: 'rgba(16,185,129,0.25)',
  },
  bookingStatusDotCompact: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: '#10B981',
  },
  bookingStatusTextCompact: {
    color: '#F9FAFB',
    fontSize: 10,
    fontWeight: '600',
    letterSpacing: 0.3,
    textTransform: 'uppercase',
  },
  bookingMetaCompact: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    flex: 1,
  },
  bookingMetaText: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 11,
    fontWeight: '500',
    flex: 1,
  },
  bookingMetaSeparator: {
    color: 'rgba(249,250,251,0.3)',
    fontSize: 11,
    marginHorizontal: 4,
  },
  bookingPriceCompact: {
    marginLeft: 'auto',
  },
  bookingPriceTextCompact: {
    color: businessTheme.primary,
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: -0.3,
  },
  locationStatusClosed: {
    backgroundColor: 'rgba(239,68,68,0.15)',
    borderColor: 'rgba(239,68,68,0.3)',
  },

  // Key Metrics
  metricsSection: { marginBottom: 16 },
  metricsScrollContainer: {
    paddingRight: 16,
    gap: 10,
  },
  metricCardHorizontal: {
    width: width * 0.85,
    maxWidth: 320,
    borderRadius: 12,
    overflow: 'hidden',
    padding: 18,
    marginRight: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
  },
  metricCardContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  metricCardLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  metricIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(59,130,246,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.2)',
  },
  metricLabel: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 11,
    fontWeight: '600',
    marginBottom: 6,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  metricValue: {
    flexDirection: 'row',
    alignItems: 'baseline',
    marginBottom: 2,
  },
  metricNumber: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '700',
    letterSpacing: -0.5,
  },
  metricPercent: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 2,
  },
  metricSubtext: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 11,
    fontWeight: '500',
    marginTop: 2,
  },
  metricTrendRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 3,
  },
  metricTrend: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 11,
    fontWeight: '600',
  },
  metricTrendUp: {
    color: '#10B981',
  },
  completionBarContainer: {
    marginTop: 8,
  },
  completionBarTrack: {
    width: '100%',
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.08)',
    overflow: 'hidden',
  },
  completionBarFill: {
    height: '100%',
    borderRadius: 2,
    backgroundColor: businessTheme.primary,
  },

  // Section Styles
  sectionTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  sectionTitleWithIcon: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    letterSpacing: 0.1,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  viewAllText: {
    color: businessTheme.primary,
    fontSize: 13,
    fontWeight: '600',
  },

  // Live Pill
  livePillContainer: {
    borderRadius: 999,
    overflow: 'hidden',
  },
  livePillBlur: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.25)',
  },
  livePulseDot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: '#10B981',
  },
  livePillText: {
    color: '#FFFFFF',
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  livePillSubtext: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 8,
    fontWeight: '600',
  },

  // Locations
  section: { marginBottom: 16 },
  locationsScrollContainer: { paddingRight: isSmallScreen ? 16 : 20 },
  locationCard: {
    width: width * 0.75,
    maxWidth: 280,
    marginRight: 10,
    borderRadius: 16,
    overflow: 'hidden',
    padding: 14,
  },
  locationContent: {
    gap: 10,
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  locationIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: `${businessTheme.primary}25`,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: `${businessTheme.primary}33`,
  },
  locationStatusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 6,
    backgroundColor: 'rgba(107,114,128,0.2)',
  },
  locationStatusLive: {
    backgroundColor: 'rgba(16,185,129,0.15)',
  },
  locationStatusDot: {
    width: 5,
    height: 5,
    borderRadius: 2.5,
    backgroundColor: '#10B981',
  },
  locationStatusText: {
    color: '#F9FAFB',
    fontSize: 10,
    fontWeight: '700',
  },
  locationInfo: {
    gap: 8,
  },
  locationName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.1,
  },
  locationStats: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    flexWrap: 'wrap',
  },
  locationStatWithIcon: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
  },
  locationStat: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 11,
    fontWeight: '600',
  },
  locationStatSeparator: {
    color: 'rgba(249,250,251,0.4)',
    fontSize: 11,
  },
  locationNextBooking: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 11,
    fontWeight: '500',
  },

  emptyCard: {
    borderRadius: 20,
    overflow: 'hidden',
    padding: 24,
  },
  emptyContent: {
    alignItems: 'center',
    gap: 12,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginTop: 12,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 8,
  },
  addButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginTop: 8,
  },
  addButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 22,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '800',
  },
});
