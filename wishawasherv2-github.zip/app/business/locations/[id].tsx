// app/business/locations/[id].tsx
import React, { useEffect, useMemo, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  ActivityIndicator,
  TouchableOpacity,
  TextInput,
  Alert,
  Dimensions,
  Platform,
  KeyboardAvoidingView,
  Switch,
  ImageBackground,
  Pressable,
  Modal,
  ScrollView,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useLocalSearchParams, router } from 'expo-router';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system/legacy';

import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';

import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

type AnyRow = Record<string, any>;

interface LocationRow {
  id: string;
  organization_id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  status?: string | null;
  is_active?: boolean | null;
  created_at?: string;

  // images (dynamic)
  header_image_url?: string | null;
  photo_url?: string | null;
  image_url?: string | null;

  // optional columns
  eco_washing?: boolean | null;
  detailing_offered?: boolean | null;
  detailing_menu?: any | null; // jsonb
}

interface LocationServiceRow {
  id: string;
  location_id: string;
  service_name: string;
  is_enabled: boolean;
  price: number | null;
  duration_minutes: number | null;
  created_at?: string;
}

const HERO_H = Math.round(width * 0.52);

// tiers
const TIER_DEFS = [
  { key: 'bronze', name: 'Bronze Wash', icon: 'layers-outline' as const, color: '#CD7F32', gradient: ['#CD7F32', '#B87333'] },
  { key: 'silver', name: 'Silver Wash', icon: 'star-outline' as const, color: '#C0C0C0', gradient: ['#C0C0C0', '#A8A8A8'] },
  { key: 'gold', name: 'Gold Wash', icon: 'trophy' as const, color: '#FFD700', gradient: ['#FFD700', '#FFA500'] },
  { key: 'platinum', name: 'Platinum Wash', icon: 'diamond' as const, color: '#E5E4E2', gradient: ['#E5E4E2', '#D3D3D3'] },
];

// detailing
type DetailingKey = 'interior' | 'exterior' | 'full' | 'mini' | 'ceramic' | 'engine' | 'seats';

type DetailingItem = {
  key: DetailingKey;
  name: string;
  enabled: boolean;
  price: number | null;
};

const DETAILING_DEFS: Array<{ key: DetailingKey; name: string; icon: keyof typeof Ionicons.glyphMap }> = [
  { key: 'mini', name: 'Mini Detail', icon: 'sparkles-outline' },
  { key: 'interior', name: 'Interior Detail', icon: 'car-outline' },
  { key: 'exterior', name: 'Exterior Detail', icon: 'water-outline' },
  { key: 'full', name: 'Full Detail', icon: 'diamond-outline' },
  { key: 'seats', name: 'Seat Shampoo', icon: 'shirt-outline' },
  { key: 'engine', name: 'Engine Bay Clean', icon: 'cog-outline' },
  { key: 'ceramic', name: 'Ceramic Coating', icon: 'shield-checkmark-outline' },
];

const STORAGE_BUCKET = 'location-photos';

// Opening hours (new)
type DayKey = 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun';
const DAYS: Array<{ key: DayKey; label: string; idx: number }> = [
  { key: 'mon', label: 'Mon', idx: 0 },
  { key: 'tue', label: 'Tue', idx: 1 },
  { key: 'wed', label: 'Wed', idx: 2 },
  { key: 'thu', label: 'Thu', idx: 3 },
  { key: 'fri', label: 'Fri', idx: 4 },
  { key: 'sat', label: 'Sat', idx: 5 },
  { key: 'sun', label: 'Sun', idx: 6 },
];

type OpeningHourRow = {
  id: string;
  location_id: string;
  day_of_week: number; // 0=Mon ... 6=Sun
  is_open: boolean;
  open_time: string | null;  // "09:00"
  close_time: string | null; // "17:00"
  slot_minutes: number | null; // 30
  created_at?: string;
};

type OpeningHourState = {
  isOpen: boolean;
  openTime: string;  // "09:00"
  closeTime: string; // "17:00"
  slotMinutes: number; // 30
};

const defaultOpeningHours = (): Record<DayKey, OpeningHourState> => ({
  mon: { isOpen: true, openTime: '09:00', closeTime: '17:00', slotMinutes: 30 },
  tue: { isOpen: true, openTime: '09:00', closeTime: '17:00', slotMinutes: 30 },
  wed: { isOpen: true, openTime: '09:00', closeTime: '17:00', slotMinutes: 30 },
  thu: { isOpen: true, openTime: '09:00', closeTime: '17:00', slotMinutes: 30 },
  fri: { isOpen: true, openTime: '09:00', closeTime: '17:00', slotMinutes: 30 },
  sat: { isOpen: false, openTime: '09:00', closeTime: '13:00', slotMinutes: 30 },
  sun: { isOpen: false, openTime: '09:00', closeTime: '13:00', slotMinutes: 30 },
});

// ---------- helpers ----------
const money = (n: any) => {
  const v = typeof n === 'string' ? Number(n) : typeof n === 'number' ? n : 0;
  if (!Number.isFinite(v)) return '0.00';
  return v.toFixed(2);
};

function isMissingColumnErr(err: any) {
  return typeof err?.code === 'string' && err.code.startsWith('PGRST');
}

function normalizeServiceName(s: any) {
  return String(s || '').trim().toLowerCase();
}

function safeBool(v: any, fallback = false) {
  if (v === true) return true;
  if (v === false) return false;
  return fallback;
}

function buildDefaultDetailingItems(): DetailingItem[] {
  return DETAILING_DEFS.map((d) => ({ key: d.key, name: d.name, enabled: false, price: null }));
}

function coerceDetailingMenu(raw: any): DetailingItem[] {
  const defaults = buildDefaultDetailingItems();
  const map = new Map<DetailingKey, DetailingItem>();
  defaults.forEach((d) => map.set(d.key, d));

  const items = raw?.items;
  if (Array.isArray(items)) {
    for (const it of items) {
      const key = it?.key as DetailingKey;
      if (!key || !map.has(key)) continue;
      map.set(key, {
        key,
        name: String(it?.name || map.get(key)!.name),
        enabled: !!it?.enabled,
        price:
          it?.price === null || it?.price === undefined || it?.price === ''
            ? null
            : Number.isFinite(Number(it?.price))
              ? Number(it?.price)
              : null,
      });
    }
  }

  return Array.from(map.values());
}

const base64ToUint8Array = (base64: string) => {
  const bin = globalThis.atob ? globalThis.atob(base64) : Buffer.from(base64, 'base64').toString('binary');
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
};

const guessContentType = (uri: string) => {
  const lower = (uri || '').toLowerCase();
  if (lower.endsWith('.png')) return 'image/png';
  if (lower.endsWith('.webp')) return 'image/webp';
  if (lower.endsWith('.heic') || lower.endsWith('.heif')) return 'image/heic';
  return 'image/jpeg';
};

const pad2 = (n: number) => String(n).padStart(2, '0');

const isValidHHMM = (s: string) => /^([01]\d|2[0-3]):([0-5]\d)$/.test((s || '').trim());

const hhmmToMinutes = (s: string) => {
  if (!isValidHHMM(s)) return null;
  const [h, m] = s.split(':').map((x) => Number(x));
  return h * 60 + m;
};

const minutesToHHMM = (mins: number) => {
  const h = Math.floor(mins / 60);
  const m = mins % 60;
  return `${pad2(h)}:${pad2(m)}`;
};

const buildSlots = (openHHMM: string, closeHHMM: string, slotMinutes: number) => {
  const open = hhmmToMinutes(openHHMM);
  const close = hhmmToMinutes(closeHHMM);
  if (open === null || close === null) return [];
  if (slotMinutes <= 0) return [];
  if (close <= open) return [];
  const out: string[] = [];
  for (let t = open; t + slotMinutes <= close; t += slotMinutes) {
    out.push(minutesToHHMM(t));
  }
  return out;
};

export default function BusinessLocationDetails() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [location, setLocation] = useState<LocationRow | null>(null);

  // header image
  const [headerImageUrl, setHeaderImageUrl] = useState<string | null>(null);
  const [uploadingPhoto, setUploadingPhoto] = useState(false);

  // editable fields
  const [name, setName] = useState('');
  const [address, setAddress] = useState('');
  const [status, setStatus] = useState<'active' | 'inactive'>('active');
  const [isActive, setIsActive] = useState(true);

  // eco + detailing
  const [ecoWashing, setEcoWashing] = useState(false);
  const [detailingOffered, setDetailingOffered] = useState(false);
  const [detailingItems, setDetailingItems] = useState<DetailingItem[]>(buildDefaultDetailingItems());
  const [detailPickerOpen, setDetailPickerOpen] = useState(false);
  const [selectedDetailKey, setSelectedDetailKey] = useState<DetailingKey>('mini');

  // services (tiers)
  const [services, setServices] = useState<LocationServiceRow[]>([]);
  const [servicesTableOk, setServicesTableOk] = useState(true);
  const [seedingTiers, setSeedingTiers] = useState(false);

  // opening hours (new)
  const [openingHoursTableOk, setOpeningHoursTableOk] = useState(true);
  const [openingHours, setOpeningHours] = useState<Record<DayKey, OpeningHourState>>(defaultOpeningHours());
  const [savingHours, setSavingHours] = useState(false);

  const organizationId = useMemo(() => user?.organizationId ?? null, [user?.organizationId]);
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (!id || !isOrgUser || !organizationId) {
      setLoading(false);
      return;
    }
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, isOrgUser, organizationId]);

  const loadAll = async () => {
    try {
      setLoading(true);
      await Promise.all([loadLocation(), loadServicesAndEnsureTiers(), loadOpeningHours()]);
    } catch (e) {
      console.error('[LocationDetails] loadAll error:', e);
    } finally {
      setLoading(false);
    }
  };

  const loadLocation = async () => {
    if (!id || !organizationId) return;

    const { data, error } = await supabase.from('car_wash_locations').select('*').eq('id', id).maybeSingle();
    if (error) throw error;

    if (!data) {
      setLocation(null);
      return;
    }

    if ((data as AnyRow).organization_id !== organizationId) {
      setLocation(null);
      Alert.alert('Access denied', 'That location does not belong to this business.');
      router.back();
      return;
    }

    const row = data as LocationRow;
    setLocation(row);

    setName(row.name ?? '');
    setAddress(row.address ?? '');
    setStatus(((row.status ?? (row.is_active ? 'active' : 'inactive')) as any) === 'inactive' ? 'inactive' : 'active');
    setIsActive(row.is_active === null || row.is_active === undefined ? row.status !== 'inactive' : !!row.is_active);

    setEcoWashing(safeBool((row as AnyRow).eco_washing, false));
    setDetailingOffered(safeBool((row as AnyRow).detailing_offered, false));
    setDetailingItems(coerceDetailingMenu((row as AnyRow).detailing_menu));

    const photo =
      (row as any).header_image_url ??
      (row as any).photo_url ??
      (row as any).image_url ??
      null;

    setHeaderImageUrl(typeof photo === 'string' && photo.trim() ? photo : null);
  };

  const tryUpdatePhotoColumn = async (locationId: string, url: string) => {
    const candidates = ['header_image_url', 'photo_url', 'image_url'];
    let lastErr: any = null;

    for (const col of candidates) {
      const { error } = await supabase.from('car_wash_locations').update({ [col]: url }).eq('id', locationId);
      if (!error) return { ok: true, column: col };

      lastErr = error;
      if (isMissingColumnErr(error) && /column/i.test(String(error?.message || ''))) continue;
      break;
    }

    return { ok: false, error: lastErr };
  };

  const updateLocationPatch = async (patch: Record<string, any>) => {
    if (!location?.id) return { ok: false as const };

    const { error } = await supabase.from('car_wash_locations').update(patch).eq('id', location.id);
    if (!error) return { ok: true as const };

    if (isMissingColumnErr(error) && /column/i.test(String(error?.message || ''))) {
      Alert.alert(
        'DB update needed',
        "Your 'car_wash_locations' table is missing one of the new columns.\n\nRun this SQL in Supabase:\n\n" +
          "ALTER TABLE public.car_wash_locations\n" +
          "  ADD COLUMN IF NOT EXISTS eco_washing boolean NOT NULL DEFAULT false;\n\n" +
          "ALTER TABLE public.car_wash_locations\n" +
          "  ADD COLUMN IF NOT EXISTS detailing_offered boolean NOT NULL DEFAULT false;\n\n" +
          "ALTER TABLE public.car_wash_locations\n" +
          "  ADD COLUMN IF NOT EXISTS detailing_menu jsonb NULL;\n",
      );
      return { ok: false as const };
    }

    Alert.alert('Error', error.message || 'Failed to update location');
    return { ok: false as const };
  };

  const pickAndUploadHeaderPhoto = async () => {
    if (!location?.id || !organizationId) return;

    try {
      setUploadingPhoto(true);
      await hapticFeedback('light');

      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permission needed', 'Please allow photo library access to upload a header photo.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaType.Images,
        allowsEditing: true,
        aspect: [16, 9],
        quality: 0.85,
      });

      if (result.canceled) return;

      const asset = result.assets?.[0];
      if (!asset?.uri) {
        Alert.alert('Error', 'Could not read that image.');
        return;
      }

      setHeaderImageUrl(asset.uri);

      const ext = (asset.uri.split('.').pop() || 'jpg').toLowerCase();
      const fileName = `header_${Date.now()}.${ext}`;
      const filePath = `org_${organizationId}/locations/${location.id}/${fileName}`;

      const base64 = await FileSystem.readAsStringAsync(asset.uri, { encoding: 'base64' as any });
      const bytes = base64ToUint8Array(base64);
      const contentType = guessContentType(asset.uri);

      const upload = await supabase.storage.from(STORAGE_BUCKET).upload(filePath, bytes, {
        contentType,
        upsert: true,
        cacheControl: '3600',
      });

      if (upload.error) throw upload.error;

      const pub = supabase.storage.from(STORAGE_BUCKET).getPublicUrl(filePath);
      const publicUrl = pub?.data?.publicUrl;

      if (!publicUrl) throw new Error('Upload succeeded but could not get public URL.');

      const upd = await tryUpdatePhotoColumn(location.id, publicUrl);

      if (!upd.ok) {
        console.error('[LocationDetails] photo url update failed:', upd.error);
        Alert.alert(
          'DB update needed',
          "The photo uploaded, but your 'car_wash_locations' table doesn't have a column to store the URL.\n\nRun this SQL in Supabase:\n\nALTER TABLE public.car_wash_locations ADD COLUMN IF NOT EXISTS header_image_url text NULL;",
        );
        setHeaderImageUrl(publicUrl);
        return;
      }

      setHeaderImageUrl(publicUrl);
      await loadLocation();
      Alert.alert('Updated', 'Header photo saved.');
    } catch (e: any) {
      console.error('[LocationDetails] upload photo error:', e);
      Alert.alert('Error', e?.message || 'Failed to upload photo');
    } finally {
      setUploadingPhoto(false);
    }
  };

  const parseMaybeNumber = (raw: string, kind: 'price' | 'minutes'): number | null => {
    const t = (raw || '').trim();
    if (!t) return null;

    const v = Number(t);
    if (!Number.isFinite(v)) return null;
    if (v < 0) return null;

    if (kind === 'minutes') return Math.round(v);
    return v;
  };

  // ---------- Opening hours: load + save ----------
  const openingHoursSQL = () =>
    [
      `-- Create opening hours table`,
      `CREATE TABLE IF NOT EXISTS public.location_opening_hours (`,
      `  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),`,
      `  location_id uuid NOT NULL REFERENCES public.car_wash_locations(id) ON DELETE CASCADE,`,
      `  day_of_week int NOT NULL CHECK (day_of_week >= 0 AND day_of_week <= 6), -- 0=Mon ... 6=Sun`,
      `  is_open boolean NOT NULL DEFAULT true,`,
      `  open_time text NULL,  -- "09:00"`,
      `  close_time text NULL, -- "17:00"`,
      `  slot_minutes int NOT NULL DEFAULT 30,`,
      `  created_at timestamptz NOT NULL DEFAULT now(),`,
      `  UNIQUE (location_id, day_of_week)`,
      `);`,
    ].join('\n');

  const loadOpeningHours = async () => {
    if (!id) return;

    try {
      const { data, error } = await supabase
        .from('location_opening_hours')
        .select('*')
        .eq('location_id', id)
        .order('day_of_week', { ascending: true });

      if (error) {
        console.warn('[LocationDetails] opening hours table not available:', error.message || error);
        setOpeningHoursTableOk(false);
        return;
      }

      setOpeningHoursTableOk(true);

      const rows = (data || []) as OpeningHourRow[];
      const next = defaultOpeningHours();

      for (const d of DAYS) {
        const row = rows.find((r) => r.day_of_week === d.idx);
        if (!row) continue;

        const openTime = row.open_time && isValidHHMM(row.open_time) ? row.open_time : next[d.key].openTime;
        const closeTime = row.close_time && isValidHHMM(row.close_time) ? row.close_time : next[d.key].closeTime;
        const slotMinutes = Number.isFinite(Number(row.slot_minutes)) ? Math.max(5, Number(row.slot_minutes)) : 30;

        next[d.key] = {
          isOpen: !!row.is_open,
          openTime,
          closeTime,
          slotMinutes,
        };
      }

      setOpeningHours(next);
    } catch (e) {
      console.error('[LocationDetails] loadOpeningHours error:', e);
      setOpeningHoursTableOk(false);
    }
  };

  const validateOpeningHours = () => {
    for (const d of DAYS) {
      const s = openingHours[d.key];
      if (!s.isOpen) continue;

      if (!isValidHHMM(s.openTime) || !isValidHHMM(s.closeTime)) {
        return `${d.label}: please use HH:MM (e.g. 09:00)`;
      }

      const open = hhmmToMinutes(s.openTime)!;
      const close = hhmmToMinutes(s.closeTime)!;
      if (close <= open) {
        return `${d.label}: close time must be after open time`;
      }

      if (!Number.isFinite(s.slotMinutes) || s.slotMinutes < 5 || s.slotMinutes > 240) {
        return `${d.label}: slot minutes must be between 5 and 240`;
      }
    }
    return null;
  };

  const saveOpeningHours = async () => {
    if (!id) return;

    const errMsg = validateOpeningHours();
    if (errMsg) {
      Alert.alert('Opening hours', errMsg);
      return;
    }

    try {
      setSavingHours(true);
      await hapticFeedback('light');

      // Upsert each day
      const payload = DAYS.map((d) => {
        const s = openingHours[d.key];
        return {
          location_id: id,
          day_of_week: d.idx,
          is_open: !!s.isOpen,
          open_time: s.isOpen ? s.openTime : null,
          close_time: s.isOpen ? s.closeTime : null,
          slot_minutes: s.slotMinutes || 30,
        };
      });

      const { error } = await supabase.from('location_opening_hours').upsert(payload, {
        onConflict: 'location_id,day_of_week',
      });

      if (error) {
        console.error('[LocationDetails] saveOpeningHours error:', error);

        // Common when table doesn't exist yet
        Alert.alert('DB update needed', `Run this SQL in Supabase:\n\n${openingHoursSQL()}`);
        setOpeningHoursTableOk(false);
        return;
      }

      await hapticFeedback('success');
      Alert.alert('Saved', 'Opening hours updated.');
      await loadOpeningHours();
    } catch (e: any) {
      console.error('[LocationDetails] saveOpeningHours crash:', e);
      Alert.alert('Error', e?.message || 'Failed to save opening hours');
    } finally {
      setSavingHours(false);
    }
  };

  // ---------- Save location ----------
  const handleSaveLocation = async () => {
    if (!location?.id) return;

    if (!name.trim()) {
      Alert.alert('Missing info', 'Location name is required.');
      return;
    }

    try {
      setSaving(true);
      await hapticFeedback('medium');

      const nextStatus = isActive ? 'active' : 'inactive';

      const patch: AnyRow = {
        name: name.trim(),
        address: address.trim() ? address.trim() : null,
        status: nextStatus,
        is_active: isActive,
        eco_washing: ecoWashing,
        detailing_offered: detailingOffered,
        detailing_menu: { items: detailingItems },
      };

      const { error } = await supabase.from('car_wash_locations').update(patch).eq('id', location.id);
      if (error) throw error;

      await loadLocation();
      Alert.alert('Saved', 'Location updated.');
    } catch (e: any) {
      console.error('[LocationDetails] save error:', e);
      Alert.alert('Error', e?.message || 'Failed to save location');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteLocation = async () => {
    if (!location?.id) return;

    Alert.alert('Delete location', 'Are you sure? This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            setSaving(true);
            await hapticFeedback('medium');

            const { error } = await supabase.from('car_wash_locations').delete().eq('id', location.id);
            if (error) throw error;

            Alert.alert('Deleted', 'Location removed.');
            router.back();
          } catch (e: any) {
            console.error('[LocationDetails] delete error:', e);
            Alert.alert('Error', e?.message || 'Failed to delete location');
          } finally {
            setSaving(false);
          }
        },
      },
    ]);
  };

  // ---------- Services ----------
  const loadServicesAndEnsureTiers = async () => {
    if (!id) return;

    const { data, error } = await supabase
      .from('location_services')
      .select('*')
      .eq('location_id', id)
      .order('created_at', { ascending: false });

    if (error) {
      console.warn('[LocationDetails] location_services not available:', error.message);
      setServicesTableOk(false);
      setServices([]);
      return;
    }

    setServicesTableOk(true);

    const rows = (data || []) as LocationServiceRow[];
    const ensured = await ensureTierRows(rows);
    setServices(ensured);
  };

  const ensureTierRows = async (rows: LocationServiceRow[]) => {
    if (!id) return rows;

    const byName = new Map<string, LocationServiceRow>();
    rows.forEach((r) => byName.set(normalizeServiceName(r.service_name), r));

    const missingDefs = TIER_DEFS.filter((t) => !byName.has(normalizeServiceName(t.name)));
    if (missingDefs.length === 0) {
      return rows.filter((r) => TIER_DEFS.some((t) => normalizeServiceName(t.name) === normalizeServiceName(r.service_name)));
    }

    try {
      setSeedingTiers(true);

      const inserts = missingDefs.map((t) => ({
        location_id: id,
        service_name: t.name,
        is_enabled: true,
        price: null,
        duration_minutes: null,
      }));

      const ins = await supabase.from('location_services').insert(inserts);
      if (ins.error) {
        console.error('[LocationDetails] ensureTierRows insert error:', ins.error);
        return rows.filter((r) => TIER_DEFS.some((t) => normalizeServiceName(t.name) === normalizeServiceName(r.service_name)));
      }

      const { data: next, error: nextErr } = await supabase.from('location_services').select('*').eq('location_id', id);
      if (nextErr) throw nextErr;

      const nextRows = (next || []) as LocationServiceRow[];
      return nextRows.filter((r) => TIER_DEFS.some((t) => normalizeServiceName(t.name) === normalizeServiceName(r.service_name)));
    } finally {
      setSeedingTiers(false);
    }
  };

  const getTierRow = (tierName: string) =>
    services.find((s) => normalizeServiceName(s.service_name) === normalizeServiceName(tierName)) || null;

  const updateTierRow = async (row: LocationServiceRow, patch: Partial<LocationServiceRow>) => {
    if (!servicesTableOk) return;

    try {
      const { error } = await supabase.from('location_services').update(patch).eq('id', row.id);
      if (error) throw error;

      setServices((prev) => prev.map((s) => (s.id === row.id ? { ...s, ...patch } : s)));
    } catch (e: any) {
      console.error('[LocationDetails] updateTierRow error:', e);
      Alert.alert('Error', e?.message || 'Failed to update tier');
    }
  };

  const updateDetailingItem = async (key: DetailingKey, patch: Partial<DetailingItem>) => {
    const next = detailingItems.map((it) => (it.key === key ? { ...it, ...patch } : it));
    setDetailingItems(next);

    if (!detailingOffered) return;
    await updateLocationPatch({ detailing_menu: { items: next } });
  };

  const renderTierCard = (tier: (typeof TIER_DEFS)[number]) => {
    const row = getTierRow(tier.name);

    if (!row) {
      return (
        <GlassCard key={tier.key} style={styles.tierCard} accountType="business">
          <View style={{ flex: 1 }}>
            <View style={styles.tierCardHeader}>
              <View style={[styles.tierIconWrapper, { backgroundColor: `${tier.color}25`, borderColor: `${tier.color}40` }]}>
                <Ionicons name={tier.icon} size={24} color={tier.color} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={[styles.tierName, { color: tier.color }]}>{tier.name}</Text>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 8 }}>
                  <ActivityIndicator size="small" color={tier.color} />
                  <Text style={styles.miniText}>Setting up this tier...</Text>
                </View>
              </View>
            </View>
          </View>
        </GlassCard>
      );
    }

    return (
      <GlassCard key={tier.key} style={styles.tierCard} accountType="business">
        <LinearGradient
          colors={[`${tier.color}15`, `${tier.color}08`]}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
        <View style={{ flex: 1 }}>
          <View style={styles.tierCardHeader}>
            <View style={[styles.tierIconWrapper, { backgroundColor: `${tier.color}25`, borderColor: `${tier.color}40` }]}>
              <Ionicons name={tier.icon} size={24} color={tier.color} />
            </View>
            <View style={styles.tierHeaderText}>
              <View style={styles.rowBetween}>
                <Text style={[styles.tierName, { color: tier.color }]} numberOfLines={1}>
                  {tier.name}
                </Text>
                <View style={{ alignItems: 'flex-end', gap: 6 }}>
                  <Text style={styles.tierToggleLabel}>Available</Text>
                  <Switch
                    value={!!row.is_enabled}
                    onValueChange={async (v) => {
                      await hapticFeedback('light');
                      updateTierRow(row, { is_enabled: v });
                    }}
                    trackColor={{ false: 'rgba(255,255,255,0.1)', true: `${tier.color}40` }}
                    thumbColor={row.is_enabled ? tier.color : 'rgba(255,255,255,0.5)'}
                  />
                </View>
              </View>

              <View style={styles.tierPillsRow}>
                <View style={[styles.tierPill, { backgroundColor: `${tier.color}20` }]}>
                  <Text style={[styles.tierPillText, { color: tier.color }]}>£{money(row.price)}</Text>
                </View>
                <View style={[styles.tierPill, { backgroundColor: `${tier.color}20` }]}>
                  <Text style={[styles.tierPillText, { color: tier.color }]}>
                    {row.duration_minutes ? `${row.duration_minutes} min` : '— min'}
                  </Text>
                </View>
              </View>
            </View>
          </View>

          <View style={styles.tierInputsRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.tierInputLabel}>Price (£)</Text>
              <GlassCard style={styles.tierInputCard} accountType="business">
                <TextInput
                  defaultValue={row.price === null || row.price === undefined ? '' : String(row.price)}
                  placeholder="0"
                  placeholderTextColor="rgba(249,250,251,0.45)"
                  keyboardType="decimal-pad"
                  style={styles.tierInput}
                  onEndEditing={(e) => {
                    const v = parseMaybeNumber(e.nativeEvent.text || '', 'price');
                    if ((e.nativeEvent.text || '').trim() && v === null) return;
                    updateTierRow(row, { price: v });
                  }}
                />
              </GlassCard>
            </View>

            <View style={{ width: 120 }}>
              <Text style={styles.tierInputLabel}>Minutes</Text>
              <GlassCard style={styles.tierInputCard} accountType="business">
                <TextInput
                  defaultValue={
                    row.duration_minutes === null || row.duration_minutes === undefined ? '' : String(row.duration_minutes)
                  }
                  placeholder="—"
                  placeholderTextColor="rgba(249,250,251,0.45)"
                  keyboardType="number-pad"
                  style={styles.tierInput}
                  onEndEditing={(e) => {
                    const v = parseMaybeNumber(e.nativeEvent.text || '', 'minutes');
                    if ((e.nativeEvent.text || '').trim() && v === null) return;
                    updateTierRow(row, { duration_minutes: v });
                  }}
                />
              </GlassCard>
            </View>
          </View>
        </View>
      </GlassCard>
    );
  };

  // ---------- UI guards ----------
  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Location" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading location...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!location) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Location" accountType="business" />
        <View style={styles.loadingContainer}>
          <Ionicons name="alert-circle-outline" size={36} color={SKY} style={{ opacity: 0.8 }} />
          <Text style={styles.loadingText}>Location not found.</Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }}
            style={[styles.primaryBtn, { marginTop: 12 }]}
            activeOpacity={0.85}
          >
            <LinearGradient colors={[businessTheme.primary, businessTheme.primaryAlt]} style={styles.primaryBtnGrad}>
              <Text style={styles.primaryBtnText}>Go back</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title={location.name || 'Location'}
        subtitle={location.address || 'Edit details & tier pricing'}
        accountType="business"
        scrollY={scrollY}
        enableScrollAnimation={true}
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              handleSaveLocation();
            }}
            style={styles.headerSaveBtn}
            disabled={saving}
          >
            <Ionicons name="save-outline" size={20} color={SKY} />
          </TouchableOpacity>
        }
      />

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <Animated.ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
          scrollEventThrottle={16}
          contentContainerStyle={[
            styles.scrollContent, 
            { 
              paddingTop: HEADER_CONTENT_OFFSET,
              paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
            }
          ]}
        >
          {/* HEADER PHOTO */}
          <Animated.View style={[styles.heroWrap, { opacity: fadeAnim }]}>
            <ImageBackground
              source={headerImageUrl ? { uri: headerImageUrl } : undefined}
              style={styles.hero}
              imageStyle={styles.heroImg}
            >
              {!headerImageUrl && (
                <LinearGradient colors={['rgba(0,0,0,0.35)', 'rgba(0,0,0,0.65)']} style={StyleSheet.absoluteFill} />
              )}

              <View style={styles.heroTopRow}>
                <View style={styles.heroBadge}>
                  <Ionicons name="image-outline" size={16} color="#F9FAFB" />
                  <Text style={styles.heroBadgeText}>{headerImageUrl ? 'Header photo' : 'No header photo'}</Text>
                </View>

                <TouchableOpacity
                  onPress={pickAndUploadHeaderPhoto}
                  disabled={uploadingPhoto}
                  style={[styles.heroBtn, uploadingPhoto && { opacity: 0.75 }]}
                  activeOpacity={0.85}
                >
                  {uploadingPhoto ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <>
                      <Ionicons name={headerImageUrl ? 'refresh' : 'add'} size={18} color="#fff" />
                      <Text style={styles.heroBtnText}>{headerImageUrl ? 'Change' : 'Add'}</Text>
                    </>
                  )}
                </TouchableOpacity>
              </View>

              <View style={styles.heroBottom}>
                <Text style={styles.heroTitle} numberOfLines={1}>
                  {name || location.name || 'Location'}
                </Text>
                <Text style={styles.heroSubtitle} numberOfLines={1}>
                  {address || location.address || 'Tap Add to upload a header image'}
                </Text>
              </View>
            </ImageBackground>
          </Animated.View>

          {/* DETAILS */}
          <Animated.View style={{ opacity: fadeAnim }}>
            <Text style={styles.sectionTitle}>Location Details</Text>

            <GlassCard style={styles.card} accountType="business">
              <View style={styles.field}>
                <Text style={styles.label}>Location name</Text>
                <GlassCard style={styles.inputCard} accountType="business">
                  <TextInput
                    value={name}
                    onChangeText={setName}
                    placeholder="e.g., Main Car Wash Hub"
                    placeholderTextColor="rgba(249,250,251,0.5)"
                    style={styles.input}
                  />
                </GlassCard>
              </View>

              <View style={styles.field}>
                <Text style={styles.label}>Address</Text>
                <GlassCard style={styles.inputCard} accountType="business">
                  <TextInput
                    value={address}
                    onChangeText={setAddress}
                    placeholder="Enter full address"
                    placeholderTextColor="rgba(249,250,251,0.5)"
                    style={[styles.input, styles.textArea]}
                    multiline
                    numberOfLines={3}
                  />
                </GlassCard>
              </View>

              <View style={styles.rowBetween}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>Active</Text>
                  <Text style={styles.miniText}>If off, this location won’t show for bookings.</Text>
                </View>
                <Switch
                  value={isActive}
                  onValueChange={async (v) => {
                    await hapticFeedback('light');
                    setIsActive(v);
                    setStatus(v ? 'active' : 'inactive');
                  }}
                />
              </View>

              {/* ECO + DETAILING */}
              <View style={{ height: 14 }} />

              <View style={styles.rowBetween}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>Eco washing</Text>
                  <Text style={styles.miniText}>Marks this location as eco-friendly for customers.</Text>
                </View>
                <Switch
                  value={ecoWashing}
                  onValueChange={async (v) => {
                    await hapticFeedback('light');
                    setEcoWashing(v);
                    await updateLocationPatch({ eco_washing: v });
                  }}
                />
              </View>

              <View style={{ height: 10 }} />

              <View style={styles.rowBetween}>
                <View style={{ flex: 1 }}>
                  <Text style={styles.label}>Detailing offered</Text>
                  <Text style={styles.miniText}>Turn on to show detailing options + pricing.</Text>
                </View>
                <Switch
                  value={detailingOffered}
                  onValueChange={async (v) => {
                    await hapticFeedback('light');
                    setDetailingOffered(v);

                    const menu = { items: detailingItems };
                    await updateLocationPatch({ detailing_offered: v, detailing_menu: menu });
                  }}
                />
              </View>

              {detailingOffered && (
                <>
                  <View style={{ height: 14 }} />

                  <View style={styles.sectionHeaderRow}>
                    <Text style={[styles.label, { fontSize: 14 }]}>Detailing menu</Text>

                    <TouchableOpacity
                      onPress={async () => {
                        await hapticFeedback('light');
                        setDetailPickerOpen(true);
                      }}
                      style={styles.smallAddBtn}
                      activeOpacity={0.85}
                    >
                      <Ionicons name="add" size={18} color={SKY} />
                    </TouchableOpacity>
                  </View>

                  <Text style={styles.miniText}>
                    Enable the detailing services you offer and set the price. Customers will see these as add-ons.
                  </Text>

                  <View style={{ height: 10 }} />

                  <View style={{ gap: 10 }}>
                    {DETAILING_DEFS.map((def) => {
                      const item =
                        detailingItems.find((x) => x.key === def.key) || {
                          key: def.key,
                          name: def.name,
                          enabled: false,
                          price: null,
                        };

                      return (
                        <View key={def.key} style={styles.serviceRow}>
                          <View style={{ flex: 1 }}>
                            <View style={styles.rowBetween}>
                              <View style={styles.row}>
                                <Ionicons name={def.icon} size={18} color={SKY} />
                                <Text style={styles.serviceName} numberOfLines={1}>
                                  {def.name}
                                </Text>
                              </View>

                              <View style={{ alignItems: 'flex-end', gap: 6 }}>
                                <Text style={styles.inlineLabel}>Offered</Text>
                                <Switch
                                  value={!!item.enabled}
                                  onValueChange={async (v) => {
                                    await hapticFeedback('light');
                                    await updateDetailingItem(def.key, { enabled: v });
                                  }}
                                />
                              </View>
                            </View>

                            <View style={styles.inlineEditRow}>
                              <View style={{ flex: 1 }}>
                                <Text style={styles.inlineLabel}>Price (£)</Text>
                                <GlassCard style={styles.inlineInputCard} accountType="business">
                                  <TextInput
                                    defaultValue={item.price === null || item.price === undefined ? '' : String(item.price)}
                                    placeholder="0"
                                    placeholderTextColor="rgba(249,250,251,0.45)"
                                    keyboardType="decimal-pad"
                                    style={styles.inlineInput}
                                    editable={!!item.enabled}
                                    onEndEditing={async (e) => {
                                      const v = parseMaybeNumber(e.nativeEvent.text || '', 'price');
                                      if ((e.nativeEvent.text || '').trim() && v === null) return;
                                      await updateDetailingItem(def.key, { price: v });
                                    }}
                                  />
                                </GlassCard>
                              </View>

                              <View style={{ width: 110, justifyContent: 'flex-end' }}>
                                <View style={styles.serviceChip}>
                                  <Text style={styles.serviceChipText}>{item.price ? `£${money(item.price)}` : '—'}</Text>
                                </View>
                              </View>
                            </View>
                          </View>
                        </View>
                      );
                    })}
                  </View>

                  <Modal transparent visible={detailPickerOpen} animationType="fade" onRequestClose={() => setDetailPickerOpen(false)}>
                    <Pressable style={styles.modalOverlay} onPress={() => setDetailPickerOpen(false)}>
                      <Pressable style={styles.modalCard} onPress={() => {}}>
                        <View style={styles.modalHeader}>
                          <Text style={styles.modalTitle}>Quick select</Text>
                          <TouchableOpacity onPress={() => setDetailPickerOpen(false)} style={styles.modalCloseBtn}>
                            <Ionicons name="close" size={20} color="#F9FAFB" />
                          </TouchableOpacity>
                        </View>

                        <Text style={styles.modalSub}>Pick one to toggle ON + focus it for pricing.</Text>

                        <View style={{ height: 10 }} />

                        <View style={{ gap: 8 }}>
                          {DETAILING_DEFS.map((d) => (
                            <TouchableOpacity
                              key={d.key}
                              activeOpacity={0.85}
                              onPress={async () => {
                                await hapticFeedback('light');
                                setSelectedDetailKey(d.key);

                                const already = detailingItems.find((x) => x.key === d.key);
                                if (!already?.enabled) {
                                  await updateDetailingItem(d.key, { enabled: true });
                                }

                                setDetailPickerOpen(false);
                              }}
                              style={styles.modalOption}
                            >
                              <View style={styles.row}>
                                <Ionicons name={d.icon} size={18} color={SKY} />
                                <Text style={styles.modalOptionText}>{d.name}</Text>
                              </View>

                              {selectedDetailKey === d.key && <Ionicons name="checkmark-circle" size={18} color={SKY} />}
                            </TouchableOpacity>
                          ))}
                        </View>
                      </Pressable>
                    </Pressable>
                  </Modal>
                </>
              )}

              <View style={styles.actionsRow}>
                <TouchableOpacity
                  onPress={handleSaveLocation}
                  disabled={saving}
                  style={[styles.primaryBtn, saving && { opacity: 0.7 }]}
                  activeOpacity={0.85}
                >
                  <LinearGradient colors={[businessTheme.primary, businessTheme.primaryAlt]} style={styles.primaryBtnGrad}>
                    {saving ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      <>
                        <Ionicons name="checkmark" size={18} color="#fff" />
                        <Text style={styles.primaryBtnText}>Save changes</Text>
                      </>
                    )}
                  </LinearGradient>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={handleDeleteLocation}
                  disabled={saving}
                  style={[styles.dangerBtn, saving && { opacity: 0.7 }]}
                  activeOpacity={0.85}
                >
                  <View style={styles.dangerBtnInner}>
                    <Ionicons name="trash-outline" size={18} color="#FFFFFF" />
                    <Text style={styles.dangerBtnText}>Delete</Text>
                  </View>
                </TouchableOpacity>
              </View>
            </GlassCard>
          </Animated.View>

          {/* OPENING HOURS (NEW) */}
          <Animated.View style={{ opacity: fadeAnim, marginTop: 22 }}>
            <View style={styles.sectionHeaderRow}>
              <Text style={styles.sectionTitle}>Opening Hours</Text>

              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  loadOpeningHours();
                }}
                style={styles.smallAddBtn}
                activeOpacity={0.85}
              >
                <Ionicons name="refresh" size={18} color={SKY} />
              </TouchableOpacity>
            </View>

            {!openingHoursTableOk ? (
              <GlassCard style={styles.card} accountType="business">
                <View style={{ gap: 10 }}>
                  <View style={styles.row}>
                    <Ionicons name="information-circle-outline" size={18} color={SKY} />
                    <Text style={styles.infoText}>
                      Opening hours aren’t available because the{' '}
                      <Text style={{ fontWeight: '900' }}>location_opening_hours</Text> table isn’t accessible.
                    </Text>
                  </View>
                  <Text style={styles.miniText}>Run this SQL in Supabase to add it:</Text>
                  <GlassCard style={{ padding: 12 }} accountType="business">
                    <Text style={[styles.miniText, { fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace' }]}>
                      {openingHoursSQL()}
                    </Text>
                  </GlassCard>
                </View>
              </GlassCard>
            ) : (
              <GlassCard style={styles.card} accountType="business">
                <Text style={styles.miniText}>
                  Set opening/closing times per day. The customer app can then generate <Text style={{ fontWeight: '900' }}>30 minute</Text>{' '}
                  slots (or whatever you set).
                </Text>

                <View style={{ height: 12 }} />

                <View style={{ gap: 12 }}>
                  {DAYS.map((d) => {
                    const s = openingHours[d.key];
                    const slots = s.isOpen ? buildSlots(s.openTime, s.closeTime, s.slotMinutes) : [];

                    return (
                      <View key={d.key} style={styles.hoursRow}>
                        <View style={styles.hoursTop}>
                          <View style={styles.row}>
                            <View style={styles.dayPill}>
                              <Text style={styles.dayPillText}>{d.label}</Text>
                            </View>
                            <Text style={styles.label}>{s.isOpen ? 'Open' : 'Closed'}</Text>
                          </View>

                          <Switch
                            value={s.isOpen}
                            onValueChange={async (v) => {
                              await hapticFeedback('light');
                              setOpeningHours((prev) => ({
                                ...prev,
                                [d.key]: { ...prev[d.key], isOpen: v },
                              }));
                            }}
                          />
                        </View>

                        {s.isOpen ? (
                          <>
                            <View style={styles.hoursInputs}>
                              <View style={{ flex: 1 }}>
                                <Text style={styles.inlineLabel}>Open</Text>
                                <GlassCard style={styles.inlineInputCard} accountType="business">
                                  <TextInput
                                    value={s.openTime}
                                    onChangeText={(t) =>
                                      setOpeningHours((prev) => ({ ...prev, [d.key]: { ...prev[d.key], openTime: t } }))
                                    }
                                    placeholder="09:00"
                                    placeholderTextColor="rgba(249,250,251,0.45)"
                                    style={styles.inlineInput}
                                    autoCapitalize="none"
                                    autoCorrect={false}
                                  />
                                </GlassCard>
                              </View>

                              <View style={{ flex: 1 }}>
                                <Text style={styles.inlineLabel}>Close</Text>
                                <GlassCard style={styles.inlineInputCard} accountType="business">
                                  <TextInput
                                    value={s.closeTime}
                                    onChangeText={(t) =>
                                      setOpeningHours((prev) => ({ ...prev, [d.key]: { ...prev[d.key], closeTime: t } }))
                                    }
                                    placeholder="17:00"
                                    placeholderTextColor="rgba(249,250,251,0.45)"
                                    style={styles.inlineInput}
                                    autoCapitalize="none"
                                    autoCorrect={false}
                                  />
                                </GlassCard>
                              </View>

                              <View style={{ width: 110 }}>
                                <Text style={styles.inlineLabel}>Slot (min)</Text>
                                <GlassCard style={styles.inlineInputCard} accountType="business">
                                  <TextInput
                                    value={String(s.slotMinutes)}
                                    onChangeText={(t) => {
                                      const n = Number((t || '').replace(/[^\d]/g, ''));
                                      setOpeningHours((prev) => ({
                                        ...prev,
                                        [d.key]: { ...prev[d.key], slotMinutes: Number.isFinite(n) && n > 0 ? n : prev[d.key].slotMinutes },
                                      }));
                                    }}
                                    placeholder="30"
                                    placeholderTextColor="rgba(249,250,251,0.45)"
                                    keyboardType="number-pad"
                                    style={styles.inlineInput}
                                  />
                                </GlassCard>
                              </View>
                            </View>

                            <View style={styles.slotPreviewRow}>
                              <View style={styles.serviceChip}>
                                <Text style={styles.serviceChipText}>
                                  Creates {slots.length} slots
                                </Text>
                              </View>

                              {slots.length > 0 ? (
                                <Text style={[styles.miniText, { flex: 1, textAlign: 'right' }]} numberOfLines={1}>
                                  {slots.slice(0, 4).join(', ')}
                                  {slots.length > 4 ? ` …` : ''}
                                </Text>
                              ) : (
                                <Text style={[styles.miniText, { flex: 1, textAlign: 'right' }]}>
                                  Check times
                                </Text>
                              )}
                            </View>
                          </>
                        ) : null}
                      </View>
                    );
                  })}
                </View>

                <View style={{ height: 14 }} />

                <TouchableOpacity
                  onPress={saveOpeningHours}
                  disabled={savingHours}
                  style={[styles.primaryBtn, savingHours && { opacity: 0.7 }]}
                  activeOpacity={0.85}
                >
                  <LinearGradient colors={[businessTheme.primary, businessTheme.primaryAlt]} style={styles.primaryBtnGrad}>
                    {savingHours ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      <>
                        <Ionicons name="time-outline" size={18} color="#fff" />
                        <Text style={styles.primaryBtnText}>Save opening hours</Text>
                      </>
                    )}
                  </LinearGradient>
                </TouchableOpacity>
              </GlassCard>
            )}
          </Animated.View>

          {/* TIER PRICING */}
          <Animated.View style={{ opacity: fadeAnim, marginTop: 22 }}>
            <View style={styles.sectionHeaderRow}>
              <Text style={styles.sectionTitle}>Tier Pricing</Text>

              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  loadServicesAndEnsureTiers();
                }}
                style={styles.smallAddBtn}
                activeOpacity={0.85}
              >
                {seedingTiers ? <ActivityIndicator size="small" color={SKY} /> : <Ionicons name="refresh" size={18} color={SKY} />}
              </TouchableOpacity>
            </View>

            {!servicesTableOk ? (
              <GlassCard style={styles.card} accountType="business">
                <View style={{ gap: 10 }}>
                  <View style={styles.row}>
                    <Ionicons name="information-circle-outline" size={18} color={SKY} />
                    <Text style={styles.infoText}>
                      Tier pricing isn’t available because <Text style={{ fontWeight: '900' }}>location_services</Text> table/policy isn’t accessible.
                    </Text>
                  </View>
                  <Text style={styles.miniText}>If you want, I’ll generate the SQL + RLS for the location_services table.</Text>
                </View>
              </GlassCard>
            ) : (
              <GlassCard style={styles.card} accountType="business">
                <View style={{ gap: 12 }}>{TIER_DEFS.map(renderTierCard)}</View>

                <View style={{ height: 10 }} />

                <Text style={styles.miniText}>
                  These are the fixed tiers customers will see: Bronze, Silver, Gold, Platinum. Set price + duration per location, and toggle availability.
                </Text>
              </GlassCard>
            )}
          </Animated.View>

          <View style={{ height: 28 }} />
        </Animated.ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  scrollView: { flex: 1 },
  scrollContent: { padding: 20 },

  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 14 },

  heroWrap: {
    marginBottom: 18,
    borderRadius: 22,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  hero: {
    height: HERO_H,
    width: '100%',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  heroImg: { borderRadius: 22 },
  heroTopRow: {
    padding: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 10,
  },
  heroBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 10,
    paddingVertical: 8,
    borderRadius: 999,
    backgroundColor: 'rgba(0,0,0,0.35)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  heroBadgeText: { color: '#F9FAFB', fontSize: 12, fontWeight: '800' },
  heroBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 999,
    backgroundColor: 'rgba(0,0,0,0.40)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  heroBtnText: { color: '#F9FAFB', fontSize: 12, fontWeight: '900' },
  heroBottom: {
    padding: 14,
    backgroundColor: 'rgba(0,0,0,0.40)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.10)',
  },
  heroTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '900' },
  heroSubtitle: { color: 'rgba(249,250,251,0.78)', fontSize: 12, marginTop: 4, fontWeight: '700' },

  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 12,
  },
  sectionHeaderRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },

  card: { padding: 16 },

  field: { gap: 8, marginBottom: 12 },
  label: { color: 'rgba(249,250,251,0.85)', fontSize: 13, fontWeight: '700' },
  miniText: { color: 'rgba(249,250,251,0.65)', fontSize: 12, lineHeight: 18 },

  inputCard: { padding: 0, overflow: 'hidden' },
  input: { color: '#F9FAFB', fontSize: 16, padding: 14, minHeight: 48 },
  textArea: { minHeight: 92, textAlignVertical: 'top' },

  row: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  rowBetween: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between', gap: 12 },

  actionsRow: { flexDirection: 'row', gap: 12, marginTop: 14 },
  primaryBtn: { borderRadius: 16, overflow: 'hidden' },
  primaryBtnGrad: {
    paddingVertical: 14,
    paddingHorizontal: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  primaryBtnText: { color: '#fff', fontSize: 14, fontWeight: '800' },

  dangerBtn: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#DC2626',
    backgroundColor: '#EF4444',
    overflow: 'hidden',
    justifyContent: 'center',
    minWidth: 110,
  },
  dangerBtnInner: { 
    paddingVertical: 14, 
    paddingHorizontal: 16,
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'center', 
    gap: 8 
  },
  dangerBtnText: { 
    color: '#FFFFFF', 
    fontSize: 13, 
    fontWeight: '800' 
  },

  headerSaveBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  smallAddBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: 'rgba(135,206,235,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  infoText: { color: 'rgba(249,250,251,0.8)', fontSize: 13, fontWeight: '700', flex: 1 },

  serviceRow: {
    flexDirection: 'row',
    gap: 12,
    padding: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.14)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  serviceName: { color: '#F9FAFB', fontSize: 15, fontWeight: '900', flexShrink: 1 },
  serviceMetaRow: { flexDirection: 'row', gap: 8, marginTop: 8 },
  serviceChip: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
    alignSelf: 'flex-start',
  },
  serviceChipText: { color: 'rgba(249,250,251,0.85)', fontSize: 12, fontWeight: '800' },

  inlineEditRow: { flexDirection: 'row', gap: 10, marginTop: 12 },
  inlineLabel: { color: 'rgba(249,250,251,0.6)', fontSize: 11, fontWeight: '900', marginBottom: 6 },
  inlineInputCard: { padding: 0, overflow: 'hidden' },
  inlineInput: { color: '#F9FAFB', fontSize: 14, paddingVertical: 10, paddingHorizontal: 12 },

  // Tier pricing styles
  tierCard: {
    padding: 18,
    borderRadius: 22,
    overflow: 'hidden',
    marginBottom: 0,
  },
  tierCardHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 14,
    marginBottom: 16,
  },
  tierIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
  },
  tierHeaderText: {
    flex: 1,
  },
  tierName: {
    fontSize: 17,
    fontWeight: '900',
    marginBottom: 10,
    letterSpacing: 0.2,
  },
  tierToggleLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 11,
    fontWeight: '800',
  },
  tierPillsRow: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 8,
  },
  tierPill: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 14,
  },
  tierPillText: {
    fontSize: 13,
    fontWeight: '900',
  },
  tierInputsRow: {
    flexDirection: 'row',
    gap: 12,
  },
  tierInputLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '800',
    marginBottom: 8,
  },
  tierInputCard: {
    padding: 0,
    overflow: 'hidden',
  },
  tierInput: {
    color: '#F9FAFB',
    fontSize: 15,
    paddingVertical: 12,
    paddingHorizontal: 14,
    fontWeight: '800',
  },

  // Opening hours UI
  hoursRow: {
    padding: 12,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.14)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    gap: 10,
  },
  hoursTop: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  dayPill: {
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
  },
  dayPillText: { color: '#F9FAFB', fontSize: 12, fontWeight: '900' },
  hoursInputs: {
    flexDirection: 'row',
    gap: 10,
    alignItems: 'flex-end',
  },
  slotPreviewRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },

  // modal “dropdown”
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    padding: 18,
    justifyContent: 'flex-end',
  },
  modalCard: {
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    backgroundColor: 'rgba(16,20,28,0.92)',
    padding: 14,
  },
  modalHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  modalTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '900' },
  modalSub: { color: 'rgba(249,250,251,0.65)', fontSize: 12, marginTop: 8, lineHeight: 18 },
  modalCloseBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalOption: {
    paddingVertical: 12,
    paddingHorizontal: 12,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    backgroundColor: 'rgba(255,255,255,0.06)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  modalOptionText: { color: '#F9FAFB', fontSize: 13, fontWeight: '800' },
});
