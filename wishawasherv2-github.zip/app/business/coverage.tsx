import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING, STANDARD_SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const businessTheme = getAccountTheme('business');

export default function BusinessCoverage() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      setLoading(false);
    }
  }, [user?.id]);

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Damage Coverage Policy" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#87CEEB" />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Damage Coverage Policy"
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[
          styles.scrollContent, 
          { 
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          }
        ]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <GlassCard style={styles.policyCard} accountType="business">
            <View style={styles.policyContent}>
              <View style={styles.policyHeader}>
                <Ionicons name="shield-checkmark" size={24} color="#87CEEB" />
                <Text style={styles.policyTitle}>Coverage Details</Text>
              </View>

              <View style={styles.policySection}>
                <Text style={styles.policySubtitle}>What's Covered</Text>
                <View style={styles.bulletList}>
                  <View style={styles.bulletItem}>
                    <Ionicons name="checkmark-circle" size={16} color="#87CEEB" />
                    <Text style={styles.bulletText}>
                      Damage to customer vehicles during service
                    </Text>
                  </View>
                  <View style={styles.bulletItem}>
                    <Ionicons name="checkmark-circle" size={16} color="#87CEEB" />
                    <Text style={styles.bulletText}>
                      Accidental damage by valeters
                    </Text>
                  </View>
                  <View style={styles.bulletItem}>
                    <Ionicons name="checkmark-circle" size={16} color="#87CEEB" />
                    <Text style={styles.bulletText}>
                      Equipment damage or loss
                    </Text>
                  </View>
                </View>
              </View>

              <View style={styles.policySection}>
                <Text style={styles.policySubtitle}>Coverage Limits</Text>
                <View style={styles.limitCard}>
                  <Text style={styles.limitLabel}>Maximum Coverage per Incident</Text>
                  <Text style={styles.limitValue}>£5,000</Text>
                </View>
                <View style={styles.limitCard}>
                  <Text style={styles.limitLabel}>Annual Coverage Limit</Text>
                  <Text style={styles.limitValue}>£50,000</Text>
                </View>
              </View>

              <View style={styles.policySection}>
                <Text style={styles.policySubtitle}>How to Report</Text>
                <Text style={styles.policyText}>
                  If damage occurs during service, report it immediately through the app or contact support.
                  All claims are reviewed within 48 hours.
                </Text>
              </View>

              <TouchableOpacity
                style={styles.contactButton}
                onPress={async () => {
                  await hapticFeedback('light');
                  router.push('/business/issues');
                }}
              >
                <View style={styles.contactButtonContent}>
                  <Ionicons name="mail" size={18} color="#FFFFFF" />
                  <Text style={styles.contactButtonText}>Report an Issue</Text>
                </View>
              </TouchableOpacity>
            </View>
          </GlassCard>
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: '#87CEEB',
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  content: {
    gap: 22,
  },
  policyCard: {
    padding: 20,
    borderRadius: 24,
    marginBottom: 0,
  },
  policyContent: {
    gap: 22,
  },
  policyHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    marginBottom: 4,
  },
  policyTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  policySection: {
    gap: 12,
  },
  policySubtitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 12,
    letterSpacing: 0.2,
  },
  bulletList: {
    gap: 12,
  },
  bulletItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  bulletText: {
    flex: 1,
    color: 'rgba(249,250,251,0.9)',
    fontSize: 15,
    lineHeight: 22,
    fontWeight: '500',
  },
  limitCard: {
    padding: 16,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    marginBottom: 12,
  },
  limitLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    marginBottom: 8,
    fontWeight: '700',
  },
  limitValue: {
    color: '#87CEEB',
    fontSize: 24,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  policyText: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 15,
    lineHeight: 22,
    fontWeight: '500',
  },
  contactButton: {
    marginTop: 22,
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#87CEEB',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  contactButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 16,
    paddingHorizontal: 28,
  },
  contactButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
});

