import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Switch,
  ActivityIndicator,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const businessTheme = getAccountTheme('business');

interface NotificationSetting {
  id: string;
  label: string;
  description: string;
  enabled: boolean;
  category: 'bookings' | 'team' | 'analytics' | 'system';
}

export default function BusinessNotifications() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [settings, setSettings] = useState<NotificationSetting[]>([]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadSettings();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadSettings = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      // Load notification settings from database
      const defaultSettings: NotificationSetting[] = [
        {
          id: 'new_booking',
          label: 'New Bookings',
          description: 'Get notified when new bookings are created',
          enabled: true,
          category: 'bookings',
        },
        {
          id: 'booking_cancelled',
          label: 'Booking Cancellations',
          description: 'Alert when customers cancel bookings',
          enabled: true,
          category: 'bookings',
        },
        {
          id: 'valeter_online',
          label: 'Valeter Status',
          description: 'Notifications when valeters come online or go offline',
          enabled: false,
          category: 'team',
        },
        {
          id: 'team_updates',
          label: 'Team Updates',
          description: 'Important updates about your team members',
          enabled: true,
          category: 'team',
        },
        {
          id: 'daily_summary',
          label: 'Daily Summary',
          description: 'Receive daily reports of your business performance',
          enabled: true,
          category: 'analytics',
        },
        {
          id: 'weekly_report',
          label: 'Weekly Reports',
          description: 'Weekly analytics and insights',
          enabled: false,
          category: 'analytics',
        },
        {
          id: 'system_updates',
          label: 'System Updates',
          description: 'Important app updates and maintenance notices',
          enabled: true,
          category: 'system',
        },
      ];
      setSettings(defaultSettings);
    } catch (error) {
      console.error('Error loading notification settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleSetting = async (settingId: string) => {
    if (!user?.id) return;
    try {
      await hapticFeedback('light');
      setSettings(prev =>
        prev.map(s => (s.id === settingId ? { ...s, enabled: !s.enabled } : s))
      );

      // Save to database
      // await supabase.from('business_notification_settings').upsert({...});
    } catch (error) {
      console.error('Error toggling setting:', error);
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'bookings':
        return 'calendar';
      case 'team':
        return 'people';
      case 'analytics':
        return 'stats-chart';
      case 'system':
        return 'settings';
      default:
        return 'notifications';
    }
  };

  const groupedSettings = settings.reduce((acc, setting) => {
    if (!acc[setting.category]) {
      acc[setting.category] = [];
    }
    acc[setting.category].push(setting);
    return acc;
  }, {} as Record<string, NotificationSetting[]>);

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Notification Settings" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#87CEEB" />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" bubbleCount={4} />

      <AppHeader
        title="Notifications"
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={32}
        contentContainerStyle={[
          styles.scrollContent, 
          { 
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          }
        ]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <View style={styles.headerSection}>
            <View style={styles.headerIconBox}>
              <Ionicons name="notifications-outline" size={28} color={businessTheme.primary} />
            </View>
            <View>
              <Text style={styles.sectionTitle}>Notification Preferences</Text>
              <Text style={styles.sectionSubtitle}>
                Control which alerts you receive
              </Text>
            </View>
          </View>

          {Object.entries(groupedSettings).map(([category, categorySettings], catIndex) => (
            <View key={category} style={styles.categorySection}>
              <View style={styles.categoryHeader}>
                <View style={styles.categoryIconWrapper}>
                  <Ionicons
                    name={getCategoryIcon(category) as any}
                    size={18}
                    color={businessTheme.primary}
                  />
                </View>
                <Text style={styles.categoryTitle}>
                  {category.charAt(0).toUpperCase() + category.slice(1)}
                </Text>
              </View>

              <GlassCard style={styles.categoryCard} accountType="business">
                <LinearGradient
                  colors={['rgba(96,217,255,0.06)', 'rgba(96,217,255,0.02)']}
                  style={StyleSheet.absoluteFill}
                />
                <View style={styles.settingsList}>
                  {categorySettings.map((setting, index) => (
                    <View key={setting.id}>
                      <TouchableOpacity
                        style={styles.settingRow}
                        onPress={() => toggleSetting(setting.id)}
                        activeOpacity={0.8}
                      >
                        <View style={styles.settingLeft}>
                          <View style={[styles.settingIconBox, setting.enabled && styles.settingIconBoxActive]}>
                            <Ionicons
                              name={setting.enabled ? 'notifications' : 'notifications-off'}
                              size={18}
                              color={setting.enabled ? businessTheme.primary : 'rgba(255,255,255,0.5)'}
                            />
                          </View>
                          <View style={styles.settingInfo}>
                            <Text style={[styles.settingLabel, !setting.enabled && styles.settingLabelDisabled]}>
                              {setting.label}
                            </Text>
                            <Text style={styles.settingDescription}>{setting.description}</Text>
                          </View>
                        </View>
                        <Switch
                          value={setting.enabled}
                          onValueChange={() => toggleSetting(setting.id)}
                          trackColor={{ 
                            false: 'rgba(255,255,255,0.15)', 
                            true: businessTheme.primary 
                          }}
                          thumbColor={setting.enabled ? '#FFFFFF' : '#9CA3AF'}
                          ios_backgroundColor="rgba(255,255,255,0.15)"
                        />
                      </TouchableOpacity>
                      {index < categorySettings.length - 1 && <View style={styles.settingDivider} />}
                    </View>
                  ))}
                </View>
              </GlassCard>
            </View>
          ))}
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: '#87CEEB',
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: isSmallScreen ? 16 : 20,
  },
  content: {
    gap: SPACING.lg,
  },
  headerSection: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 14,
    marginBottom: SPACING.md,
  },
  headerIconBox: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: 'rgba(96,217,255,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(96,217,255,0.25)',
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '600',
    marginBottom: 4,
    letterSpacing: -0.3,
  },
  sectionSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '500',
    lineHeight: 18,
  },
  categorySection: {
    gap: SPACING.sm,
    marginBottom: SPACING.md,
  },
  categoryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: SPACING.sm,
    paddingHorizontal: 4,
  },
  categoryIconWrapper: {
    width: 32,
    height: 32,
    borderRadius: 10,
    backgroundColor: 'rgba(96,217,255,0.15)',
    borderWidth: 1.5,
    borderColor: 'rgba(96,217,255,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  categoryTitle: {
    color: businessTheme.primary,
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  categoryCard: {
    borderRadius: 16,
    padding: 0,
    overflow: 'hidden',
  },
  settingsList: {
    padding: 12,
  },
  settingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 12,
    paddingHorizontal: 4,
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 12,
  },
  settingIconBox: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  settingIconBoxActive: {
    backgroundColor: 'rgba(96,217,255,0.15)',
    borderColor: 'rgba(96,217,255,0.3)',
  },
  settingInfo: {
    flex: 1,
    gap: 3,
  },
  settingLabel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: -0.1,
  },
  settingLabelDisabled: {
    color: 'rgba(249,250,251,0.6)',
  },
  settingDescription: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '500',
  },
  settingDivider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.08)',
    marginLeft: 48,
    marginVertical: 4,
  },
});

