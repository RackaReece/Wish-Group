import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  TextInput,
  Alert,
  Platform,
  ScrollView,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import StatusDot from '../../src/components/shared/StatusDot';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

interface Valeter {
  id: string;
  name: string;
  email: string;
  phone?: string;
  is_online: boolean;
  total_jobs?: number;
  rating?: number;
  location_assignment?: string;
  role?: string;
  clocked_in?: boolean;
  created_at: string;
}

type ProfileRow = {
  id: string;
  name: string | null;
  full_name: string | null;
  email: string | null;
  phone: string | null;
  created_at: string | null;
  user_type: string | null;
  organization_id: string | null;
};

type PresenceRow = {
  user_id: string;
  is_online: boolean | null;
};

type BookingStatRow = {
  id: string;
  rating: number | null;
};

export default function BusinessTeam() {
  const { user } = useAuth();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [valeters, setValeters] = useState<Valeter[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [filterLocation, setFilterLocation] = useState<string | null>(null);

  // Remove assigned valeter state
  const [removingId, setRemovingId] = useState<string | null>(null);

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (isOrgUser && organizationId) {
      loadValeters();
    } else {
      setValeters([]);
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, user?.userType, organizationId]);

  const normalizeName = (v: ProfileRow) =>
    (v.full_name ?? '').trim() || (v.name ?? '').trim() || 'Valeter';

  const normalizeEmail = (v: ProfileRow) => (v.email ?? '').trim() || 'no-email@unknown';

  const mapProfileToValeter = async (v: ProfileRow): Promise<Valeter> => {
    const displayName = normalizeName(v);
    const email = normalizeEmail(v);

    const { data: presenceData } = await supabase
      .from('valeter_presence')
      .select('user_id, is_online')
      .eq('user_id', v.id)
      .maybeSingle();

    const presence = (presenceData as PresenceRow | null) ?? null;

    // Optimized: Limit to recent bookings for faster loading
    const { data: statsData } = await supabase
      .from('bookings')
      .select('id, rating')
      .eq('valeter_id', v.id)
      .eq('status', 'completed')
      .order('created_at', { ascending: false })
      .limit(50);

    const stats = (statsData || []) as BookingStatRow[];
    const totalJobs = stats.length;
    const avgRating =
      totalJobs > 0 ? stats.reduce((acc, s) => acc + (s.rating || 0), 0) / totalJobs : 0;

    return {
      id: v.id,
      name: displayName,
      email,
      phone: (v.phone ?? '').trim() || undefined,
      created_at: v.created_at ?? new Date().toISOString(),
      is_online: !!presence?.is_online,
      total_jobs: totalJobs,
      rating: avgRating,
      location_assignment: null,
      role: 'valeter',
      clocked_in: false,
    };
  };

  const loadValeters = async () => {
    if (!isOrgUser || !organizationId) return;

    try {
      setLoading(true);

      const { data, error } = await supabase
        .from('profiles')
        .select('id, name, full_name, email, phone, created_at, user_type, organization_id')
        .eq('organization_id', organizationId)
        .ilike('user_type', 'valeter%')
        .order('created_at', { ascending: false });

      if (error) throw error;

      const rows = (data || []) as ProfileRow[];
      const valeterData: Valeter[] = await Promise.all(rows.map(mapProfileToValeter));
      setValeters(valeterData);
    } catch (error) {
      console.error('Error loading valeters:', error);
    } finally {
      setLoading(false);
    }
  };

  const navigateToInvite = async () => {
    await hapticFeedback('light');
    router.push('/business/team/invite');
  };

  const removeValeterFromOrg = async (valeter: Valeter) => {
    if (!organizationId) return;

    Alert.alert(
      'Remove from team?',
      `${valeter.name}\nThis will unassign them from your business.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Remove',
          style: 'destructive',
          onPress: async () => {
            try {
              setRemovingId(valeter.id);
              await hapticFeedback('light');

              const { error } = await supabase
                .from('profiles')
                .update({ organization_id: null })
                .eq('id', valeter.id);

              if (error) throw error;

              await hapticFeedback('success');

              await loadValeters();
            } catch (e) {
              console.error('Error removing valeter:', e);
              await hapticFeedback('error');
              Alert.alert('Could not remove', 'Something went wrong. Please try again.');
            } finally {
              setRemovingId(null);
            }
          },
        },
      ],
      { cancelable: true }
    );
  };

  const filteredValeters = valeters.filter((valeter) => {
    const q = searchQuery.trim().toLowerCase();
    const matchesSearch =
      !q || valeter.name.toLowerCase().includes(q) || valeter.email.toLowerCase().includes(q);

    const matchesLocation = !filterLocation || valeter.location_assignment === filterLocation;

    return matchesSearch && matchesLocation;
  });

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Team" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading team...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!isOrgUser || !organizationId) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Team" accountType="business" />
        <View style={styles.loadingContainer}>
          <Ionicons name="alert-circle-outline" size={42} color={SKY} style={{ opacity: 0.85 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This business account isn’t linked to an organization yet.
            {'\n'}Log out and back in, or contact support.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Team"
        rightAction={
          <TouchableOpacity onPress={navigateToInvite} style={styles.inviteButton}>
            <Ionicons name="person-add" size={24} color={SKY} />
          </TouchableOpacity>
        }
        scrollY={scrollY}
        enableScrollAnimation={true}
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
          useNativeDriver: false,
        })}
        scrollEventThrottle={16}
        contentContainerStyle={[
          styles.scrollContent, 
          { 
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          }
        ]}
      >
        <GlassCard style={styles.searchCard} accountType="business">
          <View style={styles.searchContainer}>
            <Ionicons name="search" size={18} color="#87CEEB" style={styles.searchIcon} />
            <TextInput
              style={styles.searchInput}
              placeholder="Search team..."
              placeholderTextColor="rgba(249,250,251,0.5)"
              value={searchQuery}
              onChangeText={setSearchQuery}
            />
          </View>
        </GlassCard>

        <View style={styles.quickActions}>
          <TouchableOpacity onPress={navigateToInvite} style={styles.quickActionButton}>
            <GlassCard onPress={undefined} style={styles.quickActionCard} accountType="business">
              <LinearGradient
                colors={['rgba(59,130,246,0.2)', 'rgba(59,130,246,0.1)']}
                style={StyleSheet.absoluteFill}
              />
              <View style={styles.quickActionContent}>
                <Ionicons name="person-add" size={20} color="#3B82F6" />
                <Text style={styles.quickActionText}>Add Valeter</Text>
              </View>
            </GlassCard>
          </TouchableOpacity>

          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              loadValeters();
            }}
            style={styles.quickActionButton}
          >
            <GlassCard onPress={undefined} style={styles.quickActionCard} accountType="business">
              <LinearGradient
                colors={['rgba(107,114,128,0.15)', 'rgba(107,114,128,0.08)']}
                style={StyleSheet.absoluteFill}
              />
              <View style={styles.quickActionContent}>
                <Ionicons name="refresh" size={20} color="#6B7280" />
                <Text style={styles.quickActionText}>Refresh</Text>
              </View>
            </GlassCard>
          </TouchableOpacity>
        </View>

        <View style={styles.statsRow}>
          <GlassCard style={styles.statCard} accountType="business">
            <LinearGradient
              colors={['rgba(59,130,246,0.2)', 'rgba(59,130,246,0.1)']}
              style={StyleSheet.absoluteFill}
            />
            <Text style={styles.statValue}>{valeters.length}</Text>
            <Text style={styles.statLabel}>Total Valeters</Text>
          </GlassCard>
          <GlassCard style={styles.statCard} accountType="business">
            <LinearGradient
              colors={['rgba(16,185,129,0.2)', 'rgba(16,185,129,0.1)']}
              style={StyleSheet.absoluteFill}
            />
            <Text style={styles.statValue}>{valeters.filter((v) => v.is_online).length}</Text>
            <Text style={styles.statLabel}>Online Now</Text>
          </GlassCard>
          <GlassCard style={styles.statCard} accountType="business">
            <LinearGradient
              colors={['rgba(245,158,11,0.2)', 'rgba(245,158,11,0.1)']}
              style={StyleSheet.absoluteFill}
            />
            <Text style={styles.statValue}>{valeters.filter((v) => v.clocked_in).length}</Text>
            <Text style={styles.statLabel}>Clocked In</Text>
          </GlassCard>
        </View>

        {filteredValeters.length === 0 ? (
          <GlassCard style={styles.emptyCard} accountType="business">
            <View style={styles.emptyContent}>
              <Ionicons name="people-outline" size={48} color={SKY} style={{ opacity: 0.5 }} />
              <Text style={styles.emptyTitle}>
                {searchQuery ? 'No valeters found' : 'No team members yet'}
              </Text>
              <Text style={styles.emptyText}>
                {searchQuery ? 'Try adjusting your search' : 'Add existing valeters to your business team'}
              </Text>

              {!searchQuery ? (
                <TouchableOpacity onPress={navigateToInvite} style={styles.primaryCta}>
                  <Ionicons name="person-add" size={18} color="#FFFFFF" />
                  <Text style={styles.primaryCtaText}>Add Valeter</Text>
                </TouchableOpacity>
              ) : null}
            </View>
          </GlassCard>
        ) : (
          <View style={styles.teamSection}>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Team Members</Text>
            </View>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.valetersScrollContainer}
            >
            {filteredValeters.map((valeter, index) => (
              <Animated.View
                key={valeter.id}
                style={[
                  { opacity: fadeAnim },
                  {
                    transform: [
                      {
                        translateX: fadeAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [20 + index * 5, 0],
                        }),
                      },
                    ],
                  },
                ]}
              >
                <GlassCard style={styles.valeterCard} accountType="business">
                  <LinearGradient
                    colors={valeter.is_online 
                      ? ['rgba(16,185,129,0.15)', 'rgba(16,185,129,0.08)']
                      : valeter.clocked_in
                      ? ['rgba(245,158,11,0.15)', 'rgba(245,158,11,0.08)']
                      : ['rgba(107,114,128,0.1)', 'rgba(107,114,128,0.05)']}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={styles.valeterHeader}>
                    <View style={styles.valeterAvatar}>
                      <Ionicons name="person" size={24} color={SKY} />
                    </View>

                    <View style={styles.valeterInfo}>
                      <View style={styles.valeterNameRow}>
                        <Text style={styles.valeterName}>{valeter.name}</Text>
                        {valeter.role && (
                          <View style={styles.roleBadge}>
                            <Text style={styles.roleText}>{valeter.role}</Text>
                          </View>
                        )}
                      </View>

                      <Text style={styles.valeterEmail} numberOfLines={1} ellipsizeMode="tail">{valeter.email}</Text>
                      {valeter.phone && <Text style={styles.valeterPhone}>{valeter.phone}</Text>}
                    </View>

                    <View style={styles.rightCluster}>
                      <View style={styles.statusContainer}>
                        <StatusDot
                          status={valeter.is_online ? 'available' : valeter.clocked_in ? 'busy' : 'offline'}
                          size={12}
                          pulseOnChange={true}
                        />
                      </View>

                      <TouchableOpacity
                        onPress={() => removeValeterFromOrg(valeter)}
                        disabled={removingId === valeter.id}
                        style={[styles.removeBtn, removingId === valeter.id && { opacity: 0.6 }]}
                        hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                      >
                        <View style={styles.removeBtnInner}>
                          {removingId === valeter.id ? (
                            <ActivityIndicator size="small" color="#FFFFFF" />
                          ) : (
                            <Ionicons name="trash-outline" size={16} color="#FFFFFF" />
                          )}
                        </View>
                      </TouchableOpacity>
                    </View>
                  </View>

                  <View style={styles.valeterStats}>
                    <View style={styles.statItem}>
                      <Ionicons name="car" size={14} color="#87CEEB" />
                      <Text style={styles.statItemText}>{valeter.total_jobs || 0} jobs</Text>
                    </View>

                    {valeter.rating && valeter.rating > 0 ? (
                      <View style={styles.statItem}>
                        <Ionicons name="star" size={14} color="#87CEEB" />
                        <Text style={styles.statItemText}>{valeter.rating.toFixed(1)}</Text>
                      </View>
                    ) : null}

                    <View style={styles.statItem}>
                      <Ionicons
                        name={valeter.clocked_in ? 'time' : 'time-outline'}
                        size={14}
                        color="#87CEEB"
                      />
                      <Text style={styles.statItemText}>{valeter.clocked_in ? 'Clocked In' : 'Off'}</Text>
                    </View>
                  </View>
                </GlassCard>
              </Animated.View>
            ))}
            </ScrollView>
          </View>
        )}
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 24,
  },
  loadingText: { color: SKY, fontSize: 14 },

  inviteButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },

  scrollView: { flex: 1 },
  scrollContent: { padding: 20 },

  searchCard: { padding: 0, marginBottom: 24, overflow: 'hidden' },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 14,
  },
  searchIcon: { marginRight: 12 },
  searchInput: { 
    flex: 1, 
    color: '#F9FAFB', 
    fontSize: 16,
    fontWeight: '500',
  },

  quickActions: { flexDirection: 'row', gap: 12, marginBottom: 24 },
  quickActionButton: { flex: 1 },
  quickActionCard: { ...CARD_SIZES.small, position: 'relative', overflow: 'hidden' },
  quickActionContent: {
    padding: CARD_SIZES.small.padding,
    alignItems: 'center',
    gap: SPACING.sm,
  },
  quickActionText: { color: '#F9FAFB', fontSize: 12, fontWeight: '600' },

  statsRow: { flexDirection: 'row', gap: 12, marginBottom: 24 },
  statCard: { flex: 1, ...CARD_SIZES.small, alignItems: 'center', position: 'relative', overflow: 'hidden' },
  statValue: { color: '#F9FAFB', fontSize: 20, fontWeight: '700', marginBottom: 4 },
  statLabel: { color: 'rgba(249,250,251,0.7)', fontSize: 11, fontWeight: '500' },

  teamSection: {
    marginTop: 8,
  },
  sectionHeader: {
    marginBottom: 12,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  valetersScrollContainer: {
    paddingRight: 20,
    gap: 12,
  },
  valeterCard: { 
    ...CARD_SIZES.medium,
    width: Math.min(width * 0.75, 320),
    marginRight: 12,
    position: 'relative',
    overflow: 'hidden',
  },
  valeterHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 12 },
  valeterAvatar: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  valeterInfo: { flex: 1 },
  valeterNameRow: { flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 4 },
  valeterName: { color: '#F9FAFB', fontSize: 16, fontWeight: '700' },
  roleBadge: {
    backgroundColor: 'rgba(135,206,235,0.15)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  roleText: { color: '#87CEEB', fontSize: 9, fontWeight: '600', textTransform: 'uppercase' },
  valeterEmail: { color: 'rgba(249,250,251,0.7)', fontSize: 12, marginBottom: 2 },
  valeterPhone: { color: 'rgba(249,250,251,0.6)', fontSize: 12 },

  rightCluster: { alignItems: 'flex-end', gap: 8 },
  statusContainer: { justifyContent: 'center', alignItems: 'center' },
  removeBtn: {
    width: 36,
    height: 36,
    borderRadius: 8,
    backgroundColor: 'rgba(239,68,68,0.85)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(220,38,38,0.6)',
  },
  removeBtnInner: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(220,38,38,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },

  valeterStats: {
    flexDirection: 'row',
    gap: SPACING.lg,
    paddingTop: SPACING.md,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  statItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  statItemText: { color: 'rgba(249,250,251,0.7)', fontSize: 12, fontWeight: '600' },

  emptyCard: { ...CARD_SIZES.large },
  emptyContent: { alignItems: 'center' },
  emptyTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '700', marginTop: 16, marginBottom: 8 },
  emptyText: { color: 'rgba(249,250,251,0.7)', fontSize: 14, textAlign: 'center' },
  primaryCta: {
    marginTop: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: SKY,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 999,
  },
  primaryCtaText: { color: '#FFFFFF', fontSize: 13, fontWeight: '800' },
});
