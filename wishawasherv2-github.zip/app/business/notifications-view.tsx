import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  RefreshControl,
  Image,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Marker, Polyline } from 'react-native-maps';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width, height } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

type NotificationType = 'booking' | 'team_request' | 'team_update' | 'booking_update';
type NotificationPriority = 'low' | 'medium' | 'high';

interface NotificationItem {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  time: string;
  priority: NotificationPriority;
  route?: string;
  bookingId?: string;
  requestId?: string;
  createdAt: string;
  status?: string;
  serviceName?: string;
  customerLocation?: { lat: number; lng: number } | null;
  locationHistory?: Array<{ lat: number; lng: number; timestamp: string }>;
}

export default function BusinessNotificationsView() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [selectedNotification, setSelectedNotification] = useState<NotificationItem | null>(null);
  const [showLocationMap, setShowLocationMap] = useState(false);

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (isOrgUser && organizationId) {
      fetchNotifications();
    } else {
      setLoading(false);
    }
  }, [isOrgUser, organizationId]);

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
  };

  const getPriority = (type: NotificationType, status?: string): NotificationPriority => {
    if (type === 'booking_update' && (status === 'cancelled' || status === 'in_progress')) {
      return 'high';
    }
    if (type === 'team_request') {
      return 'high';
    }
    if (type === 'booking' && (status === 'pending_valeter_acceptance' || status === 'confirmed')) {
      return 'medium';
    }
    if (type === 'team_update') {
      return 'medium';
    }
    return 'low';
  };

  // Simulate location history from 5 mins before booking (UI only, no backend)
  const generateLocationHistory = (booking: any): Array<{ lat: number; lng: number; timestamp: string }> => {
    const history: Array<{ lat: number; lng: number; timestamp: string }> = [];
    const bookingTime = new Date(booking.scheduled_at || booking.created_at);
    const fiveMinsBefore = new Date(bookingTime.getTime() - 5 * 60 * 1000);
    
    // Get customer current location if available
    const currentLat = booking.customer_lat || (booking.location_lat ? booking.location_lat + 0.01 : 51.5074);
    const currentLng = booking.customer_lng || (booking.location_lng ? booking.location_lng + 0.01 : -0.1278);
    
    // Generate 5 location points over 5 minutes (simulated)
    for (let i = 0; i < 5; i++) {
      const timeOffset = (i * 60 * 1000); // 1 minute intervals
      const timestamp = new Date(fiveMinsBefore.getTime() + timeOffset);
      
      // Simulate movement towards booking location
      const progress = i / 4; // 0 to 1
      const lat = currentLat + (booking.location_lat - currentLat) * progress + (Math.random() - 0.5) * 0.001;
      const lng = currentLng + (booking.location_lng - currentLng) * progress + (Math.random() - 0.5) * 0.001;
      
      history.push({
        lat,
        lng,
        timestamp: timestamp.toISOString(),
      });
    }
    
    return history;
  };

  const fetchNotifications = async () => {
    if (!organizationId) return;

    try {
      setLoading(true);
      const notificationItems: NotificationItem[] = [];

      // Get valeters for the organization
      const { data: valeters } = await supabase
        .from('profiles')
        .select('id, full_name, name, updated_at')
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      const valeterIds = (valeters || []).map((v: any) => v.id);
      let bookings: any[] = [];
      
      if (valeterIds.length > 0) {
        const { data: bookingsData, error: bookingsError } = await supabase
          .from('bookings')
          .select('id, status, service_name, created_at, updated_at, scheduled_at, location_lat, location_lng, user_id')
          .in('valeter_id', valeterIds)
          .in('status', [
            'pending',
            'pending_valeter_acceptance',
            'pending_payment',
            'confirmed',
            'in_progress',
            'completed',
            'cancelled',
            'valeter_assigned',
          ])
          .order('updated_at', { ascending: false })
          .limit(50);

        if (!bookingsError) {
          bookings = bookingsData || [];
        }

        // Fetch customer locations for bookings
        const customerIds = Array.from(new Set(bookings.map(b => b.user_id).filter(Boolean)));
        const customerLocationMap = new Map<string, { lat: number; lng: number }>();
        
        if (customerIds.length > 0) {
          const { data: customerProfiles } = await supabase
            .from('profiles')
            .select('id, current_latitude, current_longitude, latitude, longitude')
            .in('id', customerIds);

          (customerProfiles || []).forEach((p: any) => {
            const lat = p.current_latitude || p.latitude;
            const lng = p.current_longitude || p.longitude;
            if (lat && lng && p.id) {
              customerLocationMap.set(p.id, { lat, lng });
            }
          });
        }

        if (bookings.length > 0) {
          bookings.forEach((booking: any) => {
            const isNew = new Date(booking.created_at).getTime() === new Date(booking.updated_at).getTime();
            const type: NotificationType = isNew ? 'booking' : 'booking_update';
            
            let title = 'New Booking';
            let message = '';
            
            if (type === 'booking_update') {
              switch (booking.status) {
                case 'confirmed':
                  title = 'Booking Confirmed';
                  message = 'A booking has been confirmed';
                  break;
                case 'in_progress':
                  title = 'Booking In Progress';
                  message = 'A service is now in progress';
                  break;
                case 'completed':
                  title = 'Booking Completed';
                  message = 'A booking has been completed';
                  break;
                case 'cancelled':
                  title = 'Booking Cancelled';
                  message = 'A booking has been cancelled';
                  break;
                default:
                  title = 'Booking Updated';
                  message = 'A booking has been updated';
              }
            } else {
              message = booking.service_name || 'New booking received';
            }

            const customerLoc = booking.user_id ? customerLocationMap.get(booking.user_id) : null;
            const locationHistory = booking.status === 'in_progress' || booking.status === 'confirmed' 
              ? generateLocationHistory({ ...booking, customer_lat: customerLoc?.lat, customer_lng: customerLoc?.lng })
              : undefined;

            notificationItems.push({
              id: `booking-${booking.id}-${booking.updated_at}`,
              type,
              title,
              message,
              time: formatTime(booking.updated_at || booking.created_at),
              priority: getPriority(type, booking.status),
              route: `/business/bookings?bookingId=${booking.id}`,
              bookingId: booking.id,
              createdAt: booking.updated_at || booking.created_at,
              status: booking.status,
              serviceName: booking.service_name,
              customerLocation: customerLoc || null,
              locationHistory,
            });
          });
        }
      }

      // Fetch team requests
      const { data: teamRequests } = await supabase
        .from('team_requests')
        .select('id, valeter_name, valeter_email, created_at, status')
        .eq('organization_id', organizationId)
        .eq('status', 'pending')
        .order('created_at', { ascending: false })
        .limit(20);

      if (teamRequests) {
        teamRequests.forEach((request: any) => {
          notificationItems.push({
            id: `request-${request.id}`,
            type: 'team_request',
            title: 'Team Request',
            message: request.valeter_name
              ? `${request.valeter_name} wants to join your team`
              : request.valeter_email || 'New team request',
            time: formatTime(request.created_at),
            priority: 'high',
            route: '/business/team/requests',
            requestId: request.id,
            createdAt: request.created_at,
          });
        });
      }

      // Sort by priority and time
      const priorityOrder: Record<NotificationPriority, number> = {
        high: 3,
        medium: 2,
        low: 1,
      };

      notificationItems.sort((a, b) => {
        const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority];
        if (priorityDiff !== 0) return priorityDiff;
        
        const timeA = new Date(a.createdAt).getTime();
        const timeB = new Date(b.createdAt).getTime();
        return timeB - timeA;
      });

      setNotifications(notificationItems);
    } catch (error) {
      console.error('Error fetching notifications:', error);
      setNotifications([]);
    } finally {
      setLoading(false);
    }
  };

  const onRefresh = async () => {
    setRefreshing(true);
    await fetchNotifications();
    setRefreshing(false);
  };

  const handleNotificationPress = async (item: NotificationItem) => {
    await hapticFeedback('light');
    
    // For active bookings, navigate to bookings page with the specific booking
    if (item.type === 'booking' || item.type === 'booking_update') {
      if (item.bookingId) {
        router.push(`/business/bookings?bookingId=${item.bookingId}` as any);
        return;
      }
    }
    
    // For other notifications, use the route
    if (item.route) {
      router.push(item.route as any);
    }
  };

  const handleViewLocation = async (item: NotificationItem) => {
    await hapticFeedback('medium');
    setSelectedNotification(item);
    setShowLocationMap(true);
  };

  const getNotificationIcon = (type: NotificationType): { name: keyof typeof Ionicons.glyphMap; color: string } => {
    switch (type) {
      case 'booking':
        return { name: 'calendar-outline', color: businessTheme.primary };
      case 'booking_update':
        return { name: 'refresh-circle', color: '#3B82F6' };
      case 'team_request':
        return { name: 'person-add', color: '#10B981' };
      case 'team_update':
        return { name: 'people', color: '#8B5CF6' };
      default:
        return { name: 'notifications', color: businessTheme.primary };
    }
  };

  const getPriorityColor = (priority: NotificationPriority): string => {
    switch (priority) {
      case 'high':
        return '#EF4444';
      case 'medium':
        return '#FBBF24';
      case 'low':
        return '#10B981';
      default:
        return businessTheme.primary;
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="All Notifications" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading notifications...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!isOrgUser || !organizationId) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="All Notifications" accountType="business" />
        <View style={styles.loadingContainer}>
          <Ionicons name="alert-circle-outline" size={42} color={SKY} style={{ opacity: 0.85 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This business account isn't linked to an organization yet.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />

      <AppHeader
        title="All Notifications"
        accountType="business"
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.push('/business/notifications');
            }}
            style={styles.settingsButton}
          >
            <Ionicons name="settings-outline" size={20} color={SKY} />
          </TouchableOpacity>
        }
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          },
        ]}
        refreshControl={<RefreshControl tintColor={SKY} refreshing={refreshing} onRefresh={onRefresh} />}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          {notifications.length === 0 ? (
            <View style={styles.emptyContainer}>
              <GlassCard style={styles.emptyCard} accountType="business">
                <View style={styles.emptyContent}>
                  <Ionicons name="notifications-off-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
                  <Text style={styles.emptyTitle}>No Notifications</Text>
                  <Text style={styles.emptyText}>
                    You're all caught up! New notifications will appear here.
                  </Text>
                </View>
              </GlassCard>
            </View>
          ) : (
            notifications.map((item, index) => {
              const icon = getNotificationIcon(item.type);
              const priorityColor = getPriorityColor(item.priority);
              const hasLocation = item.customerLocation && (item.status === 'in_progress' || item.status === 'confirmed');

              return (
                <TouchableOpacity
                  key={item.id}
                  onPress={() => handleNotificationPress(item)}
                  activeOpacity={0.7}
                  style={styles.notificationWrapper}
                >
                  <GlassCard style={styles.notificationCard} accountType="business">
                    <View style={styles.notificationContent}>
                      <View style={[styles.iconWrapper, { backgroundColor: `${icon.color}20` }]}>
                        <Ionicons name={icon.name} size={24} color={icon.color} />
                      </View>
                      
                      <View style={styles.notificationText}>
                        <View style={styles.notificationHeader}>
                          <Text style={styles.notificationTitle}>{item.title}</Text>
                          <View style={[styles.priorityBadge, { backgroundColor: `${priorityColor}20`, borderColor: `${priorityColor}40` }]}>
                            <View style={[styles.priorityDot, { backgroundColor: priorityColor }]} />
                            <Text style={[styles.priorityText, { color: priorityColor }]}>
                              {item.priority.toUpperCase()}
                            </Text>
                          </View>
                        </View>
                        <Text style={styles.notificationMessage}>{item.message}</Text>
                        {item.serviceName && (
                          <Text style={styles.serviceName}>{item.serviceName}</Text>
                        )}
                        <View style={styles.notificationFooter}>
                          <Text style={styles.notificationTime}>{item.time}</Text>
                          {hasLocation && item.locationHistory && (
                            <TouchableOpacity
                              onPress={(e) => {
                                e.stopPropagation();
                                handleViewLocation(item);
                              }}
                              style={styles.locationButton}
                            >
                              <Ionicons name="location" size={14} color={SKY} />
                              <Text style={styles.locationButtonText}>Track Location</Text>
                            </TouchableOpacity>
                          )}
                        </View>
                      </View>
                    </View>
                  </GlassCard>
                </TouchableOpacity>
              );
            })
          )}
        </Animated.View>
      </Animated.ScrollView>

      {/* Location Tracking Modal */}
      {showLocationMap && selectedNotification && selectedNotification.locationHistory && (
        <View style={styles.mapModal}>
          <TouchableOpacity
            style={styles.mapOverlay}
            activeOpacity={1}
            onPress={() => setShowLocationMap(false)}
          >
            <TouchableOpacity
              activeOpacity={1}
              onPress={(e) => e.stopPropagation()}
              style={styles.mapContainer}
            >
              <BlurView intensity={90} tint="dark" style={styles.mapCard}>
                <View style={styles.mapHeader}>
                  <View>
                    <Text style={styles.mapTitle}>Customer Location Tracking</Text>
                    <Text style={styles.mapSubtitle}>
                      Location history from 5 minutes before booking
                    </Text>
                  </View>
                  <TouchableOpacity
                    onPress={() => setShowLocationMap(false)}
                    style={styles.closeButton}
                  >
                    <Ionicons name="close" size={22} color="#F9FAFB" />
                  </TouchableOpacity>
                </View>

                <View style={styles.mapWrapper}>
                  <MapView
                    style={styles.map}
                    initialRegion={{
                      latitude: selectedNotification.locationHistory![0].lat,
                      longitude: selectedNotification.locationHistory![0].lng,
                      latitudeDelta: 0.05,
                      longitudeDelta: 0.05,
                    }}
                    showsUserLocation={false}
                    showsMyLocationButton={false}
                  >
                    {/* Location history path */}
                    {selectedNotification.locationHistory!.length > 1 && (
                      <Polyline
                        coordinates={selectedNotification.locationHistory!.map(loc => ({
                          latitude: loc.lat,
                          longitude: loc.lng,
                        }))}
                        strokeColor={SKY}
                        strokeWidth={3}
                        lineDashPattern={[5, 5]}
                      />
                    )}
                    
                    {/* Start marker (5 mins before) */}
                    {selectedNotification.locationHistory![0] && (
                      <Marker
                        coordinate={{
                          latitude: selectedNotification.locationHistory![0].lat,
                          longitude: selectedNotification.locationHistory![0].lng,
                        }}
                        title="5 mins before"
                        description="Customer location 5 minutes before booking"
                      >
                        <View style={styles.startMarker}>
                          <Ionicons name="time-outline" size={20} color="#FFFFFF" />
                        </View>
                      </Marker>
                    )}

                    {/* Current location marker */}
                    {selectedNotification.customerLocation && (
                      <Marker
                        coordinate={{
                          latitude: selectedNotification.customerLocation.lat,
                          longitude: selectedNotification.customerLocation.lng,
                        }}
                        title="Current Location"
                        description="Customer's current location"
                      >
                        <View style={styles.currentMarker}>
                          <Ionicons name="person" size={20} color="#FFFFFF" />
                        </View>
                      </Marker>
                    )}

                    {/* Intermediate points */}
                    {selectedNotification.locationHistory!.slice(1, -1).map((loc, idx) => (
                      <Marker
                        key={idx}
                        coordinate={{ latitude: loc.lat, longitude: loc.lng }}
                      >
                        <View style={styles.pathMarker} />
                      </Marker>
                    ))}
                  </MapView>
                </View>

                <View style={styles.mapInfo}>
                  <View style={styles.infoRow}>
                    <Ionicons name="time" size={16} color={SKY} />
                    <Text style={styles.infoText}>
                      Tracking from {new Date(selectedNotification.locationHistory![0].timestamp).toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
                    </Text>
                  </View>
                  {selectedNotification.customerLocation && (
                    <View style={styles.infoRow}>
                      <Ionicons name="location" size={16} color="#10B981" />
                      <Text style={styles.infoText}>
                        Current: {selectedNotification.customerLocation.lat.toFixed(4)}, {selectedNotification.customerLocation.lng.toFixed(4)}
                      </Text>
                    </View>
                  )}
                </View>
              </BlurView>
            </TouchableOpacity>
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  settingsButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  content: {
    gap: 12,
  },
  notificationWrapper: {
    marginBottom: 12,
  },
  notificationCard: {
    padding: 0,
    borderRadius: 20,
  },
  notificationContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: 16,
    gap: 14,
  },
  iconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  notificationText: {
    flex: 1,
    gap: 6,
  },
  notificationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  notificationTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    flex: 1,
    letterSpacing: -0.2,
  },
  priorityBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
  },
  priorityDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  priorityText: {
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  notificationMessage: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 14,
    fontWeight: '500',
    lineHeight: 20,
  },
  serviceName: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
    marginTop: 2,
  },
  notificationFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 4,
  },
  notificationTime: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    fontWeight: '500',
  },
  locationButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  locationButtonText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '700',
  },
  emptyContainer: {
    marginTop: 40,
  },
  emptyCard: {
    padding: 40,
  },
  emptyContent: {
    alignItems: 'center',
    gap: 12,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginTop: 12,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  mapModal: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 1000,
  },
  mapOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.85)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  mapContainer: {
    width: '100%',
    maxWidth: 500,
    maxHeight: '80%',
  },
  mapCard: {
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  mapHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.2)',
  },
  mapTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 4,
  },
  mapSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
  },
  closeButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(249,250,251,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  mapWrapper: {
    height: 400,
    borderRadius: 0,
    overflow: 'hidden',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  startMarker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#FBBF24',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#FFFFFF',
  },
  currentMarker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#10B981',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#FFFFFF',
  },
  pathMarker: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: SKY,
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  mapInfo: {
    padding: 16,
    gap: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  infoText: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 13,
    fontWeight: '500',
  },
});
