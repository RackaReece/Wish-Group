import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';

const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

interface ValeterRequest {
  id: string;
  valeter_id: string;
  valeter_name: string;
  valeter_email: string;
  requested_location: string | null;
  requested_role: string;
  status: string;
  created_at: string;
}

export default function ValeterRequests() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const [requests, setRequests] = useState<ValeterRequest[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user?.id) {
      loadRequests();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadRequests = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      
      // TODO: Fetch from valeter_requests table when available
      // For now, empty state UI
      setRequests([]);
    } catch (error) {
      console.error('Error loading requests:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleApprove = async (requestId: string) => {
    try {
      await hapticFeedback('medium');
      
      // TODO: Approve request and add valeter to team
      
      Alert.alert('Approved', 'Valeter added to your team');
      await loadRequests();
    } catch (error: any) {
      console.error('Error approving request:', error);
      Alert.alert('Error', error.message || 'Failed to approve request');
    }
  };

  const handleReject = async (requestId: string) => {
    Alert.alert(
      'Reject Request',
      'Are you sure you want to reject this request?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Reject',
          style: 'destructive',
          onPress: async () => {
            try {
              await hapticFeedback('medium');
              
              // TODO: Reject request
              
              Alert.alert('Rejected', 'Request has been rejected');
              await loadRequests();
            } catch (error: any) {
              console.error('Error rejecting request:', error);
              Alert.alert('Error', error.message || 'Failed to reject request');
            }
          },
        },
      ]
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Valeter Requests" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading requests...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader title="Valeter Requests" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent, 
          { 
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          }
        ]}
        showsVerticalScrollIndicator={false}
      >
        {requests.length === 0 ? (
          <GlassCard style={styles.emptyCard}>
            <View style={styles.emptyContent}>
              <Ionicons name="mail-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
              <Text style={styles.emptyTitle}>No requests yet</Text>
              <Text style={styles.emptyText}>
                Valeter requests to join your business will appear here
              </Text>
            </View>
          </GlassCard>
        ) : (
          <View style={styles.requestsList}>
            {requests.map((request) => (
              <GlassCard
                key={request.id}
                style={styles.requestCard}
                borderColor="rgba(135,206,235,0.3)"
              >
                <View style={styles.requestHeader}>
                  <View style={styles.valeterAvatar}>
                    <Ionicons name="person" size={24} color={SKY} />
                  </View>
                  <View style={styles.requestInfo}>
                    <Text style={styles.valeterName}>{request.valeter_name}</Text>
                    <Text style={styles.valeterEmail}>{request.valeter_email}</Text>
                    {request.requested_location && (
                      <View style={styles.locationRow}>
                        <Ionicons name="location" size={14} color={SKY} />
                        <Text style={styles.locationText}>{request.requested_location}</Text>
                      </View>
                    )}
                    {request.requested_role && (
                      <View style={styles.roleRow}>
                        <Ionicons name="person-circle" size={14} color={SKY} />
                        <Text style={styles.roleText}>{request.requested_role}</Text>
                      </View>
                    )}
                  </View>
                </View>

                <View style={styles.requestActions}>
                  <TouchableOpacity
                    onPress={() => handleApprove(request.id)}
                    style={styles.approveButton}
                  >
                    <LinearGradient
                      colors={['#10B981', '#059669']}
                      style={styles.actionButtonGradient}
                    >
                      <Ionicons name="checkmark" size={18} color="#FFFFFF" />
                      <Text style={styles.actionButtonText}>Approve</Text>
                    </LinearGradient>
                  </TouchableOpacity>

                  <TouchableOpacity
                    onPress={() => handleReject(request.id)}
                    style={styles.rejectButton}
                  >
                    <GlassCard
                      style={styles.actionButtonCard}
                      borderColor="rgba(239,68,68,0.3)"
                    >
                      <Ionicons name="close" size={18} color="#EF4444" />
                      <Text style={styles.rejectButtonText}>Reject</Text>
                    </GlassCard>
                  </TouchableOpacity>
                </View>
              </GlassCard>
            ))}
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  emptyCard: {
    padding: 40,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginTop: 20,
    marginBottom: 12,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  requestsList: {
    gap: 16,
  },
  requestCard: {
    padding: 16,
  },
  requestHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 16,
  },
  valeterAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  requestInfo: {
    flex: 1,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  valeterEmail: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    marginBottom: 8,
  },
  locationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  locationText: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 13,
  },
  roleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  roleText: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 13,
    textTransform: 'capitalize',
  },
  requestActions: {
    flexDirection: 'row',
    gap: 12,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  approveButton: {
    flex: 1,
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  actionButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
  },
  rejectButton: {
    flex: 1,
  },
  actionButtonCard: {
    paddingVertical: 14,
    paddingHorizontal: 16,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 8,
  },
  rejectButtonText: {
    color: '#EF4444',
    fontSize: 15,
    fontWeight: '700',
  },
});
