import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  TextInput,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';

const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

export default function InviteValeter() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const [email, setEmail] = useState('');
  const [selectedLocation, setSelectedLocation] = useState<string | null>(null);
  const [role, setRole] = useState('valeter');
  const [sending, setSending] = useState(false);

  const roles = [
    { id: 'location_manager', label: 'Location Manager', icon: 'person' },
    { id: 'senior_valeter', label: 'Senior Valeter', icon: 'star' },
    { id: 'valeter', label: 'Valeter', icon: 'person-circle' },
    { id: 'staff', label: 'Staff', icon: 'people' },
  ];

  const handleSendInvite = async () => {
    if (!email.trim()) {
      Alert.alert('Error', 'Please enter an email address');
      return;
    }

    if (!user?.id) {
      Alert.alert('Error', 'User not authenticated');
      return;
    }

    try {
      setSending(true);
      await hapticFeedback('medium');

      // TODO: Send actual invite via backend
      // For now, just UI placeholder

      Alert.alert('Invite Sent', `Invitation sent to ${email}`, [
        {
          text: 'OK',
          onPress: () => {
            setEmail('');
            setSelectedLocation(null);
            router.back();
          },
        },
      ]);
    } catch (error: any) {
      console.error('Error sending invite:', error);
      Alert.alert('Error', error.message || 'Failed to send invite');
    } finally {
      setSending(false);
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader title="Invite Valeter" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent, 
          { 
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          }
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Premium Header Section */}
        <View style={styles.headerSection}>
          <View style={styles.headerIconWrapper}>
            <LinearGradient
              colors={['rgba(135,206,235,0.3)', `${businessTheme.primary}33`]}
              style={StyleSheet.absoluteFill}
            />
            <Ionicons name="person-add" size={32} color={SKY} />
          </View>
          <Text style={styles.headerTitle}>Invite a Valeter</Text>
          <Text style={styles.description}>
            Send an email invitation to join your business team. They'll receive a link to accept and get started.
          </Text>
        </View>

        {/* Email Input */}
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Email Address</Text>
          <GlassCard style={styles.inputCard} accountType="business">
            <View style={styles.inputContainer}>
              <View style={styles.inputIconWrapper}>
                <Ionicons name="mail" size={22} color={SKY} />
              </View>
              <TextInput
                style={styles.textInput}
                placeholder="valeter@example.com"
                placeholderTextColor="rgba(249,250,251,0.5)"
                value={email}
                onChangeText={setEmail}
                keyboardType="email-address"
                autoCapitalize="none"
                autoCorrect={false}
              />
            </View>
          </GlassCard>
        </View>

        {/* Role Selection */}
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Assign Role</Text>
          <View style={styles.rolesGrid}>
            {roles.map((roleOption) => (
              <TouchableOpacity
                key={roleOption.id}
                onPress={async () => {
                  await hapticFeedback('light');
                  setRole(roleOption.id);
                }}
                style={styles.roleButton}
                activeOpacity={0.8}
              >
                <GlassCard
                  style={[
                    styles.roleCard,
                    role === roleOption.id && styles.roleCardActive,
                  ]}
                  accountType="business"
                  borderColor={
                    role === roleOption.id
                      ? 'rgba(135,206,235,0.5)'
                      : 'rgba(135,206,235,0.2)'
                  }
                >
                  {role === roleOption.id && (
                    <LinearGradient
                      colors={['rgba(135,206,235,0.2)', `${businessTheme.primary}1A`]}
                      style={StyleSheet.absoluteFill}
                    />
                  )}
                  <View style={[
                    styles.roleIconWrapper,
                    role === roleOption.id && styles.roleIconWrapperActive
                  ]}>
                    <Ionicons
                      name={roleOption.icon as any}
                      size={26}
                      color={role === roleOption.id ? SKY : 'rgba(249,250,251,0.7)'}
                    />
                  </View>
                  <Text
                    style={[
                      styles.roleText,
                      role === roleOption.id && styles.roleTextActive,
                    ]}
                  >
                    {roleOption.label}
                  </Text>
                </GlassCard>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Location Selection Placeholder */}
        <View style={styles.inputGroup}>
          <Text style={styles.label}>Location Assignment</Text>
          <GlassCard style={styles.infoCard} accountType="business">
            <View style={styles.infoContent}>
              <View style={styles.infoIconWrapper}>
                <Ionicons name="information-circle" size={22} color={SKY} />
              </View>
              <View style={styles.infoTextWrapper}>
                <Text style={styles.infoTitle}>Configure Later</Text>
                <Text style={styles.infoText}>
                  Location assignment can be configured after the valeter accepts the invitation.
                </Text>
              </View>
            </View>
          </GlassCard>
        </View>

        {/* Send Button */}
        <TouchableOpacity
          onPress={handleSendInvite}
          style={styles.sendButton}
          disabled={sending || !email.trim()}
          activeOpacity={0.8}
        >
          <LinearGradient
            colors={email.trim() ? [SKY, businessTheme.primary] : ['rgba(135,206,235,0.3)', `${businessTheme.primary}33`]}
            style={styles.sendButtonGradient}
          >
            {sending ? (
              <ActivityIndicator size="small" color={email.trim() ? "#FFFFFF" : "#F9FAFB"} />
            ) : (
              <>
                <Ionicons 
                  name="send" 
                  size={22} 
                  color={email.trim() ? "#FFFFFF" : "rgba(249,250,251,0.5)"} 
                />
                <Text style={[
                  styles.sendButtonText,
                  !email.trim() && styles.sendButtonTextDisabled
                ]}>
                  Send Invitation
                </Text>
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  headerSection: {
    alignItems: 'center',
    marginBottom: 32,
    paddingTop: 8,
  },
  headerIconWrapper: {
    width: 80,
    height: 80,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 26,
    fontWeight: '800',
    marginBottom: 12,
    letterSpacing: -0.5,
  },
  description: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 15,
    lineHeight: 22,
    textAlign: 'center',
    maxWidth: 320,
  },
  inputGroup: {
    marginBottom: 24,
  },
  label: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  inputCard: {
    padding: 0,
    overflow: 'hidden',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 16,
  },
  inputIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  inputIcon: {
    marginRight: 12,
  },
  textInput: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '500',
  },
  rolesGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  roleButton: {
    flex: 1,
    minWidth: '47%',
  },
  roleCard: {
    padding: 18,
    alignItems: 'center',
    gap: 10,
    minHeight: 110,
    justifyContent: 'center',
    overflow: 'hidden',
  },
  roleCardActive: {
    backgroundColor: 'rgba(135,206,235,0.15)',
  },
  roleIconWrapper: {
    width: 52,
    height: 52,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.12)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  roleIconWrapperActive: {
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderColor: 'rgba(135,206,235,0.4)',
    transform: [{ scale: 1.05 }],
  },
  roleText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '600',
    textAlign: 'center',
  },
  roleTextActive: {
    color: SKY,
    fontWeight: '800',
  },
  infoCard: {
    padding: 18,
  },
  infoContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 14,
  },
  infoIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  infoTextWrapper: {
    flex: 1,
  },
  infoTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 6,
  },
  infoText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    lineHeight: 20,
  },
  sendButton: {
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    marginTop: 24,
  },
  sendButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 20,
    paddingHorizontal: 32,
  },
  sendButtonText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  sendButtonTextDisabled: {
    color: 'rgba(249,250,251,0.5)',
  },
});
