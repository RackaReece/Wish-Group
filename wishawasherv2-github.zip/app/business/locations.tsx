import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  ScrollView,
  Alert,
  Modal,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Image,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET, HEADER_HEIGHT } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width, height } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

interface Location {
  id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  status?: string | null;
  is_active?: boolean | null;
  created_at: string;
  // Performance stats (computed)
  rating?: number;
  washesThisWeek?: number;
  revenueThisWeek?: number;
}

export default function BusinessLocations() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const mapRef = useRef<MapView>(null);
  const scrollViewRef = useRef<any>(null);

  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLocationIndex, setSelectedLocationIndex] = useState(0);
  const [showAddModal, setShowAddModal] = useState(false);
  const [newLocationName, setNewLocationName] = useState('');
  const [newLocationAddress, setNewLocationAddress] = useState('');
  const [saving, setSaving] = useState(false);
  const [bookingsToday, setBookingsToday] = useState(0);
  const [revenueToday, setRevenueToday] = useState(0);
  const [avgRating, setAvgRating] = useState(0);
  const [showStatsBoxes, setShowStatsBoxes] = useState(true);
  const [initialRegion, setInitialRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  });
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  });

  const cardWidth = width - 40;
  const cardSpacing = 20;

  // ✅ Use the org id, not the user id
  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  // Sync map with selected location
  useEffect(() => {
    if (locations.length > 0 && selectedLocationIndex < locations.length) {
      const selectedLocation = locations[selectedLocationIndex];
      if (selectedLocation.latitude && selectedLocation.longitude) {
        const newRegion: Region = {
          latitude: selectedLocation.latitude,
          longitude: selectedLocation.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        };
        setRegion(newRegion);
        mapRef.current?.animateToRegion(newRegion, 500);
      }
    }
  }, [selectedLocationIndex, locations]);

  // Scroll to selected location when index changes
  useEffect(() => {
    if (scrollViewRef.current && locations.length > 0 && selectedLocationIndex < locations.length) {
      const scrollX = selectedLocationIndex * (cardWidth + cardSpacing);
      scrollViewRef.current.scrollTo({
        x: scrollX,
        animated: true,
      });
    }
  }, [selectedLocationIndex, locations.length, cardWidth, cardSpacing]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    // Only load locations when we have a valid org context
    if (isOrgUser && organizationId) {
      loadLocations();
    } else {
      setLocations([]);
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id, user?.userType, organizationId]);

  const getValeterIds = async (): Promise<string[]> => {
    if (!organizationId) return [];
    try {
      const { data: valeters, error: valErr } = await supabase
        .from('profiles')
        .select('id')
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      if (valErr) throw valErr;
      return (valeters || []).map((v: any) => v.id) as string[];
    } catch (error) {
      console.error('Error loading valeter IDs:', error);
      return [];
    }
  };

  const loadLocationStats = async (locationId: string): Promise<{ rating: number; washesThisWeek: number; revenueThisWeek: number }> => {
    try {
      const valeterIds = await getValeterIds();
      if (valeterIds.length === 0) {
        return { rating: 0, washesThisWeek: 0, revenueThisWeek: 0 };
      }

      // Get bookings for this location (we'll need to match by address or location_id if available)
      // For now, we'll get all bookings and filter by location if we have location_id in bookings
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);

      // Try to get bookings by location_id first, then fallback to address matching
      const { data: bookings, error: bookingsError } = await supabase
        .from('bookings')
        .select('id, price, status, rating, location_address, location_id')
        .in('valeter_id', valeterIds)
        .gte('created_at', weekAgo.toISOString());

      if (bookingsError) {
        console.warn('Error loading location stats:', bookingsError);
        return { rating: 0, washesThisWeek: 0, revenueThisWeek: 0 };
      }

      // Get location details to match by address
      const { data: locationData } = await supabase
        .from('car_wash_locations')
        .select('address')
        .eq('id', locationId)
        .maybeSingle();

      const locationAddress = locationData?.address;

      // Filter bookings for this location (by location_id or address match)
      const locationBookings = (bookings || []).filter((b: any) => {
        if (b.location_id === locationId) return true;
        if (locationAddress && b.location_address && 
            b.location_address.toLowerCase().includes(locationAddress.toLowerCase())) {
          return true;
        }
        return false;
      });

      const completed = locationBookings.filter((b: any) => b.status === 'completed');
      const washesThisWeek = completed.length;
      
      const revenueThisWeek = completed.reduce((sum: number, b: any) => {
        const price = Number(b.price || 0);
        return sum + (Number.isFinite(price) ? price : 0);
      }, 0);

      // Calculate average rating
      const ratings = completed
        .map((b: any) => Number(b.rating))
        .filter((r: number) => Number.isFinite(r) && r > 0);
      
      const rating = ratings.length > 0
        ? ratings.reduce((sum: number, r: number) => sum + r, 0) / ratings.length
        : 0;

      return {
        rating: Math.round(rating * 10) / 10,
        washesThisWeek,
        revenueThisWeek: Math.round(revenueThisWeek),
      };
    } catch (error) {
      console.error('Error loading location stats:', error);
      return { rating: 0, washesThisWeek: 0, revenueThisWeek: 0 };
    }
  };

  const loadLocations = async () => {
    if (!isOrgUser || !organizationId) return;

    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, latitude, longitude, status, is_active, created_at')
        .eq('organization_id', organizationId)
        .order('created_at', { ascending: false });

      if (error) throw error;
      const loadedLocations = (data as Location[]) || [];
      
      // Load performance stats for each location
      const locationsWithStats = await Promise.all(
        loadedLocations.map(async (location) => {
          const stats = await loadLocationStats(location.id);
          return {
            ...location,
            ...stats,
          };
        })
      );
      
      setLocations(locationsWithStats);

      // Update map region to show all locations
      const locationsWithCoords = loadedLocations.filter(l => l.latitude && l.longitude);
      if (locationsWithCoords.length > 0) {
        const lats = locationsWithCoords.map(l => l.latitude!);
        const lngs = locationsWithCoords.map(l => l.longitude!);
        const minLat = Math.min(...lats);
        const maxLat = Math.max(...lats);
        const minLng = Math.min(...lngs);
        const maxLng = Math.max(...lngs);
        
        const newRegion = {
          latitude: (minLat + maxLat) / 2,
          longitude: (minLng + maxLng) / 2,
          latitudeDelta: Math.max((maxLat - minLat) * 1.5, 0.05),
          longitudeDelta: Math.max((maxLng - minLng) * 1.5, 0.05),
        };
        setRegion(newRegion);
        setInitialRegion(newRegion);
      }
    } catch (error: any) {
      console.error('Error loading locations:', error);
      Alert.alert('Error', error?.message || 'Failed to load locations');
    } finally {
      setLoading(false);
    }
  };


  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Locations" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading locations...</Text>
        </View>
      </SafeAreaView>
    );
  }

  // If they somehow reached this screen without an org context, give a clear message
  if (!isOrgUser || !organizationId) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Locations" accountType="business" />
        <View style={styles.loadingContainer}>
          <Ionicons name="alert-circle-outline" size={42} color={SKY} style={{ opacity: 0.85 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This business account isn’t linked to an organization yet.
            {'\n'}If you think this is wrong, log out and back in.
          </Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }}
            style={[styles.addButton, { marginTop: 10 }]}
          >
            <Ionicons name="arrow-back" size={20} color={SKY} />
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const handleToggleLocationStatus = async (locationId: string, currentStatus: boolean) => {
    try {
      await hapticFeedback('medium');
      const newStatus = !currentStatus;

      const { error } = await supabase
        .from('car_wash_locations')
        .update({ 
          is_active: newStatus,
          status: newStatus ? 'active' : 'inactive'
        })
        .eq('id', locationId)
        .eq('organization_id', organizationId!);

      if (error) throw error;

      // Update local state
      setLocations(prev => prev.map(loc => 
        loc.id === locationId ? { ...loc, is_active: newStatus, status: newStatus ? 'active' : 'inactive' } : loc
      ));
      
      Alert.alert(
        newStatus ? 'Location Opened' : 'Location Closed',
        newStatus 
          ? 'This location is now open for bookings.'
          : 'This location is now closed. Customers cannot book at this location.'
      );
    } catch (error: any) {
      console.error('Error toggling location status:', error);
      Alert.alert('Error', error?.message || 'Failed to update location status');
    }
  };

  // Render location card (without blue wrapper)
  const renderLocationCard = (location: Location) => {
    const isOpen = location.is_active !== false; // Default to open if not set
    const addressParts = location.address?.split(',') || [];
    const postcode = addressParts[addressParts.length - 1]?.trim() || '';
    const streetName = addressParts[0]?.trim() || location.address || 'Address not set';

    return (
      <View style={styles.locationCardWrapper}>
        <BlurView intensity={60} tint="dark" style={styles.locationCardBlur}>
          <View style={styles.jobCardBackground} />
          <View style={[styles.jobCardBorder, { borderColor: 'rgba(135,206,235,0.3)' }]} />
          
          {/* Header */}
          <View style={styles.locationCardHeader}>
            <View style={styles.locationCardHeaderContent}>
              <View style={styles.servicePreviewIcon}>
                <Ionicons name="location" size={12} color={businessTheme.primary} />
              </View>
              <View style={styles.locationCardHeaderText}>
                <Text style={styles.locationCardTitle} numberOfLines={1}>
                  {location.name}
                </Text>
                <Text style={styles.locationCardAddress} numberOfLines={1}>
                  {streetName}
                </Text>
              </View>
            </View>
            <View style={styles.locationCardHeaderRight}>
              <TouchableOpacity
                onPress={async (e: any) => {
                  e?.stopPropagation?.();
                  await hapticFeedback('light');
                  handleDeleteLocation(location.id);
                }}
                style={styles.deleteButton}
              >
                <Ionicons name="trash-outline" size={18} color="#EF4444" />
              </TouchableOpacity>
            </View>
          </View>

          {/* Open/Closed Toggle */}
          <View style={styles.locationStatusSection}>
            <TouchableOpacity
              onPress={() => handleToggleLocationStatus(location.id, isOpen)}
              style={styles.statusToggleButton}
              activeOpacity={0.8}
            >
              <View style={[styles.statusPill, isOpen && styles.statusPillOpen]}>
                <View style={[styles.statusDot, isOpen && styles.statusDotOpen]} />
                <Text style={[styles.statusText, isOpen && styles.statusTextOpen]}>
                  {isOpen ? 'OPEN' : 'CLOSED'}
                </Text>
              </View>
            </TouchableOpacity>
          </View>


          {/* Action Buttons */}
          <View style={styles.locationCardActions}>
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                router.push({
                  pathname: '/business/bookings',
                  params: { locationId: location.id },
                } as any);
              }}
              style={[styles.actionButton, styles.viewBookingsButton]}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={[SKY, '#3B82F6']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.actionButtonGradient}
              >
                <Ionicons name="calendar" size={18} color="#FFFFFF" />
                <Text style={styles.actionButtonText}>View Bookings</Text>
              </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                router.push(`/business/locations/${location.id}` as any);
              }}
              style={[styles.actionButton, styles.manageButton]}
              activeOpacity={0.8}
            >
              <BlurView intensity={40} tint="dark" style={styles.manageButtonBlur}>
                <View style={styles.manageButtonBackground} />
                <Ionicons name="settings" size={18} color={SKY} />
                <Text style={styles.manageButtonText}>Manage</Text>
              </BlurView>
            </TouchableOpacity>
          </View>
        </BlurView>
      </View>
    );
  };

  // Render map with location markers
  const renderMap = () => {
    if (loading) {
      return (
        <View style={styles.mapContainer}>
          <View style={styles.mapLoadingContainer}>
            <ActivityIndicator size="large" color={SKY} />
            <Text style={styles.mapLoadingText}>Loading map...</Text>
          </View>
        </View>
      );
    }

    return (
      <View style={styles.mapContainer}>
        <MapView
          ref={mapRef}
          style={styles.map}
          region={region}
          showsUserLocation={false}
          showsMyLocationButton={false}
          mapType="standard"
          mapPadding={{ top: 0, bottom: height * 0.4, left: 0, right: 0 }}
          loadingEnabled={true}
          loadingIndicatorColor={SKY}
          followsUserLocation={false}
        >
          {locations.filter(l => l.latitude && l.longitude).map((location, index) => {
            const isSelected = index === selectedLocationIndex;
            return (
              <Marker
                key={location.id}
                coordinate={{
                  latitude: location.latitude!,
                  longitude: location.longitude!,
                }}
                anchor={{ x: 0.5, y: 0.5 }}
              >
                <View style={[styles.locationMarker, isSelected && styles.locationMarkerSelected]}>
                  <Image
                    source={require('../../assets/washing.png')}
                    style={styles.spongeMarkerImage}
                    resizeMode="contain"
                  />
                </View>
              </Marker>
            );
          })}
        </MapView>
      </View>
    );
  };

  const handleScroll = (event: any) => {
    const scrollPosition = event.nativeEvent.contentOffset.x;
    const newIndex = Math.round(scrollPosition / (cardWidth + cardSpacing));
    
    if (newIndex >= 0 && newIndex < locations.length && newIndex !== selectedLocationIndex) {
      setSelectedLocationIndex(newIndex);
    }
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (initialRegion) {
      setRegion(initialRegion);
      mapRef.current?.animateToRegion(initialRegion, 500);
    }
  };

  const handleAddLocation = async () => {
    if (!newLocationName.trim() || !newLocationAddress.trim()) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    if (!isOrgUser || !organizationId) {
      Alert.alert('Error', 'Business account not linked to an organization.');
      return;
    }

    try {
      setSaving(true);
      await hapticFeedback('medium');

      const { error } = await supabase.from('car_wash_locations').insert({
        name: newLocationName.trim(),
        address: newLocationAddress.trim(),
        organization_id: organizationId,
        latitude: null,
        longitude: null,
        is_active: true,
        status: 'active',
      });

      if (error) throw error;

      setShowAddModal(false);
      setNewLocationName('');
      setNewLocationAddress('');
      await loadLocations();
      Alert.alert('Success', 'Location added successfully');
    } catch (error: any) {
      console.error('Error adding location:', error);
      Alert.alert('Error', error?.message || 'Failed to add location');
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteLocation = async (locationId: string) => {
    Alert.alert(
      'Delete Location',
      'Are you sure you want to delete this location? This action cannot be undone.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await hapticFeedback('medium');

              const { error } = await supabase
                .from('car_wash_locations')
                .delete()
                .eq('id', locationId)
                .eq('organization_id', organizationId!);

              if (error) throw error;

              await loadLocations();
              Alert.alert('Success', 'Location deleted');
            } catch (error: any) {
              console.error('Error deleting location:', error);
              Alert.alert('Error', error?.message || 'Failed to delete location');
            }
          },
        },
      ]
    );
  };

  const selectedLocation = locations.length > 0 && locations[selectedLocationIndex] ? locations[selectedLocationIndex] : null;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
        {renderMap()}
        
        <View style={styles.headerOverlay}>
          <AppHeader
            title="Locations"
            rightAction={
              <View style={styles.headerActions}>
                <TouchableOpacity
                  onPress={handleRecenter}
                  style={styles.headerActionButton}
                >
                  <Ionicons name="locate" size={20} color={SKY} />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    setShowAddModal(true);
                  }}
                  style={styles.headerActionButton}
                >
                  <Ionicons name="add" size={24} color={SKY} />
                </TouchableOpacity>
              </View>
            }
            accountType="business"
          />
        </View>
        
        {/* Location Stats - Under Header */}
        {locations.length > 0 && locations[selectedLocationIndex] && showStatsBoxes && (() => {
          const selectedLocation = locations[selectedLocationIndex];
          return (
            <View style={[styles.locationStatsUnderHeader, { top: insets.top + HEADER_HEIGHT + 8 }]}>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  setShowStatsBoxes(false);
                }}
                style={styles.statsCloseButton}
                activeOpacity={0.7}
              >
                <BlurView intensity={20} tint="dark" style={styles.statsCloseButtonBlur}>
                  <Ionicons name="close" size={12} color="rgba(249,250,251,0.9)" />
                </BlurView>
              </TouchableOpacity>
              <BlurView intensity={20} tint="dark" style={styles.locationStatBox}>
                <View style={styles.locationStatBoxContent}>
                  <Ionicons name="calendar-outline" size={16} color={SKY} />
                  <Text style={styles.locationStatLabel}>Bookings Today</Text>
                  <Text style={styles.locationStatValue}>{bookingsToday}</Text>
                </View>
              </BlurView>
              <BlurView intensity={20} tint="dark" style={styles.locationStatBox}>
                <View style={styles.locationStatBoxContent}>
                  <Ionicons name="wallet-outline" size={16} color="#10B981" />
                  <Text style={styles.locationStatLabel}>Revenue</Text>
                  <Text style={styles.locationStatValue}>£{revenueToday}</Text>
                </View>
              </BlurView>
              <BlurView intensity={20} tint="dark" style={styles.locationStatBox}>
                <View style={styles.locationStatBoxContent}>
                  <Ionicons name="star-outline" size={16} color="#FBBF24" />
                  <Text style={styles.locationStatLabel}>Avg Rating</Text>
                  <Text style={styles.locationStatValue}>{selectedLocation.rating?.toFixed(1) || '0.0'}</Text>
                </View>
              </BlurView>
            </View>
          );
        })()}

          {locations.length > 1 && (
            <View style={styles.headerIndicatorContainer}>
              {locations.map((location, index) => (
                <View
                  key={location.id || `indicator-${index}`}
                  style={[
                    styles.headerIndicatorDot,
                    index === selectedLocationIndex && styles.headerIndicatorDotActive,
                  ]}
                />
              ))}
            </View>
          )}
        </Animated.View>

        {/* Location Cards - Horizontal Scrolling */}
        {locations.length === 0 ? (
          <View style={[styles.emptyContainer, { paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20 }]}>
            <BlurView intensity={60} tint="dark" style={styles.emptyCard}>
              <View style={styles.jobCardBackground} />
              <View style={[styles.jobCardBorder, { borderColor: 'rgba(135,206,235,0.3)' }]} />
              <View style={styles.emptyContent}>
                <Ionicons name="location-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
                <Text style={styles.emptyTitle}>No locations yet</Text>
                <Text style={styles.emptyText}>
                  Add your first physical location to start accepting bookings at your business
                </Text>
              </View>
            </BlurView>
          </View>
        ) : (
          <View style={[styles.locationCardContainer, { paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20 }]}>
            <ScrollView
              ref={scrollViewRef}
              horizontal
              pagingEnabled={false}
              showsHorizontalScrollIndicator={false}
              onScroll={handleScroll}
              scrollEventThrottle={16}
              contentContainerStyle={styles.scrollContent}
              snapToInterval={cardWidth + cardSpacing}
              decelerationRate="fast"
              snapToAlignment="start"
            >
              {locations.map((location, index) => (
                <View key={location.id} style={styles.locationCardScrollItem}>
                  {renderLocationCard(location)}
                </View>
              ))}
            </ScrollView>
          </View>
        )}

        {/* Add Location Modal */}
        <Modal
          visible={showAddModal}
          animationType="slide"
          transparent={true}
          onRequestClose={() => setShowAddModal(false)}
        >
          <KeyboardAvoidingView
            style={styles.modalOverlay}
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          >
            <TouchableOpacity
              style={StyleSheet.absoluteFill}
              activeOpacity={1}
              onPress={() => {
                hapticFeedback('light');
                setShowAddModal(false);
              }}
            >
              <TouchableOpacity
                activeOpacity={1}
                onPress={(e) => e.stopPropagation()}
                style={styles.modalContentWrapper}
              >
                <BlurView intensity={90} tint="dark" style={styles.modalContent}>
                  <View style={styles.jobCardBackground} />
                  <View style={[styles.jobCardBorder, { borderColor: 'rgba(135,206,235,0.4)' }]} />
                  
                  {/* Header with Icon */}
                  <View style={styles.modalHeader}>
                    <View style={styles.modalHeaderLeft}>
                      <View style={styles.modalIconWrapper}>
                        <LinearGradient
                          colors={['rgba(135,206,235,0.4)', 'rgba(59,130,246,0.3)']}
                          style={styles.modalIconGradient}
                        >
                          <Ionicons name="location" size={32} color={SKY} />
                        </LinearGradient>
                      </View>
                      <View style={styles.modalTitleContainer}>
                        <Text style={styles.modalTitle}>Add New Location</Text>
                        <Text style={styles.modalSubtitle}>Create a new service location</Text>
                      </View>
                    </View>
                    <TouchableOpacity
                      onPress={() => {
                        hapticFeedback('light');
                        setShowAddModal(false);
                      }}
                      style={styles.modalCloseButton}
                    >
                      <Ionicons name="close" size={22} color="#F9FAFB" />
                    </TouchableOpacity>
                  </View>

                  {/* Form */}
                  <ScrollView
                    showsVerticalScrollIndicator={false}
                    keyboardShouldPersistTaps="handled"
                    style={styles.modalScrollView}
                    contentContainerStyle={styles.modalScrollContent}
                  >
                    <View style={styles.modalBody}>
                      {/* Location Name Input */}
                      <View style={styles.inputGroup}>
                        <View style={styles.inputLabelContainer}>
                          <Ionicons name="business-outline" size={18} color={SKY} />
                          <Text style={styles.inputLabel}>Location Name</Text>
                        </View>
                        <Text style={styles.inputHint}>Give your location a memorable name</Text>
                        <BlurView intensity={40} tint="dark" style={styles.inputContainerBlur}>
                          <View style={styles.inputInner}>
                            <Ionicons name="pricetag-outline" size={20} color="rgba(135,206,235,0.6)" style={styles.inputIcon} />
                            <TextInput
                              style={styles.textInput}
                              placeholder="e.g., Main Car Wash Hub"
                              placeholderTextColor="rgba(249,250,251,0.4)"
                              value={newLocationName}
                              onChangeText={setNewLocationName}
                              autoCapitalize="words"
                              autoFocus={true}
                            />
                          </View>
                        </BlurView>
                      </View>

                      {/* Address Input */}
                      <View style={styles.inputGroup}>
                        <View style={styles.inputLabelContainer}>
                          <Ionicons name="map-outline" size={18} color={SKY} />
                          <Text style={styles.inputLabel}>Full Address</Text>
                        </View>
                        <Text style={styles.inputHint}>Include street, city, and postcode</Text>
                        <BlurView intensity={40} tint="dark" style={styles.inputContainerBlur}>
                          <View style={styles.inputInner}>
                            <Ionicons name="location-outline" size={20} color="rgba(135,206,235,0.6)" style={styles.inputIcon} />
                            <TextInput
                              style={[styles.textInput, styles.textArea]}
                              placeholder="Enter full address"
                              placeholderTextColor="rgba(249,250,251,0.4)"
                              value={newLocationAddress}
                              onChangeText={setNewLocationAddress}
                              multiline
                              numberOfLines={3}
                              autoCapitalize="words"
                            />
                          </View>
                        </BlurView>
                      </View>

                      {/* Action Buttons */}
                      <View style={styles.modalActions}>
                        <TouchableOpacity
                          onPress={() => {
                            hapticFeedback('light');
                            setShowAddModal(false);
                          }}
                          style={styles.cancelButton}
                          activeOpacity={0.8}
                        >
                          <Text style={styles.cancelButtonText}>Cancel</Text>
                        </TouchableOpacity>

                        <TouchableOpacity
                          onPress={handleAddLocation}
                          style={styles.saveButton}
                          disabled={saving}
                          activeOpacity={0.8}
                        >
                          <LinearGradient
                            colors={[SKY, '#3B82F6']}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 0 }}
                            style={styles.saveButtonGradient}
                          >
                            {saving ? (
                              <ActivityIndicator size="small" color="#FFFFFF" />
                            ) : (
                              <>
                                <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                                <Text style={styles.saveButtonText}>Add Location</Text>
                              </>
                            )}
                          </LinearGradient>
                        </TouchableOpacity>
                      </View>
                    </View>
                  </ScrollView>
                </BlurView>
              </TouchableOpacity>
            </TouchableOpacity>
          </KeyboardAvoidingView>
        </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 24,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  addButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    minHeight: 400,
  },
  emptyCard: {
    padding: 40,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '600',
    marginTop: 20,
    marginBottom: 12,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  addFirstButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addFirstButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 32,
  },
  addFirstButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
  locationsList: {
    gap: 16,
  },
  locationCard: {
    padding: 16,
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  locationIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  locationInfo: {
    flex: 1,
  },
  locationName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 6,
  },
  locationAddress: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    lineHeight: 20,
  },
  deleteButton: {
    width: 36,
    height: 36,
    borderRadius: 8,
    backgroundColor: 'rgba(239,68,68,0.85)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(220,38,38,0.6)',
  },
  deleteButtonInner: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(220,38,38,0.6)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  locationFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.85)',
    justifyContent: 'flex-end',
  },
  modalContentWrapper: {
    width: '100%',
    maxHeight: '90%',
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    overflow: 'hidden',
  },
  modalContent: {
    width: '100%',
    padding: 0,
    borderTopLeftRadius: 32,
    borderTopRightRadius: 32,
    borderBottomLeftRadius: 0,
    borderBottomRightRadius: 0,
    overflow: 'visible',
    borderWidth: 1,
    backgroundColor: 'transparent',
    elevation: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    position: 'relative',
  },
  modalScrollView: {
    maxHeight: 500,
  },
  modalScrollContent: {
    paddingBottom: 20,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    padding: 28,
    paddingBottom: 24,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.2)',
  },
  modalHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 16,
    flex: 1,
  },
  modalIconWrapper: {
    width: 64,
    height: 64,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  modalIconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalTitleContainer: {
    flex: 1,
    gap: 4,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 26,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  modalSubtitle: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 14,
    fontWeight: '500',
    marginTop: 2,
  },
  modalCloseButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(249,250,251,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(249,250,251,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalBody: {
    padding: 28,
    gap: 28,
    paddingBottom: 32,
  },
  inputGroup: {
    gap: 12,
  },
  inputLabelContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  inputLabel: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  inputHint: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 13,
    fontWeight: '500',
    marginTop: -4,
    marginBottom: 4,
  },
  inputContainerBlur: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  inputInner: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    padding: 18,
    gap: 14,
  },
  inputIcon: {
    marginTop: 2,
  },
  textInput: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    padding: 0,
    minHeight: 24,
  },
  textArea: {
    minHeight: 80,
    textAlignVertical: 'top',
    paddingTop: 0,
  },
  modalActions: {
    flexDirection: 'row',
    gap: 14,
    marginTop: 12,
  },
  cancelButton: {
    flex: 1,
    paddingVertical: 16,
    paddingHorizontal: 20,
    borderRadius: 16,
    backgroundColor: 'rgba(249,250,251,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(249,250,251,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  cancelButtonText: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 16,
    fontWeight: '600',
  },
  saveButton: {
    flex: 1.5,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 12,
    shadowColor: businessTheme.primary,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
  },
  saveButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    letterSpacing: 0.3,
  },
  content: {
    flex: 1,
  },
  mapContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  mapLoadingContainer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  mapLoadingText: {
    color: SKY,
    fontSize: 14,
    marginTop: 12,
  },
  locationMarker: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'transparent',
    borderWidth: 0,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  spongeMarkerImage: {
    width: 48,
    height: 48,
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    backgroundColor: 'transparent',
    elevation: 10,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
  },
  locationCardContainer: {
    position: 'absolute',
    bottom: 20,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
  locationCardScrollItem: {
    width: width - 40,
    marginRight: 20,
  },
  locationCardWrapper: {
    width: '100%',
    overflow: 'visible',
  },
  locationCardBlur: {
    padding: 20,
    paddingBottom: 24,
    minHeight: 200,
    borderRadius: 20,
    overflow: 'visible',
    borderWidth: 1,
    backgroundColor: 'transparent',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
  },
  locationCardHeader: {
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  locationCardHeaderContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  servicePreviewIcon: {
    width: 28,
    height: 28,
    borderRadius: 8,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  locationCardHeaderText: {
    flex: 1,
  },
  locationCardTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    flex: 1,
  },
  locationCardAddress: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 14,
    marginTop: 4,
  },
  locationCardHeaderRight: {
    alignItems: 'flex-end',
  },
  statusBadgeSmall: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
  },
  statusDotSmall: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  statusTextSmall: {
    fontSize: 12,
    fontWeight: '600',
  },
  locationStatsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    gap: 12,
    marginTop: 12,
    marginBottom: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.08)',
  },
  locationStatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  locationStatText: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 12,
    fontWeight: '600',
  },
  locationStatEmoji: {
    fontSize: 12,
  },
  locationStatusSection: {
    marginBottom: 16,
  },
  statusToggleButton: {
    alignSelf: 'flex-start',
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    backgroundColor: 'rgba(239,68,68,0.2)',
    borderWidth: 1.5,
    borderColor: 'rgba(239,68,68,0.3)',
  },
  statusPillOpen: {
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderColor: 'rgba(16,185,129,0.3)',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#EF4444',
  },
  statusDotOpen: {
    backgroundColor: '#10B981',
  },
  statusText: {
    color: '#EF4444',
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  statusTextOpen: {
    color: '#10B981',
  },
  locationCardActions: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 8,
  },
  actionButton: {
    flex: 1,
    borderRadius: 14,
    overflow: 'hidden',
  },
  viewBookingsButton: {
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
  },
  actionButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    gap: 8,
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  manageButton: {
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  manageButtonBlur: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    gap: 8,
    borderRadius: 14,
    backgroundColor: 'transparent',
    position: 'relative',
  },
  manageButtonBackground: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 14,
  },
  manageButtonText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  headerIndicatorContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
    paddingBottom: 12,
  },
  headerIndicatorDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  headerIndicatorDotActive: {
    width: 24,
    backgroundColor: SKY,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  headerActionButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  locationMarkerSelected: {
    transform: [{ scale: 1.15 }],
    borderColor: SKY,
  },
  deleteButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(239,68,68,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.75)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContentWrapper: {
    width: '100%',
    maxWidth: 400,
    borderRadius: 24,
    overflow: 'hidden',
  },
  modalContent: {
    padding: 0,
    borderRadius: 24,
    overflow: 'visible',
    borderWidth: 1,
    backgroundColor: 'transparent',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
    maxHeight: '80%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 24,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.15)',
  },
  modalScrollView: {
    maxHeight: 500,
  },
  inputContainer: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    minHeight: 50,
  },
  emptyContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    padding: 20,
  },
  emptyCard: {
    padding: 40,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
  },
  popupOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.75)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  popupContent: {
    width: '100%',
    maxWidth: 400,
    maxHeight: '80%',
    borderRadius: 24,
    overflow: 'hidden',
  },
  popupBlur: {
    padding: 0,
    borderRadius: 24,
    overflow: 'visible',
    borderWidth: 1,
    backgroundColor: 'transparent',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
  },
  jobCardBackground: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 24,
  },
  jobCardBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 24,
    borderWidth: 1,
    pointerEvents: 'none',
  },
  popupCloseButton: {
    position: 'absolute',
    top: 16,
    right: 16,
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
  },
  popupCoverContainer: {
    width: '100%',
    height: 200,
    overflow: 'hidden',
  },
  popupCoverImage: {
    width: '100%',
    height: '100%',
  },
  popupBody: {
    padding: 24,
    gap: 16,
  },
  popupTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  popupDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  popupDetailText: {
    color: '#E5E7EB',
    fontSize: 15,
    flex: 1,
  },
  popupStatusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
  },
  popupStatusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  popupStatusText: {
    color: '#9CA3AF',
    fontSize: 14,
    fontWeight: '600',
  },
  popupViewButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    marginTop: 8,
  },
  popupViewButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
  },
  popupViewButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  locationStatsUnderHeader: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 100, // Above map but below header overlay (1000)
    flexDirection: 'row',
    gap: 12,
    backgroundColor: 'transparent',
    paddingRight: 8, // Space for close button
  },
  locationStatBox: {
    flex: 1,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.05)',
  },
  statsCloseButton: {
    position: 'absolute',
    top: -6,
    right: -6,
    zIndex: 200,
  },
  statsCloseButtonBlur: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  locationStatBoxContent: {
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    padding: 12,
  },
  locationStatLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 11,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  locationStatValue: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  mapStatText: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '600',
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
  },
});
