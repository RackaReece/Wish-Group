import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Switch,
  ActivityIndicator,
  Alert,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { WASH_DEFINITIONS, WashDefinition, getVehicleSizeAdjustmentGBP, VehicleSize } from '../../src/pricing/pricingEngine';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

interface Service {
  id: string;
  name: string;
  enabled: boolean;
  price?: number;
  priceFrom?: number;
  priceTo?: number;
  description?: string;
  washDefinitionId?: string; // Link to WASH_DEFINITIONS
}

export default function BusinessServices() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [services, setServices] = useState<Service[]>([]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadServices();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadServices = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      // Convert WASH_DEFINITIONS to Service format for business configuration
      // Only include mobile wash services (not physical location only)
      const washServices: Service[] = WASH_DEFINITIONS
        .filter(wash => wash.isMobile) // Only mobile services
        .map((wash, index) => {
          // Calculate price range: SMALL (base) to XL (base + max adjustment)
          const basePrice = wash.basePriceSmallGBP;
          const smallPrice = basePrice; // SMALL = base price
          const xlPrice = basePrice + getVehicleSizeAdjustmentGBP('XL'); // XL = base + £7
          
          return {
            id: wash.id,
            name: wash.label,
            enabled: true, // Default to enabled
            price: basePrice, // Base price for small vehicle (for compatibility)
            priceFrom: smallPrice,
            priceTo: xlPrice,
            description: wash.description,
            washDefinitionId: wash.id,
          };
        });
      
      // Try to load saved service configurations from database
      // For now, use the wash definitions as default
      setServices(washServices);
    } catch (error) {
      console.error('Error loading services:', error);
      Alert.alert('Error', 'Failed to load services');
    } finally {
      setLoading(false);
    }
  };

  const toggleService = async (serviceId: string) => {
    if (!user?.id) return;
    try {
      await hapticFeedback('light');
      setServices(prev =>
        prev.map(s => (s.id === serviceId ? { ...s, enabled: !s.enabled } : s))
      );

      // Save to database
      // This would update your organization_services table
      // await supabase.from('organization_services').upsert({...});
    } catch (error) {
      console.error('Error toggling service:', error);
      Alert.alert('Error', 'Failed to update service');
    }
  };

  const handleSave = async () => {
    if (!user?.id) return;
    try {
      setSaving(true);
      await hapticFeedback('medium');
      // Save all service configurations
      Alert.alert('Success', 'Services configuration saved successfully');
    } catch (error) {
      console.error('Error saving services:', error);
      Alert.alert('Error', 'Failed to save services configuration');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Services Configuration" accountType="business" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Services Configuration"
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          },
        ]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <View style={styles.headerSection}>
            <Text style={styles.sectionTitle}>Services & Pricing</Text>
            <Text style={styles.sectionSubtitle}>
              Manage your available wash services and pricing ranges
            </Text>
          </View>

          <View style={styles.servicesList}>
            {services.map((service, index) => {
              const washDef = WASH_DEFINITIONS.find(w => w.id === service.washDefinitionId);
              const isEco = washDef?.isEco || false;
              const tier = washDef?.tier || 'BRONZE';
              
              return (
                <GlassCard key={service.id} style={styles.serviceCard} accountType="business">
                  <LinearGradient
                    colors={service.enabled 
                      ? ['rgba(96,217,255,0.08)', 'rgba(96,217,255,0.02)']
                      : ['rgba(255,255,255,0.04)', 'rgba(255,255,255,0.01)']
                    }
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={styles.serviceContent}>
                    <View style={styles.serviceInfo}>
                      <View style={styles.serviceHeader}>
                        <View style={styles.serviceTitleRow}>
                          <Text style={styles.serviceName}>{service.name}</Text>
                          <View style={styles.badgeRow}>
                            {isEco && (
                              <View style={styles.ecoBadge}>
                                <Ionicons name="leaf" size={11} color="#10B981" />
                                <Text style={styles.ecoBadgeText}>Eco</Text>
                              </View>
                            )}
                            {tier && (
                              <View style={[styles.tierBadge, { backgroundColor: getTierColor(tier) }]}>
                                <Text style={styles.tierBadgeText}>{tier}</Text>
                              </View>
                            )}
                          </View>
                        </View>
                        {service.description && (
                          <Text style={styles.serviceDescription} numberOfLines={2}>
                            {service.description}
                          </Text>
                        )}
                      </View>
                      
                      <View style={styles.priceRangeContainer}>
                        <View style={styles.priceRangeHeader}>
                          <Ionicons name="wallet-outline" size={14} color={businessTheme.primary} />
                          <Text style={styles.priceRangeLabel}>Price Range</Text>
                        </View>
                        <View style={styles.priceRangeValues}>
                          <View style={styles.priceBox}>
                            <Text style={styles.priceFromLabel}>From</Text>
                            <Text style={styles.priceFrom}>£{service.priceFrom?.toFixed(2) || '0.00'}</Text>
                          </View>
                          <View style={styles.priceSeparatorLine} />
                          <View style={styles.priceBox}>
                            <Text style={styles.priceToLabel}>To</Text>
                            <Text style={styles.priceTo}>£{service.priceTo?.toFixed(2) || '0.00'}</Text>
                          </View>
                        </View>
                        <Text style={styles.priceNote}>
                          Varies by vehicle size (Small to XL) and distance
                        </Text>
                      </View>
                    </View>
                    
                    <View style={styles.switchContainer}>
                      <Switch
                        value={service.enabled}
                        onValueChange={() => toggleService(service.id)}
                        trackColor={{ false: 'rgba(255,255,255,0.15)', true: businessTheme.primary }}
                        thumbColor={service.enabled ? '#FFFFFF' : '#9CA3AF'}
                        ios_backgroundColor="rgba(255,255,255,0.15)"
                      />
                      <Text style={[styles.switchLabel, !service.enabled && styles.switchLabelDisabled]}>
                        {service.enabled ? 'Active' : 'Inactive'}
                      </Text>
                    </View>
                  </View>
                </GlassCard>
              );
            })}
          </View>

          <TouchableOpacity
            style={[styles.saveButton, saving && styles.saveButtonDisabled]}
            onPress={handleSave}
            disabled={saving}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={[businessTheme.primary, businessTheme.primaryAlt]}
              style={styles.saveButtonGradient}
            >
              {saving ? (
                <ActivityIndicator size="small" color="#FFFFFF" />
              ) : (
                <>
                  <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                  <Text style={styles.saveButtonText}>Save Changes</Text>
                </>
              )}
            </LinearGradient>
          </TouchableOpacity>
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

// Helper function to get tier color
const getTierColor = (tier: string): string => {
  switch (tier) {
    case 'BRONZE':
      return 'rgba(205,127,50,0.2)';
    case 'SILVER':
      return 'rgba(192,192,192,0.2)';
    case 'GOLD':
      return 'rgba(255,215,0,0.2)';
    case 'PLATINUM':
      return 'rgba(229,228,226,0.2)';
    default:
      return 'rgba(255,255,255,0.1)';
  }
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: isSmallScreen ? 16 : 20,
  },
  content: {
    gap: SPACING.lg,
  },
  headerSection: {
    marginBottom: 8,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '600',
    marginBottom: 8,
    letterSpacing: -0.3,
  },
  sectionSubtitle: {
    color: 'rgba(249,250,251,0.70)',
    fontSize: 15,
    fontWeight: '500',
    lineHeight: 22,
  },
  servicesList: {
    gap: SPACING.md,
  },
  serviceCard: {
    borderRadius: 20,
    padding: 0,
    marginBottom: 12,
    overflow: 'hidden',
  },
  serviceContent: {
    padding: 18,
    gap: 16,
  },
  serviceInfo: {
    flex: 1,
    gap: 12,
  },
  serviceHeader: {
    gap: 8,
  },
  serviceTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    gap: 8,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    letterSpacing: -0.2,
    flex: 1,
  },
  badgeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  ecoBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(16,185,129,0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.25)',
  },
  ecoBadgeText: {
    color: '#10B981',
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  tierBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  tierBadgeText: {
    color: '#F9FAFB',
    fontSize: 9,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  priceRangeContainer: {
    padding: 14,
    borderRadius: 16,
    backgroundColor: 'rgba(96,217,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(96,217,255,0.15)',
    gap: 10,
  },
  priceRangeHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  priceRangeLabel: {
    color: 'rgba(249,250,251,0.70)',
    fontSize: 13,
    fontWeight: '600',
  },
  priceRangeValues: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  priceBox: {
    flex: 1,
    alignItems: 'center',
    gap: 4,
  },
  priceFromLabel: {
    color: 'rgba(249,250,251,0.60)',
    fontSize: 11,
    fontWeight: '600',
  },
  priceFrom: {
    color: businessTheme.primary,
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  priceSeparatorLine: {
    width: 1,
    height: 30,
    backgroundColor: 'rgba(255,255,255,0.15)',
  },
  priceToLabel: {
    color: 'rgba(249,250,251,0.60)',
    fontSize: 11,
    fontWeight: '600',
  },
  priceTo: {
    color: businessTheme.primary,
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  priceNote: {
    color: 'rgba(249,250,251,0.60)',
    fontSize: 11,
    fontWeight: '500',
    textAlign: 'center',
    marginTop: 2,
  },
  serviceDescription: {
    color: 'rgba(249,250,251,0.70)',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
  },
  switchContainer: {
    alignItems: 'center',
    gap: 8,
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.15)',
  },
  switchLabel: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '700',
  },
  switchLabelDisabled: {
    color: 'rgba(249,250,251,0.50)',
  },
  saveButton: {
    marginTop: SPACING.lg,
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: businessTheme.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  saveButtonDisabled: {
    opacity: 0.6,
  },
  saveButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingVertical: 16,
    paddingHorizontal: 24,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
});

