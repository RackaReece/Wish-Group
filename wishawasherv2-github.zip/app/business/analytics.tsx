import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING, getMetricCardWidth } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const businessTheme = getAccountTheme('business');

export default function BusinessAnalytics() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      // Simulate loading
      setTimeout(() => setLoading(false), 1000);
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Analytics" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading analytics...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Analytics"
        scrollY={scrollY}
        enableScrollAnimation={true}
        accountType="business"
      />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={[
          styles.scrollContent, 
          { 
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          }
        ]}
      >
        {/* Overview Stats - Horizontal Scroll */}
        <View style={styles.statsSection}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Key Metrics</Text>
          </View>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.statsScrollContainer}
          >
            <Animated.View 
              style={[
                { opacity: fadeAnim },
                {
                  transform: [
                    {
                      translateX: fadeAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [20, 0],
                      }),
                    },
                  ],
                },
              ]}
            >
              <GlassCard style={styles.statCard} accountType="business">
                <LinearGradient
                  colors={['rgba(96,217,255,0.20)', 'rgba(59,197,232,0.12)', 'rgba(0,0,0,0.05)']}
                  style={styles.statGradient}
                >
                  <View style={styles.statIconWrapper}>
                    <LinearGradient
                      colors={['rgba(96,217,255,0.35)', 'rgba(59,197,232,0.25)']}
                      style={styles.statIconGradient}
                    >
                      <Ionicons name="trending-up" size={26} color="#60D9FF" />
                    </LinearGradient>
                  </View>
                  <View style={styles.statTextContainer}>
                    <Text style={styles.statValue}>£0</Text>
                    <Text style={styles.statLabel}>Total Revenue</Text>
                  </View>
                </LinearGradient>
              </GlassCard>
            </Animated.View>

            <Animated.View 
              style={[
                { opacity: fadeAnim },
                {
                  transform: [
                    {
                      translateX: fadeAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [20, 0],
                      }),
                    },
                  ],
                },
              ]}
            >
              <GlassCard style={styles.statCard} accountType="business">
                <LinearGradient
                  colors={['rgba(16,185,129,0.20)', 'rgba(5,150,105,0.12)', 'rgba(0,0,0,0.05)']}
                  style={styles.statGradient}
                >
                  <View style={[styles.statIconWrapper, styles.statIconWrapperGreen]}>
                    <LinearGradient
                      colors={['rgba(16,185,129,0.35)', 'rgba(5,150,105,0.25)']}
                      style={styles.statIconGradient}
                    >
                      <Ionicons name="calendar" size={26} color="#10B981" />
                    </LinearGradient>
                  </View>
                  <View style={styles.statTextContainer}>
                    <Text style={styles.statValue}>0</Text>
                    <Text style={styles.statLabel}>Total Bookings</Text>
                  </View>
                </LinearGradient>
              </GlassCard>
            </Animated.View>

            <Animated.View 
              style={[
                { opacity: fadeAnim },
                {
                  transform: [
                    {
                      translateX: fadeAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [20, 0],
                      }),
                    },
                  ],
                },
              ]}
            >
              <GlassCard style={styles.statCard} accountType="business">
                <LinearGradient
                  colors={['rgba(59,130,246,0.20)', 'rgba(37,99,235,0.12)', 'rgba(0,0,0,0.05)']}
                  style={styles.statGradient}
                >
                  <View style={[styles.statIconWrapper, styles.statIconWrapperBlue]}>
                    <LinearGradient
                      colors={['rgba(59,130,246,0.35)', 'rgba(37,99,235,0.25)']}
                      style={styles.statIconGradient}
                    >
                      <Ionicons name="people" size={26} color="#3B82F6" />
                    </LinearGradient>
                  </View>
                  <View style={styles.statTextContainer}>
                    <Text style={styles.statValue}>0</Text>
                    <Text style={styles.statLabel}>Active Valeters</Text>
                  </View>
                </LinearGradient>
              </GlassCard>
            </Animated.View>

            <Animated.View 
              style={[
                { opacity: fadeAnim },
                {
                  transform: [
                    {
                      translateX: fadeAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [20, 0],
                      }),
                    },
                  ],
                },
              ]}
            >
              <GlassCard style={styles.statCard} accountType="business">
                <LinearGradient
                  colors={['rgba(251,191,36,0.20)', 'rgba(245,158,11,0.12)', 'rgba(0,0,0,0.05)']}
                  style={styles.statGradient}
                >
                  <View style={[styles.statIconWrapper, styles.statIconWrapperYellow]}>
                    <LinearGradient
                      colors={['rgba(251,191,36,0.35)', 'rgba(245,158,11,0.25)']}
                      style={styles.statIconGradient}
                    >
                      <Ionicons name="star" size={26} color="#FBBF24" />
                    </LinearGradient>
                  </View>
                  <View style={styles.statTextContainer}>
                    <Text style={styles.statValue}>0.0</Text>
                    <Text style={styles.statLabel}>Avg Rating</Text>
                  </View>
                </LinearGradient>
              </GlassCard>
            </Animated.View>
          </ScrollView>
        </View>

        {/* Charts Section */}
        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Revenue Trends</Text>
          <GlassCard style={styles.emptyCard} accountType="business">
            <View style={styles.emptyContent}>
              <Ionicons name="bar-chart-outline" size={40} color="#87CEEB" style={{ opacity: 0.6 }} />
              <Text style={styles.emptyTitle}>No data yet</Text>
              <Text style={styles.emptyText}>
                Revenue charts will appear here as your business grows
              </Text>
            </View>
          </GlassCard>
        </Animated.View>

        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Booking Trends</Text>
          <GlassCard style={styles.emptyCard} accountType="business">
            <View style={styles.emptyContent}>
              <Ionicons name="trending-up-outline" size={40} color="#87CEEB" style={{ opacity: 0.6 }} />
              <Text style={styles.emptyTitle}>No data yet</Text>
              <Text style={styles.emptyText}>
                Booking trends will be displayed here once you have bookings
              </Text>
            </View>
          </GlassCard>
        </Animated.View>

        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Valeter Performance</Text>
          <GlassCard style={styles.emptyCard} accountType="business">
            <View style={styles.emptyContent}>
              <Ionicons name="people-outline" size={40} color="#87CEEB" style={{ opacity: 0.6 }} />
              <Text style={styles.emptyTitle}>No data yet</Text>
              <Text style={styles.emptyText}>
                Valeter performance metrics will appear here
              </Text>
            </View>
          </GlassCard>
        </Animated.View>

        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <Text style={styles.sectionTitle}>Location Breakdown</Text>
          <GlassCard style={styles.emptyCard} accountType="business">
            <View style={styles.emptyContent}>
              <Ionicons name="location-outline" size={40} color="#87CEEB" style={{ opacity: 0.6 }} />
              <Text style={styles.emptyTitle}>No data yet</Text>
              <Text style={styles.emptyText}>
                Revenue breakdown by location will be shown here
              </Text>
            </View>
          </GlassCard>
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  statsSection: {
    marginBottom: 24,
  },
  sectionHeader: {
    marginBottom: 12,
  },
  statsScrollContainer: {
    paddingRight: 20,
    gap: 14,
  },
  statCard: {
    width: Math.min(width * 0.75, 280),
    padding: 0,
    overflow: 'hidden',
    borderRadius: 22,
    marginRight: 14,
  },
  statGradient: {
    padding: 20,
    minHeight: 140,
    justifyContent: 'space-between',
  },
  statIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 16,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(96,217,255,0.3)',
  },
  statIconWrapperGreen: {
    borderColor: 'rgba(16,185,129,0.3)',
  },
  statIconWrapperBlue: {
    borderColor: 'rgba(59,130,246,0.3)',
  },
  statIconWrapperYellow: {
    borderColor: 'rgba(251,191,36,0.3)',
  },
  statIconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  statTextContainer: {
    gap: 6,
  },
  statValue: {
    color: '#F9FAFB',
    fontSize: 32,
    fontWeight: '900',
    letterSpacing: -0.5,
    lineHeight: 36,
  },
  statLabel: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    marginBottom: 12,
    letterSpacing: 0.2,
  },
  emptyCard: {
    ...CARD_SIZES.large,
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
});
