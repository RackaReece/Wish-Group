import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  ScrollView,
  StatusBar,
  Image,
} from 'react-native';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Video, ResizeMode } from 'expo-av';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';

const { width, height } = Dimensions.get('window');

import { Ionicons } from '@expo/vector-icons';

interface OnboardingSlide {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  iconName: keyof typeof Ionicons.glyphMap;
  color: string;
}

const slides: OnboardingSlide[] = [
  {
    id: 1,
    title: 'Wish a Wash',
    subtitle: 'The First AI-Powered Car Care Platform',
    description: 'Revolutionizing the industry by seamlessly connecting professional valeters with customers through intelligent matching, real-time tracking, and premium service delivery.',
    iconName: 'car-sport',
    color: '#87CEEB',
  },
  {
    id: 2,
    title: 'Smart Booking System',
    subtitle: 'AI-Powered Scheduling',
    description: 'Our intelligent platform matches you with the perfect valeter, suggests optimal times, and handles all the logistics. Book in seconds, not minutes.',
    iconName: 'bulb',
    color: '#4CAF50',
  },
  {
    id: 3,
    title: 'Fair Pricing',
    subtitle: 'Win-Win for Everyone',
    description: 'Transparent pricing that ensures fair compensation for valeters while keeping costs reasonable for customers. Everyone wins with our balanced approach.',
    iconName: 'scale',
    color: '#9C27B0',
  },
  {
    id: 4,
    title: 'Live Tracking',
    subtitle: 'Real-Time Updates',
    description: 'Track your valeter\'s location in real-time and receive instant updates on arrival time. Know exactly when your professional valeter will arrive.',
    iconName: 'location',
    color: '#2196F3',
  },
  {
    id: 5,
    title: 'Premium Quality',
    subtitle: 'Excellence Guaranteed',
    description: 'Expert valeters with professional-grade equipment and eco-friendly products. Your vehicle receives the highest standard of care and attention to detail.',
    iconName: 'leaf',
    color: '#4CAF50',
  },
  {
    id: 6,
    title: 'Secure & Reliable',
    subtitle: 'Your Safety Matters',
    description: 'All valeters are verified professionals with background checks. Secure payments, insurance coverage, and 24/7 support ensure peace of mind.',
    iconName: 'shield-checkmark',
    color: '#87CEEB',
  },
  {
    id: 7,
    title: 'Ready to Get Started?',
    subtitle: 'Join Thousands of Happy Customers',
    description: 'Experience the future of car care. Book your first wash today and discover why Wish a Wash is the UK\'s leading car care platform.',
    iconName: 'rocket',
    color: '#9C27B0',
  },
];

export default function OnboardingScreen() {
  const [currentSlide, setCurrentSlide] = useState(0);
  const scrollViewRef = useRef<ScrollView>(null);
  
  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const iconAnim = useRef(new Animated.Value(0)).current;
  const progressAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Initial animations
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(iconAnim, {
        toValue: 1,
        duration: 1200,
        useNativeDriver: true,
      }),
    ]).start();

    // Progress animation
    Animated.timing(progressAnim, {
      toValue: (currentSlide + 1) / slides.length,
      duration: 500,
      useNativeDriver: false,
    }).start();
  }, [currentSlide]);

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      const nextSlide = currentSlide + 1;
      setCurrentSlide(nextSlide);
      scrollViewRef.current?.scrollTo({
        x: nextSlide * width,
        animated: true,
      });
    } else {
      handleGetStarted();
    }
  };

  const handleSkip = () => {
    handleGetStarted();
  };

  const handleGetStarted = async () => {
    try {
      // Mark onboarding as seen
      await AsyncStorage.setItem('onboarding_seen', 'true');
      router.replace('/login');
    } catch (error) {
      console.error('Error saving onboarding status:', error);
      router.replace('/login');
    }
  };

  const handleScroll = (event: any) => {
    const offsetX = event.nativeEvent.contentOffset.x;
    const slideIndex = Math.round(offsetX / width);
    if (slideIndex !== currentSlide) {
      setCurrentSlide(slideIndex);
    }
  };

  const renderSlide = (slide: OnboardingSlide, _index: number) => {
    // const isActive = index === currentSlide;
    
    return (
      <View key={slide.id} style={[styles.slide, { width }]}>
        <Animated.View
            style={[
            styles.iconContainer,
            {
              transform: [
                {
                  scale: iconAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0.5, 1],
                  }),
                },
              ],
            },
          ]}
        >
          {slide.id === 1 ? (
            <BlurView intensity={20} tint="dark" style={styles.logoBlurContainer}>
              <Image 
                source={require('../assets/auth-page.png')} 
                style={styles.logoImage} 
                resizeMode="cover" 
              />
            </BlurView>
          ) : (
            <BlurView intensity={20} tint="dark" style={styles.iconBlurContainer}>
              <View style={[styles.iconInnerContainer, {
                backgroundColor: slide.color + '25',
                borderColor: slide.color + '60',
              }]}>
                <Ionicons name={slide.iconName} size={72} color={slide.color} />
              </View>
            </BlurView>
          )}
        </Animated.View>

        <Animated.View
          style={[
            styles.content,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <Text style={styles.title}>{slide.title}</Text>
          <Text style={styles.subtitle}>{slide.subtitle}</Text>
          <Text style={styles.description}>{slide.description}</Text>
        </Animated.View>
      </View>
    );
  };

  const videoRef = useRef<Video>(null);

  useEffect(() => {
    // Play video in loop when component mounts
    const playVideo = async () => {
      try {
        if (videoRef.current) {
          await videoRef.current.loadAsync(require('../assets/water-rain.mp4'));
          await videoRef.current.playAsync();
          videoRef.current.setIsLoopingAsync(true);
          videoRef.current.setIsMutedAsync(true);
        }
      } catch (error) {
        console.error('Error playing video:', error);
      }
    };
    
    playVideo();
    
    return () => {
      // Cleanup on unmount
      videoRef.current?.unloadAsync();
    };
  }, []);

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      
      {/* Video Background */}
      <Video
        ref={videoRef}
        source={require('../assets/water-rain.mp4')}
        style={styles.videoBackground}
        resizeMode={ResizeMode.COVER}
        isLooping
        isMuted
        shouldPlay
        useNativeControls={false}
      />
      
      {/* Dark overlay - minimal for brightness */}
      <View style={styles.overlay} />
      
      {/* Gradient overlay - very minimal for sharp, bright video */}
      <LinearGradient
        colors={['rgba(10,25,41,0.05)', 'rgba(10,25,41,0.08)', 'rgba(10,25,41,0.1)']}
        style={styles.gradientOverlay}
      />
      
      {/* Progress Bar */}
      <View style={styles.progressContainer}>
        <View style={styles.progressBar}>
          <Animated.View
            style={[
              styles.progressFill,
              {
                width: progressAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: ['0%', '100%'],
                }),
              },
            ]}
          />
        </View>
        <TouchableOpacity style={styles.skipButton} onPress={handleSkip}>
          <Text style={styles.skipText}>Skip</Text>
        </TouchableOpacity>
      </View>

      {/* Slides */}
      <ScrollView
        ref={scrollViewRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        style={styles.scrollView}
      >
        {slides.map((slide, index) => renderSlide(slide, index))}
      </ScrollView>

      {/* Enhanced Navigation */}
      <View style={styles.navigation}>
        <View style={styles.navigationLeft}>
          <View style={styles.dots}>
            {slides.map((_, index) => (
              <Animated.View
                key={index}
                style={[
                  styles.dot,
                  index === currentSlide && styles.activeDot,
                  {
                    transform: [
                      {
                        scale: index === currentSlide ? 1.2 : 1,
                      },
                    ],
                  },
                ]}
              />
            ))}
          </View>
        </View>

        <View style={styles.navigationRight}>
          <TouchableOpacity style={styles.nextButton} onPress={handleNext}>
            <Text style={styles.nextButtonText}>
              {currentSlide === slides.length - 1 ? 'Get Started' : 'Next'}
            </Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  videoBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    width: width,
    height: height,
    zIndex: 0,
    pointerEvents: 'none',
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.05)',
    zIndex: 1,
    pointerEvents: 'none',
  },
  gradientOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 2,
    pointerEvents: 'none',
  },
  progressContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    zIndex: 10,
    position: 'relative',
  },
  progressBar: {
    flex: 1,
    height: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 2,
    marginRight: 20,
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#87CEEB',
    borderRadius: 2,
  },
  skipButton: {
    paddingHorizontal: 15,
    paddingVertical: 8,
  },
  skipText: {
    fontFamily: 'Rubik_600SemiBold',
    color: '#B0E0E6',
    fontSize: 16,
    letterSpacing: 0.2,
  },
  scrollView: {
    flex: 1,
    zIndex: 10,
    position: 'relative',
  },
  slide: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
    paddingVertical: 60,
  },
  iconContainer: {
    marginBottom: 50,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoBlurContainer: {
    width: 180,
    height: 180,
    borderRadius: 90,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 12,
  },
  logoImage: {
    width: '100%',
    height: '100%',
    borderRadius: 90,
  },
  iconBlurContainer: {
    width: 180,
    height: 180,
    borderRadius: 90,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 12,
  },
  iconInnerContainer: {
    width: '100%',
    height: '100%',
    borderRadius: 90,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
  },
  content: {
    alignItems: 'center',
  },
  title: {
    fontFamily: 'Rubik_600SemiBold',
    fontSize: 32,
    color: '#fff',
    textAlign: 'center',
    marginBottom: 10,
    letterSpacing: -0.3,
    lineHeight: 38,
  },
  subtitle: {
    fontFamily: 'Rubik_600SemiBold',
    fontSize: 20,
    color: '#87CEEB',
    textAlign: 'center',
    marginBottom: 20,
    letterSpacing: -0.2,
    lineHeight: 26,
  },
  description: {
    fontFamily: 'Rubik_400Regular',
    fontSize: 16,
    color: '#B0E0E6',
    textAlign: 'center',
    lineHeight: 24,
    paddingHorizontal: 20,
    letterSpacing: 0,
  },
  navigation: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 50,
    zIndex: 10,
    position: 'relative',
  },
  navigationLeft: {
    flex: 1,
    alignItems: 'flex-start',
  },
  navigationRight: {
    flex: 1,
    alignItems: 'flex-end',
  },
  dots: {
    flexDirection: 'row',
    gap: 8,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  activeDot: {
    backgroundColor: '#87CEEB',
    width: 24,
  },
  nextButton: {
    backgroundColor: '#87CEEB',
    borderRadius: 25,
    paddingHorizontal: 30,
    paddingVertical: 15,
    minWidth: 120,
    alignItems: 'center',
    shadowColor: '#87CEEB',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 8,
  },
  nextButtonText: {
    fontFamily: 'Rubik_600SemiBold',
    color: '#0A1929',
    fontSize: 16,
    letterSpacing: 0.2,
  },
});
