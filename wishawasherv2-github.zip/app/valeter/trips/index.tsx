import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Image,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import MapView, { Marker, Region } from 'react-native-maps';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import * as Location from 'expo-location';

import { colors } from '../../../src/constants/colors';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

type JobStatus =
  | 'pending_payment'
  | 'confirmed'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed';

const ACTIVE_STATUSES: JobStatus[] = ['confirmed', 'en_route', 'arrived', 'in_progress'];

export default function TripsPage() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const insets = useSafeAreaInsets();

  const jobIdParam = typeof params.jobId === 'string' ? params.jobId : undefined;
  const jobId = jobIdParam && jobIdParam !== 'undefined' ? jobIdParam : null;

  const [activeJob, setActiveJob] = useState<any | null>(null);
  const [customerName, setCustomerName] = useState('Customer');
  const [status, setStatus] = useState<JobStatus>('pending_payment');
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const [initialRegion, setInitialRegion] = useState<Region | null>(null);
  const [tripsLoading, setTripsLoading] = useState(true);
  const [valeterLocation, setValeterLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [locationPermission, setLocationPermission] = useState<Location.PermissionStatus | null>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const mapRef = useRef<MapView>(null);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(markerPulse, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Request location permission and get user location
    const requestLocationPermission = async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        setLocationPermission(status);
        
        if (status === 'granted') {
          const location = await Location.getCurrentPositionAsync({
            accuracy: Location.Accuracy.High,
          });
          setUserLocation({
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
          });
        }
      } catch (error) {
        console.error('Error getting location:', error);
      }
    };
    
    requestLocationPermission();
    loadValeterLocation();

    if (jobId) {
      loadJob();
      subscribeToJob();
    } else {
      loadActiveJob();
      subscribeToJob();
    }
  }, [jobId, user?.id]);

  // Watch user location for live updates
  useEffect(() => {
    if (locationPermission !== 'granted') return;
    
    const subscription = Location.watchPositionAsync(
      {
        accuracy: Location.Accuracy.High,
        distanceInterval: 100, // Update every 100 meters
        timeInterval: 30000, // Or every 30 seconds
      },
      (location) => {
        setUserLocation({
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        });
      }
    );

    return () => {
      subscription.then(sub => sub.remove());
    };
  }, [locationPermission]);

  const loadValeterLocation = async () => {
    if (!user?.id) return;
    try {
      const { data } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', user.id)
        .single();

      if (data?.last_lat && data?.last_lng) {
        setValeterLocation({ lat: data.last_lat, lng: data.last_lng });
        const newRegion = {
          latitude: data.last_lat,
          longitude: data.last_lng,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        };
        setRegion(newRegion);
        setInitialRegion(newRegion);
      }
    } catch (error) {
      console.error('Error loading valeter location:', error);
    }
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (activeJob && activeJob.location_lat && activeJob.location_lng) {
      const newRegion: Region = {
        latitude: activeJob.location_lat,
        longitude: activeJob.location_lng,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      };
      setRegion(newRegion);
      mapRef.current?.animateToRegion(newRegion, 500);
    } else if (initialRegion) {
      setRegion(initialRegion);
      mapRef.current?.animateToRegion(initialRegion, 500);
    } else if (userLocation) {
      const newRegion: Region = {
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      };
      setRegion(newRegion);
      mapRef.current?.animateToRegion(newRegion, 500);
    }
  };

  const loadActiveJob = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id)
        .in('status', ACTIVE_STATUSES)
        .order('request_sent_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setActiveJob(data);
        setStatus(data.status);

        if (data?.user_id) {
          const profile = await fetchProfileById(data.user_id);
          setCustomerName(profile?.full_name || 'Customer');

          // Fetch vehicle information
          try {
            const { data: vehicle } = await supabase
              .from('customer_vehicles')
              .select('registration, make, model, type')
              .eq('user_id', data.user_id)
              .eq('is_default', true)
              .single();

            if (vehicle) {
              // Store vehicle info in activeJob state
              setActiveJob({
                ...data,
                vehicle_registration: vehicle.registration || null,
                vehicle_make: vehicle.make || null,
                vehicle_model: vehicle.model || null,
                vehicle_type: vehicle.type || data.vehicle_type || null,
              });
            }
          } catch (error) {
            console.warn('Error fetching vehicle info:', error);
          }
        }

        if (data.location_lat && data.location_lng) {
          const newRegion = {
            latitude: data.location_lat,
            longitude: data.location_lng,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          };
          setRegion(newRegion);
          if (!initialRegion) {
            setInitialRegion(newRegion);
          }
        }
      }
    } catch (error) {
      console.error('Error loading active job:', error);
    } finally {
      setTripsLoading(false);
    }
  };

  const loadJob = async () => {
    if (!jobId) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', jobId)
        .single();

      if (error) throw error;

      setActiveJob(data);
      setStatus(data.status);

      if (data?.user_id) {
        const profile = await fetchProfileById(data.user_id);
        setCustomerName(profile?.full_name || 'Customer');

        // Fetch vehicle information
        try {
          const { data: vehicle } = await supabase
            .from('customer_vehicles')
            .select('registration, make, model, type')
            .eq('user_id', data.user_id)
            .eq('is_default', true)
            .single();

          if (vehicle) {
            // Store vehicle info in activeJob state
            setActiveJob({
              ...data,
              vehicle_registration: vehicle.registration || null,
              vehicle_make: vehicle.make || null,
              vehicle_model: vehicle.model || null,
              vehicle_type: vehicle.type || data.vehicle_type || null,
            });
          }
        } catch (error) {
          console.warn('Error fetching vehicle info:', error);
        }
      } else {
        setCustomerName('Customer');
      }

      if (data.location_lat && data.location_lng) {
        const newRegion = {
          latitude: data.location_lat,
          longitude: data.location_lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        };
        setRegion(newRegion);
        if (!initialRegion) {
          setInitialRegion(newRegion);
        }
      }
    } catch (error) {
      console.error('Error loading job:', error);
    } finally {
      setTripsLoading(false);
    }
  };

  const subscribeToJob = () => {
    const idToSub = jobId ?? activeJob?.id;
    if (!idToSub) return undefined;

    const channel = supabase
      .channel(`job-${idToSub}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${idToSub}`,
        },
        (payload) => {
          const updated = payload.new as any;
          setStatus(updated.status);

          if (updated.status === 'completed') {
            router.replace({
              pathname: '/valeter/jobs/complete',
              params: { jobId: idToSub },
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleRefresh = async () => {
    setTripsLoading(true);
    if (jobId) {
      await loadJob();
    } else {
      await loadActiveJob();
    }
  };

  const assertNoOtherActiveJob = async (currentBookingId: string) => {
    if (!user?.id) return;

    const { data, error } = await supabase
      .from('bookings')
      .select('id,status')
      .eq('valeter_id', user.id)
      .in('status', ACTIVE_STATUSES)
      .neq('id', currentBookingId)
      .order('request_sent_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;

    if (data?.id) {
      throw new Error(
        `You already have another active job (${data.status}). Finish it first before starting service on this one.`
      );
    }
  };

  const updateStatus = async (newStatus: JobStatus) => {
    if (!user?.id) return;
    await hapticFeedback('medium');

    const idToUpdate = jobId ?? activeJob?.id;
    if (!idToUpdate) {
      return;
    }

    try {
      if (newStatus === 'in_progress') {
        await assertNoOtherActiveJob(idToUpdate);
      }

      const { error } = await supabase
        .from('bookings')
        .update({ status: newStatus })
        .eq('id', idToUpdate);

      if (error) throw error;
      setStatus(newStatus);
    } catch (error: any) {
      const pgCode = error?.code || error?.details?.code;

      if (
        pgCode === '23505' ||
        String(error?.message || '').toLowerCase().includes('duplicate key value') ||
        String(error?.message || '').includes('ux_active_job_per_valeter')
      ) {
        return;
      }
    }
  };

  const getStatusProgress = (): number => {
    switch (status) {
      case 'pending_payment':
        return 20;
      case 'confirmed':
        return 40;
      case 'en_route':
        return 60;
      case 'arrived':
        return 80;
      case 'in_progress':
        return 90;
      case 'completed':
        return 100;
      default:
        return 0;
    }
  };

  const getStatusMessage = (): string => {
    switch (status) {
      case 'pending_payment':
        return 'Waiting for customer payment';
      case 'confirmed':
        return 'Payment received - Ready to start';
      case 'en_route':
        return 'On the way to location';
      case 'arrived':
        return 'Arrived at location';
      case 'in_progress':
        return 'Service in progress';
      case 'completed':
        return 'Service completed';
      default:
        return 'Tracking job';
    }
  };

  const getNextAction = (): { label: string; action: () => void } | null => {
    switch (status) {
      case 'pending_payment':
        return null;
      case 'confirmed':
        return {
          label: 'Start Journey',
          action: () => updateStatus('en_route'),
        };
      case 'en_route':
        return {
          label: 'Mark Arrived',
          action: () => updateStatus('arrived'),
        };
      case 'arrived':
        return {
          label: 'Start Service',
          action: () => updateStatus('in_progress'),
        };
      case 'in_progress':
        return {
          label: 'Complete Service',
          action: () => updateStatus('completed'),
        };
      default:
        return null;
    }
  };

  const renderMap = () => {
    return (
      <View style={styles.mapContainer}>
        <MapView
          ref={mapRef}
          style={styles.map}
          region={region}
          showsUserLocation={true}
          showsMyLocationButton={false}
          mapType="standard"
          mapPadding={{ top: 0, bottom: height * 0.4, left: 0, right: 0 }}
          loadingEnabled={true}
          loadingIndicatorColor={SKY}
          followsUserLocation={false}
          userLocationPriority="high"
          userLocationUpdateInterval={5000}
        >
          {valeterLocation && (
            <Marker
              coordinate={{
                latitude: valeterLocation.lat,
                longitude: valeterLocation.lng,
              }}
              anchor={{ x: 0.5, y: 0.5 }}
            >
              <View style={styles.valeterMarker}>
                <View style={styles.valeterMarkerShadow} />
                <View style={styles.valeterMarkerIcon}>
                  <Ionicons name="car" size={18} color="#FFFFFF" />
                </View>
              </View>
            </Marker>
          )}
          {activeJob && activeJob.location_lat && activeJob.location_lng && (
            <Marker
              coordinate={{
                latitude: activeJob.location_lat,
                longitude: activeJob.location_lng,
              }}
              anchor={{ x: 0.5, y: 0.5 }}
            >
              <Animated.View
                style={[
                  styles.markerContainer,
                  {
                    transform: [{ scale: markerPulse }],
                  },
                ]}
              >
                <View style={styles.marker}>
                  <Image
                    source={require('../../../assets/car.png')}
                    style={styles.carMarkerImage}
                    resizeMode="contain"
                  />
                </View>
              </Animated.View>
            </Marker>
          )}
        </MapView>
      </View>
    );
  };

  const nextAction = getNextAction();

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
        {renderMap()}
        
        <View style={styles.headerOverlay}>
          <AppHeader
            title="Trips"
            rightAction={
              <View style={styles.headerActions}>
                <TouchableOpacity
                  onPress={handleRecenter}
                  style={styles.recenterButton}
                >
                  <Ionicons name="locate" size={20} color={SKY} />
                </TouchableOpacity>
                <TouchableOpacity onPress={handleRefresh} style={styles.refreshButton}>
                  <Ionicons name="refresh" size={20} color={SKY} />
                </TouchableOpacity>
              </View>
            }
            accountType="valeter"
          />
        </View>

        {!activeJob ? (
          <View style={[styles.emptyContainer, { paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20 }]}>
            <BlurView intensity={60} tint="dark" style={styles.emptyCard}>
              <View style={styles.jobCardBackground} />
              <View style={[styles.jobCardBorder, { borderColor: 'rgba(135,206,235,0.3)' }]} />
              <View style={styles.emptyContent}>
                <Ionicons name="navigate-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
                <Text style={styles.emptyTitle}>No Active Trip</Text>
                <Text style={styles.emptyText}>
                  You don't have any active trips to track at the moment. Check the jobs page for available opportunities.
                </Text>
              </View>
            </BlurView>
          </View>
        ) : (
          <Animated.View
            style={[
              styles.cardContainer,
              {
                opacity: fadeAnim,
                bottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
              },
            ]}
          >
            <BlurView intensity={60} tint="dark" style={styles.trackingCard}>
              <View style={styles.jobCardBackground} />
              <View style={[styles.jobCardBorder, { borderColor: 'rgba(135,206,235,0.3)' }]} />
              
              <View style={styles.trackingHeader}>
                <StatusBadge status={status} size="medium" />
                <Text style={styles.statusMessage}>{getStatusMessage()}</Text>
              </View>

              <View style={styles.progressContainer}>
                <AnimatedProgress progress={getStatusProgress()} size={120} />
              </View>

              <View style={styles.jobInfo}>
                <View style={styles.infoRow}>
                  <Ionicons name="water-outline" size={16} color={SKY} />
                  <Text style={styles.infoText}>
                    {getServiceDisplayName(activeJob.service_type, activeJob.service_name)}
                  </Text>
                </View>

                {activeJob.user_id && (
                  <View style={styles.infoRow}>
                    <Ionicons name="person-outline" size={16} color={SKY} />
                    <Text style={styles.infoText}>{customerName}</Text>
                  </View>
                )}

              <View style={styles.infoRow}>
                <Ionicons name="location-outline" size={16} color={SKY} />
                <Text style={styles.infoText} numberOfLines={1}>
                  {activeJob.location_address}
                </Text>
              </View>

              {/* Vehicle Information */}
              {((activeJob as any).vehicle_registration || (activeJob as any).vehicle_type || (activeJob as any).vehicle_make || (activeJob as any).vehicle_model) && (
                <View style={styles.infoRow}>
                  <Ionicons name="car-sport-outline" size={16} color={SKY} />
                  <View style={styles.vehicleInfoContainer}>
                    {(activeJob as any).vehicle_registration && (
                      <Text style={styles.vehicleRegistration}>{(activeJob as any).vehicle_registration}</Text>
                    )}
                    {((activeJob as any).vehicle_make || (activeJob as any).vehicle_model || (activeJob as any).vehicle_type) && (
                      <Text style={styles.infoText}>
                        {[((activeJob as any).vehicle_make), ((activeJob as any).vehicle_model), ((activeJob as any).vehicle_type)].filter(Boolean).join(' ')}
                      </Text>
                    )}
                  </View>
                </View>
              )}

              <View style={styles.infoRow}>
                <Ionicons name="cash-outline" size={16} color={SKY} />
                <Text style={styles.infoText}>
                  £{activeJob.price?.toFixed(2) || '0.00'}
                </Text>
              </View>
            </View>

              {nextAction && (
                <TouchableOpacity
                  onPress={nextAction.action}
                  style={styles.actionButton}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={[SKY, '#3B82F6']}
                    style={styles.actionGradient}
                  >
                    <Text style={styles.actionText}>{nextAction.label}</Text>
                    <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                  </LinearGradient>
                </TouchableOpacity>
              )}
            </BlurView>
          </Animated.View>
        )}
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  content: {
    flex: 1,
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    backgroundColor: 'transparent',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  refreshButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  mapContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  valeterMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  valeterMarkerShadow: {
    position: 'absolute',
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: SKY,
    opacity: 0.3,
  },
  valeterMarkerIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#FFFFFF',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  marker: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
  },
  carMarkerImage: {
    width: 48,
    height: 48,
  },
  jobCardBackground: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 24,
  },
  jobCardBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 24,
    borderWidth: 1,
    pointerEvents: 'none',
  },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    padding: 20,
  },
  trackingCard: {
    padding: 20,
    paddingBottom: 24,
    minHeight: 250,
    borderRadius: 20,
    overflow: 'visible',
    borderWidth: 1,
    backgroundColor: 'transparent',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
  },
  trackingHeader: {
    alignItems: 'center',
    marginBottom: 20,
  },
  statusMessage: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginTop: 12,
    textAlign: 'center',
  },
  progressContainer: {
    alignItems: 'center',
    marginBottom: 24,
  },
  jobInfo: {
    gap: 12,
    marginBottom: 20,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  infoText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
  },
  vehicleInfoContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  vehicleRegistration: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 1,
    fontFamily: 'monospace',
  },
  actionButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  actionGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 8,
  },
  actionText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  emptyContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    padding: 20,
  },
  emptyCard: {
    padding: 40,
    borderRadius: 20,
    overflow: 'visible',
    borderWidth: 1,
    backgroundColor: 'transparent',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
  },
});
