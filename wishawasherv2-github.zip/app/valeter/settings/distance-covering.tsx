import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Alert,
  ActivityIndicator,
  StatusBar,
  Dimensions,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { supabase } from '../../../src/lib/supabase';
import { Ionicons } from '@expo/vector-icons';
import { fetchRadiusPreference, RadiusColumn } from '../../../src/utils/radiusPreference';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';


interface RadiusOption {
  value: number;
  label: string;
  description: string;
  color: string;
  icon: keyof typeof Ionicons.glyphMap;
}


export default function DistanceCovering() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const [selectedRadius, setSelectedRadius] = useState(10);
  const [isLoading, setIsLoading] = useState(false);
  const [isLoadingRadius, setIsLoadingRadius] = useState(true);

  const [radiusColumn, setRadiusColumn] = useState<RadiusColumn>('working_radius');
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const radiusOptions: RadiusOption[] = [
    { value: 5, label: '5 miles', description: 'Local area coverage', color: '#10B981', icon: 'home' },
    { value: 10, label: '10 miles', description: 'City district coverage', color: '#3B82F6', icon: 'business' },
    { value: 15, label: '15 miles', description: 'Extended city coverage', color: '#87CEEB', icon: 'location' },
    { value: 20, label: '20 miles', description: 'Metropolitan area coverage', color: '#F59E0B', icon: 'map' },
    { value: 25, label: '25 miles', description: 'Wide area coverage', color: '#EF4444', icon: 'globe' },
    { value: 30, label: '30 miles', description: 'Maximum coverage area', color: '#5BA3C7', icon: 'rocket' },
  ];

  useEffect(() => {
    loadCurrentRadius();
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);


  const loadCurrentRadius = async () => {
    if (!user?.id) return;

    try {
      setIsLoadingRadius(true);
      const { value, column } = await fetchRadiusPreference(user.id);
      setRadiusColumn(column);

      if (typeof value === 'number') setSelectedRadius(value);
      else setSelectedRadius(10);
    } catch (error) {
      console.error('Error loading radius:', error);
    } finally {
      setIsLoadingRadius(false);
    }
  };


  const handleRadiusSelect = async (radius: number) => {
    try {
      await hapticFeedback('light');
      setSelectedRadius(radius);
    } catch {
      // ignore
    }
  };

  const selectedOption = radiusOptions.find(opt => opt.value === selectedRadius);


  const handleSaveRadius = async () => {
    if (!user?.id) {
      Alert.alert('Error', 'Please sign in to update your settings.');
      return;
    }

    try {
      setIsLoading(true);
      await hapticFeedback('medium');

      const { data: existingProfile } = await supabase
        .from('valeter_profiles')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      const buildPayload = (column: RadiusColumn) => ({
        [column]: selectedRadius,
      });

      let error: any;

      if (existingProfile) {
        const { error: updateError } = await supabase
          .from('valeter_profiles')
          .update(buildPayload(radiusColumn))
          .eq('user_id', user.id);
        error = updateError;
      } else {
        const { error: insertError } = await supabase
          .from('valeter_profiles')
          .insert({ user_id: user.id, ...buildPayload(radiusColumn), is_online: false });
        error = insertError;
      }

      if (error && error.code === '42703' && radiusColumn === 'working_radius') {
        setRadiusColumn('radius_coverage');
        const fallbackPayload = buildPayload('radius_coverage');

        if (existingProfile) {
          const { error: legacyUpdateError } = await supabase
            .from('valeter_profiles')
            .update(fallbackPayload)
            .eq('user_id', user.id);
          error = legacyUpdateError;
        } else {
          const { error: legacyInsertError } = await supabase
            .from('valeter_profiles')
            .insert({ user_id: user.id, ...fallbackPayload, is_online: false });
          error = legacyInsertError;
        }
      }

      if (error && (error.code === '42703' || error.code === 'PGRST204')) {
        Alert.alert(
          'Database Migration Required',
          `Some columns need to be added. Please run this SQL in Supabase:

ALTER TABLE valeter_profiles ADD COLUMN IF NOT EXISTS working_radius INTEGER DEFAULT 10;
ALTER TABLE valeter_profiles ADD COLUMN IF NOT EXISTS availability_schedule JSONB;

Your notification preferences are saved locally on this device.`,
          [{ text: 'OK', onPress: () => router.back() }]
        );
        return;
      }

      if (error) throw error;

      Alert.alert('Settings Updated', `Your settings have been saved successfully.`, [
        { text: 'OK', onPress: () => router.back() },
      ]);
    } catch (error: any) {
      console.error('Error saving settings:', error);
      Alert.alert('Error', error.message || 'Failed to save settings. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const getRadiusDescription = (radius: number) => {
    switch (radius) {
      case 5:
        return 'Perfect for local neighbourhood work';
      case 10:
        return 'Ideal for city district coverage';
      case 15:
        return 'Great for extended city areas';
      case 20:
        return 'Covers metropolitan areas';
      case 25:
        return 'Wide coverage for busy areas';
      case 30:
        return 'Maximum coverage for high-demand areas';
      default:
        return 'Select your preferred coverage area';
    }
  };

  if (isLoadingRadius) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={['#0A1929', '#2563EB']} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <View style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
          <ActivityIndicator size="large" color="#3B82F6" />
          <Text style={{ color: '#FFFFFF', marginTop: 16 }}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={['#0A1929', '#2563EB']} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader title="Settings" accountType="valeter" />

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{
          paddingTop: HEADER_CONTENT_OFFSET + 12,
          paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          paddingHorizontal: 20,
        }}
      >
        <Animated.View style={{ opacity: fadeAnim }}>
          <View style={styles.currentSelection}>
            <Text style={styles.currentSelectionTitle}>Current Radius</Text>
            <GlassCard style={styles.currentRadiusCard} accountType="valeter">
              <View style={styles.currentRadiusContent}>
                <View style={styles.currentRadiusIconWrapper}>
                  <Ionicons name="location" size={32} color={colors.SKY} />
                </View>
                <Text style={styles.currentRadiusValue}>{selectedRadius} miles</Text>
                <Text style={styles.currentRadiusDescription}>{getRadiusDescription(selectedRadius)}</Text>
              </View>
            </GlassCard>
          </View>
        </Animated.View>

        <Animated.View style={[styles.optionsSection, { opacity: fadeAnim }]}>
          <View style={styles.sectionHeader}>
            <Text style={styles.sectionTitle}>Select Your Working Radius</Text>
            <Text style={styles.sectionSubtitle}>Choose how you're willing to travel for jobs</Text>
          </View>

          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.radiusScrollContainer}
            style={styles.radiusScrollView}
          >
            {radiusOptions.map((option) => {
              const isSelected = selectedRadius === option.value;
              return (
                <TouchableOpacity
                  key={option.value}
                  onPress={() => handleRadiusSelect(option.value)}
                  activeOpacity={0.8}
                  style={styles.radiusCardWrapper}
                >
                  <GlassCard
                    style={[
                      styles.radiusCard,
                      isSelected && styles.radiusCardSelected,
                    ]}
                    accountType="valeter"
                  >
                    <LinearGradient
                      colors={
                        isSelected
                          ? [`${option.color}25`, `${option.color}15`]
                          : ['rgba(255, 255, 255, 0.05)', 'rgba(255, 255, 255, 0.02)']
                      }
                      style={styles.radiusCardGradient}
                    >
                      <View style={styles.radiusCardContent}>
                        <View style={[
                          styles.radiusCardIconWrapper,
                          isSelected && { backgroundColor: `${option.color}25`, borderColor: `${option.color}50` }
                        ]}>
                          <Ionicons
                            name={option.icon}
                            size={28}
                            color={isSelected ? option.color : colors.SKY}
                          />
                        </View>
                        
                        <Text
                          style={[
                            styles.radiusCardLabel,
                            isSelected && { color: option.color },
                          ]}
                        >
                          {option.label}
                        </Text>
                        <Text style={styles.radiusCardDescription}>
                          {option.description}
                        </Text>

                        {isSelected && (
                          <View style={[styles.radiusSelectedBadge, { backgroundColor: `${option.color}20` }]}>
                            <Ionicons name="checkmark-circle" size={20} color={option.color} />
                          </View>
                        )}
                      </View>
                    </LinearGradient>
                  </GlassCard>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        </Animated.View>

      </ScrollView>

      <View style={styles.bottomSection}>
        <TouchableOpacity
          style={[styles.saveButton, isLoading && styles.saveButtonDisabled]}
          onPress={handleSaveRadius}
          disabled={isLoading}
          activeOpacity={0.8}
        >
          <LinearGradient colors={[colors.SKY, '#2563EB']} style={styles.saveButtonGradient}>
            {isLoading ? (
              <ActivityIndicator size="small" color="#FFFFFF" />
            ) : (
              <>
                <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" style={{ marginRight: 8 }} />
                <Text style={styles.saveButtonText}>Save Settings</Text>
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1 },

  currentSelection: { marginBottom: 24 },
  currentSelectionTitle: { 
    color: '#F9FAFB', 
    fontSize: 22, 
    fontWeight: '800', 
    letterSpacing: 0.2,
    marginBottom: 12 
  },
  currentRadiusCard: { 
    padding: 24,
    borderRadius: 20,
  },
  currentRadiusContent: {
    alignItems: 'center',
    gap: 12,
  },
  currentRadiusIconWrapper: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
    marginBottom: 4,
  },
  currentRadiusValue: { 
    color: colors.SKY, 
    fontSize: 36, 
    fontWeight: '800', 
    letterSpacing: 0.2,
  },
  currentRadiusDescription: { 
    color: 'rgba(249,250,251,0.85)', 
    fontSize: 15, 
    textAlign: 'center', 
    lineHeight: 22,
    fontWeight: '500',
  },

  optionsSection: { marginBottom: 24 },
  sectionHeader: {
    marginBottom: 16,
    gap: 4,
  },
  sectionTitle: { 
    color: '#F9FAFB', 
    fontSize: 22, 
    fontWeight: '600', 
    letterSpacing: 0.2,
  },
  sectionSubtitle: { 
    color: 'rgba(249,250,251,0.7)', 
    fontSize: 14, 
    fontWeight: '600',
    lineHeight: 20 
  },

  radiusScrollView: {
    marginTop: 12,
  },
  radiusScrollContainer: {
    paddingRight: 20,
    gap: 12,
  },
  radiusCardWrapper: {
    width: Dimensions.get('window').width * 0.75,
    maxWidth: 280,
    marginRight: 12,
  },
  radiusCard: {
    borderRadius: 20,
    padding: 0,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.1)',
    minHeight: 180,
  },
  radiusCardSelected: {
    borderWidth: 2.5,
    borderColor: 'rgba(135,206,235,0.4)',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  radiusCardGradient: {
    padding: 20,
    borderRadius: 20,
    flex: 1,
  },
  radiusCardContent: {
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    flex: 1,
  },
  radiusCardIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
    marginBottom: 4,
  },
  radiusCardLabel: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: 0.2,
    textAlign: 'center',
  },
  radiusCardDescription: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 18,
    textAlign: 'center',
    paddingHorizontal: 8,
  },
  radiusSelectedBadge: {
    position: 'absolute',
    top: 12,
    right: 12,
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.2)',
  },


  bottomSection: { 
    paddingHorizontal: 20, 
    paddingTop: 20,
    paddingBottom: 40,
    borderTopWidth: 1, 
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    backgroundColor: 'transparent',
  },
  saveButton: { 
    borderRadius: 20, 
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
  },
  saveButtonDisabled: { opacity: 0.6 },
  saveButtonGradient: { 
    paddingVertical: 18, 
    paddingHorizontal: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  saveButtonText: { 
    color: '#FFFFFF', 
    fontSize: 17, 
    fontWeight: '800',
    letterSpacing: 0.2,
  },


});
