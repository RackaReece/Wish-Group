import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  TextInput,
  Switch,
  ScrollView,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;

interface DaySchedule {
  enabled: boolean;
  startTime: string;
  endTime: string;
}

interface AvailabilitySchedule {
  monday: DaySchedule;
  tuesday: DaySchedule;
  wednesday: DaySchedule;
  thursday: DaySchedule;
  friday: DaySchedule;
  saturday: DaySchedule;
  sunday: DaySchedule;
}

const DEFAULT_AVAILABILITY: AvailabilitySchedule = {
  monday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  tuesday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  wednesday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  thursday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  friday: { enabled: true, startTime: '08:00', endTime: '18:00' },
  saturday: { enabled: true, startTime: '09:00', endTime: '17:00' },
  sunday: { enabled: false, startTime: '09:00', endTime: '17:00' },
};

export default function WorkingHours() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  
  const [loading, setLoading] = useState(true);
  const [availabilitySchedule, setAvailabilitySchedule] = useState<AvailabilitySchedule>(DEFAULT_AVAILABILITY);
  const [saving, setSaving] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (user?.id) {
      loadAvailabilitySchedule();
    } else {
      setLoading(false);
    }
  }, [user?.id]);

  const loadAvailabilitySchedule = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const { data: profile, error } = await supabase
        .from('valeter_profiles')
        .select('availability_schedule')
        .eq('user_id', user.id)
        .maybeSingle();

      if (error) throw error;

      if (profile?.availability_schedule) {
        setAvailabilitySchedule(profile.availability_schedule as AvailabilitySchedule);
      }
    } catch (error) {
      console.error('Error loading availability schedule:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDayToggle = async (day: keyof AvailabilitySchedule) => {
    try {
      await hapticFeedback('light');
      const newSchedule = {
        ...availabilitySchedule,
        [day]: { ...availabilitySchedule[day], enabled: !availabilitySchedule[day].enabled },
      };
      setAvailabilitySchedule(newSchedule);

      if (user?.id) {
        setSaving(true);
        const { error } = await supabase
          .from('valeter_profiles')
          .update({ availability_schedule: newSchedule })
          .eq('user_id', user.id);
        
        if (error) throw error;
        setSaving(false);
      }
    } catch (error) {
      console.error('Error updating availability schedule:', error);
      setSaving(false);
    }
  };

  const handleTimeChange = async (day: keyof AvailabilitySchedule, field: 'startTime' | 'endTime', value: string) => {
    try {
      // Validate time format (HH:MM)
      const timeRegex = /^([0-1]?[0-9]|2[0-3]):[0-5][0-9]$/;
      if (!timeRegex.test(value) && value !== '') {
        return; // Invalid format, don't update
      }

      const newSchedule = {
        ...availabilitySchedule,
        [day]: { ...availabilitySchedule[day], [field]: value },
      };
      setAvailabilitySchedule(newSchedule);

      // Auto-save after a delay
      if (user?.id) {
        setTimeout(async () => {
          setSaving(true);
          const { error } = await supabase
            .from('valeter_profiles')
            .update({ availability_schedule: newSchedule })
            .eq('user_id', user.id);
          
          if (error) {
            console.error('Error updating time:', error);
          }
          setSaving(false);
        }, 1000);
      }
    } catch (error) {
      console.error('Error updating time:', error);
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={[BG, '#2563EB']} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <AppHeader title="Working Hours" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading schedule...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[BG, '#2563EB']} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader title="Working Hours" />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollContent,
            {
              paddingTop: HEADER_CONTENT_OFFSET + 20,
            },
          ]}
        >
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <View style={styles.sectionHeaderIcon}>
                <Ionicons name="time-outline" size={24} color={SKY} />
              </View>
              <View style={styles.sectionHeaderText}>
                <Text style={styles.sectionTitle}>Set Your Availability</Text>
                <Text style={styles.sectionSubtitle}>Define when you're available for jobs</Text>
              </View>
            </View>
            
            <GlassCard style={styles.scheduleCard} accountType="valeter">
              <LinearGradient
                colors={['rgba(135,206,235,0.08)', 'rgba(135,206,235,0.02)']}
                style={StyleSheet.absoluteFill}
              />
              {(['monday', 'tuesday', 'wednesday', 'thursday', 'friday', 'saturday', 'sunday'] as const).map((day, index) => {
                const dayName = day.charAt(0).toUpperCase() + day.slice(1);
                const schedule = availabilitySchedule[day];
                const dayAbbr = dayName.substring(0, 3);
                const isWeekend = day === 'saturday' || day === 'sunday';
                
                return (
                  <View key={day}>
                    <TouchableOpacity
                      style={[
                        styles.scheduleDayCard,
                        schedule.enabled && styles.scheduleDayCardActive,
                        index === 6 && { marginBottom: 0 }
                      ]}
                      activeOpacity={0.8}
                    >
                      <View style={styles.scheduleDayContent}>
                        <View style={styles.scheduleDayLeft}>
                          <View style={[styles.scheduleDayBadge, schedule.enabled && styles.scheduleDayBadgeActive, isWeekend && styles.scheduleDayBadgeWeekend]}>
                            <Text style={[styles.scheduleDayAbbr, schedule.enabled && styles.scheduleDayAbbrActive]}>
                              {dayAbbr}
                            </Text>
                          </View>
                        </View>
                        
                        <View style={styles.scheduleMiddleSection}>
                          {schedule.enabled ? (
                            <View style={styles.scheduleTimeContainer}>
                              <View style={styles.scheduleTimeInput}>
                                <TextInput
                                  value={schedule.startTime}
                                  onChangeText={(value) => handleTimeChange(day, 'startTime', value)}
                                  placeholder="08:00"
                                  placeholderTextColor="rgba(16,185,129,0.5)"
                                  style={styles.scheduleTimeInputText}
                                  keyboardType="default"
                                  maxLength={5}
                                />
                              </View>
                              <Text style={styles.scheduleTimeSeparator}>-</Text>
                              <View style={styles.scheduleTimeInput}>
                                <TextInput
                                  value={schedule.endTime}
                                  onChangeText={(value) => handleTimeChange(day, 'endTime', value)}
                                  placeholder="18:00"
                                  placeholderTextColor="rgba(16,185,129,0.5)"
                                  style={styles.scheduleTimeInputText}
                                  keyboardType="default"
                                  maxLength={5}
                                />
                              </View>
                            </View>
                          ) : (
                            <View style={styles.scheduleOffBadge}>
                              <Text style={styles.scheduleOffText}>Off</Text>
                            </View>
                          )}
                        </View>
                        
                        <View style={styles.scheduleToggleWrapper}>
                          <Switch
                            value={schedule.enabled}
                            onValueChange={() => handleDayToggle(day)}
                            trackColor={{ false: 'rgba(255,255,255,0.2)', true: '#10B981' }}
                            thumbColor="#FFFFFF"
                            ios_backgroundColor="rgba(255,255,255,0.2)"
                          />
                        </View>
                      </View>
                    </TouchableOpacity>
                    {index < 6 && <View style={styles.scheduleDivider} />}
                  </View>
                );
              })}
            </GlassCard>

            {saving && (
              <View style={styles.savingIndicator}>
                <ActivityIndicator size="small" color={SKY} />
                <Text style={styles.savingText}>Saving...</Text>
              </View>
            )}
          </View>
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  section: {
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 12,
  },
  sectionHeaderIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sectionHeaderText: {
    flex: 1,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  sectionSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
  },
  scheduleCard: {
    padding: 16,
  },
  scheduleDayCard: {
    paddingVertical: 16,
    paddingHorizontal: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.03)',
  },
  scheduleDayCardActive: {
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  scheduleDayContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  scheduleDayLeft: {
    width: 48,
  },
  scheduleMiddleSection: {
    flex: 1,
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
  scheduleToggleWrapper: {
    width: 51,
    alignItems: 'flex-end',
  },
  scheduleDayBadge: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  scheduleDayBadgeActive: {
    backgroundColor: 'rgba(16,185,129,0.2)',
  },
  scheduleDayBadgeWeekend: {
    backgroundColor: 'rgba(245,158,11,0.2)',
  },
  scheduleDayAbbr: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
  },
  scheduleDayAbbrActive: {
    color: '#10B981',
  },
  scheduleTimeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    width: '100%',
  },
  scheduleTimeInput: {
    flex: 1,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  scheduleTimeInputText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
  scheduleTimeSeparator: {
    color: SKY,
    fontSize: 18,
    fontWeight: 'bold',
  },
  scheduleOffBadge: {
    width: '100%',
    alignItems: 'center',
  },
  scheduleOffText: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
  },
  scheduleDivider: {
    height: 1,
    backgroundColor: 'rgba(135,206,235,0.1)',
    marginVertical: 8,
  },
  savingIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 16,
  },
  savingText: {
    color: SKY,
    fontSize: 14,
  },
});
