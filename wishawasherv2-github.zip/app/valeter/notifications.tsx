import React, { useCallback, useEffect, useMemo, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  FlatList,
  RefreshControl,
  TouchableOpacity,
  Alert,
  Animated,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { colors } from '../../src/constants/colors';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

type JobStatus =
  | 'pending_payment'
  | 'confirmed'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed';

type DocumentType = 'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed';

type DocumentStatus = 'pending' | 'approved' | 'rejected' | 'not_uploaded';

type ValeterNotificationType = 'job' | 'document' | 'compliance' | 'system';

interface ValeterNotification {
  id: string;
  title: string;
  message: string;
  createdAt: string;
  type: ValeterNotificationType;
  status?: string;
  priority?: 'low' | 'medium' | 'high';
  actionRoute?: string;
  actionParams?: Record<string, string>;
}

interface BookingRow {
  id: string;
  status: JobStatus;
  service_type: string | null;
  service_name: string | null;
  location_address: string | null;
  updated_at: string | null;
  created_at: string | null;
}

interface ValeterDocumentRow {
  id: string;
  type: DocumentType;
  status: DocumentStatus;
  name: string | null;
  rejection_reason?: string | null;
  uploaded_at?: string | null;
  updated_at?: string | null;
}

const DOC_LABELS: Record<DocumentType, string> = {
  id_proof: 'Proof of Identity',
  selfie: 'Selfie Photo',
  profile_photo: 'Profile Photo',
  disclaimer_signed: 'Terms & Conditions',
};

export default function ValeterNotifications() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  
  const [notifications, setNotifications] = useState<ValeterNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const formatRelativeTime = useCallback((dateString: string) => {
    const date = new Date(dateString);
    if (Number.isNaN(date.getTime())) return '';
    const diff = Date.now() - date.getTime();
    const minute = 60 * 1000;
    const hour = 60 * minute;
    const day = 24 * hour;
    if (diff < minute) return 'Just now';
    if (diff < hour) {
      const m = Math.floor(diff / minute);
      return `${m} min${m === 1 ? '' : 's'} ago`;
    }
    if (diff < day) {
      const h = Math.floor(diff / hour);
      return `${h} hr${h === 1 ? '' : 's'} ago`;
    }
    const d = Math.floor(diff / day);
    if (d < 7) {
      return `${d} day${d === 1 ? '' : 's'} ago`;
    }
    return date.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  }, []);

  const mapJobNotification = useCallback((job: BookingRow): ValeterNotification => {
    const statusCopy: Record<JobStatus, { title: string; message: string; priority: 'low' | 'medium' | 'high' }> = {
      pending_payment: {
        title: 'Awaiting Payment',
        message: 'Customer needs to complete payment before work can begin.',
        priority: 'medium',
      },
      confirmed: {
        title: 'Job Confirmed',
        message: 'Payment received. You can start travelling when ready.',
        priority: 'medium',
      },
      en_route: {
        title: 'En Route',
        message: 'Marked as en route. Keep the customer updated.',
        priority: 'low',
      },
      arrived: {
        title: 'Arrived On Site',
        message: 'Remember to start the service when you begin washing.',
        priority: 'medium',
      },
      in_progress: {
        title: 'Service In Progress',
        message: 'Complete the checklist before finishing the job.',
        priority: 'low',
      },
      completed: {
        title: 'Job Completed',
        message: 'Nice work! Submit photos and completion details if required.',
        priority: 'low',
      },
    };

    const copy = statusCopy[job.status] ?? statusCopy.confirmed;
    const serviceName = job.service_name || job.service_type || 'Service';

    return {
      id: `job-${job.id}-${job.status}`,
      title: `${copy.title} · ${serviceName}`,
      message: copy.message,
      createdAt: job.updated_at || job.created_at || new Date().toISOString(),
      type: 'job',
      status: job.status,
      priority: copy.priority,
      actionRoute: '/valeter/jobs',
      actionParams: { jobId: job.id, tab: 'trips' },
    };
  }, []);

  const mapDocumentNotification = useCallback((doc: ValeterDocumentRow): ValeterNotification => {
    const baseTitle = DOC_LABELS[doc.type] || 'Document';
    let title = baseTitle;
    let message = '';
    let priority: ValeterNotification['priority'] = 'low';

    switch (doc.status) {
      case 'pending':
        title = `${baseTitle} pending review`;
        message = 'Hang tight—our compliance team is reviewing this upload.';
        priority = 'low';
        break;
      case 'approved':
        title = `${baseTitle} approved`;
        message = 'You are all set for this requirement.';
        priority = 'low';
        break;
      case 'rejected':
        title = `${baseTitle} rejected`;
        message = doc.rejection_reason
          ? doc.rejection_reason
          : 'Please resubmit this document with the requested corrections.';
        priority = 'high';
        break;
      case 'not_uploaded':
      default:
        title = `${baseTitle} missing`;
        message = 'Upload this document to stay compliant.';
        priority = 'high';
        break;
    }

    return {
      id: `doc-${doc.id}`,
      title,
      message,
      createdAt: doc.updated_at || doc.uploaded_at || new Date().toISOString(),
      type: 'document',
      status: doc.status,
      priority,
      actionRoute: '/valeter/profile/valeter-legal-compliance',
    };
  }, []);

  const computeComplianceReminder = useCallback(
    (documents: ValeterDocumentRow[] = [], profilePhotoUrl?: string | null): ValeterNotification | null => {
      const requiredTypes: DocumentType[] = ['id_proof', 'selfie', 'profile_photo', 'disclaimer_signed'];
      const uploadedTypes = documents.map((doc) => doc.type);
      let missingTypes = requiredTypes.filter((type) => !uploadedTypes.includes(type));

      const hasApprovedProfilePhoto = profilePhotoUrl || documents.some(
        (doc) => doc.type === 'profile_photo' && doc.status === 'approved'
      );
      if (!hasApprovedProfilePhoto && !missingTypes.includes('profile_photo')) {
        missingTypes = [...missingTypes, 'profile_photo'];
      }

      if (missingTypes.length === 0) {
        return null;
      }

      const missingNames = missingTypes.map((type) => DOC_LABELS[type]);

      return {
        id: `compliance-${missingTypes.join('-')}`,
        title: missingTypes.length === 1 ? 'Document Required' : 'Documents Required',
        message: `Upload ${missingNames.join(', ')} to stay compliant.`,
        createdAt: new Date().toISOString(),
        type: 'compliance',
        priority: missingTypes.length > 1 ? 'high' : 'medium',
        actionRoute: '/valeter/profile/valeter-legal-compliance',
      };
    },
    []
  );

  const fetchNotifications = useCallback(async () => {
    if (!user?.id) return;
    if (!refreshing) setLoading(true);
    try {
      const [jobsRes, docsRes, profileRes] = await Promise.all([
        supabase
          .from('bookings')
          .select('id,status,service_type,service_name,location_address,updated_at,created_at')
          .eq('valeter_id', user.id)
          .order('updated_at', { ascending: false })
          .limit(30),
        supabase
          .from('valeter_documents')
          .select('id,type,status,name,rejection_reason,uploaded_at,updated_at')
          .eq('user_id', user.id),
        supabase
          .from('valeter_profiles')
          .select('profile_photo_url')
          .eq('user_id', user.id)
          .maybeSingle(),
      ]);

      const jobNotifications =
        jobsRes.data?.map((job) => mapJobNotification(job as BookingRow)) ?? [];
      const documentNotifications =
        docsRes.data?.map((doc) => mapDocumentNotification(doc as ValeterDocumentRow)) ?? [];

      const complianceNotification = computeComplianceReminder(
        docsRes.data as ValeterDocumentRow[] | undefined,
        profileRes.data?.profile_photo_url
      );

      const combined = [
        ...jobNotifications,
        ...documentNotifications,
        ...(complianceNotification ? [complianceNotification] : []),
      ].sort(
        (a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
      );

      setNotifications(combined);
    } catch (error) {
      console.error('[ValeterNotifications] Failed to load notifications', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id, mapJobNotification, mapDocumentNotification, computeComplianceReminder, refreshing]);

  useEffect(() => {
    fetchNotifications();
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();
  }, [fetchNotifications]);

  useEffect(() => {
    if (!user?.id) return;
    const jobChannel = supabase
      .channel(`valeter-notifications-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${user.id}`,
        },
        () => fetchNotifications()
      )
      .subscribe();

    const docChannel = supabase
      .channel(`valeter-docs-${user.id}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_documents',
          filter: `user_id=eq.${user.id}`,
        },
        () => fetchNotifications()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(jobChannel);
      supabase.removeChannel(docChannel);
    };
  }, [user?.id, fetchNotifications]);

  const handleRefresh = useCallback(() => {
    setRefreshing(true);
    fetchNotifications();
  }, [fetchNotifications]);

  const handleNotificationPress = useCallback((notification: ValeterNotification) => {
    if (notification.actionRoute) {
      router.push({
        pathname: notification.actionRoute as any,
        params: (notification.actionParams || {}) as any,
      });
    }
  }, []);

  const handleDeleteNotification = useCallback((notificationId: string) => {
    Alert.alert(
      'Delete Notification',
      'Are you sure you want to delete this notification?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => {
            setNotifications(prev => prev.filter(n => n.id !== notificationId));
          },
        },
      ]
    );
  }, []);

  const handleDeleteAll = useCallback(() => {
    if (notifications.length === 0) return;
    
    Alert.alert(
      'Delete All Notifications',
      `Are you sure you want to delete all ${notifications.length} notification${notifications.length !== 1 ? 's' : ''}?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete All',
          style: 'destructive',
          onPress: () => {
            setNotifications([]);
          },
        },
      ]
    );
  }, [notifications.length]);

  const listEmptyComponent = useMemo(
    () => (
      <Animated.View style={[styles.emptyState, { opacity: fadeAnim }]}>
        <View style={styles.emptyIconWrapper}>
          <Ionicons name="notifications-off" size={48} color={colors.SKY} />
        </View>
        <Text style={styles.emptyTitle}>All caught up</Text>
        <Text style={styles.emptySubtitle}>
          You will receive job updates and compliance reminders here.
        </Text>
      </Animated.View>
    ),
    [fadeAnim]
  );

  const renderNotification = ({ item }: { item: ValeterNotification }) => {
    const iconMeta = getIconMeta(item.type, item.status);

    return (
      <Animated.View style={{ opacity: fadeAnim }}>
        <GlassCard
          style={styles.notificationCard}
          accountType="valeter"
        >
          <TouchableOpacity
            onPress={() => handleNotificationPress(item)}
            activeOpacity={0.8}
            style={styles.notificationContent}
          >
            <View style={styles.notificationMainContent}>
              <View style={styles.notificationLeft}>
                <LinearGradient
                  colors={[iconMeta.background, iconMeta.background + '60']}
                  style={[styles.iconWrapper, { borderColor: iconMeta.color + '40' }]}
                >
                  <Ionicons name={iconMeta.icon as any} size={22} color={iconMeta.color} />
                </LinearGradient>
                
                <View style={styles.notificationTextBlock}>
                  <View style={styles.titleRow}>
                    <Text style={styles.notificationTitle} numberOfLines={2}>{item.title}</Text>
                    {item.priority && (
                      <View style={[styles.priorityBadge, getPriorityStyle(item.priority)]}>
                        <Text style={styles.priorityText}>{item.priority}</Text>
                      </View>
                    )}
                  </View>
                  <Text style={styles.notificationMessage} numberOfLines={2}>{item.message}</Text>
                  <View style={styles.timeRow}>
                    <Ionicons name="time-outline" size={11} color="rgba(249,250,251,0.5)" />
                    <Text style={styles.notificationTime}>{formatRelativeTime(item.createdAt)}</Text>
                  </View>
                </View>
              </View>
              
              {item.actionRoute && (
                <View style={styles.actionIndicator}>
                  <Ionicons name="chevron-forward" size={18} color={colors.SKY} />
                </View>
              )}
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.deleteButton}
            onPress={async () => {
              await hapticFeedback('light');
              handleDeleteNotification(item.id);
            }}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={16} color="#EF4444" />
          </TouchableOpacity>
        </GlassCard>
      </Animated.View>
    );
  };

  if (loading && notifications.length === 0) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={[colors.BG, colors.headerBg]} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <AppHeader title="Notifications" accountType="valeter" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={colors.SKY} />
          <Text style={styles.loadingText}>Fetching notifications...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[colors.BG, colors.headerBg]} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader 
        title="Notifications" 
        accountType="valeter"
        rightAction={
          notifications.length > 0 ? (
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                handleDeleteAll();
              }}
              style={styles.deleteAllButton}
              activeOpacity={0.7}
            >
              <Ionicons name="trash-outline" size={20} color="#EF4444" />
            </TouchableOpacity>
          ) : null
        }
      />

      <FlatList
        data={notifications}
        keyExtractor={(item) => item.id}
        renderItem={renderNotification}
        contentContainerStyle={{
          paddingTop: HEADER_CONTENT_OFFSET + 12,
          paddingHorizontal: 20,
          paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
        }}
        style={styles.list}
        ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
        ListEmptyComponent={listEmptyComponent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={handleRefresh}
            tintColor={colors.SKY}
            colors={[colors.SKY]}
          />
        }
        ListHeaderComponent={
          notifications.length > 0 ? (
            <Animated.View style={[styles.headerSection, { opacity: fadeAnim }]}>
              <View style={styles.headerInfo}>
                <Text style={styles.headerTitle}>Recent Notifications</Text>
                <Text style={styles.headerSubtitle}>
                  {notifications.length} notification{notifications.length !== 1 ? 's' : ''}
                </Text>
              </View>
            </Animated.View>
          ) : null
        }
      />
    </SafeAreaView>
  );
}

const getIconMeta = (
  type: ValeterNotificationType,
  status?: string
): { icon: string; color: string; background: string } => {
  switch (type) {
    case 'job':
      return {
        icon: status === 'completed' ? 'checkmark-done' : 'briefcase-outline',
        color: '#10B981',
        background: 'rgba(16,185,129,0.15)',
      };
    case 'document':
      return {
        icon: status === 'rejected' ? 'close-circle' : status === 'approved' ? 'checkmark-circle' : 'document-text',
        color: status === 'rejected' ? '#F87171' : status === 'approved' ? '#10B981' : colors.SKY,
        background:
          status === 'rejected'
            ? 'rgba(248,113,113,0.15)'
            : status === 'approved'
            ? 'rgba(16,185,129,0.15)'
            : 'rgba(135,206,235,0.15)',
      };
    case 'compliance':
      return {
        icon: 'shield-half',
        color: '#FBBF24',
        background: 'rgba(251,191,36,0.2)',
      };
    default:
      return {
        icon: 'notifications',
        color: colors.SKY,
        background: 'rgba(135,206,235,0.15)',
      };
  }
};

const getPriorityStyle = (priority: 'low' | 'medium' | 'high') => {
  switch (priority) {
    case 'high':
      return { 
        backgroundColor: '#F87171', 
        borderColor: '#EF4444',
      };
    case 'medium':
      return { 
        backgroundColor: '#FBBF24', 
        borderColor: '#F59E0B',
      };
    default:
      return { 
        backgroundColor: colors.SKY, 
        borderColor: '#60A5FA',
      };
  }
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  list: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: HEADER_CONTENT_OFFSET + 28,
    gap: 12,
  },
  loadingText: {
    marginTop: 12,
    color: colors.SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  deleteAllButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(239,68,68,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
  },
  headerSection: {
    marginBottom: 16,
  },
  headerInfo: {
    gap: 4,
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  headerSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '600',
    marginTop: 2,
  },
  notificationCard: {
    padding: 0,
    borderRadius: 18,
    overflow: 'hidden',
    position: 'relative',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    marginBottom: 0,
  },
  notificationContent: {
    padding: 14,
    paddingRight: 50,
    flex: 1,
  },
  notificationMainContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  notificationLeft: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    flex: 1,
  },
  iconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    overflow: 'hidden',
  },
  notificationTextBlock: {
    flex: 1,
    gap: 6,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    gap: 8,
    flexWrap: 'wrap',
  },
  notificationTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: -0.2,
    flex: 1,
    lineHeight: 20,
  },
  notificationMessage: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
    marginTop: 2,
  },
  timeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
  },
  notificationTime: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 11,
    fontWeight: '600',
  },
  actionIndicator: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  priorityBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 10,
    borderWidth: 1,
    alignSelf: 'flex-start',
  },
  priorityText: {
    color: '#FFFFFF',
    fontSize: 9,
    fontWeight: '900',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  deleteButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(239,68,68,0.12)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.25)',
  },
  emptyState: {
    marginTop: 80,
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  emptyIconWrapper: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '900',
    marginBottom: 10,
    letterSpacing: 0.3,
  },
  emptySubtitle: {
    color: 'rgba(249,250,251,0.75)',
    textAlign: 'center',
    lineHeight: 24,
    fontSize: 16,
    fontWeight: '500',
  },
});


