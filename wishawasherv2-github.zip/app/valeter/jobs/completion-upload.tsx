import WashCompletionUpload from '../../../src/components/wash/WashCompletionUpload';
import { useLocalSearchParams, router } from 'expo-router';

export default function WashCompletionUploadScreen() {
  const { bookingId, customerId } = useLocalSearchParams<{ 
    bookingId?: string; 
    customerId?: string; 
  }>();

  return (
    <WashCompletionUpload
      bookingId={bookingId}
      customerId={customerId}
      onComplete={(washCompletion) => {
        // Handle completion - navigate back to valeter dashboard
        router.replace('/valeter/valeter-dashboard');
      }}
      onClose={() => {
        // Handle close - navigate back to valeter dashboard
        router.back();
      }}
    />
  );
}
