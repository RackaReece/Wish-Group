import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Image,
  Platform,
  ScrollView,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import MapView, { Marker, Region } from 'react-native-maps';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { fetchProfilesByIds } from '../../../src/utils/customerProfiles';
import { fetchRadiusPreference } from '../../../src/utils/radiusPreference';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';

import { colors } from '../../../src/constants/colors';

const { width, height } = Dimensions.get('window');
const SKY = colors.SKY;

interface JobRequest {
  id: string;
  service_type: string;
  service_name?: string;
  price: number;
  location_address: string;
  location_lat: number;
  location_lng: number;
  scheduled_at?: string;
  request_sent_at: string;
  customer_name?: string;
  customer_rating?: number | undefined;
  customer_review_count?: number | undefined;
  distance?: number | undefined;
  drive_time_minutes?: number | undefined;
  formatted_location?: string;
  assignedToValeter?: boolean;
  status?: string;
  vehicle_type?: string | null;
  vehicle_info?: string | null;
  vehicle_registration?: string | null;
  vehicle_make?: string | null;
  vehicle_model?: string | null;
}

export default function JobsPage() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  
  // Jobs state
  const [jobs, setJobs] = useState<JobRequest[]>([]);
  const [jobsLoading, setJobsLoading] = useState(true);
  const [selectedJobIndex, setSelectedJobIndex] = useState(0);
  const [onlineCustomersCount, setOnlineCustomersCount] = useState(0);
  
  // Map state
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const [valeterLocation, setValeterLocation] = useState<{ lat: number; lng: number } | null>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const mapRef = useRef<MapView>(null);
  const scrollViewRef = useRef<any>(null);
  
  const cardWidth = width - 40; // width - horizontal padding
  const cardSpacing = 20; // margin between cards

  useEffect(() => {
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
    }).start();

      loadJobs();
    loadOnlineCustomersCount();
    loadValeterLocation();
      subscribeToJobs();
    
    const interval = setInterval(() => {
      loadOnlineCustomersCount();
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, [user?.id]);

  // Sync map with selected job
  useEffect(() => {
    if (jobs.length > 0 && selectedJobIndex < jobs.length) {
      const selectedJob = jobs[selectedJobIndex];
      if (selectedJob.location_lat && selectedJob.location_lng) {
        const newRegion: Region = {
          latitude: selectedJob.location_lat,
          longitude: selectedJob.location_lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        };
        setRegion(newRegion);
        mapRef.current?.animateToRegion(newRegion, 500);
      }
    }
  }, [selectedJobIndex, jobs]);

  // Scroll to selected job when index changes
  useEffect(() => {
    if (scrollViewRef.current && jobs.length > 0 && selectedJobIndex < jobs.length) {
      const scrollX = selectedJobIndex * (cardWidth + cardSpacing);
      scrollViewRef.current.scrollTo({
        x: scrollX,
        animated: true,
      });
    }
  }, [selectedJobIndex, jobs.length]);

  const handleScroll = (event: any) => {
    const scrollPosition = event.nativeEvent.contentOffset.x;
    const newIndex = Math.round(scrollPosition / (cardWidth + cardSpacing));
    
    if (newIndex >= 0 && newIndex < jobs.length && newIndex !== selectedJobIndex) {
      setSelectedJobIndex(newIndex);
    }
  };


  const [initialRegion, setInitialRegion] = useState<Region | null>(null);

  const loadValeterLocation = async () => {
    if (!user?.id) return;
    try {
      const { data } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', user.id)
        .single();

      if (data?.last_lat && data?.last_lng) {
        setValeterLocation({ lat: data.last_lat, lng: data.last_lng });
        const newRegion = {
          latitude: data.last_lat,
          longitude: data.last_lng,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        };
        setRegion(newRegion);
        setInitialRegion(newRegion);
      }
    } catch (error) {
      console.error('Error loading valeter location:', error);
    }
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (jobs.length > 0 && selectedJobIndex < jobs.length) {
      const selectedJob = jobs[selectedJobIndex];
      if (selectedJob.location_lat && selectedJob.location_lng) {
        const newRegion: Region = {
          latitude: selectedJob.location_lat,
          longitude: selectedJob.location_lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        };
        setRegion(newRegion);
        mapRef.current?.animateToRegion(newRegion, 500);
      }
    } else if (initialRegion) {
      setRegion(initialRegion);
      mapRef.current?.animateToRegion(initialRegion, 500);
    }
  };

  const loadOnlineCustomersCount = async () => {
    if (!user?.id) return;
    try {
      // Get valeter's location and radius
      const { data: presenceData } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', user.id)
        .single();

      if (!presenceData?.last_lat || !presenceData?.last_lng) {
        setOnlineCustomersCount(0);
        return;
      }

      const radiusResult = await fetchRadiusPreference(user.id);
      const workingRadiusMiles = radiusResult.value ?? 10;

      // Count customers with active bookings in the area
      const { data: bookings, error } = await supabase
        .from('bookings')
        .select('user_id, location_lat, location_lng')
        .in('status', ['pending_valeter_acceptance', 'pending_payment', 'confirmed', 'scheduled'])
        .not('location_lat', 'is', null)
        .not('location_lng', 'is', null);

      if (error) throw error;

      const valeterLat = presenceData.last_lat;
      const valeterLng = presenceData.last_lng;

      const customersInRadius = (bookings || []).filter((booking: any) => {
        if (!booking.location_lat || !booking.location_lng) return false;
        const distance = calculateDistance(
          valeterLat,
          valeterLng,
          booking.location_lat,
          booking.location_lng
        );
        return distance <= workingRadiusMiles;
      });

      // Get unique customer count
      const uniqueCustomers = new Set(customersInRadius.map((b: any) => b.user_id));
      setOnlineCustomersCount(uniqueCustomers.size);
    } catch (error) {
      console.error('Error loading online customers count:', error);
    }
  };

  const loadJobs = async () => {
    if (!user?.id) return;
    try {
      let query = supabase
        .from('bookings')
        .select(`
          id,
          service_type,
          service_name,
          price,
          location_address,
          location_lat,
          location_lng,
          scheduled_at,
          request_sent_at,
          status,
          user_id,
          valeter_id,
          vehicle_type,
          vehicle_info
        `)
        .order('request_sent_at', { ascending: false })
        .limit(20);

      if (user?.id) {
        query = query.or(
          `and(status.eq.pending_valeter_acceptance,valeter_id.is.null),` +
          `and(status.eq.pending_valeter_acceptance,valeter_id.eq.${user.id}),` +
          `and(status.in.(pending_payment,confirmed,en_route,arrived,in_progress),valeter_id.eq.${user.id})`
        );
      } else {
        query = query.eq('status', 'pending_valeter_acceptance').is('valeter_id', null);
      }

      const { data, error } = await query;

      if (error) throw error;

      const customerIds = Array.from(
        new Set(
          (data || [])
            .map((job: any) => job.user_id)
            .filter(Boolean)
        )
      ) as string[];

      const customerProfiles = await fetchProfilesByIds(customerIds);

      // Fetch vehicle information from customer_vehicles table
      const vehicleMap = new Map<string, { registration?: string; make?: string; model?: string; type?: string }>();
      if (customerIds.length > 0) {
        try {
          const { data: vehicles, error: vehicleErr } = await supabase
            .from('customer_vehicles')
            .select('user_id, registration, make, model, type')
            .in('user_id', customerIds)
            .eq('is_default', true);

          if (vehicleErr) {
            console.warn('[ValeterJobs] vehicle lookup error:', vehicleErr.message);
          } else {
            (vehicles || []).forEach((v: any) => {
              vehicleMap.set(v.user_id, {
                registration: v.registration || undefined,
                make: v.make || undefined,
                model: v.model || undefined,
                type: v.type || undefined,
              });
            });
          }
        } catch (error) {
          console.warn('[ValeterJobs] vehicle lookup failed:', error);
        }
      }

      // Fetch customer ratings and review counts
      // Calculate based on completed bookings (proxy for customer reliability)
      const { data: customerBookings } = await supabase
        .from('bookings')
        .select('user_id, status, rating, review')
        .in('user_id', customerIds)
        .eq('status', 'completed');

      const customerRatingMap = new Map<string, { rating: number; count: number }>();
      if (customerBookings) {
        customerIds.forEach(customerId => {
          const completedBookings = customerBookings.filter(b => b.user_id === customerId);
          const totalCompleted = completedBookings.length;
          
          // Use completed bookings as a proxy for customer rating
          // More completed bookings = better customer (reliable, pays on time, etc.)
          // Calculate a rating based on completion rate and total bookings
          if (totalCompleted > 0) {
            // Base rating: 4.0 + (completed bookings / 10) capped at 5.0
            // This gives customers with more successful bookings a higher rating
            const baseRating = Math.min(4 + (totalCompleted / 10), 5);
            const reviews = completedBookings.filter(b => b.review).length;
            
            customerRatingMap.set(customerId, {
              rating: Math.round(baseRating * 10) / 10,
              count: reviews || totalCompleted, // Use review count or total bookings as count
            });
          }
        });
      }

      const { data: presenceData } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', user.id)
        .single();

      const valeterLat = presenceData?.last_lat;
      const valeterLng = presenceData?.last_lng;

      const radiusResult = await fetchRadiusPreference(user.id);
      const workingRadiusMiles = radiusResult.value ?? 10;

      const jobsWithDistance: JobRequest[] = (data || [])
        .map((job: any) => {
          const assignedToValeter = Boolean(user?.id && job.valeter_id === user.id);
          let distance = null;
          let driveTime = null;
          if (valeterLat && valeterLng && job.location_lat && job.location_lng) {
            distance = calculateDistance(
              valeterLat,
              valeterLng,
              job.location_lat,
              job.location_lng
            );
            driveTime = calculateDriveTime(distance);
          }

          const customerRating = customerRatingMap.get(job.user_id);
          const formattedLocation = formatLocation(job.location_address);
          const vehicleData = job.user_id ? vehicleMap.get(job.user_id) : null;

          return {
            id: job.id,
            service_type: job.service_type,
            service_name: job.service_name,
            price: job.price,
            location_address: job.location_address,
            location_lat: job.location_lat,
            location_lng: job.location_lng,
            scheduled_at: job.scheduled_at,
            request_sent_at: job.request_sent_at,
            customer_name: customerProfiles.get(job.user_id)?.full_name || 'Customer',
            customer_rating: customerRating?.rating ?? undefined,
            customer_review_count: customerRating?.count ?? undefined,
            distance: distance ? Math.round(distance * 10) / 10 : undefined,
            drive_time_minutes: driveTime ?? undefined,
            formatted_location: formattedLocation,
            assignedToValeter,
            status: job.status,
            vehicle_type: job.vehicle_type || vehicleData?.type || null,
            vehicle_info: job.vehicle_info || null,
            vehicle_registration: vehicleData?.registration || null,
            vehicle_make: vehicleData?.make || null,
            vehicle_model: vehicleData?.model || null,
          };
        })
        .filter((job) => {
          if (job.assignedToValeter) {
            return true;
          }
          if (job.distance == null) return true;
          return job.distance <= workingRadiusMiles;
        });

      setJobs(jobsWithDistance);
      if (jobsWithDistance.length > 0) {
        setSelectedJobIndex(0);
      }
    } catch (error) {
      console.error('Error loading jobs:', error);
    } finally {
      setJobsLoading(false);
    }
  };

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 3959;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const calculateDriveTime = (distanceMiles: number): number => {
    // Estimate: average 30 mph in city, so 1 mile ≈ 2 minutes
    return Math.round(distanceMiles * 2);
  };

  const formatRelativeTime = (dateString: string): string => {
    const now = new Date();
    const date = new Date(dateString);
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} ${diffMins === 1 ? 'min' : 'mins'} ago`;
    if (diffHours < 24) return `${diffHours} ${diffHours === 1 ? 'hour' : 'hours'} ago`;
    if (diffDays < 7) return `${diffDays} ${diffDays === 1 ? 'day' : 'days'} ago`;
    return date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
  };

  const getTimeRequestedColor = (dateString: string) => {
    const now = new Date();
    const date = new Date(dateString);
    const diffMs = now.getTime() - date.getTime();
    const diffHours = diffMs / (1000 * 60 * 60);
    
    if (diffHours < 1) {
      return { color: '#F59E0B' }; // Amber for urgent (recent)
    } else if (diffHours < 24) {
      return { color: '#94A3B8' }; // Grey for normal
    } else {
      return { color: '#64748B', opacity: 0.7 }; // Faded grey for stale
    }
  };

  // Get urgency signal text
  const getUrgencySignal = (job: JobRequest): string | null => {
    if (job.distance && job.distance < 5) return 'Priority job • Nearby';
    if (job.distance && job.distance < 10) return 'Likely to be accepted fast';
    const daysAgo = Math.floor((Date.now() - new Date(job.request_sent_at).getTime()) / (1000 * 60 * 60 * 24));
    if (daysAgo > 1) return 'Customer ready to pay';
    return null;
  };

  // Get tier color for service type
  const getTierColor = (serviceType?: string, serviceName?: string): string => {
    const serviceDisplay = getServiceDisplayName(serviceType, serviceName);
    if (serviceDisplay.includes('Bronze')) return '#CD7F32';
    if (serviceDisplay.includes('Silver')) return '#C0C0C0';
    if (serviceDisplay.includes('Gold')) return '#FFD700';
    if (serviceDisplay.includes('Platinum')) return '#E5E4E2';
    return SKY;
  };

  // Get tier icon for service type
  const getTierIcon = (serviceType?: string, serviceName?: string): keyof typeof Ionicons.glyphMap => {
    const serviceDisplay = getServiceDisplayName(serviceType, serviceName);
    if (serviceDisplay.includes('Bronze')) return 'layers-outline';
    if (serviceDisplay.includes('Silver')) return 'star-outline';
    if (serviceDisplay.includes('Gold')) return 'trophy';
    if (serviceDisplay.includes('Platinum')) return 'diamond';
    return 'car-outline';
  };

  const formatLocation = (address: string): string => {
    // Try to extract area and postcode from address
    // Format: "Street, Area, City (POSTCODE)" or similar
    const postcodeRegex = /\b([A-Z]{1,2}\d{1,2}[A-Z]?\s?\d[A-Z]{2})\b/i;
    const postcodeMatch = postcodeRegex.exec(address);
    const postcode = postcodeMatch ? postcodeMatch[1].toUpperCase() : null;
    
    // Try to extract area/city name
    const parts = address.split(',').map(p => p.trim());
    let area = '';
    let city = '';
    
    if (parts.length >= 2) {
      // Usually format is: Street, Area, City, Postcode
      area = parts.at(-3) || parts.at(-2) || '';
      city = parts.at(-2) || parts.at(-1) || '';
      } else {
      area = address;
    }
    
    // Clean up - remove postcode from area/city if present
    if (postcode) {
      area = area.replace(postcode, '').trim();
      city = city.replace(postcode, '').trim();
    }
    
    // Build formatted string
    if (area && city && postcode) {
      return `${area}, ${city} (${postcode})`;
    } else if (area && postcode) {
      return `${area} (${postcode})`;
    } else if (city && postcode) {
      return `${city} (${postcode})`;
    } else if (postcode) {
      return `(${postcode})`;
    } else if (area) {
      return area;
    }
    
    // Fallback to first part of address
    return parts[0] || address;
  };

  const subscribeToJobs = () => {
    const channel = supabase
      .channel('job-requests')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: 'status=eq.pending_valeter_acceptance',
        },
        () => {
          loadJobs();
          loadOnlineCustomersCount();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleRefresh = async () => {
    await Promise.all([loadJobs(), loadOnlineCustomersCount()]);
  };

  const handleJobPress = async (job: JobRequest) => {
    await hapticFeedback('light');
    
    if (job.assignedToValeter || (job.status && job.status !== 'pending_valeter_acceptance')) {
      router.push({
        pathname: '/valeter/trips',
        params: { jobId: job.id },
      });
    } else {
    router.push({
      pathname: '/valeter/jobs/accept',
        params: { jobId: job.id },
      });
    }
  };

  const handleAcceptJob = async (job: JobRequest) => {
    if (!user?.id || !job) return;
    await hapticFeedback('medium');

    try {
      const { error } = await supabase
        .from('bookings')
        .update({
          valeter_id: user.id,
          status: 'pending_payment',
          valeter_accepted_at: new Date().toISOString(),
        })
        .eq('id', job.id);

      if (error) throw error;

      // Navigate to trips page
      router.push({
        pathname: '/valeter/trips',
        params: { jobId: job.id },
      });
    } catch (error: any) {
      console.error('Error accepting job:', error);
    }
  };


  // Original job card component
  const renderJobCard = (job: JobRequest) => {
    const isPendingPayment = job.status === 'pending_payment';
    const isAssigned = job.assignedToValeter;
    const isPendingAcceptance = job.status === 'pending_valeter_acceptance';
    const urgencySignal = getUrgencySignal(job);

    return (
      <View style={styles.jobCardWrapper}>
        <BlurView intensity={60} tint="dark" style={styles.jobCard}>
          <View style={styles.jobCardBackground} />
          <View style={[styles.jobCardBorder, { borderColor: 'rgba(135,206,235,0.3)' }]} />
          
          {/* Header */}
          <View style={styles.jobHeader}>
            <View style={styles.jobHeaderContent}>
              <View style={styles.servicePreviewIcon}>
                <Ionicons 
                  name={getTierIcon(job.service_type, job.service_name)} 
                  size={20} 
                  color={getTierColor(job.service_type, job.service_name)} 
                />
              </View>
              <View style={styles.jobHeaderText}>
                <View style={styles.jobTitleRow}>
                  <Text style={styles.jobTitle} numberOfLines={1}>
                    {getServiceDisplayName(job.service_type, job.service_name)}
                  </Text>
                </View>
                {urgencySignal && (
                  <Text style={styles.urgencySignal}>{urgencySignal}</Text>
                )}
              </View>
            </View>
            <Text style={styles.jobPrice}>£{job.price?.toFixed(2) || '0.00'}</Text>
          </View>

          {/* Details */}
          <View style={styles.jobDetails}>
            <View style={styles.jobDetailRow}>
              <Ionicons name="location-outline" size={16} color={SKY} />
              <Text style={styles.jobDetailText} numberOfLines={2}>
                {job.formatted_location || job.location_address}
              </Text>
            </View>
            
            <View style={styles.jobDetailRow}>
              <Ionicons name="time-outline" size={16} color={SKY} />
              <Text style={[styles.jobDetailText, styles.timeRequestedText, getTimeRequestedColor(job.request_sent_at)]}>
                Requested {formatRelativeTime(job.request_sent_at)}
              </Text>
            </View>

            {job.distance !== null && (
              <View style={styles.jobDetailRow}>
                <Ionicons name="car-outline" size={16} color={SKY} />
                <Text style={styles.jobDetailText}>
                  {job.distance} mi away
                  {job.drive_time_minutes && ` • ${job.drive_time_minutes} min drive`}
                </Text>
              </View>
            )}

            {job.customer_name && (
              <View style={styles.jobDetailRow}>
                <Ionicons name="person-outline" size={16} color={SKY} />
                <Text style={styles.jobDetailText}>
                  {job.customer_name}
                  {job.customer_rating && (
                    <Text style={styles.ratingText}> • ⭐ {job.customer_rating.toFixed(1)}</Text>
                  )}
                </Text>
              </View>
            )}

            {/* Vehicle Information */}
            {(job.vehicle_registration || job.vehicle_type || job.vehicle_make || job.vehicle_model) && (
              <View style={styles.jobDetailRow}>
                <Ionicons name="car-sport-outline" size={16} color={SKY} />
                <View style={styles.vehicleInfoContainer}>
                  {job.vehicle_registration && (
                    <Text style={styles.vehicleRegistration}>{job.vehicle_registration}</Text>
                  )}
                  {(job.vehicle_make || job.vehicle_model || job.vehicle_type) && (
                    <Text style={styles.jobDetailText}>
                      {[job.vehicle_make, job.vehicle_model, job.vehicle_type].filter(Boolean).join(' ')}
                    </Text>
                  )}
                </View>
              </View>
            )}
          </View>

          {/* Status Strip */}
          {isPendingPayment && (
            <View style={[styles.statusStrip, styles.statusStripLocked]}>
              <View style={styles.statusStripContent}>
                <Ionicons name="lock-closed" size={16} color="#F59E0B" />
                <Text style={[styles.statusStripText, styles.lockedText]}>
                  Payment pending - Job locked
                </Text>
              </View>
            </View>
          )}

          {/* Action Buttons */}
          <View style={styles.actionButtonsWrapper}>
            {isAssigned ? (
              <TouchableOpacity
                onPress={() => handleJobPress(job)}
                style={styles.viewButton}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={[SKY, '#3B82F6']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.viewButtonGradient}
                >
                  <Ionicons name="navigate" size={20} color="#FFFFFF" />
                  <Text style={styles.viewButtonText}>View Trip</Text>
                </LinearGradient>
              </TouchableOpacity>
            ) : isPendingAcceptance ? (
              <TouchableOpacity
                onPress={() => handleAcceptJob(job)}
                style={styles.acceptButton}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={['#10B981', '#059669']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.acceptGradient}
                >
                  <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                  <Text style={styles.acceptButtonText}>Accept Job</Text>
                </LinearGradient>
              </TouchableOpacity>
            ) : isPendingPayment ? (
              <TouchableOpacity
                style={styles.pendingPaymentButton}
                activeOpacity={1}
                disabled
              >
                <LinearGradient
                  colors={['rgba(245,158,11,0.2)', 'rgba(245,158,11,0.1)']}
                  style={styles.pendingPaymentGradient}
                >
                  <Ionicons name="lock-closed" size={20} color="#F59E0B" />
                  <Text style={styles.pendingPaymentButtonText}>Payment Required</Text>
                </LinearGradient>
              </TouchableOpacity>
            ) : null}
          </View>
        </BlurView>
      </View>
    );
  };


  const renderMap = () => {
    if (jobsLoading) {
      return (
        <View style={styles.mapContainer}>
          <View style={styles.mapLoadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
            <Text style={styles.mapLoadingText}>Loading map...</Text>
        </View>
        </View>
      );
    }

      return (
      <View style={styles.mapContainer}>
        <MapView
          ref={mapRef}
          style={styles.map}
          region={region}
          showsUserLocation={true}
          showsMyLocationButton={false}
          mapType="standard"
          mapPadding={{ top: 0, bottom: height * 0.4, left: 0, right: 0 }}
        >
          {valeterLocation && (
            <Marker
              coordinate={{
                latitude: valeterLocation.lat,
                longitude: valeterLocation.lng,
              }}
              title="Your Location"
            >
              <View style={styles.valeterMarker}>
                <Image
                  source={require('../../../assets/cleaning.png')}
                  style={styles.valeterMarkerImage}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
          {jobs.map((job, index) => {
            const isNew = new Date(job.request_sent_at).getTime() > Date.now() - 3600000; // 1 hour
            const isSelected = index === selectedJobIndex;

    return (
              <Marker
            key={job.id}
                coordinate={{
                  latitude: job.location_lat,
                  longitude: job.location_lng,
                }}
                anchor={{ x: 0.5, y: 0.5 }}
              >
                <View style={[styles.mapMarkerPin, isSelected && styles.mapMarkerPinSelected]}>
                  <Image
                    source={require('../../../assets/car.png')}
                    style={styles.carMarkerImage}
                    resizeMode="contain"
                  />
                </View>
              </Marker>
            );
          })}
        </MapView>
        
        {/* Online Customers Count Badge - Small corner badge */}
        <View style={styles.customersBadge}>
          <View style={styles.badgeContent}>
            <View style={styles.onlineIndicator} />
            <Text style={styles.badgeText}>{onlineCustomersCount}</Text>
              </View>
                  </View>
                  </View>
    );
  };

  const renderJobCards = () => {
    if (jobsLoading) {
      return (
        <View style={styles.cardsLoadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading jobs...</Text>
        </View>
      );
    }

    if (jobs.length === 0) {
      return (
        <View style={styles.emptyContainer}>
          <BlurView intensity={60} tint="dark" style={styles.emptyCard}>
            <View style={styles.jobCardBackground} />
            <View style={[styles.jobCardBorder, { borderColor: 'rgba(135,206,235,0.3)' }]} />
            <View style={styles.emptyContent}>
              <Ionicons name="briefcase-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
              <Text style={styles.emptyTitle}>No Jobs Available</Text>
              <Text style={styles.emptyText}>
                New job requests will appear here when customers book services
              </Text>
            </View>
          </BlurView>
        </View>
      );
    }

    return (
      <View style={[styles.jobCardContainer, { paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20 }]}>
        <ScrollView
          ref={scrollViewRef}
          horizontal
          pagingEnabled={false}
          showsHorizontalScrollIndicator={false}
          onScroll={handleScroll}
          scrollEventThrottle={16}
          contentContainerStyle={styles.scrollContent}
          snapToInterval={cardWidth + cardSpacing}
          decelerationRate="fast"
          snapToAlignment="start"
        >
          {jobs.map((job, index) => (
            <View key={job.id} style={styles.jobCardScrollItem}>
              {renderJobCard(job)}
            </View>
          ))}
        </ScrollView>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
          },
        ]}
      >
        {renderMap()}
        <View style={styles.headerOverlay}>
          <AppHeader
            title="Jobs"
            rightAction={
              <View style={styles.headerActions}>
                <TouchableOpacity
                  onPress={handleRecenter}
                  style={styles.recenterButton}
                >
                  <Ionicons name="locate" size={20} color={SKY} />
                </TouchableOpacity>
                <TouchableOpacity onPress={handleRefresh} style={styles.refreshButton}>
                  <Ionicons name="refresh" size={20} color={SKY} />
                </TouchableOpacity>
              </View>
            }
            accountType="valeter"
          />
          {/* Job indicator dots under header */}
          {jobs.length > 1 && (
            <View style={styles.headerIndicatorContainer}>
              {jobs.map((job, index) => (
                <View
                  key={job.id || `indicator-${index}`}
                  style={[
                    styles.headerIndicatorDot,
                    index === selectedJobIndex && styles.headerIndicatorDotActive,
                  ]}
                />
              ))}
            </View>
          )}
        </View>
        {renderJobCards()}
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  refreshButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  content: {
    flex: 1,
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    backgroundColor: 'transparent',
  },
  headerIndicatorContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
    paddingBottom: 12,
  },
  headerIndicatorDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  headerIndicatorDotActive: {
    width: 24,
    backgroundColor: SKY,
  },
  mapContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  mapLoadingContainer: {
    ...StyleSheet.absoluteFillObject,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  mapLoadingText: {
    color: SKY,
    fontSize: 14,
    marginTop: 12,
  },
  valeterMarker: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
  },
  valeterMarkerImage: {
    width: 40,
    height: 40,
  },
  mapMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'flex-end',
  },
  mapMarkerBubble: {
    backgroundColor: 'rgba(0,0,0,0.85)',
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    minWidth: 120,
    maxWidth: 180,
    marginBottom: 4,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  mapMarkerBubbleSelected: {
    backgroundColor: 'rgba(0,0,0,0.95)',
    borderColor: SKY,
    borderWidth: 2,
  },
  mapMarkerHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 4,
  },
  mapMarkerServiceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    flex: 1,
  },
  mapMarkerServiceName: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '600',
    flex: 1,
  },
  mapMarkerPrice: {
    color: SKY,
    fontSize: 18,
    fontWeight: 'bold',
    marginLeft: 8,
  },
  mapMarkerDistance: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '500',
  },
  mapMarkerNewBadge: {
    backgroundColor: '#10B981',
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: 4,
  },
  mapMarkerNewText: {
    color: '#FFFFFF',
    fontSize: 8,
    fontWeight: 'bold',
  },
  mapMarkerRatingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(251,191,36,0.2)',
    paddingHorizontal: 4,
    paddingVertical: 2,
    borderRadius: 4,
    gap: 2,
  },
  mapMarkerRatingText: {
    color: '#FBBF24',
    fontSize: 9,
    fontWeight: '600',
  },
  mapMarkerPin: {
    width: 40,
    height: 40,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 5,
  },
  mapMarkerPinSelected: {
    transform: [{ scale: 1.15 }],
  },
  carMarkerImage: {
    width: 40,
    height: 40,
  },
  locationPickerIcon: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  locationPickerDot: {
    position: 'absolute',
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#1E3A8A',
    bottom: 4,
  },
  customersBadge: {
    position: 'absolute',
    top: HEADER_CONTENT_OFFSET + 12,
    right: 12,
    borderRadius: 16,
    backgroundColor: 'rgba(0,0,0,0.6)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  badgeContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  onlineIndicator: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  badgeText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  bottomSheet: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: 'transparent',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: 'hidden',
    zIndex: 1000,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: -4 },
        shadowOpacity: 0.3,
        shadowRadius: 12,
      },
      android: {
        elevation: 16,
      },
    }),
  },
  sheetHandle: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.85)',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    minHeight: 60,
    justifyContent: 'center',
  },
  handleBar: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.4)',
    marginBottom: 8,
  },
  minimizedHeader: {
    width: '100%',
    alignItems: 'center',
  },
  minimizedTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  minimizedSubtitle: {
    color: '#94A3B8',
    fontSize: 12,
  },
  sheetContent: {
    flex: 1,
    paddingTop: 8,
  },
  cardsContainer: {
    flex: 1,
  },
  cardsLoadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  jobCardContainer: {
    position: 'absolute',
    bottom: 20,
    left: 0,
    right: 0,
    zIndex: 1000,
  },
  scrollContent: {
    paddingHorizontal: 20,
  },
  jobCardScrollItem: {
    width: width - 40,
    marginRight: 20,
  },
  jobCardWrapper: {
    width: '100%',
    overflow: 'visible',
  },
  // New redesigned card styles
  newJobCardWrapper: {
    width: width - 32,
    marginHorizontal: 16,
    marginRight: 16,
    marginBottom: 12,
  },
  newJobCard: {
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    overflow: 'hidden',
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 2 },
        shadowOpacity: 0.1,
        shadowRadius: 8,
      },
      android: {
        elevation: 4,
      },
    }),
  },
  newCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    backgroundColor: '#FFFFFF',
  },
  newCardHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    marginRight: 12,
  },
  newServiceIcon: {
    width: 48,
    height: 48,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  newCardHeaderText: {
    flex: 1,
  },
  newCardTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#000000',
    marginBottom: 4,
  },
  newCardLocation: {
    fontSize: 13,
    color: '#666666',
    fontWeight: '400',
  },
  newCardHeaderRight: {
    alignItems: 'flex-end',
    gap: 4,
  },
  newCardPrice: {
    fontSize: 20,
    fontWeight: '700',
    color: '#000000',
  },
  newCardDistance: {
    fontSize: 12,
    color: '#666666',
    fontWeight: '500',
  },
  newCardContent: {
    paddingHorizontal: 16,
    paddingBottom: 16,
    overflow: 'hidden',
  },
  newCardSection: {
    paddingVertical: 12,
    borderTopWidth: 1,
    borderTopColor: '#F0F0F0',
    gap: 12,
  },
  newCardInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  newCardInfoText: {
    fontSize: 14,
    color: '#333333',
    fontWeight: '400',
    flex: 1,
  },
  newCardRating: {
    fontSize: 14,
    color: '#F59E0B',
    fontWeight: '500',
  },
  newPaymentNotice: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#FFF7ED',
    padding: 12,
    borderRadius: 8,
    marginVertical: 12,
    gap: 8,
  },
  newPaymentText: {
    fontSize: 14,
    color: '#F59E0B',
    fontWeight: '500',
  },
  newCardActions: {
    marginTop: 8,
  },
  newPrimaryButton: {
    borderRadius: 12,
    overflow: 'hidden',
    width: '100%',
  },
  newButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 20,
    gap: 8,
  },
  newButtonDisabled: {
    backgroundColor: '#CCCCCC',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 20,
    gap: 8,
  },
  newButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  jobCard: {
    padding: 20,
    paddingBottom: 24,
    minHeight: 300,
    borderRadius: 20,
    overflow: 'visible',
    borderWidth: 1,
    backgroundColor: 'transparent',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
  },
  jobCardBackground: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderRadius: 20,
  },
  jobCardBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
    pointerEvents: 'none',
  },
  jobHeader: {
    marginBottom: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  jobHeaderContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  servicePreviewIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  jobHeaderText: {
    flex: 1,
  },
  urgencySignal: {
    color: '#F59E0B',
    fontSize: 11,
    fontWeight: '600',
    marginTop: 2,
    fontStyle: 'italic',
  },
  verifiedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(16,185,129,0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  verifiedText: {
    color: '#10B981',
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  jobTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
  },
  jobTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    flex: 1,
  },
  jobPrice: {
    color: SKY,
    fontSize: 20,
    fontWeight: 'bold',
  },
  jobDetails: {
    gap: 8,
    marginBottom: 16,
  },
  jobDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  jobDetailText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
  },
  timeRequestedText: {
    fontWeight: '500',
  },
  ratingText: {
    color: '#FBBF24',
    fontSize: 14,
    fontWeight: '600',
  },
  vehicleInfoContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  vehicleRegistration: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 1,
    fontFamily: 'monospace',
  },
  earningSummary: {
    backgroundColor: 'rgba(15,23,42,0.6)',
    paddingHorizontal: 14,
    paddingVertical: 12,
    borderRadius: 14,
    marginBottom: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(16,185,129,0.4)',
    elevation: 2,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  earningContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  earningTextContainer: {
    flex: 1,
  },
  earningText: {
    color: '#10B981',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  earningRate: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
  },
  jobFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  quickActionsRow: {
    flexDirection: 'row',
    gap: 8,
    marginBottom: 12,
    width: '100%',
  },
  quickActionButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  quickActionButtonLocked: {
    backgroundColor: 'rgba(135,206,235,0.05)',
    borderColor: 'rgba(135,206,235,0.15)',
    opacity: 0.6,
  },
  quickActionText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '600',
  },
  quickActionTextLocked: {
    color: 'rgba(135,206,235,0.4)',
  },
  progressStepper: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingVertical: 8,
    paddingHorizontal: 4,
  },
  stepperStep: {
    alignItems: 'center',
    flex: 1,
  },
  stepperDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginBottom: 4,
  },
  stepperDotCompleted: {
    backgroundColor: '#10B981',
  },
  stepperDotActive: {
    backgroundColor: '#F59E0B',
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  stepperDotInactive: {
    backgroundColor: 'rgba(135,206,235,0.3)',
  },
  stepperLine: {
    flex: 1,
    height: 2,
    backgroundColor: '#10B981',
    marginBottom: 6,
    marginHorizontal: 4,
  },
  stepperLineInactive: {
    backgroundColor: 'rgba(135,206,235,0.2)',
  },
  stepperText: {
    color: '#94A3B8',
    fontSize: 9,
    fontWeight: '500',
    textAlign: 'center',
  },
  stepperTextActive: {
    color: '#F59E0B',
    fontWeight: '700',
  },
  stepperTextInactive: {
    color: 'rgba(135,206,235,0.4)',
  },
  statusStrip: {
    width: '100%',
    backgroundColor: 'rgba(135,206,235,0.12)',
    paddingHorizontal: 16,
    paddingVertical: 14,
    borderRadius: 14,
    marginBottom: 16,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.35)',
    elevation: 2,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
  },
  statusStripLocked: {
    backgroundColor: 'rgba(245,158,11,0.18)',
    borderColor: 'rgba(245,158,11,0.5)',
    shadowColor: '#F59E0B',
  },
  statusStripContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  statusStripText: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '500',
    marginLeft: 4,
  },
  lockedText: {
    color: '#F59E0B',
    fontSize: 12,
    fontWeight: '600',
    fontStyle: 'italic',
  },
  actionButtonsWrapper: {
    width: '100%',
    marginTop: 16,
  },
  actionButtonsContainer: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
    alignItems: 'center',
  },
  acceptButton: {
    flex: 1,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  acceptGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 8,
  },
  acceptButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  viewButton: {
    flex: 1,
    borderRadius: 14,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
  },
  viewButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
  },
  viewButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  messageButton: {
    flex: 1,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.6)',
    backgroundColor: 'rgba(135,206,235,0.12)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
  },
  messageButtonLocked: {
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(135,206,235,0.06)',
    opacity: 0.6,
  },
  messageButtonText: {
    color: SKY,
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  messageButtonTextLocked: {
    color: 'rgba(135,206,235,0.5)',
  },
  pendingPaymentButton: {
    width: '100%',
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 8,
  },
  pendingPaymentGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
  },
  pendingPaymentButtonText: {
    color: '#F59E0B',
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  paymentNotificationText: {
    color: 'rgba(16,185,129,0.9)',
    fontSize: 11,
    textAlign: 'center',
    fontWeight: '600',
    width: '100%',
  },
  unlocksListContainer: {
    marginTop: 12,
    padding: 12,
    backgroundColor: 'rgba(135,206,235,0.08)',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  unlocksListTitle: {
    color: 'rgba(135,206,235,0.9)',
    fontSize: 11,
    fontWeight: '700',
    marginBottom: 8,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  unlocksList: {
    gap: 6,
  },
  unlocksListItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  unlocksListText: {
    color: 'rgba(135,206,235,0.7)',
    fontSize: 11,
    fontWeight: '500',
  },
  messageLockedNote: {
    color: 'rgba(135,206,235,0.7)',
    fontSize: 10,
    textAlign: 'center',
    marginTop: 8,
    fontStyle: 'italic',
    fontWeight: '500',
    width: '100%',
  },
  holdButton: {
    flex: 1,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(245,158,11,0.4)',
  },
  holdGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    gap: 8,
  },
  holdButtonText: {
    color: '#F59E0B',
    fontSize: 16,
    fontWeight: '600',
  },
  indicatorContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 8,
  },
  indicatorDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(135,206,235,0.3)',
  },
  indicatorDotActive: {
    width: 24,
    backgroundColor: SKY,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyCard: {
    padding: 40,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    position: 'relative',
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
  },
});
