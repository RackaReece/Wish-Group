import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  ScrollView,
  StatusBar,
} from 'react-native';
import { router } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const valeterTheme = getAccountTheme('valeter');
const VALETER_PRIMARY = valeterTheme.primary;
const VALETER_PRIMARY_ALT = valeterTheme.primaryAlt;

interface WelcomeFeature {
  id: string;
  icon: string;
  title: string;
  description: string;
  color: string;
}

interface EarningPotential {
  level: string;
  jobs: number;
  earnings: number;
  color: string;
}

export default function ValeterWelcome() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const [currentStep, setCurrentStep] = useState(0);
  const [showFeatures, setShowFeatures] = useState(false);
  const [showEarnings, setShowEarnings] = useState(false);
  
  // Animation values
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const scaleAnim = useRef(new Animated.Value(0.8)).current;
  const bubbleAnim = useRef(new Animated.Value(0)).current;
  const featureAnim = useRef(new Animated.Value(0)).current;
  const earningAnim = useRef(new Animated.Value(0)).current;
  const scrollY = useRef(new Animated.Value(0)).current;

  const welcomeSteps = [
    {
      title: `Welcome to the Team, ${user?.name?.split(' ')[0] || 'Professional'}!`,
      subtitle: 'Your journey to success starts here',
      description: 'Join our elite network of professional valeters and start earning while delivering exceptional service.',
      icon: 'briefcase',
      color: VALETER_PRIMARY,
    },
    {
      title: 'Flexible Work, Maximum Earnings 💰',
      subtitle: 'Work when you want, earn what you deserve',
      description: 'Set your own schedule, choose your jobs, and keep up to 85% of every booking. No more fixed hours or low wages.',
      icon: 'cash',
      color: VALETER_PRIMARY_ALT,
    },
    {
      title: 'Professional Support & Growth 📈',
      subtitle: 'We invest in your success',
      description: 'Get training, equipment support, insurance coverage, and continuous professional development opportunities.',
      icon: 'trending-up',
      color: VALETER_PRIMARY,
    },
  ];

  const features: WelcomeFeature[] = [
    {
      id: '1',
      icon: 'flash',
      title: 'Flexible Schedule',
      description: 'Work when you want - mornings, evenings, weekends',
      color: VALETER_PRIMARY,
    },
    {
      id: '2',
      icon: 'cash',
      title: 'High Earnings',
      description: 'Keep up to 85% of every booking with transparent pricing',
      color: VALETER_PRIMARY_ALT,
    },
    {
      id: '3',
      icon: 'target',
      title: 'Job Selection',
      description: 'Choose jobs that fit your skills and preferences',
      color: VALETER_PRIMARY,
    },
    {
      id: '4',
      icon: 'shield-checkmark',
      title: 'Full Insurance',
      description: 'Complete coverage for you and your customers',
      color: VALETER_PRIMARY_ALT,
    },
    {
      id: '5',
      icon: 'phone-portrait',
      title: 'Smart App',
      description: 'Easy job management and customer communication',
      color: VALETER_PRIMARY,
    },
    {
      id: '6',
      icon: 'trophy',
      title: 'Rewards System',
      description: 'Earn bonuses and recognition for great service',
      color: VALETER_PRIMARY_ALT,
    },
  ];

  const earningPotentials: EarningPotential[] = [
    {
      level: 'Starter',
      jobs: 10,
      earnings: 250,
      color: VALETER_PRIMARY,
    },
    {
      level: 'Professional',
      jobs: 25,
      earnings: 650,
      color: VALETER_PRIMARY_ALT,
    },
    {
      level: 'Expert',
      jobs: 50,
      earnings: 1400,
      color: VALETER_PRIMARY,
    },
    {
      level: 'Elite',
      jobs: 100,
      earnings: 3200,
      color: VALETER_PRIMARY_ALT,
    },
  ];

  useEffect(() => {
    // Initial animation
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 1000,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 1000,
        useNativeDriver: true,
      }),
    ]).start();

    // Bubble animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(bubbleAnim, {
          toValue: 1,
          duration: 3000,
          useNativeDriver: true,
        }),
        Animated.timing(bubbleAnim, {
          toValue: 0,
          duration: 3000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Show features after initial animation
    setTimeout(() => {
      setShowFeatures(true);
      Animated.timing(featureAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }).start();
    }, 2000);

    // Show earnings after features
    setTimeout(() => {
      setShowEarnings(true);
      Animated.timing(earningAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }).start();
    }, 3500);
  }, []);

  const handleGetStarted = async () => {
    try {
      await hapticFeedback('medium');
    } catch (error) {
      // Haptic feedback not available
    }
    router.replace('/valeter/valeter-dashboard');
  };

  const handleSkip = async () => {
    try {
      await hapticFeedback('light');
    } catch (error) {
      // Haptic feedback not available
    }
    router.replace('/valeter/valeter-dashboard');
  };

  const headerHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [140, 100],
    extrapolate: 'clamp',
  });

  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 50, 100],
    outputRange: [1, 0.8, 0.6],
    extrapolate: 'clamp',
  });

  const renderWelcomeStep = (step: any, index: number) => (
    <Animated.View
      key={index}
      style={[
        styles.welcomeStep,
        {
          opacity: fadeAnim,
          transform: [
            { translateY: slideAnim },
            { scale: scaleAnim },
          ],
        },
      ]}
    >
      <LinearGradient
        colors={['rgba(255,255,255,0.12)', 'rgba(255,255,255,0.06)']}
        style={styles.stepCard}
      >
        <View style={[styles.stepIconWrapper, { backgroundColor: `${step.color}20` }]}>
          <Ionicons name={step.icon as any} size={32} color={step.color} />
        </View>
        <Text style={styles.stepTitle}>{step.title}</Text>
        <Text style={styles.stepSubtitle}>{step.subtitle}</Text>
        <Text style={styles.stepDescription}>{step.description}</Text>
      </LinearGradient>
    </Animated.View>
  );

  const renderFeature = (feature: WelcomeFeature, index: number) => (
    <Animated.View
      key={feature.id}
      style={[
        styles.featureCard,
        {
          opacity: featureAnim,
          transform: [
            {
              translateY: featureAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [50, 0],
              }),
            },
          ],
        },
      ]}
    >
      <LinearGradient
        colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.04)']}
        style={styles.featureGradient}
      >
        <View style={[styles.featureIconWrapper, { backgroundColor: `${feature.color}20` }]}>
          <Ionicons name={feature.icon as any} size={24} color={feature.color} />
        </View>
        <View style={styles.featureContent}>
          <Text style={styles.featureTitle}>{feature.title}</Text>
          <Text style={styles.featureDescription}>{feature.description}</Text>
        </View>
      </LinearGradient>
    </Animated.View>
  );

  const renderEarningPotential = (earning: EarningPotential, index: number) => (
    <Animated.View
      key={earning.level}
      style={[
        styles.earningCard,
        {
          opacity: earningAnim,
          transform: [
            {
              translateY: earningAnim.interpolate({
                inputRange: [0, 1],
                outputRange: [30, 0],
              }),
            },
          ],
        },
      ]}
    >
      <LinearGradient
        colors={[`${earning.color}40`, `${earning.color}20`]}
        style={styles.earningGradient}
      >
        <View style={[styles.earningHeader, { backgroundColor: earning.color }]}>
          <Text style={styles.earningLevel}>{earning.level}</Text>
        </View>
        <View style={styles.earningContent}>
            <View style={styles.earningStat}>
              <View style={styles.earningStatIconWrapper}>
                <Ionicons name="briefcase" size={18} color={VALETER_PRIMARY} />
              </View>
              <Text style={styles.earningValue}>{earning.jobs}</Text>
              <Text style={styles.earningLabel}>Jobs per week</Text>
            </View>
            <View style={styles.earningStat}>
              <View style={styles.earningStatIconWrapper}>
                <Ionicons name="wallet" size={18} color={VALETER_PRIMARY} />
              </View>
            <Text style={styles.earningValue}>£{earning.earnings}</Text>
            <Text style={styles.earningLabel}>Weekly earnings</Text>
          </View>
        </View>
      </LinearGradient>
    </Animated.View>
  );

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={valeterTheme.background} style={StyleSheet.absoluteFill} />

      {/* Animated Header */}
      <Animated.View
        style={[
          styles.header,
          {
            height: headerHeight,
            opacity: headerOpacity,
            paddingTop: insets.top,
          },
        ]}
      >
        <LinearGradient
          colors={valeterTheme.headerBackground || [VALETER_PRIMARY, VALETER_PRIMARY_ALT]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
        
        <View style={styles.headerContent}>
          <View style={styles.logoContainer}>
            <Ionicons name="car-sport" size={48} color={VALETER_PRIMARY} />
            <Text style={styles.brandName}>Wish a Wash</Text>
            <Text style={styles.tagline}>Professional Car Care Services</Text>
          </View>
        </View>
      </Animated.View>

      {/* Animated bubbles */}
      <Animated.View
        style={[
          styles.bubble,
          styles.bubble1,
          {
            opacity: bubbleAnim,
            transform: [
              {
                translateY: bubbleAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [-30, 30],
                }),
              },
              {
                scale: bubbleAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0.8, 1.2],
                }),
              },
            ],
          },
        ]}
      />
      <Animated.View
        style={[
          styles.bubble,
          styles.bubble2,
          {
            opacity: bubbleAnim.interpolate({
              inputRange: [0, 0.5, 1],
              outputRange: [0, 1, 0],
            }),
            transform: [
              {
                translateY: bubbleAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [-40, 40],
                }),
              },
              {
                scale: bubbleAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0.6, 1.4],
                }),
              },
            ],
          },
        ]}
      />
      <Animated.View
        style={[
          styles.bubble,
          styles.bubble3,
          {
            opacity: bubbleAnim.interpolate({
              inputRange: [0, 0.5, 1],
              outputRange: [0, 1, 0],
            }),
            transform: [
              {
                translateY: bubbleAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [-35, 35],
                }),
              },
              {
                scale: bubbleAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [0.7, 1.3],
                }),
              },
            ],
          },
        ]}
      />

      {/* Content */}
      <Animated.ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event(
          [{ nativeEvent: { contentOffset: { y: scrollY } } }],
          { useNativeDriver: false }
        )}
        scrollEventThrottle={16}
        contentContainerStyle={{ paddingTop: 160, paddingBottom: 40 }}
      >
        {/* Welcome Steps */}
        <View style={styles.welcomeSection}>
          {welcomeSteps.map((step, index) => renderWelcomeStep(step, index))}
        </View>

        {/* Features Grid */}
        {showFeatures && (
          <View style={styles.featuresSection}>
            <Text style={styles.sectionTitle}>Why Choose Wish a Wash?</Text>
            <View style={styles.featuresGrid}>
              {features.map((feature, index) => renderFeature(feature, index))}
            </View>
          </View>
        )}

        {/* Earning Potential */}
        {showEarnings && (
          <View style={styles.earningsSection}>
            <Text style={styles.sectionTitle}>Your Earning Potential</Text>
            <Text style={styles.sectionSubtitle}>
              Based on weekly performance levels
            </Text>
            <View style={styles.earningsGrid}>
              {earningPotentials.map((earning, index) => renderEarningPotential(earning, index))}
            </View>
          </View>
        )}

        {/* Action Buttons */}
        <View style={styles.actionSection}>
          <TouchableOpacity
            style={styles.getStartedButton}
            onPress={handleGetStarted}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={[VALETER_PRIMARY, VALETER_PRIMARY_ALT]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={styles.getStartedGradient}
            >
              <Ionicons name="rocket" size={20} color="#FFFFFF" />
              <Text style={styles.getStartedText}>Start Earning</Text>
              <Text style={styles.getStartedSubtext}>Begin Your Journey</Text>
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.skipButton}
            onPress={handleSkip}
            activeOpacity={0.7}
          >
            <Text style={styles.skipButtonText}>Skip for now</Text>
          </TouchableOpacity>
        </View>

        {/* Footer */}
        <View style={styles.footer}>
          <Text style={styles.footerText}>
            Join hundreds of successful valeters who have transformed their careers with Wish a Wash
          </Text>
        </View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    overflow: 'hidden',
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  headerContent: {
    flex: 1,
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingBottom: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoContainer: {
    alignItems: 'center',
  },
  logoIcon: {
    fontSize: 48,
    marginBottom: 8,
  },
  brandName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: '800',
    marginBottom: 4,
  },
  tagline: {
    color: VALETER_PRIMARY,
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: '600',
  },
  bubble: {
    position: 'absolute',
    borderRadius: 50,
    backgroundColor: `${VALETER_PRIMARY}30`,
    shadowColor: VALETER_PRIMARY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
  },
  bubble1: {
    width: 60,
    height: 60,
    left: '15%',
    top: '20%',
  },
  bubble2: {
    width: 40,
    height: 40,
    left: '75%',
    top: '30%',
  },
  bubble3: {
    width: 50,
    height: 50,
    left: '60%',
    top: '15%',
  },
  content: {
    flex: 1,
  },
  welcomeSection: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    marginBottom: 32,
  },
  welcomeStep: {
    marginBottom: 20,
  },
  stepCard: {
    borderRadius: 20,
    padding: isSmallScreen ? 20 : 24,
    borderWidth: 1.5,
    borderColor: `${VALETER_PRIMARY}30`,
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  stepIconWrapper: {
    width: 64,
    height: 64,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    alignSelf: 'center',
    borderWidth: 1.5,
    borderColor: `${VALETER_PRIMARY}40`,
  },
  stepTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 8,
    lineHeight: 28,
  },
  stepSubtitle: {
    color: VALETER_PRIMARY,
    fontSize: isSmallScreen ? 15 : 16,
    fontWeight: '700',
    textAlign: 'center',
    marginBottom: 12,
  },
  stepDescription: {
    color: '#E5E7EB',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  featuresSection: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    marginBottom: 32,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 20,
  },
  sectionSubtitle: {
    color: VALETER_PRIMARY,
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 20,
    fontWeight: '600',
  },
  featuresGrid: {
    gap: 12,
  },
  featureCard: {
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: `${VALETER_PRIMARY}30`,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  featureGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    gap: 12,
  },
  featureIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: `${VALETER_PRIMARY}40`,
  },
  featureContent: {
    flex: 1,
  },
  featureTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 4,
  },
  featureDescription: {
    color: '#E5E7EB',
    fontSize: 13,
    lineHeight: 18,
  },
  earningsSection: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    marginBottom: 32,
  },
  earningsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  earningCard: {
    width: (width - (isSmallScreen ? 44 : 52)) / 2,
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: `${VALETER_PRIMARY}30`,
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  earningGradient: {
    borderRadius: 18,
  },
  earningHeader: {
    paddingVertical: 12,
    paddingHorizontal: 16,
    alignItems: 'center',
  },
  earningLevel: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  earningContent: {
    padding: 16,
    gap: 16,
  },
  earningStat: {
    alignItems: 'center',
  },
  earningStatIconWrapper: {
    width: 32,
    height: 32,
    borderRadius: 8,
    backgroundColor: `${VALETER_PRIMARY}20`,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 6,
    borderWidth: 1,
    borderColor: `${VALETER_PRIMARY}40`,
  },
  earningValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '800',
    marginBottom: 2,
  },
  earningLabel: {
    color: VALETER_PRIMARY,
    fontSize: 11,
    fontWeight: '600',
    textAlign: 'center',
  },
  actionSection: {
    paddingHorizontal: isSmallScreen ? 16 : 20,
    marginBottom: 32,
  },
  getStartedButton: {
    marginBottom: 16,
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: VALETER_PRIMARY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    borderWidth: 1.5,
    borderColor: `${VALETER_PRIMARY}40`,
  },
  getStartedGradient: {
    paddingVertical: 18,
    paddingHorizontal: 32,
    alignItems: 'center',
    gap: 8,
  },
  getStartedText: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '800',
  },
  getStartedSubtext: {
    color: '#FFFFFF',
    fontSize: 13,
    opacity: 0.9,
    fontWeight: '600',
  },
  skipButton: {
    alignItems: 'center',
    paddingVertical: 12,
  },
  skipButtonText: {
    color: VALETER_PRIMARY,
    fontSize: 15,
    fontWeight: '600',
    textDecorationLine: 'underline',
  },
  footer: {
    alignItems: 'center',
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingBottom: 20,
  },
  footerText: {
    color: '#E5E7EB',
    fontSize: 13,
    textAlign: 'center',
    lineHeight: 20,
    fontStyle: 'italic',
    opacity: 0.8,
  },
});
