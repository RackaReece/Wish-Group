import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Dimensions,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import GlassCard from '../../../src/components/booking/GlassCard';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const valeterTheme = getAccountTheme('valeter');

interface ValeterProfileData {
  user_id: string;
  vehicle_make?: string;
  vehicle_model?: string;
  vehicle_registration?: string;
}

export default function ValeterVehicleInfo() {
  const router = useRouter();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    if (user?.id) {
      loadProfile();
    }
  }, [user?.id]);

  const loadProfile = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('valeter_profiles')
        .select('user_id, vehicle_make, vehicle_model, vehicle_registration')
        .eq('user_id', user!.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setProfile(data);
      } else {
        const newProfile: Partial<ValeterProfileData> = {
          user_id: user!.id,
        };

        const { data: created, error: createError } = await supabase
          .from('valeter_profiles')
          .insert(newProfile)
          .select()
          .single();

        if (createError) throw createError;
        setProfile(created);
      }
    } catch (error: any) {
      console.error('Error loading profile:', error);
      Alert.alert('Error', 'Failed to load vehicle information');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!user?.id || !profile) return;

    try {
      setIsSaving(true);
      const { error } = await supabase
        .from('valeter_profiles')
        .update({
          vehicle_make: profile.vehicle_make,
          vehicle_model: profile.vehicle_model,
          vehicle_registration: profile.vehicle_registration,
        })
        .eq('user_id', user.id);

      if (error) throw error;

      Alert.alert('Success', 'Vehicle information updated successfully');
      setIsEditing(false);
    } catch (error: any) {
      console.error('Error saving profile:', error);
      Alert.alert('Error', error.message || 'Failed to save vehicle information');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={valeterTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Vehicle Information" accountType="valeter" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={valeterTheme.primary} />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!profile) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={valeterTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Vehicle Information" accountType="valeter" />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Failed to load vehicle information</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={valeterTheme.background} style={StyleSheet.absoluteFill} />

      <AppHeader 
        title="Vehicle Information"
        accountType="valeter"
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              setIsEditing(!isEditing);
            }}
            activeOpacity={0.7}
            style={styles.editButton}
          >
            <Ionicons name={isEditing ? "close" : "create"} size={22} color={valeterTheme.primary} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.contentContainer,
          { paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20 }
        ]}
      >
        {/* Header Card */}
        <GlassCard style={styles.headerCard} accountType="valeter">
          <View style={styles.headerCardContent}>
            <View style={styles.headerIconWrapper}>
              <LinearGradient
                colors={[`${valeterTheme.primary}40`, `${valeterTheme.primaryAlt}30`]}
                style={styles.headerIconGradient}
              >
                <Ionicons name="car" size={32} color={valeterTheme.primary} />
              </LinearGradient>
            </View>
            <View style={styles.headerTextContainer}>
              <Text style={styles.headerTitle}>Vehicle Details</Text>
              <Text style={styles.headerSubtitle}>
                {isEditing ? 'Edit your vehicle information' : 'Manage your vehicle registration'}
              </Text>
            </View>
          </View>
        </GlassCard>

        {/* Vehicle Information Cards */}
        <View style={styles.cardsContainer}>
          {/* Make Card */}
          <GlassCard style={styles.infoCard} accountType="valeter">
            <View style={styles.cardHeader}>
              <View style={styles.cardIconWrapper}>
                <LinearGradient
                  colors={[`${valeterTheme.primary}30`, `${valeterTheme.primaryAlt}20`]}
                  style={styles.cardIconGradient}
                >
                  <Ionicons name="car" size={20} color={valeterTheme.primary} />
                </LinearGradient>
              </View>
              <Text style={styles.cardLabel}>Make</Text>
            </View>
            {isEditing ? (
              <TextInput
                style={styles.cardInput}
                value={profile.vehicle_make || ''}
                onChangeText={(text) => setProfile({ ...profile, vehicle_make: text })}
                placeholder="Auto-filled from DVLA lookup"
                placeholderTextColor="rgba(255,255,255,0.4)"
              />
            ) : (
              <Text style={styles.cardValue}>
                {profile.vehicle_make || 'Not set'}
              </Text>
            )}
          </GlassCard>

          {/* Model Card */}
          <GlassCard style={styles.infoCard} accountType="valeter">
            <View style={styles.cardHeader}>
              <View style={styles.cardIconWrapper}>
                <LinearGradient
                  colors={[`${valeterTheme.primary}30`, `${valeterTheme.primaryAlt}20`]}
                  style={styles.cardIconGradient}
                >
                  <Ionicons name="car-sport" size={20} color={valeterTheme.primary} />
                </LinearGradient>
              </View>
              <Text style={styles.cardLabel}>Model</Text>
            </View>
            {isEditing ? (
              <TextInput
                style={styles.cardInput}
                value={profile.vehicle_model || ''}
                onChangeText={(text) => setProfile({ ...profile, vehicle_model: text })}
                placeholder="Auto-filled from DVLA lookup"
                placeholderTextColor="rgba(255,255,255,0.4)"
              />
            ) : (
              <Text style={styles.cardValue}>
                {profile.vehicle_model || 'Not set'}
              </Text>
            )}
          </GlassCard>

          {/* Registration Card */}
          <GlassCard style={styles.infoCard} accountType="valeter">
            <View style={styles.cardHeader}>
              <View style={styles.cardIconWrapper}>
                <LinearGradient
                  colors={[`${valeterTheme.primary}30`, `${valeterTheme.primaryAlt}20`]}
                  style={styles.cardIconGradient}
                >
                  <Ionicons name="receipt" size={20} color={valeterTheme.primary} />
                </LinearGradient>
              </View>
              <Text style={styles.cardLabel}>Registration</Text>
            </View>
            {isEditing ? (
              <TextInput
                style={styles.cardInput}
                value={profile.vehicle_registration || ''}
                onChangeText={(text) => {
                  const cleanReg = text.replace(/\s/g, '').toUpperCase();
                  setProfile({ ...profile, vehicle_registration: cleanReg });
                }}
                placeholder="Enter UK registration (e.g., AB12 CDE)"
                placeholderTextColor="rgba(255,255,255,0.4)"
                autoCapitalize="characters"
              />
            ) : (
              <Text style={styles.cardValue}>
                {profile.vehicle_registration || 'Not set'}
              </Text>
            )}
          </GlassCard>
        </View>

        {/* Save Button */}
        {isEditing && (
          <TouchableOpacity
            style={[styles.saveButton, isSaving && styles.saveButtonDisabled]}
            onPress={handleSaveProfile}
            disabled={isSaving}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={[valeterTheme.primary, valeterTheme.primaryAlt]}
              style={styles.saveButtonGradient}
            >
              {isSaving ? (
                <ActivityIndicator color="#FFFFFF" />
              ) : (
                <>
                  <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                  <Text style={styles.saveButtonText}>Save Changes</Text>
                </>
              )}
            </LinearGradient>
          </TouchableOpacity>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#FFFFFF',
    marginTop: 16,
    fontSize: 16,
    fontWeight: '500',
  },
  editButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 20,
  },
  headerCard: {
    marginBottom: 24,
    padding: 20,
  },
  headerCardContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  headerIconWrapper: {
    width: 64,
    height: 64,
    borderRadius: 20,
    overflow: 'hidden',
  },
  headerIconGradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTextContainer: {
    flex: 1,
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 4,
    letterSpacing: -0.3,
  },
  headerSubtitle: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
    fontWeight: '500',
  },
  cardsContainer: {
    gap: 16,
    marginBottom: 24,
  },
  infoCard: {
    padding: 20,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 16,
  },
  cardIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 12,
    overflow: 'hidden',
  },
  cardIconGradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardLabel: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  cardValue: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '700',
    letterSpacing: -0.2,
  },
  cardInput: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '600',
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 10,
    borderWidth: 1.5,
    borderColor: 'rgba(59,130,246,0.3)',
  },
  saveButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginTop: 8,
    marginBottom: 8,
    shadowColor: valeterTheme.primary,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 10,
  },
  saveButtonDisabled: {
    opacity: 0.6,
  },
  saveButtonGradient: {
    paddingVertical: 16,
    paddingHorizontal: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
});

