import React, { useState, useEffect, useMemo, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
  Image,
  ActivityIndicator,
  Animated,
  StatusBar,
  Dimensions,
  Modal,
  LayoutAnimation,
  Platform,
  UIManager,
  InteractionManager,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { simpleDocumentUploadService } from '../../../src/services/SimpleDocumentUploadService';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';

import {
  valeterDocumentsSupabaseService,
  UploadedDocument,
} from '../../../src/services/ValeterDocumentsSupabaseService';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;

type UiStatus = 'missing' | 'pending' | 'approved' | 'rejected';

interface RequiredDocument {
  id: string; // MUST match DB docTypeId
  name: string;
  description: string;
  required: boolean;
  type: 'photo';
  icon: string;
}

if (Platform.OS === 'android' && UIManager.setLayoutAnimationEnabledExperimental) {
  UIManager.setLayoutAnimationEnabledExperimental(true);
}

export default function ValeterDocuments() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;

  const [documents, setDocuments] = useState<UploadedDocument[]>([]);
  const [uploading, setUploading] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const [showSourceModal, setShowSourceModal] = useState(false);
  const [selectedDocumentType, setSelectedDocumentType] = useState<RequiredDocument | null>(null);

  // ✅ collapse/expand rows
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const requiredDocuments: RequiredDocument[] = [
    { id: 'profile_photo', name: 'Profile Photo', description: 'Clear face shot on plain background', required: true, type: 'photo', icon: 'camera' },
    { id: 'driving_license', name: 'Driving Licence', description: 'Valid UK driving licence', required: true, type: 'photo', icon: 'car' },
    { id: 'dbs_check', name: 'DBS Check', description: 'Enhanced DBS certificate', required: true, type: 'photo', icon: 'shield-checkmark' },
    { id: 'public_liability', name: 'Public Liability Insurance', description: 'Minimum £2M coverage', required: true, type: 'photo', icon: 'document-text' },
    { id: 'vehicle_insurance', name: 'Vehicle Insurance', description: 'Comprehensive vehicle insurance', required: true, type: 'photo', icon: 'car-sport' },
    { id: 'vehicle_registration', name: 'Vehicle Registration', description: 'V5C registration document', required: true, type: 'photo', icon: 'receipt' },
    { id: 'id_proof', name: 'Proof of Identity', description: 'Valid government-issued ID', required: true, type: 'photo', icon: 'id-card' },
  ];

  const headerHeight = scrollY.interpolate({
    inputRange: [0, 100],
    outputRange: [140, 100],
    extrapolate: 'clamp',
  });

  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 50, 100],
    outputRange: [1, 0.8, 0.6],
    extrapolate: 'clamp',
  });

  useEffect(() => {
    if (!user?.id) return;

    loadDocuments();

    const unsubscribe = valeterDocumentsSupabaseService.subscribeToUserDocuments(user.id, () => {
      loadDocuments();
    });

    return unsubscribe;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const loadDocuments = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const userDocs = await valeterDocumentsSupabaseService.listUserDocuments(user.id);
      setDocuments(userDocs);
    } catch (error) {
      console.error('Error loading documents:', error);
      Alert.alert('Error', 'Failed to load documents');
    } finally {
      setLoading(false);
    }
  };

  const findDocumentForType = (docType: RequiredDocument) => documents.find((d) => d.docTypeId === docType.id);

  const getUiStatus = (docType: RequiredDocument): UiStatus => {
    const doc = findDocumentForType(docType);
    if (!doc) return 'missing';
    if (doc.verificationStatus === 'approved') return 'approved';
    if (doc.verificationStatus === 'rejected') return 'rejected';
    return 'pending';
  };

  const canUpload = (status: UiStatus) => status === 'missing' || status === 'rejected';

  const toggleExpanded = (id: string) => {
    LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
    setExpandedId((prev) => (prev === id ? null : id));
  };

  const openUploadModal = (docType: RequiredDocument) => {
    const status = getUiStatus(docType);
    if (!canUpload(status)) {
      Alert.alert(
        'Upload blocked',
        status === 'pending'
          ? 'This document is awaiting approval. You can’t upload a new one until it’s reviewed.'
          : 'This document has already been approved. Contact support if you need it changed.'
      );
      return;
    }
    setSelectedDocumentType(docType);
    setShowSourceModal(true);
  };

  const performUpload = async (localUri: string) => {
    if (!selectedDocumentType || !user?.id) return;

    await valeterDocumentsSupabaseService.uploadPhotoDocument({
      userId: user.id,
      docTypeId: selectedDocumentType.id,
      docName: selectedDocumentType.name,
      description: selectedDocumentType.description,
      localUri,
    });

    await loadDocuments();
  };

  /**
   * ✅ iOS can silently refuse to present camera/photo picker if we
   * try to open it while a Modal is dismissing.
   * Fix: close modal -> wait interactions -> extra delay -> then open picker.
   */
  const closeModalSafely = async () => {
    if (!showSourceModal) return;

    setShowSourceModal(false);

    await new Promise<void>((resolve) => {
      InteractionManager.runAfterInteractions(() => resolve());
    });

    // extra buffer prevents silent no-op on iOS
    await new Promise((r) => setTimeout(r, 350));
  };

  const handleTakePhoto = async () => {
    if (!selectedDocumentType || !user?.id) return;

    try {
      setUploading(selectedDocumentType.id);

      await closeModalSafely();

      console.log('[ValeterDocs] launch camera for:', selectedDocumentType.id);
      const picked = await simpleDocumentUploadService.takePhoto(selectedDocumentType.name);
      console.log('[ValeterDocs] camera result uri:', picked?.uri);

      if (picked?.uri) {
        await performUpload(picked.uri);
        Alert.alert('Success', `${selectedDocumentType.name} uploaded successfully!`);
      }
    } catch (error) {
      console.error('Error taking photo:', error);
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to take photo');
    } finally {
      setUploading(null);
      setSelectedDocumentType(null);
    }
  };

  const handleChooseFromPhotos = async () => {
    if (!selectedDocumentType || !user?.id) return;

    try {
      setUploading(selectedDocumentType.id);

      await closeModalSafely();

      console.log('[ValeterDocs] launch library for:', selectedDocumentType.id);
      const picked = await simpleDocumentUploadService.pickPhoto(selectedDocumentType.name);
      console.log('[ValeterDocs] library result uri:', picked?.uri);

      if (picked?.uri) {
        await performUpload(picked.uri);
        Alert.alert('Success', `${selectedDocumentType.name} uploaded successfully!`);
      }
    } catch (error) {
      console.error('Error selecting photo:', error);
      Alert.alert('Error', error instanceof Error ? error.message : 'Failed to select photo');
    } finally {
      setUploading(null);
      setSelectedDocumentType(null);
    }
  };

  const handleDeleteDocument = async (docType: RequiredDocument, documentId: string) => {
    const status = getUiStatus(docType);

    if (status === 'pending' || status === 'approved') {
      Alert.alert(
        'Action blocked',
        status === 'pending'
          ? 'This document is awaiting approval and can’t be deleted right now.'
          : 'This document is approved and can’t be deleted. Contact support if you need changes.'
      );
      return;
    }

    Alert.alert('Delete Document', 'Are you sure you want to delete this document?', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Delete',
        style: 'destructive',
        onPress: async () => {
          try {
            await valeterDocumentsSupabaseService.deleteDocument(documentId);
            await loadDocuments();
            Alert.alert('Success', 'Document deleted successfully');
          } catch (error) {
            console.error('Error deleting document:', error);
            Alert.alert('Error', 'Failed to delete document');
          }
        },
      },
    ]);
  };

  const getStatusColor = (status: UiStatus) => {
    switch (status) {
      case 'approved':
        return '#10B981';
      case 'rejected':
        return '#EF4444';
      case 'pending':
        return '#F59E0B';
      default:
        return '#6B7280';
    }
  };

  const getStatusIcon = (status: UiStatus) => {
    switch (status) {
      case 'approved':
        return 'checkmark-circle';
      case 'rejected':
        return 'close-circle';
      case 'pending':
        return 'time';
      default:
        return 'cloud-upload';
    }
  };

  const getStatusLabel = (status: UiStatus) => {
    switch (status) {
      case 'approved':
        return 'Approved';
      case 'rejected':
        return 'Rejected';
      case 'pending':
        return 'Pending';
      default:
        return 'Not uploaded';
    }
  };

  const approvedCount = useMemo(() => documents.filter((d) => d.verificationStatus === 'approved').length, [documents]);
  const progressPercentage = useMemo(() => (approvedCount / requiredDocuments.length) * 100, [approvedCount]);

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#2563EB']} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading documents...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={['#0A1929', '#2563EB']} style={StyleSheet.absoluteFill} />

      <Animated.View
        style={[
          styles.header,
          {
            height: headerHeight,
            opacity: headerOpacity,
            paddingTop: insets.top,
          },
        ]}
      >
        <View style={styles.headerContent}>
          <View style={styles.headerTop}>
            <TouchableOpacity style={styles.backButton} onPress={() => router.back()}>
              <Ionicons name="arrow-back" size={20} color="#FFFFFF" />
            </TouchableOpacity>
            <Text style={styles.headerTitle} numberOfLines={1}>
              Documents
            </Text>
            <View style={styles.placeholder} />
          </View>
        </View>
      </Animated.View>

      <Animated.ScrollView
        style={styles.content}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        contentContainerStyle={{
          paddingTop: 120,
          paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
        }}
      >
        {/* Summary */}
        <View style={styles.summaryCard}>
          <View style={styles.summaryHeader}>
            <View style={styles.summaryIconWrapper}>
              <Ionicons name="checkmark-circle" size={28} color={SKY} />
            </View>
            <View style={styles.summaryTextContainer}>
              <Text style={styles.summaryTitle} numberOfLines={1}>
                Document Verification
              </Text>
              <Text style={styles.summarySubtitle} numberOfLines={2}>
                Tap a row to view details. Pending/Approved docs can’t be replaced.
              </Text>
            </View>
          </View>

          <View style={styles.progressContainer}>
            <View style={styles.progressHeader}>
              <Text style={styles.progressText} numberOfLines={1}>
                {approvedCount} of {requiredDocuments.length} approved
              </Text>
              <Text style={styles.progressPercentage}>{Math.round(progressPercentage)}%</Text>
            </View>
            <View style={styles.progressBar}>
              <View style={[styles.progressFill, { width: `${progressPercentage}%` }]} />
            </View>
          </View>
        </View>

        {/* Documents */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Required Documents</Text>

          {requiredDocuments.map((docType) => {
            const status = getUiStatus(docType);
            const document = findDocumentForType(docType);

            const isExpanded = expandedId === docType.id;
            const isBusy = uploading === docType.id;

            return (
              <View key={docType.id} style={styles.documentCard}>
                <LinearGradient
                  colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.04)']}
                  style={styles.documentGradient}
                >
                  {/* Row (always visible) */}
                  <TouchableOpacity
                    activeOpacity={0.85}
                    onPress={() => toggleExpanded(docType.id)}
                    style={styles.row}
                  >
                    <View style={styles.rowLeft}>
                      <View style={styles.documentIconWrapper}>
                        <Ionicons name={docType.icon as any} size={22} color={SKY} />
                      </View>

                      <View style={styles.rowText}>
                        <Text style={styles.documentName} numberOfLines={1} ellipsizeMode="tail">
                          {docType.name}
                        </Text>
                        <Text style={styles.documentDescription} numberOfLines={1} ellipsizeMode="tail">
                          {docType.description}
                        </Text>
                      </View>
                    </View>

                    <View style={styles.rowRight}>
                      <View
                        style={[
                          styles.statusPill,
                          {
                            backgroundColor: getStatusColor(status) + '20',
                            borderColor: getStatusColor(status) + '55',
                          },
                        ]}
                      >
                        <Ionicons name={getStatusIcon(status) as any} size={14} color={getStatusColor(status)} />
                        <Text style={[styles.statusPillText, { color: getStatusColor(status) }]} numberOfLines={1}>
                          {getStatusLabel(status)}
                        </Text>
                      </View>

                      <Ionicons
                        name={isExpanded ? 'chevron-up' : 'chevron-down'}
                        size={18}
                        color="rgba(255,255,255,0.8)"
                        style={{ marginLeft: 10 }}
                      />
                    </View>
                  </TouchableOpacity>

                  {/* Expand content */}
                  {isExpanded && (
                    <View style={styles.expandWrap}>
                      <View style={styles.divider} />

                      {/* If uploaded show preview + info */}
                      {document ? (
                        <View style={styles.expandContent}>
                          <View style={styles.documentPreview}>
                            {document.uri ? (
                              <Image source={{ uri: document.uri }} style={styles.previewImage} />
                            ) : (
                              <View style={styles.documentIcon}>
                                <Ionicons name="image" size={24} color={SKY} />
                              </View>
                            )}

                            <View style={styles.previewMeta}>
                              <Text style={styles.fileName} numberOfLines={1} ellipsizeMode="middle">
                                {document.name}
                              </Text>
                              <Text style={styles.uploadDate} numberOfLines={1}>
                                Uploaded: {document.uploadDate.toLocaleDateString('en-GB')}
                              </Text>

                              {status === 'pending' && (
                                <Text style={styles.pendingHint} numberOfLines={2}>
                                  Waiting for admin approval — you can’t replace this yet.
                                </Text>
                              )}

                              {status === 'approved' && (
                                <Text style={styles.approvedHint} numberOfLines={2}>
                                  Approved — contact support if you need changes.
                                </Text>
                              )}

                              {status === 'rejected' && !!document.rejectionReason && (
                                <Text style={styles.rejectionText} numberOfLines={3}>
                                  Reason: {document.rejectionReason}
                                </Text>
                              )}
                            </View>
                          </View>

                          <View style={styles.actionsRow}>
                            {/* Re-upload only when rejected */}
                            {status === 'rejected' && (
                              <TouchableOpacity
                                style={[styles.primaryAction, { opacity: isBusy ? 0.6 : 1 }]}
                                onPress={() => openUploadModal(docType)}
                                disabled={isBusy}
                              >
                                {isBusy ? (
                                  <ActivityIndicator size="small" color="#FFFFFF" />
                                ) : (
                                  <>
                                    <Ionicons name="refresh" size={16} color="#FFFFFF" />
                                    <Text style={styles.primaryActionText} numberOfLines={1}>
                                      Re-upload
                                    </Text>
                                  </>
                                )}
                              </TouchableOpacity>
                            )}

                            <TouchableOpacity
                              style={[
                                styles.deleteButton,
                                (status === 'pending' || status === 'approved') && styles.deleteButtonDisabled,
                              ]}
                              onPress={() => handleDeleteDocument(docType, document.id)}
                              disabled={status === 'pending' || status === 'approved'}
                            >
                              <Ionicons
                                name="trash"
                                size={16}
                                color={status === 'pending' || status === 'approved' ? '#9CA3AF' : '#EF4444'}
                              />
                              <Text
                                style={[
                                  styles.deleteButtonText,
                                  (status === 'pending' || status === 'approved') && { color: '#9CA3AF' },
                                ]}
                                numberOfLines={1}
                              >
                                Delete
                              </Text>
                            </TouchableOpacity>
                          </View>
                        </View>
                      ) : (
                        // Not uploaded: show upload button inside dropdown
                        <View style={styles.expandContent}>
                          <TouchableOpacity
                            style={[styles.uploadButton, { opacity: isBusy ? 0.6 : 1 }]}
                            onPress={() => openUploadModal(docType)}
                            disabled={isBusy}
                          >
                            {isBusy ? (
                              <ActivityIndicator size="small" color="#FFFFFF" />
                            ) : (
                              <>
                                <Ionicons name="cloud-upload" size={18} color="#FFFFFF" />
                                <Text style={styles.uploadButtonText} numberOfLines={1}>
                                  Upload Photo
                                </Text>
                              </>
                            )}
                          </TouchableOpacity>
                        </View>
                      )}
                    </View>
                  )}
                </LinearGradient>
              </View>
            );
          })}
        </View>

        {/* Help */}
        <View style={styles.helpSection}>
          <View style={styles.helpHeader}>
            <View style={styles.helpIconWrapper}>
              <LinearGradient
                colors={['rgba(59,130,246,0.3)', 'rgba(37,99,235,0.25)']}
                style={styles.helpIconGradient}
              >
                <Ionicons name="help-circle" size={26} color="#3B82F6" />
              </LinearGradient>
            </View>
            <Text style={styles.helpTitle}>Need Help?</Text>
          </View>
          <Text style={styles.helpText}>
            If you're having trouble uploading documents or need an approved document changed, contact support.
          </Text>

          <TouchableOpacity 
            style={styles.helpButton} 
            onPress={() => router.push('/owner/support/help-support')}
            activeOpacity={0.8}
          >
            <LinearGradient 
              colors={['#3B82F6', '#2563EB']} 
              style={styles.helpButtonGradient}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 0 }}
            >
              <View style={styles.helpButtonIconWrapper}>
                <Ionicons name="chatbubble-ellipses" size={20} color="#FFFFFF" />
              </View>
              <Text style={styles.helpButtonText}>Contact Support</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </Animated.ScrollView>

      {/* Source modal */}
      <Modal
        visible={showSourceModal}
        transparent
        animationType="slide"
        onRequestClose={() => {
          setShowSourceModal(false);
          setSelectedDocumentType(null);
        }}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <LinearGradient
              colors={['rgba(10, 25, 41, 0.98)', 'rgba(10, 25, 41, 0.95)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle} numberOfLines={1}>
                Upload Photo
              </Text>
              <TouchableOpacity
                onPress={() => {
                  setShowSourceModal(false);
                  setSelectedDocumentType(null);
                }}
              >
                <Ionicons name="close" size={24} color={SKY} />
              </TouchableOpacity>
            </View>

            <View style={styles.modalBody}>
              <TouchableOpacity
                style={styles.sourceOption}
                onPress={handleTakePhoto}
                activeOpacity={0.7}
                disabled={!!uploading}
              >
                <LinearGradient
                  colors={['rgba(135,206,235,0.2)', 'rgba(135,206,235,0.1)']}
                  style={styles.sourceOptionGradient}
                >
                  <View style={styles.sourceOptionIcon}>
                    <Ionicons name="camera" size={32} color={SKY} />
                  </View>
                  <Text style={styles.sourceOptionTitle} numberOfLines={1}>
                    Take Photo
                  </Text>
                  <Text style={styles.sourceOptionSubtitle} numberOfLines={2}>
                    Use your camera to capture the document
                  </Text>
                </LinearGradient>
              </TouchableOpacity>

              <TouchableOpacity
                style={styles.sourceOption}
                onPress={handleChooseFromPhotos}
                activeOpacity={0.7}
                disabled={!!uploading}
              >
                <LinearGradient
                  colors={['rgba(135,206,235,0.2)', 'rgba(135,206,235,0.1)']}
                  style={styles.sourceOptionGradient}
                >
                  <View style={[styles.sourceOptionIcon, { backgroundColor: 'rgba(135,206,235,0.15)' }]}>
                    <Ionicons name="images" size={32} color="#87CEEB" />
                  </View>
                  <Text style={styles.sourceOptionTitle} numberOfLines={1}>
                    Choose From Photos
                  </Text>
                  <Text style={styles.sourceOptionSubtitle} numberOfLines={2}>
                    Pick an existing photo from your gallery
                  </Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  loadingText: { color: '#F9FAFB', fontSize: 16, marginTop: 16 },

  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    backgroundColor: '#0A1929',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.15)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  headerContent: { flex: 1, paddingHorizontal: isSmallScreen ? 16 : 20, paddingBottom: 12, justifyContent: 'flex-start' },
  headerTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 8 },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  headerTitle: { fontSize: isSmallScreen ? 20 : 22, fontWeight: '800', color: '#FFFFFF', flex: 1, textAlign: 'center' },
  placeholder: { width: 40 },

  content: { flex: 1, paddingHorizontal: isSmallScreen ? 12 : 20 },

  summaryCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 20,
    padding: 20,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  summaryHeader: { flexDirection: 'row', alignItems: 'center', marginBottom: 16, gap: 12 },
  summaryIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  summaryTextContainer: { flex: 1, minWidth: 0 },
  summaryTitle: { fontSize: isSmallScreen ? 18 : 20, fontWeight: '800', color: '#FFFFFF', marginBottom: 4 },
  summarySubtitle: { fontSize: 13, color: SKY, opacity: 0.9 },

  progressContainer: { marginTop: 12 },
  progressHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8, gap: 10 },
  progressText: { color: '#E5E7EB', fontSize: 14, fontWeight: '600', flex: 1, minWidth: 0 },
  progressPercentage: { color: SKY, fontSize: 16, fontWeight: '800' },
  progressBar: { height: 8, backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: 4, overflow: 'hidden' },
  progressFill: { height: '100%', backgroundColor: '#10B981', borderRadius: 4 },

  section: { marginBottom: 24 },
  sectionTitle: { fontSize: isSmallScreen ? 18 : 20, fontWeight: '600', color: '#FFFFFF', marginBottom: 16 },

  documentCard: {
    marginBottom: 12,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  documentGradient: { padding: 14 },

  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', gap: 10 },
  rowLeft: { flexDirection: 'row', alignItems: 'center', flex: 1, minWidth: 0 },
  rowText: { flex: 1, minWidth: 0 },

  documentIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },

  documentName: { fontSize: 15, fontWeight: '800', color: '#FFFFFF', marginBottom: 2 },
  documentDescription: { fontSize: 12, color: SKY, opacity: 0.9 },

  rowRight: { flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end' },

  statusPill: {
    maxWidth: 130,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
    borderWidth: 1,
  },
  statusPillText: { fontSize: 12, fontWeight: '800' },

  expandWrap: { marginTop: 12 },
  divider: { height: 1, backgroundColor: 'rgba(255,255,255,0.1)', marginBottom: 12 },
  expandContent: { gap: 12 },

  documentPreview: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  previewImage: { width: 64, height: 64, borderRadius: 10 },
  documentIcon: {
    width: 64,
    height: 64,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  previewMeta: { flex: 1, minWidth: 0 },

  fileName: { fontSize: 14, fontWeight: '700', color: '#FFFFFF' },
  uploadDate: { fontSize: 12, color: SKY, opacity: 0.85, marginTop: 2 },

  rejectionText: { fontSize: 12, color: '#EF4444', marginTop: 6, fontWeight: '700' },
  pendingHint: { fontSize: 12, color: '#F59E0B', marginTop: 6, fontWeight: '600', opacity: 0.95 },
  approvedHint: { fontSize: 12, color: '#10B981', marginTop: 6, fontWeight: '600', opacity: 0.95 },

  actionsRow: { flexDirection: 'row', justifyContent: 'flex-end', gap: 10, flexWrap: 'wrap' },

  primaryAction: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    backgroundColor: SKY,
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 10,
    minWidth: 110,
  },
  primaryActionText: { color: '#FFFFFF', fontSize: 12, fontWeight: '800' },

  deleteButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(239,68,68,0.15)',
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
    minWidth: 92,
    justifyContent: 'center',
  },
  deleteButtonDisabled: { backgroundColor: 'rgba(156,163,175,0.12)', borderColor: 'rgba(156,163,175,0.25)' },
  deleteButtonText: { color: '#EF4444', fontSize: 12, fontWeight: '800' },

  uploadButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: SKY,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
  },
  uploadButtonText: { color: '#FFFFFF', fontSize: 14, fontWeight: '800' },

  helpSection: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 20,
    padding: 24,
    marginTop: 24,
    borderWidth: 1.5,
    borderColor: 'rgba(59,130,246,0.25)',
    overflow: 'hidden',
  },
  helpHeader: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    gap: 12, 
    marginBottom: 14 
  },
  helpIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.3)',
  },
  helpIconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  helpTitle: { 
    fontSize: 20, 
    fontWeight: '900', 
    color: '#FFFFFF',
    letterSpacing: -0.3,
  },
  helpText: { 
    fontSize: 14, 
    color: 'rgba(255,255,255,0.8)', 
    marginBottom: 20, 
    lineHeight: 22, 
  },
  helpButton: { 
    borderRadius: 16, 
    overflow: 'hidden', 
    elevation: 8,
    shadowColor: '#3B82F6',
    shadowOffset: { width: 0, height: 4 }, 
    shadowOpacity: 0.4, 
    shadowRadius: 12,
  },
  helpButtonGradient: { 
    flexDirection: 'row', 
    alignItems: 'center', 
    justifyContent: 'center', 
    gap: 10, 
    paddingVertical: 16, 
    paddingHorizontal: 24,
  },
  helpButtonIconWrapper: {
    width: 32,
    height: 32,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  helpButtonText: { 
    color: '#FFFFFF', 
    fontSize: 16, 
    fontWeight: '800',
    letterSpacing: 0.3,
  },

  modalOverlay: { flex: 1, backgroundColor: 'rgba(0, 0, 0, 0.7)', justifyContent: 'flex-end' },
  modalContent: { borderTopLeftRadius: 24, borderTopRightRadius: 24, overflow: 'hidden', paddingBottom: 40 },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.2)',
  },
  modalTitle: { fontSize: 20, fontWeight: '800', color: '#F9FAFB' },
  modalBody: { padding: 20, gap: 16 },
  sourceOption: { borderRadius: 16, overflow: 'hidden', borderWidth: 1.5, borderColor: 'rgba(135,206,235,0.3)' },
  sourceOptionGradient: { padding: 20, alignItems: 'center' },
  sourceOptionIcon: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  sourceOptionTitle: { fontSize: 18, fontWeight: '800', color: '#F9FAFB', marginBottom: 4 },
  sourceOptionSubtitle: { fontSize: 14, color: '#87CEEB', textAlign: 'center', opacity: 0.8 },
});
