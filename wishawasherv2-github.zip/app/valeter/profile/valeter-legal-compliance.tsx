import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';

const SKY = colors.SKY;

interface ValeterDocument {
  id: string;
  type: 'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed';
  name: string;
  description: string;
  status: 'pending' | 'approved' | 'rejected' | 'not_uploaded';
  file_url?: string;
  uploaded_at?: string;
  approved_at?: string;
  rejection_reason?: string;
}

interface ValeterProfileData {
  profile_photo_url?: string;
}

export default function ValeterLegalCompliance() {
  const router = useRouter();
  const { user } = useAuth();
  const [documents, setDocuments] = useState<ValeterDocument[]>([]);
  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const refreshData = async () => {
    if (!user?.id) return;
    setRefreshing(true);
    try {
      await Promise.all([loadDocuments(), loadProfile()]);
    } catch (error) {
      console.error('Error refreshing compliance data:', error);
    } finally {
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (user?.id) {
      // Load both documents and profile in parallel
      Promise.all([loadDocuments(), loadProfile()]).catch(error => {
        console.error('Error loading compliance data:', error);
        setIsLoading(false);
      });
    }
  }, [user?.id]);

  const loadDocuments = async () => {
    if (!user?.id) return;
    try {
      setIsLoading(true);
      // Load documents from Supabase valeter_documents table
      const { data, error } = await supabase
        .from('valeter_documents')
        .select('*')
        .eq('user_id', user.id);

      if (error) {
        console.error('Error loading documents:', error);
        // If table doesn't exist or error, set empty array
        setDocuments([]);
        return;
      }

      if (data && data.length > 0) {
        // Map database documents to ValeterDocument interface - only show real database records
        const mappedDocs: ValeterDocument[] = data
          .map((doc: any) => ({
            id: doc.id,
            type: doc.type as 'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed',
            name: doc.name || 'Document',
            description: doc.description || '',
            status: (doc.status || 'not_uploaded') as 'pending' | 'approved' | 'rejected' | 'not_uploaded',
            file_url: doc.file_url || doc.fileUrl,
            uploaded_at: doc.uploaded_at || doc.created_at,
            approved_at: doc.approved_at || doc.updated_at,
            rejection_reason: doc.rejection_reason,
          }))
          .sort((a, b) => {
            // Sort by uploaded_at date, most recent first
            const dateA = a.uploaded_at ? new Date(a.uploaded_at).getTime() : 0;
            const dateB = b.uploaded_at ? new Date(b.uploaded_at).getTime() : 0;
            return dateB - dateA;
          });
        setDocuments(mappedDocs);
      } else {
        // No documents found in database - set empty array (don't create fake data)
        setDocuments([]);
      }
    } catch (error) {
      console.error('Error loading documents:', error);
      setDocuments([]);
    } finally {
      setIsLoading(false);
    }
  };

  const loadProfile = async () => {
    if (!user?.id) return;
    try {
      // Check valeter_profiles table for profile photo
      const { data: profileData } = await supabase
        .from('valeter_profiles')
        .select('profile_photo_url')
        .eq('user_id', user.id)
        .maybeSingle();
      
      // Also check if profile photo exists in documents table
      const { data: docData } = await supabase
        .from('valeter_documents')
        .select('file_url, status')
        .eq('user_id', user.id)
        .eq('type', 'profile_photo')
        .maybeSingle();
      
      // Use profile photo from valeter_profiles or from documents table
      const profilePhotoUrl = profileData?.profile_photo_url || (docData?.status === 'approved' ? docData.file_url : null);
      
      if (profilePhotoUrl || profileData) {
        setProfile({ profile_photo_url: profilePhotoUrl || profileData?.profile_photo_url });
      }
    } catch (error) {
      console.error('Error loading profile:', error);
    }
    // Note: setIsLoading(false) is handled in loadDocuments
  };

  const getComplianceStatus = () => {
    const issues: string[] = [];
    const recommendations: string[] = [];

    // Define required document types
    const requiredDocTypes: Array<'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed'> = [
      'id_proof',
      'selfie',
      'profile_photo',
      'disclaimer_signed',
    ];
    let missingDocumentsCount = 0;
    let missingTypes: Array<'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed'> = [];

    // Check documents from database (real data only)
    if (documents && documents.length > 0) {
      const rejectedDocs = documents.filter(d => d.status === 'rejected');
      const pendingDocs = documents.filter(d => d.status === 'pending');
      
      // Check which required documents are missing
      const uploadedTypes = documents.map(d => d.type);
      missingTypes = requiredDocTypes.filter(type => !uploadedTypes.includes(type));
      missingDocumentsCount = missingTypes.length;
      
      if (rejectedDocs.length > 0) {
        rejectedDocs.forEach(doc => {
          issues.push(`${doc.name} was rejected${doc.rejection_reason ? `: ${doc.rejection_reason}` : ''}`);
          recommendations.push(`Re-upload ${doc.name} with corrections`);
        });
      }
      
      if (pendingDocs.length > 0) {
        issues.push(`${pendingDocs.length} document(s) pending review`);
        recommendations.push('Wait for document verification to complete');
      }
      
      if (missingTypes.length > 0) {
        const missingNames = missingTypes.map(type => {
          switch (type) {
            case 'id_proof': return 'Proof of Identity';
            case 'selfie': return 'Selfie Photo';
            case 'profile_photo': return 'Profile Photo';
            case 'disclaimer_signed': return 'Terms & Conditions';
            default: return 'Document';
          }
        });
        issues.push(`${missingTypes.length} required document(s) not uploaded: ${missingNames.join(', ')}`);
        recommendations.push('Upload all required documents for verification');
      }
    } else {
      // No documents found in database - all required documents are missing
      issues.push('No documents uploaded yet');
      recommendations.push('Upload all required documents: Proof of Identity, Selfie Photo, Profile Photo, and Terms & Conditions');
      missingDocumentsCount = requiredDocTypes.length;
    }

    // Check profile photo from database (real data)
    const hasProfilePhotoDoc = documents?.some(d => d.type === 'profile_photo') ?? false;
    if (!profile?.profile_photo_url) {
      if (!hasProfilePhotoDoc) {
        issues.push('Profile photo required');
        recommendations.push('Upload a clear profile photo');
        if (!missingTypes.includes('profile_photo') && documents?.length) {
          missingDocumentsCount += 1;
        }
      } else {
        recommendations.push('Profile photo pending approval');
      }
    }

    // Calculate compliance score
    const requiredCount = requiredDocTypes.length;
    const approvedRequired = documents.filter(d => 
      requiredDocTypes.includes(d.type) && d.status === 'approved'
    ).length;
    const complianceScore = Math.round((approvedRequired / requiredCount) * 100);

    const pendingCount = documents.filter(d => d.status === 'pending').length;
    const rejectedCount = documents.filter(d => d.status === 'rejected').length;

    return {
      compliant: issues.length === 0,
      issues,
      recommendations,
      missingDocumentsCount,
      pendingCount,
      rejectedCount,
    };
  };

  const getRemainingItems = () => {
    const requiredDocTypes: Array<'id_proof' | 'selfie' | 'profile_photo' | 'disclaimer_signed'> = [
      'id_proof',
      'selfie',
      'profile_photo',
      'disclaimer_signed',
    ];

    const uploadedTypes = documents.map(d => d.type);
    const missingTypes = requiredDocTypes.filter(type => !uploadedTypes.includes(type));
    const pendingDocs = documents.filter(d => d.status === 'pending');
    const rejectedDocs = documents.filter(d => d.status === 'rejected');

    const remaining: string[] = [];

    if (missingTypes.length > 0) {
      missingTypes.forEach(type => {
        switch (type) {
          case 'id_proof': remaining.push('Proof of Identity'); break;
          case 'selfie': remaining.push('Selfie Photo'); break;
          case 'profile_photo': remaining.push('Profile Photo'); break;
          case 'disclaimer_signed': remaining.push('Terms & Conditions'); break;
        }
      });
    }

    if (rejectedDocs.length > 0) {
      rejectedDocs.forEach(doc => {
        remaining.push(`${doc.name} (needs re-upload)`);
      });
    }

    if (pendingDocs.length > 0) {
      remaining.push(`${pendingDocs.length} document(s) pending review`);
    }

    return remaining;
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#2563EB']} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const compliance = getComplianceStatus();
  const remainingItems = getRemainingItems();
  const isCompleted = compliance.compliant && remainingItems.length === 0;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={['#0A1929', '#2563EB']} style={StyleSheet.absoluteFill} />

      <AppHeader title="Legal Compliance" />

      <ScrollView 
        style={styles.content} 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: 40 }}
        refreshControl={
          <RefreshControl
            refreshing={refreshing}
            onRefresh={refreshData}
            tintColor={SKY}
            colors={[SKY]}
          />
        }
      >
        {/* Completion Status */}
        {isCompleted ? (
          <View style={styles.section}>
            <View style={styles.completedCard}>
              <LinearGradient
                colors={['rgba(16,185,129,0.2)', 'rgba(5,150,105,0.15)']}
                style={styles.completedGradient}
              >
                <View style={styles.completedContent}>
                  <View style={styles.completedBadge}>
                    <Ionicons name="checkmark-circle" size={32} color="#10B981" />
                  </View>
                  <Text style={styles.completedTitle}>Completed</Text>
                  <Text style={styles.completedSubtitle}>All compliance requirements have been met</Text>
                </View>
              </LinearGradient>
            </View>
          </View>
        ) : (
          <View style={styles.section}>
            <View style={styles.remainingCard}>
              <View style={styles.remainingHeader}>
                <Ionicons name="list" size={20} color={SKY} />
                <Text style={styles.remainingTitle}>What's Left</Text>
              </View>
              {remainingItems.map((item, index) => (
                <View key={index} style={styles.remainingItem}>
                  <Ionicons name="ellipse" size={8} color={SKY} style={{ marginRight: 12, marginTop: 6 }} />
                  <Text style={styles.remainingItemText}>{item}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        {/* Timeline Section */}
        {documents.length > 0 && (
          <View style={styles.section}>
            <View style={styles.timelineCard}>
              <View style={styles.timelineHeader}>
                <Ionicons name="time-outline" size={20} color={SKY} />
                <Text style={styles.timelineTitle}>Document Timeline</Text>
              </View>
              
              {documents.slice(0, 10).map((doc) => {
                const uploadDate = doc.uploaded_at ? new Date(doc.uploaded_at) : null;
                const approvalDate = doc.approved_at ? new Date(doc.approved_at) : null;
                const statusColor = doc.status === 'approved' ? '#10B981' :
                                   doc.status === 'rejected' ? '#EF4444' :
                                   doc.status === 'pending' ? '#EAB308' : '#6B7280';
                
                return (
                  <View key={doc.id} style={styles.timelineItem}>
                    <View style={[styles.timelineDot, { backgroundColor: statusColor }]} />
                    <View style={styles.timelineContent}>
                      <View style={styles.timelineItemHeader}>
                        <Text style={styles.timelineItemName}>{doc.name}</Text>
                        <View style={[styles.timelineStatusBadge, { backgroundColor: `${statusColor}20` }]}>
                          <Text style={[styles.timelineStatusText, { color: statusColor }]}>
                            {doc.status.charAt(0).toUpperCase() + doc.status.slice(1)}
                          </Text>
                        </View>
                      </View>
                      {uploadDate && (
                        <Text style={styles.timelineDate}>
                          Uploaded: {uploadDate.toLocaleDateString('en-GB', { 
                            day: 'numeric', 
                            month: 'short', 
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </Text>
                      )}
                      {approvalDate && (
                        <Text style={styles.timelineDate}>
                          {doc.status === 'approved' ? 'Approved' : 'Updated'}: {approvalDate.toLocaleDateString('en-GB', { 
                            day: 'numeric', 
                            month: 'short', 
                            year: 'numeric',
                            hour: '2-digit',
                            minute: '2-digit'
                          })}
                        </Text>
                      )}
                      {doc.rejection_reason && (
                        <Text style={styles.timelineRejectionReason}>
                          Reason: {doc.rejection_reason}
                        </Text>
                      )}
                    </View>
                  </View>
                );
              })}
            </View>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#FFFFFF',
    marginTop: 16,
  },
  refreshButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  refreshingIcon: {
    opacity: 0.5,
  },
  lastUpdatedText: {
    color: '#9CA3AF',
    fontSize: 10,
    marginLeft: 'auto',
  },
  completedCard: {
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 12,
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.15,
    shadowRadius: 2,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  completedGradient: {
    padding: 24,
  },
  completedContent: {
    alignItems: 'center',
  },
  completedBadge: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(16,185,129,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  completedTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '800',
    marginBottom: 8,
  },
  completedSubtitle: {
    color: '#9CA3AF',
    fontSize: 14,
    fontWeight: '500',
    textAlign: 'center',
  },
  remainingCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    marginBottom: 12,
  },
  remainingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  remainingTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  remainingItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
    paddingLeft: 4,
  },
  remainingItemText: {
    color: '#E5E7EB',
    fontSize: 14,
    fontWeight: '500',
    flex: 1,
  },
  timelineCard: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    marginBottom: 12,
  },
  timelineHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  timelineTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  timelineItem: {
    flexDirection: 'row',
    marginBottom: 16,
    paddingLeft: 8,
  },
  timelineDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 12,
    marginTop: 4,
  },
  timelineContent: {
    flex: 1,
    paddingBottom: 16,
    borderLeftWidth: 2,
    borderLeftColor: 'rgba(255,255,255,0.1)',
    paddingLeft: 12,
  },
  timelineItemHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  timelineItemName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    flex: 1,
  },
  timelineStatusBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  timelineStatusText: {
    fontSize: 11,
    fontWeight: '700',
  },
  timelineDate: {
    color: '#9CA3AF',
    fontSize: 12,
    marginTop: 2,
  },
  timelineRejectionReason: {
    color: '#EF4444',
    fontSize: 12,
    marginTop: 4,
    fontStyle: 'italic',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  section: {
    marginBottom: 20,
  },
});

