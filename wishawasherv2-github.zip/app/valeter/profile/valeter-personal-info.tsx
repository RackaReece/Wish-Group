import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Dimensions,
  ActivityIndicator,
  StatusBar,
  Alert,
  Platform,
  Switch,
  Animated,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';

import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;

interface ValeterProfileData {
  user_id: string;
  full_name: string;
  bio?: string;
  experience?: string;
  profile_photo_url?: string;
  is_self_sufficient?: boolean;
}

export default function ValeterPersonalInfo() {
  const router = useRouter();
  const { user } = useAuth();
  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [email, setEmail] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // Floating bubbles animation
  const bubbleData = useRef(
    Array.from({ length: 5 }, (_, i) => ({
      translateY: new Animated.Value(0),
      translateX: new Animated.Value(0),
      opacity: new Animated.Value(0.15 + Math.random() * 0.1),
      scale: new Animated.Value(0.8 + Math.random() * 0.4),
      size: 20 + Math.random() * 30,
      leftPosition: Math.random() * Dimensions.get('window').width,
      duration: 8000 + Math.random() * 4000,
      delay: i * 1000,
    }))
  ).current;

  useEffect(() => {
    bubbleData.forEach((bubble) => {
      const animateBubble = () => {
        Animated.parallel([
          Animated.loop(
            Animated.sequence([
              Animated.timing(bubble.translateY, {
                toValue: -64 - 50,
                duration: bubble.duration,
                useNativeDriver: true,
              }),
              Animated.timing(bubble.translateY, {
                toValue: 0,
                duration: 0,
                useNativeDriver: true,
              }),
            ])
          ),
          Animated.loop(
            Animated.sequence([
              Animated.timing(bubble.translateX, {
                toValue: 20,
                duration: bubble.duration * 0.7,
                useNativeDriver: true,
              }),
              Animated.timing(bubble.translateX, {
                toValue: -20,
                duration: bubble.duration * 0.7,
                useNativeDriver: true,
              }),
            ])
          ),
          Animated.loop(
            Animated.sequence([
              Animated.timing(bubble.scale, {
                toValue: 1.2,
                duration: bubble.duration * 0.5,
                useNativeDriver: true,
              }),
              Animated.timing(bubble.scale, {
                toValue: 0.8,
                duration: bubble.duration * 0.5,
                useNativeDriver: true,
              }),
            ])
          ),
        ]).start();
      };

      const timeout = setTimeout(() => {
        animateBubble();
      }, bubble.delay);

      return () => clearTimeout(timeout);
    });
  }, []);

  useEffect(() => {
    if (user?.id) {
      loadProfile();
    }
  }, [user?.id]);

  const loadProfile = async () => {
    try {
      setIsLoading(true);
      const { data, error } = await supabase
        .from('valeter_profiles')
        .select('*')
        .eq('user_id', user!.id)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setProfile(data);
      } else {
        const newProfile: Partial<ValeterProfileData> = {
          user_id: user!.id,
          full_name: user!.name || 'Valeter',
          bio: 'Professional mobile valeter',
          experience: '0 years',
        };

        const { data: created, error: createError } = await supabase
          .from('valeter_profiles')
          .insert(newProfile)
          .select()
          .single();

        if (createError) throw createError;
        setProfile(created);
      }

      setEmail(user!.email || '');
    } catch (error: any) {
      console.error('Error loading profile:', error);
      Alert.alert('Error', 'Failed to load profile information');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!user?.id || !profile) return;

    try {
      setIsSaving(true);
      const { error } = await supabase
        .from('valeter_profiles')
        .update({
          full_name: profile.full_name,
          bio: profile.bio,
          experience: profile.experience,
          is_self_sufficient: profile.is_self_sufficient,
        })
        .eq('user_id', user.id);

      if (error) throw error;

      Alert.alert('Success', 'Profile updated successfully');
      setIsEditing(false);
    } catch (error: any) {
      console.error('Error saving profile:', error);
      Alert.alert('Error', error.message || 'Failed to save profile');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#2563EB']} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!profile) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0A1929', '#2563EB']} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Failed to load profile</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={['#0A1929', '#2563EB']} style={StyleSheet.absoluteFill} />

      {/* Header */}
      <View style={styles.header}>
        <BlurView
          intensity={Platform.OS === 'ios' ? 30 : 25}
          tint="dark"
          style={StyleSheet.absoluteFill}
        >
          <LinearGradient
            colors={['rgba(10,25,41,0.85)', 'rgba(30,58,138,0.75)']}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
        </BlurView>
        {/* Floating Bubbles */}
        <View style={styles.bubblesContainer}>
          {bubbleData.map((bubble, index) => (
            <Animated.View
              key={index}
              style={[
                styles.bubble,
                {
                  width: bubble.size,
                  height: bubble.size,
                  left: bubble.leftPosition,
                  transform: [
                    { translateY: bubble.translateY },
                    { translateX: bubble.translateX },
                    { scale: bubble.scale },
                  ],
                  opacity: bubble.opacity,
                },
              ]}
            />
          ))}
        </View>
        <View style={styles.glowLine} />
        
        <View style={styles.headerContent}>
          <TouchableOpacity
            style={styles.backButton}
            onPress={async () => {
              await hapticFeedback('light');
              router.back();
            }}
            activeOpacity={0.7}
          >
            <LinearGradient
              colors={['rgba(135,206,235,0.25)', 'rgba(135,206,235,0.15)']}
              style={styles.backButtonGradient}
            >
              <Ionicons name="chevron-back" size={20} color={SKY} />
            </LinearGradient>
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Personal Information</Text>
          <TouchableOpacity
            style={styles.editButton}
            onPress={async () => {
              await hapticFeedback('light');
              setIsEditing(!isEditing);
            }}
            activeOpacity={0.7}
          >
            <LinearGradient
              colors={['rgba(135,206,235,0.25)', 'rgba(135,206,235,0.15)']}
              style={styles.editButtonGradient}
            >
              <Ionicons name={isEditing ? "close" : "create"} size={18} color={SKY} />
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        <View style={styles.section}>
          <View style={styles.settingsContainer}>
            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="person" size={20} color={SKY} style={styles.settingIcon} />
                <Text style={styles.settingText}>Name</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.full_name}
                  onChangeText={(text) => setProfile({ ...profile, full_name: text })}
                  placeholder="Enter your name"
                  placeholderTextColor={SKY}
                />
              ) : (
                <Text style={styles.settingValue}>{profile.full_name}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="mail" size={20} color={SKY} style={styles.settingIcon} />
                <Text style={styles.settingText}>Email</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={email}
                  onChangeText={setEmail}
                  placeholder="Enter your email"
                  placeholderTextColor={SKY}
                  keyboardType="email-address"
                  autoCapitalize="none"
                />
              ) : (
                <Text style={styles.settingValue}>{user?.email || 'No email'}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="document-text" size={20} color={SKY} style={styles.settingIcon} />
                <Text style={styles.settingText}>Bio</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={[styles.settingInput, styles.bioInput]}
                  value={profile.bio || ''}
                  onChangeText={(text) => setProfile({ ...profile, bio: text })}
                  placeholder="Tell customers about yourself"
                  placeholderTextColor={SKY}
                  multiline
                />
              ) : (
                <Text style={styles.settingValue}>{profile.bio || 'No bio added'}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="time" size={20} color={SKY} style={styles.settingIcon} />
                <Text style={styles.settingText}>Experience</Text>
              </View>
              {isEditing ? (
                <TextInput
                  style={styles.settingInput}
                  value={profile.experience || ''}
                  onChangeText={(text) => setProfile({ ...profile, experience: text })}
                  placeholder="e.g., 3+ years"
                  placeholderTextColor={SKY}
                />
              ) : (
                <Text style={styles.settingValue}>{profile.experience || 'Not specified'}</Text>
              )}
            </View>

            <View style={styles.settingItem}>
              <View style={styles.settingLeft}>
                <Ionicons name="battery-charging" size={20} color={SKY} style={styles.settingIcon} />
                <View style={styles.settingTextContainer}>
                  <Text style={styles.settingText}>Self-Sufficient</Text>
                  <Text style={styles.settingSubtext}>I have my own water and electricity</Text>
                </View>
              </View>
              <Switch
                value={profile.is_self_sufficient ?? false}
                onValueChange={async (value) => {
                  await hapticFeedback('light');
                  const updatedProfile = { ...profile, is_self_sufficient: value };
                  setProfile(updatedProfile);
                  // Auto-save when toggled
                  if (user?.id) {
                    try {
                      await supabase
                        .from('valeter_profiles')
                        .update({ is_self_sufficient: value })
                        .eq('user_id', user.id);
                    } catch (error) {
                      console.error('Error saving self-sufficiency:', error);
                    }
                  }
                }}
                trackColor={{ false: 'rgba(135,206,235,0.3)', true: SKY }}
                thumbColor="#FFFFFF"
              />
            </View>
          </View>
        </View>

        {/* Save Button */}
        {isEditing && (
          <View style={styles.section}>
            <TouchableOpacity
              style={[styles.saveButton, isSaving && { opacity: 0.6 }]}
              onPress={handleSaveProfile}
              disabled={isSaving}
            >
              <LinearGradient
                colors={['#10B981', '#059669']}
                style={styles.saveButtonGradient}
              >
                {isSaving ? (
                  <ActivityIndicator color="#FFFFFF" />
                ) : (
                  <Text style={styles.saveButtonText}>Save Changes</Text>
                )}
              </LinearGradient>
            </TouchableOpacity>
          </View>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#FFFFFF',
    marginTop: 16,
  },
  header: {
    height: 64,
    zIndex: 1000,
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    overflow: 'hidden',
  },
  bubblesContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 0,
    overflow: 'hidden',
  },
  bubble: {
    position: 'absolute',
    borderRadius: 50,
    backgroundColor: SKY,
    opacity: 0.15,
  },
  glowLine: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: 'rgba(135,206,235,0.4)',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 4,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    height: 64,
    zIndex: 1,
  },
  backButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    overflow: 'hidden',
  },
  backButtonGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  headerTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    flex: 1,
    textAlign: 'center',
    letterSpacing: 0.2,
  },
  editButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    overflow: 'hidden',
  },
  editButtonGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  section: {
    marginBottom: 20,
  },
  settingsContainer: {
    gap: 8,
  },
  settingItem: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 12,
    paddingVertical: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  settingLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  settingIcon: {
    marginRight: 10,
    width: 20,
    textAlign: 'center',
  },
  settingText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
  },
  settingTextContainer: {
    flex: 1,
  },
  settingSubtext: {
    color: '#9CA3AF',
    fontSize: 11,
    marginTop: 2,
  },
  settingValue: {
    color: SKY,
    fontSize: 13,
    textAlign: 'right',
    flex: 1,
  },
  settingInput: {
    color: '#F9FAFB',
    fontSize: 13,
    textAlign: 'right',
    flex: 1,
    borderBottomWidth: 1,
    borderBottomColor: SKY,
    paddingVertical: 4,
  },
  bioInput: {
    height: 60,
    textAlignVertical: 'top',
  },
  saveButton: {
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  saveButtonGradient: {
    paddingVertical: 16,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});

