import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Linking,
  Alert,
  Dimensions,
  Animated,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const valeterTheme = getAccountTheme('valeter');

const WHATSAPP_NUMBER = '+447960944743';
const EMAIL = 'info@wishawashapp.com';

const faqs = [
  {
    id: 'getting-started',
    question: 'How do I get started as a valeter?',
    answer: 'Complete your profile, upload required documents for verification, and set your working hours. Once verified, you can start accepting job requests from the Jobs page.',
  },
  {
    id: 'jobs',
    question: 'How do I accept and complete jobs?',
    answer: 'Go to the Jobs page to see available bookings in your area. Tap on a job to view details, then accept it. Once you arrive and complete the service, mark it as complete and upload photos if required.',
  },
  {
    id: 'earnings',
    question: 'How do I track my earnings?',
    answer: 'Visit your Dashboard to see your daily, weekly, and monthly earnings. You can also view your earnings history and payout information in the Analytics section.',
  },
  {
    id: 'ratings',
    question: 'How do ratings work?',
    answer: 'Customers rate your service after completion. Your average rating affects your visibility and tier level. Maintain high ratings by providing excellent service and arriving on time.',
  },
  {
    id: 'tiers',
    question: 'What are service tiers?',
    answer: 'Service tiers (Basic, Standard, Premium) determine your pricing and service level. Higher tiers allow you to charge more. Your tier is based on your experience, ratings, and performance.',
  },
  {
    id: 'documents',
    question: 'What documents do I need?',
    answer: 'You need to upload verification documents including ID, insurance, and any required licences. Go to Profile > Documents to upload and manage your documents.',
  },
  {
    id: 'issues',
    question: 'What if I have a problem?',
    answer: 'For urgent issues, contact us directly via WhatsApp or email. For booking-related problems, you can report issues through the app or contact the business directly.',
  },
];

export default function ValeterHelp() {
  const insets = useSafeAreaInsets();
  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const [expandedFaq, setExpandedFaq] = useState<string | null>(null);

  React.useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();
  }, []);

  const handleWhatsApp = async () => {
    await hapticFeedback('light');
    const url = `https://wa.me/${WHATSAPP_NUMBER.replace(/[^0-9]/g, '')}`;
    try {
      const canOpen = await Linking.canOpenURL(url);
      if (canOpen) {
        await Linking.openURL(url);
      } else {
        Alert.alert('Error', 'WhatsApp is not installed on this device.');
      }
    } catch (error) {
      console.error('Error opening WhatsApp:', error);
    }
  };

  const handleEmail = async () => {
    await hapticFeedback('light');
    const url = `mailto:${EMAIL}?subject=Valeter Support Request`;
    try {
      await Linking.openURL(url);
    } catch (error) {
      console.error('Error opening email:', error);
    }
  };

  const toggleFaq = async (id: string) => {
    await hapticFeedback('light');
    setExpandedFaq(expandedFaq === id ? null : id);
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={valeterTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />
      <SafeAreaView style={styles.container} edges={['top']}>
        <AppHeader
          title="Help & Support"
          scrollY={scrollY}
          enableScrollAnimation={true}
          accountType="valeter"
          onBack={() => router.back()}
        />

        <Animated.ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
            useNativeDriver: false,
          })}
          scrollEventThrottle={16}
          contentContainerStyle={[
            styles.scrollContent,
            {
              paddingTop: HEADER_CONTENT_OFFSET,
              paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
            },
          ]}
        >
          {/* Contact Section */}
          <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
            <Text style={styles.sectionTitle}>Get in Touch</Text>
            <Text style={styles.sectionDescription}>
              Need help? Contact our support team via email or WhatsApp.
            </Text>

            <View style={styles.contactContainer}>
              <TouchableOpacity
                onPress={handleEmail}
                activeOpacity={0.9}
                style={styles.contactCardWrapper}
              >
                <GlassCard style={styles.contactCard} accountType="valeter" borderColor={`${SKY}40`}>
                  <View style={styles.contactContent}>
                    <View style={[styles.contactIconWrapper, { backgroundColor: `${SKY}25` }]}>
                      <Ionicons name="mail" size={24} color={SKY} />
                    </View>
                    <View style={styles.contactTextContainer}>
                      <Text style={styles.contactLabel}>Email Support</Text>
                      <Text style={styles.contactValue}>{EMAIL}</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color={SKY} />
                  </View>
                </GlassCard>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={handleWhatsApp}
                activeOpacity={0.9}
                style={styles.contactCardWrapper}
              >
                <GlassCard style={styles.contactCard} accountType="valeter" borderColor="rgba(37,211,102,0.4)">
                  <View style={styles.contactContent}>
                    <View style={[styles.contactIconWrapper, { backgroundColor: 'rgba(37,211,102,0.25)' }]}>
                      <Ionicons name="logo-whatsapp" size={24} color="#25D366" />
                    </View>
                    <View style={styles.contactTextContainer}>
                      <Text style={styles.contactLabel}>WhatsApp Support</Text>
                      <Text style={styles.contactValue}>{WHATSAPP_NUMBER}</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color="#25D366" />
                  </View>
                </GlassCard>
              </TouchableOpacity>
            </View>
          </Animated.View>

          {/* FAQs Section */}
          <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
            <Text style={styles.sectionTitle}>Frequently Asked Questions</Text>
            <Text style={styles.sectionDescription}>
              Find answers to common questions about using Wish a Wash as a valeter.
            </Text>

            <View style={styles.faqContainer}>
              {faqs.map((faq) => {
                const isExpanded = expandedFaq === faq.id;
                return (
                  <TouchableOpacity
                    key={faq.id}
                    onPress={() => toggleFaq(faq.id)}
                    activeOpacity={0.9}
                    style={styles.faqCardWrapper}
                  >
                    <GlassCard style={styles.faqCard} accountType="valeter" borderColor={`${SKY}30`}>
                      <View style={styles.faqHeader}>
                        <Text style={styles.faqQuestion}>{faq.question}</Text>
                        <Ionicons
                          name={isExpanded ? 'chevron-up' : 'chevron-down'}
                          size={20}
                          color={SKY}
                        />
                      </View>
                      {isExpanded && (
                        <View style={styles.faqAnswerContainer}>
                          <Text style={styles.faqAnswer}>{faq.answer}</Text>
                        </View>
                      )}
                    </GlassCard>
                  </TouchableOpacity>
                );
              })}
            </View>
          </Animated.View>

          <View style={{ height: 22 }} />
        </Animated.ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  section: {
    marginBottom: 32,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 8,
    letterSpacing: 0.2,
  },
  sectionDescription: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    marginBottom: 20,
    lineHeight: 20,
  },
  contactContainer: {
    gap: 12,
  },
  contactCardWrapper: {
    marginBottom: 0,
  },
  contactCard: {
    padding: 16,
  },
  contactContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  contactIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  contactTextContainer: {
    flex: 1,
  },
  contactLabel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  contactValue: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 13,
  },
  faqContainer: {
    gap: 12,
  },
  faqCardWrapper: {
    marginBottom: 0,
  },
  faqCard: {
    padding: 16,
  },
  faqHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  faqQuestion: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '600',
    lineHeight: 22,
  },
  faqAnswerContainer: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  faqAnswer: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 14,
    lineHeight: 20,
  },
});
