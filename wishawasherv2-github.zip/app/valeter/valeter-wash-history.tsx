import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
  Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { getServiceDisplayName } from '../../src/utils/serviceNameMapper';
import AppHeader, { HEADER_CONTENT_OFFSET, HEADER_HEIGHT } from '../../src/components/shared/AppHeader';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { colors } from '../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function ValeterWashHistory() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [bookings, setBookings] = useState<any[]>([]);
  const [totalEarnings, setTotalEarnings] = useState(0);
  const [stats, setStats] = useState({
    totalJobs: 0,
    thisMonth: 0,
    thisWeek: 0,
    averageRating: 0,
  });

  const loadBookings = async () => {
    if (!user?.id) return;
    try {
      // Load valeter bookings from Supabase
      const { data: allBookings, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id);
      
      if (error) throw error;
      
      const bookingsList = allBookings || [];
      const completed = bookingsList.filter((b: any) => 
        ['completed', 'rated', 'closed'].includes(b.status)
      );
      
      // Sort by completion date (most recent first)
      const sorted = completed.sort((a: any, b: any) => {
        const dateA = a.updated_at || a.created_at || a.completed_at;
        const dateB = b.updated_at || b.created_at || b.completed_at;
        const timeA = dateA ? new Date(dateA).getTime() : 0;
        const timeB = dateB ? new Date(dateB).getTime() : 0;
        return timeB - timeA;
      });
      
      setBookings(sorted);
      
      // Calculate earnings
      const earnings = completed.reduce((sum: number, b: any) => sum + (b.price || 0), 0);
      setTotalEarnings(earnings);
      
      // Calculate stats
      const now = new Date();
      const firstDayOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
      const firstDayOfWeek = new Date(now);
      firstDayOfWeek.setDate(now.getDate() - now.getDay());
      
      const thisMonth = completed.filter((b: any) => {
        const date = b.updated_at || b.created_at || b.completed_at;
        return date && new Date(date) >= firstDayOfMonth;
      }).length;
      
      const thisWeek = completed.filter((b: any) => {
        const date = b.updated_at || b.created_at || b.completed_at;
        return date && new Date(date) >= firstDayOfWeek;
      }).length;
      
      setStats({
        totalJobs: completed.length,
        thisMonth,
        thisWeek,
        averageRating: 0, // TODO: Calculate from reviews
      });
    } catch (error: any) {
      console.error('[ValeterWashHistory] Error loading bookings:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadBookings();
  }, [user?.id]);

  const onRefresh = () => {
    setRefreshing(true);
    loadBookings();
  };


  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={[BG, colors.headerBg]} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading earnings history...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={['#0A1929', '#2563EB']} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader
        title="Earnings"
        subtitle={`£${totalEarnings.toFixed(2)} total`}
        rightAction={
          <TouchableOpacity onPress={loadBookings} style={styles.refreshButton}>
            <Ionicons name="refresh" size={20} color={SKY} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent, 
          { 
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          }
        ]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {/* Earnings Summary */}
        <View style={styles.earningsCard}>
          <LinearGradient
            colors={['rgba(135,206,235,0.3)', 'rgba(37,99,235,0.25)', 'rgba(135,206,235,0.2)']}
            style={styles.earningsGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
          >
            <View style={styles.earningsIconWrapper}>
              <LinearGradient
                colors={['rgba(135,206,235,0.4)', 'rgba(37,99,235,0.3)']}
                style={StyleSheet.absoluteFill}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              />
              <Ionicons name="wallet" size={40} color={SKY} />
            </View>
            <Text style={styles.earningsLabel}>Total Earnings</Text>
            <Text style={styles.earningsValue}>£{totalEarnings.toFixed(2)}</Text>
            <Text style={styles.earningsSubtext}>{bookings.length} completed jobs</Text>
          </LinearGradient>
        </View>

        {/* Stats Grid */}
        <View style={styles.statsGrid}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{stats.totalJobs}</Text>
            <Text style={styles.statLabel}>Total Jobs</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{stats.thisMonth}</Text>
            <Text style={styles.statLabel}>This Month</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>{stats.thisWeek}</Text>
            <Text style={styles.statLabel}>This Week</Text>
          </View>
          {stats.averageRating > 0 && (
            <View style={styles.statCard}>
              <Text style={styles.statNumber}>{stats.averageRating.toFixed(1)}</Text>
              <Text style={styles.statLabel}>Avg Rating</Text>
            </View>
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  scrollView: { flex: 1 },
  scrollContent: { padding: 20 },
  refreshButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  earningsCard: {
    borderRadius: 24,
    overflow: 'hidden',
    marginBottom: 24,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  earningsGradient: {
    padding: 32,
    alignItems: 'center',
  },
  earningsIconWrapper: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 18,
    borderWidth: 2.5,
    borderColor: 'rgba(135,206,235,0.5)',
    overflow: 'hidden',
  },
  earningsLabel: {
    color: '#87CEEB',
    fontSize: 15,
    fontWeight: '600',
    marginBottom: 8,
    letterSpacing: 0.5,
  },
  earningsValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 40 : 48,
    fontWeight: '800',
    marginBottom: 6,
  },
  earningsSubtext: {
    color: '#87CEEB',
    fontSize: 14,
    opacity: 0.9,
    fontWeight: '500',
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 24,
  },
  statCard: {
    flex: 1,
    minWidth: (width - (isSmallScreen ? 36 : 40) - 12) / 2,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 20,
    padding: 18,
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
  },
  statNumber: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: '800',
    marginBottom: 4,
  },
  statLabel: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
});
