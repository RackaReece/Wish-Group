import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  ScrollView,
  StatusBar,
  Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { VideoView, useVideoPlayer } from 'expo-video';
import { BlurView } from 'expo-blur';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const valeterTheme = getAccountTheme('valeter');
const VALETER_PRIMARY = valeterTheme.primary;
const VALETER_PRIMARY_ALT = valeterTheme.primaryAlt;

// Upgraded modern colors - removed dark blue
const MODERN_BG = '#0F172A'; // Slightly lighter than #0A1929
const MODERN_CARD_BG = 'rgba(255,255,255,0.08)';
const MODERN_TEXT_PRIMARY = '#F8FAFC';
const MODERN_TEXT_SECONDARY = 'rgba(248,250,252,0.8)';

export default function ValeterOnboarding() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const [currentStep, setCurrentStep] = useState(0);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const scaleAnim = useRef(new Animated.Value(0.9)).current;

  const steps = [
    {
      title: "Welcome to the Wish a Wash Team!",
      subtitle: "Your professional valeting journey begins here",
      description: "You're now part of an elite network of professional valeters. Get ready to build your business and deliver exceptional service to customers.",
      icon: 'sparkles',
      color: VALETER_PRIMARY,
      showLogo: true,
    },
    {
      title: "Flexible Work, Maximum Earnings",
      subtitle: "Work when you want, earn what you deserve",
      description: "Set your own schedule and keep up to 85% of your earnings. Build your business on your terms.",
      icon: 'cash',
      color: VALETER_PRIMARY_ALT,
      showLogo: false,
    },
    {
      title: "Professional Tools & Support",
      subtitle: "Everything you need to succeed",
      description: "Access to professional equipment, training resources, and dedicated support. We're here to help you grow your valeting business.",
      icon: 'construct',
      color: VALETER_PRIMARY,
      showLogo: false,
    },
    {
      title: "Build Your Reputation",
      subtitle: "Earn reviews and grow your customer base",
      description: "Every satisfied customer helps build your reputation. Great reviews lead to more bookings and higher earnings potential.",
      icon: 'star',
      color: VALETER_PRIMARY_ALT,
      showLogo: false,
    },
    {
      title: "Rewards & Recognition",
      subtitle: "Earn points and unlock exclusive benefits",
      description: "Complete washes, earn positive reviews, and unlock rewards like equipment upgrades, training courses, and priority support.",
      icon: 'trophy',
      color: VALETER_PRIMARY,
      showLogo: false,
    },
    {
      title: "You're Ready to Start!",
      subtitle: "Your professional journey awaits",
      description: "Your account is set up and ready! Go online to start accepting bookings and begin your journey as a Wish a Wash professional.",
      icon: 'rocket',
      color: VALETER_PRIMARY_ALT,
      showLogo: false,
    },
    {
      title: "Track Your Progress",
      subtitle: "Monitor your performance and earnings",
      description: "View detailed analytics, track your earnings, see customer ratings, and monitor your progress towards rewards and recognition.",
      icon: 'stats-chart',
      color: VALETER_PRIMARY,
      showLogo: false,
    },
    {
      title: "Let's Get Started!",
      subtitle: "Your success story begins now",
      description: "Everything is set up perfectly. Go online, accept your first booking, and start building your reputation as a professional valeter.",
      icon: 'checkmark-circle',
      color: VALETER_PRIMARY_ALT,
      showLogo: false,
    }
  ];

  useEffect(() => {
    animateStep();
  }, [currentStep]);

  const animateStep = () => {
    fadeAnim.setValue(0);
    slideAnim.setValue(50);
    scaleAnim.setValue(0.9);

    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(scaleAnim, {
        toValue: 1,
        tension: 50,
        friction: 7,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const completeOnboarding = async () => {
    try {
      await AsyncStorage.setItem('valeter_onboarding_seen', 'true');
      router.replace('/valeter/valeter-dashboard');
    } catch (error) {
      console.error('Error marking onboarding as seen:', error);
      router.replace('/valeter/valeter-dashboard');
    }
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      completeOnboarding();
    }
  };

  const skipOnboarding = async () => {
    await hapticFeedback('light');
    completeOnboarding();
  };

  const currentStepData = steps[currentStep];

  // Video player for background video
  const player = useVideoPlayer(require('../../assets/water-rain.mp4'), (player) => {
    player.loop = true;
    player.muted = true;
    player.play();
  });

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={MODERN_BG} />
      
      {/* Video Background */}
      <VideoView
        player={player}
        style={styles.videoBackground}
        contentFit="cover"
        nativeControls={false}
      />
      
      {/* Dark overlay - minimal for brightness */}
      <View style={styles.overlay} />
      
      {/* Gradient overlay - very minimal for sharp, bright video */}
      <LinearGradient 
        colors={['rgba(10,25,41,0.05)', 'rgba(37,99,235,0.08)']}
        style={styles.gradientOverlay} 
      />

      {/* Floating Header */}
      <AppHeader
        title="Welcome to Wish a Wash"
        showBack={false}
        accountType="valeter"
        rightAction={
          <View style={styles.headerRightContent}>
            <View style={styles.progressContainer}>
              {steps.map((_, index) => (
                <View
                  key={index}
                  style={[
                    styles.progressDot,
                    index === currentStep && styles.progressDotActive,
                    index < currentStep && styles.progressDotCompleted
                  ]}
                />
              ))}
            </View>
            <TouchableOpacity onPress={skipOnboarding} style={styles.skipButton}>
              <Text style={styles.skipText}>Skip</Text>
            </TouchableOpacity>
          </View>
        }
      />

      {/* Content */}
      <ScrollView 
        style={styles.content} 
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[styles.contentContainer, { paddingTop: HEADER_CONTENT_OFFSET }]}
      >
        <Animated.View
          style={[
            styles.stepContainer,
            {
              opacity: fadeAnim,
              transform: [
                { translateY: slideAnim },
                { scale: scaleAnim }
              ],
            },
          ]}
        >
          {/* Enhanced Icon */}
          <View style={styles.iconContainer}>
            {currentStepData.showLogo ? (
              <BlurView intensity={30} tint="dark" style={styles.logoBlurContainer}>
                <Image
                  source={require('../../assets/auth-page.png')}
                  style={styles.logoImage}
                  resizeMode="cover"
                />
              </BlurView>
            ) : (
              <BlurView intensity={20} tint="dark" style={styles.iconBlurContainer}>
                <View style={[styles.iconWrapper, {
                  backgroundColor: currentStepData.color + '25',
                  borderColor: currentStepData.color + '60',
                }]}>
                  <Ionicons name={currentStepData.icon as any} size={72} color={currentStepData.color} />
                </View>
              </BlurView>
            )}
          </View>

          {/* Simplified Content */}
          <Text style={styles.stepTitle}>{currentStepData.title}</Text>
          <Text style={styles.stepDescription}>{currentStepData.description}</Text>

        </Animated.View>
      </ScrollView>

      {/* Footer */}
      <View style={[styles.footer, { paddingBottom: insets.bottom + 16 }]}>
        <TouchableOpacity
          style={styles.nextButton}
          onPress={nextStep}
          activeOpacity={0.8}
        >
          <LinearGradient
            colors={[VALETER_PRIMARY, VALETER_PRIMARY_ALT]}
            style={styles.nextButtonGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
          >
            <Text style={styles.nextButtonText}>
              {currentStep === steps.length - 1 ? 'Start Working' : 'Next'}
            </Text>
            <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: MODERN_BG,
  },
  videoBackground: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    width: width,
    height: height,
    zIndex: 0,
    pointerEvents: 'none',
  },
  overlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0,0,0,0.05)',
    zIndex: 1,
    pointerEvents: 'none',
  },
  gradientOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 2,
    pointerEvents: 'none',
  },
  skipButton: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    backgroundColor: `${VALETER_PRIMARY}15`,
    borderWidth: 1,
    borderColor: `${VALETER_PRIMARY}30`,
    borderRadius: 10,
  },
  skipText: {
    fontFamily: 'Rubik_600SemiBold',
    color: VALETER_PRIMARY,
    fontSize: 14,
    letterSpacing: 0.2,
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  progressDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: `${VALETER_PRIMARY}25`,
  },
  progressDotActive: {
    backgroundColor: VALETER_PRIMARY,
    width: 24,
    height: 8,
    borderRadius: 4,
  },
  progressDotCompleted: {
    backgroundColor: VALETER_PRIMARY_ALT,
  },
  content: {
    flex: 1,
  },
  contentContainer: {
    paddingHorizontal: 24,
    paddingBottom: 20,
  },
  headerRightContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  stepContainer: {
    alignItems: 'center',
  },
  iconContainer: {
    marginBottom: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logoBlurContainer: {
    width: 180,
    height: 180,
    borderRadius: 90,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 12,
  },
  logoImage: {
    width: '100%',
    height: '100%',
    borderRadius: 90,
  },
  iconBlurContainer: {
    width: 180,
    height: 180,
    borderRadius: 90,
    overflow: 'hidden',
    justifyContent: 'center',
    alignItems: 'center',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    elevation: 12,
  },
  iconWrapper: {
    width: '100%',
    height: '100%',
    borderRadius: 90,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
  },
  stepTitle: {
    fontFamily: 'Rubik_600SemiBold',
    color: MODERN_TEXT_PRIMARY,
    fontSize: isSmallScreen ? 26 : 30,
    textAlign: 'center',
    marginBottom: 16,
    lineHeight: 36,
    letterSpacing: -0.3,
  },
  stepDescription: {
    fontFamily: 'Rubik_400Regular',
    color: MODERN_TEXT_SECONDARY,
    fontSize: isSmallScreen ? 16 : 17,
    textAlign: 'center',
    lineHeight: 26,
    paddingHorizontal: 20,
    letterSpacing: 0,
  },
  footer: {
    paddingTop: 20,
  },
  nextButton: {
    borderRadius: 14,
    overflow: 'hidden',
    marginHorizontal: 24,
    shadowColor: VALETER_PRIMARY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 10,
  },
  nextButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 32,
  },
  nextButtonText: {
    fontFamily: 'Rubik_600SemiBold',
    color: '#FFFFFF',
    fontSize: 16,
    letterSpacing: 0.2,
  },
});
