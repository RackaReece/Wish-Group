import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
  Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { getServiceDisplayName } from '../../src/utils/serviceNameMapper';
import AppHeader, { HEADER_CONTENT_OFFSET, HEADER_HEIGHT } from '../../src/components/shared/AppHeader';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { colors } from '../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function ValeterHistory() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [bookings, setBookings] = useState<any[]>([]);

  const loadBookings = async () => {
    if (!user?.id) return;
    try {
      const { data: allBookings, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id);
      
      if (error) throw error;
      
      const bookingsList = allBookings || [];
      const completed = bookingsList.filter((b: any) => 
        ['completed', 'rated', 'closed'].includes(b.status)
      );
      
      const sorted = completed.sort((a: any, b: any) => {
        const dateA = a.updated_at || a.created_at || a.completed_at;
        const dateB = b.updated_at || b.created_at || b.completed_at;
        const timeA = dateA ? new Date(dateA).getTime() : 0;
        const timeB = dateB ? new Date(dateB).getTime() : 0;
        return timeB - timeA;
      });
      
      setBookings(sorted);
    } catch (error: any) {
      console.error('[ValeterHistory] Error loading bookings:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadBookings();
  }, [user?.id]);

  const onRefresh = () => {
    setRefreshing(true);
    loadBookings();
  };

  const handleDeleteBooking = (bookingId: string, serviceName: string) => {
    Alert.alert(
      'Delete Job History',
      `Are you sure you want to delete this ${serviceName} job from your history? This action cannot be undone.`,
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('bookings')
                .delete()
                .eq('id', bookingId)
                .eq('valeter_id', user?.id);

              if (error) throw error;
              await loadBookings();
            } catch (error: any) {
              console.error('[ValeterHistory] Error deleting booking:', error);
              Alert.alert('Error', 'Failed to delete job. Please try again.');
            }
          },
        },
      ]
    );
  };

  const handleDeleteAllBookings = async () => {
    if (bookings.length === 0) return;

    Alert.alert(
      'Delete All Job History',
      `Are you sure you want to delete all ${bookings.length} job${bookings.length !== 1 ? 's' : ''} from your history? This action cannot be undone.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete All',
          style: 'destructive',
          onPress: async () => {
            try {
              const bookingIds = bookings.map((b) => b.id);
              const { error } = await supabase
                .from('bookings')
                .delete()
                .in('id', bookingIds)
                .eq('valeter_id', user?.id);

              if (error) throw error;
              await loadBookings();
            } catch (error: any) {
              console.error('[ValeterHistory] Error deleting all bookings:', error);
              Alert.alert('Error', error?.message || 'Failed to delete all jobs. Please try again.');
            }
          },
        },
      ]
    );
  };

  const formatDate = (dateStr: string | undefined) => {
    if (!dateStr) return 'Date unavailable';
    try {
      const date = new Date(dateStr);
      if (isNaN(date.getTime())) return 'Date unavailable';
      return date.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      });
    } catch {
      return 'Date unavailable';
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={[BG, colors.headerBg]} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading history...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={['#0A1929', '#2563EB']} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader
        title="History"
        subtitle={`${bookings.length} completed jobs`}
        rightAction={
          <TouchableOpacity onPress={loadBookings} style={styles.refreshButton}>
            <Ionicons name="refresh" size={20} color={SKY} />
          </TouchableOpacity>
        }
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent, 
          { 
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
          }
        ]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {bookings.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="time-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
            <Text style={styles.emptyTitle}>No History Yet</Text>
            <Text style={styles.emptySubtitle}>Your completed jobs will appear here</Text>
          </View>
        ) : (
          <>
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>Job History</Text>
              {bookings.length > 0 && (
                <TouchableOpacity
                  onPress={handleDeleteAllBookings}
                  style={styles.deleteAllButton}
                  activeOpacity={0.7}
                >
                  <Ionicons name="trash-outline" size={16} color="rgba(239,68,68,0.8)" />
                  <Text style={styles.deleteAllText}>Delete All</Text>
                </TouchableOpacity>
              )}
            </View>
            {bookings.map((booking) => (
              <View key={booking.id} style={styles.bookingCard}>
                <LinearGradient
                  colors={['rgba(255,255,255,0.08)', 'rgba(135,206,235,0.05)']}
                  style={styles.bookingCardGradient}
                >
                  <View style={styles.bookingHeader}>
                    <View style={styles.bookingIconWrapper}>
                      <Ionicons name="car-sport" size={22} color="#87CEEB" />
                    </View>
                    <View style={styles.bookingInfo}>
                      <Text style={styles.bookingService}>
                        {getServiceDisplayName(booking.service_type, booking.serviceName)}
                      </Text>
                      <Text style={styles.bookingDate}>{formatDate(booking.updated_at || booking.created_at || booking.completed_at)}</Text>
                    </View>
                    <View style={styles.bookingHeaderRight}>
                      <Text style={styles.bookingPrice}>£{booking.price?.toFixed(2) || '0.00'}</Text>
                      <TouchableOpacity
                        onPress={() => handleDeleteBooking(booking.id, getServiceDisplayName(booking.service_type, booking.serviceName))}
                        style={styles.deleteButton}
                        activeOpacity={0.7}
                      >
                        <Ionicons name="trash-outline" size={18} color="#EF4444" />
                      </TouchableOpacity>
                    </View>
                  </View>
                  
                  <View style={styles.bookingFooter}>
                    {booking.location?.address && (
                      <View style={styles.bookingMeta}>
                        <Ionicons name="location" size={14} color="#87CEEB" />
                        <Text style={styles.metaText} numberOfLines={1}>
                          {booking.location.address}
                        </Text>
                      </View>
                    )}
                    {booking.vehicleType && (
                      <View style={styles.bookingMeta}>
                        <Ionicons name="car" size={14} color="#87CEEB" />
                        <Text style={styles.metaText}>{booking.vehicleType}</Text>
                      </View>
                    )}
                  </View>
                </LinearGradient>
              </View>
            ))}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  scrollView: { flex: 1 },
  scrollContent: { padding: 20 },
  refreshButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
    marginTop: 8,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '600',
    flex: 1,
  },
  deleteAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 10,
    backgroundColor: 'rgba(239,68,68,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.25)',
  },
  deleteAllText: {
    color: 'rgba(239,68,68,0.85)',
    fontSize: 13,
    fontWeight: '600',
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
  },
  bookingCard: {
    borderRadius: 20,
    marginBottom: 16,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 6,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  bookingCardGradient: {
    padding: 20,
  },
  bookingHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  bookingHeaderRight: {
    alignItems: 'flex-end',
    gap: 8,
  },
  bookingIconWrapper: {
    width: 52,
    height: 52,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  bookingInfo: {
    flex: 1,
  },
  bookingService: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '700',
    marginBottom: 6,
  },
  bookingDate: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '600',
  },
  bookingPrice: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '800',
  },
  bookingFooter: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginTop: 8,
  },
  bookingMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    flex: 1,
    minWidth: '45%',
  },
  metaText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
    flex: 1,
  },
  deleteButton: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(239,68,68,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
});
