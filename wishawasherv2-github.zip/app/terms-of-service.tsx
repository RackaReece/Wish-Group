import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions,
  TouchableOpacity,
  Linking,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import AppHeader, { HEADER_HEIGHT } from '../src/components/shared/AppHeader';
import GlassCard from '../src/components/booking/GlassCard';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { getAccountTheme } from '../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

const CONTACT_EMAIL = 'support@wishawash.com';
const ONBOARDING_EMAIL = 'onboarding@wishawash.com';

export default function TermsOfService() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  
  // Determine account type from user or route
  const accountType = user?.userType === 'valeter' ? 'valeter' 
    : user?.userType === 'organization' ? 'business' 
    : 'customer';
  const theme = getAccountTheme(accountType);
  
  const handleEmailPress = (email: string) => {
    Linking.openURL(`mailto:${email}`);
  };
  
  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />

      <AppHeader 
        title="Terms of Service" 
        accountType={accountType}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: insets.top + HEADER_HEIGHT + 4 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <GlassCard style={styles.headerCard} accountType={accountType}>
          <View style={styles.headerIcon}>
            <Ionicons name="document-text" size={32} color={theme.primary} />
          </View>
          <Text style={styles.lastUpdated}>Last updated: {new Date().toLocaleDateString('en-GB', { 
            day: 'numeric', 
            month: 'long', 
            year: 'numeric' 
          })}</Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="checkmark-circle" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>1. Acceptance of Terms</Text>
          </View>
          <Text style={styles.sectionText}>
            By accessing or using Wish a Wash ("the Platform", "we", "us", or "our"), you agree to be bound by these Terms of Service. If you do not agree with any part of these terms, please do not use our service.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="globe" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>2. Platform Nature</Text>
          </View>
          <Text style={styles.sectionText}>
            Wish a Wash is a technology platform and internet marketplace that connects customers with independent service providers (valeters and car wash businesses). We provide a digital platform that facilitates bookings, payments, and communication between users and service providers.
          </Text>
          <Text style={[styles.sectionText, { marginTop: 12 }]}>
            We do not provide car wash or valeting services directly. All services are provided by independent third-party service providers who are not employees, agents, or representatives of Wish a Wash.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="shield" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>3. Limitation of Liability & Damage Disclaimer</Text>
          </View>
          <Text style={styles.sectionText}>
            <Text style={styles.boldText}>IMPORTANT:</Text> Wish a Wash acts solely as an intermediary technology platform. We do not take responsibility for any damage, loss, or injury that valeters or car wash businesses may cause to your vehicle, property, or person.
          </Text>
          <Text style={[styles.sectionText, { marginTop: 12 }]}>
            Any claims for damage, loss, or injury must be directed to the service provider who performed the service. Service providers are independent contractors and are solely responsible for their work, conduct, and any damage they may cause.
          </Text>
          <Text style={[styles.sectionText, { marginTop: 12 }]}>
            To the maximum extent permitted by law, Wish a Wash, its directors, employees, and affiliates shall not be liable for any indirect, incidental, special, consequential, or punitive damages arising from your use of the Platform or services provided by third parties.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="card" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>4. Payment Processing & Security</Text>
          </View>
          <Text style={styles.sectionText}>
            All payments are processed securely through Stripe, a globally recognised payment processor that complies with PCI DSS (Payment Card Industry Data Security Standard) Level 1, the highest level of certification in the payments industry.
          </Text>
          <Text style={[styles.sectionText, { marginTop: 12 }]}>
            Stripe uses industry-standard encryption and security measures to protect your payment information. We do not store your full card details on our servers. All payment data is encrypted in transit using TLS (Transport Layer Security) and at rest.
          </Text>
          <Text style={[styles.sectionText, { marginTop: 12 }]}>
            By using our Platform, you authorise Stripe to process payments on our behalf. Stripe's terms of service and privacy policy apply to payment processing. You can review Stripe's security practices at stripe.com/security.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="ban" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>5. Prohibited Conduct - Customer Poaching</Text>
          </View>
          <Text style={styles.sectionText}>
            <Text style={styles.boldText}>STRICT PROHIBITION:</Text> Service providers (valeters and car wash businesses) are strictly prohibited from directly contacting, soliciting, or accepting bookings from customers they have met through the Wish a Wash platform outside of the Platform.
          </Text>
          <Text style={[styles.sectionText, { marginTop: 12 }]}>
            If a service provider is found to have stolen, poached, or diverted even one customer from our Platform to conduct business directly (bypassing the Platform), the following penalties apply:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• Immediate and permanent lifetime ban from the Wish a Wash platform</Text>
            <Text style={styles.bulletPoint}>• Payment of all earnings received through the Platform, OR</Text>
            <Text style={styles.bulletPoint}>• Payment of a flat rate fee of £20,000 (whichever is greater)</Text>
            <Text style={styles.bulletPoint}>• Legal action may be pursued for breach of contract and damages</Text>
          </View>
          <Text style={[styles.sectionText, { marginTop: 12 }]}>
            This prohibition applies to all forms of direct contact including but not limited to: phone calls, text messages, email, social media, or in-person arrangements made outside the Platform.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="people" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>6. User Responsibilities</Text>
          </View>
          <Text style={styles.sectionText}>
            You are responsible for:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• Providing accurate information (vehicle details, contact information)</Text>
            <Text style={styles.bulletPoint}>• Maintaining account security and password confidentiality</Text>
            <Text style={styles.bulletPoint}>• Treating service providers and other users with respect</Text>
            <Text style={styles.bulletPoint}>• Being at least 18 years old to use our service</Text>
            <Text style={styles.bulletPoint}>• Ensuring your vehicle is accessible for service at the scheduled time</Text>
            <Text style={styles.bulletPoint}>• Complying with all applicable laws and regulations</Text>
          </View>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="close-circle" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>7. Cancellation Policy</Text>
          </View>
          <Text style={styles.sectionText}>
            Cancellation terms:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• Free cancellation up to 2 hours before scheduled time</Text>
            <Text style={styles.bulletPoint}>• Cancellations within 2 hours may incur charges</Text>
            <Text style={styles.bulletPoint}>• Service provider cancellations entitle you to a full refund</Text>
            <Text style={styles.bulletPoint}>• No-show charges may apply if service provider arrives and service cannot be performed</Text>
          </View>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="mail" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>8. Contact & Support</Text>
          </View>
          <Text style={styles.sectionText}>
            For general support, help, or inquiries:
          </Text>
          <TouchableOpacity 
            onPress={() => handleEmailPress(CONTACT_EMAIL)}
            style={styles.emailButton}
          >
            <Ionicons name="mail-outline" size={16} color={theme.primary} />
            <Text style={[styles.emailText, { color: theme.primary }]}>{CONTACT_EMAIL}</Text>
          </TouchableOpacity>
          <Text style={[styles.sectionText, { marginTop: 16 }]}>
            For business onboarding, partnership inquiries, or service provider applications:
          </Text>
          <TouchableOpacity 
            onPress={() => handleEmailPress(ONBOARDING_EMAIL)}
            style={styles.emailButton}
          >
            <Ionicons name="business-outline" size={16} color={theme.primary} />
            <Text style={[styles.emailText, { color: theme.primary }]}>{ONBOARDING_EMAIL}</Text>
          </TouchableOpacity>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="document" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>9. Modifications to Terms</Text>
          </View>
          <Text style={styles.sectionText}>
            We reserve the right to modify these Terms of Service at any time. We will notify users of significant changes via email or through the Platform. Continued use of the Platform after changes constitutes acceptance of the modified terms.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="scale" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>10. Governing Law</Text>
          </View>
          <Text style={styles.sectionText}>
            These Terms of Service are governed by and construed in accordance with the laws of England and Wales. Any disputes arising from these terms or your use of the Platform shall be subject to the exclusive jurisdiction of the courts of England and Wales.
          </Text>
        </GlassCard>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 16 : 20, gap: 16 },
  headerCard: {
    padding: 20,
    alignItems: 'center',
    marginBottom: 8,
  },
  headerIcon: {
    marginBottom: 12,
  },
  lastUpdated: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '500',
    textAlign: 'center',
  },
  sectionCard: {
    padding: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '600',
  },
  sectionText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    lineHeight: 22,
    fontWeight: '400',
  },
  boldText: {
    fontWeight: '700',
  },
  bulletList: {
    marginTop: 12,
    gap: 8,
  },
  bulletPoint: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    lineHeight: 20,
    marginLeft: 4,
  },
  emailButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
    padding: 12,
    borderRadius: 8,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  emailText: {
    fontSize: 14,
    fontWeight: '600',
  },
});
