import React, { useMemo, useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Image,
  Platform,
  Modal,
  Pressable,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname, useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Animated, { 
  useAnimatedStyle, 
  useSharedValue, 
  withSpring,
} from 'react-native-reanimated';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { supabase } from '../../src/lib/supabase';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import GlassCard from '../../src/components/booking/GlassCard';
const { width } = Dimensions.get('window');

const TAB_BAR_HEIGHT = 72;
const BAR_MARGIN_H = 20;
const BAR_RADIUS = 36;

// Used by screens to pad content above the bar (DO NOT include safe area here)
const TAB_BAR_TOTAL_HEIGHT = TAB_BAR_HEIGHT - 18;
export { TAB_BAR_TOTAL_HEIGHT };

interface Tab {
  name: string;
  icon: keyof typeof Ionicons.glyphMap;
  route: string;
}

const getTabs = (userType?: string): Tab[] => {
  if (userType === 'valeter') {
    return [
      { name: 'Home', icon: 'home', route: '/valeter/valeter-dashboard' },
      { name: 'Jobs', icon: 'car', route: '/valeter/jobs' },
      { name: 'Trips', icon: 'navigate', route: '/valeter/trips' },
      { name: 'Radius', icon: 'location', route: '/valeter/settings/distance-covering' },
      { name: 'Profile', icon: 'person', route: '/valeter/profile/valeter-profile' },
    ];
  }

  if (userType === 'organization') {
    return [
      { name: 'Home', icon: 'home', route: '/business/dashboard' },
      { name: 'Locations', icon: 'location', route: '/business/locations' },
      { name: 'Bookings', icon: 'calendar', route: '/business/bookings' },
      { name: 'Team', icon: 'people', route: '/business/team' },
      { name: 'Profile', icon: 'person', route: '/business/profile' },
    ];
  }

  return [
    { name: 'Home', icon: 'home', route: '/owner/owner-dashboard' },
    { name: 'Book', icon: 'calendar', route: '/owner/booking' },
    { name: 'History', icon: 'time', route: '/owner/wash-history' },
    { name: 'Rewards', icon: 'gift', route: '/owner/features/rewards' },
    { name: 'Profile', icon: 'person', route: '/owner/owner-profile' },
  ];
};

const getActiveIndex = (pathname: string, tabs: Tab[]): number => {
  if (pathname.includes('/booking')) {
    const bookIndex = tabs.findIndex((t) => t.route.includes('/booking'));
    return bookIndex >= 0 ? bookIndex : 0;
  }

  if (pathname.includes('/rewards')) {
    const rewardsIndex = tabs.findIndex((t) => t.route === '/rewards' || t.route.includes('rewards'));
    return rewardsIndex >= 0 ? rewardsIndex : 0;
  }

  if (pathname.includes('/valeter/jobs')) {
    const jobsIndex = tabs.findIndex((t) => t.route === '/valeter/jobs');
    return jobsIndex >= 0 ? jobsIndex : 0;
  }

  if (pathname.includes('/valeter/trips')) {
    const tripsIndex = tabs.findIndex((t) => t.route === '/valeter/trips');
    return tripsIndex >= 0 ? tripsIndex : 0;
  }

  if (pathname.includes('/valeter/settings/distance-covering')) {
    const radiusIndex = tabs.findIndex((t) => t.route === '/valeter/settings/distance-covering');
    return radiusIndex >= 0 ? radiusIndex : 0;
  }

  if (pathname.includes('/valeter/profile/valeter-profile') || pathname.includes('/valeter/valeter-profile')) {
    const profileIndex = tabs.findIndex((t) => t.route === '/valeter/profile/valeter-profile');
    return profileIndex >= 0 ? profileIndex : 0;
  }

  if (pathname.includes('/business/dashboard')) {
    const homeIndex = tabs.findIndex((t) => t.route === '/business/dashboard');
    return homeIndex >= 0 ? homeIndex : 0;
  }
  if (pathname.includes('/business/locations')) {
    const locationsIndex = tabs.findIndex((t) => t.route === '/business/locations');
    return locationsIndex >= 0 ? locationsIndex : 0;
  }
  if (pathname.includes('/business/bookings')) {
    const bookingsIndex = tabs.findIndex((t) => t.route === '/business/bookings');
    return bookingsIndex >= 0 ? bookingsIndex : 0;
  }
  if (pathname.includes('/business/team')) {
    const teamIndex = tabs.findIndex((t) => t.route === '/business/team');
    return teamIndex >= 0 ? teamIndex : 0;
  }
  if (pathname.includes('/business/profile')) {
    const profileIndex = tabs.findIndex((t) => t.route === '/business/profile');
    return profileIndex >= 0 ? profileIndex : 0;
  }

  for (let i = 0; i < tabs.length; i++) {
    if (pathname === tabs[i].route || pathname.startsWith(tabs[i].route + '/')) return i;
  }

  return 0;
};

export default function NavigationTab() {
  const pathname = usePathname();
  const router = useRouter();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [showProfileActions, setShowProfileActions] = useState(false);

  const isBusinessRoute =
    pathname.includes('/business/') ||
    pathname.includes('/Business/') ||
    pathname.includes('/organisation/') ||
    pathname.includes('/Organization/');
  const businessTheme = isBusinessRoute ? getAccountTheme('business') : null;

  const isCustomerRoute = pathname.includes('/owner/') || pathname.includes('/customer');
  const customerTheme = isCustomerRoute ? getAccountTheme('customer') : null;

  const accountTypeForBubbles: 'customer' | 'valeter' | 'business' = useMemo(() => {
    if (pathname.includes('/valeter/')) return 'valeter';
    if (isBusinessRoute) return 'business';
    return 'customer';
  }, [pathname, isBusinessRoute]);

  // Get the theme for the current account type (matches header logic)
  const currentTheme = useMemo(() => {
    if (pathname.includes('/valeter/')) return getAccountTheme('valeter');
    if (isBusinessRoute) return getAccountTheme('business');
    return getAccountTheme('customer');
  }, [pathname, isBusinessRoute]);

  const tabs = useMemo(() => {
    const userType = user?.userType;

    if (pathname.includes('/owner/') || pathname.includes('/customer')) return getTabs('customer');
    if (pathname.includes('/valeter/')) return getTabs('valeter');
    if (isBusinessRoute) return getTabs('organization');

    const safeUserType =
      userType === 'valeter' || userType === 'organization' || userType === 'business' ? userType : 'customer';

    if (userType === 'valeter' && !pathname.includes('/valeter/') && !pathname.includes('/driver/')) {
      return getTabs('customer');
    }

    return getTabs(safeUserType);
  }, [user?.userType, user?.email, pathname, isBusinessRoute]);

  const activeIndex = useMemo(() => getActiveIndex(pathname, tabs), [pathname, tabs]);

  const accent =
    (isBusinessRoute && businessTheme?.primary) ||
    (isCustomerRoute && customerTheme?.primary) ||
    currentTheme?.primary ||
    colors.navActive;

  // Use header background colors for nav tab (matching header)
  const headerBackground = currentTheme?.headerBackground || currentTheme?.background || ['rgba(96,217,255,0.65)', 'rgba(59,197,232,0.55)'];

  const barWidth = width - BAR_MARGIN_H * 2;
  const pad = 12; // Reduced padding to give more width per tab
  const slotW = (barWidth - pad * 2) / tabs.length;

  // No active capsule animation needed - just icon glow

  const searchParams = useLocalSearchParams();
  const isTripsPage = pathname.includes('/business/bookings') && searchParams.filter === 'in_progress';

  const shouldHideTab = useMemo(() => {
    const hideRoutes = [
      '/auth/',
      '/onboarding',
      '/customer-onboarding',
      '/valeter/valeter-onboarding',
      '/organisation/organization-onboarding',
    ];
    return hideRoutes.some((route) => pathname.includes(route)) || isTripsPage;
  }, [pathname, isTripsPage]);

  const isProfileTab = (tab: Tab) => tab.name === 'Profile';

  const inactiveIcon = 'rgba(255,255,255,0.65)';
  const inactiveLabel = 'rgba(255,255,255,0.62)';

  useEffect(() => {
    const loadProfilePicture = async () => {
      if (!user?.id) return;

      try {
        if (user.profilePicture) {
          setProfilePicture(user.profilePicture);
          return;
        }

        if (user.userType === 'organization' || user.userType === 'business') {
          const { data: profileData, error: profileError } = await supabase
            .from('profiles')
            .select('avatar_url, profile_picture')
            .eq('id', user.id)
            .maybeSingle();

          if (!profileError && profileData) {
            const picUrl = (profileData as any).avatar_url || (profileData as any).profile_picture;
            if (picUrl) {
              setProfilePicture(picUrl);
              return;
            }
          }

          const { data: orgData, error: orgError } = await supabase
            .from('organizations')
            .select('*')
            .eq('id', user.id)
            .maybeSingle();

          if (!orgError && orgData && (orgData as any).logo) {
            setProfilePicture((orgData as any).logo);
            return;
          }
        } else {
          const tableName = user.userType === 'valeter' ? 'valeter_profiles' : 'customer_profiles';
          const { data, error } = await supabase
            .from(tableName)
            .select('avatar_url, profile_picture')
            .eq('user_id', user.id)
            .maybeSingle();

          if (!error && data) {
            const picUrl = (data as any).avatar_url || (data as any).profile_picture;
            if (picUrl) setProfilePicture(picUrl);
          }
        }
      } catch (error) {
        console.error('[NavigationTab] Error loading profile picture:', error);
      }
    };

    loadProfilePicture();
  }, [user?.id, user?.profilePicture, user?.userType]);

  const bottomPad = Math.max(insets.bottom, 10);

  if (shouldHideTab) return null;

  return (
    <View pointerEvents="box-none" style={styles.screenWrap}>
      {/* ✅ Full screen background underlay */}
      <View
        pointerEvents="none"
        style={[
          styles.underlay,
          {
            top: 0,
            bottom: 0,
          },
        ]}
      />

      {/* The actual pill bar */}
      <View style={[styles.bar, { width: barWidth, borderRadius: BAR_RADIUS, marginBottom: bottomPad }]}>
        <BlurView
          intensity={Platform.OS === 'ios' ? 25 : 20}
          tint="dark"
          style={StyleSheet.absoluteFill}
        >
          {/* Use same header background gradient */}
          <LinearGradient
            colors={[`${headerBackground[0]}FF`, `${headerBackground[1] || headerBackground[0]}EE`]}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
          {/* Primary color overlay (matching header) */}
          <View style={StyleSheet.absoluteFill} pointerEvents="none">
            <LinearGradient
              colors={[`${accent}30`, 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
          </View>
        </BlurView>

        {/* Glass stroke with theme border */}
        <View style={[styles.glassStroke, { borderColor: currentTheme?.glassBorder || 'rgba(255,255,255,0.14)' }]} />
        
        {/* Glow line at top (matching header) */}
        <View style={[styles.glowLine, { 
          backgroundColor: `${accent}70`,
          shadowColor: accent,
        }]} />

        {/* Icon-only highlight - no bubble background */}

        <View style={[styles.row, { paddingHorizontal: pad }]}>
          {tabs.map((tab, index) => {
            const isActive = index === activeIndex;
            const isProfile = isProfileTab(tab);
            const showProfilePic = isProfile && !!profilePicture;

            const handleTabPress = async () => {
              // Don't navigate if already on this page
              if (isActive && !isProfile) {
                return;
              }
              
              if (isProfile && isBusinessRoute) {
                await hapticFeedback('light');
                setShowProfileActions(true);
              } else if (!isActive) {
                await hapticFeedback('light');
                router.push(tab.route as any);
              }
            };

            return (
              <TouchableOpacity
                key={tab.route}
                style={[styles.tab, { width: slotW, opacity: isActive && !isProfile ? 0.6 : 1 }]}
                onPress={handleTabPress}
                activeOpacity={isActive && !isProfile ? 1 : 0.85}
                disabled={isActive && !isProfile}
              >
                <View style={[styles.iconContainer, isActive && styles.iconContainerActive]}>
                  {isActive && (
                    <>
                      {/* Subtle icon glow - no bubble */}
                      <View style={[
                        styles.iconGlow, 
                        { backgroundColor: `${accent}25` },
                        (pathname.includes('/valeter/') || isBusinessRoute) && [
                          styles.iconGlowValeter,
                          { shadowColor: accent }
                        ]
                      ]} />
                    </>
                  )}
                  <Ionicons
                    name={isActive ? tab.icon : (`${tab.icon}-outline` as any)}
                    size={isActive ? 24 : 18}
                    color={isActive ? accent : inactiveIcon}
                    style={[
                      styles.icon, 
                      isActive && styles.iconActive,
                      isActive && (pathname.includes('/valeter/') || isBusinessRoute) && [
                        styles.iconActiveValeter,
                        { shadowColor: accent }
                      ]
                    ]}
                  />
                </View>

                <Text
                  style={[
                    styles.label, 
                    { color: isActive ? accent : inactiveLabel }, 
                    isActive && styles.labelActive
                  ]}
                  numberOfLines={1}
                  adjustsFontSizeToFit={true}
                  minimumFontScale={0.75}
                >
                  {tab.name}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>
      </View>

      <Modal visible={showProfileActions} transparent animationType="slide" onRequestClose={() => setShowProfileActions(false)}>
        <Pressable style={styles.modalOverlay} onPress={() => setShowProfileActions(false)}>
          <Pressable
            style={styles.actionSheetContainer}
            onPress={(e) => e.stopPropagation()}
          >
            <GlassCard style={styles.actionSheet} accountType={isBusinessRoute ? 'business' : 'valeter'}>
              <View style={styles.actionSheetHeader}>
                <Text style={styles.actionSheetTitle}>
                  Profile Options
                </Text>
                <TouchableOpacity onPress={() => setShowProfileActions(false)} style={styles.actionSheetClose}>
                  <Ionicons name="close" size={20} color={accent} />
                </TouchableOpacity>
              </View>

              <View style={styles.actionSheetContent}>
                <TouchableOpacity
                  style={styles.actionSheetItem}
                  onPress={async () => {
                    await hapticFeedback('light');
                    setShowProfileActions(false);
                    router.push('/business/profile' as any);
                  }}
                  activeOpacity={0.85}
                >
                  <GlassCard style={styles.actionSheetItemCard} accountType={isBusinessRoute ? 'business' : 'valeter'}>
                    <View style={[styles.actionSheetIconWrapper, { backgroundColor: `${accent}25` }]}>
                      <Ionicons name="person" size={22} color={accent} />
                    </View>
                    <Text style={styles.actionSheetItemText}>Business Profile</Text>
                    <Ionicons name="chevron-forward" size={18} color={accent} style={{ opacity: 0.7 }} />
                  </GlassCard>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.actionSheetItem}
                  onPress={async () => {
                    await hapticFeedback('light');
                    setShowProfileActions(false);
                    router.push('/business/settings' as any);
                  }}
                  activeOpacity={0.85}
                >
                  <GlassCard style={styles.actionSheetItemCard} accountType={isBusinessRoute ? 'business' : 'valeter'}>
                    <View style={[styles.actionSheetIconWrapper, { backgroundColor: `${accent}25` }]}>
                      <Ionicons name="settings" size={22} color={accent} />
                    </View>
                    <Text style={styles.actionSheetItemText}>Settings</Text>
                    <Ionicons name="chevron-forward" size={18} color={accent} style={{ opacity: 0.7 }} />
                  </GlassCard>
                </TouchableOpacity>
              </View>
            </GlassCard>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screenWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    zIndex: 9999,
    elevation: 30,
  },

  // ✅ Full screen background underlay
  underlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    backgroundColor: 'transparent',
  },


  bar: {
    height: TAB_BAR_HEIGHT,
    marginHorizontal: BAR_MARGIN_H,
    overflow: 'hidden',
    justifyContent: 'center',
    backgroundColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 28,
  },

  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
    borderRadius: BAR_RADIUS,
  },

  glowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 8,
  },


  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  tab: {
    height: TAB_BAR_HEIGHT,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 1,
    minWidth: 60,
  },

  iconContainer: {
    position: 'relative',
    marginBottom: 4,
    alignItems: 'center',
    justifyContent: 'center',
    width: 26,
    height: 26,
    borderRadius: 13,
  },
  
  iconContainerActive: {
    // No border needed - the capsule provides the highlight
  },

  icon: {
    zIndex: 2,
  },

  iconActive: {
    transform: [{ scale: 1.05 }],
    shadowColor: '#87CEEB',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
  },
  
  iconActiveValeter: {
    // Enhanced glow for valeter and business icons
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 12,
    transform: [{ scale: 1.1 }],
  },

  iconGlow: {
    position: 'absolute',
    width: 28,
    height: 28,
    borderRadius: 14,
    zIndex: 1,
    opacity: 0.4,
  },
  
  iconGlowValeter: {
    // Subtle glow for valeter and business - just around icon
    width: 30,
    height: 30,
    borderRadius: 15,
    opacity: 0.5,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 8,
  },

  label: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.2,
    marginTop: 2,
    textAlign: 'center',
    width: '100%',
    paddingHorizontal: 1,
  },

  labelActive: {
    fontWeight: '900',
    letterSpacing: 0.4,
  },

  avatarWrap: {
    width: 28,
    height: 28,
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.25)',
    marginBottom: 4,
    backgroundColor: 'rgba(255,255,255,0.08)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 4,
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },

  avatarWrapActive: {
    borderWidth: 2.5,
    borderColor: '#87CEEB',
    shadowColor: '#87CEEB',
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 6,
  },

  avatarBorder: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    borderRadius: 14,
    borderWidth: 0,
    zIndex: 1,
    pointerEvents: 'none',
  },

  avatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
    zIndex: 0,
    resizeMode: 'cover',
  },

  avatarGlow: {
    position: 'absolute',
    top: -3,
    left: -3,
    right: -3,
    bottom: -3,
    borderRadius: 14,
    zIndex: -1,
    opacity: 0.5,
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    justifyContent: 'flex-end',
  },

  actionSheetContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  actionSheet: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingTop: 20,
    paddingBottom: 40,
    paddingHorizontal: 0,
    marginHorizontal: 0,
  },
  actionSheetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 16,
    marginBottom: 8,
  },
  actionSheetTitle: {
    fontSize: 20,
    fontWeight: '900',
    color: '#F9FAFB',
    letterSpacing: 0.3,
  },
  actionSheetClose: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  actionSheetContent: {
    paddingHorizontal: 20,
    gap: 12,
  },
  actionSheetItem: {
    marginBottom: 0,
  },
  actionSheetItemCard: {
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  actionSheetIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionSheetItemText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '800',
    color: '#F9FAFB',
    letterSpacing: 0.2,
  },
});
