import React from 'react';
import { View, StyleSheet } from 'react-native';
import { usePathname } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import NavigationTab, { TAB_BAR_TOTAL_HEIGHT } from './NavigationTab';
import { useAuth } from '../../src/providers/enhanced-auth-context';

// Routes where tab bar should be hidden
const HIDDEN_ROUTES = [
  '/auth/login',
  '/auth/signup',
  '/auth/logout-test',
  '/customer-onboarding',
  '/onboarding',
  '/valeter/valeter-onboarding',
  '/organisation/organization-onboarding',
  '/business/onboarding',
];

export default function NavTabWrapper({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const shouldHideTab = (): boolean => {
    const currentPath = pathname || '';
    const isBusinessRoute =
      currentPath.includes('/business/') ||
      currentPath.includes('/organisation/') ||
      currentPath.includes('/organization/');

    if (HIDDEN_ROUTES.some((route) => currentPath === route)) return true;
    if (currentPath.includes('/auth/') || currentPath.includes('onboarding')) return true;

    if (
      currentPath.includes('/booking/location') ||
      currentPath.includes('/booking/tracking') ||
      currentPath.includes('/jobs/tracking') ||
      currentPath.includes('/jobs/accept') ||
      currentPath === '/valeter/jobs'
    ) {
      return true;
    }

    if (!user) return !isBusinessRoute;
    return false;
  };

  const shouldExcludePadding = (): boolean => {
    const currentPath = (pathname || '').toLowerCase();
    return (
      currentPath.includes('/booking/location') ||
      currentPath.includes('/booking/tracking') ||
      currentPath.includes('/jobs/tracking')
    );
  };

  const hideTab = shouldHideTab();
  const excludePadding = shouldExcludePadding();

  // padding is ONLY for content layout so it doesn’t sit under the nav buttons
  const bottomPadding = hideTab || excludePadding ? 0 : TAB_BAR_TOTAL_HEIGHT + Math.max(insets.bottom, 0);

  return (
    <View style={styles.container} pointerEvents="box-none">
      <View style={[styles.contentWrapper, { paddingBottom: 0 }]} pointerEvents="box-none">
        {children}
      </View>

      {!hideTab && <NavigationTab />}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // ✅ don’t paint a background here (let each screen own the background)
    backgroundColor: 'transparent',
  },
  contentWrapper: {
    flex: 1,
    // ✅ same here
    backgroundColor: 'transparent',
  },
});
