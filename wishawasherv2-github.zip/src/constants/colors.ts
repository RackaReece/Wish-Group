// Standardized color scheme for headers, footers, and navigation
// Glassmorphism design with lighter blues, greys, and navy for a modern, consistent look

export const colors = {
  // Headers/Footers - Glassmorphism Design
  headerBg: '#1E3A8A', // Dark blue base (blends with #0A1929)
  headerBgSecondary: 'rgba(135,206,235,0.15)', // Light blue glass tint
  headerGradient: ['rgba(135,206,235,0.2)', 'rgba(191,219,254,0.15)'], // Light blue gradients
  headerBorder: 'rgba(191,219,254,0.3)', // Light blue border glow
  headerText: '#F9FAFB', // Light grey/white for contrast
  headerSubtext: '#94A3B8', // Medium grey
  
  // Glassmorphism Specific
  headerGlassBg: 'rgba(135,206,235,0.15)', // Semi-transparent lighter blue
  headerGlassBorder: 'rgba(191,219,254,0.3)', // Subtle border with light blue glow
  headerGlassShadow: 'rgba(135,206,235,0.2)', // Blue tinted shadow
  headerGlassOverlay: 'rgba(30,58,138,0.1)', // Dark blue overlay for depth
  
  // Navigation Tab - Glassmorphism Design
  navBg: 'rgba(30,58,138,0.25)', // Semi-transparent dark blue
  navBorder: 'rgba(148,163,184,0.2)', // Grey border
  navGlassBg: 'rgba(30,58,138,0.25)', // Semi-transparent for navigation
  navGlassBorder: 'rgba(148,163,184,0.2)', // Navigation border
  navActive: '#BFDBFE', // Light blue for active state
  navInactive: '#64748B', // Grey for inactive
  
  // Accents
  accentLight: '#E0F2FE',
  accentMedium: '#BFDBFE',
  accentDark: '#1E293B',
  greyLight: '#F8FAFC',
  greyMedium: '#94A3B8',
  greyDark: '#64748B',
  
  // Background
  bgPrimary: '#0A1929', // Dark blue (existing)
  bgSecondary: '#1E293B', // Navy
  
  // Service-specific colors
  ecoGreen: '#10B981',
  premiumPurple: '#87CEEB', // Changed to sky blue to match app theme
  
  // Legacy support (keep for compatibility during migration)
  SKY: '#87CEEB',
  BG: '#0A1929',
  LIGHT_SKY: '#F9FAFB',
  ECO_GREEN: '#10B981',
  PREMIUM_PURPLE: '#87CEEB', // Changed to sky blue to match app theme
};

