export interface ServiceOption {
  id: string;
  name: string;
  desc: string;
  dur: string;
  icon: string;
  colors: [string, string];
  price: number;
  minPrice?: number;
  maxPrice?: number;
}

export const serviceOptions: ServiceOption[] = [
  {
    id: 'bronze-wash',
    name: 'Bronze Wash',
    desc: 'Exterior or Interior wash',
    dur: '15-20 min',
    icon: 'water-outline',
    colors: ['#CD7F32', '#A0522D'],
    price: 15,
  },
  {
    id: 'silver-wash',
    name: 'Silver Wash',
    desc: 'Exterior + interior clean',
    dur: '25-30 min',
    icon: 'sparkles-outline',
    colors: ['#C0C0C0', '#A8A8A8'],
    price: 25,
  },
  {
    id: 'gold-wash',
    name: 'Gold Wash',
    desc: 'Complete valet service',
    dur: '45-60 min',
    icon: 'diamond-outline',
    colors: ['#FFD700', '#FFA500'],
    price: 45,
  },
  {
    id: 'platinum-wash',
    name: 'Platinum Wash',
    desc: 'Premium luxury detail',
    dur: '2-3 hours',
    icon: 'star-outline',
    colors: ['#E5E4E2', '#BCC6CC'],
    price: 85,
  },
];

export const ecoServiceOptions: ServiceOption[] = [
  {
    id: 'eco-bronze-wash',
    name: 'Eco Bronze Wash',
    desc: 'Eco-friendly exterior or interior wash with biodegradable products',
    dur: '15-20 min',
    icon: 'leaf-outline',
    colors: ['#10B981', '#059669'],
    price: 18,
    minPrice: 15,
    maxPrice: 22,
  },
  {
    id: 'eco-silver-wash',
    name: 'Eco Silver Wash',
    desc: 'Eco-friendly exterior + interior with plant-based cleaners',
    dur: '25-30 min',
    icon: 'leaf',
    colors: ['#34D399', '#10B981'],
    price: 28,
    minPrice: 25,
    maxPrice: 32,
  },
  {
    id: 'eco-gold-wash',
    name: 'Eco Gold Wash',
    desc: 'Complete eco valet with water-saving technology',
    dur: '45-60 min',
    icon: 'reload-outline',
    colors: ['#059669', '#047857'],
    price: 48,
    minPrice: 45,
    maxPrice: 55,
  },
  {
    id: 'eco-platinum-wash',
    name: 'Eco Platinum Wash',
    desc: 'Premium eco detail with carbon-neutral processes',
    dur: '2-3 hours',
    icon: 'earth-outline',
    colors: ['#047857', '#065F46'],
    price: 90,
    minPrice: 85,
    maxPrice: 100,
  },
];

export const detailingServiceOptions: ServiceOption[] = [
  {
    id: 'interior-detail',
    name: 'Interior Detail',
    desc: 'Deep interior cleaning and protection',
    dur: '1-2 hours',
    icon: 'home-outline',
    colors: ['#87CEEB', '#5BA3C7'],
    price: 60,
  },
  {
    id: 'exterior-detail',
    name: 'Exterior Detail',
    desc: 'Paint correction and exterior protection',
    dur: '2-3 hours',
    icon: 'car-sport-outline',
    colors: ['#3B82F6', '#2563EB'],
    price: 80,
  },
  {
    id: 'full-detail',
    name: 'Full Detail',
    desc: 'Complete interior and exterior detailing',
    dur: '4-5 hours',
    icon: 'diamond',
    colors: ['#F59E0B', '#D97706'],
    price: 130,
  },
  {
    id: 'paint-correction',
    name: 'Paint Correction',
    desc: 'Professional paint restoration and polishing',
    dur: '5-6 hours',
    icon: 'color-filter-outline',
    colors: ['#EF4444', '#DC2626'],
    price: 200,
  },
  {
    id: 'ceramic-coating',
    name: 'Ceramic Coating',
    desc: 'Long-lasting ceramic paint protection',
    dur: '6-8 hours',
    icon: 'shield-checkmark-outline',
    colors: ['#6366F1', '#4F46E5'],
    price: 350,
  },
  {
    id: 'ppf',
    name: 'PPF (Paint Protection Film)',
    desc: 'Premium paint protection film installation',
    dur: '8-12 hours',
    icon: 'layers-outline',
    colors: ['#10B981', '#059669'],
    price: 500,
    minPrice: 400,
    maxPrice: 600,
  },
];


