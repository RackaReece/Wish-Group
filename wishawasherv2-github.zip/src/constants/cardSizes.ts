import { Dimensions } from 'react-native';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

export const CARD_SIZES = {
  small: {
    padding: 16,
    minHeight: 80,
    borderRadius: 16,
  },
  medium: {
    padding: 20,
    minHeight: 120,
    borderRadius: 18,
  },
  large: {
    padding: 24,
    minHeight: 160,
    borderRadius: 20,
  },
  fullWidth: {
    padding: 20,
    borderRadius: 20,
  },
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 20,
  xxl: 24,
  section: 32,
};

// Standard spacing values used throughout the app
export const STANDARD_SPACING = {
  // Page-level padding
  pagePadding: 20,
  pagePaddingBottom: 40,
  
  // Section spacing
  sectionMarginBottom: 22,
  sectionGap: 22,
  sectionGapSmall: 12,
  
  // Card spacing
  cardGap: 16,
  cardPadding: 18,
  cardPaddingMedium: 20,
  cardPaddingLarge: 24,
  cardBorderRadius: 20,
  cardBorderRadiusMedium: 22,
  cardBorderRadiusLarge: 24,
  
  // Content spacing
  contentGap: 12,
  contentGapLarge: 16,
  
  // Header spacing
  headerContentOffset: 32,
  
  // Input/Form spacing
  inputMarginBottom: 12,
  inputPadding: 16,
  inputBorderRadius: 14,
  
  // Button spacing
  buttonPaddingVertical: 16,
  buttonPaddingHorizontal: 22,
  buttonBorderRadius: 12,
};

export const getMetricCardWidth = (columns: number = 2, gap: number = SPACING.md) => {
  const padding = isSmallScreen ? 32 : 40;
  return (width - padding - gap * (columns - 1)) / columns;
};

