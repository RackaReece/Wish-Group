export interface JointWashRequest {
  id: string;
  jobId: string;
  requesterId: string; // Valeter requesting help
  requestedValeterId: string; // Valeter being asked to help
  status: 'pending' | 'accepted' | 'declined' | 'completed' | 'cancelled';
  createdAt: Date;
  respondedAt?: Date;
  completedAt?: Date;
  paymentSplit: {
    requesterPercentage: number;
    helperPercentage: number;
  };
  jobDetails: {
    customerName: string;
    vehicleType: string;
    serviceType: string;
    location: string;
    estimatedDuration: string;
    totalPrice: number;
  };
  notes?: string;
}

export interface JointWashJob {
  id: string;
  originalJobId: string;
  primaryValeterId: string;
  assistantValeterId?: string;
  customerId: string;
  status: 'active' | 'completed' | 'cancelled';
  paymentSplit: {
    primaryPercentage: number;
    assistantPercentage: number;
  };
  totalEarnings: number;
  primaryEarnings: number;
  assistantEarnings: number;
  createdAt: Date;
  completedAt?: Date;
  jobDetails: {
    vehicleType: string;
    serviceType: string;
    location: string;
    duration: string;
    customerRating?: number;
    customerTip?: number;
  };
}

export class JointWashService {
  private static instance: JointWashService;
  private jointWashRequests: Map<string, JointWashRequest> = new Map();
  private jointWashJobs: Map<string, JointWashJob> = new Map();
  private valeterCollaborations: Map<string, string[]> = new Map(); // valeterId -> array of collaborator IDs

  static getInstance(): JointWashService {
    if (!JointWashService.instance) {
      JointWashService.instance = new JointWashService();
    }
    return JointWashService.instance;
  }

  // Request help from another valeter
  requestJointWash(
    jobId: string,
    requesterId: string,
    requestedValeterId: string,
    jobDetails: JointWashRequest['jobDetails'],
    paymentSplit: { requesterPercentage: number; helperPercentage: number },
    notes?: string
  ): string {
    const requestId = `joint_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const request: JointWashRequest = {
      id: requestId,
      jobId,
      requesterId,
      requestedValeterId,
      status: 'pending',
      createdAt: new Date(),
      paymentSplit,
      jobDetails,
      notes
    };

    this.jointWashRequests.set(requestId, request);
    return requestId;
  }

  // Accept a joint wash request
  acceptJointWashRequest(requestId: string): boolean {
    const request = this.jointWashRequests.get(requestId);
    if (!request || request.status !== 'pending') {
      return false;
    }

    request.status = 'accepted';
    request.respondedAt = new Date();

    // Create joint wash job
    const jointJobId = `joint_job_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    const jointJob: JointWashJob = {
      id: jointJobId,
      originalJobId: request.jobId,
      primaryValeterId: request.requesterId,
      assistantValeterId: request.requestedValeterId,
      customerId: '', // Will be set when job is created
      status: 'active',
      paymentSplit: request.paymentSplit,
      totalEarnings: request.jobDetails.totalPrice,
      primaryEarnings: (request.jobDetails.totalPrice * request.paymentSplit.requesterPercentage) / 100,
      assistantEarnings: (request.jobDetails.totalPrice * request.paymentSplit.helperPercentage) / 100,
      createdAt: new Date(),
      jobDetails: {
        vehicleType: request.jobDetails.vehicleType,
        serviceType: request.jobDetails.serviceType,
        location: request.jobDetails.location,
        duration: request.jobDetails.estimatedDuration
      }
    };

    this.jointWashJobs.set(jointJobId, jointJob);

    // Update collaboration history
    this.addCollaboration(request.requesterId, request.requestedValeterId);

    return true;
  }

  // Decline a joint wash request
  declineJointWashRequest(requestId: string, reason?: string): boolean {
    const request = this.jointWashRequests.get(requestId);
    if (!request || request.status !== 'pending') {
      return false;
    }

    request.status = 'declined';
    request.respondedAt = new Date();
    if (reason) {
      request.notes = reason;
    }

    return true;
  }

  // Complete a joint wash job
  completeJointWashJob(jointJobId: string, customerRating?: number, customerTip?: number): boolean {
    const jointJob = this.jointWashJobs.get(jointJobId);
    if (!jointJob || jointJob.status !== 'active') {
      return false;
    }

    jointJob.status = 'completed';
    jointJob.completedAt = new Date();
    
    if (customerRating) {
      jointJob.jobDetails.customerRating = customerRating;
    }
    
    if (customerTip) {
      jointJob.jobDetails.customerTip = customerTip;
      // Split tip equally
      const tipSplit = customerTip / 2;
      jointJob.primaryEarnings += tipSplit;
      jointJob.assistantEarnings += tipSplit;
      jointJob.totalEarnings += customerTip;
    }

    return true;
  }

  // Get pending requests for a valeter
  getPendingRequests(valeterId: string): JointWashRequest[] {
    return Array.from(this.jointWashRequests.values())
      .filter(request => 
        request.requestedValeterId === valeterId && 
        request.status === 'pending'
      )
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // Get active joint wash jobs for a valeter
  getActiveJointJobs(valeterId: string): JointWashJob[] {
    return Array.from(this.jointWashJobs.values())
      .filter(job => 
        (job.primaryValeterId === valeterId || job.assistantValeterId === valeterId) &&
        job.status === 'active'
      );
  }

  // Get completed joint wash jobs for a valeter
  getCompletedJointJobs(valeterId: string): JointWashJob[] {
    return Array.from(this.jointWashJobs.values())
      .filter(job => 
        (job.primaryValeterId === valeterId || job.assistantValeterId === valeterId) &&
        job.status === 'completed'
      )
      .sort((a, b) => (b.completedAt?.getTime() || 0) - (a.completedAt?.getTime() || 0));
  }

  // Get collaboration history for a valeter
  getCollaborationHistory(valeterId: string): string[] {
    return this.valeterCollaborations.get(valeterId) || [];
  }

  // Add collaboration to history
  private addCollaboration(valeter1Id: string, valeter2Id: string): void {
    // Add valeter2 to valeter1's collaborations
    const valeter1Collaborations = this.valeterCollaborations.get(valeter1Id) || [];
    if (!valeter1Collaborations.includes(valeter2Id)) {
      valeter1Collaborations.push(valeter2Id);
      this.valeterCollaborations.set(valeter1Id, valeter1Collaborations);
    }

    // Add valeter1 to valeter2's collaborations
    const valeter2Collaborations = this.valeterCollaborations.get(valeter2Id) || [];
    if (!valeter2Collaborations.includes(valeter1Id)) {
      valeter2Collaborations.push(valeter1Id);
      this.valeterCollaborations.set(valeter2Id, valeter2Collaborations);
    }
  }

  // Get joint wash statistics for a valeter
  getJointWashStats(valeterId: string): {
    totalJointJobs: number;
    totalEarnings: number;
    averageRating: number;
    favouriteCollaborator: string;
    collaborationCount: number;
  } {
    const allJointJobs = Array.from(this.jointWashJobs.values())
      .filter(job => 
        job.primaryValeterId === valeterId || job.assistantValeterId === valeterId
      );

    const totalJointJobs = allJointJobs.length;
    const totalEarnings = allJointJobs.reduce((sum, job) => {
      if (job.primaryValeterId === valeterId) {
        return sum + job.primaryEarnings;
      } else {
        return sum + job.assistantEarnings;
      }
    }, 0);

    const ratings = allJointJobs
      .map(job => job.jobDetails.customerRating)
      .filter(rating => rating !== undefined) as number[];
    
    const averageRating = ratings.length > 0 
      ? ratings.reduce((sum, rating) => sum + rating, 0) / ratings.length 
      : 0;

    // Find favourite collaborator
    const collaboratorCounts: { [key: string]: number } = {};
    allJointJobs.forEach(job => {
      const collaboratorId = job.primaryValeterId === valeterId 
        ? job.assistantValeterId 
        : job.primaryValeterId;
      
      if (collaboratorId) {
        collaboratorCounts[collaboratorId] = (collaboratorCounts[collaboratorId] || 0) + 1;
      }
    });

    const favouriteCollaborator = Object.keys(collaboratorCounts).length > 0
      ? Object.keys(collaboratorCounts).reduce((a, b) => 
          collaboratorCounts[a] > collaboratorCounts[b] ? a : b
        )
      : '';

    const collaborationCount = Object.keys(collaboratorCounts).length;

    return {
      totalJointJobs,
      totalEarnings,
      averageRating,
      favouriteCollaborator,
      collaborationCount
    };
  }

  // Cancel a joint wash request
  cancelJointWashRequest(requestId: string): boolean {
    const request = this.jointWashRequests.get(requestId);
    if (!request || request.status !== 'pending') {
      return false;
    }

    request.status = 'cancelled';
    return true;
  }

  // Get all requests sent by a valeter
  getSentRequests(valeterId: string): JointWashRequest[] {
    return Array.from(this.jointWashRequests.values())
      .filter(request => request.requesterId === valeterId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  // Get request by ID
  getRequest(requestId: string): JointWashRequest | undefined {
    return this.jointWashRequests.get(requestId);
  }

  // Get joint job by ID
  getJointJob(jointJobId: string): JointWashJob | undefined {
    return this.jointWashJobs.get(jointJobId);
  }

  // Check if valeters have collaborated before
  haveCollaborated(valeter1Id: string, valeter2Id: string): boolean {
    const collaborations = this.valeterCollaborations.get(valeter1Id) || [];
    return collaborations.includes(valeter2Id);
  }

  // Get suggested collaborators for a valeter
  getSuggestedCollaborators(valeterId: string): string[] {
    const collaborations = this.valeterCollaborations.get(valeterId) || [];
    // Return recent collaborators (last 5)
    return collaborations.slice(-5);
  }
}

export const jointWashService = JointWashService.getInstance();
