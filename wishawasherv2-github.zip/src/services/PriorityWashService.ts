export interface CarWashLocation {
  id: string;
  name: string;
  address: string;
  lat: number;
  lng: number;
  phone: string;
  rating: number;
  totalReviews: number;
  services: string[];
  operatingHours: {
    open: string;
    close: string;
    daysOpen: string[];
  };
  demandLevel: 'low' | 'medium' | 'high' | 'very_high';
  currentWaitTime: number; // in minutes
  estimatedWaitTime: number; // in minutes
  priorityPrice: number; // extra cost for priority
  basePrice: number;
  status: 'green' | 'yellow' | 'orange' | 'red';
  valeters: string[]; // valeter IDs who work here
  organization: string; // car wash company name
}

export interface PriorityWashBooking {
  id: string;
  customerId: string;
  carWashId: string;
  vehicleType: string;
  serviceType: string;
  priorityLevel: 'standard' | 'priority';
  basePrice: number;
  priorityFee: number;
  totalPrice: number;
  estimatedWaitTime: number;
  estimatedArrivalTime: Date;
  status: 'pending' | 'confirmed' | 'in_progress' | 'completed' | 'cancelled';
  createdAt: Date;
  vehicleDetails: {
    make: string;
    model: string;
    size: string;
    registration: string;
    photo?: string;
  };
}

export class PriorityWashService {
  private static instance: PriorityWashService;
  private carWashLocations: Map<string, CarWashLocation> = new Map();
  private priorityBookings: Map<string, PriorityWashBooking> = new Map();
  private demandUpdates: Map<string, NodeJS.Timeout> = new Map();

  static getInstance(): PriorityWashService {
    if (!PriorityWashService.instance) {
      PriorityWashService.instance = new PriorityWashService();
    }
    return PriorityWashService.instance;
  }

  constructor() {
    this.initializeCarWashLocations();
    this.startDemandSimulation();
  }

  private initializeCarWashLocations() {
    const locations: CarWashLocation[] = [
      {
        id: 'cw1',
        name: 'Central London Express Wash',
        address: '123 Oxford Street, London W1D 1BS',
        lat: 51.5154,
        lng: -0.1419,
        phone: '+44 20 1234 5678',
        rating: 4.6,
        totalReviews: 1247,
        services: ['Exterior Wash', 'Full Valet', 'Interior Clean', 'Wax & Polish'],
        operatingHours: {
          open: '07:00',
          close: '22:00',
          daysOpen: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        },
        demandLevel: 'medium',
        currentWaitTime: 15,
        estimatedWaitTime: 20,
        priorityPrice: 12,
        basePrice: 25,
        status: 'green',
        valeters: ['valeter1', 'valeter2'],
        organization: 'Central London Car Care Ltd'
      },
      {
        id: 'cw2',
        name: 'West London Premium Wash',
        address: '456 Kensington High Street, London W8 4QY',
        lat: 51.5007,
        lng: -0.1946,
        phone: '+44 20 1234 5679',
        rating: 4.8,
        totalReviews: 892,
        services: ['Premium Wash', 'Luxury Valet', 'Interior Detail', 'Ceramic Coating'],
        operatingHours: {
          open: '08:00',
          close: '20:00',
          daysOpen: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']
        },
        demandLevel: 'high',
        currentWaitTime: 45,
        estimatedWaitTime: 60,
        priorityPrice: 18,
        basePrice: 35,
        status: 'orange',
        valeters: ['valeter3', 'valeter4'],
        organization: 'West London Auto Services'
      },
      {
        id: 'cw3',
        name: 'Canary Wharf Quick Wash',
        address: '789 Canary Wharf, London E14 5AB',
        lat: 51.5054,
        lng: -0.0235,
        phone: '+44 20 1234 5680',
        rating: 4.4,
        totalReviews: 567,
        services: ['Express Wash', 'Standard Valet', 'Interior Clean'],
        operatingHours: {
          open: '06:00',
          close: '23:00',
          daysOpen: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        },
        demandLevel: 'low',
        currentWaitTime: 5,
        estimatedWaitTime: 8,
        priorityPrice: 8,
        basePrice: 20,
        status: 'green',
        valeters: ['valeter5'],
        organization: 'Canary Wharf Car Care'
      },
      {
        id: 'cw4',
        name: 'North London Family Wash',
        address: '321 Camden High Street, London NW1 7JE',
        lat: 51.5416,
        lng: -0.1464,
        phone: '+44 20 1234 5681',
        rating: 4.7,
        totalReviews: 734,
        services: ['Family Wash', 'SUV Valet', 'Van Clean', 'Interior Detail'],
        operatingHours: {
          open: '07:30',
          close: '21:00',
          daysOpen: ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday']
        },
        demandLevel: 'very_high',
        currentWaitTime: 90,
        estimatedWaitTime: 120,
        priorityPrice: 25,
        basePrice: 30,
        status: 'red',
        valeters: ['valeter6', 'valeter7', 'valeter8'],
        organization: 'North London Auto Group'
      }
    ];

    locations.forEach(location => {
      this.carWashLocations.set(location.id, location);
    });
  }

  private startDemandSimulation() {
    this.carWashLocations.forEach((location, id) => {
      const interval = setInterval(() => {
        this.updateDemandLevel(id);
      }, 30000); // Update every 30 seconds
      this.demandUpdates.set(id, interval);
    });
  }

  private updateDemandLevel(carWashId: string) {
    const location = this.carWashLocations.get(carWashId);
    if (!location) return;

    // Simulate demand changes based on time of day
    const hour = new Date().getHours();
    let newDemand: 'low' | 'medium' | 'high' | 'very_high';
    let newWaitTime: number;
    let newStatus: 'green' | 'yellow' | 'orange' | 'red';

    if (hour >= 7 && hour <= 9) {
      // Morning rush
      newDemand = 'high';
      newWaitTime = 45 + Math.random() * 30;
    } else if (hour >= 12 && hour <= 14) {
      // Lunch time
      newDemand = 'medium';
      newWaitTime = 20 + Math.random() * 25;
    } else if (hour >= 17 && hour <= 19) {
      // Evening rush
      newDemand = 'very_high';
      newWaitTime = 60 + Math.random() * 45;
    } else if (hour >= 22 || hour <= 6) {
      // Late night
      newDemand = 'low';
      newWaitTime = 5 + Math.random() * 10;
    } else {
      // Regular hours
      newDemand = 'medium';
      newWaitTime = 15 + Math.random() * 20;
    }

    // Update status based on wait time
    if (newWaitTime <= 15) {
      newStatus = 'green';
    } else if (newWaitTime <= 30) {
      newStatus = 'yellow';
    } else if (newWaitTime <= 60) {
      newStatus = 'orange';
    } else {
      newStatus = 'red';
    }

    // Update location
    location.demandLevel = newDemand;
    location.currentWaitTime = Math.round(newWaitTime);
    location.estimatedWaitTime = Math.round(newWaitTime * 1.2);
    location.status = newStatus;

    // Update priority price based on demand
    switch (newDemand) {
      case 'low':
        location.priorityPrice = location.basePrice * 0.3;
        break;
      case 'medium':
        location.priorityPrice = location.basePrice * 0.5;
        break;
      case 'high':
        location.priorityPrice = location.basePrice * 0.7;
        break;
      case 'very_high':
        location.priorityPrice = location.basePrice * 1.0;
        break;
    }

    this.carWashLocations.set(carWashId, location);
  }

  getCarWashLocations(): CarWashLocation[] {
    return Array.from(this.carWashLocations.values());
  }

  getCarWashLocation(id: string): CarWashLocation | undefined {
    return this.carWashLocations.get(id);
  }

  getNearbyCarWashes(lat: number, lng: number, radius: number = 10): CarWashLocation[] {
    return this.getCarWashLocations().filter(location => {
      const distance = this.calculateDistance(lat, lng, location.lat, location.lng);
      return distance <= radius;
    }).sort((a, b) => {
      const distanceA = this.calculateDistance(lat, lng, a.lat, a.lng);
      const distanceB = this.calculateDistance(lat, lng, b.lat, b.lng);
      return distanceA - distanceB;
    });
  }

  calculatePriorityPrice(carWashId: string, vehicleType: string, serviceType: string): {
    basePrice: number;
    priorityFee: number;
    totalPrice: number;
    estimatedWaitTime: number;
    canSkipQueue: boolean;
  } {
    const location = this.carWashLocations.get(carWashId);
    if (!location) {
      throw new Error('Car wash location not found');
    }

    // Base price by vehicle type
    let basePrice = location.basePrice;
    switch (vehicleType) {
      case 'bike':
        basePrice = 15;
        break;
      case 'small_car':
        basePrice = location.basePrice;
        break;
      case 'large_car':
        basePrice = location.basePrice * 1.3;
        break;
      case 'suv':
        basePrice = location.basePrice * 1.5;
        break;
      case 'van':
        basePrice = location.basePrice * 1.8;
        break;
      case 'coach':
        basePrice = location.basePrice * 3.0;
        break;
      case 'luxury':
        basePrice = location.basePrice * 2.0;
        break;
    }

    // Service type multiplier
    switch (serviceType) {
      case 'exterior_only':
        basePrice = basePrice * 0.7;
        break;
      case 'standard':
        basePrice = basePrice;
        break;
      case 'premium':
        basePrice = basePrice * 1.4;
        break;
      case 'luxury':
        basePrice = basePrice * 2.0;
        break;
    }

    const priorityFee = location.priorityPrice;
    const totalPrice = basePrice + priorityFee;
    const canSkipQueue = location.status === 'green' || location.status === 'yellow';

    return {
      basePrice: Math.round(basePrice),
      priorityFee: Math.round(priorityFee),
      totalPrice: Math.round(totalPrice),
      estimatedWaitTime: canSkipQueue ? 5 : location.estimatedWaitTime,
      canSkipQueue
    };
  }

  bookPriorityWash(
    customerId: string,
    carWashId: string,
    vehicleType: string,
    serviceType: string,
    priorityLevel: 'standard' | 'priority',
    vehicleDetails: {
      make: string;
      model: string;
      size: string;
      registration: string;
      photo?: string;
    }
  ): PriorityWashBooking {
    const location = this.carWashLocations.get(carWashId);
    if (!location) {
      throw new Error('Car wash location not found');
    }

    const pricing = this.calculatePriorityPrice(carWashId, vehicleType, serviceType);
    const bookingId = `pw_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

    const booking: PriorityWashBooking = {
      id: bookingId,
      customerId,
      carWashId,
      vehicleType,
      serviceType,
      priorityLevel,
      basePrice: pricing.basePrice,
      priorityFee: priorityLevel === 'priority' ? pricing.priorityFee : 0,
      totalPrice: priorityLevel === 'priority' ? pricing.totalPrice : pricing.basePrice,
      estimatedWaitTime: priorityLevel === 'priority' ? pricing.estimatedWaitTime : location.estimatedWaitTime,
      estimatedArrivalTime: new Date(Date.now() + (priorityLevel === 'priority' ? pricing.estimatedWaitTime : location.estimatedWaitTime) * 60000),
      status: 'pending',
      createdAt: new Date(),
      vehicleDetails
    };

    this.priorityBookings.set(bookingId, booking);
    return booking;
  }

  getPriorityBooking(bookingId: string): PriorityWashBooking | undefined {
    return this.priorityBookings.get(bookingId);
  }

  getUserPriorityBookings(userId: string): PriorityWashBooking[] {
    return Array.from(this.priorityBookings.values())
      .filter(booking => booking.customerId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  updateBookingStatus(bookingId: string, status: PriorityWashBooking['status']): boolean {
    const booking = this.priorityBookings.get(bookingId);
    if (!booking) return false;

    booking.status = status;
    this.priorityBookings.set(bookingId, booking);
    return true;
  }

  private calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 6371; // Earth's radius in kilometers
    const dLat = this.toRadians(lat2 - lat1);
    const dLng = this.toRadians(lng2 - lng1);
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(this.toRadians(lat1)) * Math.cos(this.toRadians(lat2)) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  private toRadians(degrees: number): number {
    return degrees * (Math.PI / 180);
  }

  cleanup() {
    this.demandUpdates.forEach(interval => clearInterval(interval));
    this.demandUpdates.clear();
  }
}

export const priorityWashService = PriorityWashService.getInstance();
