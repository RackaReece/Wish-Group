// Google Maps API Configuration
// Replace YOUR_ACTUAL_API_KEY with your real Google Maps API key

export const GOOGLE_MAPS_API_KEY = 'AIzaSyDFb-6K3EG1rAvCeUJytpBZ_bjdeYn55-g';

// For development/testing, you can use a placeholder
// export const GOOGLE_MAPS_API_KEY = 'AIzaSyB41DRUbKWJHPxaFjMAwdrzWzbVKartNGg';

// Instructions for getting a Google Maps API key:
// 1. Go to Google Cloud Console (https://console.cloud.google.com/)
// 2. Create a new project or select an existing one
// 3. Enable the Maps JavaScript API
// 4. Create credentials (API key)
// 5. Restrict the API key to your app's domain/IP for security
// 6. Replace 'YOUR_ACTUAL_API_KEY' above with your real API key

export const MAPS_CONFIG = {
  apiKey: GOOGLE_MAPS_API_KEY,
  defaultCenter: {
    lat: 51.5074, // London coordinates
    lng: -0.1278
  },
  defaultZoom: 15,
  mapStyles: [
    {
      featureType: 'poi',
      elementType: 'labels',
      stylers: [{ visibility: 'off' }]
    }
  ]
};
