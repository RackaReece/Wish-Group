// DVLA Vehicle Enquiry Service API Configuration
// Get your API key from: https://developer-portal.driver-vehicle-licensing.api.gov.uk/

export const DVLA_API_KEY = process.env.EXPO_PUBLIC_DVLA_API_KEY || null;

// If you have a hardcoded key for development, uncomment and use:
// export const DVLA_API_KEY = 'your-dvla-api-key-here';

export const DVLA_CONFIG = {
  apiKey: DVLA_API_KEY,
  baseUrl: 'https://driver-vehicle-licensing.api.gov.uk/vehicle-enquiry/v1/vehicles',
};



















