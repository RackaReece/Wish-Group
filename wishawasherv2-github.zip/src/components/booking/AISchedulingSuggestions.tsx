import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, ScrollView, ActivityIndicator, Alert } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../providers/enhanced-auth-context';
import { supabase } from '../../lib/supabase';
import { AISchedulingService, SchedulingSuggestion } from '../../services/AISchedulingService';
import { colors } from '../../constants/colors';

const SKY = colors.SKY;

interface AISchedulingSuggestionsProps {
  location: { latitude: number; longitude: number };
  onSelectSuggestion: (date: string, timeSlot: string) => void;
}

export default function AISchedulingSuggestions({ location, onSelectSuggestion }: AISchedulingSuggestionsProps) {
  const { user } = useAuth();
  const [suggestions, setSuggestions] = useState<SchedulingSuggestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [hasLastBooking, setHasLastBooking] = useState(false);
  const [lastBooking, setLastBooking] = useState<any>(null);

  useEffect(() => {
    loadSuggestions();
    loadLastBooking();
  }, [location, user?.id]);

  const loadLastBooking = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('id, service_type, service_name, location_address, location_lat, location_lng, vehicle_type, vehicle_info')
        .eq('user_id', user.id)
        .in('status', ['completed', 'rated', 'tipped', 'closed'])
        .order('completed_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (!error && data) {
        setHasLastBooking(true);
        setLastBooking(data);
      } else {
        setHasLastBooking(false);
      }
    } catch (error) {
      console.error('Error loading last booking:', error);
      setHasLastBooking(false);
    }
  };

  const loadSuggestions = async () => {
    try {
      setLoading(true);
      const data = await AISchedulingService.getSchedulingSuggestions(location, 7);
      setSuggestions(data);
    } catch (error) {
      console.error('Error loading suggestions:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Ionicons name="sparkles" size={20} color={SKY} />
          <Text style={styles.title}>AI Scheduling Suggestions</Text>
        </View>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="small" color={SKY} />
          <Text style={styles.loadingText}>Analyzing best times...</Text>
        </View>
      </View>
    );
  }

  const handleRepeatBooking = () => {
    if (!lastBooking) return;

    // Navigate to appropriate booking flow based on service type
    if (lastBooking.service_type?.includes('detailing')) {
      router.push({
        pathname: '/owner/booking/detailing/create',
        params: {
          ...(lastBooking.location_address && { address: lastBooking.location_address }),
          ...(lastBooking.location_lat && { latitude: lastBooking.location_lat.toString() }),
          ...(lastBooking.location_lng && { longitude: lastBooking.location_lng.toString() }),
          ...(lastBooking.vehicle_type && { vehicleType: lastBooking.vehicle_type }),
          ...(lastBooking.vehicle_info && { vehicleInfo: lastBooking.vehicle_info }),
        },
      });
    } else if (lastBooking.service_type?.includes('eco')) {
      router.push({
        pathname: '/owner/booking/eco/create',
        params: {
          deliveryType: 'comeToYou',
          ...(lastBooking.location_address && { address: lastBooking.location_address }),
          ...(lastBooking.location_lat && { latitude: lastBooking.location_lat.toString() }),
          ...(lastBooking.location_lng && { longitude: lastBooking.location_lng.toString() }),
        },
      });
    } else {
      router.push({
        pathname: '/owner/booking/create',
        params: {
          ...(lastBooking.location_address && { address: lastBooking.location_address }),
          ...(lastBooking.location_lat && { latitude: lastBooking.location_lat.toString() }),
          ...(lastBooking.location_lng && { longitude: lastBooking.location_lng.toString() }),
          ...(lastBooking.vehicle_type && { vehicleType: lastBooking.vehicle_type }),
        },
      });
    }
  };

  if (suggestions.length === 0) {
    return null;
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Ionicons name="sparkles" size={20} color={SKY} />
        <Text style={styles.title}>AI Scheduling Suggestions</Text>
        <Text style={styles.subtitle}>Best times based on weather & demand</Text>
      </View>

      <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        {suggestions.map((suggestion, index) => {
          const date = new Date(suggestion.date);
          const dateStr = date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' });
          const scoreColor = suggestion.overallScore >= 80 ? '#10B981' : suggestion.overallScore >= 60 ? '#F59E0B' : SKY;

          return (
            <View key={index} style={styles.suggestionCard}>
              <TouchableOpacity
                style={styles.cardTouchable}
                onPress={() => onSelectSuggestion(suggestion.date, suggestion.timeSlot)}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={[scoreColor + '20', scoreColor + '10']}
                  style={styles.cardGradient}
                >
                  <View style={styles.cardHeader}>
                    <View style={[styles.scoreBadge, { backgroundColor: scoreColor }]}>
                      <Text style={styles.scoreText}>{Math.round(suggestion.overallScore)}%</Text>
                    </View>
                    <Ionicons name="calendar" size={16} color={scoreColor} />
                  </View>
                  <Text style={styles.dateText}>{dateStr}</Text>
                  <Text style={styles.timeText}>{suggestion.timeSlot}</Text>
                  <View style={styles.metrics}>
                    <View style={styles.metric}>
                      <Ionicons name="sunny" size={12} color={SKY} />
                      <Text style={styles.metricText}>{suggestion.weatherScore}%</Text>
                    </View>
                    <View style={styles.metric}>
                      <Ionicons name="trending-up" size={12} color={SKY} />
                      <Text style={styles.metricText}>{suggestion.demandScore}%</Text>
                    </View>
                  </View>
                  <Text style={styles.reasonText} numberOfLines={2}>{suggestion.reason}</Text>
                </LinearGradient>
              </TouchableOpacity>
              {hasLastBooking && (
                <TouchableOpacity
                  style={styles.repeatButton}
                  onPress={handleRepeatBooking}
                  activeOpacity={0.7}
                >
                  <Ionicons name="repeat" size={14} color="#10B981" />
                  <Text style={styles.repeatButtonText}>Repeat</Text>
                </TouchableOpacity>
              )}
            </View>
          );
        })}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    paddingHorizontal: 4,
  },
  title: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
  },
  subtitle: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    marginLeft: 'auto',
  },
  loadingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  scrollContent: {
    gap: 12,
    paddingRight: 20,
  },
  suggestionCard: {
    width: 160,
    borderRadius: 16,
    overflow: 'visible',
    marginBottom: 8,
  },
  cardTouchable: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  cardGradient: {
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  scoreBadge: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  scoreText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '700',
  },
  dateText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  timeText: {
    color: SKY,
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  metrics: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 8,
  },
  metric: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metricText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 11,
  },
  reasonText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 11,
    lineHeight: 14,
  },
  repeatButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderRadius: 8,
    paddingVertical: 6,
    paddingHorizontal: 8,
    marginTop: 8,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  repeatButtonText: {
    color: '#10B981',
    fontSize: 11,
    fontWeight: '600',
  },
});

