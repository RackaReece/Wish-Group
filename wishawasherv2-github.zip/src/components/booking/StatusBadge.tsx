import React, { useMemo } from 'react';
import { View, Text, StyleSheet, StyleProp, ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors as appColors } from '../../constants/colors'; // adjust path if needed

type StatusBadgeSize = 'small' | 'medium' | 'large';

type AnyStatus =
  // DB / schema statuses
  | 'scheduled'
  | 'in_progress'
  | 'completed'
  | 'cancelled'
  // older / UI statuses you’ve used in screens
  | 'pending_payment'
  | 'confirmed'
  | 'valeter_assigned'
  | 'en_route'
  | 'arrived'
  | 'rejected'
  | 'unknown'
  // allow unexpected values from DB without crashing
  | string;

type BadgeConfig = {
  label: string;
  colors: string[];
  borderColor: string;
  icon: keyof typeof Ionicons.glyphMap;
};

const SKY = appColors?.SKY ?? '#38BDF8';

const STATUS_CONFIG: Record<string, BadgeConfig> = {
  // ✅ DB schema aligned
  scheduled: {
    label: 'Scheduled',
    colors: ['rgba(56,189,248,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(56,189,248,0.45)',
    icon: 'calendar-outline',
  },
  in_progress: {
    label: 'In Progress',
    colors: ['rgba(245,158,11,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(245,158,11,0.55)',
    icon: 'construct-outline',
  },
  completed: {
    label: 'Completed',
    colors: ['rgba(16,185,129,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(16,185,129,0.55)',
    icon: 'checkmark-circle-outline',
  },
  cancelled: {
    label: 'Cancelled',
    colors: ['rgba(239,68,68,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(239,68,68,0.55)',
    icon: 'close-circle-outline',
  },

  // ✅ older flow statuses (keep for both apps)
  pending_payment: {
    label: 'Pending Payment',
    colors: ['rgba(245,158,11,0.4)', 'rgba(245,158,11,0.15)'],
    borderColor: 'rgba(245,158,11,0.6)',
    icon: 'lock-closed',
  },
  confirmed: {
    label: 'Confirmed',
    colors: ['rgba(56,189,248,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(56,189,248,0.45)',
    icon: 'checkmark-outline',
  },
  valeter_assigned: {
    label: 'Valeter Assigned',
    colors: ['rgba(99,102,241,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(99,102,241,0.55)',
    icon: 'person-outline',
  },
  en_route: {
    label: 'En Route',
    colors: ['rgba(245,158,11,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(245,158,11,0.55)',
    icon: 'navigate-outline',
  },
  arrived: {
    label: 'Arrived',
    colors: ['rgba(34,197,94,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(34,197,94,0.55)',
    icon: 'pin-outline',
  },
  rejected: {
    label: 'Rejected',
    colors: ['rgba(239,68,68,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(239,68,68,0.55)',
    icon: 'alert-circle-outline',
  },
};

const FALLBACK_CONFIG: BadgeConfig = {
  label: 'Status',
  colors: ['rgba(56,189,248,0.25)', 'rgba(30,58,138,0.10)'],
  borderColor: 'rgba(56,189,248,0.35)',
  icon: 'information-circle-outline',
};

export default function StatusBadge({
  status,
  size = 'small',
  style,
}: {
  status: AnyStatus;
  size?: StatusBadgeSize;
  style?: StyleProp<ViewStyle>;
}) {
  const config = useMemo(() => {
    const key = String(status ?? '').toLowerCase();
    return STATUS_CONFIG[key] ?? {
      ...FALLBACK_CONFIG,
      label: key ? key.replace(/_/g, ' ') : FALLBACK_CONFIG.label,
    };
  }, [status]);

  const padding = size === 'large' ? 16 : size === 'medium' ? 12 : 10;
  const fontSize = size === 'large' ? 15 : size === 'medium' ? 14 : 13;
  const iconSize = size === 'large' ? 18 : size === 'medium' ? 16 : 14;

  // Get icon color based on status
  const getIconColor = () => {
    const statusKey = String(status ?? '').toLowerCase();
    if (statusKey === 'pending_payment') return '#F59E0B';
    if (statusKey === 'completed' || statusKey === 'arrived' || statusKey === 'confirmed') return '#10B981';
    if (statusKey === 'cancelled' || statusKey === 'rejected') return '#EF4444';
    if (statusKey === 'in_progress' || statusKey === 'en_route') return '#F59E0B';
    return SKY;
  };

  return (
    <View
      style={[
        styles.container,
        { paddingHorizontal: padding, paddingVertical: padding / 1.5 },
        style,
      ]}
    >
      <LinearGradient 
        colors={config.colors} 
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={StyleSheet.absoluteFill} 
      />
      <View style={[styles.border, { borderColor: config.borderColor }]} />

      <View style={styles.row}>
        <Ionicons name={config.icon} size={iconSize} color={getIconColor()} />
        <Text style={[styles.text, { fontSize }]} numberOfLines={1}>
          {config.label}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 12,
    overflow: 'hidden',
    alignSelf: 'flex-start',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
  },
  border: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
    borderRadius: 12,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    position: 'relative',
    zIndex: 1,
  },
  text: {
    color: '#F9FAFB',
    fontWeight: '700',
    letterSpacing: 0.3,
    textTransform: 'capitalize',
  },
});
