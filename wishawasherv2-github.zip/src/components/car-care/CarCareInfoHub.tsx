import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  ActivityIndicator,
  RefreshControl,
  Dimensions,
  Alert,
  Modal,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../providers/enhanced-auth-context';
import { supabase } from '../../lib/supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../shared/AppHeader';
import GlassCard from '../booking/GlassCard';
import BubbleBackground from '../shared/BubbleBackground';
import { colors } from '../../constants/colors';
import { getAccountTheme } from '../../constants/accountThemes';
import { STANDARD_SPACING } from '../../constants/cardSizes';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;


interface ComingSoonFeature {
  id: string;
  title: string;
  description: string;
  icon: string;
  availableDate?: string;
}

interface TaxMOTReminder {
  id: string;
  vehicleId: string;
  type: 'tax' | 'mot';
  vehicleRegistration: string;
  expiryDate: Date;
  daysRemaining: number;
}


interface Promotion {
  id: string;
  code?: string;
  title: string;
  description: string;
  discount?: number;
  discountPercent?: number;
  expiry?: Date;
  type: 'code' | 'offer' | 'subscription';
  price?: number;
  savings?: number;
  benefits?: string[];
  route?: string;
}

interface DailyGoal {
  id: string;
  title: string;
  icon: keyof typeof Ionicons.glyphMap;
  completed: boolean;
}

const DEFAULT_GOALS: Omit<DailyGoal, 'completed'>[] = [
  { id: 'check_stock', title: 'Check Stock', icon: 'cube-outline' },
  { id: 'take_break', title: 'Take a Break', icon: 'cafe-outline' },
  { id: 'clean_with_care', title: 'Clean with Care', icon: 'sparkles-outline' },
  { id: 'check_equipment', title: 'Check Equipment', icon: 'construct-outline' },
  { id: 'review_schedule', title: 'Review Schedule', icon: 'calendar-outline' },
];

const getProductivityKey = (userId: string, date: string) => `valeter:productivity:${userId}:${date}`;

export default function CarCareInfoHub({ userType, onClose }: { userType: 'customer' | 'valeter' | 'organization'; onClose?: () => void }) {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'reminders' | 'promotions' | 'productivity'>('reminders');
  
  // Get theme based on user type
  const theme = userType === 'customer' 
    ? getAccountTheme('customer')
    : userType === 'valeter'
    ? getAccountTheme('valeter')
    : getAccountTheme('business');
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [reminders, setReminders] = useState<TaxMOTReminder[]>([]);
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const [dailyGoals, setDailyGoals] = useState<DailyGoal[]>([]);
  const [valeterName, setValeterName] = useState<string>('');
  const [showCelebration, setShowCelebration] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);
  
  const confettiAnim = useRef(new Animated.Value(0)).current;
  const celebrationScale = useRef(new Animated.Value(0)).current;



  // Get current season
  const getCurrentSeason = (): 'spring' | 'summer' | 'autumn' | 'winter' => {
    const month = new Date().getMonth();
    if (month >= 2 && month <= 4) return 'spring'; // March-May
    if (month >= 5 && month <= 7) return 'summer'; // June-August
    if (month >= 8 && month <= 10) return 'autumn'; // September-November
    return 'winter'; // December-February
  };

  // Load all promotions and offers
  const loadPromotions = async () => {
    setLoading(true);
    try {
      const currentSeason = getCurrentSeason();
      const now = Date.now();
      
      // Seasonal promotions - only show during appropriate seasons
      const seasonalPromotions: Promotion[] = [];
      
      if (currentSeason === 'spring') {
        seasonalPromotions.push({
          id: 'promo-spring',
          code: 'SPRING20',
          title: 'Spring Cleaning Special',
          description: '20% off all car washes this spring',
          discountPercent: 20,
          expiry: new Date(now + 90 * 24 * 60 * 60 * 1000), // 90 days
          type: 'code',
        });
      } else if (currentSeason === 'summer') {
        seasonalPromotions.push({
          id: 'promo-summer',
          code: 'SUMMER25',
          title: 'Summer Special',
          description: '25% off all car washes this summer',
          discountPercent: 25,
          expiry: new Date(now + 90 * 24 * 60 * 60 * 1000), // 90 days
          type: 'code',
        });
      } else if (currentSeason === 'autumn') {
        seasonalPromotions.push({
          id: 'promo-autumn',
          code: 'AUTUMN15',
          title: 'Autumn Clean',
          description: '15% off all car washes this autumn',
          discountPercent: 15,
          expiry: new Date(now + 90 * 24 * 60 * 60 * 1000), // 90 days
          type: 'code',
        });
      } else if (currentSeason === 'winter') {
        seasonalPromotions.push({
          id: 'promo-winter',
          code: 'WINTER20',
          title: 'Winter Warm-Up',
          description: '20% off all car washes this winter',
          discountPercent: 20,
          expiry: new Date(now + 90 * 24 * 60 * 60 * 1000), // 90 days
          type: 'code',
        });
      }

      // Subscription offers (always available)
      const subscriptionOffers: Promotion[] = [
        {
          id: 'sub-1',
          title: 'Monthly Wash Plan',
          description: '4 washes per month',
          price: 60,
          savings: 25,
          benefits: ['Priority booking', 'Free interior clean'],
          route: '/owner/features/subscriptions',
          type: 'subscription',
        },
        {
          id: 'sub-2',
          title: 'Premium Package',
          description: '8 washes per month',
          price: 120,
          savings: 30,
          benefits: ['Unlimited priority', 'Free wax & polish'],
          route: '/owner/features/subscriptions',
          type: 'subscription',
        },
      ];

      setPromotions([...seasonalPromotions, ...subscriptionOffers]);
    } catch (error) {
      console.error('Error loading promotions:', error);
      setPromotions([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    if (activeTab === 'promotions') {
      loadPromotions();
    } else if (activeTab === 'productivity' && userType === 'valeter') {
      loadProductivityGoals();
      loadValeterName();
    }
  }, [activeTab, userType]);

  useEffect(() => {
    if (showCelebration) {
      Animated.parallel([
        Animated.spring(celebrationScale, {
          toValue: 1,
          tension: 50,
          friction: 7,
          useNativeDriver: true,
        }),
        Animated.timing(confettiAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      celebrationScale.setValue(0);
      confettiAnim.setValue(0);
    }
  }, [showCelebration]);

  const onRefresh = () => {
    setRefreshing(true);
    if (activeTab === 'promotions') {
      loadPromotions();
    } else if (activeTab === 'reminders') {
      loadReminders();
    } else if (activeTab === 'productivity') {
      loadProductivityGoals();
    }
  };

  const loadValeterName = async () => {
    if (!user?.id || userType !== 'valeter') return;
    try {
      const { data: profile } = await supabase
        .from('valeter_profiles')
        .select('display_name')
        .eq('user_id', user.id)
        .maybeSingle();
      
      if (profile?.display_name) {
        setValeterName(profile.display_name);
      } else {
        const { data: userProfile } = await supabase
          .from('profiles')
          .select('full_name')
          .eq('id', user.id)
          .maybeSingle();
        
        setValeterName(userProfile?.full_name || user.name || 'Valeter');
      }
    } catch (error) {
      console.error('Error loading valeter name:', error);
      setValeterName(user.name || 'Valeter');
    }
  };

  const loadProductivityGoals = async () => {
    if (!user?.id || userType !== 'valeter') return;
    try {
      const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD
      const key = getProductivityKey(user.id, today);
      const stored = await AsyncStorage.getItem(key);
      
      if (stored) {
        const completedIds = JSON.parse(stored) as string[];
        const goals = DEFAULT_GOALS.map(goal => ({
          ...goal,
          completed: completedIds.includes(goal.id),
        }));
        setDailyGoals(goals);
      } else {
        const goals = DEFAULT_GOALS.map(goal => ({
          ...goal,
          completed: false,
        }));
        setDailyGoals(goals);
      }
    } catch (error) {
      console.error('Error loading productivity goals:', error);
      const goals = DEFAULT_GOALS.map(goal => ({
        ...goal,
        completed: false,
      }));
      setDailyGoals(goals);
    }
  };

  const toggleGoal = async (goalId: string) => {
    if (!user?.id || userType !== 'valeter') return;
    
    try {
      await hapticFeedback('light');
      const updatedGoals = dailyGoals.map(goal =>
        goal.id === goalId ? { ...goal, completed: !goal.completed } : goal
      );
      setDailyGoals(updatedGoals);

      const today = new Date().toISOString().split('T')[0];
      const key = getProductivityKey(user.id, today);
      const completedIds = updatedGoals.filter(g => g.completed).map(g => g.id);
      await AsyncStorage.setItem(key, JSON.stringify(completedIds));

      // Check if all goals are completed
      const allCompleted = updatedGoals.every(goal => goal.completed);
      if (allCompleted && updatedGoals.length > 0) {
        await hapticFeedback('heavy');
        setShowCelebration(true);
      }
    } catch (error) {
      console.error('Error toggling goal:', error);
    }
  };




  // Load Tax & MOT reminders
  const loadReminders = async () => {
    if (!user?.id) {
      setReminders([]);
      return;
    }

    setLoading(true);
    try {
      let vehicles: any[] = [];
      
      // For valeters, check valeter_profiles table
      if (userType === 'valeter') {
        const { data: valeterProfile, error: valeterError } = await supabase
          .from('valeter_profiles')
          .select('user_id, vehicle_registration, vehicle_make, vehicle_model, tax_expiry, mot_expiry')
          .eq('user_id', user.id)
          .maybeSingle();
        
        if (!valeterError && valeterProfile && valeterProfile.vehicle_registration) {
          // Convert valeter profile to vehicle format
          vehicles = [{
            id: valeterProfile.user_id,
            registration: valeterProfile.vehicle_registration,
            tax_expiry: valeterProfile.tax_expiry,
            mot_expiry: valeterProfile.mot_expiry,
          }];
        }
      } else {
        // For customers, use customer_vehicles table
        const { data: customerVehicles, error } = await supabase
          .from('customer_vehicles')
          .select('id,registration,tax_expiry,mot_expiry')
          .eq('user_id', user.id);
        
        if (error) {
          // If error is about missing columns (42703 = undefined_column), skip reminders
          if (error.code === '42703' || error.message?.includes('does not exist') || error.message?.includes('tax_expiry')) {
            console.warn('Tax/MOT expiry columns not available in database, skipping reminders');
            setReminders([]);
            return;
          }
          throw error;
        }
        
        vehicles = customerVehicles || [];
      }


      const reminderList: TaxMOTReminder[] = [];

      vehicles?.forEach((vehicle: any) => {
        const now = new Date();
        
        // Tax reminders (only if column exists)
        if (vehicle.tax_expiry) {
          try {
            const taxExpiry = new Date(vehicle.tax_expiry);
            const daysRemaining = Math.ceil((taxExpiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
            if (daysRemaining >= 0 && daysRemaining <= 60) {
              reminderList.push({
                id: `tax-${vehicle.id}`,
                vehicleId: vehicle.id,
                type: 'tax',
                vehicleRegistration: vehicle.registration || 'Unknown',
                expiryDate: taxExpiry,
                daysRemaining,
              });
            }
          } catch {
            // Invalid date, skip
          }
        }

        // MOT reminders (only if column exists)
        if (vehicle.mot_expiry) {
          try {
            const motExpiry = new Date(vehicle.mot_expiry);
            const daysRemaining = Math.ceil((motExpiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
            if (daysRemaining >= 0 && daysRemaining <= 60) {
              reminderList.push({
                id: `mot-${vehicle.id}`,
                vehicleId: vehicle.id,
                type: 'mot',
                vehicleRegistration: vehicle.registration || 'Unknown',
                expiryDate: motExpiry,
                daysRemaining,
              });
            }
          } catch {
            // Invalid date, skip
          }
        }
      });

      // Sort by days remaining (most urgent first)
      reminderList.sort((a, b) => a.daysRemaining - b.daysRemaining);
      setReminders(reminderList);
    } catch (error) {
      console.error('Error loading reminders:', error);
      setReminders([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const handleDeleteVehicle = async (vehicleId: string, vehicleRegistration: string) => {
    Alert.alert(
      'Delete Vehicle',
      `Are you sure you want to delete vehicle ${vehicleRegistration}? This will remove all reminders for this vehicle.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('customer_vehicles')
                .delete()
                .eq('id', vehicleId)
                .eq('user_id', user?.id);

              if (error) throw error;

              // Reload reminders to reflect the deletion
              await loadReminders();
            } catch (error: any) {
              console.error('Error deleting vehicle:', error);
              Alert.alert('Error', error?.message || 'Failed to delete vehicle');
            }
          },
        },
      ]
    );
  };

  const handleDeleteAllVehicles = async () => {
    if (reminders.length === 0) return;

    // Get unique vehicle IDs from reminders
    const uniqueVehicleIds = Array.from(new Set(reminders.map((r) => r.vehicleId)));

    Alert.alert(
      'Delete All Vehicles',
      `Are you sure you want to delete all ${uniqueVehicleIds.length} vehicle${uniqueVehicleIds.length !== 1 ? 's' : ''}? This will remove all reminders.`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete All',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('customer_vehicles')
                .delete()
                .in('id', uniqueVehicleIds)
                .eq('user_id', user?.id);

              if (error) throw error;

              // Reload reminders to reflect the deletion
              await loadReminders();
            } catch (error: any) {
              console.error('Error deleting all vehicles:', error);
              Alert.alert('Error', error?.message || 'Failed to delete all vehicles');
            }
          },
        },
      ]
    );
  };

  useEffect(() => {
    if (activeTab === 'reminders') {
      loadReminders();
    } else if (activeTab === 'productivity' && userType === 'valeter') {
      loadProductivityGoals();
      loadValeterName();
    }
  }, [activeTab, user?.id]);

  useEffect(() => {
    if (showCelebration) {
      Animated.parallel([
        Animated.spring(celebrationScale, {
          toValue: 1,
          tension: 50,
          friction: 7,
          useNativeDriver: true,
        }),
        Animated.timing(confettiAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
      ]).start();
    } else {
      celebrationScale.setValue(0);
      confettiAnim.setValue(0);
    }
  }, [showCelebration]);

  const renderPromotions = () => {
    if (loading && !refreshing) {
      return (
        <View style={styles.contentSection}>
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={theme.primary} />
            <Text style={[styles.loadingText, { color: theme.primary }]}>Loading promotions...</Text>
          </View>
        </View>
      );
    }

    if (promotions.length === 0) {
      return (
        <View style={styles.contentSection}>
          <GlassCard style={styles.emptyCard} accountType={userType === 'customer' ? 'customer' : userType === 'valeter' ? 'valeter' : 'business'}>
            <View style={styles.emptyContainer}>
              <View style={[styles.emptyIconWrapper, { backgroundColor: `${theme.primary}20` }]}>
                <Ionicons name="pricetag-outline" size={48} color={theme.primary} />
              </View>
              <Text style={styles.emptyTitle}>No Promotions Available</Text>
              <Text style={styles.emptySubtitle}>
                Check back soon for new offers and discounts
              </Text>
            </View>
          </GlassCard>
        </View>
      );
    }

    return (
      <View style={styles.contentSection}>
        <Text style={styles.sectionDescription}>
          All available promotions and offers
        </Text>
        {promotions.map((promo) => {
          const isExpiringSoon = promo.expiry && (promo.expiry.getTime() - Date.now()) < 48 * 60 * 60 * 1000;
          const timeRemaining = promo.expiry 
            ? Math.max(0, promo.expiry.getTime() - Date.now())
            : null;
          const hoursRemaining = timeRemaining ? Math.floor(timeRemaining / (1000 * 60 * 60)) : null;
          const minutesRemaining = timeRemaining ? Math.floor((timeRemaining % (1000 * 60 * 60)) / (1000 * 60)) : null;

          if (promo.type === 'subscription') {
            return (
              <GlassCard
                key={promo.id}
                style={styles.promotionCard}
                onPress={() => promo.route && router.push(promo.route as any)}
                accountType={userType === 'customer' ? 'customer' : userType === 'valeter' ? 'valeter' : 'business'}
              >
                <LinearGradient
                  colors={[`${theme.primary}12`, `${theme.primary}06`]}
                  style={StyleSheet.absoluteFill}
                />
                <View style={styles.promotionContentWrapper}>
                  <View style={styles.promotionHeader}>
                    <View style={[styles.promotionIconWrapper, { backgroundColor: `${theme.primary}25`, borderColor: `${theme.primary}40` }]}>
                      <Ionicons name="star" size={24} color={theme.primary} />
                    </View>
                    <View style={styles.promotionContent}>
                      <Text style={styles.promotionTitle}>{promo.title}</Text>
                      <Text style={styles.promotionDescription}>{promo.description}</Text>
                      {promo.benefits && promo.benefits.length > 0 && (
                        <View style={styles.promotionBenefits}>
                          {promo.benefits.map((benefit, idx) => (
                            <View key={idx} style={styles.benefitItem}>
                              <Ionicons name="checkmark-circle" size={14} color={theme.primary} />
                              <Text style={styles.benefitText}>{benefit}</Text>
                            </View>
                          ))}
                        </View>
                      )}
                    </View>
                  </View>
                  <View style={styles.promotionFooter}>
                    <View style={styles.promotionPricing}>
                      <Text style={styles.promotionPrice}>£{promo.price}</Text>
                      {promo.savings && (
                        <Text style={[styles.promotionSavings, { color: '#10B981' }]}>Save {promo.savings}%</Text>
                      )}
                    </View>
                    <Ionicons name="chevron-forward" size={20} color={theme.primary} />
                  </View>
                </View>
              </GlassCard>
            );
          }

          return (
            <GlassCard
              key={promo.id}
              style={styles.promotionCard}
              onPress={() => {
                if (promo.code) {
                  router.push({
                    pathname: '/owner/booking',
                    params: { promoCode: promo.code },
                  } as any);
                }
              }}
              accountType={userType === 'customer' ? 'customer' : userType === 'valeter' ? 'valeter' : 'business'}
            >
              <LinearGradient
                colors={isExpiringSoon 
                  ? ['rgba(239,68,68,0.12)', 'rgba(239,68,68,0.06)']
                  : [`${theme.primary}12`, `${theme.primary}06`]}
                style={StyleSheet.absoluteFill}
              />
              <View style={styles.promotionContentWrapper}>
                <View style={styles.promotionHeader}>
                  <View style={[
                    styles.promotionIconWrapper,
                    { 
                      backgroundColor: isExpiringSoon 
                        ? 'rgba(239,68,68,0.25)' 
                        : `${theme.primary}25`,
                      borderColor: isExpiringSoon 
                        ? 'rgba(239,68,68,0.40)' 
                        : `${theme.primary}40`
                    },
                  ]}>
                    <Ionicons 
                      name={promo.type === 'offer' ? 'flash' : 'pricetag'} 
                      size={24} 
                      color={isExpiringSoon ? '#EF4444' : theme.primary} 
                    />
                  </View>
                  <View style={styles.promotionContent}>
                    <Text style={styles.promotionTitle}>{promo.title}</Text>
                    <Text style={styles.promotionDescription}>{promo.description}</Text>
                    {promo.code && (
                      <View style={styles.promoCodeContainer}>
                        <Text style={styles.promoCodeLabel}>Code:</Text>
                        <Text style={[
                          styles.promoCode,
                          {
                            color: theme.primary,
                            backgroundColor: `${theme.primary}26`,
                            borderColor: `${theme.primary}4D`,
                          }
                        ]}>{promo.code}</Text>
                      </View>
                    )}
                  </View>
                </View>
                <View style={styles.promotionFooter}>
                  <View style={styles.promotionDiscount}>
                    {promo.discountPercent ? (
                      <Text style={[styles.promotionDiscountText, { color: isExpiringSoon ? '#EF4444' : theme.primary }]}>
                        {promo.discountPercent}% OFF
                      </Text>
                    ) : promo.discount ? (
                      <Text style={[styles.promotionDiscountText, { color: isExpiringSoon ? '#EF4444' : theme.primary }]}>
                        Save £{promo.discount}
                      </Text>
                    ) : null}
                    {timeRemaining && timeRemaining > 0 && (
                      <Text style={[
                        styles.promotionTimer,
                        isExpiringSoon && { color: '#EF4444' },
                      ]}>
                        {hoursRemaining}h {minutesRemaining}m left
                      </Text>
                    )}
                  </View>
                  <TouchableOpacity
                    style={[
                      styles.redeemButton,
                      {
                        backgroundColor: isExpiringSoon ? 'rgba(239,68,68,0.30)' : `${theme.primary}40`,
                        borderColor: isExpiringSoon ? 'rgba(239,68,68,0.40)' : `${theme.primary}66`,
                      }
                    ]}
                    onPress={() => {
                      if (promo.code) {
                        router.push({
                          pathname: '/owner/booking',
                          params: { promoCode: promo.code },
                        } as any);
                      }
                    }}
                  >
                    <Text style={[
                      styles.redeemButtonText,
                      { color: isExpiringSoon ? '#EF4444' : theme.primary }
                    ]}>
                      Redeem
                    </Text>
                  </TouchableOpacity>
                </View>
              </View>
            </GlassCard>
          );
        })}
      </View>
    );
  };

  const renderProductivity = () => {
    const completedCount = dailyGoals.filter(g => g.completed).length;
    const totalCount = dailyGoals.length;
    const progress = totalCount > 0 ? completedCount / totalCount : 0;

    return (
      <View style={styles.contentSection}>
        <View style={styles.productivityHeader}>
          <Text style={styles.sectionDescription}>
            Complete your daily goals to stay productive
          </Text>
          <View style={styles.progressContainer}>
            <View style={styles.progressBar}>
              <View
                style={[
                  styles.progressFill,
                  {
                    width: `${progress * 100}%`,
                    backgroundColor: progress === 1 ? '#10B981' : theme.primary,
                  },
                ]}
              />
            </View>
            <Text style={styles.progressText}>
              {completedCount} / {totalCount} completed
            </Text>
          </View>
        </View>

        {dailyGoals.map((goal, index) => (
          <GlassCard
            key={goal.id}
            style={[styles.goalCard, index === dailyGoals.length - 1 && { marginBottom: 0 }]}
            accountType="valeter"
          >
            <LinearGradient
              colors={goal.completed 
                ? ['rgba(16,185,129,0.15)', 'rgba(16,185,129,0.05)']
                : ['rgba(255,255,255,0.05)', 'rgba(255,255,255,0.02)']
              }
              style={StyleSheet.absoluteFill}
            />
            <TouchableOpacity
              style={styles.goalContent}
              onPress={() => toggleGoal(goal.id)}
              activeOpacity={0.7}
            >
              <View style={styles.goalLeft}>
                <View style={[
                  styles.goalIconWrapper,
                  goal.completed && styles.goalIconWrapperCompleted
                ]}>
                  <Ionicons
                    name={goal.completed ? 'checkmark-circle' : goal.icon}
                    size={24}
                    color={goal.completed ? '#10B981' : theme.primary}
                  />
                </View>
                <Text style={[
                  styles.goalTitle,
                  goal.completed && styles.goalTitleCompleted
                ]}>
                  {goal.title}
                </Text>
              </View>
              <View style={[
                styles.checkbox,
                goal.completed && styles.checkboxCompleted
              ]}>
                {goal.completed && (
                  <Ionicons name="checkmark" size={20} color="#FFFFFF" />
                )}
              </View>
            </TouchableOpacity>
          </GlassCard>
        ))}
      </View>
    );
  };

  const renderReminders = () => {
    if (loading && !refreshing) {
      return (
        <View style={styles.contentSection}>
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={theme.primary} />
            <Text style={[styles.loadingText, { color: theme.primary }]}>Loading reminders...</Text>
          </View>
        </View>
      );
    }

    if (reminders.length === 0) {
      return (
        <View style={styles.contentSection}>
          <GlassCard style={styles.emptyCard} accountType={userType === 'customer' ? 'customer' : userType === 'valeter' ? 'valeter' : 'business'}>
            <View style={styles.emptyContainer}>
              <View style={[styles.emptyIconWrapper, { backgroundColor: `${theme.primary}20` }]}>
                <Ionicons name="calendar-outline" size={48} color={theme.primary} />
              </View>
              <Text style={styles.emptyTitle}>No Active Reminders</Text>
              <Text style={styles.emptySubtitle}>
                Add your vehicles and set tax/MOT expiry dates to receive automatic reminders
              </Text>
              <TouchableOpacity 
                style={[styles.addVehicleButton, { backgroundColor: theme.primary }]}
                onPress={() => {
                  if (userType === 'valeter') {
                    router.push('/valeter/profile/valeter-vehicle-info');
                  } else {
                    router.push('/owner/settings/vehicle-management');
                  }
                }}
                activeOpacity={0.8}
              >
                <Text style={styles.addVehicleText}>Manage Vehicles</Text>
              </TouchableOpacity>
            </View>
          </GlassCard>
        </View>
      );
    }

    return (
      <View style={styles.contentSection}>
        <View style={styles.remindersHeader}>
          <Text style={styles.sectionDescription}>
            Active reminders for your vehicles
          </Text>
          {reminders.length > 0 && (
            <TouchableOpacity
              onPress={handleDeleteAllVehicles}
              style={styles.deleteAllVehiclesButton}
            >
              <Ionicons name="trash-outline" size={16} color="#EF4444" />
              <Text style={styles.deleteAllVehiclesText}>Delete All</Text>
            </TouchableOpacity>
          )}
        </View>
        {reminders.map((reminder) => {
          const isUrgent = reminder.daysRemaining < 7;
          const isWarning = reminder.daysRemaining >= 7 && reminder.daysRemaining < 30;
          const color = isUrgent ? '#EF4444' : isWarning ? '#F59E0B' : '#10B981';
          
          return (
            <GlassCard
              key={reminder.id}
              style={styles.reminderCard}
              accountType={userType === 'customer' ? 'customer' : userType === 'valeter' ? 'valeter' : 'business'}
            >
              <LinearGradient
                colors={[`${color}12`, `${color}06`]}
                style={StyleSheet.absoluteFill}
              />
              <View style={styles.reminderContentWrapper}>
                <View style={styles.reminderHeader}>
                <View style={[styles.reminderIconWrapper, { backgroundColor: `${color}25`, borderColor: `${color}40` }]}>
                  <Ionicons 
                    name={reminder.type === 'tax' ? 'card-outline' : 'shield-checkmark-outline'} 
                    size={22} 
                    color={color} 
                  />
                </View>
                <View style={styles.reminderContent}>
                  <Text style={styles.reminderTitle}>
                    {reminder.type === 'tax' ? 'Vehicle Tax' : 'MOT'} Expiry
                  </Text>
                  <Text style={styles.reminderRegistration}>
                    {reminder.vehicleRegistration}
                  </Text>
                </View>
                <View style={styles.reminderHeaderRight}>
                  <View style={[styles.daysBadge, { backgroundColor: `${color}30`, borderColor: `${color}50` }]}>
                    <Text style={[styles.daysText, { color }]}>
                      {reminder.daysRemaining === 0 
                        ? 'Today' 
                        : reminder.daysRemaining === 1 
                        ? '1 day' 
                        : `${reminder.daysRemaining} days`}
                    </Text>
                  </View>
                  <TouchableOpacity
                    onPress={() => handleDeleteVehicle(reminder.vehicleId, reminder.vehicleRegistration)}
                    style={styles.deleteVehicleButton}
                    activeOpacity={0.7}
                  >
                    <Ionicons name="trash-outline" size={18} color="#EF4444" />
                  </TouchableOpacity>
                </View>
              </View>
              <View style={styles.reminderFooter}>
                <Ionicons name="calendar-outline" size={14} color={color} />
                <Text style={[styles.reminderDate, { color }]}>
                  Expires: {reminder.expiryDate.toLocaleDateString('en-GB', { 
                    day: 'numeric', 
                    month: 'short', 
                    year: 'numeric' 
                  })}
                </Text>
              </View>
              </View>
            </GlassCard>
          );
        })}
        <TouchableOpacity 
          style={[styles.addVehicleButton, { backgroundColor: theme.primary }]}
          onPress={() => router.push('/owner/vehicle-management')}
        >
          <Text style={styles.addVehicleText}>Manage Vehicles</Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType={userType === 'customer' ? 'customer' : userType === 'valeter' ? 'valeter' : 'business'} />
      
      <AppHeader
        title="Car Care Info Hub"
        subtitle="Tax & MOT Reminders"
        accountType={userType === 'customer' ? 'customer' : userType === 'valeter' ? 'valeter' : 'business'}
        rightAction={
          onClose ? (
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Ionicons name="close" size={24} color={theme.primary} />
            </TouchableOpacity>
          ) : undefined
        }
        showBack={false}
      />

      <View style={styles.contentWrapper}>
        <View style={[styles.tabsWrapper, { paddingTop: HEADER_CONTENT_OFFSET - 20 }]}>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false} 
            contentContainerStyle={styles.tabsContainer}
          >
            <TouchableOpacity
              style={[
                styles.tab,
                activeTab === 'reminders' && styles.tabActive,
                activeTab === 'reminders' && { 
                  borderColor: theme.primary,
                  backgroundColor: `${theme.primary}25`
                }
              ]}
              onPress={() => setActiveTab('reminders')}
              activeOpacity={0.7}
            >
              <View style={[styles.tabIconWrapper, activeTab === 'reminders' && { backgroundColor: `${theme.primary}20` }]}>
                <Ionicons 
                  name="calendar" 
                  size={16} 
                  color={activeTab === 'reminders' ? theme.primary : 'rgba(255,255,255,0.5)'} 
                />
              </View>
              <Text style={[styles.tabText, activeTab === 'reminders' && { color: theme.primary, fontWeight: '600' }]}>
                Tax & MOT
              </Text>
            </TouchableOpacity>
            {userType === 'customer' && (
              <TouchableOpacity
                style={[
                  styles.tab,
                  activeTab === 'promotions' && styles.tabActive,
                  activeTab === 'promotions' && { 
                    borderColor: theme.primary,
                    backgroundColor: `${theme.primary}25`
                  }
                ]}
                onPress={() => setActiveTab('promotions')}
                activeOpacity={0.7}
              >
                <View style={[styles.tabIconWrapper, activeTab === 'promotions' && { backgroundColor: `${theme.primary}20` }]}>
                <Ionicons 
                  name="pricetag" 
                  size={16} 
                  color={activeTab === 'promotions' ? theme.primary : 'rgba(255,255,255,0.5)'} 
                />
                </View>
                <Text style={[styles.tabText, activeTab === 'promotions' && { color: theme.primary, fontWeight: '600' }]}>
                  Promotions
                </Text>
              </TouchableOpacity>
            )}
            {userType === 'valeter' && (
              <TouchableOpacity
                style={[
                  styles.tab,
                  activeTab === 'productivity' && styles.tabActive,
                  activeTab === 'productivity' && { 
                    borderColor: theme.primary,
                    backgroundColor: `${theme.primary}25`
                  }
                ]}
                onPress={() => setActiveTab('productivity')}
                activeOpacity={0.7}
              >
                <View style={[styles.tabIconWrapper, activeTab === 'productivity' && { backgroundColor: `${theme.primary}20` }]}>
                <Ionicons 
                  name="checkmark-circle" 
                  size={16} 
                  color={activeTab === 'productivity' ? theme.primary : 'rgba(255,255,255,0.5)'} 
                />
                </View>
                <Text style={[styles.tabText, activeTab === 'productivity' && { color: theme.primary, fontWeight: '600' }]}>
                  Productivity
                </Text>
              </TouchableOpacity>
            )}
          </ScrollView>
        </View>

        <ScrollView
          ref={scrollViewRef}
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />}
        >
          {activeTab === 'reminders' && renderReminders()}
          {activeTab === 'promotions' && renderPromotions()}
          {activeTab === 'productivity' && userType === 'valeter' && renderProductivity()}
        </ScrollView>
      </View>

      {/* Celebration Modal */}
      <Modal
        visible={showCelebration}
        transparent
        animationType="fade"
        onRequestClose={() => setShowCelebration(false)}
      >
        <View style={styles.celebrationOverlay}>
          <Animated.View
            style={[
              styles.celebrationContainer,
              {
                opacity: confettiAnim,
                transform: [{ scale: celebrationScale }],
              },
            ]}
          >
            <LinearGradient
              colors={['rgba(16,185,129,0.95)', 'rgba(5,150,105,0.95)']}
              style={styles.celebrationGradient}
            >
              {/* Confetti Effect */}
              <Animated.View
                style={[
                  styles.confettiContainer,
                  {
                    opacity: confettiAnim,
                  },
                ]}
              >
                {[...Array(20)].map((_, i) => (
                  <Animated.View
                    key={i}
                    style={[
                      styles.confettiPiece,
                      {
                        backgroundColor: ['#10B981', '#FBBF24', '#3B82F6', '#EF4444', '#8B5CF6'][i % 5],
                        left: `${(i * 5) % 100}%`,
                        transform: [
                          {
                            translateY: confettiAnim.interpolate({
                              inputRange: [0, 1],
                              outputRange: [-50, height + 100],
                            }),
                          },
                          {
                            rotate: confettiAnim.interpolate({
                              inputRange: [0, 1],
                              outputRange: ['0deg', `${360 * (i % 2 === 0 ? 1 : -1)}deg`],
                            }),
                          },
                        ],
                      },
                    ]}
                  />
                ))}
              </Animated.View>

              <View style={styles.celebrationContent}>
                <View style={styles.celebrationIcon}>
                  <Ionicons name="trophy" size={80} color="#FFFFFF" />
                </View>
                <Text style={styles.celebrationTitle}>
                  Well Done{valeterName ? `, ${valeterName.split(' ')[0]}` : ''}!
                </Text>
                <Text style={styles.celebrationMessage}>
                  You've made the day count, great job!
                </Text>
                <TouchableOpacity
                  style={styles.celebrationButton}
                  onPress={() => {
                    setShowCelebration(false);
                    hapticFeedback('medium');
                  }}
                  activeOpacity={0.8}
                >
                  <Text style={styles.celebrationButtonText}>Awesome!</Text>
                </TouchableOpacity>
              </View>
            </LinearGradient>
          </Animated.View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  contentWrapper: {
    flex: 1,
  },
  closeButton: {
    padding: 8,
  },
  tabsWrapper: {
    paddingHorizontal: 20,
    paddingTop: 4,
    paddingBottom: 16,
  },
  tabsContainer: {
    gap: 12,
    paddingRight: 20,
  },
  tab: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  tabActive: {
    borderWidth: 1.5,
  },
  tabIconWrapper: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
  },
  tabText: {
    color: 'rgba(255,255,255,0.65)',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: STANDARD_SPACING.pagePadding,
    paddingBottom: STANDARD_SPACING.pagePaddingBottom,
  },
  contentSection: {
    gap: STANDARD_SPACING.sectionGap,
  },
  remindersHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  sectionDescription: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
    flex: 1,
    fontWeight: '600',
    letterSpacing: 0.1,
  },
  remindersHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  loadingContainer: {
    paddingVertical: 60,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    fontSize: 15,
    fontWeight: '600',
  },
  emptyCard: {
    padding: 40,
    borderRadius: 24,
  },
  emptyContainer: {
    alignItems: 'center',
    gap: 16,
  },
  emptyIconWrapper: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '600',
    letterSpacing: 0.2,
    marginBottom: 8,
  },
  emptySubtitle: {
    color: 'rgba(255,255,255,0.65)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 20,
  },
  featureCard: {
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
  },
  featureGradient: {
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    position: 'relative',
  },
  featureHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  featureIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  featureContent: {
    flex: 1,
  },
  featureTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  featureDate: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
  },
  featureDescription: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 12,
  },
  comingSoonBadge: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(135,206,235,0.3)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  comingSoonText: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
  addVehicleButton: {
    marginTop: 24,
    paddingHorizontal: 28,
    paddingVertical: 14,
    borderRadius: 16,
    alignSelf: 'center',
  },
  addVehicleText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  reminderCard: {
    marginBottom: STANDARD_SPACING.sectionGap,
    padding: 0,
    overflow: 'hidden',
  },
  reminderContentWrapper: {
    padding: STANDARD_SPACING.cardPaddingMedium,
  },
  reminderHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    marginBottom: 14,
  },
  reminderIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
  },
  reminderContent: {
    flex: 1,
    paddingTop: 2,
  },
  reminderHeaderRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  deleteVehicleButton: {
    padding: 8,
    borderRadius: 12,
    backgroundColor: 'rgba(239,68,68,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
  },
  reminderTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    letterSpacing: 0.2,
    marginBottom: 6,
    lineHeight: 24,
  },
  reminderRegistration: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  daysBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    borderWidth: 1.5,
  },
  daysText: {
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  deleteAllVehiclesButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: 'rgba(239,68,68,0.15)',
    borderRadius: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(239,68,68,0.4)',
  },
  deleteAllVehiclesText: {
    color: '#EF4444',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  reminderFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingTop: 12,
    borderTopWidth: 1.5,
    borderTopColor: 'rgba(255,255,255,0.12)',
    marginTop: 4,
  },
  reminderDate: {
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  promotionCard: {
    marginBottom: STANDARD_SPACING.sectionGap,
    padding: 0,
    overflow: 'hidden',
  },
  promotionContentWrapper: {
    padding: STANDARD_SPACING.cardPaddingMedium,
  },
  promotionHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 14,
    marginBottom: 14,
  },
  promotionIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
  },
  promotionContent: {
    flex: 1,
    paddingTop: 2,
  },
  promotionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    letterSpacing: 0.2,
    marginBottom: 8,
    lineHeight: 24,
  },
  promotionDescription: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 15,
    lineHeight: 22,
    marginBottom: 10,
  },
  promoCodeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 8,
  },
  promoCodeLabel: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    fontWeight: '600',
  },
  promoCode: {
    fontSize: 14,
    fontWeight: '700',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    fontFamily: 'monospace',
    borderWidth: 1,
  },
  promotionBenefits: {
    marginTop: 8,
    gap: 6,
  },
  benefitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  benefitText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
  },
  promotionFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingTop: 14,
    borderTopWidth: 1.5,
    borderTopColor: 'rgba(255,255,255,0.12)',
    marginTop: 4,
  },
  promotionPricing: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  promotionPrice: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  promotionSavings: {
    color: '#10B981',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  promotionDiscount: {
    flex: 1,
  },
  promotionDiscountText: {
    fontSize: 20,
    fontWeight: '600',
    marginBottom: 6,
    letterSpacing: 0.2,
  },
  promotionTimer: {
    color: 'rgba(255,255,255,0.65)',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  redeemButton: {
    paddingHorizontal: 22,
    paddingVertical: 12,
    borderRadius: 16,
    borderWidth: 1.5,
  },
  redeemButtonText: {
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  productivityHeader: {
    marginBottom: 20,
  },
  progressContainer: {
    marginTop: 12,
    gap: 8,
  },
  progressBar: {
    height: 8,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    borderRadius: 4,
  },
  progressText: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  goalCard: {
    marginBottom: 12,
    padding: 16,
  },
  goalContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  goalLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    flex: 1,
  },
  goalIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  goalIconWrapperCompleted: {
    backgroundColor: 'rgba(16,185,129,0.2)',
  },
  goalTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    flex: 1,
  },
  goalTitleCompleted: {
    color: '#10B981',
    textDecorationLine: 'line-through',
    opacity: 0.7,
  },
  checkbox: {
    width: 32,
    height: 32,
    borderRadius: 8,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  checkboxCompleted: {
    backgroundColor: '#10B981',
    borderColor: '#10B981',
  },
  celebrationOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.7)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  celebrationContainer: {
    width: '100%',
    maxWidth: 400,
    borderRadius: 24,
    overflow: 'hidden',
  },
  celebrationGradient: {
    padding: 32,
    alignItems: 'center',
  },
  confettiContainer: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
  },
  confettiPiece: {
    position: 'absolute',
    width: 12,
    height: 12,
    borderRadius: 2,
  },
  celebrationContent: {
    alignItems: 'center',
    zIndex: 10,
  },
  celebrationIcon: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  celebrationTitle: {
    color: '#FFFFFF',
    fontSize: 32,
    fontWeight: 'bold',
    marginBottom: 12,
    textAlign: 'center',
  },
  celebrationMessage: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 32,
    lineHeight: 26,
  },
  celebrationButton: {
    backgroundColor: '#FFFFFF',
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 16,
    minWidth: 150,
  },
  celebrationButtonText: {
    color: '#10B981',
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});

