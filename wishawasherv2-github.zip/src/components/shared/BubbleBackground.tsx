import React, { useEffect, useRef, useMemo } from 'react';
import { View, StyleSheet, Animated, Dimensions } from 'react-native';
import { AccountType, getAccountTheme } from '../../constants/accountThemes';
import { colors } from '../../constants/colors';

const { width, height } = Dimensions.get('window');

interface BubbleBackgroundProps {
  accountType?: AccountType;
  bubbleCount?: number;
}

interface Bubble {
  translateY: Animated.Value;
  translateX: Animated.Value;
  opacity: Animated.Value;
  scale: Animated.Value;
  size: number;
  leftPosition: number;
  duration: number;
  delay: number;
}

export default function BubbleBackground({ 
  accountType = 'customer',
  bubbleCount = 3 
}: BubbleBackgroundProps) {
  const bubbleColor = useMemo(() => {
    const theme = getAccountTheme(accountType);
    if (accountType === 'business') {
      return theme.primary || '#84CC16';
    } else if (accountType === 'customer') {
      return colors.SKY || '#87CEEB';
    } else {
      return colors.SKY || '#87CEEB';
    }
  }, [accountType]);
  
  const bubbles = useRef<Bubble[]>(
    Array.from({ length: bubbleCount }, (_, i) => ({
      translateY: new Animated.Value(0),
      translateX: new Animated.Value(0),
      opacity: new Animated.Value(0.08 + Math.random() * 0.12),
      scale: new Animated.Value(1),
      size: 25 + Math.random() * 25,
      leftPosition: Math.random() * width,
      duration: 12000 + Math.random() * 8000, // 12-20 seconds (slower = less CPU)
      delay: i * 1500,
    }))
  ).current;

  useEffect(() => {
    const animationRefs: Animated.CompositeAnimation[] = [];
    const timeoutRefs: NodeJS.Timeout[] = [];

    bubbles.forEach((bubble) => {
      const animateBubble = () => {
        // Simplified: Only vertical floating animation for better performance
        const verticalAnim = Animated.loop(
          Animated.sequence([
            Animated.timing(bubble.translateY, {
              toValue: -height * 0.2 - bubble.size,
              duration: bubble.duration,
              useNativeDriver: true,
            }),
            Animated.timing(bubble.translateY, {
              toValue: 0,
              duration: 0,
              useNativeDriver: true,
            }),
          ])
        );

        // Light opacity variation only
        const opacityAnim = Animated.loop(
          Animated.sequence([
            Animated.timing(bubble.opacity, {
              toValue: 0.2,
              duration: bubble.duration * 0.8,
              useNativeDriver: true,
            }),
            Animated.timing(bubble.opacity, {
              toValue: 0.05,
              duration: bubble.duration * 0.8,
              useNativeDriver: true,
            }),
          ])
        );

        const animation = Animated.parallel([
          verticalAnim,
          opacityAnim,
        ]);
        
        animation.start();
        animationRefs.push(animation);
      };

      const timeout = setTimeout(() => {
        animateBubble();
      }, bubble.delay);
      
      timeoutRefs.push(timeout);
    });

    return () => {
      // Cleanup all animations
      animationRefs.forEach(anim => anim.stop());
      timeoutRefs.forEach(timeout => clearTimeout(timeout));
    };
  }, []);

  return (
    <View style={styles.container} pointerEvents="none">
      {bubbles.map((bubble, index) => {
        const bubbleStyle = {
          position: 'absolute' as const,
          left: bubble.leftPosition,
          bottom: -bubble.size,
          width: bubble.size,
          height: bubble.size,
          borderRadius: bubble.size / 2,
          backgroundColor: bubbleColor,
          transform: [
            { translateY: bubble.translateY },
          ],
          opacity: bubble.opacity,
        };

        return <Animated.View key={index} style={bubbleStyle} />;
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    zIndex: 0,
    overflow: 'hidden',
  },
});


