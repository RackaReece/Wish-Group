import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Modal,
  FlatList,
  ActivityIndicator,
  Animated,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../providers/enhanced-auth-context';
import { supabase } from '../../lib/supabase';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import GlassCard from '../booking/GlassCard';
import { getAccountTheme } from '../../constants/accountThemes';

const { width } = Dimensions.get('window');
const businessTheme = getAccountTheme('business');

type NotificationType = 'booking' | 'team_request' | 'team_update' | 'booking_update';
type NotificationPriority = 'low' | 'medium' | 'high';

interface NotificationItem {
  id: string;
  type: NotificationType;
  title: string;
  message: string;
  time: string;
  priority: NotificationPriority;
  route?: string;
  bookingId?: string;
  requestId?: string;
  createdAt: string; // For sorting
}

interface BusinessNotificationDropdownProps {
  visible: boolean;
  onClose: () => void;
  organizationId: string | null;
}

export default function BusinessNotificationDropdown({
  visible,
  onClose,
  organizationId,
}: BusinessNotificationDropdownProps) {
  const [notifications, setNotifications] = useState<NotificationItem[]>([]);
  const [loading, setLoading] = useState(true);
  const slideAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible && organizationId) {
      fetchNotifications();
      Animated.spring(slideAnim, {
        toValue: 1,
        useNativeDriver: true,
        tension: 50,
        friction: 7,
      }).start();
    } else {
      slideAnim.setValue(0);
    }
  }, [visible, organizationId]);

  const getPriority = (type: NotificationType, status?: string): NotificationPriority => {
    // High priority: urgent booking updates, critical team issues
    if (type === 'booking_update' && (status === 'cancelled' || status === 'in_progress')) {
      return 'high';
    }
    if (type === 'team_request') {
      return 'high';
    }

    // Medium priority: new bookings, confirmed bookings, team status changes
    if (type === 'booking' && (status === 'pending_business_acceptance' || status === 'confirmed')) {
      return 'medium';
    }
    if (type === 'team_update') {
      return 'medium';
    }

    // Low priority: completed bookings, general updates
    return 'low';
  };

  const formatTime = (dateString: string) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins}m ago`;
    if (diffHours < 24) return `${diffHours}h ago`;
    if (diffDays < 7) return `${diffDays}d ago`;
    return date.toLocaleDateString();
  };

  const fetchNotifications = async () => {
    if (!organizationId) return;

    try {
      setLoading(true);

      // Get valeters for the organization
      const { data: valeters, error: valetersError } = await supabase
        .from('profiles')
        .select('id, full_name, name, is_online, updated_at')
        .eq('organization_id', organizationId)
        .eq('user_type', 'valeter');

      if (valetersError) {
        console.error('Error fetching valeters:', valetersError);
      }

      const notificationItems: NotificationItem[] = [];

      // Fetch bookings by valeter_id
      const valeterIds = (valeters || []).map((v: any) => v.id);
      if (valeterIds.length > 0) {
      const { data: bookings, error: bookingsError } = await supabase
        .from('bookings')
        .select('id, status, service_name, created_at, updated_at')
        .in('valeter_id', valeterIds)
        .in('status', [
          'pending',
          'pending_valeter_acceptance',
          'pending_payment',
          'confirmed',
          'in_progress',
          'completed',
          'cancelled',
          'valeter_assigned',
        ])
        .order('updated_at', { ascending: false })
        .limit(20);

      if (bookingsError) {
        console.error('Error fetching bookings:', bookingsError);
      }

        if (bookings) {
          bookings.forEach((booking: any) => {
            const isNew = new Date(booking.created_at).getTime() === new Date(booking.updated_at).getTime();
            const type: NotificationType = isNew ? 'booking' : 'booking_update';
            
            let title = 'New Booking';
            let message = '';
            
            if (type === 'booking_update') {
              switch (booking.status) {
                case 'confirmed':
                  title = 'Booking Confirmed';
                  message = 'A booking has been confirmed';
                  break;
                case 'in_progress':
                  title = 'Booking In Progress';
                  message = 'A service is now in progress';
                  break;
                case 'completed':
                  title = 'Booking Completed';
                  message = 'A booking has been completed';
                  break;
                case 'cancelled':
                  title = 'Booking Cancelled';
                  message = 'A booking has been cancelled';
                  break;
                default:
                  title = 'Booking Updated';
                  message = 'A booking has been updated';
              }
            } else {
              message = booking.service_name || 'New booking received';
            }

            notificationItems.push({
              id: `booking-${booking.id}-${booking.updated_at}`,
              type,
              title,
              message,
              time: formatTime(booking.updated_at || booking.created_at),
              priority: getPriority(type, booking.status),
              route: `/business/bookings/${booking.id}`,
              bookingId: booking.id,
              createdAt: booking.updated_at || booking.created_at,
            });
          });
        }
      }

      // Fetch team requests (high priority)
      const { data: teamRequests } = await supabase
        .from('team_requests')
        .select('id, valeter_name, valeter_email, created_at, status')
        .eq('organization_id', organizationId)
        .eq('status', 'pending')
        .order('created_at', { ascending: false })
        .limit(10);

      if (teamRequests) {
        teamRequests.forEach((request: any) => {
          notificationItems.push({
            id: `request-${request.id}`,
            type: 'team_request',
            title: 'Team Request',
            message: request.valeter_name
              ? `${request.valeter_name} wants to join your team`
              : request.valeter_email || 'New team request',
            time: formatTime(request.created_at),
            priority: 'high',
            route: '/business/team/requests',
            requestId: request.id,
            createdAt: request.created_at,
          });
        });
      }

      // Fetch team member updates (online/offline status changes)
      if (valeters && valeters.length > 0) {
        valeters.forEach((valeter: any) => {
          const updatedAt = valeter.updated_at;
          if (updatedAt) {
            const updateTime = new Date(updatedAt).getTime();
            const now = Date.now();
            const fiveMinutesAgo = now - 5 * 60 * 1000;
            
            // Only show recent status changes (within last 5 minutes)
            if (updateTime > fiveMinutesAgo) {
              const status = valeter.is_online ? 'online' : 'offline';
              notificationItems.push({
                id: `team-update-${valeter.id}-${updatedAt}`,
                type: 'team_update',
                title: 'Team Member Update',
                message: `${valeter.full_name || valeter.name || 'A valeter'} is now ${status}`,
                time: formatTime(updatedAt),
                priority: 'medium',
                route: '/business/team',
                createdAt: updatedAt,
              });
            }
          }
        });
      }

      // Sort by priority (high -> medium -> low), then by time (newest first)
      const priorityOrder: Record<NotificationPriority, number> = {
        high: 3,
        medium: 2,
        low: 1,
      };

      notificationItems.sort((a, b) => {
        const priorityDiff = priorityOrder[b.priority] - priorityOrder[a.priority];
        if (priorityDiff !== 0) return priorityDiff;
        
        const timeA = new Date(a.createdAt).getTime();
        const timeB = new Date(b.createdAt).getTime();
        return timeB - timeA;
      });

      console.log('[NotificationDropdown] Fetched notifications:', {
        valeterIds: valeterIds.length,
        bookingsCount: bookings?.length || 0,
        teamRequestsCount: teamRequests?.length || 0,
        totalItems: notificationItems.length,
        finalCount: notificationItems.slice(0, 15).length,
      });

      setNotifications(notificationItems.slice(0, 15));
    } catch (error) {
      console.error('Error fetching notifications:', error);
      setNotifications([]);
    } finally {
      setLoading(false);
    }
  };

  const handleNotificationPress = async (item: NotificationItem) => {
    await hapticFeedback('light');
    onClose();
    
    // If it's an active (in_progress) booking notification, go to trips/bookings page
    if (item.type === 'booking_update' && item.bookingId) {
      // Check if the booking is in_progress by checking the notification message/title
      const isActive = item.title === 'Booking In Progress' || item.message.toLowerCase().includes('in progress');
      if (isActive) {
        router.push('/business/bookings?filter=in_progress' as any);
        return;
      }
    }
    
    if (item.route) {
      router.push(item.route as any);
    }
  };

  const getNotificationIcon = (type: NotificationType): { name: keyof typeof Ionicons.glyphMap; color: string } => {
    switch (type) {
      case 'booking':
        return { name: 'calendar-outline', color: businessTheme.primary };
      case 'booking_update':
        return { name: 'refresh-circle', color: '#3B82F6' };
      case 'team_request':
        return { name: 'person-add', color: '#10B981' };
      case 'team_update':
        return { name: 'people', color: '#8B5CF6' };
      default:
        return { name: 'notifications', color: businessTheme.primary };
    }
  };

  const getPriorityColor = (priority: NotificationPriority): string => {
    switch (priority) {
      case 'high':
        return '#EF4444';
      case 'medium':
        return '#FBBF24';
      case 'low':
        return '#10B981';
      default:
        return businessTheme.primary;
    }
  };

  const renderNotification = ({ item }: { item: NotificationItem }) => {
    const icon = getNotificationIcon(item.type);
    const priorityColor = getPriorityColor(item.priority);

    return (
      <TouchableOpacity
        onPress={() => handleNotificationPress(item)}
        activeOpacity={0.7}
      >
        <GlassCard style={styles.notificationCard} accountType="business">
          <View style={styles.notificationContent}>
            <View style={[styles.iconWrapper, { backgroundColor: `${icon.color}20` }]}>
              <Ionicons name={icon.name} size={20} color={icon.color} />
            </View>
            <View style={styles.notificationText}>
              <View style={styles.notificationHeader}>
                <Text style={styles.notificationTitle}>{item.title}</Text>
                <View style={[styles.priorityBadge, { backgroundColor: `${priorityColor}20`, borderColor: `${priorityColor}40` }]}>
                  <View style={[styles.priorityDot, { backgroundColor: priorityColor }]} />
                  <Text style={[styles.priorityText, { color: priorityColor }]}>
                    {item.priority.toUpperCase()}
                  </Text>
                </View>
              </View>
              <Text style={styles.notificationMessage} numberOfLines={2}>
                {item.message}
              </Text>
              <Text style={styles.notificationTime}>{item.time}</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color="rgba(249,250,251,0.5)" />
          </View>
        </GlassCard>
      </TouchableOpacity>
    );
  };

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
    >
      <TouchableOpacity
        style={styles.overlay}
        activeOpacity={1}
        onPress={onClose}
      >
        <Animated.View
          style={[
            styles.dropdown,
            {
              transform: [
                {
                  translateY: slideAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [-20, 0],
                  }),
                },
              ],
              opacity: slideAnim,
            },
          ]}
        >
          <TouchableOpacity activeOpacity={1} onPress={(e) => e.stopPropagation()}>
            <GlassCard style={styles.dropdownCard} accountType="business">
              <View style={styles.dropdownHeader}>
                <Text style={styles.dropdownTitle}>Notifications</Text>
                <TouchableOpacity onPress={onClose} style={styles.closeButton}>
                  <Ionicons name="close" size={20} color="#F9FAFB" />
                </TouchableOpacity>
              </View>

              {loading ? (
                <View style={styles.loadingContainer}>
                  <ActivityIndicator size="small" color={businessTheme.primary} />
                  <Text style={styles.loadingText}>Loading...</Text>
                </View>
              ) : notifications.length === 0 ? (
                <View style={styles.emptyContainer}>
                  <Ionicons name="notifications-off-outline" size={48} color="rgba(249,250,251,0.4)" />
                  <Text style={styles.emptyText}>No notifications</Text>
                  <Text style={styles.emptySubtext}>You're all caught up!</Text>
                </View>
              ) : (
                <FlatList
                  data={notifications}
                  renderItem={renderNotification}
                  keyExtractor={(item) => item.id}
                  style={styles.list}
                  contentContainerStyle={styles.listContent}
                  showsVerticalScrollIndicator={false}
                />
              )}

              {notifications.length > 0 && (
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    onClose();
                    router.push('/business/notifications' as any);
                  }}
                  style={styles.viewAllButton}
                >
                  <Text style={styles.viewAllText}>View All</Text>
                  <Ionicons name="arrow-forward" size={16} color={businessTheme.primary} />
                </TouchableOpacity>
              )}
            </GlassCard>
          </TouchableOpacity>
        </Animated.View>
      </TouchableOpacity>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-start',
    alignItems: 'flex-end',
    paddingTop: 100,
    paddingRight: 20,
  },
  dropdown: {
    width: Math.min(width - 40, 380),
    maxHeight: 500,
  },
  dropdownCard: {
    padding: 0,
    borderRadius: 24,
    overflow: 'hidden',
  },
  dropdownHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(96,217,255,0.15)',
  },
  dropdownTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: 0.3,
  },
  closeButton: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(249,250,251,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
  },
  emptyContainer: {
    padding: 40,
    alignItems: 'center',
    gap: 12,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  emptySubtext: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 13,
  },
  list: {
    maxHeight: 350,
  },
  listContent: {
    padding: 12,
    gap: 8,
  },
  notificationCard: {
    padding: 0,
    marginBottom: 8,
  },
  notificationContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    gap: 12,
  },
  iconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  notificationText: {
    flex: 1,
    gap: 4,
  },
  notificationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
    marginBottom: 4,
  },
  notificationTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '800',
    flex: 1,
  },
  priorityBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 8,
    borderWidth: 1,
  },
  priorityDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  priorityText: {
    fontSize: 9,
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  notificationMessage: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 13,
    lineHeight: 18,
  },
  notificationTime: {
    color: 'rgba(249,250,251,0.5)',
    fontSize: 11,
    fontWeight: '600',
    marginTop: 2,
  },
  viewAllButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(96,217,255,0.15)',
  },
  viewAllText: {
    color: businessTheme.primary,
    fontSize: 14,
    fontWeight: '800',
  },
});
