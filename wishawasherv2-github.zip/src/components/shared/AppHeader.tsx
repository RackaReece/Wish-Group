import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Platform,
  Dimensions,
  Image,
  Animated,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { colors } from '../../constants/colors';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { AccountType, getAccountTheme } from '../../constants/accountThemes';
import { useAccountTheme } from './AccountThemeProvider';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const HEADER_MARGIN_H = 20;
const HEADER_RADIUS = 24;

// Header content heights (not including safe area or padding)
export const HEADER_CONTENT_HEIGHT = 64;
export const DASHBOARD_HEADER_CONTENT_HEIGHT = 88;
// Total header heights including padding (for calculating page padding)
// Formula: top padding (12/16) + content height + bottom padding (16/20)
export const HEADER_HEIGHT = 12 + HEADER_CONTENT_HEIGHT + 16; // = 92
export const DASHBOARD_HEADER_HEIGHT = 16 + DASHBOARD_HEADER_CONTENT_HEIGHT + 20; // = 124

// Standard spacing to position content directly beneath the header.
// Account for floating header: safe area + margin (8) + header height + spacing (40)
export const HEADER_CONTENT_OFFSET = HEADER_HEIGHT + 40; // Safe area + 8 margin + header + 40 spacing
export const DASHBOARD_HEADER_CONTENT_OFFSET = DASHBOARD_HEADER_HEIGHT + 40; // Safe area + 8 margin + header + 40 spacing

interface AppHeaderProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  rightAction?: React.ReactNode;
  variant?: 'default' | 'dashboard';
  accountType?: AccountType;
  showBack?: boolean;
  points?: number;
  businessName?: string;
  businessAddress?: string;
  businessRating?: number;
  showOnlineStatus?: boolean;
  onlineStatusAnim?: Animated.Value;
  profilePicture?: string | null;
  notificationCount?: number;
  onNotificationPress?: () => void;
  todayRevenue?: number;
  todayJobs?: number;
  lastJob?: string | null;
  isOnline?: boolean;
  AnimatedCounter?: React.ComponentType<{ value: number; style?: any }>;
}

export default function AppHeader({
  title,
  subtitle,
  onBack,
  rightAction,
  variant = 'default',
  accountType,
  showBack = true,
  points,
  businessName,
  businessAddress,
  businessRating,
  showOnlineStatus = false,
  onlineStatusAnim,
  profilePicture,
  notificationCount,
  onNotificationPress,
  todayRevenue,
  todayJobs,
  lastJob,
  isOnline,
  AnimatedCounter,
}: AppHeaderProps) {
  const insets = useSafeAreaInsets();
  
  const contextTheme = useAccountTheme();
  const theme = accountType 
    ? getAccountTheme(accountType)
    : contextTheme.theme;

  // Get header background colors (matching nav tab logic)
  const headerBackground = theme.headerBackground || theme.background || ['rgba(96,217,255,0.65)', 'rgba(59,197,232,0.55)'];
  const accent = theme.primary || colors.navActive;

  const handleBack = async () => {
    await hapticFeedback('light');
    if (onBack) {
      onBack();
    } else {
      router.back();
    }
  };

  const isDashboard = variant === 'dashboard';
  const headerContentHeight = isDashboard ? DASHBOARD_HEADER_CONTENT_HEIGHT : HEADER_CONTENT_HEIGHT;

  const headerWidth = width - HEADER_MARGIN_H * 2;
  // Dashboard variant gets more rounded corners and is full width (not floating)
  const borderRadius = isDashboard ? 28 : HEADER_RADIUS;
  const finalWidth = isDashboard ? width : headerWidth;
  const finalMarginTop = isDashboard ? insets.top : insets.top + 8;
  const finalMarginHorizontal = isDashboard ? 0 : HEADER_MARGIN_H;

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <View style={[styles.wrapper, { marginHorizontal: finalMarginHorizontal }]}>
        <View
          style={[
            styles.container,
            { 
              width: finalWidth,
              borderRadius: borderRadius,
              marginTop: finalMarginTop,
              marginHorizontal: finalMarginHorizontal,
            },
          ]}
        >
          <BlurView
            intensity={Platform.OS === 'ios' ? (isDashboard ? 50 : 25) : (isDashboard ? 40 : 20)}
            tint="dark"
            style={StyleSheet.absoluteFill}
          >
            {/* Use same header background gradient as nav tab */}
            <LinearGradient
              colors={
                isDashboard
                  ? [
                      headerBackground[0].includes('rgba')
                        ? headerBackground[0]
                        : `${headerBackground[0]}66`,
                      (headerBackground[1] || headerBackground[0]).includes('rgba')
                        ? (headerBackground[1] || headerBackground[0])
                        : `${headerBackground[1] || headerBackground[0]}40`
                    ]
                  : [`${headerBackground[0]}FF`, `${headerBackground[1] || headerBackground[0]}EE`]
              }
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
            {/* Primary color overlay (matching nav tab) */}
            <View style={StyleSheet.absoluteFill} pointerEvents="none">
              <LinearGradient
                colors={[`${accent}${isDashboard ? '15' : '30'}`, 'transparent']}
                start={{ x: 0, y: 0 }}
                end={{ x: 0, y: 1 }}
                style={StyleSheet.absoluteFill}
              />
            </View>
          </BlurView>

          {/* Glass stroke with theme border (matching nav tab) */}
          <View style={[styles.glassStroke, { 
            borderColor: theme.glassBorder || 'rgba(255,255,255,0.14)',
            borderRadius: borderRadius,
          }]} />

          {/* Glow line at top (matching nav tab) */}
          <View style={[styles.glowLine, { 
            backgroundColor: `${accent}70`,
            shadowColor: accent,
          }]} />

          <View style={[styles.content, { 
            paddingTop: isDashboard ? 16 : 12,
            minHeight: headerContentHeight,
            paddingBottom: isDashboard ? 18 : 16,
          }]}>
            <View style={styles.leftSection}>
            {showBack && (
              <TouchableOpacity
                onPress={handleBack}
                style={styles.backButton}
                activeOpacity={0.7}
              >
                <Ionicons name="chevron-back" size={isDashboard ? 20 : 22} color={theme.primary} />
              </TouchableOpacity>
            )}
            <View style={styles.titleContainer}>
              {isDashboard && businessName ? (
                <>
                  <Text 
                    style={[
                      styles.title,
                      styles.titleDashboard,
                      { color: '#FFFFFF' }
                    ]} 
                    numberOfLines={1} 
                    ellipsizeMode="tail"
                  >
                    {businessName}
                  </Text>
                  {businessAddress && (
                    <View style={styles.businessInfoRow}>
                      <Ionicons name="location" size={12} color={theme.primary} style={{ marginRight: 4 }} />
                      <Text 
                        style={[styles.businessAddress, { color: theme.primary }]} 
                        numberOfLines={1} 
                        ellipsizeMode="tail"
                      >
                        {businessAddress}
                      </Text>
                    </View>
                  )}
                  {businessRating !== undefined && businessRating > 0 && (
                    <View style={styles.businessInfoRow}>
                      <Ionicons name="star" size={12} color="#FFD700" style={{ marginRight: 4 }} />
                      <Text 
                        style={[styles.businessRating, { color: '#FFD700' }]} 
                        numberOfLines={1}
                      >
                        {businessRating.toFixed(1)}
                      </Text>
                    </View>
                  )}
                  {/* Stats Row */}
                  {(todayRevenue !== undefined || todayJobs !== undefined || businessRating !== undefined) && (
                    <View style={styles.statsRow}>
                      {todayRevenue !== undefined && (
                        <>
                          <View style={styles.statItem}>
                            <Text style={styles.statText}>Today: £</Text>
                            {AnimatedCounter ? (
                              <AnimatedCounter value={todayRevenue} style={styles.statValue} />
                            ) : (
                              <Text style={styles.statValue}>{todayRevenue.toFixed(0)}</Text>
                            )}
                          </View>
                          <Text style={styles.statSeparator}>•</Text>
                        </>
                      )}
                      {todayJobs !== undefined && (
                        <>
                          <View style={styles.statItem}>
                            {AnimatedCounter ? (
                              <AnimatedCounter value={todayJobs} style={styles.statValue} />
                            ) : (
                              <Text style={styles.statValue}>{todayJobs}</Text>
                            )}
                            <Text style={styles.statText}> jobs</Text>
                          </View>
                          {businessRating !== undefined && businessRating > 0 && <Text style={styles.statSeparator}>•</Text>}
                        </>
                      )}
                      {businessRating !== undefined && businessRating > 0 && (
                        <View style={styles.statWithIcon}>
                          <Ionicons name="star" size={12} color="#FBBF24" />
                          <Text style={styles.statText}>
                            {businessRating.toFixed(1)}
                          </Text>
                        </View>
                      )}
                    </View>
                  )}
                  {/* Last Job */}
                  {lastJob && (
                    <Text style={styles.lastJobText}>
                      Last job: {lastJob}
                    </Text>
                  )}
                  {/* Online Status */}
                  {isOnline !== undefined && (
                    <View style={[styles.statusBadge, isOnline && styles.statusBadgeOnline]}>
                      {onlineStatusAnim && (
                        <Animated.View 
                          style={[
                            styles.statusDot,
                            {
                              transform: [{ scale: onlineStatusAnim }],
                              opacity: onlineStatusAnim.interpolate({
                                inputRange: [1, 1.3],
                                outputRange: [1, 0.4],
                              }),
                            },
                          ]}
                        />
                      )}
                      <Text style={styles.statusText}>{isOnline ? 'Open for bookings' : 'Offline'}</Text>
                    </View>
                  )}
                </>
              ) : (
                <>
                  <Text 
                    style={[
                      styles.title,
                      isDashboard && styles.titleDashboard,
                      { color: '#FFFFFF' }
                    ]} 
                    numberOfLines={1} 
                    ellipsizeMode="tail"
                  >
                    {title || ' '}
                  </Text>
                  {subtitle && (
                    <Text 
                      style={[styles.subtitle, { color: theme.primary }]} 
                      numberOfLines={1} 
                      ellipsizeMode="tail"
                    >
                      {subtitle}
                    </Text>
                  )}
                </>
              )}
            </View>
            </View>

            <View style={styles.rightSection}>
            {isDashboard && points !== undefined && (
              <View style={styles.pointsBadge}>
                <Ionicons name="trophy" size={14} color="#FFD700" />
                <Text style={styles.pointsText}>{points} pts</Text>
              </View>
            )}
            {isDashboard && profilePicture ? (
              <TouchableOpacity
                onPress={onNotificationPress || handleBack}
                activeOpacity={0.8}
                style={styles.profilePictureWrapper}
              >
                <View style={styles.profilePictureContainer}>
                  <LinearGradient
                    colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.1)']}
                    style={styles.profileGradient}
                  />
                  <Image 
                    source={{ uri: profilePicture }} 
                    style={styles.profilePicture}
                    resizeMode="cover"
                  />
                  <View style={styles.profilePictureBorder} />
                </View>
              </TouchableOpacity>
            ) : !isDashboard && profilePicture ? (
              <TouchableOpacity
                onPress={onNotificationPress || handleBack}
                activeOpacity={0.8}
                style={styles.profilePictureWrapper}
              >
                <View style={styles.profilePictureContainer}>
                  <LinearGradient
                    colors={['rgba(255,255,255,0.2)', 'rgba(255,255,255,0.1)']}
                    style={styles.profileGradient}
                  />
                  <Image 
                    source={{ uri: profilePicture }} 
                    style={styles.profilePicture}
                    resizeMode="cover"
                  />
                  <View style={styles.profilePictureBorder} />
                  {notificationCount !== undefined && notificationCount > 0 && (
                    <View style={styles.headerBellBadge}>
                      <Text style={styles.headerBellBadgeText}>
                        {notificationCount > 99 ? '99+' : notificationCount}
                      </Text>
                    </View>
                  )}
                </View>
              </TouchableOpacity>
            ) : null}
            {rightAction && (
              <View style={styles.rightActionContainer}>
                {rightAction}
              </View>
            )}
            </View>
          </View>
        </View>
      </View>
    </>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    alignItems: 'center',
    pointerEvents: 'box-none',
  },
  container: {
    overflow: 'hidden',
    backgroundColor: 'transparent',
    marginHorizontal: HEADER_MARGIN_H,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 28,
  },
  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
  },
  glowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 8,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 16,
    zIndex: 200,
    elevation: 12,
    position: 'relative',
  },
  leftSection: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    minWidth: 0,
    zIndex: 200,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    flexShrink: 0,
  },
  titleContainer: {
    flex: 1,
    gap: 2,
    minWidth: 0,
    justifyContent: 'center',
  },
  title: {
    fontSize: 20,
    fontWeight: '600',
    letterSpacing: 0.3,
    textShadowColor: 'rgba(0, 0, 0, 0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
    includeFontPadding: false,
    lineHeight: 24,
  },
  titleDashboard: {
    fontSize: isSmallScreen ? 20 : 22,
    lineHeight: isSmallScreen ? 24 : 26,
    fontWeight: '600',
    marginBottom: 4,
    letterSpacing: -0.3,
  },
  subtitle: {
    fontSize: 13,
    fontWeight: '600',
    opacity: 0.9,
    marginTop: 1,
    textShadowColor: 'rgba(0, 0, 0, 0.3)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
    includeFontPadding: false,
  },
  rightSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginLeft: 12,
    zIndex: 200,
    elevation: 12,
  },
  pointsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255, 215, 0, 0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 215, 0, 0.3)',
  },
  pointsText: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.2,
  },
  businessInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 4,
  },
  businessAddress: {
    fontSize: 12,
    fontWeight: '500',
    opacity: 0.9,
    flex: 1,
  },
  businessRating: {
    fontSize: 12,
    fontWeight: '600',
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 6,
    gap: 6,
    flexWrap: 'wrap',
  },
  statItem: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statText: {
    fontSize: 12,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.9)',
  },
  statValue: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FFFFFF',
  },
  statSeparator: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.5)',
    marginHorizontal: 2,
  },
  statWithIcon: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  lastJobText: {
    fontSize: 11,
    fontWeight: '500',
    color: 'rgba(255,255,255,0.7)',
    marginTop: 4,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 6,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(107,114,128,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(107,114,128,0.3)',
    alignSelf: 'flex-start',
  },
  statusBadgeOnline: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderColor: 'rgba(16,185,129,0.3)',
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  statusText: {
    fontSize: 11,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.9)',
  },
  onlineStatusContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
    position: 'relative',
    overflow: 'visible',
    marginRight: 8,
  },
  onlineStatusDot: {
    position: 'absolute',
    left: 6,
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 4,
  },
  onlineStatusIcon: {
    marginLeft: 2,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 3,
  },
  profilePictureWrapper: {
    position: 'relative',
    borderRadius: 20,
    overflow: 'visible',
  },
  profilePictureContainer: {
    width: 40,
    height: 40,
    borderRadius: 20,
    overflow: 'hidden',
    position: 'relative',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 5,
  },
  profileGradient: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    opacity: 0.3,
  },
  profilePicture: {
    width: '100%',
    height: '100%',
    borderRadius: 20,
  },
  profilePictureBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.25)',
    pointerEvents: 'none',
  },
  headerBellBadge: {
    position: 'absolute',
    top: -2,
    right: -2,
    minWidth: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: '#EF4444',
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 4,
    borderWidth: 2,
    borderColor: 'rgba(0,0,0,0.3)',
    zIndex: 10,
    shadowColor: '#EF4444',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.6,
    shadowRadius: 3,
    elevation: 6,
  },
  headerBellBadgeText: {
    color: '#FFF',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.2,
  },
  rightActionContainer: {
    // Spacing handled by rightSection gap
  },
});

