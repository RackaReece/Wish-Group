import React, { useState } from 'react';
import {
  TouchableOpacity,
  View,
  Text,
  StyleSheet,
  Modal,
  TouchableWithoutFeedback,
  FlatList,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';

export interface ServiceOption {
  label: string;
  value: string;
  description?: string;
  icon?: keyof typeof Ionicons.glyphMap;
}

interface ServicePickerPillProps {
  label?: string;
  selectedValue: string;
  onSelect: (value: string) => void;
  options: ServiceOption[];
  accentColor?: string;
}

export default function ServicePickerPill({
  label = 'Preferred service',
  selectedValue,
  onSelect,
  options,
  accentColor = '#87CEEB',
}: ServicePickerPillProps) {
  const [open, setOpen] = useState(false);

  const selectedOption = options.find((opt) => opt.value === selectedValue) || options[0];

  const handleSelect = (value: string) => {
    onSelect(value);
    setOpen(false);
  };

  return (
    <>
      <TouchableOpacity
        style={styles.pill}
        activeOpacity={0.85}
        onPress={() => setOpen(true)}
      >
        <View style={styles.leftSection}>
          <Ionicons name={selectedOption?.icon || 'sparkles-outline'} size={18} color={accentColor} />
          <View style={styles.textWrapper}>
            <Text style={styles.labelText}>{label}</Text>
            <Text style={styles.valueText}>{selectedOption?.label || 'Select service'}</Text>
            {selectedOption?.description ? (
              <Text style={styles.optionDescription}>{selectedOption.description}</Text>
            ) : null}
          </View>
        </View>
        <Ionicons name="chevron-down" size={18} color="#E5E7EB" />
      </TouchableOpacity>

      <Modal
        visible={open}
        transparent
        animationType="fade"
        onRequestClose={() => setOpen(false)}
      >
        <TouchableWithoutFeedback onPress={() => setOpen(false)}>
          <View style={styles.modalOverlay}>
            <TouchableWithoutFeedback>
              <View style={styles.modalContent}>
                <View style={styles.modalHeader}>
                  <Text style={styles.modalTitle}>Choose a service</Text>
                  <TouchableOpacity onPress={() => setOpen(false)}>
                    <Ionicons name="close" size={22} color="#F9FAFB" />
                  </TouchableOpacity>
                </View>
                <FlatList
                  data={options}
                  keyExtractor={(item) => item.value}
                  ItemSeparatorComponent={() => <View style={styles.separator} />}
                  renderItem={({ item }) => (
                    <TouchableOpacity
                      style={styles.optionRow}
                      onPress={() => handleSelect(item.value)}
                      activeOpacity={0.85}
                    >
                      <View style={styles.optionIconWrapper}>
                        <Ionicons
                          name={item.icon || 'water'}
                          size={20}
                          color={accentColor}
                        />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.optionLabel}>{item.label}</Text>
                        {item.description ? (
                          <Text style={styles.optionSubtitle}>{item.description}</Text>
                        ) : null}
                      </View>
                      {selectedValue === item.value ? (
                        <Ionicons name="checkmark-circle" size={20} color={accentColor} />
                      ) : (
                        <Ionicons name="ellipse-outline" size={20} color="#4B5563" />
                      )}
                    </TouchableOpacity>
                  )}
                />
              </View>
            </TouchableWithoutFeedback>
          </View>
        </TouchableWithoutFeedback>
      </Modal>
    </>
  );
}

const styles = StyleSheet.create({
  pill: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 24,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  leftSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
  },
  textWrapper: {
    flex: 1,
  },
  labelText: {
    color: '#9CA3AF',
    fontSize: 11,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  valueText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  optionDescription: {
    color: '#9CA3AF',
    fontSize: 12,
    marginTop: 2,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    padding: 24,
  },
  modalContent: {
    backgroundColor: '#0F172A',
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    maxHeight: '70%',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  separator: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  optionRow: {
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  optionIconWrapper: {
    width: 34,
    height: 34,
    borderRadius: 17,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  optionLabel: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '600',
  },
  optionSubtitle: {
    color: '#9CA3AF',
    fontSize: 12,
    marginTop: 2,
  },
});

