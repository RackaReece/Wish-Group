import React, { useEffect, useRef, useState } from 'react';
import { View, StyleSheet, Animated } from 'react-native';
import MapView, { Marker, Region, PROVIDER_DEFAULT } from 'react-native-maps';

interface Location {
  latitude: number;
  longitude: number;
  name?: string;
}

// Major cities around the globe for transitions
const CITIES: Region[] = [
  { latitude: 51.5074, longitude: -0.1278, latitudeDelta: 0.15, longitudeDelta: 0.15 }, // London
  { latitude: 40.7128, longitude: -74.0060, latitudeDelta: 0.15, longitudeDelta: 0.15 }, // New York
  { latitude: 34.0522, longitude: -118.2437, latitudeDelta: 0.15, longitudeDelta: 0.15 }, // Los Angeles
  { latitude: 48.8566, longitude: 2.3522, latitudeDelta: 0.15, longitudeDelta: 0.15 }, // Paris
  { latitude: 52.5200, longitude: 13.4050, latitudeDelta: 0.15, longitudeDelta: 0.15 }, // Berlin
  { latitude: 35.6762, longitude: 139.6503, latitudeDelta: 0.15, longitudeDelta: 0.15 }, // Tokyo
  { latitude: -33.8688, longitude: 151.2093, latitudeDelta: 0.15, longitudeDelta: 0.15 }, // Sydney
  { latitude: -22.9068, longitude: -43.1729, latitudeDelta: 0.15, longitudeDelta: 0.15 }, // Rio de Janeiro
  { latitude: 25.2048, longitude: 55.2708, latitudeDelta: 0.15, longitudeDelta: 0.15 }, // Dubai
  { latitude: 1.3521, longitude: 103.8198, latitudeDelta: 0.15, longitudeDelta: 0.15 }, // Singapore
];

// Sample Wish a Wash locations (blue pins) - you can replace with real data from database
const WISH_A_WASH_LOCATIONS: Location[] = [
  { latitude: 51.5074, longitude: -0.1278, name: 'London Central' },
  { latitude: 51.5154, longitude: -0.1419, name: 'London West' },
  { latitude: 40.7128, longitude: -74.0060, name: 'New York Downtown' },
  { latitude: 40.7589, longitude: -73.9851, name: 'New York Midtown' },
  { latitude: 34.0522, longitude: -118.2437, name: 'LA Central' },
  { latitude: 34.0689, longitude: -118.4452, name: 'LA Beverly Hills' },
  { latitude: 48.8566, longitude: 2.3522, name: 'Paris Central' },
  { latitude: 52.5200, longitude: 13.4050, name: 'Berlin Mitte' },
  { latitude: 35.6762, longitude: 139.6503, name: 'Tokyo Shibuya' },
  { latitude: -33.8688, longitude: 151.2093, name: 'Sydney CBD' },
];

const SLIDE_DURATION = 12000; // 12 seconds for smooth sliding
const HOLD_DURATION = 2000; // 2 seconds hold before next slide

// Pulsing Pin Component
function PulsingPin({ delay = 0 }: { delay?: number }) {
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const timeoutRef = useRef<NodeJS.Timeout | null>(null);
  const animationRef = useRef<Animated.CompositeAnimation | null>(null);

  useEffect(() => {
    timeoutRef.current = setTimeout(() => {
      animationRef.current = Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, {
            toValue: 1.3,
            duration: 1000,
            useNativeDriver: true,
          }),
          Animated.timing(pulseAnim, {
            toValue: 1,
            duration: 1000,
            useNativeDriver: true,
          }),
        ])
      );
      animationRef.current.start();
    }, delay);

    return () => {
      if (timeoutRef.current) {
        clearTimeout(timeoutRef.current);
      }
      if (animationRef.current) {
        animationRef.current.stop();
      }
      pulseAnim.stopAnimation();
    };
  }, [pulseAnim, delay]);

  return (
    <View style={styles.markerContainer}>
      {/* Pulsing outer ring */}
      <Animated.View
        style={[
          styles.pulseRing,
          {
            transform: [{ scale: pulseAnim }],
            opacity: pulseAnim.interpolate({
              inputRange: [1, 1.3],
              outputRange: [0.6, 0],
            }),
          },
        ]}
      />
      
      {/* Pin shadow */}
      <View style={styles.pinShadow} />
      
      {/* Main pin */}
      <View style={styles.pinContainer}>
        {/* Blue pin body (teardrop) */}
        <View style={styles.pinBody}>
          <View style={styles.pinBodyInner} />
        </View>
        
        {/* White circle on top */}
        <View style={styles.pinHead}>
          <View style={styles.pinHeadInner} />
        </View>
      </View>
    </View>
  );
}

export default function AnimatedMapBackground() {
  const [currentCityIndex, setCurrentCityIndex] = useState(0);
  const mapRef = useRef<MapView>(null);

  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    let intervalId: NodeJS.Timeout;

    const slideToNextCity = () => {
      setCurrentCityIndex((prevIndex) => {
        const nextIndex = (prevIndex + 1) % CITIES.length;
        const nextCity = CITIES[nextIndex];

        // Smooth sliding animation to next city
        if (mapRef.current) {
          mapRef.current.animateToRegion(
            {
              latitude: nextCity.latitude,
              longitude: nextCity.longitude,
              latitudeDelta: nextCity.latitudeDelta,
              longitudeDelta: nextCity.longitudeDelta,
            },
            SLIDE_DURATION
          );
        }

        return nextIndex;
      });
    };

    // Start sliding animation after initial delay
    timeoutId = setTimeout(() => {
      // Begin sliding to next city
      slideToNextCity();
      
      // Continue sliding between cities continuously
      intervalId = setInterval(() => {
        slideToNextCity();
      }, HOLD_DURATION + SLIDE_DURATION);
    }, HOLD_DURATION);

    return () => {
      if (timeoutId) clearTimeout(timeoutId);
      if (intervalId) clearInterval(intervalId);
    };
  }, []);

  return (
    <View style={styles.container}>
      <View style={styles.mapContainer}>
        <MapView
          ref={mapRef}
          provider={PROVIDER_DEFAULT}
          style={styles.map}
          initialRegion={CITIES[0]}
          mapType="standard"
          customMapStyle={DARK_MAP_STYLE}
          showsUserLocation={false}
          showsMyLocationButton={false}
          showsCompass={false}
          showsScale={false}
          toolbarEnabled={false}
          scrollEnabled={false}
          zoomEnabled={false}
          rotateEnabled={false}
          pitchEnabled={false}
          mapPadding={{ top: 0, bottom: 0, left: 0, right: 0 }}
          animationEnabled={true}
        >
          {WISH_A_WASH_LOCATIONS.map((location, index) => (
            <Marker
              key={`location-${index}`}
              coordinate={{ latitude: location.latitude, longitude: location.longitude }}
              title={location.name || 'Wish a Wash'}
              anchor={{ x: 0.5, y: 1 }}
            >
              <PulsingPin delay={index * 150} />
            </Marker>
          ))}
        </MapView>
      </View>
      {/* Dark overlay for better text readability */}
      <View style={styles.overlay} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
  },
  mapContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 32,
    height: 48,
  },
  pulseRing: {
    position: 'absolute',
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#2563EB',
    borderWidth: 2,
    borderColor: '#2563EB',
  },
  pinShadow: {
    position: 'absolute',
    bottom: 0,
    width: 16,
    height: 6,
    borderRadius: 8,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    transform: [{ scaleX: 1.2 }],
  },
  pinContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  pinBody: {
    width: 0,
    height: 0,
    borderLeftWidth: 10,
    borderRightWidth: 10,
    borderTopWidth: 16,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderTopColor: '#2563EB',
    marginTop: 8,
  },
  pinBodyInner: {
    position: 'absolute',
    top: 2,
    left: -8,
    width: 0,
    height: 0,
    borderLeftWidth: 8,
    borderRightWidth: 8,
    borderTopWidth: 12,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    borderTopColor: '#1E40AF',
  },
  pinHead: {
    position: 'absolute',
    top: 0,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#FFFFFF',
    borderWidth: 3,
    borderColor: '#2563EB',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
    elevation: 5,
  },
  pinHeadInner: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: '#2563EB',
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(10, 25, 41, 0.4)',
  },
});

// Dark mode map style
const DARK_MAP_STYLE = [
  {
    elementType: 'geometry',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.fill',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'administrative.locality',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'geometry',
    stylers: [{ color: '#263c3f' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#6b9a76' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry',
    stylers: [{ color: '#38414e' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#212a37' }],
  },
  {
    featureType: 'road',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#9ca5b3' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#1f2835' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#f3d19c' }],
  },
  {
    featureType: 'transit',
    elementType: 'geometry',
    stylers: [{ color: '#2f3948' }],
  },
  {
    featureType: 'transit.station',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [{ color: '#17263c' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#515c6d' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#17263c' }],
  },
];
