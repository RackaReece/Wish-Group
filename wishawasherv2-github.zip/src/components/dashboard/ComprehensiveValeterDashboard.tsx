import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  ScrollView,
  ActivityIndicator,
  Alert,
  Linking,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../providers/enhanced-auth-context';
import { supabase } from '../../lib/supabase';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { PaymentCommissionService, ValeterEarnings } from '../../services/PaymentCommissionService';
import { ValeterStatsService } from '../../services/Valeterstatsservice';
import { ValeterVerificationService } from '../../services/ValeterVerificationService';
import GlassCard from '../booking/GlassCard';
import BubbleBackground from '../shared/BubbleBackground';
import { getAccountTheme } from '../../constants/accountThemes';
import { colors } from '../../constants/colors';
import * as Location from 'expo-location';

const { width } = Dimensions.get('window');
const valeterTheme = getAccountTheme('valeter');
const SKY = colors.SKY;

interface TodayJob {
  id: string;
  time: string;
  service: string;
  address: string;
  distance: number;
  price: number;
  status: string;
}

interface JobRequest {
  id: string;
  serviceName: string;
  distance: number;
  price: number;
  customerName: string;
  address: string;
  timeRemaining: number; // seconds
  scheduledAt: string;
}

interface ActiveJob {
  id: string;
  status: 'en_route' | 'arrived' | 'washing' | 'completed' | 'taking_photos';
  service: string;
  address: string;
  customerName: string;
}

interface VerificationStatus {
  idVerified: boolean;
  insuranceVerified: boolean;
  businessVerified: boolean;
}

interface KitItem {
  id: string;
  name: string;
  checked: boolean;
}

const AnimatedCounter = ({ value, style }: { value: number; style?: any }) => {
  const [displayValue, setDisplayValue] = useState(0);
  const animValue = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(animValue, {
      toValue: value,
      duration: 800,
      useNativeDriver: false,
    }).start();
  }, [value, animValue]);

  useEffect(() => {
    const listener = animValue.addListener(({ value: v }) => {
      setDisplayValue(Math.round(v));
    });
    return () => animValue.removeListener(listener);
  }, [animValue]);

  return <Text style={style}>{displayValue}</Text>;
};

export default function ComprehensiveValeterDashboard() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  
  const [isOnline, setIsOnline] = useState(false);
  const [toggling, setToggling] = useState(false);
  const [loading, setLoading] = useState(true);
  
  // Today's Jobs
  const [todayJobs, setTodayJobs] = useState<TodayJob[]>([]);
  const [nextJob, setNextJob] = useState<TodayJob | null>(null);
  
  // Earnings
  const [earnings, setEarnings] = useState<ValeterEarnings | null>(null);
  const [todayEarnings, setTodayEarnings] = useState(0);
  const [weekEarnings, setWeekEarnings] = useState(0);
  const [pendingPayout, setPendingPayout] = useState(0);
  const [availableBalance, setAvailableBalance] = useState(0);
  
  // Job Requests
  const [jobRequests, setJobRequests] = useState<JobRequest[]>([]);
  
  // Active Job
  const [activeJob, setActiveJob] = useState<ActiveJob | null>(null);
  
  // Ratings
  const [rating, setRating] = useState(0);
  const [lastReview, setLastReview] = useState<string | null>(null);
  
  // Verification
  const [verification, setVerification] = useState<VerificationStatus>({
    idVerified: false,
    insuranceVerified: false,
    businessVerified: false,
  });
  
  // Kit Checklist
  const [kitItems, setKitItems] = useState<KitItem[]>([
    { id: '1', name: 'Microfibres', checked: false },
    { id: '2', name: 'Shampoo', checked: false },
    { id: '3', name: 'Vacuum', checked: false },
    { id: '4', name: 'Wax', checked: false },
    { id: '5', name: 'Tire Shine', checked: false },
  ]);
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();
  }, []);

  useEffect(() => {
    if (isOnline) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
        ])
      ).start();
    } else {
      pulseAnim.setValue(1);
    }
  }, [isOnline, pulseAnim]);

  useEffect(() => {
    if (!user?.id) return;
    loadInitialData();
    
    // Subscribe to presence changes
    const channel = supabase
      .channel('presence-valeter')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const row: any = payload.new ?? payload.old;
          if (row && typeof row.is_online === 'boolean') setIsOnline(row.is_online);
        }
      )
      .subscribe();

    // Subscribe to job requests
    const jobChannel = supabase
      .channel('job-requests-valeter')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${user.id}`,
        },
        () => {
          loadTodayJobs();
          loadJobRequests();
          loadActiveJob();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      supabase.removeChannel(jobChannel);
    };
  }, [user?.id]);

  const loadInitialData = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      await Promise.all([
        loadOnlineStatus(),
        loadTodayJobs(),
        loadEarnings(),
        loadJobRequests(),
        loadActiveJob(),
        loadRating(),
        loadVerification(),
      ]);
    } catch (error) {
      console.error('Error loading dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadOnlineStatus = async () => {
    if (!user?.id) return;
    try {
      const { data } = await supabase
        .from('valeter_presence')
        .select('is_online')
        .eq('user_id', user.id)
        .maybeSingle();
      setIsOnline(!!data?.is_online);
    } catch (error) {
      console.error('Error loading online status:', error);
    }
  };

  const toggleOnlineStatus = async () => {
    if (!user?.id || toggling) return;
    
    try {
      setToggling(true);
      await hapticFeedback('medium');
      
      const newStatus = !isOnline;
      
      // Update presence
      const { error } = await supabase
        .from('valeter_presence')
        .upsert({
          user_id: user.id,
          is_online: newStatus,
          updated_at: new Date().toISOString(),
        }, {
          onConflict: 'user_id',
        });

      if (error) throw error;
      
      setIsOnline(newStatus);
      
      if (newStatus) {
        // Start location tracking when going online
        await Location.requestForegroundPermissionsAsync();
      }
    } catch (error) {
      console.error('Error toggling online status:', error);
      Alert.alert('Error', 'Failed to update status. Please try again.');
    } finally {
      setToggling(false);
    }
  };

  const loadTodayJobs = async () => {
    if (!user?.id) return;
    try {
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(tomorrow.getDate() + 1);

      const { data: bookings } = await supabase
        .from('bookings')
        .select('id, scheduled_at, service_type, location_address, price, status')
        .eq('valeter_id', user.id)
        .gte('scheduled_at', today.toISOString())
        .lt('scheduled_at', tomorrow.toISOString())
        .in('status', ['confirmed', 'pending_valeter_acceptance', 'in_progress'])
        .order('scheduled_at', { ascending: true });

      if (!bookings) return;

      const jobs: TodayJob[] = bookings.map((b: any) => {
        const date = new Date(b.scheduled_at);
        const timeStr = date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
        return {
          id: b.id,
          time: timeStr,
          service: b.service_type || 'Car Wash',
          address: b.location_address || 'Address TBD',
          distance: 0, // TODO: Calculate distance
          price: Number(b.price || 0),
          status: b.status,
        };
      });

      setTodayJobs(jobs);
      setNextJob(jobs.length > 0 ? jobs[0] : null);
    } catch (error) {
      console.error('Error loading today jobs:', error);
    }
  };

  const loadEarnings = async () => {
    if (!user?.id) return;
    try {
      const earningsData = await PaymentCommissionService.getInstance().getValeterEarnings(user.id);
      setEarnings(earningsData);
      
      // Calculate today's earnings
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const { data: todayBookings } = await supabase
        .from('bookings')
        .select('price, completed_at')
        .eq('valeter_id', user.id)
        .eq('status', 'completed')
        .gte('completed_at', today.toISOString());
      
      const todayTotal = (todayBookings || []).reduce((sum: number, b: any) => sum + Number(b.price || 0), 0);
      setTodayEarnings(todayTotal);
      
      // Calculate week's earnings
      const weekAgo = new Date();
      weekAgo.setDate(weekAgo.getDate() - 7);
      const { data: weekBookings } = await supabase
        .from('bookings')
        .select('price, completed_at')
        .eq('valeter_id', user.id)
        .eq('status', 'completed')
        .gte('completed_at', weekAgo.toISOString());
      
      const weekTotal = (weekBookings || []).reduce((sum: number, b: any) => sum + Number(b.price || 0), 0);
      setWeekEarnings(weekTotal);
      
      setPendingPayout(earningsData.pendingPayment);
      setAvailableBalance(earningsData.totalEarnings - earningsData.totalCommission);
    } catch (error) {
      console.error('Error loading earnings:', error);
    }
  };

  const loadJobRequests = async () => {
    if (!user?.id || !isOnline) {
      setJobRequests([]);
      return;
    }
    
    try {
      const { data: bookings } = await supabase
        .from('bookings')
        .select('id, service_type, location_address, price, scheduled_at, created_at')
        .eq('valeter_id', user.id)
        .eq('status', 'pending_valeter_acceptance')
        .order('created_at', { ascending: false })
        .limit(5);

      if (!bookings) return;

      const requests: JobRequest[] = bookings.map((b: any) => {
        const created = new Date(b.created_at);
        const now = new Date();
        const timeRemaining = Math.max(0, 300 - Math.floor((now.getTime() - created.getTime()) / 1000));
        
        return {
          id: b.id,
          serviceName: b.service_type || 'Car Wash',
          distance: 0, // TODO: Calculate
          price: Number(b.price || 0),
          customerName: 'Customer',
          address: b.location_address || '',
          timeRemaining,
          scheduledAt: b.scheduled_at,
        };
      });

      setJobRequests(requests);
    } catch (error) {
      console.error('Error loading job requests:', error);
    }
  };

  const loadActiveJob = async () => {
    if (!user?.id) return;
    try {
      const { data: booking } = await supabase
        .from('bookings')
        .select('id, status, service_type, location_address')
        .eq('valeter_id', user.id)
        .eq('status', 'in_progress')
        .order('updated_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (booking) {
        setActiveJob({
          id: booking.id,
          status: 'washing', // TODO: Get actual status from booking
          service: booking.service_type || 'Car Wash',
          address: booking.location_address || '',
          customerName: 'Customer',
        });
      } else {
        setActiveJob(null);
      }
    } catch (error) {
      console.error('Error loading active job:', error);
    }
  };

  const loadRating = async () => {
    if (!user?.id) return;
    try {
      const stats = await ValeterStatsService.getValeterStats(user.id);
      setRating(stats.averageRating);
      
      // Get last review
      const { data: reviews } = await supabase
        .from('bookings')
        .select('review_text')
        .eq('valeter_id', user.id)
        .not('review_text', 'is', null)
        .order('updated_at', { ascending: false })
        .limit(1)
        .maybeSingle();
      
      setLastReview(reviews?.review_text || null);
    } catch (error) {
      console.error('Error loading rating:', error);
    }
  };

  const loadVerification = async () => {
    if (!user?.id) return;
    try {
      const service = ValeterVerificationService.getInstance();
      const profile = service.getValeterProfile(user.id);
      
      if (profile) {
        const idDoc = profile.documents.find(d => d.type === 'id_proof');
        const insuranceDoc = profile.documents.find(d => d.type === 'insurance');
        const businessDoc = profile.documents.find(d => d.type === 'business_license');
        
        setVerification({
          idVerified: idDoc?.status === 'approved' || false,
          insuranceVerified: insuranceDoc?.status === 'approved' || false,
          businessVerified: businessDoc?.status === 'approved' || profile.verificationBadge || false,
        });
      } else {
        // Check from database
        const { data: documents } = await supabase
          .from('valeter_documents')
          .select('document_type, status')
          .eq('valeter_id', user.id);
        
        if (documents) {
          setVerification({
            idVerified: documents.some(d => d.document_type === 'id_proof' && d.status === 'approved'),
            insuranceVerified: documents.some(d => d.document_type === 'insurance' && d.status === 'approved'),
            businessVerified: documents.some(d => d.document_type === 'business_license' && d.status === 'approved'),
          });
        }
      }
    } catch (error) {
      console.error('Error loading verification:', error);
    }
  };

  const handleAcceptJob = async (requestId: string) => {
    if (!user?.id) return;
    try {
      await hapticFeedback('success');
      const { error } = await supabase
        .from('bookings')
        .update({ status: 'confirmed' })
        .eq('id', requestId)
        .eq('valeter_id', user.id);
      
      if (error) throw error;
      
      setJobRequests(prev => prev.filter(r => r.id !== requestId));
      loadTodayJobs();
    } catch (error) {
      console.error('Error accepting job:', error);
      Alert.alert('Error', 'Failed to accept job. Please try again.');
    }
  };

  const handleDeclineJob = async (requestId: string) => {
    if (!user?.id) return;
    try {
      await hapticFeedback('light');
      const { error } = await supabase
        .from('bookings')
        .update({ status: 'cancelled' })
        .eq('id', requestId)
        .eq('valeter_id', user.id);
      
      if (error) throw error;
      
      setJobRequests(prev => prev.filter(r => r.id !== requestId));
    } catch (error) {
      console.error('Error declining job:', error);
    }
  };

  const handleStartNavigation = (address: string) => {
    const url = `https://maps.google.com/?daddr=${encodeURIComponent(address)}`;
    Linking.openURL(url).catch(err => console.error('Error opening maps:', err));
  };

  const toggleKitItem = (id: string) => {
    setKitItems(prev => prev.map(item => 
      item.id === id ? { ...item, checked: !item.checked } : item
    ));
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={valeterTheme.background} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="valeter" />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading dashboard...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={valeterTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />
      
      <Animated.ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: insets.top + 20, paddingBottom: insets.bottom + 100 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {/* Main Status Toggle */}
        <Animated.View style={[styles.statusToggleSection, { opacity: fadeAnim }]}>
          <GlassCard style={styles.statusToggleCard} accountType="valeter">
            <LinearGradient
              colors={isOnline ? ['rgba(16,185,129,0.15)', 'rgba(16,185,129,0.05)'] : ['rgba(107,114,128,0.15)', 'rgba(107,114,128,0.05)']}
              style={StyleSheet.absoluteFill}
            />
            <TouchableOpacity
              onPress={toggleOnlineStatus}
              disabled={toggling}
              style={styles.statusToggleButton}
              activeOpacity={0.8}
            >
              <View style={styles.statusToggleContent}>
                <Animated.View
                  style={[
                    styles.statusIndicator,
                    {
                      backgroundColor: isOnline ? '#10B981' : '#6B7280',
                      transform: [{ scale: pulseAnim }],
                    },
                  ]}
                />
                <Text style={styles.statusToggleText}>
                  {isOnline ? '✅ Online / Available' : '❌ Offline'}
                </Text>
                {toggling && <ActivityIndicator size="small" color={SKY} style={{ marginLeft: 8 }} />}
              </View>
            </TouchableOpacity>
          </GlassCard>
        </Animated.View>

        {/* Today's Jobs Card */}
        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <View style={styles.sectionHeader}>
            <Ionicons name="calendar" size={20} color={SKY} />
            <Text style={styles.sectionTitle}>Today's Jobs</Text>
          </View>
          <GlassCard style={styles.jobsCard} accountType="valeter">
            <View style={styles.jobsContent}>
              <Text style={styles.jobsCount}>Jobs today: {todayJobs.length}</Text>
              {nextJob ? (
                <>
                  <View style={styles.nextJobInfo}>
                    <View style={styles.nextJobRow}>
                      <Ionicons name="time" size={16} color={SKY} />
                      <Text style={styles.nextJobText}>Next job: {nextJob.time}</Text>
                    </View>
                    <View style={styles.nextJobRow}>
                      <Ionicons name="location" size={16} color={SKY} />
                      <Text style={styles.nextJobText} numberOfLines={1}>{nextJob.address}</Text>
                    </View>
                    <View style={styles.nextJobRow}>
                      <Ionicons name="navigate" size={16} color={SKY} />
                      <Text style={styles.nextJobText}>{nextJob.distance > 0 ? `${nextJob.distance}km` : 'Distance TBD'}</Text>
                    </View>
                  </View>
                  <TouchableOpacity
                    onPress={() => handleStartNavigation(nextJob.address)}
                    style={styles.navButton}
                    activeOpacity={0.8}
                  >
                    <LinearGradient
                      colors={[SKY, '#5BA3D0']}
                      style={styles.navButtonGradient}
                    >
                      <Ionicons name="navigate" size={18} color="#FFFFFF" />
                      <Text style={styles.navButtonText}>Start Navigation</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </>
              ) : (
                <Text style={styles.noJobsText}>No jobs scheduled for today</Text>
              )}
            </View>
          </GlassCard>
        </Animated.View>

        {/* Earnings Snapshot */}
        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <View style={styles.sectionHeader}>
            <Ionicons name="cash" size={20} color={SKY} />
            <Text style={styles.sectionTitle}>Earnings Snapshot</Text>
          </View>
          <GlassCard style={styles.earningsCard} accountType="valeter">
            <View style={styles.earningsGrid}>
              <View style={styles.earningsItem}>
                <Text style={styles.earningsLabel}>Today</Text>
                <Text style={styles.earningsValue}>£<AnimatedCounter value={todayEarnings} style={styles.earningsNumber} /></Text>
              </View>
              <View style={styles.earningsItem}>
                <Text style={styles.earningsLabel}>This Week</Text>
                <Text style={styles.earningsValue}>£<AnimatedCounter value={weekEarnings} style={styles.earningsNumber} /></Text>
              </View>
              <View style={styles.earningsItem}>
                <Text style={styles.earningsLabel}>Pending Payout</Text>
                <Text style={styles.earningsValue}>£<AnimatedCounter value={pendingPayout} style={styles.earningsNumber} /></Text>
              </View>
              <View style={styles.earningsItem}>
                <Text style={styles.earningsLabel}>Available Balance</Text>
                <Text style={styles.earningsValue}>£<AnimatedCounter value={availableBalance} style={styles.earningsNumber} /></Text>
              </View>
            </View>
          </GlassCard>
        </Animated.View>

        {/* New Requests / Queue Panel */}
        {isOnline && jobRequests.length > 0 && (
          <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
            <View style={styles.sectionHeader}>
              <Ionicons name="notifications" size={20} color={SKY} />
              <Text style={styles.sectionTitle}>New Booking Requests</Text>
            </View>
            {jobRequests.map((request) => (
              <GlassCard key={request.id} style={styles.requestCard} accountType="valeter">
                <View style={styles.requestContent}>
                  <View style={styles.requestHeader}>
                    <Text style={styles.requestTitle}>{request.serviceName}</Text>
                    <View style={styles.timeLimitBadge}>
                      <Ionicons name="time-outline" size={12} color="#EF4444" />
                      <Text style={styles.timeLimitText}>{Math.floor(request.timeRemaining / 60)}m {request.timeRemaining % 60}s</Text>
                    </View>
                  </View>
                  <Text style={styles.requestPrice}>£{request.price.toFixed(2)}</Text>
                  <Text style={styles.requestAddress} numberOfLines={1}>{request.address}</Text>
                  <View style={styles.requestActions}>
                    <TouchableOpacity
                      onPress={() => handleDeclineJob(request.id)}
                      style={styles.declineButton}
                      activeOpacity={0.8}
                    >
                      <Text style={styles.declineButtonText}>Decline</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => handleAcceptJob(request.id)}
                      style={styles.acceptButton}
                      activeOpacity={0.8}
                    >
                      <LinearGradient
                        colors={['#10B981', '#059669']}
                        style={styles.acceptButtonGradient}
                      >
                        <Text style={styles.acceptButtonText}>Accept</Text>
                      </LinearGradient>
                    </TouchableOpacity>
                  </View>
                </View>
              </GlassCard>
            ))}
          </Animated.View>
        )}

        {/* Active Job Tracker */}
        {activeJob && (
          <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
            <View style={styles.sectionHeader}>
              <Ionicons name="car" size={20} color={SKY} />
              <Text style={styles.sectionTitle}>Active Job</Text>
            </View>
            <GlassCard style={styles.activeJobCard} accountType="valeter">
              <Text style={styles.activeJobService}>{activeJob.service}</Text>
              <Text style={styles.activeJobAddress} numberOfLines={1}>{activeJob.address}</Text>
              <View style={styles.jobSteps}>
                {['en_route', 'arrived', 'washing', 'completed', 'taking_photos'].map((step, index) => {
                  const isActive = step === activeJob.status;
                  const isCompleted = ['en_route', 'arrived', 'washing', 'completed', 'taking_photos'].indexOf(activeJob.status) > index;
                  return (
                    <View key={step} style={styles.jobStep}>
                      <View style={[styles.stepCircle, isCompleted && styles.stepCircleCompleted, isActive && styles.stepCircleActive]}>
                        {isCompleted ? (
                          <Ionicons name="checkmark" size={16} color="#FFFFFF" />
                        ) : (
                          <View style={styles.stepDot} />
                        )}
                      </View>
                      <Text style={[styles.stepLabel, isActive && styles.stepLabelActive]}>
                        {step === 'en_route' ? 'En route' : 
                         step === 'arrived' ? 'Arrived' :
                         step === 'washing' ? 'Washing' :
                         step === 'completed' ? 'Completed' : 'Take photos'}
                      </Text>
                    </View>
                  );
                })}
              </View>
            </GlassCard>
          </Animated.View>
        )}

        {/* Ratings + Reviews */}
        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <View style={styles.sectionHeader}>
            <Ionicons name="star" size={20} color={SKY} />
            <Text style={styles.sectionTitle}>Ratings & Reviews</Text>
          </View>
          <GlassCard style={styles.ratingCard} accountType="valeter">
            <View style={styles.ratingContent}>
              <View style={styles.ratingRow}>
                <Ionicons name="star" size={24} color="#FBBF24" />
                <Text style={styles.ratingValue}>{rating.toFixed(1)}</Text>
              </View>
              {lastReview && (
                <Text style={styles.lastReviewText}>"{lastReview}"</Text>
              )}
            </View>
          </GlassCard>
        </Animated.View>

        {/* Verification Badge */}
        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <View style={styles.sectionHeader}>
            <Ionicons name="shield-checkmark" size={20} color={SKY} />
            <Text style={styles.sectionTitle}>Verification</Text>
          </View>
          <GlassCard style={styles.verificationCard} accountType="valeter">
            <View style={styles.verificationContent}>
              <View style={styles.verificationItem}>
                <Ionicons 
                  name={verification.idVerified ? "checkmark-circle" : "close-circle"} 
                  size={20} 
                  color={verification.idVerified ? "#10B981" : "#6B7280"} 
                />
                <Text style={styles.verificationText}>ID verified</Text>
              </View>
              <View style={styles.verificationItem}>
                <Ionicons 
                  name={verification.insuranceVerified ? "checkmark-circle" : "close-circle"} 
                  size={20} 
                  color={verification.insuranceVerified ? "#10B981" : "#6B7280"} 
                />
                <Text style={styles.verificationText}>Insurance verified</Text>
              </View>
              <View style={styles.verificationItem}>
                <Ionicons 
                  name={verification.businessVerified ? "checkmark-circle" : "close-circle"} 
                  size={20} 
                  color={verification.businessVerified ? "#10B981" : "#6B7280"} 
                />
                <Text style={styles.verificationText}>Business verified</Text>
              </View>
            </View>
          </GlassCard>
        </Animated.View>

        {/* Stock / Kit Checklist */}
        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <View style={styles.sectionHeader}>
            <Ionicons name="bag" size={20} color={SKY} />
            <Text style={styles.sectionTitle}>Kit Checklist</Text>
          </View>
          <GlassCard style={styles.kitCard} accountType="valeter">
            <View style={styles.kitContent}>
              {kitItems.map((item) => (
                <TouchableOpacity
                  key={item.id}
                  onPress={() => toggleKitItem(item.id)}
                  style={styles.kitItem}
                  activeOpacity={0.7}
                >
                  <Ionicons
                    name={item.checked ? "checkbox" : "square-outline"}
                    size={20}
                    color={item.checked ? "#10B981" : "rgba(255,255,255,0.5)"}
                  />
                  <Text style={[styles.kitItemText, item.checked && styles.kitItemTextChecked]}>
                    {item.name}
                  </Text>
                </TouchableOpacity>
              ))}
            </View>
          </GlassCard>
        </Animated.View>

        {/* Quick Buttons */}
        <Animated.View style={[styles.section, { opacity: fadeAnim }]}>
          <View style={styles.quickButtons}>
            <TouchableOpacity
              onPress={() => router.push('/valeter/jobs')}
              style={styles.quickButton}
              activeOpacity={0.8}
            >
              <GlassCard style={styles.quickButtonCard} accountType="valeter">
                <Ionicons name="play-circle" size={24} color={SKY} />
                <Text style={styles.quickButtonText}>Start Shift</Text>
              </GlassCard>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => router.push('/valeter/valeter-analytics')}
              style={styles.quickButton}
              activeOpacity={0.8}
            >
              <GlassCard style={styles.quickButtonCard} accountType="valeter">
                <Ionicons name="wallet" size={24} color={SKY} />
                <Text style={styles.quickButtonText}>Payouts</Text>
              </GlassCard>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => Alert.alert('Support', 'Contact support at support@wishawash.com')}
              style={styles.quickButton}
              activeOpacity={0.8}
            >
              <GlassCard style={styles.quickButtonCard} accountType="valeter">
                <Ionicons name="help-circle" size={24} color={SKY} />
                <Text style={styles.quickButtonText}>Support</Text>
              </GlassCard>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => router.push('/valeter/profile/valeter-profile')}
              style={styles.quickButton}
              activeOpacity={0.8}
            >
              <GlassCard style={styles.quickButtonCard} accountType="valeter">
                <Ionicons name="settings" size={24} color={SKY} />
                <Text style={styles.quickButtonText}>Services</Text>
              </GlassCard>
            </TouchableOpacity>
          </View>
        </Animated.View>
      </Animated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.BG,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 16,
    gap: 16,
  },
  section: {
    marginBottom: 8,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    letterSpacing: -0.3,
  },
  // Status Toggle
  statusToggleSection: {
    marginBottom: 8,
  },
  statusToggleCard: {
    padding: 20,
    borderRadius: 20,
  },
  statusToggleButton: {
    width: '100%',
  },
  statusToggleContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  statusIndicator: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  statusToggleText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  // Today's Jobs
  jobsCard: {
    padding: 16,
    borderRadius: 16,
  },
  jobsContent: {
    gap: 12,
  },
  jobsCount: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  nextJobInfo: {
    gap: 8,
  },
  nextJobRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  nextJobText: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 14,
    fontWeight: '500',
    flex: 1,
  },
  navButton: {
    marginTop: 8,
    borderRadius: 12,
    overflow: 'hidden',
  },
  navButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 20,
  },
  navButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
  },
  noJobsText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    fontStyle: 'italic',
  },
  // Earnings
  earningsCard: {
    padding: 16,
    borderRadius: 16,
  },
  earningsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  earningsItem: {
    width: (width - 64) / 2,
    gap: 4,
  },
  earningsLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  earningsValue: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
  },
  earningsNumber: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '900',
  },
  // Job Requests
  requestCard: {
    padding: 16,
    borderRadius: 16,
    marginBottom: 12,
  },
  requestContent: {
    gap: 8,
  },
  requestHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  requestTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    flex: 1,
  },
  timeLimitBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(239,68,68,0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  timeLimitText: {
    color: '#EF4444',
    fontSize: 12,
    fontWeight: '700',
  },
  requestPrice: {
    color: SKY,
    fontSize: 18,
    fontWeight: '800',
  },
  requestAddress: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 13,
  },
  requestActions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 8,
  },
  declineButton: {
    flex: 1,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(239,68,68,0.15)',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
  },
  declineButtonText: {
    color: '#EF4444',
    fontSize: 14,
    fontWeight: '700',
  },
  acceptButton: {
    flex: 1,
    borderRadius: 12,
    overflow: 'hidden',
  },
  acceptButtonGradient: {
    paddingVertical: 12,
    alignItems: 'center',
  },
  acceptButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '800',
  },
  // Active Job
  activeJobCard: {
    padding: 16,
    borderRadius: 16,
  },
  activeJobService: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
  },
  activeJobAddress: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 14,
    marginBottom: 16,
  },
  jobSteps: {
    gap: 12,
  },
  jobStep: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  stepCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  stepCircleCompleted: {
    backgroundColor: '#10B981',
    borderColor: '#10B981',
  },
  stepCircleActive: {
    backgroundColor: SKY,
    borderColor: SKY,
  },
  stepDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.5)',
  },
  stepLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    fontWeight: '600',
  },
  stepLabelActive: {
    color: '#F9FAFB',
    fontWeight: '700',
  },
  // Ratings
  ratingCard: {
    padding: 16,
    borderRadius: 16,
  },
  ratingContent: {
    gap: 8,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  ratingValue: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '800',
  },
  lastReviewText: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 13,
    fontStyle: 'italic',
  },
  // Verification
  verificationCard: {
    padding: 16,
    borderRadius: 16,
  },
  verificationContent: {
    gap: 12,
  },
  verificationItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  verificationText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  // Kit Checklist
  kitCard: {
    padding: 16,
    borderRadius: 16,
  },
  kitContent: {
    gap: 12,
  },
  kitItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  kitItemText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    fontWeight: '600',
  },
  kitItemTextChecked: {
    color: '#F9FAFB',
    textDecorationLine: 'line-through',
  },
  // Quick Buttons
  quickButtons: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
  },
  quickButton: {
    width: (width - 64) / 2,
  },
  quickButtonCard: {
    padding: 16,
    borderRadius: 16,
    alignItems: 'center',
    gap: 8,
  },
  quickButtonText: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '700',
    textAlign: 'center',
  },
});
