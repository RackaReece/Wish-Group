import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Easing,
  Dimensions,
  ScrollView,
  Modal,
  ActivityIndicator,
  StatusBar,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../providers/enhanced-auth-context';
import { supabase } from '../../lib/supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import CarCareInfoHub from '../car-care/CarCareInfoHub';
import GradientNotificationBell from '../shared/GradientNotificationBell';
import AppHeader, { DASHBOARD_HEADER_CONTENT_OFFSET } from '../shared/AppHeader';
import BubbleBackground from '../shared/BubbleBackground';
import useLiveLocation from '../../hooks/useLiveLocation';
import { customerTheme } from '../../constants/customerTheme';
import { colors } from '../../constants/colors';
import { getServiceDisplayName } from '../../utils/serviceNameMapper';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY;

interface NearbyValeter {
  id: string;
  name: string;
  organization: string;
  rating: number;
  distance: number | null;
  isOnline: boolean;
}

interface LoyaltyData {
  points: number;
  tier: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  pointsToNextTier: number;
  nextReward?: string;
}

type DbBookingStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled';

type ActiveBooking = {
  id: string;
  status: DbBookingStatus;
  service_type: string;
  service_name: string | null;
  location_address: string | null;
  scheduled_at: string;
  price: number;
  valeter_name: string | null;
};

const ACTIVE_STATUSES: DbBookingStatus[] = ['scheduled', 'in_progress'];

export default function EnhancedCustomerDashboard() {
  const { user } = useAuth();

  const [nearbyValeters, setNearbyValeters] = useState<NearbyValeter[]>([]);
  const [showCarCareHub, setShowCarCareHub] = useState(false);
  const [loading, setLoading] = useState(true);
  const [profileName, setProfileName] = useState<string>('');
  const [notificationCount, setNotificationCount] = useState(0);

  const [activeBooking, setActiveBooking] = useState<ActiveBooking | null>(null);
  const [activeBookingLoading, setActiveBookingLoading] = useState(false);

  // Still used by header points + notifications logic
  const [loyaltyData] = useState<LoyaltyData | null>({
    points: 850,
    tier: 'Silver',
    pointsToNextTier: 150,
    nextReward: '50 points = 10% off next wash',
  });

  const { refresh } = useLiveLocation();

  const notificationStatuses = useMemo(
    () => [
      'pending',
      'pending_valeter_acceptance',
      'pending_payment',
      'confirmed',
      'valeter_assigned',
      'en_route',
      'arrived',
      'in_progress',
      'scheduled',
      'completed',
      'cancelled',
    ],
    []
  );

  const refreshRef = useRef(refresh);
  useEffect(() => {
    refreshRef.current = refresh;
  }, [refresh]);

  useEffect(() => {
    const interval = setInterval(() => {
      refreshRef.current?.();
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const scrollY = useRef(new Animated.Value(0)).current;

  // Animated bubbles for header background
  const bubbleData = useRef(
    Array.from({ length: 8 }, (_, index) => {
      const random = Math.random();
      return {
        translateY: new Animated.Value(0),
        opacity: new Animated.Value(0.2 + random * 0.2),
        scale: new Animated.Value(0.6 + random * 0.3),
        size: 20 + random * 30,
        leftPosition: width * 0.6 + random * width * 0.3,
        delay: index * 800,
        duration: 12000 + random * 8000,
        startY: 120 + random * 40,
        endY: -60,
        initialOpacity: 0.2 + random * 0.2,
      };
    })
  ).current;

  useEffect(() => {
    bubbleData.forEach((bubble) => {
      bubble.translateY.setValue(bubble.startY);
      bubble.opacity.setValue(bubble.initialOpacity);

      Animated.parallel([
        Animated.loop(
          Animated.sequence([
            Animated.delay(bubble.delay),
            Animated.timing(bubble.translateY, {
              toValue: bubble.endY,
              duration: bubble.duration,
              useNativeDriver: true,
            }),
            Animated.timing(bubble.translateY, {
              toValue: bubble.startY,
              duration: 0,
              useNativeDriver: true,
            }),
          ])
        ),
        Animated.loop(
          Animated.sequence([
            Animated.timing(bubble.opacity, {
              toValue: 0.35,
              duration: bubble.duration / 3,
              easing: Easing.inOut(Easing.ease),
              useNativeDriver: true,
            }),
            Animated.timing(bubble.opacity, {
              toValue: 0.15,
              duration: bubble.duration / 3,
              easing: Easing.inOut(Easing.ease),
              useNativeDriver: true,
            }),
            Animated.timing(bubble.opacity, {
              toValue: bubble.initialOpacity,
              duration: bubble.duration / 3,
              easing: Easing.inOut(Easing.ease),
              useNativeDriver: true,
            }),
          ])
        ),
      ]).start();
    });
  }, [bubbleData]);

  const loadActiveBooking = async () => {
    if (!user?.id) return;

    try {
      setActiveBookingLoading(true);

      const { data, error } = await supabase
        .from('bookings')
        .select('id,status,service_type,service_name,location_address,scheduled_at,price,valeter_name')
        .eq('user_id', user.id)
        .in('status', ACTIVE_STATUSES as any)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        console.warn('[CustomerDashboard] loadActiveBooking error:', error);
        setActiveBooking(null);
        return;
      }

      if (!data) {
        setActiveBooking(null);
        return;
      }

      setActiveBooking({
        id: data.id,
        status: data.status as DbBookingStatus,
        service_type: data.service_type,
        service_name: data.service_name ?? null,
        location_address: data.location_address ?? null,
        scheduled_at: data.scheduled_at,
        price: Number(data.price ?? 0),
        valeter_name: data.valeter_name ?? null,
      });
    } catch (e) {
      console.warn('[CustomerDashboard] loadActiveBooking exception:', e);
      setActiveBooking(null);
    } finally {
      setActiveBookingLoading(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;

    loadActiveBooking();

    const channel = supabase
      .channel(`customer-active-booking-${user.id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        () => loadActiveBooking()
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        (payload) => {
          const updated = payload.new as any;

          if (activeBooking?.id && updated?.id === activeBooking.id) {
            const newStatus = updated.status as DbBookingStatus;

            if (newStatus === 'completed' || newStatus === 'cancelled') {
              setActiveBooking(null);
            } else {
              setActiveBooking((prev) =>
                prev
                  ? {
                      ...prev,
                      status: newStatus,
                      valeter_name: updated.valeter_name ?? prev.valeter_name,
                      price: Number(updated.price ?? prev.price),
                      service_name: updated.service_name ?? prev.service_name,
                      location_address: updated.location_address ?? prev.location_address,
                    }
                  : prev
              );
            }
            return;
          }

          loadActiveBooking();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, activeBooking?.id]);

  // Notifications count (unchanged)
  useEffect(() => {
    if (!user?.id) return;
    let isMounted = true;
    const DISMISSED_STORAGE_KEY = 'wishawash:dismissed-notifications-v1';

    const fetchVehicleReminders = async (
      userId: string
    ): Promise<Array<{ id: string; type: 'vehicle_reminder' }>> => {
      try {
        const { data: vehicles, error } = await supabase
          .from('customer_vehicles')
          .select('id,make,model,registration,tax_expiry,mot_expiry')
          .eq('user_id', userId);

        if (error || !vehicles) return [];

        const reminders: Array<{ id: string; type: 'vehicle_reminder' }> = [];
        const now = new Date();
        const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

        vehicles.forEach((vehicle) => {
          if (vehicle.tax_expiry) {
            const taxExpiry = new Date(vehicle.tax_expiry);
            if (taxExpiry <= thirtyDaysFromNow && taxExpiry >= now) {
              reminders.push({ id: `tax-reminder-${vehicle.id}`, type: 'vehicle_reminder' });
            }
          }
          if (vehicle.mot_expiry) {
            const motExpiry = new Date(vehicle.mot_expiry);
            if (motExpiry <= thirtyDaysFromNow && motExpiry >= now) {
              reminders.push({ id: `mot-reminder-${vehicle.id}`, type: 'vehicle_reminder' });
            }
          }
        });

        return reminders;
      } catch (error) {
        console.warn('[CustomerDashboard] Vehicle reminders error', error);
        return [];
      }
    };

    const fetchRewardNotifications = async (userId: string): Promise<Array<{ id: string; type: 'reward' }>> => {
      try {
        const { data: userData, error } = await supabase
          .from('users')
          .select('tier_points,tier')
          .eq('id', userId)
          .single();

        if (error || !userData) return [];

        const notifications: Array<{ id: string; type: 'reward' }> = [];
        const points = userData.tier_points || 0;
        const milestones = [500, 1000, 2000, 3000, 5000];
        const nextMilestone = milestones.find((m) => m > points);

        if (nextMilestone && points > 0) {
          const pointsNeeded = nextMilestone - points;
          if (pointsNeeded <= 100) {
            notifications.push({ id: `reward-milestone-${nextMilestone}`, type: 'reward' });
          }
        }

        return notifications;
      } catch (error) {
        console.warn('[CustomerDashboard] Reward notifications error', error);
        return [];
      }
    };

    const fetchNotificationCount = async () => {
      try {
        const [bookingsResult, vehicleReminders, rewardNotifications] = await Promise.all([
          supabase
            .from('bookings')
            .select(
              'id,status,service_name,service_type,price,created_at,updated_at,scheduled_at,time_slot,location_address,address,valeter_name'
            )
            .eq('user_id', user.id)
            .in('status', notificationStatuses as any)
            .order('created_at', { ascending: false })
            .limit(100),
          fetchVehicleReminders(user.id),
          fetchRewardNotifications(user.id),
        ]);

        if (!isMounted) return;

        const bookingNotifications: Array<{ id: string; type: 'booking' }> = [];
        if (!bookingsResult.error && bookingsResult.data) {
          bookingNotifications.push(
            ...bookingsResult.data.map((b) => ({
              id: `booking-${b.id}`,
              type: 'booking' as const,
            }))
          );
        }

        const allNotifications = [...bookingNotifications, ...vehicleReminders, ...rewardNotifications];

        try {
          const raw = await AsyncStorage.getItem(DISMISSED_STORAGE_KEY);
          const dismissedStore = raw ? JSON.parse(raw) : {};
          const dismissedIds = new Set(dismissedStore[user.id] || []);
          const visibleNotifications = allNotifications.filter((notif) => !dismissedIds.has(notif.id));
          setNotificationCount(visibleNotifications.length);
        } catch (storageError) {
          console.warn('[CustomerDashboard] Storage read error:', storageError);
          setNotificationCount(allNotifications.length);
        }
      } catch (error) {
        if (isMounted) {
          console.warn('[CustomerDashboard] Notification count exception:', error);
          setNotificationCount(0);
        }
      }
    };

    fetchNotificationCount();
    const interval = setInterval(fetchNotificationCount, 45000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [user?.id, notificationStatuses]);

  // Load profile name
  useEffect(() => {
    if (!user?.id) return;
    const loadProfileName = async () => {
      const { data: profileData } = await supabase.from('profiles').select('full_name').eq('id', user.id).maybeSingle();
      if (profileData) setProfileName(profileData.full_name || user.name || 'Customer');
      else setProfileName(user.name || 'Customer');
    };
    loadProfileName();
  }, [user?.id]);

  const loadNearbyValeters = async () => {
    if (!user?.id) return;
    try {
      const { data: presence, error: presErr } = await supabase.from('valeter_presence').select('user_id, is_online').eq('is_online', true);

      if (presErr) console.warn('[NearbyValeters] presence error:', presErr);
      if (!presence || presence.length === 0) {
        setNearbyValeters([]);
        return;
      }

      const ids = presence.map((p) => p.user_id);
      const { data: profiles } = await supabase.from('valeter_profiles').select('user_id, display_name, company_name').in('user_id', ids);

      const list: NearbyValeter[] = (presence || []).map((p) => {
        const profile = profiles?.find((pr) => pr.user_id === p.user_id);
        return {
          id: p.user_id,
          name: profile?.display_name || 'Valeter',
          organization: profile?.company_name || 'Independent',
          rating: 4.5,
          distance: null,
          isOnline: p.is_online,
        };
      });

      setNearbyValeters(list.slice(0, 8));
    } catch (e) {
      console.error('[NearbyValeters] load error:', e);
      setNearbyValeters([]);
    }
  };

  useEffect(() => {
    loadNearbyValeters();
    const interval = setInterval(loadNearbyValeters, 30000);
    return () => clearInterval(interval);
  }, [user?.id]);

  useEffect(() => {
    if (user?.id) {
      const timer = setTimeout(() => setLoading(false), 500);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, [user?.id]);

  const handleNotificationPress = () => {
    router.push('/owner/features/notifications');
  };

  const handleResumeTracking = () => {
    if (!activeBooking?.id) return;
    router.push({
      pathname: '/owner/booking/tracking',
      params: { bookingId: activeBooking.id },
    } as any);
  };

  const handleAttemptNewBooking = (route: string) => {
    if (!activeBooking?.id) {
      router.push(route as any);
      return;
    }

    Alert.alert(
      'Active booking in progress',
      'You already have an active booking. You can resume tracking it now.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'View booking',
          onPress: handleResumeTracking,
        },
      ]
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const onlineCount = nearbyValeters.filter((v) => v.isOnline).length;

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={customerTheme.backgroundColor} />
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="customer" />

      <AppHeader
        title={profileName || user?.name || 'Customer'}
        subtitle={
          new Date().getHours() < 12
            ? 'Good morning!'
            : new Date().getHours() < 17
              ? 'Good afternoon!'
              : 'Good evening!'
        }
        variant="dashboard"
        accountType="customer"
        showBack={false}
        scrollY={scrollY}
        enableScrollAnimation={true}
        {...(loyaltyData?.points !== undefined && { points: loyaltyData.points })}
        rightAction={<GradientNotificationBell count={notificationCount} onPress={handleNotificationPress} />}
      />

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        contentContainerStyle={{
          paddingTop: DASHBOARD_HEADER_CONTENT_OFFSET,
          paddingBottom: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Booking Buttons */}
        <View style={styles.bookingButtonsSection}>
          <TouchableOpacity
            style={[styles.bookingButton, styles.bookingButtonTall]}
            onPress={() => handleAttemptNewBooking('/owner/booking')}
            activeOpacity={0.9}
          >
            <LinearGradient colors={['rgba(135,206,235,0.55)', 'rgba(59,130,246,0.55)']} style={styles.bookingButtonGradientTall}>
              <View style={styles.bookingButtonIconWrap}>
                <Ionicons name="water" size={22} color={LIGHT_SKY} />
              </View>
              <View style={styles.bookingButtonTextWrap}>
                <Text style={styles.bookingButtonTitle}>Book a Wash</Text>
                <Text style={styles.bookingButtonSubtitle}>
                  {activeBooking ? 'Finish your active booking first' : 'Quick mobile wash'}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.85)" />
            </LinearGradient>
          </TouchableOpacity>

          <TouchableOpacity
            style={[styles.bookingButton, styles.bookingButtonTall]}
            onPress={() => handleAttemptNewBooking('/owner/booking/detailing')}
            activeOpacity={0.9}
          >
            <LinearGradient colors={['rgba(135,206,235,0.55)', 'rgba(91,163,199,0.55)']} style={styles.bookingButtonGradientTall}>
              <View style={styles.bookingButtonIconWrap}>
                <Ionicons name="diamond" size={22} color={LIGHT_SKY} />
              </View>
              <View style={styles.bookingButtonTextWrap}>
                <Text style={styles.bookingButtonTitle}>Book Detailing</Text>
                <Text style={styles.bookingButtonSubtitle}>
                  {activeBooking ? 'Finish your active booking first' : 'Deep clean & finish'}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.85)" />
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Active Booking Card (bigger) */}
        {activeBookingLoading ? (
          <View style={styles.activeBookingSection}>
            <View style={styles.activeBookingSkeleton}>
              <ActivityIndicator size="small" color={SKY} />
              <Text style={styles.activeBookingLoadingText}>Checking active booking…</Text>
            </View>
          </View>
        ) : activeBooking ? (
          <View style={styles.activeBookingSection}>
            <TouchableOpacity activeOpacity={0.9} onPress={handleResumeTracking} style={styles.activeBookingCard}>
              <LinearGradient colors={['rgba(135,206,235,0.24)', 'rgba(30,58,138,0.3)']} style={styles.activeBookingGradient}>
                <View style={styles.activeBookingTopRow}>
                  <View style={styles.activeBookingIconWrap}>
                    <Ionicons name="radio" size={22} color={SKY} />
                  </View>

                  <View style={{ flex: 1 }}>
                    <Text style={styles.activeBookingTitle}>Active booking</Text>
                    <Text style={styles.activeBookingSubtitle} numberOfLines={1}>
                      {getServiceDisplayName(activeBooking.service_type, activeBooking.service_name)}
                    </Text>
                    {!!activeBooking.valeter_name && (
                      <Text style={styles.activeBookingValeter} numberOfLines={1}>
                        Valeter: {activeBooking.valeter_name}
                      </Text>
                    )}
                  </View>

                  <View style={styles.activeBookingStatusPill}>
                    <Ionicons
                      name={activeBooking.status === 'in_progress' ? 'play' : 'time'}
                      size={12}
                      color="#0A1929"
                    />
                    <Text style={styles.activeBookingStatusText}>
                      {activeBooking.status === 'in_progress' ? 'In progress' : 'Scheduled'}
                    </Text>
                  </View>
                </View>

                {!!activeBooking.location_address && (
                  <View style={styles.activeBookingMetaRow}>
                    <Ionicons name="location-outline" size={15} color={LIGHT_SKY} />
                    <Text style={styles.activeBookingMetaText} numberOfLines={1}>
                      {activeBooking.location_address}
                    </Text>
                  </View>
                )}

                <View style={styles.activeBookingBottomRow}>
                  <View style={styles.activeBookingPriceWrap}>
                    <Ionicons name="cash-outline" size={15} color={LIGHT_SKY} />
                    <Text style={styles.activeBookingPrice}>£{Number(activeBooking.price || 0).toFixed(2)}</Text>
                  </View>

                  <View style={styles.activeBookingCta}>
                    <Text style={styles.activeBookingMetaCta}>Resume tracking</Text>
                    <Ionicons name="chevron-forward" size={18} color={SKY} />
                  </View>
                </View>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        ) : null}

        {/* Car Care Info Hub */}
        <View style={styles.assistantSection}>
          <TouchableOpacity style={styles.assistantCard} onPress={() => setShowCarCareHub(true)} activeOpacity={0.9}>
            <LinearGradient colors={['rgba(135,206,235,0.2)', 'rgba(30,58,138,0.25)']} style={styles.assistantGradient}>
              <View style={styles.assistantContent}>
                <View style={styles.assistantIconWrapper}>
                  <Ionicons name="information-circle" size={30} color={SKY} />
                </View>
                <View style={styles.assistantTextContainer}>
                  <Text style={styles.assistantTitle}>Car Care Info Hub</Text>
                  <Text style={styles.assistantSubtitle}>Tips, locations & more</Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color={SKY} />
              </View>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Live Availability (stat-style instead of listing people) */}
        <View style={styles.availabilitySection}>
          <Text style={styles.sectionTitle}>Live Availability Near You</Text>

          <View style={styles.availabilityCard}>
            <LinearGradient colors={['rgba(135,206,235,0.18)', 'rgba(30,58,138,0.22)']} style={styles.availabilityGradient}>
              <View style={styles.availabilityTopRow}>
                <View style={styles.availabilityIconWrap}>
                  <Ionicons name="pulse" size={20} color={SKY} />
                </View>

                <View style={{ flex: 1 }}>
                  <Text style={styles.availabilityTitle}>Valeters online now</Text>
                  <Text style={styles.availabilitySubtitle}>{onlineCount} available</Text>
                </View>

                {(() => {
                  const label =
                    onlineCount >= 6 ? 'Great' : onlineCount >= 3 ? 'Good' : onlineCount >= 1 ? 'Limited' : 'None';

                  const pillBg =
                    onlineCount >= 6
                      ? 'rgba(16,185,129,0.95)'
                      : onlineCount >= 3
                        ? 'rgba(59,130,246,0.95)'
                        : onlineCount >= 1
                          ? 'rgba(245,158,11,0.95)'
                          : 'rgba(239,68,68,0.95)';

                  return (
                    <View style={[styles.availabilityPill, { backgroundColor: pillBg }]}>
                      <Text style={styles.availabilityPillText}>{label}</Text>
                    </View>
                  );
                })()}
              </View>

              <View style={styles.availabilityStatsRow}>
                <View style={styles.availabilityStat}>
                  <Text style={styles.availabilityStatLabel}>Est. wait</Text>
                  <Text style={styles.availabilityStatValue}>
                    {onlineCount >= 6 ? '~5–10m' : onlineCount >= 3 ? '~10–20m' : onlineCount >= 1 ? '~20–40m' : '—'}
                  </Text>
                </View>

                <View style={styles.availabilityDivider} />

                <View style={styles.availabilityStat}>
                  <Text style={styles.availabilityStatLabel}>Coverage</Text>
                  <Text style={styles.availabilityStatValue}>
                    {onlineCount >= 6 ? 'High' : onlineCount >= 3 ? 'Medium' : onlineCount >= 1 ? 'Low' : 'None'}
                  </Text>
                </View>

                <View style={styles.availabilityDivider} />

                <View style={styles.availabilityStat}>
                  <Text style={styles.availabilityStatLabel}>Updated</Text>
                  <Text style={styles.availabilityStatValue}>Live</Text>
                </View>
              </View>

              <Text style={styles.availabilityHint}>Counts update automatically.</Text>
            </LinearGradient>
          </View>
        </View>
      </Animated.ScrollView>

      <Modal visible={showCarCareHub} animationType="slide" presentationStyle="fullScreen">
        <CarCareInfoHub userType="customer" onClose={() => setShowCarCareHub(false)} />
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: customerTheme.backgroundColor },
  loadingText: { color: LIGHT_SKY, fontSize: 16 },
  scrollView: { flex: 1 },

  bookingButtonsSection: {
    flexDirection: 'column',
    gap: 12,
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginTop: -8,
    marginBottom: 14,
  },
  bookingButton: {
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
  },
  bookingButtonTall: {
    minHeight: 76,
  },
  bookingButtonGradientTall: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 18,
    paddingHorizontal: 16,
    gap: 12,
  },
  bookingButtonIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.18)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.25)',
  },
  bookingButtonTextWrap: {
    flex: 1,
    gap: 2,
  },
  bookingButtonTitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  bookingButtonSubtitle: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 12,
    fontWeight: '600',
  },

  /* Active Booking (bigger + more prominent) */
  activeBookingSection: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 18,
  },
  activeBookingSkeleton: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.28)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    padding: 18,
    alignItems: 'center',
  },
  activeBookingCard: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.8,
    borderColor: 'rgba(135,206,235,0.38)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.28,
    shadowRadius: 10,
  },
  activeBookingGradient: {
    padding: 18,
  },
  activeBookingLoadingText: {
    color: LIGHT_SKY,
    fontSize: 13,
    fontWeight: '600',
    marginTop: 10,
    textAlign: 'center',
  },
  activeBookingTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  activeBookingIconWrap: {
    width: 50,
    height: 50,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.38)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  activeBookingTitle: {
    color: LIGHT_SKY,
    fontSize: 15,
    fontWeight: '900',
    letterSpacing: 0.2,
    marginBottom: 3,
  },
  activeBookingSubtitle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 13,
    fontWeight: '700',
  },
  activeBookingValeter: {
    color: 'rgba(255,255,255,0.78)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 4,
  },
  activeBookingStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    backgroundColor: SKY,
  },
  activeBookingStatusText: {
    color: '#0A1929',
    fontSize: 11,
    fontWeight: '900',
  },
  activeBookingMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 6,
  },
  activeBookingMetaText: {
    color: 'rgba(255,255,255,0.88)',
    fontSize: 12,
    fontWeight: '650',
    flex: 1,
  },
  activeBookingBottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 14,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.18)',
  },
  activeBookingPriceWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  activeBookingPrice: {
    color: LIGHT_SKY,
    fontSize: 13,
    fontWeight: '900',
  },
  activeBookingCta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  activeBookingMetaCta: {
    color: SKY,
    fontSize: 13,
    fontWeight: '900',
  },

  assistantSection: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 20,
  },
  assistantCard: {
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.22,
    shadowRadius: 6,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  assistantGradient: {
    padding: 18,
  },
  assistantContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  assistantIconWrapper: {
    width: 52,
    height: 52,
    borderRadius: 26,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  assistantTextContainer: {
    flex: 1,
    gap: 4,
  },
  assistantTitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '800',
    letterSpacing: 0.2,
    flexShrink: 1,
  },
  assistantSubtitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 12 : 13,
    opacity: 0.9,
    fontWeight: '600',
    flexShrink: 1,
  },

  /* Availability */
  availabilitySection: { marginBottom: 18 },
  sectionTitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 12,
    marginHorizontal: isSmallScreen ? 12 : 20,
  },
  availabilityCard: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.22)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    marginHorizontal: isSmallScreen ? 12 : 20,
  },
  availabilityGradient: { padding: 16 },
  availabilityTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 14,
  },
  availabilityIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  availabilityTitle: { color: LIGHT_SKY, fontSize: 14, fontWeight: '800', marginBottom: 2 },
  availabilitySubtitle: { color: 'rgba(255,255,255,0.85)', fontSize: 12, fontWeight: '600' },
  availabilityPill: { paddingHorizontal: 12, paddingVertical: 7, borderRadius: 999 },
  availabilityPillText: { color: '#0A1929', fontSize: 11, fontWeight: '900' },
  availabilityStatsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    backgroundColor: 'rgba(0,0,0,0.18)',
    borderRadius: 14,
    paddingVertical: 12,
    paddingHorizontal: 12,
  },
  availabilityStat: { flex: 1, alignItems: 'center', gap: 4 },
  availabilityStatLabel: { color: 'rgba(255,255,255,0.7)', fontSize: 11, fontWeight: '700' },
  availabilityStatValue: { color: LIGHT_SKY, fontSize: 13, fontWeight: '900' },
  availabilityDivider: { width: 1, height: 30, backgroundColor: 'rgba(135,206,235,0.18)' },
  availabilityHint: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: 11,
    fontWeight: '600',
    marginTop: 10,
    textAlign: 'center',
  },
});
