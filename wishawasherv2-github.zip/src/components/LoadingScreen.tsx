import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Dimensions,
  Easing,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import BubbleBackground from './shared/BubbleBackground';
import { colors } from '../constants/colors';

const { width, height } = Dimensions.get('window');

interface LoadingScreenProps {
  message?: string;
}

export default function LoadingScreen({ message = "Loading..." }: LoadingScreenProps) {
  const logoScale = useRef(new Animated.Value(1)).current;
  const loadingBarProgress = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    // Logo pulsing zoom animation (scale from 0.85 to 1.15 for more pronounced effect)
    Animated.loop(
      Animated.sequence([
        Animated.timing(logoScale, {
          toValue: 1.15,
          duration: 1200,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(logoScale, {
          toValue: 0.85,
          duration: 1200,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Loading bar animation (0% to 100% over 2.5 seconds, then loop)
    const animateLoadingBar = () => {
      loadingBarProgress.setValue(0);
      Animated.timing(loadingBarProgress, {
        toValue: 1,
        duration: 2500,
        easing: Easing.inOut(Easing.ease),
        useNativeDriver: false, // width animation doesn't support native driver
      }).start(() => {
        animateLoadingBar();
      });
    };
    animateLoadingBar();
  }, [logoScale, loadingBarProgress]);

  const loadingBarWidth = loadingBarProgress.interpolate({
    inputRange: [0, 1],
    outputRange: ['0%', '100%'],
  });

  return (
    <View style={styles.container}>
      {/* Background gradient - Updated with new UI colors */}
      <LinearGradient
        colors={[colors.BG, '#1E3A8A', '#2563EB']}
        style={StyleSheet.absoluteFill}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      />
      
      {/* Bubble background */}
      <BubbleBackground accountType="customer" />

      {/* Main content */}
      <View style={styles.content}>
        {/* Pulsing logo */}
        <Animated.View
          style={[
            styles.logoContainer,
            {
              transform: [
                {
                  scale: logoScale,
                },
              ],
            },
          ]}
        >
          <Image
            source={require('../../assets/icon.png')}
            style={styles.logo}
            resizeMode="contain"
          />
        </Animated.View>

        {/* Brand text */}
        <View style={styles.brandContainer}>
          <Text style={styles.brandTitle}>Wish a Wash</Text>
          <Text style={styles.brandSubtitle}>Your Wish Our Wash</Text>
        </View>

        {/* Loading bar */}
        <View style={styles.loadingBarContainer}>
          <View style={styles.loadingBarBackground}>
            <Animated.View
              style={[
                styles.loadingBarFill,
                {
                  width: loadingBarWidth,
                },
              ]}
            />
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  content: {
    alignItems: 'center',
    zIndex: 10,
    justifyContent: 'center',
    flex: 1,
  },
  logoContainer: {
    marginBottom: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  logo: {
    width: 140,
    height: 140,
  },
  brandContainer: {
    alignItems: 'center',
    marginBottom: 60,
  },
  brandTitle: {
    fontSize: 32,
    fontWeight: '900',
    color: '#F9FAFB',
    marginBottom: 8,
    letterSpacing: 0.5,
  },
  brandSubtitle: {
    fontSize: 15,
    color: colors.SKY,
    textAlign: 'center',
    fontWeight: '600',
    opacity: 0.9,
  },
  loadingBarContainer: {
    position: 'absolute',
    bottom: 60,
    width: width * 0.8,
    alignItems: 'center',
  },
  loadingBarBackground: {
    width: '100%',
    height: 6,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderRadius: 3,
    overflow: 'hidden',
  },
  loadingBarFill: {
    height: '100%',
    backgroundColor: colors.SKY,
    borderRadius: 3,
    shadowColor: colors.SKY,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 8,
    elevation: 4,
  },
});
