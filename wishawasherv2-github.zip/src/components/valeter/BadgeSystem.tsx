import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../../constants/colors';

const SKY = colors.SKY;

export type BadgeType = 'most_booked' | 'top_rated' | 'eco_champion' | 'rising_star';

interface Badge {
  type: BadgeType;
  label: string;
  icon: string;
  colors: string[];
  description: string;
}

export const BADGES: Record<BadgeType, Badge> = {
  most_booked: {
    type: 'most_booked',
    label: 'Most Booked',
    icon: 'trophy',
    colors: ['#F59E0B', '#D97706'],
    description: 'Top 10% by booking count',
  },
  top_rated: {
    type: 'top_rated',
    label: 'Top Rated',
    icon: 'star',
    colors: ['#FBBF24', '#F59E0B'],
    description: '4.8+ stars, 20+ reviews',
  },
  eco_champion: {
    type: 'eco_champion',
    label: 'Eco Champion',
    icon: 'leaf',
    colors: ['#10B981', '#059669'],
    description: '50+ eco washes completed',
  },
  rising_star: {
    type: 'rising_star',
    label: 'Rising Star',
    icon: 'rocket',
    colors: ['#87CEEB', '#5BA3C7'],
    description: 'New valeter with 5+ 5-star reviews',
  },
};

interface BadgeSystemProps {
  badges: BadgeType[];
  size?: 'small' | 'medium' | 'large';
  showDescription?: boolean;
}

export default function BadgeSystem({ badges, size = 'medium', showDescription = false }: BadgeSystemProps) {
  if (badges.length === 0) return null;

  const sizeConfig = {
    small: { icon: 12, fontSize: 10, padding: 6 },
    medium: { icon: 16, fontSize: 12, padding: 8 },
    large: { icon: 20, fontSize: 14, padding: 10 },
  };

  const config = sizeConfig[size];

  return (
    <View style={styles.container}>
      {badges.map((badgeType) => {
        const badge = BADGES[badgeType];
        return (
          <View key={badgeType} style={styles.badgeWrapper}>
            <LinearGradient
              colors={badge.colors}
              style={[styles.badge, { padding: config.padding }]}
            >
              <Ionicons name={badge.icon as any} size={config.icon} color="#FFFFFF" />
              <Text style={[styles.badgeText, { fontSize: config.fontSize }]}>{badge.label}</Text>
            </LinearGradient>
            {showDescription && (
              <Text style={styles.description}>{badge.description}</Text>
            )}
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  badgeWrapper: {
    alignItems: 'center',
  },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    borderRadius: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  badgeText: {
    color: '#FFFFFF',
    fontWeight: '700',
  },
  description: {
    marginTop: 4,
    fontSize: 10,
    color: 'rgba(255,255,255,0.6)',
    textAlign: 'center',
  },
});

