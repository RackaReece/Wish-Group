/**
 * Utility to check and fix user_type in the database
 * Use this in development to verify/fix customer accounts
 */

import { supabase } from '../lib/supabase';

/**
 * Check the user_type for a given email address
 */
export async function checkUserType(email: string) {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('id, email, name, user_type')
      .eq('email', email.toLowerCase())
      .maybeSingle();

    if (error) {
      console.error('Error checking user type:', error);
      return { error: error.message };
    }

    if (!data) {
      return { error: 'User not found' };
    }

    return {
      id: data.id,
      email: data.email,
      name: data.name,
      user_type: data.user_type,
    };
  } catch (error: any) {
    return { error: error.message };
  }
}

/**
 * Update the user_type for a given email address
 * WARNING: Only use this in development/testing
 */
export async function updateUserType(email: string, userType: 'customer' | 'valeter' | 'business' | 'super_admin') {
  try {
    const { data, error } = await supabase
      .from('users')
      .update({ user_type: userType })
      .eq('email', email.toLowerCase())
      .select('id, email, user_type')
      .single();

    if (error) {
      console.error('Error updating user type:', error);
      return { error: error.message };
    }

    // Also update profiles table if it exists
    if (data?.id) {
      await supabase
        .from('profiles')
        .update({ user_type: userType })
        .eq('id', data.id);
    }

    return {
      success: true,
      id: data.id,
      email: data.email,
      user_type: data.user_type,
    };
  } catch (error: any) {
    return { error: error.message };
  }
}

/**
 * List all users with their user_types (for debugging)
 */
export async function listAllUsers() {
  try {
    const { data, error } = await supabase
      .from('users')
      .select('id, email, name, user_type')
      .order('created_at', { ascending: false })
      .limit(50);

    if (error) {
      console.error('Error listing users:', error);
      return { error: error.message };
    }

    return { users: data || [] };
  } catch (error: any) {
    return { error: error.message };
  }
}

