import { supabase } from '../lib/supabase';

export interface CustomerProfileRow {
  id: string;
  full_name?: string | null;
  email?: string | null;
  phone?: string | null;
}

export async function fetchProfilesByIds(ids: string[]): Promise<Map<string, CustomerProfileRow>> {
  if (!ids.length) {
    return new Map();
  }

  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('id, full_name, email, phone')
      .in('id', ids);

    if (error || !data) {
      if (error) {
        console.warn('[customerProfiles] fetchProfilesByIds error:', error);
      }
      return new Map();
    }

    const map = new Map<string, CustomerProfileRow>();
    data.forEach((profile) => {
      if (profile?.id) {
        map.set(profile.id, profile as CustomerProfileRow);
      }
    });
    return map;
  } catch (err) {
    console.warn('[customerProfiles] fetchProfilesByIds exception:', err);
    return new Map();
  }
}

export async function fetchProfileById(id?: string | null): Promise<CustomerProfileRow | null> {
  if (!id) return null;
  const map = await fetchProfilesByIds([id]);
  return map.get(id) ?? null;
}
