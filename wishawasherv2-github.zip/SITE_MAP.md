# Wish a Wash - Complete Site Map & Documentation

Complete route structure, file organization, and backend integration guide for the Wish a Wash application.

## Table of Contents
1. [Route Structure](#route-structure)
2. [File Organization](#file-organization)
3. [Backend Integration](#backend-integration)
4. [Database Schema](#database-schema)
5. [Services & Utilities](#services--utilities)

---

## Route Structure

### Entry Points
- `/` - Main entry point (routes to dashboards based on user type)
- `/onboarding` - General onboarding
- `/site-map` - Site map and documentation (this page)

### Authentication Routes
- `/auth/login` - User login
- `/auth/signup` - User registration

### Customer/Owner Routes (`/owner/`)

#### Dashboards & Main
- `/owner/owner-dashboard` - Customer dashboard (home)
- `/owner/customer-onboarding` - Customer onboarding flow

#### Booking Flows

**Main Booking**
- `/owner/booking` - Booking type selection (Valeter, Physical Hub, Eco, Detailing)
- `/owner/booking/create` - Create valeter booking (vehicle selection)
- `/owner/booking/location` - Select location for valeter booking (map view)
- `/owner/booking/valeter-selection` - Select a valeter
- `/owner/booking/waiting-acceptance` - Waiting for valeter acceptance
- `/owner/booking/payment` - Payment processing
- `/owner/booking/tracking` - Track active booking
- `/owner/booking/completion` - Booking completion

**Physical Hub Booking**
- `/owner/booking/physical/location` - Choose physical hub
- `/owner/booking/physical/service` - Select service
- `/owner/booking/physical/vehicle` - Select vehicle
- `/owner/booking/physical/schedule` - Pick service & time slot
- `/owner/booking/physical/confirm` - Confirm booking
- `/owner/booking/physical/confirmation` - Booking confirmed

**Eco Wash Booking**
- `/owner/booking/eco` - Eco wash info & delivery choice
- `/owner/booking/eco/create` - Select eco service (They Come to You)
- `/owner/booking/eco/vehicle` - Select vehicle
- `/owner/booking/eco/service` - Select eco service
- `/owner/booking/eco/location` - Choose eco hub (map view)
- `/owner/booking/eco/schedule` - Pick service & time
- `/owner/booking/eco/valeter-selection` - Select eco valeter
- `/owner/booking/eco/confirm` - Confirm eco booking
- `/owner/booking/eco/confirmation` - Eco booking confirmed

**Detailing Booking**
- `/owner/booking/detailing` - Detailing info & delivery choice
- `/owner/booking/detailing/create` - Select detailing service (They Come to You)
- `/owner/booking/detailing/vehicle` - Select vehicle
- `/owner/booking/detailing/service` - Select detailing service
- `/owner/booking/detailing/location` - Choose detailing hub (map view)
- `/owner/booking/detailing/schedule` - Schedule appointment
- `/owner/booking/detailing/valeter-selection` - Select detailing valeter
- `/owner/booking/detailing/confirm` - Confirm detailing
- `/owner/booking/detailing/confirmation` - Detailing confirmed

#### History & Reviews
- `/owner/wash-history` - View booking history
- `/owner/wash-rating` - Rate completed service

#### Profile & Settings
- `/owner/owner-profile` - Customer profile management
- `/owner/settings/vehicle-management` - Manage vehicles
- `/owner/settings/payment-methods` - Manage payment methods
- `/owner/settings/privacy-settings` - Privacy settings

#### Features
- `/owner/features/rewards` - Rewards program
- `/owner/features/favourites` - Favourite valeters/locations
- `/owner/features/notifications` - Notifications centre
- `/owner/features/referral-system` - Referral system
- `/owner/features/promotions` - Promotions & offers
- `/owner/features/subscriptions` - Subscription plans
- `/owner/features/become-valeter` - Become a valeter

#### Analytics
- `/owner/analytics/owner-analytics` - Customer analytics

#### Support
- `/owner/support/help-support` - Help & support
- `/owner/support/report-issue` - Report an issue
- `/owner/support/request-refund` - Request refund

### Valeter Routes (`/valeter/`)

#### Dashboards & Main
- `/valeter/valeter-dashboard` - Valeter dashboard (home)
- `/valeter/valeter-welcome` - Valeter welcome screen
- `/valeter/valeter-onboarding` - Valeter onboarding flow

#### Jobs
- `/valeter/jobs/queue` - Available jobs queue
- `/valeter/jobs/accept` - Accept a job
- `/valeter/jobs/tracking` - Track active job
- `/valeter/jobs/complete` - Complete job
- `/valeter/jobs/completion-upload` - Upload completion photos

#### Profile & Settings
- `/valeter/profile/valeter-profile` - Valeter profile
- `/valeter/profile/valeter-detail-profile` - Detailed profile view
- `/valeter/profile/valeter-personal-info` - Personal information
- `/valeter/profile/valeter-vehicle-info` - Vehicle information
- `/valeter/profile/valeter-documents` - Document management
- `/valeter/profile/valeter-legal-compliance` - Legal compliance
- `/valeter/settings/distance-covering` - Distance covering settings

#### Features
- `/valeter/valeter-wash-history` - Earnings & history
- `/valeter/valeter-rewards-system` - Rewards program
- `/valeter/valeter-analytics` - Analytics
- `/valeter/features/referral-system` - Referral system
- `/valeter/notifications` - Notifications

### Business/Organization Routes (`/business/`)

#### Dashboards & Main
- `/business/dashboard` - Main business dashboard (home)
- `/business/onboarding` - Business onboarding flow

#### Management
- `/business/locations` - Location management list
- `/business/bookings` - All bookings view
- `/business/team` - Team management
- `/business/team/invite` - Invite valeter form
- `/business/team/requests` - Valeter requests list
- `/business/services` - Services & pricing management
- `/business/analytics` - Analytics dashboard
- `/business/earnings` - Earnings overview
- `/business/coverage` - Coverage area management
- `/business/time-tracking` - Time tracking
- `/business/issues` - Issues & support
- `/business/notifications` - Notifications
- `/business/settings` - Business settings
- `/business/profile` - Business profile
- `/business/privacy` - Privacy settings

### Legal & Policy
- `/terms-of-service` - Terms of service
- `/privacy-policy` - Privacy policy

---

## File Organization

### Directory Structure

```
/
├── app/                          # Expo Router pages (file-based routing)
│   ├── _layout.tsx              # Root layout with navigation
│   ├── index.tsx                # Entry point
│   ├── onboarding.tsx           # General onboarding
│   ├── site-map.tsx             # Site map & documentation
│   ├── auth/                    # Authentication pages
│   ├── owner/                   # Customer pages
│   │   ├── owner-dashboard.tsx
│   │   ├── booking/            # All booking flows
│   │   ├── features/           # Customer features
│   │   ├── settings/          # Customer settings
│   │   └── support/           # Support pages
│   ├── valeter/                # Valeter pages
│   │   ├── valeter-dashboard.tsx
│   │   ├── jobs/              # Job management
│   │   ├── profile/          # Profile management
│   │   └── features/         # Valeter features
│   ├── business/              # Business pages
│   │   ├── dashboard.tsx
│   │   ├── team/             # Team management
│   │   └── ...               # Business features
│   └── components/            # App-level components
│       └── NavigationTab.tsx  # Bottom navigation
│
├── src/                        # Source code
│   ├── components/            # Reusable React components
│   │   ├── booking/          # Booking-related components
│   │   ├── dashboard/        # Dashboard components
│   │   ├── shared/           # Shared UI components
│   │   ├── valeter/          # Valeter-specific components
│   │   └── wash/            # Wash-related components
│   ├── services/             # Business logic & API services
│   ├── lib/                  # Core libraries
│   │   └── supabase.ts      # Supabase client & types
│   ├── providers/            # React context providers
│   ├── hooks/               # Custom React hooks
│   ├── constants/           # App constants & themes
│   ├── types/              # TypeScript type definitions
│   ├── utils/              # Utility functions
│   └── config/             # Configuration files
│
└── assets/                   # Static assets (images, fonts)
```

### Key File Categories

#### Pages (`app/`)
- **File-based routing**: Each `.tsx` file in `app/` becomes a route
- **Nested routes**: Folders create nested routes (e.g., `app/owner/booking/create.tsx` → `/owner/booking/create`)
- **Layouts**: `_layout.tsx` files define layouts for route groups

#### Components (`src/components/`)
- **Shared components**: Reusable UI elements in `shared/`
- **Feature components**: Feature-specific components in subdirectories
- **Dashboard components**: Dashboard-specific UI in `dashboard/`

#### Services (`src/services/`)
- **Business logic**: All backend integration logic
- **API calls**: Supabase queries and mutations
- **Data processing**: Business rules and calculations

#### Providers (`src/providers/`)
- **Auth context**: User authentication state (`enhanced-auth-context.tsx`)
- **AI chat context**: AI chat functionality (`AIChatContext.tsx`)

#### Constants (`src/constants/`)
- **Themes**: UI themes for different user types
- **Colors**: App-wide color definitions
- **Service options**: Service definitions and pricing

---

## Backend Integration

### Supabase Connection

**File**: `src/lib/supabase.ts`

```typescript
import { supabase } from '../../src/lib/supabase';

// All database queries use this client
const { data, error } = await supabase
  .from('table_name')
  .select('*')
  .eq('column', 'value');
```

### Database Tables

#### Core Tables

1. **`users`** / **`profiles`**
   - **Purpose**: User accounts and profile information
   - **Key Fields**: `id`, `email`, `user_type`, `tier`, `tier_points`
   - **Used By**: Authentication, profiles, dashboards
   - **Integration**: `src/providers/enhanced-auth-context.tsx`

2. **`bookings`**
   - **Purpose**: All booking records
   - **Key Fields**: `id`, `user_id`, `valeter_id`, `status`, `price`, `location_*`
   - **Used By**: Booking flows, history, tracking
   - **Integration**: `src/services/BookingService.ts`, booking pages

3. **`valeter_profiles`**
   - **Purpose**: Valeter-specific profile data
   - **Key Fields**: `user_id`, `working_radius`, `is_online`, `documents`
   - **Used By**: Valeter dashboards, job queue
   - **Integration**: `app/valeter/valeter-dashboard.tsx`

4. **`valeter_presence`**
   - **Purpose**: Real-time valeter location and online status
   - **Key Fields**: `user_id`, `is_online`, `last_lat`, `last_lng`
   - **Used By**: Job queue, nearby valeters, tracking
   - **Integration**: `src/hooks/useLiveLocation.ts`, dashboards

5. **`organizations`**
   - **Purpose**: Business/organization accounts
   - **Key Fields**: `id`, `name`, `address`, `is_verified`
   - **Used By**: Business dashboards, team management
   - **Integration**: `app/business/dashboard.tsx`

6. **`car_wash_locations`**
   - **Purpose**: Physical wash hub locations
   - **Key Fields**: `id`, `name`, `address`, `latitude`, `longitude`, `organization_id`
   - **Used By**: Physical booking flows, location selection
   - **Integration**: Physical booking pages

7. **`customer_vehicles`**
   - **Purpose**: Customer vehicle information
   - **Key Fields**: `user_id`, `make`, `model`, `registration`, `tax_expiry`, `mot_expiry`
   - **Used By**: Vehicle management, booking flows
   - **Integration**: `app/owner/settings/vehicle-management.tsx`

8. **`wash_completions`**
   - **Purpose**: Completed wash records with photos and ratings
   - **Key Fields**: `id`, `status`, `photos`, `rating`, `customer_review`
   - **Used By**: Wash history, ratings
   - **Integration**: `app/owner/wash-history.tsx`

### Service Files & Backend Integration

#### Authentication
- **File**: `src/providers/enhanced-auth-context.tsx`
- **Tables**: `profiles`, `users` (via Supabase Auth)
- **Functions**: Login, signup, profile management

#### Bookings
- **File**: `src/services/BookingService.ts`
- **Tables**: `bookings`
- **Functions**: Create, update, query bookings, real-time subscriptions

#### Valeter Services
- **File**: `src/services/ValeterStatusService.ts`
- **Tables**: `valeter_presence`, `valeter_profiles`
- **Functions**: Online/offline status, location updates

#### Payments
- **File**: `src/services/PaymentSystem.ts`, `src/services/StripePaymentService.ts`
- **Tables**: `bookings` (payment status)
- **Functions**: Process payments, handle commissions

#### Documents
- **File**: `src/services/DocumentUploadService.ts`
- **Tables**: `valeter_profiles` (documents field)
- **Functions**: Upload license, insurance, background checks

#### Notifications
- **File**: `app/owner/features/notifications.tsx`
- **Tables**: `bookings`, `customer_vehicles`, `users`
- **Functions**: Fetch notifications, real-time updates

### Real-time Subscriptions

**Pattern**: Subscribe to database changes for live updates

```typescript
// Example from BookingService.ts
const channel = supabase
  .channel(`bookings:user:${userId}`)
  .on('postgres_changes', {
    event: '*',
    schema: 'public',
    table: 'bookings',
    filter: `user_id=eq.${userId}`
  }, (payload) => {
    // Handle update
  })
  .subscribe();
```

### Common Query Patterns

#### Fetch User Bookings
```typescript
const { data } = await supabase
  .from('bookings')
  .select('*')
  .eq('user_id', userId)
  .order('created_at', { ascending: false });
```

#### Fetch Nearby Valeters
```typescript
const { data } = await supabase
  .from('valeter_presence')
  .select('user_id, is_online, last_lat, last_lng')
  .eq('is_online', true);
```

#### Update Booking Status
```typescript
await supabase
  .from('bookings')
  .update({ status: 'completed', completed_at: new Date().toISOString() })
  .eq('id', bookingId);
```

---

## Database Schema

### Primary Tables

#### `profiles` / `users`
- Stores user account information
- Links to Supabase Auth users
- Contains user type, tier, points, verification status

#### `bookings`
- Core booking table
- Status flow: `pending` → `pending_valeter_acceptance` → `confirmed` → `en_route` → `arrived` → `in_progress` → `completed`
- Links customers (`user_id`) to valeters (`valeter_id`)

#### `valeter_presence`
- Real-time valeter location and status
- Updated via `update_my_presence` RPC function
- Used for job matching and distance calculations

#### `organizations`
- Business/organization accounts
- Links to `profiles` via `organization_id`
- Contains business verification and location data

#### `car_wash_locations`
- Physical wash hub locations
- Belongs to organizations
- Used in physical booking flows

#### `customer_vehicles`
- Customer vehicle registry
- Includes tax/MOT expiry for reminders
- Used in booking flows for vehicle selection

#### `wash_completions`
- Completed wash records
- Contains photos, ratings, reviews
- Used in history and analytics

### Relationships

```
profiles (users)
  ├── bookings (user_id) → bookings
  ├── customer_vehicles (user_id) → customer_vehicles
  └── organization_id → organizations

bookings
  ├── user_id → profiles (customer)
  └── valeter_id → profiles (valeter)

valeter_presence
  └── user_id → profiles (valeter)

organizations
  └── id → profiles.organization_id

car_wash_locations
  └── organization_id → organizations
```

---

## Services & Utilities

### Service Files (`src/services/`)

#### Core Services
- **`BookingService.ts`**: Booking CRUD operations, real-time subscriptions
- **`PaymentSystem.ts`**: Payment processing logic
- **`StripePaymentService.ts`**: Stripe integration
- **`ValeterStatusService.ts`**: Valeter online/offline management
- **`DocumentUploadService.ts`**: Document upload to Supabase Storage

#### Feature Services
- **`RewardSystem.ts`**: Points, tiers, rewards calculation
- **`BadgeService.ts`**: Badge system for valeters
- **`AIChatService.ts`**: AI chat functionality
- **`AISchedulingService.ts`**: AI scheduling suggestions
- **`JobLifecycleService.ts`**: Job state management

#### Utility Services
- **`HapticFeedbackService.ts`**: Haptic feedback helpers
- **`FileUploadService.ts`**: File upload utilities
- **`ErrorHandlingService.ts`**: Error handling utilities
- **`registerPushToken.ts`**: Push notification registration

### Utility Files (`src/utils/`)

- **`timeSlots.ts`**: Generate time slots for scheduling
- **`ChatService.ts`**: Chat message handling
- **`checkUserType.ts`**: User type validation
- **`customerProfiles.ts`**: Customer profile helpers
- **`radiusPreference.ts`**: Valeter radius preference management

### Hooks (`src/hooks/`)

- **`useLiveLocation.ts`**: Real-time location tracking
- **`useOfflineMode.ts`**: Offline mode handling
- **`useCodeSplitting.ts`**: Code splitting utilities

### Constants (`src/constants/`)

- **`colors.ts`**: App-wide color palette
- **`accountThemes.ts`**: Theme definitions per user type
- **`customerTheme.ts`**: Customer-specific theme
- **`serviceOptions.ts`**: Service definitions and pricing
- **`cardSizes.ts`**: Card size constants

---

## Navigation Structure

### Bottom Navigation Tabs

#### Customer Tabs
1. **Home** → `/owner/owner-dashboard`
2. **Book** → `/owner/booking`
3. **History** → `/owner/wash-history`
4. **Rewards** → `/owner/features/rewards`
5. **Profile** → `/owner/owner-profile`

#### Valeter Tabs
1. **Home** → `/valeter/valeter-dashboard`
2. **Jobs** → `/valeter/jobs/queue`
3. **Trip** → `/valeter/jobs/tracking`
4. **Earnings** → `/valeter/valeter-wash-history`
5. **Profile** → `/valeter/profile/valeter-profile`

#### Business Tabs
1. **Home** → `/business/dashboard`
2. **Analytics** → `/business/analytics`
3. **Team** → `/business/team`
4. **Settings** → `/business/settings`
5. **Profile** → `/business/profile`

---

## Backend Integration Points

### How to Connect Backend Logic

1. **Import Supabase Client**
   ```typescript
   import { supabase } from '../../src/lib/supabase';
   ```

2. **Query Data**
   ```typescript
   const { data, error } = await supabase
     .from('table_name')
     .select('columns')
     .eq('filter_column', 'value');
   ```

3. **Insert Data**
   ```typescript
   const { data, error } = await supabase
     .from('table_name')
     .insert({ column: 'value' })
     .select();
   ```

4. **Update Data**
   ```typescript
   await supabase
     .from('table_name')
     .update({ column: 'new_value' })
     .eq('id', recordId);
   ```

5. **Real-time Subscriptions**
   ```typescript
   const channel = supabase
     .channel('channel_name')
     .on('postgres_changes', {
       event: '*',
       schema: 'public',
       table: 'table_name',
       filter: 'column=eq.value'
     }, (payload) => {
       // Handle change
     })
     .subscribe();
   ```

### Service Layer Pattern

All backend logic should go through service files:

1. **Create service file** in `src/services/`
2. **Export functions** that wrap Supabase queries
3. **Import in pages** and call service functions
4. **Handle errors** consistently

Example:
```typescript
// src/services/MyService.ts
export async function fetchUserData(userId: string) {
  const { data, error } = await supabase
    .from('users')
    .select('*')
    .eq('id', userId)
    .single();
  
  if (error) throw error;
  return data;
}

// In page component
import { fetchUserData } from '../../src/services/MyService';
const data = await fetchUserData(user.id);
```

---

## Summary

- **Total Routes**: ~100+ pages
- **Components**: 30+ reusable components
- **Services**: 20+ service files
- **Database Tables**: 10+ primary tables
- **User Types**: Customer, Valeter, Business
- **Backend**: Supabase (PostgreSQL + Real-time + Storage)

**Last Updated**: Current codebase structure
