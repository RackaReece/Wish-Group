# Fix for current runtime errors

If you still see these errors after clearing Metro cache (`npx expo start -c`), apply these edits:

## 1. dashboard.tsx – `businessTheme` doesn't exist (line ~766)

**Fix:** Use `theme` instead of `businessTheme` in JSX.  
Replace every `colors={businessTheme.background}` with `colors={theme.background}`.  
(You already have `const theme = businessTheme ?? getAccountTheme('business', 'light');` – use `theme` in the render.)

## 2. settings.tsx – `Switch` doesn't exist (line ~261)

**Fix:** Import `Switch` from React Native.  
In the top import from `'react-native'`, add `Switch` to the list, e.g.:
```ts
import { View, Text, StyleSheet, ..., Switch } from 'react-native';
```

## 3. bookings.tsx – `SKY` / `theme` doesn't exist (StyleSheet)

**Fix:** At the top of the file (with other constants), ensure you have:
```ts
const SKY = colors.SKY;
const BUSINESS_PRIMARY = getAccountTheme('business').primary;
```
In `StyleSheet.create()`, do **not** use `theme` or `businessTheme` (they exist only inside the component).  
Use `SKY` for `loadingText.color` and use `BUSINESS_PRIMARY` for any `backgroundColor` or `color` that was `theme.primary`.

## 4. earnings.tsx – `SKY` / `theme` in StyleSheet

**Fix:** Same as bookings – at top:
```ts
const SKY = colors.SKY;
const BUSINESS_PRIMARY = getAccountTheme('business').primary;
```
In styles, use `SKY` and `BUSINESS_PRIMARY` instead of `theme.primary` (e.g. `loadingText.color: SKY`, `borderColor: \`${BUSINESS_PRIMARY}4D\``).

## 5. locations.tsx – `businessTheme.primary` in StyleSheet

**Fix:** At top add `const BUSINESS_PRIMARY = getAccountTheme('business').primary;`  
In styles replace `shadowColor: businessTheme.primary` or `shadowColor: theme.primary` with `shadowColor: BUSINESS_PRIMARY`.

## 6. notifications.tsx – `BubbleBackground` already declared (line ~27)

**Fix:** Remove the **duplicate** import. You should have only **one** line:
```ts
import BubbleBackground from '../../src/components/shared/BubbleBackground';
```
Delete the second occurrence (the one that appears after `useAccountTheme`).

---

Then restart with cache clear: `npx expo start -c`.
