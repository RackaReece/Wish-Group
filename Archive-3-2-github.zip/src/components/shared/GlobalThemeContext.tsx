import React, { createContext, useContext, useState, ReactNode } from 'react';
import { ThemeMode } from '../../constants/accountThemes';

interface GlobalThemeContextValue {
  mode: ThemeMode;
  setMode: (mode: ThemeMode) => void;
  toggleMode: () => void;
}

const GlobalThemeContext = createContext<GlobalThemeContextValue | undefined>(undefined);

export function GlobalThemeProvider({ children, initialMode = 'dark' }: { children: ReactNode; initialMode?: ThemeMode }) {
  const [mode, setModeState] = useState<ThemeMode>(initialMode);

  const toggleMode = () => {
    setModeState(prev => prev === 'light' ? 'dark' : 'light');
  };

  const setMode = (newMode: ThemeMode) => {
    setModeState(newMode);
  };

  return (
    <GlobalThemeContext.Provider value={{ mode, setMode, toggleMode }}>
      {children}
    </GlobalThemeContext.Provider>
  );
}

export function useGlobalTheme(): GlobalThemeContextValue {
  const context = useContext(GlobalThemeContext);
  if (!context) {
    return {
      mode: 'dark',
      setMode: () => {},
      toggleMode: () => {},
    };
  }
  return context;
}
