import React, { createContext, useContext, ReactNode } from 'react';
import { AccountType, getAccountTheme, AccountTheme, ThemeMode } from '../../constants/accountThemes';
import { useGlobalTheme } from './GlobalThemeContext';

interface AccountThemeContextValue {
  accountType: AccountType;
  theme: AccountTheme;
  mode: ThemeMode;
  toggleMode: () => void;
  setMode: (mode: ThemeMode) => void;
}

const AccountThemeContext = createContext<AccountThemeContextValue | undefined>(undefined);

interface AccountThemeProviderProps {
  accountType: AccountType;
  children: ReactNode;
  // initialMode removed as it's handled globally
}

export function AccountThemeProvider({ accountType, children }: AccountThemeProviderProps) {
  const { mode, toggleMode, setMode } = useGlobalTheme();
  const theme = getAccountTheme(accountType, mode);

  return (
    <AccountThemeContext.Provider value={{ accountType, theme, mode, toggleMode, setMode }}>
      {children}
    </AccountThemeContext.Provider>
  );
}

export function useAccountTheme(): AccountThemeContextValue {
  const context = useContext(AccountThemeContext);
  if (!context) {
    // Default to customer theme if no provider
    return {
      accountType: 'customer',
      theme: getAccountTheme('customer'),
      mode: 'dark',
      toggleMode: () => {},
      setMode: () => {},
    };
  }
  return context;
}

