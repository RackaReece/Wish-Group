import React from 'react';
import Svg, { Defs, Path, Filter, FeGaussianBlur, FeOffset, FeFlood, FeComposite, FeMerge, FeMergeNode } from 'react-native-svg';
import type { IconProps } from './IconProps';

export default function IconCar({ size = 24, color = '#F9FAFB', style }: IconProps) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={style}>
      <Defs>
        <Filter id="shadow-car" x="-20%" y="-20%" width="140%" height="140%">
          <FeGaussianBlur in="SourceAlpha" stdDeviation="1.8" />
          <FeOffset dx="0" dy="2" result="offsetblur" />
          <FeFlood floodColor="rgba(0,0,0,0.22)" floodOpacity="1" />
          <FeComposite in2="offsetblur" operator="in" />
          <FeMerge>
            <FeMergeNode />
            <FeMergeNode in="SourceGraphic" />
          </FeMerge>
        </Filter>
      </Defs>
      <Path
        d="M18 17h1v-4l-2.5-4.5h-9L5 13v4h1v-2h10v2zm-10-5l1.5-2.5h3L13 12H8zm-2 3a1.5 1.5 0 110-3 1.5 1.5 0 010 3zm10 0a1.5 1.5 0 110-3 1.5 1.5 0 010 3z"
        fill={color}
        fillRule="evenodd"
        filter="url(#shadow-car)"
      />
    </Svg>
  );
}
