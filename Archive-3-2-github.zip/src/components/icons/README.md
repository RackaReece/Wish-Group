# Custom SVG Icons

**Do NOT use** Material, Feather, Ionicons, or SF Symbols. Use these custom SVG illustration icons instead.

## Design spec

- **Flat solid fills** – solid colors, no gradients
- **Rounded geometry** – soft curves, rounded corners
- **Soft shadows** – pronounced drop shadow (stdDeviation 1.8, dy 2, rgba 0.22) for subtle 3D lift

## Usage

```tsx
import { IconHome, IconCar, IconClose } from '../components/icons';

<IconHome size={24} color="#87CEEB" />
<IconCar size={20} color={theme.primary} style={{ marginRight: 8 }} />
```

## Available icons

- `IconHome` – Home / dashboard
- `IconCar` – Vehicle / jobs
- `IconNavigate` – Navigation / trips
- `IconTime` – Time / hours
- `IconPerson` – Profile / user
- `IconLocation` – Location / map pin
- `IconCalendar` – Calendar / bookings
- `IconPeople` – Team / group
- `IconChevronBack` – Back navigation
- `IconChevronForward` – Forward / next
- `IconClose` – Close / dismiss
- `IconInfo` – Information
- `IconSettings` – Settings / gear
- `IconTrophy` – Trophy / rewards
- `IconNotifications` – Bell / alerts
- `IconLeaf` – Leaf / eco / environmental

## Adding new icons

1. Create `IconName.tsx` in this folder.
2. Use `react-native-svg` (Svg, Path, Circle, Defs, Filter, etc.).
3. Accept `IconProps`: `size?`, `color?`, `style?`.
4. Use flat fills, rounded geometry, and optional soft shadow filter.
5. Export from `index.ts`.
