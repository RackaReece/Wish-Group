import React from 'react';
import Svg, { Defs, Path, Filter, FeGaussianBlur, FeOffset, FeFlood, FeComposite, FeMerge, FeMergeNode } from 'react-native-svg';
import type { IconProps } from './IconProps';

/** Stylized leaf - rounded organic shape, smooth curves, flat solid fill, soft shadow */
export default function IconLeaf({ size = 24, color = '#F9FAFB', style }: IconProps) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={style}>
      <Defs>
        <Filter id="shadow-leaf" x="-30%" y="-20%" width="160%" height="160%">
          <FeGaussianBlur in="SourceAlpha" stdDeviation="1.8" />
          <FeOffset dx="0" dy="2" result="offsetblur" />
          <FeFlood floodColor="rgba(0,0,0,0.22)" floodOpacity="1" />
          <FeComposite in2="offsetblur" operator="in" />
          <FeMerge>
            <FeMergeNode />
            <FeMergeNode in="SourceGraphic" />
          </FeMerge>
        </Filter>
      </Defs>
      <Path
        d="M17 8C8 10 5.9 16.2 4 20c2.5-3.5 6-5.1 7.5-5.1 1.5 0 4 1.5 5.5 4 1.6 2.6 2.1 5.6 2.1 5.6s-2.1-3-3.1-4.5c-1-1.5-2.5-2.5-4-2.5-.9 0-2 .4-2.8 1.2C8.9 13 8 14.8 8 17c0 0 2-6 9-9z"
        fill={color}
        fillRule="evenodd"
        filter="url(#shadow-leaf)"
      />
    </Svg>
  );
}
