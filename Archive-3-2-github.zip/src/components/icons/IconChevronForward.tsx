import React from 'react';
import Svg, { Defs, Path, Filter, FeGaussianBlur, FeOffset, FeFlood, FeComposite, FeMerge, FeMergeNode } from 'react-native-svg';
import type { IconProps } from './IconProps';

export default function IconChevronForward({ size = 24, color = '#F9FAFB', style }: IconProps) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={style}>
      <Defs>
        <Filter id="shadow-chevf" x="-20%" y="-20%" width="140%" height="140%">
          <FeGaussianBlur in="SourceAlpha" stdDeviation="1.8" />
          <FeOffset dx="0" dy="2" result="offsetblur" />
          <FeFlood floodColor="rgba(0,0,0,0.22)" floodOpacity="1" />
          <FeComposite in2="offsetblur" operator="in" />
          <FeMerge>
            <FeMergeNode />
            <FeMergeNode in="SourceGraphic" />
          </FeMerge>
        </Filter>
      </Defs>
      <Path
        d="M8.6 18l6-6-6-6"
        stroke={color}
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
        filter="url(#shadow-chevf)"
      />
    </Svg>
  );
}
