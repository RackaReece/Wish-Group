import React from 'react';
import Svg, { Defs, Path, Filter, FeGaussianBlur, FeOffset, FeFlood, FeComposite, FeMerge, FeMergeNode } from 'react-native-svg';
import type { IconProps } from './IconProps';

export default function IconTrophy({ size = 24, color = '#FFD700', style }: IconProps) {
  return (
    <Svg width={size} height={size} viewBox="0 0 24 24" fill="none" style={style}>
      <Defs>
        <Filter id="shadow-trophy" x="-20%" y="-20%" width="140%" height="140%">
          <FeGaussianBlur in="SourceAlpha" stdDeviation="1.8" />
          <FeOffset dx="0" dy="2" result="offsetblur" />
          <FeFlood floodColor="rgba(0,0,0,0.22)" floodOpacity="1" />
          <FeComposite in2="offsetblur" operator="in" />
          <FeMerge>
            <FeMergeNode />
            <FeMergeNode in="SourceGraphic" />
          </FeMerge>
        </Filter>
      </Defs>
      <Path
        d="M19 5h-2V3H7v2H5c-1.1 0-2 .9-2 2v1c0 2.55 1.92 4.63 4.39 4.94.63 1.5 1.98 2.63 3.61 2.96V19H7v2h10v-2h-4v-3.1c1.63-.33 2.98-1.46 3.61-2.96C19.08 12.63 21 10.55 21 8V7c0-1.1-.9-2-2-2zM5 8V7h2v3.82C5.84 10.4 5 9.3 5 8zm14 0c0 1.3-.84 2.4-2 2.82V7h2v1z"
        fill={color}
        fillRule="evenodd"
        filter="url(#shadow-trophy)"
      />
    </Svg>
  );
}
