import React from 'react';
import { View, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { AccountType, getAccountTheme } from '../../constants/accountThemes';
import { CARD_BORDER_RADIUS } from '../../constants/colors';
import { useAccountTheme } from '../shared/AccountThemeProvider';

interface GlassCardProps {
  children: React.ReactNode;
  onPress?: () => void;
  style?: ViewStyle;
  intensity?: number;
  tint?: 'light' | 'dark' | 'default';
  borderColor?: string;
  accountType?: AccountType;
}

export default function GlassCard({ 
  children, 
  onPress, 
  style, 
  intensity = 40,
  tint = 'dark',
  borderColor,
  accountType
}: GlassCardProps) {
  // Use account theme if provided, otherwise try to get from context, otherwise default to customer
  const contextTheme = useAccountTheme();
  const theme = accountType 
    ? getAccountTheme(accountType, contextTheme.mode)
    : contextTheme.theme;
  
  const isLightMode = theme.mode === 'light';
  const finalBorderColor = borderColor || theme.cardBorder || theme.glassBorder;
  const noBorder = isLightMode && (theme.glassBorder === 'transparent' || !theme.glassBorder);
  const finalTint = isLightMode ? 'light' : tint;
  const finalIntensity = isLightMode ? 80 : intensity;

  const gradientColors = isLightMode 
    ? (theme.cardBackgroundGradient || ['rgba(255,255,255,0.9)', 'rgba(255,255,255,0.7)'])
    : (theme.cardBackgroundGradient || ['rgba(255,255,255,0.1)', 'rgba(255,255,255,0.05)']);

  const content = (
    <BlurView
      intensity={finalIntensity}
      tint={finalTint}
      style={[
        styles.blurContainer,
        noBorder && styles.blurContainerNoBorder,
        !noBorder && { borderColor: finalBorderColor },
        style,
      ]}
    >
      <LinearGradient
        colors={gradientColors}
        style={StyleSheet.absoluteFill}
      />
      {children}
    </BlurView>
  );

  if (onPress) {
    return (
      <TouchableOpacity activeOpacity={0.8} onPress={onPress}>
        {content}
      </TouchableOpacity>
    );
  }

  return content;
}

const styles = StyleSheet.create({
  blurContainer: {
    borderRadius: CARD_BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    elevation: 8,
    shadowColor: 'transparent',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0,
    shadowRadius: 12,
  },
  blurContainerNoBorder: {
    borderWidth: 0,
  },
});

