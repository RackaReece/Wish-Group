import { Linking, Platform } from 'react-native';

/**
 * Opens the device's maps app for turn-by-turn navigation to the given destination.
 * - iOS: Apple Maps (http://maps.apple.com/?daddr=...)
 * - Android: Google Maps navigation (google.navigation:q=...)
 * - Fallback: Google Maps web URL (opens in browser / can open in app)
 */
export function openTurnByTurnNavigation(
  latitude: number,
  longitude: number,
  address?: string | null
): void {
  const dest = address?.trim()
    ? encodeURIComponent(address)
    : `${latitude},${longitude}`;

  let url: string;

  if (Platform.OS === 'ios') {
    // Apple Maps: daddr can be "lat,lng" or address
    url = `http://maps.apple.com/?daddr=${dest}&dirflg=d`;
  } else if (Platform.OS === 'android') {
    // Google Maps turn-by-turn; use coordinates for reliability
    url = `google.navigation:q=${latitude},${longitude}&mode=d`;
  } else {
    url = `https://www.google.com/maps/dir/?api=1&destination=${latitude},${longitude}&travelmode=driving`;
  }

  Linking.openURL(url).catch((err) =>
    console.warn('[openTurnByTurnNavigation]', err)
  );
}
