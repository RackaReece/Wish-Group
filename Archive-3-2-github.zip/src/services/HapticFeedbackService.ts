// src/services/HapticFeedbackService.ts
import * as Haptics from 'expo-haptics';

type Impact = 'light' | 'medium' | 'heavy' | 'soft' | 'rigid' | 'success' | 'error';

const map: Record<Impact, Haptics.ImpactFeedbackStyle> = {
  light: Haptics.ImpactFeedbackStyle.Light,
  medium: Haptics.ImpactFeedbackStyle.Medium,
  heavy: Haptics.ImpactFeedbackStyle.Heavy,
  soft: Haptics.ImpactFeedbackStyle.Soft,
  rigid: Haptics.ImpactFeedbackStyle.Rigid,
  success: Haptics.ImpactFeedbackStyle.Light,
  error: Haptics.ImpactFeedbackStyle.Heavy,
};

export async function hapticFeedback(kind: Impact = 'light') {
  await Haptics.impactAsync(map[kind]);
}
