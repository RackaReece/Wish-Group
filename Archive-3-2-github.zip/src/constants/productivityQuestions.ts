/**
 * Productivity / daily goals for valeters.
 * 50+ questions: car care + well-being. Each day of the week (0=Sun … 6=Sat) has its own set.
 * Goals reset automatically each day (storage key includes date).
 */

export interface ProductivityGoalTemplate {
  id: string;
  title: string;
  icon: string;
  /** 0 = Sunday, 1 = Monday, … 6 = Saturday */
  dayOfWeek: number;
}

/** All productivity goals by day. Over 50 total; each day has 8 goals. */
export const PRODUCTIVITY_GOALS_BY_DAY: ProductivityGoalTemplate[] = [
  // Sunday (0) – 8
  { id: 'sun_1', title: 'Check wash mitts and drying towels are clean', icon: 'water-outline', dayOfWeek: 0 },
  { id: 'sun_2', title: 'Rest and recharge for the week ahead', icon: 'bed-outline', dayOfWeek: 0 },
  { id: 'sun_3', title: 'Plan your week’s jobs and routes', icon: 'map-outline', dayOfWeek: 0 },
  { id: 'sun_4', title: 'Stay hydrated throughout the day', icon: 'water-outline', dayOfWeek: 0 },
  { id: 'sun_5', title: 'Review any customer feedback from last week', icon: 'chatbubble-ellipses-outline', dayOfWeek: 0 },
  { id: 'sun_6', title: 'Check your vehicle’s fuel and fluids', icon: 'car-outline', dayOfWeek: 0 },
  { id: 'sun_7', title: 'Stretch before starting any physical work', icon: 'body-outline', dayOfWeek: 0 },
  { id: 'sun_8', title: 'Confirm tomorrow’s bookings are in your calendar', icon: 'calendar-outline', dayOfWeek: 0 },
  // Monday (1) – 8
  { id: 'mon_1', title: 'Check stock levels of shampoo and wax', icon: 'flask-outline', dayOfWeek: 1 },
  { id: 'mon_2', title: 'Take a short break after every 2 cars', icon: 'cafe-outline', dayOfWeek: 1 },
  { id: 'mon_3', title: 'Inspect buckets and hoses for damage', icon: 'construct-outline', dayOfWeek: 1 },
  { id: 'mon_4', title: 'Use two-bucket method for every wash', icon: 'water-outline', dayOfWeek: 1 },
  { id: 'mon_5', title: 'Eat a proper lunch away from the work area', icon: 'nutrition-outline', dayOfWeek: 1 },
  { id: 'mon_6', title: 'Wear sunscreen if working outdoors', icon: 'sunny-outline', dayOfWeek: 1 },
  { id: 'mon_7', title: 'Double-check wheels and tyres on every job', icon: 'disc-outline', dayOfWeek: 1 },
  { id: 'mon_8', title: 'Log completed jobs before end of day', icon: 'list-outline', dayOfWeek: 1 },
  // Tuesday (2) – 8
  { id: 'tue_1', title: 'Clean with care—no harsh pressure on paint', icon: 'sparkles-outline', dayOfWeek: 2 },
  { id: 'tue_2', title: 'Check vacuum and interior cleaning products', icon: 'cube-outline', dayOfWeek: 2 },
  { id: 'tue_3', title: 'Review today’s schedule first thing', icon: 'calendar-outline', dayOfWeek: 2 },
  { id: 'tue_4', title: 'Take a 5-minute walk between jobs', icon: 'walk-outline', dayOfWeek: 2 },
  { id: 'tue_5', title: 'Use separate cloths for interior and exterior', icon: 'shirt-outline', dayOfWeek: 2 },
  { id: 'tue_6', title: 'Stay positive—one task at a time', icon: 'heart-outline', dayOfWeek: 2 },
  { id: 'tue_7', title: 'Check tyre pressure on your own vehicle', icon: 'car-sport-outline', dayOfWeek: 2 },
  { id: 'tue_8', title: 'Reply to any messages within 2 hours', icon: 'chatbubble-outline', dayOfWeek: 2 },
  // Wednesday (3) – 8
  { id: 'wed_1', title: 'Inspect microfibre cloths for grit or damage', icon: 'grid-outline', dayOfWeek: 3 },
  { id: 'wed_2', title: 'Drink water after every car completed', icon: 'water-outline', dayOfWeek: 3 },
  { id: 'wed_3', title: 'Check windscreen cleaner and glass cloths', icon: 'glasses-outline', dayOfWeek: 3 },
  { id: 'wed_4', title: 'Avoid rushing—quality over speed', icon: 'timer-outline', dayOfWeek: 3 },
  { id: 'wed_5', title: 'Wear gloves when using chemicals', icon: 'hand-left-outline', dayOfWeek: 3 },
  { id: 'wed_6', title: 'Take a 10-minute break at midday', icon: 'cafe-outline', dayOfWeek: 3 },
  { id: 'wed_7', title: 'Do a final walk-around before handing keys back', icon: 'eye-outline', dayOfWeek: 3 },
  { id: 'wed_8', title: 'Note any low stock to reorder', icon: 'cart-outline', dayOfWeek: 3 },
  // Thursday (4) – 8
  { id: 'thu_1', title: 'Check equipment: pressure washer and hose', icon: 'construct-outline', dayOfWeek: 4 },
  { id: 'thu_2', title: 'Use pH-neutral shampoo for paintwork', icon: 'flask-outline', dayOfWeek: 4 },
  { id: 'thu_3', title: 'Stretch your back and shoulders', icon: 'body-outline', dayOfWeek: 4 },
  { id: 'thu_4', title: 'Confirm next-day bookings with customers', icon: 'call-outline', dayOfWeek: 4 },
  { id: 'thu_5', title: 'Keep work area tidy between jobs', icon: 'trash-outline', dayOfWeek: 4 },
  { id: 'thu_6', title: 'Eat a healthy snack to keep energy up', icon: 'nutrition-outline', dayOfWeek: 4 },
  { id: 'thu_7', title: 'Dry door jambs and sills properly', icon: 'water-outline', dayOfWeek: 4 },
  { id: 'thu_8', title: 'Smile—it helps you and the customer', icon: 'happy-outline', dayOfWeek: 4 },
  // Friday (5) – 8
  { id: 'fri_1', title: 'Review schedule and plan efficient route', icon: 'navigate-outline', dayOfWeek: 5 },
  { id: 'fri_2', title: 'Check tyre dressing and applicators', icon: 'disc-outline', dayOfWeek: 5 },
  { id: 'fri_3', title: 'Take a break if you feel tired', icon: 'bed-outline', dayOfWeek: 5 },
  { id: 'fri_4', title: 'Use separate buckets for wheels and body', icon: 'water-outline', dayOfWeek: 5 },
  { id: 'fri_5', title: 'Stay hydrated in hot or cold weather', icon: 'water-outline', dayOfWeek: 5 },
  { id: 'fri_6', title: 'Vacuum before wiping interior surfaces', icon: 'sparkles-outline', dayOfWeek: 5 },
  { id: 'fri_7', title: 'Log mileage and expenses for the day', icon: 'calculator-outline', dayOfWeek: 5 },
  { id: 'fri_8', title: 'End the day with a quick kit check', icon: 'checkbox-outline', dayOfWeek: 5 },
  // Saturday (6) – 8
  { id: 'sat_1', title: 'Start with a full kit checklist', icon: 'list-outline', dayOfWeek: 6 },
  { id: 'sat_2', title: 'Take a proper lunch break', icon: 'restaurant-outline', dayOfWeek: 6 },
  { id: 'sat_3', title: 'Check wax and sealant levels', icon: 'sparkles-outline', dayOfWeek: 6 },
  { id: 'sat_4', title: 'Use sun protection if working outside', icon: 'sunny-outline', dayOfWeek: 6 },
  { id: 'sat_5', title: 'Be kind to yourself—rest when needed', icon: 'heart-outline', dayOfWeek: 6 },
  { id: 'sat_6', title: 'Inspect brushes for interior detailing', icon: 'brush-outline', dayOfWeek: 6 },
  { id: 'sat_7', title: 'Leave each car spotless inside and out', icon: 'car-outline', dayOfWeek: 6 },
  { id: 'sat_8', title: 'Wind down and switch off after work', icon: 'moon-outline', dayOfWeek: 6 },
];

/** Get productivity goals for a given day of week (0–6). */
export function getProductivityGoalsForDay(dayOfWeek: number): ProductivityGoalTemplate[] {
  return PRODUCTIVITY_GOALS_BY_DAY.filter((g) => g.dayOfWeek === dayOfWeek);
}

/** Day names for display. */
export const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'] as const;
