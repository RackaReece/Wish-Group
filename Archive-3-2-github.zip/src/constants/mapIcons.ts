/**
 * Map marker icons.
 * - CUSTOMER_MAP_ICON (car.png): customer/vehicle on maps.
 * - HUB_MAP_ICON (cleaning.png): car wash hub / business location on maps.
 */

// eslint-disable-next-line @typescript-eslint/no-require-imports
export const CUSTOMER_MAP_ICON = require('../../app/assets/car.png');

// eslint-disable-next-line @typescript-eslint/no-require-imports
export const HUB_MAP_ICON = require('../../app/assets/cleaning.png');
