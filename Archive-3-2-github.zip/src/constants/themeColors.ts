import { AccountTheme } from './accountThemes';
import { colors } from './colors';
import { textStyles } from './typography';

/** Icon accent palette – harmonious with sky blue UI. Use for semantic icon colour. */
export const getIconAccentColors = () => ({ ...colors.iconAccent });

/** Text colors with WCAG 2.1 AA contrast (4.5:1+) on dark/light backgrounds */
export const getTextColors = (theme: AccountTheme) => {
  const isLight = theme.mode === 'light';
  return {
    primary: isLight ? (theme.textPrimary ?? '#FFFFFF') : '#F9FAFB',
    secondary: isLight ? (theme.textSecondary ?? '#E0E7FF') : 'rgba(249,250,251,0.88)',
    tertiary: isLight ? (theme.textOnBackground ?? '#F1F5F9') : 'rgba(249,250,251,0.75)',
    muted: isLight ? 'rgba(255,255,255,0.8)' : 'rgba(249,250,251,0.68)',
    disabled: isLight ? 'rgba(255,255,255,0.55)' : 'rgba(249,250,251,0.48)',
  };
};

/** High-contrast icon colors – WCAG AA compliant */
export const getIconColors = (theme: AccountTheme) => {
  const isLight = theme.mode === 'light';
  const primary = (theme as { iconPrimary?: string }).iconPrimary ?? theme.accent;
  return {
    primary: isLight ? primary : theme.accent,
    secondary: isLight ? '#E0E7FF' : 'rgba(255,255,255,0.88)',
    active: isLight ? primary : theme.accent,
    inactive: isLight ? 'rgba(255,255,255,0.9)' : 'rgba(255,255,255,0.72)',
  };
};

/** Full text styles with theme colors – use for consistent typography across all pages */
export const getTextStylesWithColors = (theme: AccountTheme) => {
  const tc = getTextColors(theme);
  return {
    pageTitle: { ...textStyles.pageTitle, color: tc.primary },
    pageSubtitle: { ...textStyles.pageSubtitle, color: tc.secondary },
    sectionTitle: { ...textStyles.sectionTitle, color: tc.primary },
    sectionSubtitle: { ...textStyles.sectionSubtitle, color: tc.secondary },
    body: { ...textStyles.body, color: tc.primary },
    bodyMedium: { ...textStyles.bodyMedium, color: tc.primary },
    bodySemiBold: { ...textStyles.bodySemiBold, color: tc.primary },
    bodySmall: { ...textStyles.bodySmall, color: tc.secondary },
    bodySmallMedium: { ...textStyles.bodySmallMedium, color: tc.secondary },
    caption: { ...textStyles.caption, color: tc.tertiary },
    captionMedium: { ...textStyles.captionMedium, color: tc.tertiary },
    captionSemiBold: { ...textStyles.captionSemiBold, color: tc.tertiary },
    cardTitle: { ...textStyles.cardTitle, color: tc.primary },
    button: { ...textStyles.button, color: tc.primary },
    buttonLarge: { ...textStyles.buttonLarge, color: tc.primary },
    statValue: { ...textStyles.statValue, color: tc.primary },
    statLabel: { ...textStyles.statLabel, color: tc.tertiary },
    tabLabel: { ...textStyles.tabLabel, color: tc.primary },
    modalTitle: { ...textStyles.modalTitle, color: tc.primary },
    modalSubtitle: { ...textStyles.modalSubtitle, color: tc.secondary },
    emptyTitle: { ...textStyles.emptyTitle, color: tc.primary },
  };
};

export const getBackgroundColors = (theme: AccountTheme) => {
  const isLight = theme.mode === 'light';
  return {
    card: isLight ? (theme.cardBackground || 'rgba(255,255,255,0.7)') : 'rgba(255,255,255,0.05)',
    cardBorder: isLight ? (theme.cardBorder || 'rgba(135,206,235,0.5)') : (theme.glassBorder || 'rgba(255,255,255,0.1)'),
  };
};
