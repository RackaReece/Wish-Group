import { customerTheme } from './customerTheme';
import { colors } from './colors';

export type AccountType = 'customer' | 'valeter' | 'business';

export type ThemeMode = 'light' | 'dark';

export interface AccountTheme {
  primary: string;
  primaryAlt: string;
  background: [string, string];
  headerBackground?: [string, string];
  glassBorder: string;
  glassBorderAlt?: string;
  accent: string;
  accentAlt: string;
  // Add new fields for light mode support (optional to maintain backward compat)
  cardBackground?: string;
  cardBackgroundGradient?: [string, string];
  cardBorder?: string;
  textPrimary?: string;
  textSecondary?: string;
  /** For labels/titles on the pale background (e.g. section titles above cards) */
  textOnBackground?: string;
  /** Optional: high-contrast icon color (e.g. dark on light background) */
  iconPrimary?: string;
  mode?: ThemeMode;
}

const SKY_BLUE = '#7DD3FC'; // Brighter cyan for visibility on dark backgrounds
const SKY_BLUE_BORDER = 'rgba(125,211,252,0.55)';

export const businessLightTheme: AccountTheme = {
  primary: SKY_BLUE,
  primaryAlt: '#5BA3C7',
  // Background: navy to blue – cohesive
  background: ['#2A5F82', '#1E3A8A'],
  // Header & cards: the blue (sky blue – same as “current” card blue)
  headerBackground: ['#3B7BA8', '#2A5F82'],
  glassBorder: SKY_BLUE_BORDER,
  accent: SKY_BLUE,
  accentAlt: '#5BA3C7',
  cardBackground: '#1e3a8a',
  cardBackgroundGradient: ['#2A5F82', '#1E3A8A'],
  cardBorder: SKY_BLUE_BORDER,
  // Text: high contrast on cards and background
  textPrimary: '#FFFFFF',
  textSecondary: '#E0E7FF', // Indigo-100 – readable, no clash
  textOnBackground: '#F1F5F9',
  iconPrimary: '#FFFFFF',
  mode: 'light',
};

// Valeter uses same UI colours as business (sky blue) for consistency
export const valeterLightTheme: AccountTheme = {
  ...businessLightTheme,
  mode: 'light',
};

export const accountThemes: Record<AccountType, AccountTheme> = {
  customer: {
    primary: SKY_BLUE,
    primaryAlt: '#5BA3C7',
    background: customerTheme.backgroundGradient,
    headerBackground: ['rgba(30,58,138,0.35)', 'rgba(30,58,138,0.25)'],
    glassBorder: 'rgba(125,211,252,0.5)',
    accent: SKY_BLUE,
    accentAlt: '#5BA3C7',
    mode: 'dark',
  },

  valeter: {
    primary: SKY_BLUE,
    primaryAlt: '#5BA3C7',
    background: ['#0f172a', '#020617'],
    headerBackground: ['rgba(30,58,138,0.7)', 'rgba(15,23,42,0.6)'],
    glassBorder: SKY_BLUE_BORDER,
    cardBorder: SKY_BLUE_BORDER,
    cardBackgroundGradient: ['rgba(30,58,138,0.55)', 'rgba(15,23,42,0.4)'],
    accent: SKY_BLUE,
    accentAlt: '#5BA3C7',
    mode: 'dark',
  },

  business: {
    primary: SKY_BLUE,
    primaryAlt: '#5BA3C7',
    background: ['#0f172a', '#020617'],
    headerBackground: ['rgba(30,58,138,0.7)', 'rgba(15,23,42,0.6)'],
    glassBorder: 'rgba(125,211,252,0.55)',
    cardBorder: 'rgba(125,211,252,0.55)',
    cardBackgroundGradient: ['rgba(30,58,138,0.55)', 'rgba(15,23,42,0.4)'],
    accent: SKY_BLUE,
    accentAlt: '#5BA3C7',
    mode: 'dark',
  },
};

export const getAccountTheme = (accountType: AccountType, mode: ThemeMode = 'dark'): AccountTheme => {
  if (accountType === 'business' && mode === 'light') {
    return businessLightTheme;
  }
  if (accountType === 'valeter' && mode === 'light') {
    return valeterLightTheme;
  }
  return accountThemes[accountType];
};
