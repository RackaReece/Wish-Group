// Shared customer theme with sky blue and navy blue gradient
// Used across all customer-related pages for consistent styling

export const customerTheme = {
  // Background gradient: sky blue to navy blue
  backgroundGradient: ['#7DD3FC', '#1E3A8A'] as [string, string],
  
  // Fallback solid background color
  backgroundColor: '#0A1929',
  
  // Header background to match nav tabs
  headerBg: 'rgba(30,58,138,0.25)',
  
  // Primary colors
  skyBlue: '#7DD3FC',
  navyBlue: '#1E3A8A',
  darkNavy: '#0A1929',
};

