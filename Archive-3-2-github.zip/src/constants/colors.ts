// Standardized color scheme for headers, footers, and navigation
// Glassmorphism design with lighter blues, greys, and navy for a modern, consistent look
// Colors meet WCAG 2.1 AA contrast guidelines (4.5:1 text, 3:1 UI) on dark backgrounds

export const colors = {
  // Headers/Footers - Glassmorphism Design
  headerBg: '#1E3A8A', // Dark blue base (blends with #0A1929)
  headerBgSecondary: 'rgba(125,211,252,0.2)', // Brighter cyan glass tint
  headerGradient: ['rgba(125,211,252,0.25)', 'rgba(191,219,254,0.18)'], // Brighter blue gradients
  headerBorder: 'rgba(191,219,254,0.3)', // Light blue border glow
  headerText: '#F9FAFB', // Light grey/white – WCAG AAA
  headerSubtext: '#B8C5D6', // Lighter grey – WCAG AA on dark (~5.5:1)

  // Glassmorphism Specific
  headerGlassBg: 'rgba(125,211,252,0.2)', // Semi-transparent brighter cyan
  headerGlassBorder: 'rgba(191,219,254,0.35)', // Subtle border with light blue glow
  headerGlassShadow: 'rgba(125,211,252,0.25)', // Brighter blue tinted shadow
  headerGlassOverlay: 'rgba(30,58,138,0.1)', // Dark blue overlay for depth

  // Navigation Tab - Glassmorphism Design
  navBg: 'rgba(30,58,138,0.25)', // Semi-transparent dark blue
  navBorder: 'rgba(148,163,184,0.25)', // Grey border – improved visibility
  navGlassBg: 'rgba(30,58,138,0.25)', // Semi-transparent for navigation
  navGlassBorder: 'rgba(148,163,184,0.25)', // Navigation border
  navActive: '#BFDBFE', // Light blue for active state – WCAG AA
  navInactive: '#94A3B8', // Lighter grey – WCAG AA on dark (~5.5:1)

  // Accents
  accentLight: '#E0F2FE',
  accentMedium: '#BFDBFE',
  accentDark: '#1E293B',
  greyLight: '#F8FAFC',
  greyMedium: '#94A3B8', // WCAG AA on dark
  greyDark: '#94A3B8', // Improved from #64748B for accessibility
  
  // Background
  bgPrimary: '#0A1929', // Dark blue (existing)
  bgSecondary: '#1E293B', // Navy
  
  // Service-specific colors
  ecoGreen: '#10B981',
  premiumPurple: '#7DD3FC', // Brighter cyan for visibility on dark backgrounds
  
  // Legacy support (keep for compatibility during migration)
  SKY: '#7DD3FC',
  BG: '#0A1929',
  LIGHT_SKY: '#F9FAFB',
  ECO_GREEN: '#10B981',
  PREMIUM_PURPLE: '#7DD3FC', // Brighter cyan for visibility

  // Icon accent palette – WCAG AA compliant, high visibility on dark backgrounds
  iconAccent: {
    primary: '#7DD3FC',   // Bright cyan – main actions, time, location, settings
    success: '#34D399',   // emerald – checkmark, eco, completed (~4.5:1)
    money: '#FBBF24',     // amber – wallet, earnings (~4.2:1 on dark)
    highlight: '#A78BFA', // violet – star, featured, premium
    warning: '#FB923C',   // orange – notifications, alerts (~4.5:1)
    destructive: '#F87171', // red – delete, logout (~4.5:1)
  },

  // Accessibility – minimum contrast ratios met on bgPrimary (#0A1929)
  accessibility: {
    textOnDark: '#F9FAFB',      // Primary text – AAA
    textSecondaryOnDark: '#E2E8F0', // Secondary – AA
    textMutedOnDark: '#CBD5E1',     // Muted – AA large text
  },
};

// Business cards: single bright cyan rounded border (match GlassCard)
export const CARD_BORDER_RADIUS = 24;
export const SKY_BLUE_BORDER = 'rgba(125,211,252,0.55)';