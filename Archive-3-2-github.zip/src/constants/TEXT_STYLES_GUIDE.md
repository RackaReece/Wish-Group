# Text & Layout Guide

## Icon + Text Alignment

Use `ICON_TEXT_LAYOUT` from `cardSizes` for consistent icon/text positioning:

```tsx
import { ICON_TEXT_LAYOUT } from '../../src/constants/cardSizes';

// Section header (icon + title)
<View style={ICON_TEXT_LAYOUT.sectionHeader}>
  <Ionicons name="location" size={ICON_TEXT_LAYOUT.iconSize.section} color={...} />
  <Text>Section Title</Text>
</View>

// Inline row (icon + text)
<View style={ICON_TEXT_LAYOUT.row}>
  <Ionicons name="info" size={ICON_TEXT_LAYOUT.iconSize.card} color={...} />
  <Text>Content</Text>
</View>

// Card/list item row
<View style={ICON_TEXT_LAYOUT.itemRow}>
  <View style={iconWrapper}><Ionicons size={ICON_TEXT_LAYOUT.iconSize.listItem} ... /></View>
  <Text>Item label</Text>
</View>
```

Standard gaps: 8px (row/section), 12px (itemRow). Icon sizes: section 16, listItem 20, card 18, small 14.

---

# Text Styles Guide

All pages should use consistent typography. Use the centralized text styles instead of defining ad-hoc `fontSize`, `fontWeight`, `fontFamily` in component styles.

## Usage

```tsx
import { getTextStylesWithColors } from '../../src/constants/themeColors';

// In your component:
const ts = getTextStylesWithColors(theme);

// Page title (24px, semibold)
<Text style={[ts.pageTitle, { marginBottom: 8 }]}>Page Title</Text>

// Page subtitle (15px, medium)
<Text style={ts.pageSubtitle}>Description text</Text>

// Section heading (18px, semibold)
<Text style={ts.sectionTitle}>Section Title</Text>

// Section subtitle (14px, medium)
<Text style={ts.sectionSubtitle}>Supporting text</Text>

// Body text
<Text style={ts.body}>Body content</Text>
<Text style={ts.bodySmall}>Secondary body</Text>

// Stats, cards, buttons
<Text style={ts.statValue}>£120</Text>
<Text style={ts.statLabel}>Revenue</Text>
<Text style={ts.cardTitle}>Card Title</Text>
<Text style={ts.button}>Button Text</Text>

// Captions, labels
<Text style={ts.caption}>Small label</Text>
<Text style={ts.captionMedium}>Medium weight caption</Text>

// Modals
<Text style={ts.modalTitle}>Modal Title</Text>
<Text style={ts.modalSubtitle}>Modal description</Text>
```

## Font-only styles (for custom colors)

If you need the font styling without theme color, import from typography:

```tsx
import { textStyles } from '../../src/constants/typography';

<Text style={[textStyles.sectionTitle, { color: myCustomColor }]}>Title</Text>
```

## Standard sizes

| Role | Font size | Weight |
|------|-----------|--------|
| pageTitle | 24 | SemiBold |
| pageSubtitle | 15 | Medium |
| sectionTitle | 18 | SemiBold |
| sectionSubtitle | 14 | Medium |
| body | 16 | Regular |
| bodySmall | 14 | Regular |
| caption | 12 | Regular |
| cardTitle | 18 | SemiBold |
| statValue | 20 | Bold |
| statLabel | 12 | Medium |
| tabLabel | 11 | SemiBold |
| modalTitle | 18 | SemiBold |
| button | 16 | SemiBold |
