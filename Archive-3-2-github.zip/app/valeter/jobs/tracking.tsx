import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Image,
  Linking,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import MapView, { Marker, Region } from 'react-native-maps';
import { CUSTOMER_MAP_ICON } from '../../../src/constants/mapIcons';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import { openTurnByTurnNavigation } from '../../../src/utils/openTurnByTurnNavigation';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import LoadingView from '../../../src/components/shared/LoadingView';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';

import * as ColorsModule from '../../../src/constants/colors';

const appColors: any =
  (ColorsModule as any).colors ??
  (ColorsModule as any).default ??
  ColorsModule;

const SKY = appColors?.SKY ?? '#38BDF8';
const BG = appColors?.BG ?? '#000E1B';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

type JobStatus =
  | 'pending_valeter_acceptance'
  | 'pending_payment'
  | 'confirmed'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed';

const ACTIVE_STATUSES: JobStatus[] = ['confirmed', 'en_route', 'arrived', 'in_progress'];

export default function JobTracking() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const insets = useSafeAreaInsets();

  const jobIdParam = typeof params.jobId === 'string' ? params.jobId : undefined;
  const jobId = jobIdParam && jobIdParam !== 'undefined' ? jobIdParam : null;

  const [job, setJob] = useState<any | null>(null);
  const [customerName, setCustomerName] = useState('Customer');
  const [customerPhone, setCustomerPhone] = useState<string | null>(null);
  const [status, setStatus] = useState<JobStatus>('pending_valeter_acceptance');
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });

  // Use route param jobId if present; otherwise fall back to loaded active job id
  const effectiveJobId = useMemo(() => {
    return jobId ?? job?.id ?? null;
  }, [jobId, job?.id]);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(markerPulse, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    // If no jobId provided, try to load the valeter's active job
    if (!jobId && user?.id) {
      loadActiveJob();
      return;
    }

    if (!jobId) {
      console.warn('[JobTracking] Missing jobId param');
      return;
    }

    loadJob();
  }, [jobId, user?.id]);

  // Subscribe once we have an actual booking id (route param OR loaded active job)
  useEffect(() => {
    const unsubscribe = subscribeToJob();
    return () => {
      unsubscribe?.();
    };
  }, [effectiveJobId]);

  const loadActiveJob = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id)
        .in('status', ['pending_valeter_acceptance', ...ACTIVE_STATUSES])
        .order('request_sent_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) throw error;

      if (data) {
        setJob(data);
        setStatus(data.status);

        if (data?.user_id) {
          const profile = await fetchProfileById(data.user_id);
          setCustomerName(profile?.full_name || 'Customer');
          setCustomerPhone(profile?.phone ?? null);
        }

        if (data.location_lat && data.location_lng) {
          setRegion({
            latitude: data.location_lat,
            longitude: data.location_lng,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          });
        }
      }
    } catch (error) {
      console.error('Error loading active job:', error);
    }
  };

  const loadJob = async () => {
    if (!jobId) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', jobId)
        .single();

      if (error) throw error;

      setJob(data);
      setStatus(data.status);

      if (data?.user_id) {
        const profile = await fetchProfileById(data.user_id);
        setCustomerName(profile?.full_name || 'Customer');
        setCustomerPhone(profile?.phone ?? null);
      } else {
        setCustomerName('Customer');
        setCustomerPhone(null);
      }

      if (data.location_lat && data.location_lng) {
        setRegion({
          latitude: data.location_lat,
          longitude: data.location_lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      }
    } catch (error) {
      console.error('Error loading job:', error);
    }
  };

  const subscribeToJob = () => {
    const idToSub = effectiveJobId;
    if (!idToSub) return undefined;

    const channel = supabase
      .channel(`job-${idToSub}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${idToSub}`,
        },
        (payload) => {
          const updated = payload.new as any;
          setStatus(updated.status);

          if (updated.status === 'completed') {
            router.replace({
              pathname: '/valeter/jobs/complete',
              params: { jobId: idToSub },
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  /**
   * Guard against the DB constraint: only one "active job" per valeter.
   * We block moving into in_progress if another booking for this valeter is already active.
   */
  const assertNoOtherActiveJob = async (currentBookingId: string) => {
    if (!user?.id) return;

    // If your constraint only considers a subset (e.g. in_progress only),
    // you can narrow ACTIVE_STATUSES here.
    const { data, error } = await supabase
      .from('bookings')
      .select('id,status')
      .eq('valeter_id', user.id)
      .in('status', ACTIVE_STATUSES)
      .neq('id', currentBookingId)
      .order('request_sent_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;

    if (data?.id) {
      throw new Error(
        `You already have another active job (${data.status}). Finish it first before starting service on this one.`
      );
    }
  };

  const updateStatus = async (newStatus: JobStatus) => {
    if (!user?.id) return;
    await hapticFeedback('medium');

    const idToUpdate = effectiveJobId;
    if (!idToUpdate) {
      Alert.alert(
        'Error',
        'Missing booking id (jobId). Please reopen the job from the queue.'
      );
      return;
    }

    try {
      // Only do the "active job" precheck when trying to begin the actual service
      if (newStatus === 'in_progress') {
        await assertNoOtherActiveJob(idToUpdate);
      }

      const { error } = await supabase
        .from('bookings')
        .update({ status: newStatus })
        .eq('id', idToUpdate);

      if (error) throw error;
      setStatus(newStatus);
    } catch (error: any) {
      // Postgres unique violation (most Supabase errors include a Postgres code)
      const pgCode = error?.code || error?.details?.code;

      if (
        pgCode === '23505' ||
        String(error?.message || '').toLowerCase().includes('duplicate key value') ||
        String(error?.message || '').includes('ux_active_job_per_valeter')
      ) {
        Alert.alert(
          'You already have an active job',
          'Looks like your account already has another active job assigned. Open your active job and complete it first, or ask an admin to clear the stuck active job flag.'
        );
        return;
      }

      Alert.alert('Error', error?.message || 'Failed to update status');
    }
  };

  const getStatusProgress = (): number => {
    switch (status) {
      case 'pending_valeter_acceptance':
        return 10;
      case 'pending_payment':
        return 20;
      case 'confirmed':
        return 40;
      case 'en_route':
        return 60;
      case 'arrived':
        return 80;
      case 'in_progress':
        return 90;
      case 'completed':
        return 100;
      default:
        return 0;
    }
  };

  const getStatusMessage = (): string => {
    switch (status) {
      case 'pending_valeter_acceptance':
        return 'Job awaiting your response';
      case 'pending_payment':
        return 'Waiting for customer payment';
      case 'confirmed':
        return 'Payment received - Ready to start';
      case 'en_route':
        return 'On the way to location';
      case 'arrived':
        return 'Arrived at location';
      case 'in_progress':
        return 'Service in progress';
      case 'completed':
        return 'Service completed';
      default:
        return 'Tracking job';
    }
  };

  const handleAcceptOnTracking = async () => {
    if (!user?.id || !effectiveJobId) return;
    await hapticFeedback('medium');
    try {
      const { error } = await supabase
        .from('bookings')
        .update({
          valeter_id: user.id,
          status: 'pending_payment',
          valeter_accepted_at: new Date().toISOString(),
        })
        .eq('id', effectiveJobId);

      if (error) throw error;
      setStatus('pending_payment');
    } catch (error: any) {
      Alert.alert('Error', error?.message || 'Failed to accept job');
    }
  };

  const handleRejectOnTracking = async () => {
    await hapticFeedback('light');
    router.replace('/valeter/jobs');
  };

  const chatCallLocked = status === 'pending_payment';

  const handleCallChat = () => {
    if (chatCallLocked) {
      hapticFeedback('light');
      Alert.alert('Unlocks after payment', 'Chat / Call becomes available once the customer has paid.');
      return;
    }
    hapticFeedback('light');
    const phone = customerPhone?.trim();
    if (phone) {
      Linking.openURL(`tel:${phone}`).catch(() =>
        Alert.alert('Cannot call', 'Phone number not available.')
      );
    } else {
      Alert.alert('No contact', 'Customer phone number is not available.');
    }
  };

  const handleCancelBooking = () => {
    hapticFeedback('light');
    Alert.alert(
      'Cancel booking',
      'Cancel this booking? You will be removed from this job.',
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, cancel',
          style: 'destructive',
          onPress: async () => {
            if (!effectiveJobId) return;
            try {
              const { error } = await supabase
                .from('bookings')
                .update({ status: 'cancelled', valeter_id: null })
                .eq('id', effectiveJobId);
              if (error) throw error;
              Alert.alert('Cancelled', 'Booking cancelled.');
              router.replace('/valeter/jobs');
            } catch (e: any) {
              Alert.alert('Error', e?.message ?? 'Failed to cancel booking.');
            }
          },
        },
      ]
    );
  };

  const getNextAction = (): { label: string; action: () => void | Promise<void> } | null => {
    switch (status) {
      case 'pending_valeter_acceptance':
      case 'pending_payment':
        return null;
      case 'confirmed':
        return {
          label: 'Start Journey',
          action: async () => {
            await updateStatus('en_route');
            if (job?.location_lat != null && job?.location_lng != null) {
              openTurnByTurnNavigation(
                job.location_lat,
                job.location_lng,
                job.location_address ?? undefined
              );
              Alert.alert(
                'Navigation started',
                'When you arrive, return to this app and tap "Mark Arrived".',
                [{ text: 'OK' }]
              );
            }
          },
        };
      case 'en_route':
        return {
          label: 'Mark Arrived',
          action: () => updateStatus('arrived'),
        };
      case 'arrived':
        return {
          label: 'Start Service',
          action: () => updateStatus('in_progress'),
        };
      case 'in_progress':
        return {
          label: 'Complete Service',
          action: () => updateStatus('completed'),
        };
      default:
        return null;
    }
  };

  // Default region (user's location or default)
  const defaultRegion: Region = {
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  };

  const nextAction = getNextAction();
  const mapRegion = job ? region : defaultRegion;
  const isLoading = !jobId && !job && user?.id;

  return (
    <SafeAreaView style={styles.container} edges={[] as any}>
      <View style={styles.mapWrapper}>
        <MapView 
          style={styles.map} 
          region={mapRegion} 
          showsUserLocation={true}
          mapPadding={{ top: 0, bottom: 0, left: 0, right: 0 }}
          mapType="mutedStandard"
        >
          {job && job.location_lat && job.location_lng && (
            <Marker
              coordinate={{
                latitude: job.location_lat,
                longitude: job.location_lng,
              }}
            >
              <Animated.View
                style={[
                  styles.markerContainer,
                  {
                    transform: [{ scale: markerPulse }],
                  },
                ]}
              >
                <View style={styles.marker}>
                  <Image
                    source={CUSTOMER_MAP_ICON}
                    style={styles.carMarkerImage}
                    resizeMode="contain"
                  />
                </View>
                <View style={styles.markerPulse} />
              </Animated.View>
            </Marker>
          )}
        </MapView>
        {/* Dark overlay so background matches job cards (no blue) */}
        <View style={styles.mapOverlay} pointerEvents="none" />

        {/* Header Overlay */}
        <View style={styles.headerOverlay}>
          <AppHeader title="Tracking" accountType="valeter" />
        </View>

        {/* Content Overlay */}
        {isLoading ? (
          <View style={styles.loadingOverlay}>
            <LoadingView />
          </View>
        ) : !job ? (
          <View style={styles.emptyOverlay}>
            <GlassCard style={styles.emptyCard} accountType="valeter">
              <View style={styles.emptyContent}>
                <Ionicons name="navigate-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
                <Text style={styles.emptyTitle}>No Active Job</Text>
                <Text style={styles.emptyText}>
                  You don't have any active jobs to track at the moment. Check the jobs page for available opportunities.
                </Text>
                <TouchableOpacity
                  style={styles.backToQueueButton}
                  onPress={() => router.push('/valeter/jobs')}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={[SKY, '#60A5FA']}
                    style={styles.backToQueueGradient}
                  >
                    <Text style={styles.backToQueueText}>View Jobs</Text>
                    <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </GlassCard>
          </View>
        ) : (
          <Animated.View
            style={[
              styles.cardContainer,
              {
                opacity: fadeAnim,
                bottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom,
              },
            ]}
          >
            <View style={styles.trackingCardPremium}>
              <BlurView intensity={40} tint="dark" style={styles.trackingCardBlur} />
              <LinearGradient
                colors={['rgba(135,206,235,0.12)', 'rgba(135,206,235,0.06)']}
                style={StyleSheet.absoluteFill}
              />
              <View style={styles.trackingCardGradient}>
                <View style={styles.trackingStatusBar}>
                  <View style={[styles.trackingStatusDot, getStatusProgress() >= 20 && styles.trackingStatusDotDone]} />
                  <View style={[styles.trackingStatusLine, getStatusProgress() >= 40 && styles.trackingStatusLineDone]} />
                  <View style={[styles.trackingStatusDot, getStatusProgress() >= 40 && styles.trackingStatusDotDone]} />
                  <View style={[styles.trackingStatusLine, getStatusProgress() >= 60 && styles.trackingStatusLineDone]} />
                  <View style={[styles.trackingStatusDot, getStatusProgress() >= 60 && styles.trackingStatusDotDone]} />
                  <View style={[styles.trackingStatusLine, getStatusProgress() >= 80 && styles.trackingStatusLineDone]} />
                  <View style={[styles.trackingStatusDot, getStatusProgress() >= 80 && styles.trackingStatusDotDone]} />
                  <View style={[styles.trackingStatusLine, getStatusProgress() >= 100 && styles.trackingStatusLineDone]} />
                  <View style={[styles.trackingStatusDot, getStatusProgress() >= 100 && styles.trackingStatusDotDone]} />
                </View>
                <View style={styles.trackingHeader}>
                  <StatusBadge status={status} size="medium" />
                  <Text style={styles.statusMessage}>{getStatusMessage()}</Text>
                </View>

                <View style={styles.progressRow}>
                  <TouchableOpacity
                    onPress={handleCallChat}
                    style={[styles.iconButton, chatCallLocked && styles.iconButtonLocked]}
                    activeOpacity={0.8}
                    disabled={chatCallLocked}
                  >
                    <View style={[styles.iconButtonInner, chatCallLocked && styles.iconButtonInnerLocked]}>
                      <Ionicons name="chatbubble-ellipses" size={24} color={chatCallLocked ? 'rgba(255,255,255,0.4)' : SKY} />
                    </View>
                    <Text style={[styles.iconButtonLabel, chatCallLocked && styles.iconButtonLabelLocked]}>
                      {chatCallLocked ? 'Chat / Call (after payment)' : 'Chat / Call'}
                    </Text>
                  </TouchableOpacity>
                  <View style={styles.progressRingWrap}>
                    <AnimatedProgress progress={getStatusProgress()} size={100} />
                  </View>
                  <TouchableOpacity onPress={handleCancelBooking} style={styles.iconButton} activeOpacity={0.8}>
                    <View style={[styles.iconButtonInner, styles.iconButtonCancel]}>
                      <Ionicons name="close-circle" size={24} color="#EF4444" />
                    </View>
                    <Text style={styles.iconButtonLabel}>Cancel</Text>
                  </TouchableOpacity>
                </View>

                <View style={styles.jobInfo}>
                <View style={styles.infoRow}>
                  <Ionicons name="water-outline" size={16} color={SKY} />
                  <Text style={styles.infoText}>
                    {getServiceDisplayName(job.service_type, job.service_name)}
                  </Text>
                </View>

                {job.user_id && (
                  <View style={styles.infoRow}>
                    <Ionicons name="person-outline" size={16} color={SKY} />
                    <Text style={styles.infoText}>{customerName}</Text>
                  </View>
                )}

                <View style={styles.infoRow}>
                  <Ionicons name="location-outline" size={16} color={SKY} />
                  <Text style={styles.infoText} numberOfLines={1}>
                    {job.location_address}
                  </Text>
                </View>

                <View style={styles.infoRow}>
                  <Ionicons name="cash-outline" size={16} color={SKY} />
                  <Text style={styles.infoText}>
                    £{job.price?.toFixed(2) || '0.00'}
                  </Text>
                </View>
                </View>

              {status === 'pending_valeter_acceptance' ? (
                <View style={styles.acceptRejectRow}>
                  <TouchableOpacity
                    onPress={handleAcceptOnTracking}
                    style={styles.acceptButton}
                    activeOpacity={0.8}
                  >
                    <LinearGradient
                      colors={['#10B981', '#059669']}
                      style={styles.acceptGradient}
                    >
                      <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                      <Text style={styles.acceptButtonText}>Accept Job</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={handleRejectOnTracking}
                    style={styles.rejectButton}
                    activeOpacity={0.8}
                  >
                    <Ionicons name="close-circle-outline" size={20} color="#EF4444" />
                    <Text style={styles.rejectButtonText}>Decline</Text>
                  </TouchableOpacity>
                </View>
              ) : nextAction ? (
                <TouchableOpacity
                  onPress={nextAction.action}
                  style={styles.actionButton}
                  activeOpacity={0.8}
                >
                  <LinearGradient
                    colors={[SKY, '#60A5FA']}
                    style={styles.actionGradient}
                  >
                    <Text style={styles.actionText}>{nextAction.label}</Text>
                    <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                  </LinearGradient>
                </TouchableOpacity>
              ) : null}
              </View>
            </View>
          </Animated.View>
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  mapWrapper: {
    flex: 1,
  },
  mapOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(10, 25, 41, 0.35)',
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(10, 25, 41, 0.7)',
  },
  loadingText: {
    color: SKY,
    fontSize: 16,
    marginTop: 12,
    textAlign: 'center',
  },
  emptyOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    padding: 20,
  },
  emptyCard: {
    padding: 40,
    maxWidth: 400,
    alignSelf: 'center',
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 20,
  },
  backToQueueButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    marginTop: 8,
  },
  backToQueueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 28,
    gap: 8,
  },
  backToQueueText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  marker: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#EF4444',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  markerPulse: {
    position: 'absolute',
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#EF4444',
    opacity: 0.3,
  },
  carMarkerImage: {
    width: 28,
    height: 28,
  },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    padding: 16,
  },
  trackingCardPremium: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 14,
  },
  trackingCardBlur: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
  },
  trackingCardGradient: {
    padding: 18,
  },
  trackingStatusBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingHorizontal: 4,
  },
  trackingStatusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: 'rgba(135,206,235,0.3)',
  },
  trackingStatusDotDone: {
    backgroundColor: SKY,
  },
  trackingStatusLine: {
    flex: 1,
    height: 3,
    backgroundColor: 'rgba(135,206,235,0.2)',
    marginHorizontal: 2,
    borderRadius: 2,
  },
  trackingStatusLineDone: {
    backgroundColor: SKY,
  },
  trackingHeader: {
    alignItems: 'center',
    marginBottom: 12,
  },
  statusMessage: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginTop: 8,
    textAlign: 'center',
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingHorizontal: 8,
  },
  progressRingWrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconButton: {
    alignItems: 'center',
    minWidth: 64,
  },
  iconButtonInner: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  iconButtonCancel: {
    backgroundColor: 'rgba(239,68,68,0.15)',
  },
  iconButtonLabel: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 12,
    fontWeight: '600',
  },
  iconButtonLocked: { opacity: 0.7 },
  iconButtonInnerLocked: { backgroundColor: 'rgba(255,255,255,0.06)' },
  iconButtonLabelLocked: { color: 'rgba(249,250,251,0.5)' },
  jobInfo: {
    gap: 8,
    marginBottom: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  infoText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
  },
  acceptRejectRow: {
    flexDirection: 'row',
    gap: 12,
    width: '100%',
  },
  acceptButton: {
    flex: 1,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  acceptGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
  },
  acceptButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  rejectButton: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.5)',
  },
  rejectButtonText: {
    color: '#EF4444',
    fontSize: 16,
    fontWeight: '600',
  },
  actionButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  actionGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 8,
  },
  actionText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
});
