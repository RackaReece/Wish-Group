import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  StatusBar,
  Modal,
  Pressable,
  ScrollView,
  Alert,
  ActivityIndicator,
} from 'react-native';
// Job complete screen - no scroll, single-screen layout
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import GlassCard from '../../../src/components/booking/GlassCard';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { fetchProfileById, type CustomerProfileRow } from '../../../src/utils/customerProfiles';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';

const { width, height } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;

function getInitials(name: string | null | undefined): string {
  if (!name || !name.trim()) return '?';
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) {
    return (parts[0][0] + parts[parts.length - 1][0]).toUpperCase().slice(0, 2);
  }
  return name.slice(0, 2).toUpperCase();
}

export default function JobComplete() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams();
  const jobId = params.jobId as string;

  const [job, setJob] = useState<any | null>(null);
  const [customerProfile, setCustomerProfile] = useState<CustomerProfileRow | null>(null);
  const [showRatingModal, setShowRatingModal] = useState(true);
  const [experienceRating, setExperienceRating] = useState(0);
  const [customerRating, setCustomerRating] = useState(0);
  const [submittingRating, setSubmittingRating] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const successScale = useRef(new Animated.Value(0)).current;
  const confettiAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(successScale, {
        toValue: 1,
        tension: 50,
        friction: 7,
        useNativeDriver: true,
      }),
    ]).start();

    // Confetti animation
    Animated.timing(confettiAnim, {
      toValue: 1,
      duration: 2000,
      useNativeDriver: true,
    }).start();

    loadJob();
  }, [jobId]);

  const loadJob = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', jobId)
        .single();

      if (error) throw error;
      setJob(data);
      if (data?.user_id) {
        const profile = await fetchProfileById(data.user_id);
        setCustomerProfile(profile ?? null);
      } else {
        setCustomerProfile(null);
      }
    } catch (error) {
      console.error('Error loading job:', error);
    }
  };

  const handleBackToQueue = () => {
    router.replace('/valeter/jobs');
  };

  const handleSubmitRating = async () => {
    if (experienceRating === 0) {
      Alert.alert('Rate experience', 'Please tap stars to rate the experience (1–5).');
      return;
    }
    if (customerRating === 0) {
      Alert.alert('Rate customer', 'Please tap stars to rate the customer (1–5).');
      return;
    }
    if (!jobId) return;
    setSubmittingRating(true);
    try {
      const reviewText = `Valeter rated customer: ${customerRating}/5`;
      const { error } = await supabase
        .from('bookings')
        .update({
          rating: experienceRating,
          review: reviewText,
        })
        .eq('id', jobId);

      if (error) throw error;
      setShowRatingModal(false);
    } catch (e: any) {
      Alert.alert('Error', e?.message || 'Could not save rating.');
    } finally {
      setSubmittingRating(false);
    }
  };

  const handleSkipRating = () => {
    setShowRatingModal(false);
  };

  const StarRow = ({ value, onChange, label }: { value: number; onChange: (n: number) => void; label: string }) => (
    <View style={styles.starRow}>
      <Text style={styles.starRowLabel}>{label}</Text>
      <View style={styles.starRowStars}>
        {[1, 2, 3, 4, 5].map((n) => (
          <TouchableOpacity key={n} onPress={() => onChange(n)} style={styles.starTouch} activeOpacity={0.8}>
            <Ionicons name={value >= n ? 'star' : 'star-outline'} size={36} color={value >= n ? '#FBBF24' : '#6B7280'} />
          </TouchableOpacity>
        ))}
      </View>
      <Text style={styles.starRowHint}>{value === 0 ? 'Tap to rate' : value === 1 ? 'Poor' : value === 2 ? 'Fair' : value === 3 ? 'Good' : value === 4 ? 'Very good' : 'Excellent'}</Text>
    </View>
  );

  return (
    <SafeAreaView style={[styles.container, { paddingTop: insets.top, paddingBottom: insets.bottom }]} edges={[]}>
      <StatusBar barStyle="light-content" backgroundColor={BG} />
      <LinearGradient colors={[BG, '#0f172a']} style={StyleSheet.absoluteFill} />

      <AppHeader title="Job Complete!" showBack={false} />

      {/* Rating modal: customer card + rate experience & customer 1–5 */}
      <Modal visible={showRatingModal} transparent animationType="slide">
        <Pressable style={styles.ratingOverlay} onPress={handleSkipRating}>
          <Pressable style={styles.ratingModalBox} onPress={(e) => e.stopPropagation()}>
            <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.ratingScrollContent}>
              <View style={styles.ratingModalHeader}>
                <Text style={styles.ratingModalTitle}>Rate this job</Text>
                <Text style={styles.ratingModalSubtitle}>Your feedback helps improve the experience</Text>
              </View>

              {/* Customer profile card inside modal */}
              {job && (customerProfile || job.user_id) && (
                <View style={styles.ratingProfileWrap}>
                  <LinearGradient colors={['rgba(56,189,248,0.2)', 'rgba(30,58,138,0.25)']} style={styles.profileCard}>
                    <View style={styles.profileCardHeader}>
                      <View style={styles.profileAvatarWrap}>
                        <Text style={styles.profileAvatarText}>{getInitials(customerProfile?.full_name ?? 'Customer')}</Text>
                      </View>
                      <View style={styles.profileCardHeaderText}>
                        <Text style={styles.profileCardName} numberOfLines={1}>{customerProfile?.full_name || 'Customer'}</Text>
                        <Text style={styles.profileCardSubtitle}>Customer</Text>
                      </View>
                    </View>
                    <View style={styles.profileCardDetails}>
                      {customerProfile?.email ? (
                        <View style={styles.profileDetailRow}>
                          <Ionicons name="mail-outline" size={16} color={SKY} />
                          <Text style={styles.profileDetailText} numberOfLines={1}>{customerProfile.email}</Text>
                        </View>
                      ) : null}
                      {customerProfile?.phone ? (
                        <View style={styles.profileDetailRow}>
                          <Ionicons name="call-outline" size={16} color={SKY} />
                          <Text style={styles.profileDetailText}>{customerProfile.phone}</Text>
                        </View>
                      ) : null}
                      {job?.location_address ? (
                        <View style={styles.profileDetailRow}>
                          <Ionicons name="location-outline" size={16} color={SKY} />
                          <Text style={styles.profileDetailText} numberOfLines={2}>{job.location_address}</Text>
                        </View>
                      ) : null}
                    </View>
                  </LinearGradient>
                </View>
              )}

              <StarRow label="Experience" value={experienceRating} onChange={setExperienceRating} />
              <StarRow label="Customer" value={customerRating} onChange={setCustomerRating} />

              <View style={styles.ratingActions}>
                <TouchableOpacity onPress={handleSubmitRating} disabled={submittingRating} style={styles.ratingSubmitButton} activeOpacity={0.8}>
                  <LinearGradient colors={[SKY, '#60A5FA']} style={styles.ratingSubmitGradient}>
                    {submittingRating ? (
                      <ActivityIndicator color="#FFFFFF" size="small" />
                    ) : (
                      <>
                        <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                        <Text style={styles.ratingSubmitText}>Submit rating</Text>
                      </>
                    )}
                  </LinearGradient>
                </TouchableOpacity>
                <TouchableOpacity onPress={handleSkipRating} style={styles.ratingSkipButton} activeOpacity={0.8}>
                  <Text style={styles.ratingSkipText}>Skip for now</Text>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </Pressable>
        </Pressable>
      </Modal>

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24,
          },
        ]}
      >
        {/* Success + Summary: single column, no scroll */}
        <View style={styles.mainBlock}>
          <Animated.View
            style={[
              styles.successContainer,
              {
                transform: [{ scale: successScale }],
                opacity: confettiAnim,
              },
            ]}
          >
            <View style={styles.successCircle}>
              <Ionicons name="checkmark-done-circle" size={56} color="#10B981" />
            </View>
            <Text style={styles.successTitle}>Boom!</Text>
            <Text style={styles.successSubtitle}>Onto the next customer!</Text>
          </Animated.View>

          {job && (customerProfile || job.user_id) && (
            <View style={styles.profileCardWrap}>
              <LinearGradient
                colors={['rgba(56,189,248,0.2)', 'rgba(30,58,138,0.25)']}
                style={styles.profileCard}
              >
                <View style={styles.profileCardHeader}>
                  <View style={styles.profileAvatarWrap}>
                    <Text style={styles.profileAvatarText}>
                      {getInitials(customerProfile?.full_name ?? 'Customer')}
                    </Text>
                  </View>
                  <View style={styles.profileCardHeaderText}>
                    <Text style={styles.profileCardName} numberOfLines={1}>
                      {customerProfile?.full_name || 'Customer'}
                    </Text>
                    <Text style={styles.profileCardSubtitle}>Customer</Text>
                  </View>
                </View>
                <View style={styles.profileCardDetails}>
                  {customerProfile?.email ? (
                    <View style={styles.profileDetailRow}>
                      <Ionicons name="mail-outline" size={16} color={SKY} />
                      <Text style={styles.profileDetailText} numberOfLines={1}>{customerProfile.email}</Text>
                    </View>
                  ) : null}
                  {customerProfile?.phone ? (
                    <View style={styles.profileDetailRow}>
                      <Ionicons name="call-outline" size={16} color={SKY} />
                      <Text style={styles.profileDetailText}>{customerProfile.phone}</Text>
                    </View>
                  ) : null}
                  {job?.location_address ? (
                    <View style={styles.profileDetailRow}>
                      <Ionicons name="location-outline" size={16} color={SKY} />
                      <Text style={styles.profileDetailText} numberOfLines={2}>{job.location_address}</Text>
                    </View>
                  ) : null}
                </View>
              </LinearGradient>
            </View>
          )}

          {job && (
            <GlassCard style={styles.summaryCard}>
              <View style={styles.summaryRow}>
                <Text style={styles.summaryLabel}>Service</Text>
                <Text style={styles.summaryValue} numberOfLines={1}>
                  {getServiceDisplayName(job.service_type, job.service_name)}
                </Text>
              </View>
              <View style={[styles.summaryRow, styles.summaryRowLast]}>
                <Text style={styles.summaryLabel}>Earnings</Text>
                <Text style={styles.summaryValue}>£{job.price?.toFixed(2) || '0.00'}</Text>
              </View>
            </GlassCard>
          )}

          <View style={styles.celebrationRow}>
            <Ionicons name="trophy" size={24} color="#FBBF24" />
            <Text style={styles.celebrationText}>Great job — you're one step closer to your next achievement</Text>
          </View>
        </View>

        <TouchableOpacity
          onPress={handleBackToQueue}
          style={styles.backButton}
          activeOpacity={0.8}
        >
          <LinearGradient
            colors={[SKY, '#60A5FA']}
            style={styles.backGradient}
          >
            <Text style={styles.backText}>Back to Jobs</Text>
            <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
    justifyContent: 'space-between',
  },
  mainBlock: {
    flex: 1,
    minHeight: 0,
    alignItems: 'center',
  },
  successContainer: {
    alignItems: 'center',
    marginBottom: 12,
  },
  successCircle: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: 'rgba(16,185,129,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  successTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  successSubtitle: {
    color: SKY,
    fontSize: 15,
  },
  profileCardWrap: {
    width: '100%',
    marginBottom: 12,
  },
  profileCard: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    padding: 16,
  },
  profileCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 14,
  },
  profileAvatarWrap: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(56,189,248,0.35)',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },
  profileAvatarText: {
    color: '#F8FAFC',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  profileCardHeaderText: {
    flex: 1,
  },
  profileCardName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 2,
  },
  profileCardSubtitle: {
    color: SKY,
    fontSize: 12,
    fontWeight: '600',
  },
  profileCardDetails: {
    gap: 8,
    paddingTop: 12,
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  profileDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  profileDetailText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
    fontWeight: '500',
  },
  summaryCard: {
    padding: 14,
    marginBottom: 8,
    width: '100%',
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 4,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(135,206,235,0.2)',
  },
  summaryRowLast: {
    borderBottomWidth: 0,
  },
  summaryLabel: {
    color: '#9CA3AF',
    fontSize: 13,
  },
  summaryValue: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
    textAlign: 'right',
    marginLeft: 12,
  },
  celebrationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 0,
  },
  celebrationText: {
    color: '#E5E7EB',
    fontSize: 13,
    flex: 1,
  },
  backButton: {
    width: '100%',
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  backGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 32,
    gap: 8,
  },
  backText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  ratingOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'flex-end',
  },
  ratingModalBox: {
    maxHeight: '90%',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    backgroundColor: BG,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    overflow: 'hidden',
  },
  ratingScrollContent: {
    padding: 20,
    paddingBottom: 32,
  },
  ratingModalHeader: {
    marginBottom: 16,
  },
  ratingModalTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  ratingModalSubtitle: {
    color: '#9CA3AF',
    fontSize: 14,
  },
  ratingProfileWrap: {
    width: '100%',
    marginBottom: 20,
  },
  starRow: {
    marginBottom: 20,
  },
  starRowLabel: {
    color: '#E5E7EB',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 8,
  },
  starRowStars: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  starTouch: {
    padding: 4,
  },
  starRowHint: {
    color: '#9CA3AF',
    fontSize: 13,
    marginTop: 6,
  },
  ratingActions: {
    marginTop: 8,
    gap: 12,
  },
  ratingSubmitButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  ratingSubmitGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 8,
  },
  ratingSubmitText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  ratingSkipButton: {
    alignItems: 'center',
    paddingVertical: 12,
  },
  ratingSkipText: {
    color: '#9CA3AF',
    fontSize: 15,
  },
});

