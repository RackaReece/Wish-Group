import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Share,
  Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;
const valeterTheme = getAccountTheme('valeter');

type Tab = 'rewards' | 'referrals';

// Account status tier – no cost, based on jobs completed
const TIERS = [
  { id: 'rookie', label: 'Rookie', jobsRequired: 0, icon: 'leaf', color: '#6B7280' },
  { id: 'rising', label: 'Rising Star', jobsRequired: 10, icon: 'star', color: '#7DD3FC' },
  { id: 'pro', label: 'Pro', jobsRequired: 50, icon: 'ribbon', color: '#10B981' },
  { id: 'elite', label: 'Elite', jobsRequired: 150, icon: 'diamond', color: '#A78BFA' },
  { id: 'legend', label: 'Legend', jobsRequired: 500, icon: 'trophy', color: '#F59E0B' },
];

// Achievement badges – unlocked by doing things, no money
const ACHIEVEMENTS = [
  { id: 'first', title: 'First Job', desc: 'Complete your first wash', icon: 'sparkles', criteria: 1 },
  { id: '10', title: 'Getting Started', desc: 'Complete 10 jobs', icon: 'car', criteria: 10 },
  { id: '50', title: 'Trusted Pro', desc: 'Complete 50 jobs', icon: 'shield-checkmark', criteria: 50 },
  { id: '100', title: 'Century', desc: 'Complete 100 jobs', icon: 'flame', criteria: 100 },
  { id: 'early', title: 'Early Bird', desc: 'Complete a job before 9am', icon: 'sunny', criteria: -1 },
  { id: 'night', title: 'Night Owl', desc: 'Complete a job after 8pm', icon: 'moon', criteria: -1 },
  { id: 'week', title: 'Busy Week', desc: 'Complete 10 jobs in one week', icon: 'calendar', criteria: -1 },
  { id: 'star', title: '5-Star Week', desc: 'Average 5.0 rating for a week', icon: 'star', criteria: -1 },
];

function getTierForJobs(jobsCompleted: number) {
  let current = TIERS[0];
  for (const tier of TIERS) {
    if (jobsCompleted >= tier.jobsRequired) current = tier;
  }
  return current;
}

function generateShortCode(userId: string | undefined): string {
  if (!userId) return 'WAW000';
  const shortId = userId.replace(/-/g, '').substring(0, 6).toUpperCase();
  return shortId || 'WAW000';
}

export default function ValeterRewardsSystem() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const [tab, setTab] = useState<Tab>('rewards');
  const [jobsCompleted, setJobsCompleted] = useState(0);
  const [referralCode] = useState(() => generateShortCode(user?.id));
  const [referrals, setReferrals] = useState<Array<{ id: string; name: string; date: string; reward: string }>>([]);

  useEffect(() => {
    if (!user?.id) return;
    (async () => {
      const { data } = await supabase
        .from('bookings')
        .select('id')
        .eq('valeter_id', user.id)
        .eq('status', 'completed');
      setJobsCompleted(data?.length ?? 0);
    })();
  }, [user?.id]);

  const currentTier = getTierForJobs(jobsCompleted);
  const nextTier = TIERS.find((t) => t.jobsRequired > jobsCompleted);
  const achievementsWithStatus = ACHIEVEMENTS.map((a) => ({
    ...a,
    unlocked: a.criteria > 0 ? jobsCompleted >= a.criteria : false,
  }));

  const handleShareReferral = async () => {
    await hapticFeedback('light');
    try {
      await Share.share({
        message: `Join me on Wish a Wash as a valeter! Use my referral code: ${referralCode} – complete your first job and we both benefit!`,
      });
    } catch {
      Alert.alert('Error', 'Unable to share referral code');
    }
  };

  const handleCopyReferral = () => {
    hapticFeedback('light');
    Alert.alert('Copied!', 'Referral code copied to clipboard');
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[BG, colors.headerBg]} style={StyleSheet.absoluteFill} />

      <AppHeader title={tab === 'rewards' ? 'Rewards' : 'Referrals'} accountType="valeter" />

      {/* Tabs */}
      <View style={styles.tabBar}>
        <TouchableOpacity
          style={[styles.tab, tab === 'rewards' && styles.tabActive]}
          onPress={() => { hapticFeedback('light'); setTab('rewards'); }}
          activeOpacity={0.8}
        >
          <Ionicons name="medal-outline" size={20} color={tab === 'rewards' ? SKY : '#9CA3AF'} />
          <Text style={[styles.tabLabel, tab === 'rewards' && styles.tabLabelActive]}>Rewards</Text>
        </TouchableOpacity>
        <TouchableOpacity
          style={[styles.tab, tab === 'referrals' && styles.tabActive]}
          onPress={() => { hapticFeedback('light'); setTab('referrals'); }}
          activeOpacity={0.8}
        >
          <Ionicons name="people-outline" size={20} color={tab === 'referrals' ? SKY : '#9CA3AF'} />
          <Text style={[styles.tabLabel, tab === 'referrals' && styles.tabLabelActive]}>Referrals</Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: 12,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
          },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {tab === 'rewards' ? (
          <>
            {/* Status tier card – no cost */}
            <View style={styles.tierCard}>
              <LinearGradient
                colors={[`${currentTier.color}25`, `${currentTier.color}08`]}
                style={styles.tierGradient}
              >
                <View style={[styles.tierIconWrap, { backgroundColor: `${currentTier.color}30` }]}>
                  <Ionicons name={currentTier.icon as any} size={36} color={currentTier.color} />
                </View>
                <Text style={styles.tierLabel}>Your status</Text>
                <Text style={[styles.tierName, { color: currentTier.color }]}>{currentTier.label}</Text>
                <Text style={styles.tierSubtext}>
                  {jobsCompleted} jobs completed
                  {nextTier
                    ? ` · ${nextTier.jobsRequired - jobsCompleted} to ${nextTier.label}`
                    : ' · Top tier!'}
                </Text>
              </LinearGradient>
            </View>

            {/* Achievements – account status badges */}
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Achievements</Text>
              <Text style={styles.sectionSubtitle}>
                Unlock badges by completing jobs and hitting milestones. No cost – just progress.
              </Text>
              {achievementsWithStatus.map((a) => (
                <View
                  key={a.id}
                  style={[styles.achievementCard, !a.unlocked && styles.achievementCardLocked]}
                >
                  <View style={[styles.achievementIconWrap, !a.unlocked && styles.achievementIconLocked]}>
                    <Ionicons
                      name={a.icon as any}
                      size={24}
                      color={a.unlocked ? SKY : '#6B7280'}
                    />
                  </View>
                  <View style={styles.achievementContent}>
                    <Text style={[styles.achievementTitle, !a.unlocked && styles.achievementTitleLocked]}>
                      {a.title}
                    </Text>
                    <Text style={styles.achievementDesc}>{a.desc}</Text>
                  </View>
                  {a.unlocked ? (
                    <Ionicons name="checkmark-circle" size={24} color="#10B981" />
                  ) : (
                    <Ionicons name="lock-closed-outline" size={24} color="#6B7280" />
                  )}
                </View>
              ))}
            </View>
          </>
        ) : (
          <>
            {/* Referral code card */}
            <View style={styles.codeCard}>
              <BlurView intensity={35} tint="dark" style={styles.codeBlur}>
                <LinearGradient
                  colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
                  style={StyleSheet.absoluteFill}
                />
                <View style={styles.codeGradient}>
                  <View style={styles.codeIconWrapper}>
                    <Ionicons name="gift" size={32} color={SKY} />
                  </View>
                  <Text style={styles.codeLabel}>Your Referral Code</Text>
                  <View style={styles.codeContainer}>
                    <Text style={styles.codeText}>{referralCode}</Text>
                  </View>
                  <View style={styles.codeActions}>
                    <TouchableOpacity style={styles.codeButton} onPress={handleCopyReferral}>
                      <Ionicons name="copy" size={18} color={SKY} />
                      <Text style={styles.codeButtonText}>Copy</Text>
                    </TouchableOpacity>
                    <TouchableOpacity style={styles.codeButton} onPress={handleShareReferral}>
                      <Ionicons name="share" size={18} color={SKY} />
                      <Text style={styles.codeButtonText}>Share</Text>
                    </TouchableOpacity>
                  </View>
                </View>
              </BlurView>
            </View>

            {/* How it works */}
            <View style={styles.infoCard}>
              <View style={styles.infoContentWrapper}>
                <View style={styles.infoIconWrapper}>
                  <Ionicons name="information-circle" size={24} color={SKY} />
                </View>
                <View style={styles.infoContent}>
                  <Text style={styles.infoTitle}>How it Works</Text>
                  <Text style={styles.infoText}>
                    Share your code with other valeters. When they sign up and complete their first job, you both get recognised – no cash cost, just more people in the network!
                  </Text>
                </View>
              </View>
            </View>

            {/* Referrals list */}
            <View style={styles.referralsSection}>
              <Text style={styles.sectionTitle}>Your Referrals ({referrals.length})</Text>
              {referrals.length === 0 ? (
                <View style={styles.emptyContainer}>
                  <Ionicons name="people-outline" size={48} color={SKY} style={{ opacity: 0.5 }} />
                  <Text style={styles.emptyText}>No referrals yet</Text>
                  <Text style={styles.emptySubtext}>Start sharing your code!</Text>
                </View>
              ) : (
                referrals.map((r) => (
                  <View key={r.id} style={styles.referralRow}>
                    <View style={styles.referralIconWrap}>
                      <Ionicons name="person" size={20} color={SKY} />
                    </View>
                    <View style={styles.referralContent}>
                      <Text style={styles.referralName}>{r.name}</Text>
                      <Text style={styles.referralDate}>{r.date}</Text>
                    </View>
                    <View style={styles.rewardBadge}>
                      <Text style={styles.rewardText}>{r.reward}</Text>
                    </View>
                  </View>
                ))
              )}
            </View>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  tabBar: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingTop: 8,
    paddingBottom: 12,
    gap: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.04)',
  },
  tabActive: {
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  tabLabel: { color: '#9CA3AF', fontSize: 15, fontWeight: '700' },
  tabLabelActive: { color: SKY },
  scrollView: { flex: 1 },
  scrollContent: { padding: 20 },

  // Rewards tab
  tierCard: {
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 24,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  tierGradient: {
    padding: 24,
    alignItems: 'center',
  },
  tierIconWrap: {
    width: 72,
    height: 72,
    borderRadius: 36,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  tierLabel: { color: '#9CA3AF', fontSize: 13, fontWeight: '600', marginBottom: 4 },
  tierName: { fontSize: isSmallScreen ? 22 : 26, fontWeight: '800', marginBottom: 4 },
  tierSubtext: { color: '#9CA3AF', fontSize: 13, fontWeight: '600' },

  section: { marginBottom: 24 },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '700',
    marginBottom: 6,
  },
  sectionSubtitle: {
    color: '#9CA3AF',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 16,
  },
  achievementCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  achievementCardLocked: { opacity: 0.7 },
  achievementIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  achievementIconLocked: { backgroundColor: 'rgba(107,114,128,0.2)' },
  achievementContent: { flex: 1 },
  achievementTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 17,
    fontWeight: '700',
    marginBottom: 2,
  },
  achievementTitleLocked: { color: '#6B7280' },
  achievementDesc: { color: '#9CA3AF', fontSize: 13, fontWeight: '500' },

  // Referrals tab
  codeCard: {
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  codeBlur: { borderRadius: 20, overflow: 'hidden' },
  codeGradient: { padding: 24, alignItems: 'center' },
  codeIconWrapper: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  codeLabel: { color: SKY, fontSize: 14, fontWeight: '600', marginBottom: 12 },
  codeContainer: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  codeText: { color: '#F9FAFB', fontSize: isSmallScreen ? 20 : 24, fontWeight: '800', letterSpacing: 2 },
  codeActions: { flexDirection: 'row', gap: 12 },
  codeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(135,206,235,0.25)',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 12,
    gap: 6,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  codeButtonText: { color: SKY, fontSize: 14, fontWeight: '700' },

  infoCard: {
    borderRadius: 16,
    marginBottom: 24,
    padding: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  infoContentWrapper: { flexDirection: 'row' },
  infoIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  infoContent: { flex: 1 },
  infoTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '700', marginBottom: 6 },
  infoText: { color: '#9CA3AF', fontSize: 13, lineHeight: 18 },

  referralsSection: { marginBottom: 24 },
  emptyContainer: { alignItems: 'center', paddingVertical: 40 },
  emptyText: { color: '#F9FAFB', fontSize: 16, fontWeight: '700', marginTop: 12, marginBottom: 4 },
  emptySubtext: { color: SKY, fontSize: 13 },
  referralRow: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
    borderRadius: 16,
    marginBottom: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  referralIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  referralContent: { flex: 1 },
  referralName: { color: '#F9FAFB', fontSize: 15, fontWeight: '700', marginBottom: 4 },
  referralDate: { color: SKY, fontSize: 12, fontWeight: '600' },
  rewardBadge: {
    backgroundColor: 'rgba(16,185,129,0.2)',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  rewardText: { color: '#10B981', fontSize: 12, fontWeight: '700' },
});
