import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  ScrollView,
  Switch,
  Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import LoadingView from '../../../src/components/shared/LoadingView';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;

type PaymentMethodType = 'bank_account' | 'paypal' | 'stripe';

interface PaymentMethod {
  id: string;
  type: PaymentMethodType;
  isDefault: boolean;
  accountHolderName?: string;
  last4?: string;
  sortCode?: string;
  bankName?: string;
  paypalEmail?: string;
  createdAt: string;
}

export default function ValeterPaymentMethods() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const [loading, setLoading] = useState(true);
  const [methods, setMethods] = useState<PaymentMethod[]>([]);
  const [instantPayout, setInstantPayout] = useState(false);
  const [saving, setSaving] = useState(false);
  const [showAddModal, setShowAddModal] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
    loadPaymentMethods();
  }, [user?.id]);

  const loadPaymentMethods = async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }
    try {
      setLoading(true);
      // Load from Supabase/Stripe when backend is ready
      setMethods([]);
      setInstantPayout(false);
    } catch (e) {
      console.error('[ValeterPaymentMethods] load error:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleSetDefault = (id: string) => {
    hapticFeedback('light');
    setMethods((prev) =>
      prev.map((m) => ({ ...m, isDefault: m.id === id }))
    );
  };

  const handleAddMethod = () => {
    hapticFeedback('light');
    setShowAddModal(true);
  };

  const handleCloseAddModal = () => {
    setShowAddModal(false);
  };

  const handleSaveNewBank = () => {
    hapticFeedback('light');
    setShowAddModal(false);
    // In real app: call Stripe / Supabase to add bank
    loadPaymentMethods();
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={[BG, '#1e3a5f']} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[BG, '#1e3a5f']} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader title="Payments" />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: HEADER_CONTENT_OFFSET + 12, paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12 },
        ]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Payout via Stripe</Text>
            <Text style={styles.sectionSubtitle}>
              Add a bank account or connect Stripe to receive your earnings.
            </Text>
          </View>

          <GlassCard style={styles.card} accountType="valeter">
            <View style={styles.instantRow}>
              <View style={styles.instantLeft}>
                <Ionicons name="flash" size={20} color={SKY} />
                <View>
                  <Text style={styles.instantTitle}>Instant Payout</Text>
                  <Text style={styles.instantSubtitle}>Get paid within minutes (small fee)</Text>
                </View>
              </View>
              <Switch
                value={instantPayout}
                onValueChange={(v) => {
                  hapticFeedback('light');
                  setInstantPayout(v);
                }}
                trackColor={{ false: 'rgba(255,255,255,0.2)', true: SKY }}
                thumbColor="#fff"
              />
            </View>
          </GlassCard>

          <View style={styles.section}>
            <View style={styles.sectionRow}>
              <Text style={styles.sectionTitle}>Your payout methods</Text>
              <TouchableOpacity onPress={handleAddMethod} style={styles.addBtn} activeOpacity={0.8}>
                <Ionicons name="add-circle" size={22} color={SKY} />
                <Text style={styles.addBtnText}>Add</Text>
              </TouchableOpacity>
            </View>
          </View>

          {methods.length === 0 ? (
            <GlassCard style={styles.emptyCard} accountType="valeter">
              <Ionicons name="wallet-outline" size={48} color="rgba(125,211,252,0.75)" />
              <Text style={styles.emptyTitle}>No payout method</Text>
              <Text style={styles.emptySubtitle}>Add a bank account to receive your earnings.</Text>
              <TouchableOpacity onPress={handleAddMethod} style={styles.primaryButton} activeOpacity={0.85}>
                <LinearGradient colors={[SKY, '#5ba3c6']} style={styles.primaryButtonGradient}>
                  <Ionicons name="add" size={20} color="#FFFFFF" />
                  <Text style={styles.primaryButtonText}>Add bank account</Text>
                </LinearGradient>
              </TouchableOpacity>
            </GlassCard>
          ) : (
            methods.map((m) => (
              <GlassCard key={m.id} style={styles.methodCard} accountType="valeter">
                <View style={styles.methodRow}>
                  <View style={styles.methodIconWrap}>
                    <Ionicons name="business-outline" size={22} color={SKY} />
                  </View>
                  <View style={styles.methodDetails}>
                    <Text style={styles.methodBank}>{m.bankName || 'Bank account'}</Text>
                    <Text style={styles.methodMeta}>
                      •••• {m.last4} {m.sortCode ? ` • ${m.sortCode}` : ''}
                    </Text>
                    {m.isDefault && (
                      <View style={styles.defaultBadge}>
                        <Text style={styles.defaultBadgeText}>Default</Text>
                      </View>
                    )}
                  </View>
                  {!m.isDefault && (
                    <TouchableOpacity onPress={() => handleSetDefault(m.id)} style={styles.setDefaultBtn}>
                      <Text style={styles.setDefaultText}>Set default</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </GlassCard>
            ))
          )}

          <TouchableOpacity onPress={handleAddMethod} style={styles.addMethodCard} activeOpacity={0.85}>
            <Ionicons name="add-circle-outline" size={24} color={SKY} />
            <Text style={styles.addMethodText}>Add bank account or PayPal</Text>
          </TouchableOpacity>

          <View style={styles.footer}>
            <Ionicons name="shield-checkmark" size={16} color="rgba(125,211,252,0.9)" />
            <Text style={styles.footerText}>Payouts are processed securely via Stripe.</Text>
          </View>
        </Animated.View>
      </Animated.ScrollView>

      {showAddModal && (
        <View style={styles.modalOverlay}>
          <View style={styles.modal}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add bank account</Text>
              <TouchableOpacity onPress={handleCloseAddModal} hitSlop={12}>
                <Ionicons name="close" size={24} color={SKY} />
              </TouchableOpacity>
            </View>
            <Text style={styles.modalSubtitle}>
              You’ll be taken to Stripe to add your account. We never see your full bank details.
            </Text>
            <TouchableOpacity onPress={handleSaveNewBank} style={styles.primaryButton} activeOpacity={0.85}>
              <LinearGradient colors={[SKY, '#5ba3c6']} style={styles.primaryButtonGradient}>
                {saving ? (
                  <ActivityIndicator size="small" color="#FFFFFF" />
                ) : (
                  <>
                    <Ionicons name="open-outline" size={20} color="#FFFFFF" />
                    <Text style={styles.primaryButtonText}>Continue with Stripe</Text>
                  </>
                )}
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },
  content: { gap: 16 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 14 },
  section: { marginBottom: 4 },
  sectionRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '700', marginBottom: 4 },
  sectionSubtitle: { color: 'rgba(249,250,251,0.7)', fontSize: 13 },
  card: { padding: 16, marginBottom: 8 },
  instantRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  instantLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  instantTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '600' },
  instantSubtitle: { color: 'rgba(249,250,251,0.6)', fontSize: 12, marginTop: 2 },
  addBtn: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  addBtnText: { color: SKY, fontSize: 14, fontWeight: '600' },
  emptyCard: { padding: 28, alignItems: 'center', gap: 12 },
  emptyTitle: { color: '#F9FAFB', fontSize: 17, fontWeight: '600' },
  emptySubtitle: { color: 'rgba(249,250,251,0.6)', fontSize: 13 },
  methodCard: { padding: 16, marginBottom: 8 },
  methodRow: { flexDirection: 'row', alignItems: 'center' },
  methodIconWrap: { width: 44, height: 44, borderRadius: 22, backgroundColor: `${SKY}25`, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  methodDetails: { flex: 1 },
  methodBank: { color: '#F9FAFB', fontSize: 16, fontWeight: '600' },
  methodMeta: { color: 'rgba(249,250,251,0.6)', fontSize: 13, marginTop: 2 },
  defaultBadge: { alignSelf: 'flex-start', backgroundColor: `${SKY}30`, paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8, marginTop: 6 },
  defaultBadgeText: { color: SKY, fontSize: 11, fontWeight: '700' },
  setDefaultBtn: { paddingHorizontal: 12, paddingVertical: 8 },
  setDefaultText: { color: SKY, fontSize: 13, fontWeight: '600' },
  addMethodCard: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, padding: 18, borderWidth: 2, borderStyle: 'dashed', borderColor: `${SKY}50`, borderRadius: 16, marginTop: 8 },
  addMethodText: { color: SKY, fontSize: 15, fontWeight: '600' },
  primaryButton: { borderRadius: 14, overflow: 'hidden', marginTop: 16 },
  primaryButtonGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 14, paddingHorizontal: 20 },
  primaryButtonText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
  footer: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 24, paddingVertical: 12 },
  footerText: { color: 'rgba(249,250,251,0.6)', fontSize: 12 },
  modalOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', padding: 24 },
  modal: { backgroundColor: '#1e3a5f', borderRadius: 20, padding: 24, borderWidth: 1, borderColor: `${SKY}30` },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  modalTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '700' },
  modalSubtitle: { color: 'rgba(249,250,251,0.7)', fontSize: 14, marginBottom: 20 },
});
