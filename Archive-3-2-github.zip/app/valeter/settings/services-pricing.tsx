import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  TextInput,
  Switch,
  KeyboardAvoidingView,
  Platform,
  Modal,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import LoadingView from '../../../src/components/shared/LoadingView';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import BubbleBackground from '../../../src/components/shared/BubbleBackground';
import { colors } from '../../../src/constants/colors';
import { getIconAccentColors } from '../../../src/constants/themeColors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';

const SKY = colors.SKY;

type TierKey = 'bronze' | 'silver' | 'gold' | 'platinum';
const TIER_DEFS: Array<{ key: TierKey; name: string; icon: keyof typeof Ionicons.glyphMap; color: string }> = [
  { key: 'bronze', name: 'Bronze Wash', icon: 'layers-outline', color: '#CD7F32' },
  { key: 'silver', name: 'Silver Wash', icon: 'star-outline', color: '#C0C0C0' },
  { key: 'gold', name: 'Gold Wash', icon: 'trophy', color: '#FFD700' },
  { key: 'platinum', name: 'Platinum Wash', icon: 'diamond', color: '#E5E4E2' },
];

type DetailingKey = 'mini' | 'interior' | 'exterior' | 'full' | 'seats' | 'engine' | 'ceramic';
type DetailingItem = { key: DetailingKey; name: string; enabled: boolean; price: number | null; size_extras?: SizeExtras };

const DETAILING_DEFS: Array<{ key: DetailingKey; name: string; icon: keyof typeof Ionicons.glyphMap }> = [
  { key: 'mini', name: 'Mini Detail', icon: 'sparkles-outline' },
  { key: 'interior', name: 'Interior Detail', icon: 'car-outline' },
  { key: 'exterior', name: 'Exterior Detail', icon: 'water-outline' },
  { key: 'full', name: 'Full Detail', icon: 'diamond-outline' },
  { key: 'seats', name: 'Seat Shampoo', icon: 'shirt-outline' },
  { key: 'engine', name: 'Engine Bay Clean', icon: 'cog-outline' },
  { key: 'ceramic', name: 'Ceramic Coating', icon: 'shield-checkmark-outline' },
];

/** Extra £ to add to base price for larger vehicle sizes (base price on card = Small) */
export type VehicleSizeExtraKey = 'medium' | 'large' | 'xl';
export type SizeExtras = Partial<Record<VehicleSizeExtraKey, number>>;

const VEHICLE_SIZE_LABELS: Record<VehicleSizeExtraKey, string> = {
  medium: 'Medium',
  large: 'Large',
  xl: 'XL / SUV / Van',
};

type TierRow = { price: number | null; minutes: number | null; size_extras?: SizeExtras };
type TierPricing = Record<TierKey, TierRow>;

const defaultTierPricing = (): TierPricing => ({
  bronze: { price: null, minutes: null, size_extras: {} },
  silver: { price: null, minutes: null, size_extras: {} },
  gold: { price: null, minutes: null, size_extras: {} },
  platinum: { price: null, minutes: null, size_extras: {} },
});

const money = (n: any) => {
  const v = typeof n === 'string' ? Number(n) : typeof n === 'number' ? n : 0;
  return Number.isFinite(v) ? v.toFixed(2) : '0.00';
};

const parseMaybeNumber = (raw: string, kind: 'price' | 'minutes'): number | null => {
  const t = (raw || '').trim();
  if (!t) return null;
  const v = Number(t);
  if (!Number.isFinite(v) || v < 0) return null;
  return kind === 'minutes' ? Math.round(v) : v;
};

const buildDefaultDetailingItems = (): DetailingItem[] =>
  DETAILING_DEFS.map((d) => ({ key: d.key, name: d.name, enabled: false, price: null, size_extras: undefined }));

const coerceDetailingMenu = (raw: any): DetailingItem[] => {
  const defaults = buildDefaultDetailingItems();
  const map = new Map<DetailingKey, DetailingItem>();
  defaults.forEach((d) => map.set(d.key, d));
  const items = raw?.items;
  if (Array.isArray(items)) {
    for (const it of items) {
      const key = it?.key as DetailingKey;
      if (!key || !map.has(key)) continue;
      const extras = it?.size_extras && typeof it.size_extras === 'object' ? it.size_extras : {};
      const size_extras: SizeExtras = {};
      (['medium', 'large', 'xl'] as VehicleSizeExtraKey[]).forEach((sz) => {
        const v = extras[sz];
        if (v != null && Number.isFinite(Number(v)) && Number(v) >= 0) size_extras[sz] = Number(v);
      });
      map.set(key, {
        key,
        name: String(it?.name || map.get(key)!.name),
        enabled: !!it?.enabled,
        price: it?.price == null || it?.price === '' ? null : Number.isFinite(Number(it?.price)) ? Number(it?.price) : null,
        size_extras: Object.keys(size_extras).length ? size_extras : undefined,
      });
    }
  }
  return Array.from(map.values());
};

const coerceTierPricing = (raw: any): TierPricing => {
  const base = defaultTierPricing();
  const obj = raw && typeof raw === 'object' ? raw : {};
  (Object.keys(base) as TierKey[]).forEach((k) => {
    const row = obj?.[k] || {};
    const extras = row?.size_extras && typeof row.size_extras === 'object' ? row.size_extras : {};
    const size_extras: SizeExtras = {};
    (['medium', 'large', 'xl'] as VehicleSizeExtraKey[]).forEach((sz) => {
      const v = extras[sz];
      if (v != null && Number.isFinite(Number(v)) && Number(v) >= 0) size_extras[sz] = Number(v);
    });
    base[k] = {
      price: row?.price == null ? null : Number.isFinite(Number(row.price)) ? Number(row.price) : null,
      minutes: row?.minutes == null ? null : Number.isFinite(Number(row.minutes)) ? Math.round(Number(row.minutes)) : null,
      size_extras: Object.keys(size_extras).length ? size_extras : undefined,
    };
  });
  return base;
};

const isMissingTableErr = (err: any) => {
  const msg = String(err?.message || '').toLowerCase();
  return msg.includes('does not exist') || msg.includes('relation') || msg.includes('schema cache');
};

const SERVICE_SETTINGS_SQL = `-- Run in Supabase SQL editor
create table if not exists public.valeter_service_settings (
  valeter_id uuid primary key references auth.users(id) on delete cascade,
  eco_washing boolean not null default false,
  detailing_offered boolean not null default false,
  detailing_menu jsonb,
  tier_pricing jsonb,
  updated_at timestamptz not null default now()
);
create index if not exists idx_valeter_service_settings_updated_at on public.valeter_service_settings(updated_at);
`;

export default function ValeterServicesPricing() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const iconAccent = getIconAccentColors();

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [ecoWashing, setEcoWashing] = useState(false);
  const [detailingOffered, setDetailingOffered] = useState(false);
  const [detailingItems, setDetailingItems] = useState<DetailingItem[]>(buildDefaultDetailingItems());
  const [tierPricing, setTierPricing] = useState<TierPricing>(defaultTierPricing());
  const [sizeExtrasModalTier, setSizeExtrasModalTier] = useState<TierKey | null>(null);
  const [detailingSizeExtrasModalKey, setDetailingSizeExtrasModalKey] = useState<DetailingKey | null>(null);

  useEffect(() => {
    if (user?.id) loadSettings();
    else setLoading(false);
  }, [user?.id]);

  const loadSettings = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const { data, error } = await supabase.from('valeter_service_settings').select('*').eq('valeter_id', user.id).maybeSingle();
      if (error && isMissingTableErr(error)) {
        Alert.alert('DB setup needed', "The table 'valeter_service_settings' doesn't exist yet. Run the SQL to create it.");
        return;
      }
      if (data) {
        setEcoWashing(!!data.eco_washing);
        setDetailingOffered(!!data.detailing_offered);
        setDetailingItems(coerceDetailingMenu(data.detailing_menu));
        setTierPricing(coerceTierPricing(data.tier_pricing));
      }
    } catch (e) {
      console.warn('[ServicesPricing] load error:', e);
    } finally {
      setLoading(false);
    }
  };

  const saveSettings = async () => {
    if (!user?.id) return;
    try {
      setSaving(true);
      await hapticFeedback('medium');
      const payload = {
        valeter_id: user.id,
        eco_washing: ecoWashing,
        detailing_offered: detailingOffered,
        detailing_menu: { items: detailingItems },
        tier_pricing: tierPricing,
      };
      const { error } = await supabase.from('valeter_service_settings').upsert(payload, { onConflict: 'valeter_id' });
      if (error && isMissingTableErr(error)) {
        Alert.alert('DB setup needed', "Create 'valeter_service_settings' first. SQL is available via the info button.");
        return;
      }
      if (error) throw error;
      Alert.alert('Saved', 'Your services & pricing have been updated.');
    } catch (e: any) {
      Alert.alert('Error', e?.message || 'Failed to save');
    } finally {
      setSaving(false);
    }
  };

  const setTierField = (key: TierKey, field: 'price' | 'minutes', raw: string) => {
    const v = parseMaybeNumber(raw, field === 'price' ? 'price' : 'minutes');
    setTierPricing((prev) => ({ ...prev, [key]: { ...prev[key], [field]: v } }));
  };

  const setTierSizeExtra = (key: TierKey, size: VehicleSizeExtraKey, raw: string) => {
    const v = parseMaybeNumber(raw, 'price');
    setTierPricing((prev) => {
      const row = prev[key];
      const extras = { ...(row.size_extras || {}), [size]: v };
      const size_extras = Object.fromEntries(Object.entries(extras).filter(([, n]) => n != null)) as SizeExtras;
      return { ...prev, [key]: { ...row, size_extras: Object.keys(size_extras).length ? size_extras : undefined } };
    });
  };

  const toggleDetailingItem = (key: DetailingKey, enabled: boolean) => {
    setDetailingItems((prev) => prev.map((it) => (it.key === key ? { ...it, enabled } : it)));
  };

  const setDetailingPrice = (key: DetailingKey, raw: string) => {
    const v = parseMaybeNumber(raw, 'price');
    setDetailingItems((prev) => prev.map((it) => (it.key === key ? { ...it, price: v } : it)));
  };

  const setDetailingSizeExtra = (key: DetailingKey, size: VehicleSizeExtraKey, raw: string) => {
    const v = parseMaybeNumber(raw, 'price');
    setDetailingItems((prev) =>
      prev.map((it) => {
        if (it.key !== key) return it;
        const extras = { ...(it.size_extras || {}), [size]: v };
        const size_extras = Object.fromEntries(Object.entries(extras).filter(([, n]) => n != null)) as SizeExtras;
        return { ...it, size_extras: Object.keys(size_extras).length ? size_extras : undefined };
      })
    );
  };

  const showSql = async () => {
    await hapticFeedback('light');
    Alert.alert('Supabase SQL', 'Copy/paste into Supabase SQL editor:\n\n' + SERVICE_SETTINGS_SQL, [{ text: 'OK' }]);
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={['#0A1929', '#2563EB']} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={['#0A1929', '#2563EB']} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      <AppHeader title="Services" />

      <KeyboardAvoidingView style={styles.keyboardView} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET + 12, paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12 }]}
          keyboardShouldPersistTaps="handled"
          decelerationRate="fast"
        >
          {/* Eco Washing */}
          <View style={styles.section}>
            <GlassCard style={styles.ecoWashCard} accountType="valeter">
              <View style={styles.ecoWashContent}>
                <View style={styles.ecoWashLeft}>
                  <View style={styles.ecoWashIconWrapper}>
                    <Ionicons name="leaf" size={20} color={iconAccent.success} />
                  </View>
                  <View style={styles.ecoWashText}>
                    <Text style={styles.sectionTitle}>Eco-Friendly Washing</Text>
                    <Text style={styles.hint}>Show customers you offer environmentally conscious services</Text>
                  </View>
                </View>
                <Switch value={ecoWashing} onValueChange={async (v) => { await hapticFeedback('light'); setEcoWashing(v); }} trackColor={{ false: 'rgba(255,255,255,0.1)', true: 'rgba(16,185,129,0.5)' }} thumbColor={ecoWashing ? '#10B981' : '#f4f3f4'} />
              </View>
            </GlassCard>
          </View>

          {/* Wash Tiers */}
          <View style={styles.section}>
            <View style={styles.sectionHeader}>
              <View style={styles.sectionHeaderIcon}>
                <Ionicons name="layers" size={20} color={iconAccent.primary} />
              </View>
              <View style={styles.sectionHeaderText}>
                <Text style={styles.sectionTitle}>Wash Tiers</Text>
                <Text style={styles.hint}>Set pricing and duration for each service tier</Text>
              </View>
            </View>

            <View style={styles.tierCardsContainer}>
              {TIER_DEFS.map((t) => {
                const row = tierPricing[t.key];
                return (
                  <GlassCard key={t.key} style={styles.tierCard} accountType="valeter">
                    <LinearGradient colors={[`${t.color}18`, `${t.color}08`, 'rgba(255,255,255,0.02)']} style={StyleSheet.absoluteFill} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} />
                    <View style={styles.tierCardHeader}>
                      <View style={[styles.tierIconWrapper, { backgroundColor: `${t.color}25` }]}>
                        <Ionicons name={t.icon} size={22} color={t.color} />
                      </View>
                      <View style={styles.tierHeaderText}>
                        <Text style={[styles.tierName, { color: t.color }]}>{t.name}</Text>
                        <View style={styles.tierPillsRow}>
                          <View style={[styles.tierPill, { backgroundColor: `${t.color}22`, borderColor: `${t.color}35` }]}>
                            <Ionicons name="cash" size={14} color={t.color} />
                            <Text style={[styles.tierPillText, { color: t.color }]}>£{row?.price ? money(row.price) : '0.00'}</Text>
                          </View>
                          <View style={[styles.tierPill, { backgroundColor: `${t.color}22`, borderColor: `${t.color}35` }]}>
                            <Ionicons name="time" size={14} color={t.color} />
                            <Text style={[styles.tierPillText, { color: t.color }]}>{row?.minutes ? `${row.minutes}m` : '—'}</Text>
                          </View>
                        </View>
                      </View>
                      <TouchableOpacity
                        style={[styles.tierPlusButton, { backgroundColor: `${t.color}25` }]}
                        onPress={async () => { await hapticFeedback('light'); setSizeExtrasModalTier(t.key); }}
                        activeOpacity={0.8}
                      >
                        <Ionicons name="add" size={22} color={t.color} />
                      </TouchableOpacity>
                    </View>
                    <View style={styles.tierInputsRow}>
                      <View style={styles.tierInputGroup}>
                        <View style={styles.tierInputLabel}>
                          <Ionicons name="cash-outline" size={14} color="rgba(249,250,251,0.6)" />
                          <Text style={styles.tierInputLabelText}>Price (Small)</Text>
                        </View>
                        <BlurView intensity={40} tint="dark" style={styles.tierInputBlur}>
                          <TextInput value={row?.price == null ? '' : String(row.price)} placeholder="0.00" placeholderTextColor="rgba(249,250,251,0.4)" keyboardType="decimal-pad" style={styles.tierInput} onChangeText={(txt) => setTierField(t.key, 'price', txt)} />
                        </BlurView>
                      </View>
                      <View style={styles.tierInputGroup}>
                        <View style={styles.tierInputLabel}>
                          <Ionicons name="time-outline" size={14} color="rgba(249,250,251,0.6)" />
                          <Text style={styles.tierInputLabelText}>Duration</Text>
                        </View>
                        <BlurView intensity={40} tint="dark" style={styles.tierInputBlur}>
                          <TextInput value={row?.minutes == null ? '' : String(row.minutes)} placeholder="—" placeholderTextColor="rgba(249,250,251,0.4)" keyboardType="number-pad" style={styles.tierInput} onChangeText={(txt) => setTierField(t.key, 'minutes', txt)} />
                        </BlurView>
                      </View>
                    </View>
                  </GlassCard>
                );
              })}
            </View>

            {/* Size extras modal */}
            <Modal visible={sizeExtrasModalTier != null} transparent animationType="fade">
              <Pressable style={styles.sizeExtrasOverlay} onPress={() => setSizeExtrasModalTier(null)}>
                <Pressable style={styles.sizeExtrasModal} onPress={(e) => e.stopPropagation()}>
                  {sizeExtrasModalTier != null && (() => {
                    const t = TIER_DEFS.find((x) => x.key === sizeExtrasModalTier)!;
                    const row = tierPricing[sizeExtrasModalTier];
                    const extras = row?.size_extras || {};
                    return (
                      <>
                        <View style={styles.sizeExtrasModalHeader}>
                          <Text style={[styles.sizeExtrasModalTitle, { color: t.color }]}>{t.name}</Text>
                          <Text style={styles.sizeExtrasModalSubtitle}>Base price above is for Small. Add extra £ for larger vehicles.</Text>
                          <TouchableOpacity style={styles.sizeExtrasCloseBtn} onPress={() => setSizeExtrasModalTier(null)}>
                            <Ionicons name="close" size={24} color="#F9FAFB" />
                          </TouchableOpacity>
                        </View>
                        <View style={styles.sizeExtrasInputs}>
                          {(['medium', 'large', 'xl'] as VehicleSizeExtraKey[]).map((size) => (
                            <View key={size} style={styles.sizeExtrasRow}>
                              <Text style={styles.sizeExtrasLabel}>{VEHICLE_SIZE_LABELS[size]} (+£)</Text>
                              <BlurView intensity={40} tint="dark" style={styles.sizeExtrasInputBlur}>
                                <TextInput
                                  value={extras[size] == null ? '' : String(extras[size])}
                                  placeholder="0.00"
                                  placeholderTextColor="rgba(249,250,251,0.4)"
                                  keyboardType="decimal-pad"
                                  style={styles.sizeExtrasInput}
                                  onChangeText={(txt) => setTierSizeExtra(sizeExtrasModalTier, size, txt)}
                                />
                              </BlurView>
                            </View>
                          ))}
                        </View>
                        <TouchableOpacity style={[styles.sizeExtrasDoneBtn, { backgroundColor: t.color }]} onPress={async () => { await hapticFeedback('light'); setSizeExtrasModalTier(null); }}>
                          <Text style={styles.sizeExtrasDoneText}>Done</Text>
                        </TouchableOpacity>
                      </>
                    );
                  })()}
                </Pressable>
              </Pressable>
            </Modal>
          </View>

          {/* Detailing */}
          <View style={styles.section}>
            <GlassCard style={styles.detailingToggleCard} accountType="valeter">
              <View style={styles.detailingToggleContent}>
                <View style={styles.detailingToggleLeft}>
                  <View style={styles.detailingToggleIconWrapper}>
                    <Ionicons name="sparkles" size={20} color={iconAccent.money} />
                  </View>
                  <View style={styles.detailingToggleText}>
                    <Text style={styles.sectionTitle}>Detailing Services</Text>
                    <Text style={styles.hint}>Offer premium detailing services to customers</Text>
                  </View>
                </View>
                <Switch value={detailingOffered} onValueChange={async (v) => { await hapticFeedback('light'); setDetailingOffered(v); }} trackColor={{ false: 'rgba(255,255,255,0.1)', true: 'rgba(245,158,11,0.5)' }} thumbColor={detailingOffered ? '#F59E0B' : '#f4f3f4'} />
              </View>
            </GlassCard>

            {detailingOffered && (
              <View style={styles.detailingItemsContainer}>
                {DETAILING_DEFS.map((def) => {
                  const item = detailingItems.find((x) => x.key === def.key) || { key: def.key, name: def.name, enabled: false, price: null, size_extras: undefined };
                  return (
                    <GlassCard key={def.key} style={StyleSheet.flatten([styles.detailingItemCard, !item.enabled && styles.detailingItemCardDisabled])} accountType="valeter">
                      <View style={styles.detailingItemHeader}>
                        <View style={styles.detailingItemLeft}>
                          <View style={[styles.detailingItemIconWrapper, !item.enabled && styles.detailingItemIconDisabled]}>
                            <Ionicons name={def.icon} size={18} color={item.enabled ? iconAccent.primary : 'rgba(125,211,252,0.5)'} />
                          </View>
                          <Text style={[styles.detailingItemName, !item.enabled && styles.detailingItemNameDisabled]}>{def.name}</Text>
                        </View>
                        <View style={styles.detailingItemHeaderRight}>
                          {item.enabled && (
                            <TouchableOpacity
                              style={styles.detailingPlusButton}
                              onPress={async () => { await hapticFeedback('light'); setDetailingSizeExtrasModalKey(def.key); }}
                              activeOpacity={0.8}
                            >
                              <Ionicons name="add" size={20} color={SKY} />
                            </TouchableOpacity>
                          )}
                          <Switch value={!!item.enabled} onValueChange={async (v) => { await hapticFeedback('light'); toggleDetailingItem(def.key, v); }} trackColor={{ false: 'rgba(255,255,255,0.1)', true: 'rgba(135,206,235,0.5)' }} thumbColor={item.enabled ? SKY : '#f4f3f4'} />
                        </View>
                      </View>
                      {item.enabled && (
                        <View style={styles.detailingItemInputContainer}>
                          <View style={styles.detailingItemInputGroup}>
                            <View style={styles.detailingItemInputLabel}>
                              <Ionicons name="cash-outline" size={14} color="rgba(249,250,251,0.6)" />
                              <Text style={styles.detailingItemInputLabelText}>Price (Small) £</Text>
                            </View>
                            <BlurView intensity={40} tint="dark" style={styles.detailingItemInputBlur}>
                              <TextInput value={item.price == null ? '' : String(item.price)} placeholder="0.00" placeholderTextColor="rgba(249,250,251,0.4)" keyboardType="decimal-pad" style={styles.detailingItemInput} onChangeText={(txt) => setDetailingPrice(def.key, txt)} />
                            </BlurView>
                          </View>
                          {item.price != null && (
                            <View style={styles.detailingItemPriceBadge}>
                              <Text style={styles.detailingItemPriceBadgeText}>£{money(item.price)}</Text>
                            </View>
                          )}
                        </View>
                      )}
                    </GlassCard>
                  );
                })}
              </View>
            )}

            {/* Detailing size extras modal */}
            <Modal visible={detailingSizeExtrasModalKey != null} transparent animationType="fade">
              <Pressable style={styles.sizeExtrasOverlay} onPress={() => setDetailingSizeExtrasModalKey(null)}>
                <Pressable style={styles.sizeExtrasModal} onPress={(e) => e.stopPropagation()}>
                  {detailingSizeExtrasModalKey != null && (() => {
                    const def = DETAILING_DEFS.find((x) => x.key === detailingSizeExtrasModalKey)!;
                    const item = detailingItems.find((x) => x.key === detailingSizeExtrasModalKey) || { key: def.key, name: def.name, enabled: false, price: null, size_extras: undefined };
                    const extras = item.size_extras || {};
                    return (
                      <>
                        <View style={styles.sizeExtrasModalHeader}>
                          <Text style={[styles.sizeExtrasModalTitle, { color: SKY }]}>{def.name}</Text>
                          <Text style={styles.sizeExtrasModalSubtitle}>Base price above is for Small. Add extra £ for larger vehicles.</Text>
                          <TouchableOpacity style={styles.sizeExtrasCloseBtn} onPress={() => setDetailingSizeExtrasModalKey(null)}>
                            <Ionicons name="close" size={24} color="#F9FAFB" />
                          </TouchableOpacity>
                        </View>
                        <View style={styles.sizeExtrasInputs}>
                          {(['medium', 'large', 'xl'] as VehicleSizeExtraKey[]).map((size) => (
                            <View key={size} style={styles.sizeExtrasRow}>
                              <Text style={styles.sizeExtrasLabel}>{VEHICLE_SIZE_LABELS[size]} (+£)</Text>
                              <BlurView intensity={40} tint="dark" style={styles.sizeExtrasInputBlur}>
                                <TextInput
                                  value={extras[size] == null ? '' : String(extras[size])}
                                  placeholder="0.00"
                                  placeholderTextColor="rgba(249,250,251,0.4)"
                                  keyboardType="decimal-pad"
                                  style={styles.sizeExtrasInput}
                                  onChangeText={(txt) => setDetailingSizeExtra(detailingSizeExtrasModalKey, size, txt)}
                                />
                              </BlurView>
                            </View>
                          ))}
                        </View>
                        <TouchableOpacity style={[styles.sizeExtrasDoneBtn, { backgroundColor: SKY }]} onPress={async () => { await hapticFeedback('light'); setDetailingSizeExtrasModalKey(null); }}>
                          <Text style={styles.sizeExtrasDoneText}>Done</Text>
                        </TouchableOpacity>
                      </>
                    );
                  })()}
                </Pressable>
              </Pressable>
            </Modal>
          </View>

          {/* DB help */}
          <View style={styles.sqlHelpCard}>
            <View style={styles.sqlHelpRow}>
              <Ionicons name="information-circle-outline" size={18} color={iconAccent.primary} style={{ marginTop: 2 }} />
              <View style={{ flex: 1 }}>
                <Text style={styles.sqlHelpTitle}>If this doesn't save</Text>
                <Text style={styles.sqlHelpText}>You might not have the valeter_service_settings table yet. Tap below to get the SQL.</Text>
              </View>
            </View>
            <TouchableOpacity onPress={showSql} activeOpacity={0.85} style={styles.sqlBtn}>
              <Ionicons name="code-slash" size={16} color="#FFFFFF" />
              <Text style={styles.sqlBtnText}>Show SQL</Text>
            </TouchableOpacity>
          </View>

          {/* Save button */}
          <View style={styles.footer}>
            <TouchableOpacity onPress={() => router.back()} style={styles.secondaryBtn} activeOpacity={0.85} disabled={saving}>
              <Text style={styles.secondaryBtnText}>Cancel</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={saveSettings} style={[styles.primaryBtn, saving && { opacity: 0.7 }]} activeOpacity={0.85} disabled={saving}>
              {saving ? <ActivityIndicator size="small" color="#FFFFFF" /> : (
                <>
                  <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                  <Text style={styles.primaryBtnText}>Save Changes</Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  keyboardView: { flex: 1 },
  scrollContent: { padding: 20 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 16 },
  loadingText: { color: SKY, fontSize: 14 },
  section: { marginBottom: 24 },
  sectionHeader: { flexDirection: 'row', alignItems: 'flex-start', gap: 12, marginBottom: 16 },
  sectionHeaderIcon: { width: 36, height: 36, borderRadius: 12, backgroundColor: 'rgba(125,211,252,0.18)', justifyContent: 'center', alignItems: 'center' },
  sectionHeaderText: { flex: 1 },
  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '700', letterSpacing: 0.2 },
  hint: { color: 'rgba(249,250,251,0.6)', fontSize: 13, marginTop: 4, lineHeight: 20 },
  ecoWashCard: { padding: 14, borderRadius: 16 },
  ecoWashContent: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  ecoWashLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  ecoWashIconWrapper: { width: 40, height: 40, borderRadius: 14, backgroundColor: 'rgba(16,185,129,0.2)', justifyContent: 'center', alignItems: 'center' },
  ecoWashText: { flex: 1 },
  tierCardsContainer: { gap: 12, marginTop: 8 },
  tierCard: {
    padding: 16,
    borderRadius: 18,
    overflow: 'hidden',
    marginBottom: 0,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.08)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 12,
    elevation: 6,
    minHeight: 160,
  },
  tierCardHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 14 },
  tierIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tierHeaderText: { flex: 1 },
  tierPlusButton: {
    width: 40,
    height: 40,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sizeExtrasOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  sizeExtrasModal: {
    width: '100%',
    maxWidth: 360,
    borderRadius: 20,
    overflow: 'hidden',
    backgroundColor: 'rgba(10,25,41,0.98)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    padding: 20,
  },
  sizeExtrasModalHeader: { marginBottom: 20, paddingRight: 32 },
  sizeExtrasModalTitle: { fontSize: 20, fontWeight: '800', letterSpacing: 0.3, marginBottom: 8 },
  sizeExtrasModalSubtitle: { color: 'rgba(249,250,251,0.65)', fontSize: 13, lineHeight: 18 },
  sizeExtrasCloseBtn: { position: 'absolute', top: 0, right: 0, padding: 8 },
  sizeExtrasInputs: { gap: 14, marginBottom: 24 },
  sizeExtrasRow: { flexDirection: 'row', alignItems: 'center', gap: 12, minHeight: 52 },
  sizeExtrasLabel: { color: '#F9FAFB', fontSize: 14, fontWeight: '600', width: 125 },
  sizeExtrasInputBlur: { flex: 1, borderRadius: 12, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(135,206,235,0.25)', backgroundColor: 'rgba(255,255,255,0.05)' },
  sizeExtrasInput: { color: '#F9FAFB', fontSize: 15, paddingVertical: 10, paddingHorizontal: 12, fontWeight: '700' },
  sizeExtrasDoneBtn: { paddingVertical: 14, borderRadius: 12, alignItems: 'center' },
  sizeExtrasDoneText: { color: '#FFFFFF', fontSize: 16, fontWeight: '800' },
  tierName: { fontSize: 17, fontWeight: '800', marginBottom: 6, letterSpacing: 0.2 },
  tierPillsRow: { flexDirection: 'row', gap: 8 },
  tierPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1,
  },
  tierPillText: { fontSize: 13, fontWeight: '700' },
  tierInputsRow: { flexDirection: 'row', gap: 10 },
  tierInputGroup: { flex: 1 },
  tierInputLabel: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 },
  tierInputLabelText: { color: 'rgba(249,250,251,0.7)', fontSize: 12, fontWeight: '600' },
  tierInputBlur: { borderRadius: 12, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(135,206,235,0.25)', backgroundColor: 'rgba(255,255,255,0.05)' },
  tierInput: { color: '#F9FAFB', fontSize: 15, paddingVertical: 10, paddingHorizontal: 12, fontWeight: '700' },
  detailingToggleCard: { padding: 14, borderRadius: 16 },
  detailingToggleContent: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  detailingToggleLeft: { flexDirection: 'row', alignItems: 'center', gap: 12, flex: 1 },
  detailingToggleIconWrapper: { width: 40, height: 40, borderRadius: 14, backgroundColor: 'rgba(245,158,11,0.2)', justifyContent: 'center', alignItems: 'center' },
  detailingToggleText: { flex: 1 },
  detailingItemsContainer: { gap: 10, marginTop: 12 },
  detailingItemCard: { padding: 14, borderRadius: 16, borderWidth: 1, borderColor: 'rgba(255,255,255,0.06)', shadowColor: '#000', shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.08, shadowRadius: 8, elevation: 4 },
  detailingItemCardDisabled: { opacity: 0.6 },
  detailingItemHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  detailingItemHeaderRight: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  detailingPlusButton: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: 'rgba(125,211,252,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  detailingItemLeft: { flexDirection: 'row', alignItems: 'center', gap: 10, flex: 1 },
  detailingItemIconWrapper: { width: 36, height: 36, borderRadius: 12, backgroundColor: 'rgba(125,211,252,0.2)', justifyContent: 'center', alignItems: 'center' },
  detailingItemIconDisabled: { backgroundColor: 'rgba(255,255,255,0.05)', borderColor: 'rgba(255,255,255,0.1)' },
  detailingItemName: { color: '#F9FAFB', fontSize: 15, fontWeight: '700' },
  detailingItemNameDisabled: { color: 'rgba(249,250,251,0.5)' },
  detailingItemInputContainer: { flexDirection: 'row', alignItems: 'flex-end', gap: 10 },
  detailingItemInputGroup: { flex: 1 },
  detailingItemInputLabel: { flexDirection: 'row', alignItems: 'center', gap: 6, marginBottom: 6 },
  detailingItemInputLabelText: { color: 'rgba(249,250,251,0.7)', fontSize: 12, fontWeight: '600' },
  detailingItemInputBlur: { borderRadius: 12, overflow: 'hidden', borderWidth: 1, borderColor: 'rgba(135,206,235,0.25)', backgroundColor: 'rgba(255,255,255,0.05)' },
  detailingItemInput: { color: '#F9FAFB', fontSize: 15, paddingVertical: 10, paddingHorizontal: 12, fontWeight: '700' },
  detailingItemPriceBadge: { paddingHorizontal: 12, paddingVertical: 10, borderRadius: 12, backgroundColor: 'rgba(135,206,235,0.2)', borderWidth: 1, borderColor: 'rgba(135,206,235,0.3)' },
  detailingItemPriceBadgeText: { color: SKY, fontSize: 15, fontWeight: '700' },
  sqlHelpCard: { margin: 14, padding: 12, borderRadius: 16, borderWidth: 1, borderColor: 'rgba(255,255,255,0.10)', backgroundColor: 'rgba(255,255,255,0.05)', gap: 10 },
  sqlHelpRow: { flexDirection: 'row', gap: 10, alignItems: 'flex-start' },
  sqlHelpTitle: { color: '#F9FAFB', fontSize: 13, fontWeight: '900' },
  sqlHelpText: { color: 'rgba(249,250,251,0.72)', fontSize: 12, marginTop: 4, lineHeight: 18 },
  sqlBtn: { alignSelf: 'flex-start', flexDirection: 'row', alignItems: 'center', gap: 8, backgroundColor: SKY, paddingHorizontal: 12, paddingVertical: 10, borderRadius: 14 },
  sqlBtnText: { color: '#FFFFFF', fontWeight: '900', fontSize: 12 },
  footer: { flexDirection: 'row', gap: 14, marginTop: 8, marginBottom: 16 },
  secondaryBtn: { flex: 1, borderRadius: 18, borderWidth: 1.5, borderColor: 'rgba(135,206,235,0.3)', backgroundColor: 'rgba(135,206,235,0.1)', alignItems: 'center', justifyContent: 'center', paddingVertical: 16 },
  secondaryBtnText: { color: '#E5E7EB', fontWeight: '700', fontSize: 16 },
  primaryBtn: { flex: 1.5, borderRadius: 18, backgroundColor: SKY, alignItems: 'center', justifyContent: 'center', paddingVertical: 16, flexDirection: 'row', gap: 10, elevation: 8, shadowColor: SKY, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.4, shadowRadius: 8 },
  primaryBtnText: { color: '#FFFFFF', fontWeight: '700', fontSize: 16 },
});
