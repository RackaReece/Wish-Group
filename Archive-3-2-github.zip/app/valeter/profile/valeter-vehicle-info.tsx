import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Dimensions,
  ActivityIndicator,
  Alert,
  Image,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import LoadingView from '../../../src/components/shared/LoadingView';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import GlassCard from '../../../src/components/booking/GlassCard';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { DVLA_CONFIG } from '../../../src/config/dvla';

const { width } = Dimensions.get('window');
const valeterTheme = getAccountTheme('valeter');
const PHOTO_BOX_HEIGHT = Math.min(width - 40, 220);

const IMAGE_MEDIA_TYPES: any =
  (ImagePicker as any)?.MediaType?.Images ? [(ImagePicker as any).MediaType.Images] : undefined;

interface ValeterProfileData {
  user_id: string;
  vehicle_make?: string;
  vehicle_model?: string;
  vehicle_registration?: string;
  tax_status?: string;
  tax_due_date?: string;
  mot_status?: string;
  mot_expiry_date?: string;
}

interface ValeterVehicleInfoProps {
  /** When true, render only the content (no SafeAreaView/AppHeader/ScrollView) for embedding in Tax & MOT Hub */
  embedded?: boolean;
}

export default function ValeterVehicleInfo({ embedded = false }: ValeterVehicleInfoProps = {}) {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const [profile, setProfile] = useState<ValeterProfileData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [isLookingUpDVLA, setIsLookingUpDVLA] = useState(false);
  const [vehiclePhotoUri, setVehiclePhotoUri] = useState<string | null>(null);
  const [pickingPhoto, setPickingPhoto] = useState(false);

  useEffect(() => {
    if (user?.id) loadProfile();
  }, [user?.id]);

  const loadProfile = async () => {
    try {
      setIsLoading(true);

      const { data } = await supabase
        .from('valeter_profiles')
        .select('*')
        .eq('user_id', user!.id)
        .maybeSingle();

      if (data) {
        setProfile(data);
        // If your backend adds vehicle_photo_url later, set it here:
        // setVehiclePhotoUri(data.vehicle_photo_url || null);
      } else {
        const { data: created } = await supabase
          .from('valeter_profiles')
          .insert({ user_id: user!.id, full_name: ' ' })
          .select()
          .single();

        setProfile(created);
      }
    } catch {
      Alert.alert('Error', 'Failed to load vehicle information');
    } finally {
      setIsLoading(false);
    }
  };

  const pickVehiclePhoto = async () => {
    try {
      setPickingPhoto(true);
      await hapticFeedback('light');

      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (perm.status !== 'granted') {
        Alert.alert('Permission Required', 'Gallery permission is required to add a vehicle photo.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: IMAGE_MEDIA_TYPES,
        allowsEditing: true,
        aspect: [16, 9],
        quality: 0.85,
      });

      if (!result.canceled && result.assets?.[0]?.uri) {
        setVehiclePhotoUri(result.assets[0].uri);
      }
    } catch (error: any) {
      Alert.alert('Error', error?.message || 'Failed to select photo.');
    } finally {
      setPickingPhoto(false);
    }
  };

  const lookupDVLA = async (registration: string) => {
    if (!DVLA_CONFIG.apiKey) {
      Alert.alert('DVLA not configured', 'Missing DVLA API key');
      return;
    }

    try {
      setIsLookingUpDVLA(true);

      const res = await fetch(DVLA_CONFIG.baseUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': DVLA_CONFIG.apiKey,
        },
        body: JSON.stringify({ registrationNumber: registration }),
      });

      if (!res.ok) throw new Error('DVLA lookup failed');

      const data = await res.json();

      setProfile(prev =>
        prev
          ? {
              ...prev,
              vehicle_make: data.make ?? prev.vehicle_make,
              tax_status: data.taxStatus ?? null,
              tax_due_date: data.taxDueDate ?? null,
              mot_status: data.motStatus ?? null,
              mot_expiry_date: data.motExpiryDate ?? null,
            }
          : prev
      );

      await hapticFeedback('success');
    } catch (e: any) {
      Alert.alert('DVLA lookup failed', e.message || 'Unable to fetch vehicle details');
    } finally {
      setIsLookingUpDVLA(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!profile || !user?.id) return;

    try {
      setIsSaving(true);

      const { error } = await supabase
        .from('valeter_profiles')
        .update({
          vehicle_make: profile.vehicle_make,
          vehicle_model: profile.vehicle_model,
          vehicle_registration: profile.vehicle_registration,
          tax_status: profile.tax_status,
          tax_due_date: profile.tax_due_date,
          mot_status: profile.mot_status,
          mot_expiry_date: profile.mot_expiry_date,
        })
        .eq('user_id', user.id);

      if (error) throw error;

      Alert.alert('Saved', 'Vehicle details updated');
      setIsEditing(false);
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to save vehicle details');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading || !profile) {
    if (embedded) {
      return (
        <View style={styles.embeddedLoading}>
          <LoadingView />
        </View>
      );
    }
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={valeterTheme.background} style={StyleSheet.absoluteFill} />
        <AppHeader title="Vehicle" accountType="valeter" />
        <LoadingView style={styles.loadingContainer} />
      </SafeAreaView>
    );
  }

  const StatusRow = ({ label, status, date }: { label: string; status?: string | null; date?: string | null }) => {
    const good = status === 'Taxed' || status === 'Valid';
    return (
      <View style={styles.statusRow}>
        <Text style={styles.statusLabel}>{label}</Text>
        <Text style={[styles.statusValue, good ? styles.statusGood : styles.statusBad]}>{status || '—'}</Text>
        {date ? <Text style={styles.statusSub}>{date}</Text> : null}
      </View>
    );
  };

  const content = (
    <>
        {/* Photo box at top */}
        <TouchableOpacity
          style={styles.photoBox}
          onPress={pickVehiclePhoto}
          disabled={pickingPhoto}
          activeOpacity={0.9}
        >
          <LinearGradient
            colors={['rgba(135,206,235,0.25)', 'rgba(30,58,138,0.2)']}
            style={StyleSheet.absoluteFill}
          />
          <View style={styles.photoBoxBorder} />
          {vehiclePhotoUri ? (
            <Image source={{ uri: vehiclePhotoUri }} style={styles.photoImage} resizeMode="cover" />
          ) : (
            <View style={styles.photoPlaceholder}>
              {pickingPhoto ? (
                <ActivityIndicator size="large" color={valeterTheme.primary} />
              ) : (
                <>
                  <View style={styles.photoIconWrap}>
                    <Ionicons name="car" size={40} color="rgba(255,255,255,0.7)" />
                  </View>
                  <Text style={styles.photoPlaceholderText}>Add vehicle photo</Text>
                  <Text style={styles.photoPlaceholderSub}>Tap to choose from gallery</Text>
                </>
              )}
            </View>
          )}
        </TouchableOpacity>

        {/* Vehicle details section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Vehicle details</Text>

          <GlassCard style={styles.card} accountType="valeter">
            <View style={styles.cardRow}>
              <Text style={styles.cardLabel}>Registration</Text>
              {isEditing ? (
                <TextInput
                  style={styles.input}
                  value={profile.vehicle_registration || ''}
                  autoCapitalize="characters"
                  onChangeText={t =>
                    setProfile({ ...profile, vehicle_registration: t.replace(/\s/g, '').toUpperCase() })
                  }
                  onBlur={() => profile.vehicle_registration && lookupDVLA(profile.vehicle_registration)}
                  placeholder="AB12 CDE"
                  placeholderTextColor="rgba(255,255,255,0.4)"
                />
              ) : (
                <Text style={styles.cardValue}>{profile.vehicle_registration || '—'}</Text>
              )}
              {isLookingUpDVLA && <ActivityIndicator size="small" color={valeterTheme.primary} style={styles.dvlaSpinner} />}
            </View>
          </GlassCard>

          <GlassCard style={styles.card} accountType="valeter">
            <View style={styles.cardRow}>
              <Text style={styles.cardLabel}>Make</Text>
              <Text style={styles.cardValue}>{profile.vehicle_make || '—'}</Text>
            </View>
          </GlassCard>

          <GlassCard style={styles.card} accountType="valeter">
            <View style={styles.cardRow}>
              <Text style={styles.cardLabel}>Model</Text>
              {isEditing ? (
                <TextInput
                  style={styles.input}
                  value={profile.vehicle_model || ''}
                  onChangeText={t => setProfile({ ...profile, vehicle_model: t })}
                  placeholder="e.g. Transit Custom"
                  placeholderTextColor="rgba(255,255,255,0.4)"
                />
              ) : (
                <Text style={styles.cardValue}>{profile.vehicle_model || '—'}</Text>
              )}
            </View>
          </GlassCard>
        </View>

        {/* Tax & MOT section */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Tax & MOT</Text>
          <GlassCard style={styles.taxMotCard} accountType="valeter">
            <StatusRow
              label="Vehicle Tax"
              status={profile.tax_status}
              date={profile.tax_due_date ? `Due ${new Date(profile.tax_due_date).toLocaleDateString()}` : null}
            />
            <View style={styles.divider} />
            <StatusRow
              label="MOT"
              status={profile.mot_status}
              date={profile.mot_expiry_date ? `Expires ${new Date(profile.mot_expiry_date).toLocaleDateString()}` : null}
            />
          </GlassCard>
        </View>

        {isEditing && (
          <TouchableOpacity
            style={styles.saveButton}
            onPress={handleSaveProfile}
            disabled={isSaving}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={[valeterTheme.primary, valeterTheme.primaryAlt || valeterTheme.primary]}
              style={styles.saveButtonGradient}
            >
              {isSaving ? (
                <ActivityIndicator color="#fff" />
              ) : (
                <Text style={styles.saveText}>Save changes</Text>
              )}
            </LinearGradient>
          </TouchableOpacity>
        )}
    </>
  );

  if (embedded) {
    return (
      <View style={styles.embeddedContent}>
        <View style={styles.embeddedHeader}>
          <TouchableOpacity onPress={() => setIsEditing(!isEditing)} style={styles.editButton}>
            <Ionicons name={isEditing ? 'close' : 'create'} size={20} color={valeterTheme.primary} />
          </TouchableOpacity>
        </View>
        {content}
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={valeterTheme.background} style={StyleSheet.absoluteFill} />
      <AppHeader
        title="Vehicle"
        accountType="valeter"
        rightAction={
          <TouchableOpacity onPress={() => setIsEditing(!isEditing)} style={styles.editButton}>
            <Ionicons name={isEditing ? 'close' : 'create'} size={20} color={valeterTheme.primary} />
          </TouchableOpacity>
        }
      />
      <ScrollView
        contentContainerStyle={[
          styles.scrollContent,
          { paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        {content}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  embeddedLoading: {
    paddingVertical: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  embeddedLoadingText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
    marginTop: 12,
  },
  embeddedContent: {
    paddingHorizontal: 20,
    paddingBottom: 24,
  },
  embeddedHeader: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    marginBottom: 12,
  },
  scrollContent: {
    paddingTop: HEADER_CONTENT_OFFSET,
    paddingHorizontal: 20,
  },

  editButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  /* Photo box */
  photoBox: {
    width: width - 40,
    height: PHOTO_BOX_HEIGHT,
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 24,
    alignSelf: 'center',
  },
  photoBoxBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  photoImage: {
    width: '100%',
    height: '100%',
  },
  photoPlaceholder: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  photoIconWrap: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: 'rgba(255,255,255,0.12)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  photoPlaceholderText: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 4,
  },
  photoPlaceholderSub: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 13,
  },

  /* Sections */
  section: { marginBottom: 24 },
  sectionTitle: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.5,
    marginBottom: 12,
    marginLeft: 4,
  },

  card: {
    paddingVertical: 16,
    paddingHorizontal: 20,
    marginBottom: 12,
    borderRadius: 16,
  },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
  },
  cardLabel: {
    color: 'rgba(255,255,255,0.65)',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 6,
  },
  cardValue: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
  },
  input: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
    backgroundColor: 'rgba(255,255,255,0.08)',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    minWidth: 140,
  },
  dvlaSpinner: { marginLeft: 8 },

  taxMotCard: {
    padding: 20,
    borderRadius: 16,
  },
  statusRow: { marginBottom: 0 },
  statusLabel: { color: 'rgba(255,255,255,0.65)', fontSize: 13, fontWeight: '600', marginBottom: 4 },
  statusValue: { fontSize: 16, fontWeight: '700' },
  statusGood: { color: '#22C55E' },
  statusBad: { color: '#EF4444' },
  statusSub: { color: 'rgba(255,255,255,0.55)', fontSize: 12, marginTop: 2 },
  divider: {
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.12)',
    marginVertical: 16,
  },

  saveButton: { borderRadius: 16, overflow: 'hidden', marginTop: 8 },
  saveButtonGradient: { paddingVertical: 16, alignItems: 'center' },
  saveText: { color: '#fff', fontSize: 16, fontWeight: '800' },
});
