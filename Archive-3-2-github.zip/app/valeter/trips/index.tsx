import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Image,
  Alert,
  Linking,
  FlatList,
  NativeSyntheticEvent,
  NativeScrollEvent,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import { openTurnByTurnNavigation } from '../../../src/utils/openTurnByTurnNavigation';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import MapView, { Marker, Region } from 'react-native-maps';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import * as Location from 'expo-location';

import { colors } from '../../../src/constants/colors';
import { CUSTOMER_MAP_ICON } from '../../../src/constants/mapIcons';

const { width, height } = Dimensions.get('window');
const CARD_PADDING = 32;
const cardWidth = width - CARD_PADDING;
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

type JobStatus =
  | 'pending_payment'
  | 'confirmed'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed';

const ACTIVE_STATUSES: JobStatus[] = ['confirmed', 'en_route', 'arrived', 'in_progress'];

export default function TripsPage() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const insets = useSafeAreaInsets();

  const jobIdParam = typeof params.jobId === 'string' ? params.jobId : undefined;
  const jobId = jobIdParam && jobIdParam !== 'undefined' ? jobIdParam : null;

  const [activeBookings, setActiveBookings] = useState<any[]>([]);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const [initialRegion, setInitialRegion] = useState<Region | null>(null);
  const [tripsLoading, setTripsLoading] = useState(true);
  const [valeterLocation, setValeterLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [locationPermission, setLocationPermission] = useState<Location.PermissionStatus | null>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const mapRef = useRef<MapView>(null);
  const listRef = useRef<FlatList>(null);

  const activeJob = activeBookings[selectedIndex] ?? null;
  const status: JobStatus = activeJob?.status ?? 'pending_payment';
  const customerName = activeJob?.customer_name ?? 'Customer';
  const customerPhone = activeJob?.customer_phone ?? null;

  const loadAllActiveBookings = React.useCallback(async () => {
    if (!user?.id) return;
    try {
      setTripsLoading(true);
      const { data: rows, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('valeter_id', user.id)
        .in('status', ['pending_payment', ...ACTIVE_STATUSES])
        .order('scheduled_at', { ascending: true });

      if (error) throw error;

      const enriched = await Promise.all(
        (rows ?? []).map(async (b) => {
          let customer_name = 'Customer';
          let customer_phone: string | null = null;
          if (b.user_id) {
            const profile = await fetchProfileById(b.user_id);
            customer_name = profile?.full_name || 'Customer';
            customer_phone = profile?.phone ?? null;
          }
          let vehicle_registration = null;
          let vehicle_make = null;
          let vehicle_model = null;
          let vehicle_type = b.vehicle_type ?? null;
          try {
            const { data: vehicle } = await supabase
              .from('customer_vehicles')
              .select('registration, make, model, type')
              .eq('user_id', b.user_id)
              .eq('is_default', true)
              .maybeSingle();
            if (vehicle) {
              vehicle_registration = vehicle.registration ?? null;
              vehicle_make = vehicle.make ?? null;
              vehicle_model = vehicle.model ?? null;
              vehicle_type = vehicle.type ?? vehicle_type;
            }
          } catch {}
          return {
            ...b,
            customer_name,
            customer_phone,
            vehicle_registration,
            vehicle_make,
            vehicle_model,
            vehicle_type,
          };
        })
      );

      setActiveBookings(enriched);
      const idx = jobId ? enriched.findIndex((b) => b.id === jobId) : 0;
      const safeIdx = idx >= 0 ? idx : 0;
      setSelectedIndex(safeIdx);

      const first = enriched[safeIdx];
      if (first?.location_lat != null && first?.location_lng != null) {
        const newRegion: Region = {
          latitude: first.location_lat,
          longitude: first.location_lng,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        };
        setRegion(newRegion);
        setInitialRegion((prev) => prev ?? newRegion);
      }
    } catch (error) {
      console.error('Error loading active bookings:', error);
    } finally {
      setTripsLoading(false);
    }
  }, [user?.id, jobId]);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(markerPulse, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    // Request location permission and get user location
    const requestLocationPermission = async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        setLocationPermission(status);
        
        if (status === 'granted') {
          const location = await Location.getCurrentPositionAsync({
            accuracy: Location.Accuracy.High,
          });
          setUserLocation({
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
          });
        }
      } catch (error) {
        console.error('Error getting location:', error);
      }
    };
    
    requestLocationPermission();
    loadValeterLocation();

    loadAllActiveBookings();
  }, [jobId, user?.id, loadAllActiveBookings]);

  const bookingIds = activeBookings.map((b) => b.id).filter(Boolean).join(',');
  useEffect(() => {
    if (activeBookings.length === 0) return;
    const unsub = subscribeToBookings();
    return () => { unsub?.(); };
  }, [bookingIds]);

  useEffect(() => {
    if (activeBookings.length > 0 && selectedIndex > 0) {
      listRef.current?.scrollToOffset({ offset: cardWidth * selectedIndex, animated: false });
    }
  }, [activeBookings.length]);

  // Watch user location for live updates
  useEffect(() => {
    if (locationPermission !== 'granted') return;
    
    const subscription = Location.watchPositionAsync(
      {
        accuracy: Location.Accuracy.High,
        distanceInterval: 100, // Update every 100 meters
        timeInterval: 30000, // Or every 30 seconds
      },
      (location) => {
        setUserLocation({
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        });
      }
    );

    return () => {
      subscription.then(sub => sub.remove());
    };
  }, [locationPermission]);

  const loadValeterLocation = async () => {
    if (!user?.id) return;
    try {
      const { data } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', user.id)
        .single();

      if (data?.last_lat && data?.last_lng) {
        setValeterLocation({ lat: data.last_lat, lng: data.last_lng });
        const newRegion = {
          latitude: data.last_lat,
          longitude: data.last_lng,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        };
        setRegion(newRegion);
        setInitialRegion(newRegion);
      }
    } catch (error) {
      console.error('Error loading valeter location:', error);
    }
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (activeJob && activeJob.location_lat && activeJob.location_lng) {
      const newRegion: Region = {
        latitude: activeJob.location_lat,
        longitude: activeJob.location_lng,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      };
      setRegion(newRegion);
      mapRef.current?.animateToRegion(newRegion, 500);
    } else if (initialRegion) {
      setRegion(initialRegion);
      mapRef.current?.animateToRegion(initialRegion, 500);
    } else if (userLocation) {
      const newRegion: Region = {
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      };
      setRegion(newRegion);
      mapRef.current?.animateToRegion(newRegion, 500);
    }
  };

  const subscribeToBookings = () => {
    if (!user?.id || activeBookings.length === 0) return undefined;
    const ids = new Set(activeBookings.map((b) => b.id).filter(Boolean));
    if (ids.size === 0) return undefined;

    const channel = supabase
      .channel('trips-bookings')
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings' },
        (payload) => {
          const updated = payload.new as any;
          if (!ids.has(updated.id)) return;
          setActiveBookings((prev) => {
            const next = prev.map((b) => (b.id === updated.id ? { ...b, ...updated } : b));
            if (updated.status === 'completed' || updated.status === 'cancelled') {
              return next.filter((b) => b.id !== updated.id);
            }
            return next;
          });
          if (updated.status === 'completed' && activeBookings[selectedIndex]?.id === updated.id) {
            router.replace({ pathname: '/valeter/jobs/complete', params: { jobId: updated.id } });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleRefresh = async () => {
    await loadAllActiveBookings();
  };

  const assertNoOtherActiveJob = async (currentBookingId: string) => {
    if (!user?.id) return;

    const { data, error } = await supabase
      .from('bookings')
      .select('id,status')
      .eq('valeter_id', user.id)
      .in('status', ACTIVE_STATUSES)
      .neq('id', currentBookingId)
      .order('request_sent_at', { ascending: false })
      .limit(1)
      .maybeSingle();

    if (error) throw error;

    if (data?.id) {
      throw new Error(
        `You already have another active job (${data.status}). Finish it first before starting service on this one.`
      );
    }
  };

  const updateStatus = async (newStatus: JobStatus, bookingId?: string) => {
    if (!user?.id) return;
    await hapticFeedback('medium');

    const idToUpdate = bookingId ?? activeJob?.id;
    if (!idToUpdate) return;

    try {
      if (newStatus === 'in_progress') {
        await assertNoOtherActiveJob(idToUpdate);
      }

      const { error } = await supabase
        .from('bookings')
        .update({ status: newStatus })
        .eq('id', idToUpdate);

      if (error) throw error;
      setActiveBookings((prev) =>
        prev.map((b) => (b.id === idToUpdate ? { ...b, status: newStatus } : b))
      );
    } catch (error: any) {
      const pgCode = error?.code || error?.details?.code;
      if (
        pgCode === '23505' ||
        String(error?.message || '').toLowerCase().includes('duplicate key value') ||
        String(error?.message || '').includes('ux_active_job_per_valeter')
      ) {
        return;
      }
    }
  };

  const getStatusProgress = (s?: JobStatus): number => {
    const st = s ?? status;
    switch (st) {
      case 'pending_payment': return 20;
      case 'confirmed': return 40;
      case 'en_route': return 60;
      case 'arrived': return 80;
      case 'in_progress': return 90;
      case 'completed': return 100;
      default: return 0;
    }
  };

  const getStatusMessage = (s?: JobStatus): string => {
    const st = s ?? status;
    switch (st) {
      case 'pending_payment': return 'Waiting for customer payment';
      case 'confirmed': return 'Payment received - Ready to start';
      case 'en_route': return 'On the way to location';
      case 'arrived': return 'Arrived at location';
      case 'in_progress': return 'Service in progress';
      case 'completed': return 'Service completed';
      default: return 'Tracking job';
    }
  };

  const handleCallChat = (booking?: any) => {
    const b = booking ?? activeJob;
    const locked = b?.status === 'pending_payment';
    if (locked) {
      hapticFeedback('light');
      Alert.alert('Unlocks after payment', 'Chat / Call becomes available once the customer has paid.');
      return;
    }
    hapticFeedback('light');
    const phone = (b?.customer_phone ?? customerPhone)?.trim();
    if (phone) {
      Linking.openURL(`tel:${phone}`).catch(() =>
        Alert.alert('Cannot call', 'Phone number not available.')
      );
    } else {
      Alert.alert('No contact', 'Customer phone number is not available.');
    }
  };

  const handleCancelBooking = (booking?: any) => {
    hapticFeedback('light');
    const b = booking ?? activeJob;
    const idToCancel = b?.id;
    if (!idToCancel) return;
    Alert.alert(
      'Cancel booking',
      'Cancel this booking? You will be removed from this job.',
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, cancel',
          style: 'destructive',
          onPress: async () => {
            try {
              const { error } = await supabase
                .from('bookings')
                .update({ status: 'cancelled', valeter_id: null })
                .eq('id', idToCancel);
              if (error) throw error;
              setActiveBookings((prev) => {
                const next = prev.filter((x) => x.id !== idToCancel);
                if (next.length === 0) setTimeout(() => router.replace('/valeter/jobs'), 0);
                return next;
              });
              setSelectedIndex((i) => Math.min(i, Math.max(0, activeBookings.length - 2)));
              Alert.alert('Cancelled', 'Booking cancelled.');
            } catch (e: any) {
              Alert.alert('Error', e?.message ?? 'Failed to cancel booking.');
            }
          },
        },
      ]
    );
  };

  const getNextAction = (booking?: any): { label: string; action: () => void | Promise<void> } | null => {
    const b = booking ?? activeJob;
    const st = b?.status ?? status;
    switch (st) {
      case 'pending_payment':
        return null;
      case 'confirmed':
        return {
          label: 'Start Journey',
          action: async () => {
            await updateStatus('en_route', b?.id);
            if (b?.location_lat != null && b?.location_lng != null) {
              openTurnByTurnNavigation(
                b.location_lat,
                b.location_lng,
                b.location_address ?? undefined
              );
              Alert.alert(
                'Navigation started',
                'When you arrive, return to this app and tap "Mark Arrived".',
                [{ text: 'OK' }]
              );
            }
          },
        };
      case 'en_route':
        return { label: 'Mark Arrived', action: () => updateStatus('arrived', b?.id) };
      case 'arrived':
        return { label: 'Start Service', action: () => updateStatus('in_progress', b?.id) };
      case 'in_progress':
        return { label: 'Complete Service', action: () => updateStatus('completed', b?.id) };
      default:
        return null;
    }
  };

  const nextAction = getNextAction();
  const mapSelectedJob = activeBookings[selectedIndex] ?? null;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
        <View style={styles.mapContainer}>
          <MapView
            ref={mapRef}
            style={styles.map}
            region={region}
            showsUserLocation={true}
            showsMyLocationButton={false}
            mapType="standard"
            mapPadding={{ top: 0, bottom: height * 0.4, left: 0, right: 0 }}
            loadingEnabled={true}
            loadingIndicatorColor={SKY}
            followsUserLocation={false}
            userLocationPriority="high"
            userLocationUpdateInterval={5000}
          >
            {valeterLocation && (
              <Marker
                coordinate={{
                  latitude: valeterLocation.lat,
                  longitude: valeterLocation.lng,
                }}
                anchor={{ x: 0.5, y: 0.5 }}
              >
                <View style={styles.valeterMarker}>
                  <View style={styles.valeterMarkerShadow} />
                  <View style={styles.valeterMarkerIcon}>
                    <Ionicons name="car" size={18} color="#FFFFFF" />
                  </View>
                </View>
              </Marker>
            )}
            {mapSelectedJob != null && mapSelectedJob.location_lat != null && mapSelectedJob.location_lng != null && (
              <Marker
                coordinate={{
                  latitude: mapSelectedJob.location_lat,
                  longitude: mapSelectedJob.location_lng,
                }}
                anchor={{ x: 0.5, y: 0.5 }}
              >
                <Animated.View
                  style={[
                    styles.markerContainer,
                    { transform: [{ scale: markerPulse }] },
                  ]}
                >
                  <View style={styles.marker}>
                    <Image
                      source={CUSTOMER_MAP_ICON}
                      style={styles.carMarkerImage}
                      resizeMode="contain"
                    />
                  </View>
                </Animated.View>
              </Marker>
            )}
          </MapView>
        </View>
        
        <View style={styles.headerOverlay}>
          <AppHeader
            title="Trips"
            rightAction={
              <View style={styles.headerActions}>
                <TouchableOpacity
                  onPress={handleRecenter}
                  style={styles.recenterButton}
                >
                  <Ionicons name="locate" size={20} color={SKY} />
                </TouchableOpacity>
                <TouchableOpacity onPress={handleRefresh} style={styles.refreshButton}>
                  <Ionicons name="refresh" size={20} color={SKY} />
                </TouchableOpacity>
              </View>
            }
            accountType="valeter"
          />
        </View>

        {activeBookings.length === 0 ? (
          <View style={[styles.emptyContainer, { bottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 80 }]}>
            <BlurView intensity={60} tint="dark" style={styles.emptyCard}>
              <View style={styles.jobCardBackground} />
              <View style={styles.jobCardBorder} />
              <View style={styles.emptyContent}>
                <Ionicons name="navigate-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
                <Text style={styles.emptyTitle}>No Active Trips</Text>
                <Text style={styles.emptyText}>
                  You don't have any active trips to track. Check the jobs page for available opportunities.
                </Text>
              </View>
            </BlurView>
          </View>
        ) : (
          <Animated.View
            style={[
              styles.cardContainer,
              {
                opacity: fadeAnim,
                bottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom,
              },
            ]}
          >
            <FlatList
              ref={listRef}
              data={activeBookings}
              keyExtractor={(item) => item.id}
              horizontal
              pagingEnabled
              showsHorizontalScrollIndicator={false}
              snapToInterval={cardWidth}
              snapToAlignment="start"
              decelerationRate="fast"
              getItemLayout={(_, index) => ({ length: cardWidth, offset: cardWidth * index, index })}
              onMomentumScrollEnd={(e: NativeSyntheticEvent<NativeScrollEvent>) => {
                const i = Math.round(e.nativeEvent.contentOffset.x / cardWidth);
                setSelectedIndex(i);
                const b = activeBookings[i];
                if (b?.location_lat != null && b?.location_lng != null) {
                  const newRegion: Region = {
                    latitude: b.location_lat,
                    longitude: b.location_lng,
                    latitudeDelta: 0.01,
                    longitudeDelta: 0.01,
                  };
                  setRegion(newRegion);
                  mapRef.current?.animateToRegion(newRegion, 400);
                }
              }}
              renderItem={({ item: booking }) => {
                const st = booking.status as JobStatus;
                const nextAction = getNextAction(booking);
                return (
                  <View style={[styles.cardSlide, { width: cardWidth }]}>
                    <View style={styles.trackingCardPremium}>
                      <BlurView intensity={40} tint="dark" style={styles.trackingCardBlur} />
                      <LinearGradient
                        colors={['rgba(135,206,235,0.12)', 'rgba(135,206,235,0.06)']}
                        style={StyleSheet.absoluteFill}
                      />
                      <View style={styles.trackingCardGradient}>
                        <View style={styles.trackingStatusBar}>
                          {[20, 40, 60, 80, 100].map((p, i) => (
                            <React.Fragment key={p}>
                              <View style={[styles.trackingStatusDot, getStatusProgress(st) >= p && styles.trackingStatusDotDone]} />
                              {i < 4 && <View style={[styles.trackingStatusLine, getStatusProgress(st) >= p + 20 && styles.trackingStatusLineDone]} />}
                            </React.Fragment>
                          ))}
                        </View>
                        <View style={styles.trackingHeader}>
                          <StatusBadge status={st} size="medium" />
                          <Text style={styles.statusMessage}>{getStatusMessage(st)}</Text>
                        </View>

                        <View style={styles.progressRow}>
                          {(() => {
                            const chatCallLocked = st === 'pending_payment';
                            return (
                              <TouchableOpacity
                                onPress={() => handleCallChat(booking)}
                                style={[styles.iconButton, chatCallLocked && styles.iconButtonLocked]}
                                activeOpacity={0.8}
                                disabled={chatCallLocked}
                              >
                                <View style={[styles.iconButtonInner, chatCallLocked && styles.iconButtonInnerLocked]}>
                                  <Ionicons name="chatbubble-ellipses" size={24} color={chatCallLocked ? 'rgba(255,255,255,0.4)' : SKY} />
                                </View>
                                <Text style={[styles.iconButtonLabel, chatCallLocked && styles.iconButtonLabelLocked]}>
                                  {chatCallLocked ? 'Chat / Call (after payment)' : 'Chat / Call'}
                                </Text>
                              </TouchableOpacity>
                            );
                          })()}
                          <View style={styles.progressRingWrap}>
                            <AnimatedProgress progress={getStatusProgress(st)} size={100} />
                          </View>
                          <TouchableOpacity onPress={() => handleCancelBooking(booking)} style={styles.iconButton} activeOpacity={0.8}>
                            <View style={[styles.iconButtonInner, styles.iconButtonCancel]}>
                              <Ionicons name="close-circle" size={24} color="#EF4444" />
                            </View>
                            <Text style={styles.iconButtonLabel}>Cancel</Text>
                          </TouchableOpacity>
                        </View>

                        <View style={styles.jobInfo}>
                          <View style={styles.infoRow}>
                            <Ionicons name="water-outline" size={16} color={SKY} />
                            <Text style={styles.infoText}>
                              {getServiceDisplayName(booking.service_type, booking.service_name)}
                            </Text>
                          </View>
                          {booking.user_id && (
                            <View style={styles.infoRow}>
                              <Ionicons name="person-outline" size={16} color={SKY} />
                              <Text style={styles.infoText}>{booking.customer_name ?? 'Customer'}</Text>
                            </View>
                          )}
                          <View style={styles.infoRow}>
                            <Ionicons name="location-outline" size={16} color={SKY} />
                            <Text style={styles.infoText} numberOfLines={1}>
                              {booking.location_address}
                            </Text>
                          </View>
                          {(booking.vehicle_registration || booking.vehicle_type || booking.vehicle_make || booking.vehicle_model) && (
                            <View style={styles.infoRow}>
                              <Ionicons name="car-sport-outline" size={16} color={SKY} />
                              <View style={styles.vehicleInfoContainer}>
                                {booking.vehicle_registration && (
                                  <Text style={styles.vehicleRegistration}>{booking.vehicle_registration}</Text>
                                )}
                                {(booking.vehicle_make || booking.vehicle_model || booking.vehicle_type) && (
                                  <Text style={styles.infoText}>
                                    {[booking.vehicle_make, booking.vehicle_model, booking.vehicle_type].filter(Boolean).join(' ')}
                                  </Text>
                                )}
                              </View>
                            </View>
                          )}
                          <View style={styles.infoRow}>
                            <Ionicons name="cash-outline" size={16} color={SKY} />
                            <Text style={styles.infoText}>£{booking.price?.toFixed(2) || '0.00'}</Text>
                          </View>
                        </View>

                        {nextAction && (
                          <TouchableOpacity
                            onPress={nextAction.action}
                            style={styles.actionButton}
                            activeOpacity={0.8}
                          >
                            <LinearGradient
                              colors={[SKY, '#60A5FA']}
                              style={styles.actionGradient}
                            >
                              <Text style={styles.actionText}>{nextAction.label}</Text>
                              <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                            </LinearGradient>
                          </TouchableOpacity>
                        )}
                      </View>
                    </View>
                  </View>
                );
              }}
            />
            {activeBookings.length > 1 && (
              <View style={styles.pageIndicator}>
                {activeBookings.map((_, i) => (
                  <View
                    key={i}
                    style={[
                      styles.pageDot,
                      i === selectedIndex && styles.pageDotActive,
                    ]}
                  />
                ))}
              </View>
            )}
          </Animated.View>
        )}
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  content: {
    flex: 1,
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
    backgroundColor: 'transparent',
  },
  headerActions: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  refreshButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  mapContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  valeterMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  valeterMarkerShadow: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: SKY,
    opacity: 0.3,
  },
  valeterMarkerIcon: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  marker: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
  },
  carMarkerImage: {
    width: 28,
    height: 28,
  },
  jobCardBackground: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(135,206,235,0.18)',
    borderRadius: 20,
  },
  jobCardBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.5)',
    pointerEvents: 'none',
  },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 16,
  },
  cardSlide: {
    paddingHorizontal: 0,
  },
  pageIndicator: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    marginTop: 12,
  },
  pageDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  pageDotActive: {
    backgroundColor: SKY,
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  trackingCardPremium: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 14,
  },
  trackingCardBlur: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
  },
  trackingCardGradient: {
    padding: 18,
  },
  trackingStatusBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingHorizontal: 4,
  },
  trackingStatusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: 'rgba(135,206,235,0.3)',
  },
  trackingStatusDotDone: {
    backgroundColor: SKY,
  },
  trackingStatusLine: {
    flex: 1,
    height: 3,
    backgroundColor: 'rgba(135,206,235,0.2)',
    marginHorizontal: 2,
    borderRadius: 2,
  },
  trackingStatusLineDone: {
    backgroundColor: SKY,
  },
  trackingHeader: {
    alignItems: 'center',
    marginBottom: 12,
  },
  statusMessage: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
    marginTop: 12,
    textAlign: 'center',
  },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
    paddingHorizontal: 8,
  },
  progressRingWrap: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconButton: {
    alignItems: 'center',
    minWidth: 64,
  },
  iconButtonInner: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 4,
  },
  iconButtonCancel: {
    backgroundColor: 'rgba(239,68,68,0.15)',
  },
  iconButtonLabel: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 12,
    fontWeight: '600',
  },
  iconButtonLocked: { opacity: 0.7 },
  iconButtonInnerLocked: { backgroundColor: 'rgba(255,255,255,0.06)' },
  iconButtonLabelLocked: { color: 'rgba(249,250,251,0.5)' },
  jobInfo: {
    gap: 10,
    marginBottom: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  infoText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
  },
  vehicleInfoContainer: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flexWrap: 'wrap',
  },
  vehicleRegistration: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 1,
    fontFamily: 'monospace',
  },
  actionButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  actionGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 8,
  },
  actionText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  emptyContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    padding: 20,
  },
  emptyCard: {
    padding: 40,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.5)',
    backgroundColor: 'rgba(135,206,235,0.12)',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    position: 'relative',
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
  },
});
