import React, { useMemo, useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  Platform,
  Modal,
  Pressable,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname, useRouter, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { supabase } from '../../src/lib/supabase';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { getIconColors, getTextColors } from '../../src/constants/themeColors';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import GlassCard from '../../src/components/booking/GlassCard';
import { useGlobalTheme } from '../../src/components/shared/GlobalThemeContext';
const TAB_BAR_HEIGHT = 72;
const BAR_MARGIN_H = 20;
const BAR_RADIUS = 36;

// Business: individual floating icons (no shared bar)
const FLOATING_ICON_SIZE = 52;
const FLOATING_ICON_RADIUS = FLOATING_ICON_SIZE / 2;
const FLOATING_ICON_GAP = 10;

// Used by screens to pad content above the bar (DO NOT include safe area here)
const TAB_BAR_TOTAL_HEIGHT = TAB_BAR_HEIGHT - 18;
export { TAB_BAR_TOTAL_HEIGHT };

type IoniconsName = keyof typeof Ionicons.glyphMap;

interface Tab {
  name: string;
  iconName: IoniconsName;
  route: string;
}

const getTabs = (userType?: string): Tab[] => {
  if (userType === 'valeter') {
    return [
      { name: 'Home', iconName: 'home', route: '/valeter/valeter-dashboard' },
      { name: 'Jobs', iconName: 'briefcase', route: '/valeter/jobs' },
      { name: 'Trips', iconName: 'navigate', route: '/valeter/trips' },
      { name: 'Hours', iconName: 'time', route: '/valeter/settings/working-hours' },
      { name: 'Profile', iconName: 'person', route: '/valeter/profile/valeter-profile' },
    ];
  }

  if (userType === 'organization') {
    return [
      { name: 'Home', iconName: 'home', route: '/business/dashboard' },
      { name: 'Locations', iconName: 'location', route: '/business/locations' },
      { name: 'Bookings', iconName: 'calendar', route: '/business/bookings' },
      { name: 'Team', iconName: 'people', route: '/business/team' },
      { name: 'Profile', iconName: 'person', route: '/business/profile' },
    ];
  }

  // Owner/customer pages removed – no tabs for customer
  return [];
};

const getActiveIndex = (pathname: string, tabs: Tab[]): number => {
  if (pathname.includes('/booking')) {
    const bookIndex = tabs.findIndex((t) => t.route.includes('/booking'));
    return bookIndex >= 0 ? bookIndex : 0;
  }

  if (pathname.includes('/rewards')) {
    const rewardsIndex = tabs.findIndex((t) => t.route === '/rewards' || t.route.includes('rewards'));
    return rewardsIndex >= 0 ? rewardsIndex : 0;
  }

  if (pathname.includes('/valeter/jobs')) {
    const jobsIndex = tabs.findIndex((t) => t.route === '/valeter/jobs');
    return jobsIndex >= 0 ? jobsIndex : 0;
  }

  if (pathname.includes('/valeter/trips')) {
    const tripsIndex = tabs.findIndex((t) => t.route === '/valeter/trips');
    return tripsIndex >= 0 ? tripsIndex : 0;
  }

  if (pathname.includes('/valeter/settings/working-hours')) {
    const hoursIndex = tabs.findIndex((t) => t.route === '/valeter/settings/working-hours');
    return hoursIndex >= 0 ? hoursIndex : 0;
  }
  if (pathname.includes('/valeter/settings/distance-covering')) {
    const radiusIndex = tabs.findIndex((t) => t.route === '/valeter/settings/distance-covering');
    return radiusIndex >= 0 ? radiusIndex : 0;
  }

  if (pathname.includes('/valeter/profile/valeter-profile') || pathname.includes('/valeter/valeter-profile')) {
    const profileIndex = tabs.findIndex((t) => t.route === '/valeter/profile/valeter-profile');
    return profileIndex >= 0 ? profileIndex : 0;
  }

  if (pathname.includes('/business/dashboard')) {
    const homeIndex = tabs.findIndex((t) => t.route === '/business/dashboard');
    return homeIndex >= 0 ? homeIndex : 0;
  }
  if (pathname.includes('/business/locations')) {
    const locationsIndex = tabs.findIndex((t) => t.route === '/business/locations');
    return locationsIndex >= 0 ? locationsIndex : 0;
  }
  if (pathname.includes('/business/bookings')) {
    const bookingsIndex = tabs.findIndex((t) => t.route === '/business/bookings');
    return bookingsIndex >= 0 ? bookingsIndex : 0;
  }
  if (pathname.includes('/business/team')) {
    const teamIndex = tabs.findIndex((t) => t.route === '/business/team');
    return teamIndex >= 0 ? teamIndex : 0;
  }
  if (pathname.includes('/business/profile')) {
    const profileIndex = tabs.findIndex((t) => t.route === '/business/profile');
    return profileIndex >= 0 ? profileIndex : 0;
  }

  for (let i = 0; i < tabs.length; i++) {
    if (pathname === tabs[i].route || pathname.startsWith(tabs[i].route + '/')) return i;
  }

  return 0;
};

export default function NavigationTab() {
  const { mode } = useGlobalTheme();
  const pathname = usePathname();
  const router = useRouter();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [showProfileActions, setShowProfileActions] = useState(false);

  const isBusinessRoute =
    pathname.includes('/business/') ||
    pathname.includes('/Business/') ||
    pathname.includes('/organisation/') ||
    pathname.includes('/Organization/');
  const businessTheme = isBusinessRoute ? getAccountTheme('business') : null;

  const isCustomerRoute = pathname.includes('/owner/') || pathname.includes('/customer');
  const customerTheme = isCustomerRoute ? getAccountTheme('customer') : null;

  const accountTypeForBubbles: 'customer' | 'valeter' | 'business' = useMemo(() => {
    if (pathname.includes('/valeter/')) return 'valeter';
    if (isBusinessRoute) return 'business';
    return 'customer';
  }, [pathname, isBusinessRoute]);

  // Get the theme for the current account type (matches header logic)
  const currentTheme = useMemo(() => {
    if (pathname.includes('/valeter/')) return getAccountTheme('valeter', mode);
    if (isBusinessRoute) return getAccountTheme('business', mode);
    return getAccountTheme('customer', mode);
  }, [pathname, isBusinessRoute, mode]);

  const tabs = useMemo(() => {
    const userType = user?.userType;

    if (pathname.includes('/owner/') || pathname.includes('/customer')) return [];
    if (pathname.includes('/valeter/')) return getTabs('valeter');
    if (isBusinessRoute) return getTabs('organization');

    const safeUserType: 'customer' | 'valeter' | 'organization' =
      userType === 'valeter' ? 'valeter'
      : userType === 'organization' || (userType as string) === 'business' ? 'organization'
      : 'customer';

    if (userType === 'valeter' && !pathname.includes('/valeter/') && !pathname.includes('/driver/')) {
      return getTabs('customer');
    }

    return getTabs(safeUserType);
  }, [user?.userType, user?.email, pathname, isBusinessRoute]);

  const activeIndex = useMemo(() => getActiveIndex(pathname, tabs), [pathname, tabs]);

  const accent = currentTheme?.primary || colors.navActive;
  const iconColors = currentTheme ? getIconColors(currentTheme) : { active: colors.navActive, inactive: 'rgba(255,255,255,0.65)' };
  const textColors = currentTheme ? getTextColors(currentTheme) : { primary: '#F9FAFB', secondary: 'rgba(255,255,255,0.8)' };

  // Use same colors as cards for nav tab (match card look)
  const cardGradient = currentTheme?.cardBackgroundGradient || currentTheme?.headerBackground || currentTheme?.background || ['rgba(30,58,138,0.6)', 'rgba(15,23,42,0.5)'];


  const searchParams = useLocalSearchParams();
  const isTripsPage = pathname.includes('/business/bookings') && searchParams.filter === 'in_progress';

  const shouldHideTab = useMemo(() => {
    const hideRoutes = [
      '/auth/',
      '/onboarding',
      '/customer-onboarding',
      '/valeter/valeter-onboarding',
      '/organisation/organization-onboarding',
    ];
    return hideRoutes.some((route) => pathname.includes(route)) || isTripsPage;
  }, [pathname, isTripsPage]);

  const isProfileTab = (tab: Tab) => tab.name === 'Profile';

  const inactiveIcon = iconColors.inactive;

  useEffect(() => {
    const loadProfilePicture = async () => {
      if (!user?.id) return;

      try {
        if (user.profilePicture) {
          setProfilePicture(user.profilePicture);
          return;
        }

        if (user.userType === 'organization' || (user.userType as string) === 'business') {
          const { data: profileData, error: profileError } = await supabase
            .from('profiles')
            .select('avatar_url, profile_picture')
            .eq('id', user.id)
            .maybeSingle();

          if (!profileError && profileData) {
            const picUrl = (profileData as any).avatar_url || (profileData as any).profile_picture;
            if (picUrl) {
              setProfilePicture(picUrl);
              return;
            }
          }

          const { data: orgData, error: orgError } = await supabase
            .from('organizations')
            .select('*')
            .eq('id', user.id)
            .maybeSingle();

          if (!orgError && orgData && (orgData as any).logo) {
            setProfilePicture((orgData as any).logo);
            return;
          }
        } else {
          const tableName = user.userType === 'valeter' ? 'valeter_profiles' : 'customer_profiles';
          const { data, error } = await supabase
            .from(tableName)
            .select('avatar_url, profile_picture')
            .eq('user_id', user.id)
            .maybeSingle();

          if (!error && data) {
            const picUrl = (data as any).avatar_url || (data as any).profile_picture;
            if (picUrl) setProfilePicture(picUrl);
          }
        }
      } catch (error) {
        console.error('[NavigationTab] Error loading profile picture:', error);
      }
    };

    loadProfilePicture();
  }, [user?.id, user?.profilePicture, user?.userType]);

  const bottomPad = Math.max(insets.bottom, 10);

  if (shouldHideTab || tabs.length === 0) return null;

  const isBusinessLight = isBusinessRoute && currentTheme?.mode === 'light';

  return (
    <View pointerEvents="box-none" style={styles.screenWrap}>
      {/* ✅ Full screen background underlay */}
      <View
        pointerEvents="none"
        style={[
          styles.underlay,
          {
            top: 0,
            bottom: 0,
          },
        ]}
      />

      {/* Individual floating icons for both business and valeter */}
      <View style={[styles.floatingRow, { marginBottom: bottomPad, paddingHorizontal: BAR_MARGIN_H }]}>
        {tabs.map((tab, index) => {
          const isActive = index === activeIndex;
          const isProfile = isProfileTab(tab);
          const showProfilePic = isProfile && !!profilePicture;
          const useLightBlur = isBusinessRoute && currentTheme?.mode === 'light';

          const handleTabPress = async () => {
            if (isActive && !isProfile) return;
            if (!isActive) {
              await hapticFeedback('light');
              router.push(tab.route as any);
            }
          };

          return (
            <TouchableOpacity
              key={tab.route}
              onPress={handleTabPress}
              activeOpacity={0.85}
              disabled={isActive && !isProfile}
              style={styles.floatingIconTouch}
            >
              <View
                style={[
                  styles.floatingIconCircle,
                  isActive && [styles.floatingIconCircleActive, { borderColor: accent, shadowColor: accent }],
                ]}
              >
                <BlurView
                  intensity={Platform.OS === 'ios' ? (useLightBlur ? 60 : 28) : (useLightBlur ? 50 : 22)}
                  tint={useLightBlur ? 'light' : 'dark'}
                  style={StyleSheet.absoluteFill}
                >
                  <LinearGradient
                    colors={
                      isActive
                        ? [`${accent}40`, `${accent}25`]
                        : [cardGradient[0], cardGradient[1] || cardGradient[0]]
                    }
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={StyleSheet.absoluteFill}
                  />
                </BlurView>
                <View style={StyleSheet.absoluteFill} pointerEvents="none">
                  <View style={[styles.floatingIconInner, { borderColor: currentTheme?.cardBorder || currentTheme?.glassBorder || 'rgba(255,255,255,0.14)' }]} />
                </View>
                {isProfile && showProfilePic && profilePicture ? (
                  <Image source={{ uri: profilePicture }} style={styles.floatingAvatar} />
                ) : (
                  <Ionicons
                    name={tab.iconName}
                    size={isActive ? 24 : 22}
                    color={isActive ? accent : inactiveIcon}
                    style={styles.floatingIcon}
                  />
                )}
              </View>
            </TouchableOpacity>
          );
        })}
      </View>

      <Modal visible={showProfileActions} transparent animationType="slide" onRequestClose={() => setShowProfileActions(false)}>
        <Pressable style={styles.modalOverlay} onPress={() => setShowProfileActions(false)}>
          <Pressable
            style={styles.actionSheetContainer}
            onPress={(e) => e.stopPropagation()}
          >
            <GlassCard style={styles.actionSheet} accountType={isBusinessRoute ? 'business' : 'valeter'}>
              <View style={styles.actionSheetHeader}>
                <Text style={styles.actionSheetTitle}>
                  Profile Options
                </Text>
                <TouchableOpacity onPress={() => setShowProfileActions(false)} style={styles.actionSheetClose}>
                  <Ionicons name="close" size={20} color={accent} />
                </TouchableOpacity>
              </View>

              <View style={styles.actionSheetContent}>
                <TouchableOpacity
                  style={styles.actionSheetItem}
                  onPress={async () => {
                    await hapticFeedback('light');
                    setShowProfileActions(false);
                    router.push('/business/profile' as any);
                  }}
                  activeOpacity={0.85}
                >
                  <GlassCard style={styles.actionSheetItemCard} accountType={isBusinessRoute ? 'business' : 'valeter'}>
                    <View style={[styles.actionSheetIconWrapper, { backgroundColor: `${accent}25` }]}>
                      <Ionicons name="person" size={22} color={accent} />
                    </View>
                    <Text style={styles.actionSheetItemText}>Business Profile</Text>
                    <Ionicons name="chevron-forward" size={18} color={accent} style={{ opacity: 0.7 }} />
                  </GlassCard>
                </TouchableOpacity>

                <TouchableOpacity
                  style={styles.actionSheetItem}
                  onPress={async () => {
                    await hapticFeedback('light');
                    setShowProfileActions(false);
                    router.push('/business/settings' as any);
                  }}
                  activeOpacity={0.85}
                >
                  <GlassCard style={styles.actionSheetItemCard} accountType={isBusinessRoute ? 'business' : 'valeter'}>
                    <View style={[styles.actionSheetIconWrapper, { backgroundColor: `${accent}25` }]}>
                      <Ionicons name="settings" size={22} color={accent} />
                    </View>
                    <Text style={styles.actionSheetItemText}>Settings</Text>
                    <Ionicons name="chevron-forward" size={18} color={accent} style={{ opacity: 0.7 }} />
                  </GlassCard>
                </TouchableOpacity>
              </View>
            </GlassCard>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screenWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    zIndex: 9999,
    elevation: 30,
  },

  // ✅ Full screen background underlay
  underlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    backgroundColor: 'transparent',
  },


  // Business: individual floating icons
  floatingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-evenly',
    gap: FLOATING_ICON_GAP,
  },
  floatingIconTouch: {
    padding: 4,
  },
  floatingIconCircle: {
    width: FLOATING_ICON_SIZE,
    height: FLOATING_ICON_SIZE,
    borderRadius: FLOATING_ICON_RADIUS,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.2)',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    elevation: 12,
  },
  floatingIconCircleActive: {
    borderWidth: 2,
    shadowOpacity: 0.45,
    shadowRadius: 14,
    elevation: 16,
  },
  floatingIconInner: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: FLOATING_ICON_RADIUS,
    borderWidth: 0.5,
  },
  floatingIcon: {
    zIndex: 2,
  },
  floatingAvatar: {
    width: FLOATING_ICON_SIZE - 8,
    height: FLOATING_ICON_SIZE - 8,
    borderRadius: (FLOATING_ICON_SIZE - 8) / 2,
    zIndex: 2,
  },

  bar: {
    height: TAB_BAR_HEIGHT,
    marginHorizontal: BAR_MARGIN_H,
    overflow: 'hidden',
    justifyContent: 'center',
    backgroundColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 16 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 28,
  },

  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
    borderRadius: BAR_RADIUS,
  },

  glowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 8,
  },


  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  tab: {
    height: TAB_BAR_HEIGHT,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 1,
    minWidth: 60,
  },

  iconContainer: {
    position: 'relative',
    marginBottom: 4,
    alignItems: 'center',
    justifyContent: 'center',
    width: 26,
    height: 26,
    borderRadius: 13,
  },
  
  iconContainerActive: {
    // No border needed - the capsule provides the highlight
  },

  icon: {
    zIndex: 2,
  },

  iconActive: {
    transform: [{ scale: 1.05 }],
    shadowColor: '#7DD3FC',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 3,
  },
  
  iconActiveValeter: {
    // Enhanced glow for valeter and business icons
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.8,
    shadowRadius: 12,
    transform: [{ scale: 1.1 }],
  },

  iconGlow: {
    position: 'absolute',
    width: 28,
    height: 28,
    borderRadius: 14,
    zIndex: 1,
    opacity: 0.4,
  },
  
  iconGlowValeter: {
    // Subtle glow for valeter and business - just around icon
    width: 30,
    height: 30,
    borderRadius: 15,
    opacity: 0.5,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 8,
  },

  labelLayout: {
    marginTop: 2,
    textAlign: 'center' as const,
    width: '100%',
    paddingHorizontal: 1,
  },

  labelActive: {
    fontFamily: 'Rubik_700Bold',
    letterSpacing: 0.4,
  },

  avatarWrap: {
    width: 28,
    height: 28,
    borderRadius: 14,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.25)',
    marginBottom: 4,
    backgroundColor: 'rgba(255,255,255,0.08)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 4,
    position: 'relative',
    alignItems: 'center',
    justifyContent: 'center',
  },

  avatarWrapActive: {
    borderWidth: 2.5,
    borderColor: '#7DD3FC',
    shadowColor: '#7DD3FC',
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 6,
  },

  avatarBorder: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    borderRadius: 14,
    borderWidth: 0,
    zIndex: 1,
    pointerEvents: 'none',
  },

  avatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
    zIndex: 0,
    resizeMode: 'cover',
  },

  avatarGlow: {
    position: 'absolute',
    top: -3,
    left: -3,
    right: -3,
    bottom: -3,
    borderRadius: 14,
    zIndex: -1,
    opacity: 0.5,
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    justifyContent: 'flex-end',
  },

  actionSheetContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
  },
  actionSheet: {
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    paddingTop: 20,
    paddingBottom: 40,
    paddingHorizontal: 0,
    marginHorizontal: 0,
  },
  actionSheetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingBottom: 16,
    marginBottom: 8,
  },
  actionSheetTitle: {
    fontSize: 20,
    fontWeight: '900',
    color: '#F9FAFB',
    letterSpacing: 0.3,
  },
  actionSheetClose: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  actionSheetContent: {
    paddingHorizontal: 20,
    gap: 12,
  },
  actionSheetItem: {
    marginBottom: 0,
  },
  actionSheetItemCard: {
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  actionSheetIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionSheetItemText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '800',
    color: '#F9FAFB',
    letterSpacing: 0.2,
  },
});
