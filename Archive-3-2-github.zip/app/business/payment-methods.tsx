import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  ScrollView,
  Switch,
  Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import LoadingView from '../../src/components/shared/LoadingView';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { getIconColors, getTextColors } from '../../src/constants/themeColors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;

type PaymentMethodType = 'bank_account' | 'stripe_connect';

interface PaymentMethod {
  id: string;
  type: PaymentMethodType;
  isDefault: boolean;
  isVerified: boolean;
  accountHolderName?: string;
  last4?: string;
  sortCode?: string;
  bankName?: string;
  stripeStatus?: 'pending' | 'verified' | 'restricted';
  createdAt: string;
}

export default function BusinessPaymentMethods() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const iconColors = getIconColors(businessTheme);
  const textColors = getTextColors(businessTheme);
  const [loading, setLoading] = useState(true);
  const [methods, setMethods] = useState<PaymentMethod[]>([]);
  const [autoPayout, setAutoPayout] = useState(false);
  const [payoutThreshold, setPayoutThreshold] = useState(100);
  const [showAddModal, setShowAddModal] = useState(false);
  const [saving, setSaving] = useState(false);
  const [earningsBalance, setEarningsBalance] = useState(0);
  const [nextPayoutDate, setNextPayoutDate] = useState<string | null>(null);
  const [nextPayoutAmount, setNextPayoutAmount] = useState(0);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
    loadPaymentMethods();
  }, [user?.id]);

  const loadPaymentMethods = async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }
    try {
      setLoading(true);
      // Load from Supabase/Stripe when backend is ready
      setMethods([]);
      setEarningsBalance(0);
      setNextPayoutDate(null);
      setNextPayoutAmount(0);
    } catch (e) {
      console.error('[BusinessPaymentMethods] load error:', e);
    } finally {
      setLoading(false);
    }
  };

  const handleSetDefault = (id: string) => {
    hapticFeedback('light');
    setMethods((prev) =>
      prev.map((m) => ({ ...m, isDefault: m.id === id }))
    );
  };

  const handleAddMethod = () => {
    hapticFeedback('light');
    setShowAddModal(true);
  };

  const handleCloseAddModal = () => setShowAddModal(false);

  const handleSaveNewBank = () => {
    hapticFeedback('light');
    setShowAddModal(false);
    loadPaymentMethods();
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />

      <AppHeader title="Payments" accountType="business" />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: HEADER_CONTENT_OFFSET + 12, paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12 },
        ]}
      >
        <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
          <View style={styles.section}>
            <Text style={[styles.sectionTitle, { color: textColors.tertiary }]}>Receive payouts via Stripe</Text>
            <Text style={styles.sectionSubtitle}>
              Add a bank account or connect Stripe to receive your business earnings.
            </Text>
          </View>

          <GlassCard style={styles.earningsCard} accountType="business">
            <LinearGradient
              colors={[`${businessTheme.primary}25`, `${businessTheme.primaryAlt}15`]}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.earningsRow}>
              <View>
                <Text style={styles.earningsLabel}>Available balance</Text>
                <Text style={styles.earningsAmount}>£{earningsBalance.toFixed(2)}</Text>
              </View>
              <View style={styles.earningsRight}>
                <Text style={styles.nextPayoutLabel}>Next payout</Text>
                <Text style={styles.nextPayoutAmount}>£{nextPayoutAmount.toFixed(2)}</Text>
                <Text style={styles.nextPayoutDate}>{nextPayoutDate ?? '—'}</Text>
              </View>
            </View>
          </GlassCard>

          <GlassCard style={styles.card} accountType="business">
            <View style={styles.autoRow}>
              <View style={styles.autoLeft}>
                <Ionicons name="repeat" size={20} color={iconColors.primary} />
                <View>
                  <Text style={styles.autoTitle}>Auto-payout</Text>
                  <Text style={styles.autoSubtitle}>Send earnings to your bank automatically</Text>
                </View>
              </View>
              <Switch
                value={autoPayout}
                onValueChange={(v) => {
                  hapticFeedback('light');
                  setAutoPayout(v);
                }}
                trackColor={{ false: 'rgba(255,255,255,0.2)', true: businessTheme.primary }}
                thumbColor="#fff"
              />
            </View>
            {autoPayout && (
              <View style={styles.thresholdRow}>
                <Text style={styles.thresholdLabel}>Payout when balance reaches</Text>
                <Text style={styles.thresholdValue}>£{payoutThreshold}</Text>
              </View>
            )}
          </GlassCard>

          <View style={styles.section}>
            <View style={styles.sectionRow}>
              <Text style={[styles.sectionTitle, { color: textColors.tertiary }]}>Payout methods</Text>
              <TouchableOpacity onPress={handleAddMethod} style={styles.addBtn} activeOpacity={0.8}>
                <Ionicons name="add-circle" size={22} color={iconColors.primary} />
                <Text style={[styles.addBtnText, { color: iconColors.primary }]}>Add</Text>
              </TouchableOpacity>
            </View>
          </View>

          {methods.length === 0 ? (
            <GlassCard style={styles.emptyCard} accountType="business">
              <Ionicons name="wallet-outline" size={48} color={iconColors.inactive} />
              <Text style={styles.emptyTitle}>No payout method</Text>
              <Text style={styles.emptySubtitle}>Add a bank account to receive your earnings.</Text>
              <TouchableOpacity onPress={handleAddMethod} style={styles.primaryButton} activeOpacity={0.85}>
                <LinearGradient colors={[businessTheme.primary, businessTheme.primaryAlt]} style={styles.primaryButtonGradient}>
                  <Ionicons name="add" size={20} color="#fff" />
                  <Text style={styles.primaryButtonText}>Add bank account</Text>
                </LinearGradient>
              </TouchableOpacity>
            </GlassCard>
          ) : (
            methods.map((m) => (
              <GlassCard key={m.id} style={styles.methodCard} accountType="business">
                <View style={styles.methodRow}>
                  <View style={[styles.methodIconWrap, { backgroundColor: `${businessTheme.primary}25` }]}>
                    <Ionicons name="business-outline" size={22} color={iconColors.primary} />
                  </View>
                  <View style={styles.methodDetails}>
                    <Text style={styles.methodBank}>{m.bankName || 'Bank account'}</Text>
                    <Text style={styles.methodMeta}>
                      •••• {m.last4} {m.sortCode ? ` • ${m.sortCode}` : ''}
                    </Text>
                    <View style={styles.badges}>
                      {m.isDefault && (
                        <View style={[styles.defaultBadge, { backgroundColor: `${businessTheme.primary}30` }]}>
                          <Text style={[styles.defaultBadgeText, { color: businessTheme.primary }]}>Default</Text>
                        </View>
                      )}
                      {m.isVerified && (
                        <View style={styles.verifiedBadge}>
                          <Ionicons name="checkmark-circle" size={12} color="#10B981" />
                          <Text style={styles.verifiedBadgeText}>Verified</Text>
                        </View>
                      )}
                    </View>
                  </View>
                  {!m.isDefault && (
                    <TouchableOpacity onPress={() => handleSetDefault(m.id)} style={styles.setDefaultBtn}>
                      <Text style={[styles.setDefaultText, { color: businessTheme.primary }]}>Set default</Text>
                    </TouchableOpacity>
                  )}
                </View>
              </GlassCard>
            ))
          )}

          <TouchableOpacity onPress={handleAddMethod} style={[styles.addMethodCard, { borderColor: `${businessTheme.primary}50` }]} activeOpacity={0.85}>
            <Ionicons name="add-circle-outline" size={24} color={iconColors.primary} />
            <Text style={[styles.addMethodText, { color: iconColors.primary }]}>Add bank account or Stripe Connect</Text>
          </TouchableOpacity>

          <View style={styles.footer}>
            <Ionicons name="shield-checkmark" size={16} color={iconColors.secondary} />
            <Text style={styles.footerText}>Payouts are processed securely via Stripe.</Text>
          </View>
        </Animated.View>
      </Animated.ScrollView>

      {showAddModal && (
        <View style={styles.modalOverlay}>
          <View style={styles.modal}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Add bank account</Text>
              <TouchableOpacity onPress={handleCloseAddModal} hitSlop={12}>
                <Ionicons name="close" size={24} color={iconColors.primary} />
              </TouchableOpacity>
            </View>
            <Text style={styles.modalSubtitle}>
              You’ll be taken to Stripe to add your account. We never see your full bank details.
            </Text>
            <TouchableOpacity onPress={handleSaveNewBank} style={styles.primaryButton} activeOpacity={0.85}>
              <LinearGradient colors={[businessTheme.primary, businessTheme.primaryAlt]} style={styles.primaryButtonGradient}>
                {saving ? (
                  <ActivityIndicator size="small" color="#fff" />
                ) : (
                  <>
                    <Ionicons name="open-outline" size={20} color="#fff" />
                    <Text style={[styles.primaryButtonText, { color: '#fff' }]}>Continue with Stripe</Text>
                  </>
                )}
              </LinearGradient>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingHorizontal: 20 },
  content: { gap: 16 },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 14 },
  section: { marginBottom: 4 },
  sectionRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  sectionTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '700', marginBottom: 4 },
  sectionSubtitle: { color: 'rgba(249,250,251,0.7)', fontSize: 13 },
  earningsCard: { padding: 18, marginBottom: 12, overflow: 'hidden' },
  earningsRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  earningsLabel: { color: 'rgba(249,250,251,0.7)', fontSize: 13 },
  earningsAmount: { color: '#F9FAFB', fontSize: 24, fontWeight: '800' },
  earningsRight: { alignItems: 'flex-end' },
  nextPayoutLabel: { color: 'rgba(249,250,251,0.6)', fontSize: 12 },
  nextPayoutAmount: { color: '#F9FAFB', fontSize: 16, fontWeight: '700' },
  nextPayoutDate: { color: 'rgba(249,250,251,0.5)', fontSize: 11 },
  card: { padding: 16, marginBottom: 8 },
  autoRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  autoLeft: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  autoTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '600' },
  autoSubtitle: { color: 'rgba(249,250,251,0.6)', fontSize: 12, marginTop: 2 },
  thresholdRow: { marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: 'rgba(255,255,255,0.1)', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  thresholdLabel: { color: 'rgba(249,250,251,0.7)', fontSize: 13 },
  thresholdValue: { color: '#F9FAFB', fontSize: 16, fontWeight: '700' },
  addBtn: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  addBtnText: { fontSize: 14, fontWeight: '600' },
  emptyCard: { padding: 28, alignItems: 'center', gap: 12 },
  emptyTitle: { color: '#F9FAFB', fontSize: 17, fontWeight: '600' },
  emptySubtitle: { color: 'rgba(249,250,251,0.6)', fontSize: 13 },
  methodCard: { padding: 16, marginBottom: 8 },
  methodRow: { flexDirection: 'row', alignItems: 'center' },
  methodIconWrap: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center', marginRight: 12 },
  methodDetails: { flex: 1 },
  methodBank: { color: '#F9FAFB', fontSize: 16, fontWeight: '600' },
  methodMeta: { color: 'rgba(249,250,251,0.6)', fontSize: 13, marginTop: 2 },
  badges: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 6 },
  defaultBadge: { paddingHorizontal: 8, paddingVertical: 4, borderRadius: 8 },
  defaultBadgeText: { fontSize: 11, fontWeight: '700' },
  verifiedBadge: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  verifiedBadgeText: { color: '#10B981', fontSize: 11, fontWeight: '600' },
  setDefaultBtn: { paddingHorizontal: 12, paddingVertical: 8 },
  setDefaultText: { fontSize: 13, fontWeight: '600' },
  addMethodCard: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, padding: 18, borderWidth: 2, borderStyle: 'dashed', borderRadius: 16, marginTop: 8 },
  addMethodText: { fontSize: 15, fontWeight: '600' },
  primaryButton: { borderRadius: 14, overflow: 'hidden', marginTop: 16 },
  primaryButtonGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, paddingVertical: 14, paddingHorizontal: 20 },
  primaryButtonText: { fontSize: 16, fontWeight: '700' },
  footer: { flexDirection: 'row', alignItems: 'center', gap: 8, marginTop: 24, paddingVertical: 12 },
  footerText: { color: 'rgba(249,250,251,0.6)', fontSize: 12 },
  modalOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', padding: 24 },
  modal: { backgroundColor: '#0f172a', borderRadius: 20, padding: 24, borderWidth: 1, borderColor: 'rgba(59,130,246,0.3)' },
  modalHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 },
  modalTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '700' },
  modalSubtitle: { color: 'rgba(249,250,251,0.7)', fontSize: 14, marginBottom: 20 },
});
