import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Image,
  Linking,
  Modal,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Region } from 'react-native-maps';
import { CUSTOMER_MAP_ICON, HUB_MAP_ICON } from '../../../src/constants/mapIcons';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import AppHeader from '../../../src/components/shared/AppHeader';
import LoadingView from '../../../src/components/shared/LoadingView';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { colors } from '../../../src/constants/colors';
import { getAccountTheme } from '../../../src/constants/accountThemes';
import { getIconColors } from '../../../src/constants/themeColors';
import { useAccountTheme } from '../../../src/components/shared/AccountThemeProvider';

const SKY = colors.SKY;
const BG = colors.BG;
const { width, height } = Dimensions.get('window');

const CONFETTI_COLORS = ['#FFD700', '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4', '#FFEAA7', '#DDA0DD', '#98D8C8'];
const CONFETTI_COUNT = 50;

type BookingStatus =
  | 'pending_business_acceptance'
  | 'pending_valeter_acceptance'
  | 'pending_payment'
  | 'confirmed'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

export default function BusinessBookingTracking() {
  const params = useLocalSearchParams<{ bookingId: string }>();
  const bookingId = params.bookingId;
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const { theme } = useAccountTheme();
  const iconColors = getIconColors(theme);

  const [booking, setBooking] = useState<any | null>(null);
  const [hubLocation, setHubLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [status, setStatus] = useState<BookingStatus>('confirmed');
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  });
  const [customerPhone, setCustomerPhone] = useState<string | null>(null);
  const [showCompletedOverlay, setShowCompletedOverlay] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const overlayScale = useRef(new Animated.Value(0.8)).current;
  const overlayOpacity = useRef(new Animated.Value(0)).current;
  const confettiParticles = useRef(
    Array.from({ length: CONFETTI_COUNT }, () => ({
      x: Math.random() * width,
      delay: Math.random() * 400,
      duration: 2000 + Math.random() * 1500,
      color: CONFETTI_COLORS[Math.floor(Math.random() * CONFETTI_COLORS.length)],
      size: 6 + Math.random() * 8,
      startY: -20,
    }))
  ).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 400, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (!bookingId) return;
    loadBooking();
  }, [bookingId]);

  useEffect(() => {
    if (!bookingId) return;
    const channel = supabase
      .channel(`booking-${bookingId}`)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `id=eq.${bookingId}` }, (payload) => {
        const next = (payload.new as any)?.status;
        if (next) setStatus(next as BookingStatus);
      })
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [bookingId]);

  const loadBooking = async () => {
    if (!bookingId) return;
    try {
      const { data: bookingData, error: bookingError } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', bookingId)
        .single();

      if (bookingError || !bookingData) {
        Alert.alert('Error', 'Booking not found');
        router.back();
        return;
      }

      setBooking(bookingData);
      setStatus((bookingData.status as BookingStatus) || 'confirmed');

      const locLat = bookingData.location_lat ?? bookingData.customer_lat;
      const locLng = bookingData.location_lng ?? bookingData.customer_lng;
      if (locLat != null && locLng != null) {
        setRegion({
          latitude: Number(locLat),
          longitude: Number(locLng),
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        });
      }

      if (bookingData.user_id) {
        const { data: profile } = await supabase
          .from('profiles')
          .select('phone')
          .eq('id', bookingData.user_id)
          .maybeSingle();
        setCustomerPhone((profile as any)?.phone ?? null);
      }

      const orgId = (bookingData as any).organization_id ?? user?.organizationId ?? null;
      if (orgId) {
        const { data: locData } = await supabase
          .from('car_wash_locations')
          .select('latitude, longitude')
          .eq('organization_id', orgId)
          .not('latitude', 'is', null)
          .limit(1)
          .maybeSingle();
        if (locData && (locData as any).latitude != null) {
          setHubLocation({
            lat: Number((locData as any).latitude),
            lng: Number((locData as any).longitude),
          });
        }
      }
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Failed to load booking');
      router.back();
    }
  };

  const getStatusProgress = (): number => {
    switch (status) {
      case 'pending_business_acceptance':
      case 'pending_valeter_acceptance':
      case 'pending_payment':
        return 10;
      case 'confirmed':
        return 25;
      case 'en_route':
        return 50;
      case 'arrived':
        return 70;
      case 'in_progress':
        return 90;
      case 'completed':
        return 100;
      case 'cancelled':
        return 0;
      default:
        return 20;
    }
  };

  const getStatusMessage = (): string => {
    switch (status) {
      case 'pending_payment':
        return 'Waiting for payment';
      case 'confirmed':
        return 'Confirmed – customer may be on the way';
      case 'en_route':
        return 'Customer en route';
      case 'arrived':
        return 'Customer arrived – wash can start';
      case 'in_progress':
        return 'Wash in progress';
      case 'completed':
        return 'Wash completed';
      case 'cancelled':
        return 'Booking cancelled';
      default:
        return 'Tracking booking';
    }
  };

  const chatCallLocked = status === 'pending_payment';

  const handleChat = () => {
    if (chatCallLocked) {
      hapticFeedback('light');
      Alert.alert('Unlocks after payment', 'Chat / Call becomes available once the customer has paid.');
      return;
    }
    hapticFeedback('light');
    if (customerPhone) {
      Linking.openURL(`tel:${customerPhone}`).catch(() =>
        Alert.alert('Cannot call', 'Phone number not available.')
      );
    } else {
      Alert.alert('Contact customer', 'Chat and call will use the customer’s number when available. For now, contact them via your usual channel.');
    }
  };

  const handleCancel = () => {
    hapticFeedback('light');
    Alert.alert(
      'Cancel booking',
      'Cancel this booking? The customer will be notified.',
      [
        { text: 'No', style: 'cancel' },
        {
          text: 'Yes, cancel',
          style: 'destructive',
          onPress: async () => {
            if (!bookingId) return;
            const { error } = await supabase.from('bookings').update({ status: 'cancelled' }).eq('id', bookingId);
            if (error) Alert.alert('Error', error.message);
            else {
              setStatus('cancelled');
              Alert.alert('Cancelled', 'Booking cancelled.');
            }
          },
        },
      ]
    );
  };

  const updateStatus = async (newStatus: BookingStatus) => {
    if (!bookingId) return;
    await hapticFeedback('medium');
    try {
      const { error } = await supabase.from('bookings').update({ status: newStatus }).eq('id', bookingId);
      if (error) throw error;
      setStatus(newStatus);
      if (newStatus === 'completed') setShowCompletedOverlay(true);
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Failed to update status');
    }
  };

  useEffect(() => {
    if (!showCompletedOverlay) return;
    overlayScale.setValue(0.8);
    overlayOpacity.setValue(0);
    Animated.parallel([
      Animated.timing(overlayOpacity, { toValue: 1, duration: 300, useNativeDriver: true }),
      Animated.spring(overlayScale, { toValue: 1, tension: 60, friction: 8, useNativeDriver: true }),
    ]).start();
  }, [showCompletedOverlay]);

  const fallAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (!showCompletedOverlay) return;
    fallAnim.setValue(0);
    Animated.timing(fallAnim, { toValue: 1, duration: 3200, useNativeDriver: true }).start();
  }, [showCompletedOverlay]);

  const dismissCompletedOverlay = () => {
    setShowCompletedOverlay(false);
    router.back();
  };

  const getNextAction = (): { label: string; action: () => void } | null => {
    switch (status) {
      case 'confirmed':
        return { label: 'Mark customer arrived', action: () => updateStatus('arrived') };
      case 'arrived':
        return { label: 'Start wash', action: () => updateStatus('in_progress') };
      case 'in_progress':
        return { label: 'Mark complete', action: () => updateStatus('completed') };
      default:
        return null;
    }
  };

  const nextAction = getNextAction();

  const customerCoords = useMemo(() => {
    if (!booking) return null;
    const lat = booking.location_lat ?? booking.customer_lat;
    const lng = booking.location_lng ?? booking.customer_lng;
    if (lat == null || lng == null) return null;
    return { latitude: Number(lat), longitude: Number(lng) };
  }, [booking]);

  if (!bookingId) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.centerContent}>
          <Text style={styles.errorText}>No booking selected</Text>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={styles.backBtnText}>Go back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (!booking) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={[BG, '#0f172a']} style={StyleSheet.absoluteFill} />
        <AppHeader title="Tracking" accountType="business" />
        <LoadingView style={styles.loadingWrap} />
      </SafeAreaView>
    );
  }

  const mapRegion: Region = customerCoords
    ? { ...region, latitude: customerCoords.latitude, longitude: customerCoords.longitude }
    : region;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {/* Completed overlay with confetti */}
      <Modal visible={showCompletedOverlay} transparent animationType="none">
        <Pressable style={styles.overlayBackdrop} onPress={dismissCompletedOverlay}>
          <View style={StyleSheet.absoluteFill} pointerEvents="none">
            {confettiParticles.map((p, i) => (
              <Animated.View
                key={i}
                pointerEvents="none"
                style={[
                  styles.confettiPiece,
                  {
                    left: p.x,
                    top: p.startY,
                    width: p.size,
                    height: p.size * 1.2,
                    backgroundColor: p.color,
                    borderRadius: p.size > 10 ? 2 : 1,
                  },
                  {
                    transform: [
                      {
                        translateY: fallAnim.interpolate({
                          inputRange: [0, Math.max(0.02, i / CONFETTI_COUNT), 1],
                          outputRange: [0, 0, height + 60],
                        }),
                      },
                    ],
                  },
                ]}
              />
            ))}
          </View>
          <Pressable style={styles.overlayContent} onPress={(e) => e.stopPropagation()}>
            <Animated.View style={[styles.boomCard, { opacity: overlayOpacity, transform: [{ scale: overlayScale }] }]}>
              <LinearGradient colors={['rgba(56,189,248,0.35)', 'rgba(15,23,42,0.98)']} style={styles.boomCardGradient}>
                <Text style={styles.boomTitle}>Boom!</Text>
                <Text style={styles.boomSubtitle}>Onto the next customer!</Text>
                <TouchableOpacity style={styles.boomButton} onPress={dismissCompletedOverlay} activeOpacity={0.85}>
                  <LinearGradient colors={[SKY, '#60A5FA']} style={styles.boomButtonGradient}>
                    <Text style={styles.boomButtonText}>Back to bookings</Text>
                    <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                  </LinearGradient>
                </TouchableOpacity>
              </LinearGradient>
            </Animated.View>
          </Pressable>
        </Pressable>
      </Modal>

      <View style={styles.mapWrapper}>
        <MapView
          style={styles.map}
          region={mapRegion}
          mapType="mutedStandard"
          showsUserLocation={false}
          mapPadding={{ top: 0, bottom: 320, left: 0, right: 0 }}
        >
          {hubLocation && (
            <Marker coordinate={{ latitude: hubLocation.lat, longitude: hubLocation.lng }} anchor={{ x: 0.5, y: 0.5 }}>
              <View style={styles.hubMarker}>
                <Image source={HUB_MAP_ICON} style={styles.hubMarkerImage} resizeMode="contain" />
              </View>
            </Marker>
          )}
          {customerCoords && (
            <Marker coordinate={customerCoords} anchor={{ x: 0.5, y: 0.5 }}>
              <View style={styles.customerMarker}>
                <Image source={CUSTOMER_MAP_ICON} style={styles.carMarkerImage} resizeMode="contain" />
              </View>
            </Marker>
          )}
        </MapView>

        <View style={styles.headerOverlay}>
          <AppHeader title="Tracking" accountType="business" />
        </View>

        <Animated.View
          style={[
            styles.cardContainer,
            {
              opacity: fadeAnim,
              bottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
            },
          ]}
        >
          <View style={styles.trackingCard}>
            <LinearGradient colors={['rgba(135,206,235,0.2)', 'rgba(15,23,42,0.98)']} style={styles.trackingCardGradient}>
              {/* Progress steps bar (like valeter) */}
              <View style={styles.statusBar}>
                {[20, 40, 60, 80, 100].map((p) => (
                  <React.Fragment key={p}>
                    <View style={[styles.statusDot, getStatusProgress() >= p && styles.statusDotDone]} />
                    {p < 100 && <View style={[styles.statusLine, getStatusProgress() >= p + 20 && styles.statusLineDone]} />}
                  </React.Fragment>
                ))}
              </View>

              <View style={styles.trackingHeader}>
                <StatusBadge status={status as any} size="medium" />
                <Text style={styles.statusMessage}>{getStatusMessage()}</Text>
              </View>

              <View style={styles.progressRow}>
                <AnimatedProgress progress={getStatusProgress()} size={90} />
                <View style={styles.actionIcons}>
                  <TouchableOpacity
                    onPress={handleChat}
                    style={[styles.iconButton, chatCallLocked && styles.iconButtonLocked]}
                    activeOpacity={0.8}
                    disabled={chatCallLocked}
                  >
                    <View style={[styles.iconButtonInner, chatCallLocked && styles.iconButtonInnerLocked]}>
                      <Ionicons name="chatbubble-ellipses" size={24} color={chatCallLocked ? 'rgba(255,255,255,0.4)' : iconColors.primary} />
                    </View>
                    <Text style={[styles.iconButtonLabel, chatCallLocked && styles.iconButtonLabelLocked]}>
                      {chatCallLocked ? 'Chat / Call (after payment)' : 'Chat / Call'}
                    </Text>
                  </TouchableOpacity>
                  <TouchableOpacity onPress={handleCancel} style={styles.iconButton} activeOpacity={0.8}>
                    <View style={[styles.iconButtonInner, styles.iconButtonCancel]}>
                      <Ionicons name="close-circle" size={24} color="#EF4444" />
                    </View>
                    <Text style={styles.iconButtonLabel}>Cancel</Text>
                  </TouchableOpacity>
                </View>
              </View>

              <View style={styles.jobInfo}>
                <View style={styles.infoRow}>
                  <Ionicons name="person-outline" size={16} color={SKY} />
                  <Text style={styles.infoText}>{booking.customer_name ?? 'Customer'}</Text>
                </View>
                <View style={styles.infoRow}>
                  <Ionicons name="location-outline" size={16} color={SKY} />
                  <Text style={styles.infoText} numberOfLines={1}>{booking.location_address ?? '—'}</Text>
                </View>
                {booking.service_name && (
                  <View style={styles.infoRow}>
                    <Ionicons name="water-outline" size={16} color={SKY} />
                    <Text style={styles.infoText}>{booking.service_name}</Text>
                  </View>
                )}
              </View>

              {nextAction && (
                <TouchableOpacity style={styles.nextActionButton} onPress={nextAction.action} activeOpacity={0.8}>
                  <LinearGradient colors={[SKY, '#60A5FA']} style={styles.nextActionGradient}>
                    <Text style={styles.nextActionText}>{nextAction.label}</Text>
                    <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                  </LinearGradient>
                </TouchableOpacity>
              )}
            </LinearGradient>
          </View>
        </Animated.View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  mapWrapper: { flex: 1 },
  map: { ...StyleSheet.absoluteFillObject },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
  },
  hubMarker: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.95)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  hubMarkerImage: { width: 28, height: 28 },
  customerMarker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#EF4444',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  carMarkerImage: { width: 28, height: 28 },
  loadingWrap: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 14 },
  centerContent: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 16 },
  errorText: { color: '#F9FAFB', fontSize: 16 },
  backBtn: { paddingVertical: 12, paddingHorizontal: 24, backgroundColor: SKY, borderRadius: 12 },
  backBtnText: { color: '#FFF', fontWeight: '700' },
  cardContainer: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 100,
  },
  trackingCard: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    elevation: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.35,
    shadowRadius: 14,
  },
  trackingCardGradient: { padding: 18 },
  statusBar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
    paddingHorizontal: 4,
  },
  statusDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: 'rgba(135,206,235,0.3)',
  },
  statusDotDone: { backgroundColor: SKY },
  statusLine: {
    flex: 1,
    height: 3,
    backgroundColor: 'rgba(135,206,235,0.2)',
    marginHorizontal: 2,
    borderRadius: 2,
  },
  statusLineDone: { backgroundColor: SKY },
  trackingHeader: { alignItems: 'center', marginBottom: 12 },
  statusMessage: { color: '#F9FAFB', fontSize: 15, fontWeight: '600', textAlign: 'center' },
  progressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
    paddingHorizontal: 8,
  },
  actionIcons: { flexDirection: 'row', gap: 20, alignItems: 'center' },
  iconButton: { alignItems: 'center' },
  iconButtonInner: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
  },
  iconButtonCancel: { backgroundColor: 'rgba(239,68,68,0.15)' },
  iconButtonLabel: { color: 'rgba(249,250,251,0.85)', fontSize: 12, fontWeight: '600' },
  iconButtonLocked: { opacity: 0.7 },
  iconButtonInnerLocked: { backgroundColor: 'rgba(255,255,255,0.06)' },
  iconButtonLabelLocked: { color: 'rgba(249,250,251,0.5)' },
  jobInfo: {
    gap: 8,
    paddingTop: 12,
    marginBottom: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  infoText: { color: '#E5E7EB', fontSize: 14, flex: 1 },
  nextActionButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  nextActionGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 8,
  },
  nextActionText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  overlayBackdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.65)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  overlayContent: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  confettiPiece: {
    position: 'absolute',
  },
  boomCard: {
    width: width - 48,
    maxWidth: 320,
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.4)',
    elevation: 24,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
  },
  boomCardGradient: {
    padding: 32,
    alignItems: 'center',
  },
  boomTitle: {
    fontSize: 42,
    fontWeight: '900',
    color: '#FFFFFF',
    marginBottom: 8,
    letterSpacing: 1,
  },
  boomSubtitle: {
    fontSize: 18,
    fontWeight: '700',
    color: SKY,
    marginBottom: 28,
    textAlign: 'center',
  },
  boomButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  boomButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 28,
    gap: 8,
  },
  boomButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
});
