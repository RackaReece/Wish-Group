import { Stack } from 'expo-router';
import { AccountThemeProvider } from '../../src/components/shared/AccountThemeProvider';

export default function BusinessLayout() {
  return (
    <AccountThemeProvider accountType="business">
      <Stack screenOptions={{ headerShown: false }}>
        <Stack.Screen name="dashboard" />
        <Stack.Screen name="profile" />
        <Stack.Screen name="settings" />
        <Stack.Screen name="locations" />
        <Stack.Screen name="bookings" />
        <Stack.Screen name="team" />
        <Stack.Screen name="earnings" />
        <Stack.Screen name="notifications" />
        <Stack.Screen name="onboarding" />
        <Stack.Screen name="privacy" />
        <Stack.Screen name="issues" />
        <Stack.Screen name="services" />
        <Stack.Screen name="payment-methods" />
        <Stack.Screen name="orders" />
      </Stack>
    </AccountThemeProvider>
  );
}
