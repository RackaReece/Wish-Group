import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  RefreshControl,
  Linking,
  Platform,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader from '../../src/components/shared/AppHeader';
import GlassCard from '../../src/components/booking/GlassCard';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { getTextColors, getIconColors } from '../../src/constants/themeColors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const SKY = colors.SKY;
const BG = colors.BG;

type OrderRow = {
  id: string;
  status: string;
  customer_name: string | null;
  service_name: string | null;
  location_address: string | null;
  scheduled_at: string | null;
  completed_at: string | null;
  price: number | null;
  created_at: string;
};

function receiptHtml(order: OrderRow, businessName: string): string {
  const date = order.completed_at || order.scheduled_at || order.created_at;
  const dateStr = date ? new Date(date).toLocaleString('en-GB', { dateStyle: 'medium', timeStyle: 'short' }) : '—';
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <style>
    body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 24px; color: #1e293b; max-width: 400px; margin: 0 auto; }
    h1 { font-size: 22px; margin: 0 0 8px; color: #0f172a; }
    .sub { font-size: 12px; color: #64748b; margin-bottom: 24px; }
    table { width: 100%; border-collapse: collapse; margin: 16px 0; }
    th { text-align: left; font-size: 11px; text-transform: uppercase; color: #64748b; padding: 6px 0; border-bottom: 1px solid #e2e8f0; }
    td { padding: 8px 0; border-bottom: 1px solid #f1f5f9; font-size: 14px; }
    .total { font-weight: 700; font-size: 18px; margin-top: 16px; padding-top: 12px; border-top: 2px solid #0f172a; }
    .receipt-id { font-size: 11px; color: #94a3b8; margin-top: 24px; }
  </style>
</head>
<body>
  <h1>${businessName || 'Wish a Wash'}</h1>
  <p class="sub">Receipt</p>
  <table>
    <tr><th>Order ID</th><td>${order.id.slice(0, 8).toUpperCase()}</td></tr>
    <tr><th>Date</th><td>${dateStr}</td></tr>
    <tr><th>Customer</th><td>${order.customer_name || 'Customer'}</td></tr>
    <tr><th>Service</th><td>${order.service_name || 'Wash'}</td></tr>
    <tr><th>Location</th><td>${order.location_address || '—'}</td></tr>
    <tr><th>Amount</th><td>£${(order.price ?? 0).toFixed(2)}</td></tr>
  </table>
  <p class="total">Total: £${(order.price ?? 0).toFixed(2)}</p>
  <p class="receipt-id">Thank you for your business.</p>
</body>
</html>
  `.trim();
}

export default function BusinessOrders() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme } = useAccountTheme();
  const textColors = getTextColors(theme);
  const iconColors = getIconColors(theme);

  const [orders, setOrders] = useState<OrderRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [businessName, setBusinessName] = useState('Wish a Wash');
  const [generatingPdf, setGeneratingPdf] = useState<string | null>(null);

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  const loadOrders = useCallback(async () => {
    if (!organizationId || !isOrgUser) {
      setOrders([]);
      setLoading(false);
      return;
    }
    try {
      const { data: locations } = await supabase
        .from('car_wash_locations')
        .select('id')
        .eq('organization_id', organizationId);

      const locationIds = (locations || []).map((l: any) => l.id).filter(Boolean);
      if (locationIds.length === 0) {
        setOrders([]);
      } else {
        const { data: rows } = await supabase
          .from('bookings')
          .select('id, status, customer_name, service_name, location_address, scheduled_at, completed_at, price, created_at')
          .in('location_id', locationIds)
          .eq('status', 'completed')
          .order('created_at', { ascending: false });
        setOrders((rows as OrderRow[]) || []);
      }

      const { data: org } = await supabase
        .from('organizations')
        .select('name')
        .eq('id', organizationId)
        .maybeSingle();
      if (org && (org as any).name) setBusinessName((org as any).name);
    } catch (e) {
      console.error(e);
      setOrders([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [organizationId, isOrgUser]);

  useEffect(() => {
    loadOrders();
  }, [loadOrders]);

  const onRefresh = () => {
    setRefreshing(true);
    loadOrders();
  };

  const viewReceipt = async (order: OrderRow) => {
    await hapticFeedback('light');
    setGeneratingPdf(order.id);
    try {
      const html = receiptHtml(order, businessName);
      const { uri } = await Print.printToFileAsync({
        html,
        width: 400,
        base64: false,
      });
      const canShare = await Sharing.isAvailableAsync();
      if (canShare) {
        await Sharing.shareAsync(uri, { mimeType: 'application/pdf', UTI: '.pdf' });
      } else {
        if (Platform.OS === 'web') {
          window.open(uri, '_blank');
        } else {
          await Linking.openURL(uri);
        }
      }
    } catch (e: any) {
      Alert.alert('Error', e?.message ?? 'Could not generate receipt');
    } finally {
      setGeneratingPdf(null);
    }
  };

  if (!isOrgUser || !organizationId) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={[BG, '#0f172a']} style={StyleSheet.absoluteFill} />
        <AppHeader title="Orders" accountType="business" />
        <View style={styles.centerContent}>
          <Ionicons name="document-text-outline" size={48} color={iconColors.secondary} style={{ opacity: 0.7 }} />
          <Text style={[styles.emptyText, { color: textColors.primary }]}>Link your organization to view orders.</Text>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={styles.backBtnText}>Go back</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[BG, '#0f172a']} style={StyleSheet.absoluteFill} />
      <AppHeader title="Orders" accountType="business" />
      {loading ? (
        <LoadingView style={styles.loadingWrap} />
      ) : orders.length === 0 ? (
        <View style={styles.centerContent}>
          <Ionicons name="receipt-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
          <Text style={styles.emptyTitle}>No orders yet</Text>
          <Text style={styles.emptyText}>Completed washes appear here with printable receipts.</Text>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn}>
            <Text style={styles.backBtnText}>Back to profile</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={[styles.scrollContent, { paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 24 }]}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
          showsVerticalScrollIndicator={false}
        >
          {orders.map((order) => (
            <GlassCard key={order.id} style={styles.orderCard} accountType="business">
              <View style={styles.orderRow}>
                <View style={styles.orderMain}>
                  <Text style={styles.orderCustomer} numberOfLines={1}>{order.customer_name || 'Customer'}</Text>
                  <Text style={styles.orderService} numberOfLines={1}>{order.service_name || 'Wash'}</Text>
                  <Text style={styles.orderDate}>
                    {order.completed_at || order.scheduled_at || order.created_at
                      ? new Date(order.completed_at || order.scheduled_at || order.created_at).toLocaleDateString('en-GB', {
                          day: 'numeric',
                          month: 'short',
                          year: 'numeric',
                          hour: '2-digit',
                          minute: '2-digit',
                        })
                      : '—'}
                  </Text>
                </View>
                <View style={styles.orderRight}>
                  <Text style={styles.orderPrice}>£{(order.price ?? 0).toFixed(2)}</Text>
                  <TouchableOpacity
                    style={styles.receiptBtn}
                    onPress={() => viewReceipt(order)}
                    disabled={generatingPdf === order.id}
                    activeOpacity={0.8}
                  >
                    <LinearGradient colors={[SKY, '#60A5FA']} style={styles.receiptBtnGrad}>
                      {generatingPdf === order.id ? (
                        <ActivityIndicator size="small" color="#FFF" />
                      ) : (
                        <>
                          <Ionicons name="document-text" size={18} color="#FFFFFF" />
                          <Text style={styles.receiptBtnText}>Receipt</Text>
                        </>
                      )}
                    </LinearGradient>
                  </TouchableOpacity>
                </View>
              </View>
            </GlassCard>
          ))}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  scroll: { flex: 1 },
  scrollContent: { padding: 20, paddingTop: 8 },
  loadingWrap: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: SKY, fontSize: 14 },
  centerContent: { flex: 1, justifyContent: 'center', alignItems: 'center', padding: 24, gap: 12 },
  emptyTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: '700' },
  emptyText: { color: 'rgba(249,250,251,0.8)', fontSize: 14, textAlign: 'center' },
  backBtn: { marginTop: 16, paddingVertical: 12, paddingHorizontal: 24, backgroundColor: SKY, borderRadius: 12 },
  backBtnText: { color: '#FFF', fontWeight: '700', fontSize: 15 },
  orderCard: { marginBottom: 12, padding: 16 },
  orderRow: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start', gap: 12 },
  orderMain: { flex: 1, minWidth: 0 },
  orderCustomer: { color: '#F9FAFB', fontSize: 17, fontWeight: '700', marginBottom: 4 },
  orderService: { color: 'rgba(249,250,251,0.85)', fontSize: 14, marginBottom: 4 },
  orderDate: { color: 'rgba(249,250,251,0.6)', fontSize: 12 },
  orderRight: { alignItems: 'flex-end', gap: 10 },
  orderPrice: { color: SKY, fontSize: 18, fontWeight: '700' },
  receiptBtn: { borderRadius: 12, overflow: 'hidden', elevation: 4, shadowColor: SKY, shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.3, shadowRadius: 6 },
  receiptBtnGrad: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 10, paddingHorizontal: 16, gap: 6 },
  receiptBtnText: { color: '#FFFFFF', fontSize: 14, fontWeight: '700' },
});
