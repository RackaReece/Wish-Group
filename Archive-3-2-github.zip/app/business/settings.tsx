import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Alert,
  Switch,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import LoadingView from '../../src/components/shared/LoadingView';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { colors } from '../../src/constants/colors';
import { ICON_TEXT_LAYOUT } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { getTextColors, getIconColors, getBackgroundColors } from '../../src/constants/themeColors';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;

export default function BusinessSettings() {
  const { user, logout } = useAuth();
  const { theme: businessTheme, mode, toggleMode } = useAccountTheme();
  const insets = useSafeAreaInsets();
  
  const textColors = getTextColors(businessTheme);
  const iconColors = getIconColors(businessTheme);
  const bgColors = getBackgroundColors(businessTheme);

  const scrollY = useRef(new Animated.Value(0)).current;
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    setLoading(false);
  }, [user?.id]);

  const handleLogout = async () => {
    if (loggingOut) return;

    Alert.alert(
      'Log out?',
      'You’ll need to sign in again to access your business account.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Log out',
          style: 'destructive',
          onPress: async () => {
            try {
              setLoggingOut(true);
              await hapticFeedback('medium');
              await logout();
              // Take them back to standard login (adjust route if your app uses a different one)
              router.replace('/auth/login' as any);
            } catch (e: any) {
              console.error('[BusinessSettings] logout error:', e);
              Alert.alert('Error', e?.message || 'Failed to log out. Please try again.');
            } finally {
              setLoggingOut(false);
            }
          },
        },
      ]
    );
  };

  const settingsSections = [
    {
      title: 'Business Profile',
      items: [
        {
          id: 'profile',
          label: 'Business Information',
          icon: 'business',
          route: '/business/profile',
          color: '#60A5FA',
        },
        {
          id: 'locations',
          label: 'Manage Locations',
          icon: 'location',
          route: '/business/locations',
          color: '#10B981',
        },
        {
          id: 'services',
          label: 'Services Configuration',
          icon: 'construct',
          route: '/business/locations',
          color: '#F59E0B',
        },
      ],
    },
    {
      title: 'Team & Operations',
      items: [
        {
          id: 'team',
          label: 'Team Management',
          icon: 'people',
          route: '/business/team',
          color: SKY,
        },
        {
          id: 'earnings',
          label: 'Earnings & Payouts',
          icon: 'wallet',
          route: '/business/earnings',
          color: '#10B981',
        },
        {
          id: 'payment-methods',
          label: 'Payment Methods',
          icon: 'card',
          route: '/business/payment-methods',
          color: '#8B5CF6',
        },
      ],
    },
    {
      title: 'Policies & Legal',
      items: [
        {
          id: 'issues',
          label: 'Reports & Issues',
          icon: 'alert-circle',
          route: '/business/issues',
          color: '#F59E0B',
        },
      ],
    },
    {
      title: 'Preferences',
      items: [
        {
          id: 'privacy',
          label: 'Privacy Settings',
          icon: 'lock-closed',
          route: '/business/privacy',
          color: businessTheme.accent,
        },
        {
          id: 'theme',
          label: 'Dark Mode',
          icon: mode === 'dark' ? 'moon' : 'sunny',
          isToggle: true,
          value: mode === 'dark',
          onToggle: toggleMode,
          color: mode === 'dark' ? '#818CF8' : '#F59E0B',
        },
      ],
    },
  ];

  if (loading) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <SafeAreaView style={styles.container} edges={['top']}>
        <AppHeader
          title="Settings"
          scrollY={scrollY}
          enableScrollAnimation={true}
          accountType="business"
        />

      <Animated.ScrollView
        style={styles.scrollView}
        showsVerticalScrollIndicator={false}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
          useNativeDriver: false,
        })}
        scrollEventThrottle={16}
        contentContainerStyle={[
          styles.scrollContent,
          {
            paddingTop: HEADER_CONTENT_OFFSET,
            paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
          },
        ]}
      >
        {settingsSections.map((section, sectionIndex) => (
          <Animated.View
            key={section.title}
            style={[
              styles.section,
              { opacity: fadeAnim },
              {
                transform: [
                  {
                    translateY: fadeAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: [30 + sectionIndex * 10, 0],
                    }),
                  },
                ],
              },
            ]}
          >
            <Text style={[styles.sectionTitle, { color: textColors.tertiary }]}>{section.title}</Text>
            <View style={styles.itemsContainer}>
              {section.items.map((item) => (
                <TouchableOpacity
                  key={item.id}
                  onPress={async () => {
                    if (item.isToggle && item.onToggle) {
                      await hapticFeedback('light');
                      item.onToggle();
                    } else if (item.route) {
                      await hapticFeedback('light');
                      router.push(item.route as any);
                    }
                  }}
                  style={styles.itemWrapper}
                  activeOpacity={0.9}
                  disabled={item.isToggle && !item.onToggle} // Disable press if it's a toggle handled by internal switch? No, allow row press to toggle
                >
                  <GlassCard style={styles.itemCard} accountType="business" borderColor={`${item.color}40`}>
                    <View style={styles.itemContent}>
                      <View style={[styles.itemIconWrapper, { backgroundColor: `${item.color}25` }]}>
                        <Ionicons name={item.icon as any} size={24} color={iconColors.primary} />
                      </View>
                      <Text style={[styles.itemLabel, { color: textColors.primary }]}>{item.label}</Text>
                      {item.isToggle ? (
                        <View pointerEvents="none">
                          <Switch
                            value={item.value}
                            trackColor={{ false: 'rgba(203,213,225,0.5)', true: item.color }}
                            thumbColor="#FFFFFF"
                            // onValueChange is handled by row press for better UX
                          />
                        </View>
                      ) : (
                        <Ionicons name="chevron-forward" size={20} color={iconColors.primary} />
                      )}
                    </View>
                  </GlassCard>
                </TouchableOpacity>
              ))}
            </View>
          </Animated.View>
        ))}

        {/* Logout */}
        <Animated.View
          style={[
            styles.section,
            { opacity: fadeAnim },
            {
              transform: [
                {
                  translateY: fadeAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [45, 0],
                  }),
                },
              ],
            },
          ]}
        >
          <Text style={[styles.sectionTitle, { color: textColors.tertiary }]}>Account</Text>

          <TouchableOpacity
            onPress={handleLogout}
            disabled={loggingOut}
            activeOpacity={0.9}
          >
            <GlassCard style={StyleSheet.flatten([styles.logoutCard, loggingOut && { opacity: 0.7 }])} accountType="business" borderColor="rgba(239,68,68,0.35)">
              <View style={styles.logoutContent}>
                <View style={styles.logoutIconWrapper}>
                  {loggingOut ? (
                    <ActivityIndicator size="small" color="#EF4444" />
                  ) : (
                    <Ionicons name="log-out-outline" size={22} color="#EF4444" />
                  )}
                </View>

                <View style={{ flex: 1 }}>
                  <Text style={[styles.logoutTitle, { color: textColors.primary }]}>
                    {loggingOut ? 'Logging out…' : 'Log out'}
                  </Text>
                  <Text style={[styles.logoutSubtitle, { color: textColors.secondary }]}>
                    Sign out of this business account
                  </Text>
                </View>

                <Ionicons name="chevron-forward" size={20} color="rgba(239,68,68,0.9)" />
              </View>
            </GlassCard>
          </TouchableOpacity>
        </Animated.View>

        <View style={{ height: 22 }} />
      </Animated.ScrollView>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
  },
  section: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 12,
    letterSpacing: 0.2,
  },
  itemsContainer: {
    gap: 12,
  },
  itemWrapper: {
    marginBottom: 0,
  },
  itemCard: {
    padding: 16,
  },
  itemContent: {
    ...ICON_TEXT_LAYOUT.itemRow,
  },
  itemIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  itemLabel: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '600',
  },

  // Logout
  logoutCard: {
    padding: 16,
    backgroundColor: 'rgba(239,68,68,0.06)',
  },
  logoutContent: {
    ...ICON_TEXT_LAYOUT.itemRow,
  },
  logoutIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(239,68,68,0.14)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.22)',
  },
  logoutTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 2,
  },
  logoutSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
});
