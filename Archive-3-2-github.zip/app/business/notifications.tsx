import React, { useCallback, useEffect, useRef, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Animated,
  Alert,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import LoadingView from '../../src/components/shared/LoadingView';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { getTextColors, getIconColors } from '../../src/constants/themeColors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';
import { CARD_BORDER_RADIUS } from '../../src/constants/colors';

const SKY = colors.SKY;

type BusinessNotificationType = 'booking' | 'team' | 'system';

interface BusinessNotification {
  id: string;
  title: string;
  message: string;
  createdAt: string;
  type: BusinessNotificationType;
  priority?: 'low' | 'medium' | 'high';
  actionRoute?: string;
  actionParams?: Record<string, string>;
}

export default function BusinessNotifications() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const theme = businessTheme ?? getAccountTheme('business', 'light');
  const textColors = getTextColors(theme);
  const iconColors = getIconColors(theme);

  const [notifications, setNotifications] = useState<BusinessNotification[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const organizationId = user?.organizationId ?? null;
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  const formatRelativeTime = useCallback((dateString: string) => {
    const date = new Date(dateString);
    if (Number.isNaN(date.getTime())) return '';
    const diff = Date.now() - date.getTime();
    const minute = 60 * 1000;
    const hour = 60 * minute;
    const day = 24 * hour;
    if (diff < minute) return 'Just now';
    if (diff < hour) {
      const m = Math.floor(diff / minute);
      return `${m} min${m === 1 ? '' : 's'} ago`;
    }
    if (diff < day) {
      const h = Math.floor(diff / hour);
      return `${h} hr${h === 1 ? '' : 's'} ago`;
    }
    const d = Math.floor(diff / day);
    if (d < 7) return `${d} day${d === 1 ? '' : 's'} ago`;
    return date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  }, []);

  const fetchNotifications = useCallback(async () => {
    if (!organizationId || !isOrgUser) {
      setLoading(false);
      setNotifications([]);
      return;
    }
    if (!refreshing) setLoading(true);
    try {
      const { data: locationRows } = await supabase
        .from('car_wash_locations')
        .select('address')
        .eq('organization_id', organizationId);
      const locationAddresses = (locationRows || [])
        .map((r: any) => (typeof r?.address === 'string' ? r.address.trim() : ''))
        .filter((a: string) => a.length > 0);

      let valeterIds: string[] = [];
      try {
        const { data: users } = await supabase
          .from('users')
          .select('id')
          .eq('organization_id', organizationId);
        valeterIds = (users || []).map((u: any) => u.id).filter(Boolean);
      } catch {
        // fallback: profiles if users.organization_id not available
        const { data: profiles } = await supabase
          .from('profiles')
          .select('id')
          .eq('organization_id', organizationId);
        valeterIds = (profiles || []).map((p: any) => p.id).filter(Boolean);
      }

      if (valeterIds.length === 0 && locationAddresses.length === 0) {
        setNotifications([]);
        setLoading(false);
        setRefreshing(false);
        return;
      }

      let query = supabase
        .from('bookings')
        .select('id, status, scheduled_at, updated_at, service_type, location_address, price')
        .order('updated_at', { ascending: false })
        .limit(50);
      if (valeterIds.length > 0) query = query.in('valeter_id', valeterIds);
      if (locationAddresses.length > 0) query = query.in('location_address', locationAddresses);

      const { data: bookings, error } = await query;

      if (error) {
        setNotifications([]);
        setLoading(false);
        setRefreshing(false);
        return;
      }

      const statusToNotification: Record<string, { title: string; message: string; priority: 'low' | 'medium' | 'high' }> = {
        pending_business_acceptance: { title: 'New booking request', message: 'A customer has requested a booking. Accept or decline.', priority: 'high' },
        pending_valeter_acceptance: { title: 'Booking awaiting valeter', message: 'A valeter needs to accept this booking.', priority: 'medium' },
        confirmed: { title: 'Booking confirmed', message: 'The booking has been confirmed.', priority: 'low' },
        in_progress: { title: 'Service in progress', message: 'A valeter is currently completing this job.', priority: 'medium' },
        completed: { title: 'Booking completed', message: 'The service has been completed.', priority: 'low' },
        cancelled: { title: 'Booking cancelled', message: 'This booking was cancelled.', priority: 'medium' },
      };

      const list: BusinessNotification[] = (bookings || []).map((b: any) => {
        const meta = statusToNotification[b.status] || { title: 'Booking update', message: 'Your booking has been updated.', priority: 'low' as const };
        return {
          id: `booking-${b.id}-${b.updated_at || b.scheduled_at}`,
          title: meta.title,
          message: meta.message,
          createdAt: b.updated_at || b.scheduled_at || new Date().toISOString(),
          type: 'booking',
          priority: meta.priority,
          actionRoute: '/business/bookings',
          actionParams: {},
        };
      });

      setNotifications(list);
    } catch (err) {
      console.error('[BusinessNotifications] fetch error:', err);
      setNotifications([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [organizationId, isOrgUser, refreshing]);

  useEffect(() => {
    fetchNotifications();
    Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }).start();
  }, [fetchNotifications]);

  const handleRefresh = useCallback(() => {
    setRefreshing(true);
    fetchNotifications();
  }, [fetchNotifications]);

  const handleNotificationPress = useCallback((item: BusinessNotification) => {
    if (item.actionRoute) {
      hapticFeedback('light');
      router.push({ pathname: item.actionRoute as any, params: (item.actionParams || {}) as any });
    }
  }, []);

  const handleDeleteNotification = useCallback((id: string) => {
    Alert.alert('Remove', 'Remove this notification from the list?', [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Remove', style: 'destructive', onPress: () => setNotifications((prev) => prev.filter((n) => n.id !== id)) },
    ]);
  }, []);

  const getIconMeta = (type: BusinessNotificationType, priority?: string) => {
    switch (type) {
      case 'booking':
        return { icon: 'calendar', color: SKY, background: 'rgba(135,206,235,0.2)' };
      case 'team':
        return { icon: 'people', color: '#10B981', background: 'rgba(16,185,129,0.2)' };
      default:
        return { icon: 'notifications', color: SKY, background: 'rgba(135,206,235,0.2)' };
    }
  };

  const listEmptyComponent = (
    <Animated.View style={[styles.emptyState, { opacity: fadeAnim }]}>
      <View style={styles.emptyIconWrapper}>
        <Ionicons name="notifications-off" size={48} color={SKY} />
      </View>
      <Text style={styles.emptyTitle}>All caught up</Text>
      <Text style={styles.emptySubtitle}>Booking updates and alerts will appear here.</Text>
    </Animated.View>
  );

  const renderItem = ({ item }: { item: BusinessNotification }) => {
    const iconMeta = getIconMeta(item.type, item.priority);
    return (
      <Animated.View style={{ opacity: fadeAnim }}>
        <GlassCard style={styles.notificationCard} accountType="business">
          <TouchableOpacity
            onPress={() => handleNotificationPress(item)}
            activeOpacity={0.8}
            style={styles.notificationContent}
          >
            <View style={styles.notificationMainContent}>
              <View style={[styles.iconWrapper, { backgroundColor: iconMeta.background, borderColor: `${iconMeta.color}40` }]}>
                <Ionicons name={iconMeta.icon as any} size={22} color={iconMeta.color} />
              </View>
              <View style={styles.notificationTextBlock}>
                <Text style={styles.notificationTitle} numberOfLines={2}>{item.title}</Text>
                <Text style={styles.notificationMessage} numberOfLines={2}>{item.message}</Text>
                <View style={styles.timeRow}>
                  <Ionicons name="time-outline" size={11} color="rgba(249,250,251,0.5)" />
                  <Text style={styles.notificationTime}>{formatRelativeTime(item.createdAt)}</Text>
                </View>
              </View>
              {item.actionRoute && (
                <View style={styles.actionIndicator}>
                  <Ionicons name="chevron-forward" size={18} color={SKY} />
                </View>
              )}
            </View>
          </TouchableOpacity>
          <TouchableOpacity
            style={styles.deleteButton}
            onPress={async () => { await hapticFeedback('light'); handleDeleteNotification(item.id); }}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={16} color="#EF4444" />
          </TouchableOpacity>
        </GlassCard>
      </Animated.View>
    );
  };

  const listHeaderComponent =
    notifications.length > 0 ? (
      <Animated.View style={[styles.headerSection, { opacity: fadeAnim }]}>
        <View style={styles.headerInfo}>
          <Text style={[styles.headerTitle, { color: textColors.primary }]}>Recent notifications</Text>
          <Text style={[styles.headerSubtitle, { color: textColors.secondary }]}>
            {notifications.length} notification{notifications.length !== 1 ? 's' : ''}
          </Text>
        </View>
        <TouchableOpacity
          style={styles.preferencesCta}
          onPress={async () => {
            await hapticFeedback('light');
            router.push('/business/profile');
          }}
          activeOpacity={0.8}
        >
          <GlassCard style={styles.preferencesCtaCard} accountType="business">
            <View style={styles.preferencesCtaContent}>
              <View style={[styles.preferencesCtaIcon, { backgroundColor: `${theme.primary}25` }]}>
                <Ionicons name="settings-outline" size={20} color={iconColors.primary} />
              </View>
              <View style={styles.preferencesCtaText}>
                <Text style={[styles.preferencesCtaLabel, { color: textColors.primary }]}>Notification preferences</Text>
                <Text style={[styles.preferencesCtaSub, { color: textColors.secondary }]}>Manage what you get notified about</Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color={iconColors.primary} />
            </View>
          </GlassCard>
        </TouchableOpacity>
      </Animated.View>
    ) : null;

  if (loading && notifications.length === 0) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <AppHeader
        title="Notifications"
        accountType="business"
        rightAction={
          notifications.length > 0 ? (
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                Alert.alert('Clear all', 'Remove all notifications from this list?', [
                  { text: 'Cancel', style: 'cancel' },
                  { text: 'Clear all', style: 'destructive', onPress: () => setNotifications([]) },
                ]);
              }}
              style={styles.deleteAllButton}
              activeOpacity={0.7}
            >
              <Ionicons name="trash-outline" size={20} color="#EF4444" />
            </TouchableOpacity>
          ) : null
        }
      />
      <FlatList
        data={notifications}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={{
          paddingTop: HEADER_CONTENT_OFFSET + 8,
          paddingHorizontal: 16,
          paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
        }}
        style={styles.list}
        ItemSeparatorComponent={() => <View style={{ height: 12 }} />}
        ListEmptyComponent={listEmptyComponent}
        ListHeaderComponent={listHeaderComponent}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={SKY} colors={[SKY]} />
        }
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  list: { flex: 1 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: HEADER_CONTENT_OFFSET + 28,
    gap: 12,
  },
  loadingText: { fontSize: 14, fontWeight: '600' },
  deleteAllButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(239,68,68,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
  },
  headerSection: { marginBottom: 12 },
  headerInfo: { gap: 4 },
  headerTitle: { fontSize: 22, fontWeight: '900', letterSpacing: -0.3, fontFamily: 'Rubik_700Bold' },
  headerSubtitle: { fontSize: 13, fontWeight: '600', marginTop: 2, fontFamily: 'Rubik_600SemiBold' },
  preferencesCta: { marginBottom: 12 },
  preferencesCtaCard: { padding: 0, overflow: 'hidden', borderRadius: CARD_BORDER_RADIUS },
  preferencesCtaContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
    gap: 12,
  },
  preferencesCtaIcon: {
    width: 40,
    height: 40,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  preferencesCtaText: { flex: 1, gap: 2 },
  preferencesCtaLabel: { fontSize: 15, fontWeight: '800' },
  preferencesCtaSub: { fontSize: 12, fontWeight: '500' },
  notificationCard: {
    padding: 0,
    borderRadius: 18,
    overflow: 'hidden',
    position: 'relative',
  },
  notificationContent: { padding: 14, paddingRight: 50, flex: 1 },
  notificationMainContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  iconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
  },
  notificationTextBlock: { flex: 1, gap: 6 },
  notificationTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: -0.2,
    lineHeight: 20,
  },
  notificationMessage: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
    marginTop: 2,
  },
  timeRow: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: 4 },
  notificationTime: { color: 'rgba(249,250,251,0.5)', fontSize: 11, fontWeight: '600' },
  actionIndicator: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  deleteButton: {
    position: 'absolute',
    top: 10,
    right: 10,
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(239,68,68,0.12)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.25)',
  },
  emptyState: { marginTop: 80, alignItems: 'center', paddingHorizontal: 40 },
  emptyIconWrapper: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '900',
    marginBottom: 10,
    letterSpacing: 0.3,
  },
  emptySubtitle: {
    color: 'rgba(249,250,251,0.75)',
    textAlign: 'center',
    lineHeight: 24,
    fontSize: 16,
    fontWeight: '500',
  },
});
