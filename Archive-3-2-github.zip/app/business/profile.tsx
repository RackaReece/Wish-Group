import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  TextInput,
  ActivityIndicator,
  Alert,
  Animated,
  RefreshControl,
  Platform,
  KeyboardAvoidingView,
  Image,
  Switch,
  ScrollView,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import LoadingView from '../../src/components/shared/LoadingView';
import GlassCard from '../../src/components/booking/GlassCard';
import BubbleBackground from '../../src/components/shared/BubbleBackground';
import { colors } from '../../src/constants/colors';
import { CARD_SIZES, SPACING, ICON_TEXT_LAYOUT } from '../../src/constants/cardSizes';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { getTextColors, getIconColors, getIconAccentColors, getTextStylesWithColors } from '../../src/constants/themeColors';
import { useAccountTheme } from '../../src/components/shared/AccountThemeProvider';
import * as ImagePicker from 'expo-image-picker';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

const SKY = colors.SKY;
// Default (dark) theme for StyleSheet; component uses useAccountTheme() for live mode
const businessThemeStatic = getAccountTheme('business');
const LIGHT_TEXT = '#F9FAFB';
const MUTED_TEXT = 'rgba(249,250,251,0.7)';

type OrgRow = Record<string, any>;

function getMissingColumn(message?: string | null) {
  const m = (message || '').match(/column\s+organizations\.([a-zA-Z0-9_]+)\s+does\s+not\s+exist/i);
  return m?.[1] ?? null;
}

export default function BusinessProfile() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const { theme: businessTheme } = useAccountTheme();
  const textColors = getTextColors(businessTheme);
  const iconColors = getIconColors(businessTheme);
  const iconAccent = getIconAccentColors();
  const ts = getTextStylesWithColors(businessTheme);
  const iconOnPrimary = businessTheme.mode === 'light' ? (businessTheme.textPrimary || '#0C4A6E') : '#F9FAFB';
  const isLightMode = businessTheme.mode === 'light';

  const fadeAnim = useRef(new Animated.Value(0)).current;

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  // logo
  const [logoUrl, setLogoUrl] = useState<string>('');
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);

  // form fields
  const [businessName, setBusinessName] = useState('');
  const [businessEmail, setBusinessEmail] = useState('');
  const [businessPhone, setBusinessPhone] = useState('');
  const [businessAddress, setBusinessAddress] = useState('');
  const [businessDescription, setBusinessDescription] = useState('');
  const [taxId, setTaxId] = useState('');

  // Notification settings
  const [notificationSettings, setNotificationSettings] = useState([
    { id: 'new_booking', label: 'New Bookings', description: 'Get notified when new bookings are created', enabled: true, category: 'bookings' },
    { id: 'booking_cancelled', label: 'Booking Cancellations', description: 'Alert when customers cancel bookings', enabled: true, category: 'bookings' },
    { id: 'valeter_online', label: 'Valeter Status', description: 'Notifications when valeters come online or go offline', enabled: false, category: 'team' },
    { id: 'team_updates', label: 'Team Updates', description: 'Important updates about your team members', enabled: true, category: 'team' },
    { id: 'daily_summary', label: 'Daily Summary', description: 'Receive daily reports of your business performance', enabled: true, category: 'analytics' },
  ]);

  // Availability settings
  const [isAvailable, setIsAvailable] = useState(true);
  const [autoAcceptBookings, setAutoAcceptBookings] = useState(false);
  
  // Collapsible sections
  const [notificationSettingsExpanded, setNotificationSettingsExpanded] = useState(false);
  const [availabilitySettingsExpanded, setAvailabilitySettingsExpanded] = useState(false);
  
  // Animation values for chevron rotation (start at 0 since sections are collapsed by default)
  const notificationChevronRotate = useRef(new Animated.Value(0)).current;
  const availabilityChevronRotate = useRef(new Animated.Value(0)).current;

  const originalRef = useRef({
    logoUrl: '',
    businessName: '',
    businessEmail: '',
    businessPhone: '',
    businessAddress: '',
    businessDescription: '',
    taxId: '',
  });

  const organizationId = useMemo(() => user?.organizationId ?? null, [user?.organizationId]);
  const isOrgUser = (user?.userType ?? '').toLowerCase() === 'organization';

  const profileCompletion = useMemo(() => {
    const fields = [!!logoUrl, !!businessName?.trim(), !!businessEmail?.trim(), !!businessPhone?.trim(), !!businessAddress?.trim(), !!businessDescription?.trim()];
    const filled = fields.filter(Boolean).length;
    return Math.round((filled / fields.length) * 100);
  }, [logoUrl, businessName, businessEmail, businessPhone, businessAddress, businessDescription]);

  const hasChanges = useMemo(() => {
    const o = originalRef.current;
    return (
      logoUrl !== o.logoUrl ||
      businessName !== o.businessName ||
      businessEmail !== o.businessEmail ||
      businessPhone !== o.businessPhone ||
      businessAddress !== o.businessAddress ||
      businessDescription !== o.businessDescription ||
      taxId !== o.taxId
    );
  }, [logoUrl, businessName, businessEmail, businessPhone, businessAddress, businessDescription, taxId]);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 450, useNativeDriver: true }).start();
  }, []);

  useEffect(() => {
    if (isOrgUser && organizationId) {
      loadBusinessProfile();
    } else {
      setLoading(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [organizationId, isOrgUser]);

  useFocusEffect(
    React.useCallback(() => {
      if (isOrgUser && organizationId) loadBusinessProfile(false);
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [organizationId, isOrgUser])
  );

  const applyOrgToForm = (org: OrgRow | null) => {
    const nextName = (org?.name ?? '') as string;
    const nextEmail = ((org?.email ?? user?.email ?? '') as string) || '';
    const nextPhone = (org?.phone ?? '') as string;
    const nextAddress = (org?.address ?? '') as string;
    const nextDesc = (org?.description ?? '') as string;

    const nextTax = (org?.tax_id ?? org?.vat_number ?? org?.vat ?? org?.taxid ?? '') as string;

    const nextLogo = (org?.logo ?? org?.logo_url ?? org?.avatar_url ?? org?.profile_picture ?? '') as string;

    setBusinessName(nextName);
    setBusinessEmail(nextEmail);
    setBusinessPhone(nextPhone);
    setBusinessAddress(nextAddress);
    setBusinessDescription(nextDesc);
    setTaxId(nextTax);
    setLogoUrl(nextLogo);

    originalRef.current = {
      logoUrl: nextLogo,
      businessName: nextName,
      businessEmail: nextEmail,
      businessPhone: nextPhone,
      businessAddress: nextAddress,
      businessDescription: nextDesc,
      taxId: nextTax,
    };
  };

  const loadBusinessProfile = async (showSpinner = true) => {
    if (!isOrgUser || !organizationId) return;

    try {
      if (showSpinner) setLoading(true);

      const { data, error } = await supabase
        .from('organizations')
        .select('*')
        .eq('id', organizationId)
        .maybeSingle();

      if (error) throw error;

      applyOrgToForm(data || null);
    } catch (error: any) {
      console.error('Error loading business profile:', error);
      Alert.alert('Error', error?.message || 'Failed to load business information');
    } finally {
      if (showSpinner) setLoading(false);
    }
  };

  const onRefresh = async () => {
    if (!isOrgUser || !organizationId) return;
    try {
      setRefreshing(true);
      await loadBusinessProfile(false);
    } finally {
      setRefreshing(false);
    }
  };

  const cancelEditing = async () => {
    await hapticFeedback('light');
    const o = originalRef.current;
    setLogoUrl(o.logoUrl);
    setBusinessName(o.businessName);
    setBusinessEmail(o.businessEmail);
    setBusinessPhone(o.businessPhone);
    setBusinessAddress(o.businessAddress);
    setBusinessDescription(o.businessDescription);
    setTaxId(o.taxId);
    setIsEditing(false);
  };

  // storage
  const BUCKET = 'org-logos';

  const uploadLogoToStorage = async (localUri: string) => {
    if (!organizationId) return '';

    const ext = (localUri.split('.').pop() || 'jpg').toLowerCase();
    const path = `organizations/${organizationId}/logo_${Date.now()}.${ext}`;

    const res = await fetch(localUri);
    const blob = await res.blob();

    const { error: upErr } = await supabase.storage.from(BUCKET).upload(path, blob, {
      upsert: true,
      contentType: blob.type || (ext === 'png' ? 'image/png' : 'image/jpeg'),
    });

    if (upErr) throw upErr;

    const { data } = supabase.storage.from(BUCKET).getPublicUrl(path);
    return data?.publicUrl || '';
  };

  const handlePickLogo = async () => {
    try {
      await hapticFeedback('light');

      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permission needed', 'Please allow photo library access to upload your logo.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.9,
      });

      if (result.canceled) return;

      const uri = result.assets?.[0]?.uri;
      if (!uri) return;

      setIsUploadingLogo(true);

      let finalUrl = uri;

      try {
        const uploaded = await uploadLogoToStorage(uri);
        if (uploaded) finalUrl = uploaded;
      } catch (e: any) {
        console.warn('[BusinessProfile] logo upload failed (using local preview):', e?.message || e);
        Alert.alert(
          'Logo upload not configured',
          'I picked the image but couldn’t upload it yet. If you want it to persist, create a Supabase Storage bucket named "org-logos" (or update BUCKET in this file).'
        );
      }

      setLogoUrl(finalUrl);
      setIsEditing(true);
    } finally {
      setIsUploadingLogo(false);
    }
  };

  const handleRemoveLogo = async () => {
    await hapticFeedback('light');
    setLogoUrl('');
    setIsEditing(true);
  };

  const handleDeleteAccount = async () => {
    try {
      await hapticFeedback('heavy');
      Alert.alert('Delete Account', 'This action cannot be undone. Are you sure?', [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: () => Alert.alert('Account Deleted', 'Your account has been deleted.'),
        },
      ]);
    } catch {}
  };

  const handleSave = async () => {
    if (!isOrgUser || !organizationId) {
      Alert.alert('Error', 'Business account not linked to an organization.');
      return;
    }

    if (!businessName.trim()) {
      Alert.alert('Missing info', 'Business name is required.');
      return;
    }

    try {
      setIsSaving(true);
      await hapticFeedback('medium');

      const payload: Record<string, any> = {
        id: organizationId,
        name: businessName.trim(),
        email: businessEmail.trim() || null,
        phone: businessPhone.trim() || null,
        address: businessAddress.trim() || null,
        description: businessDescription.trim() || null,
        updated_at: new Date().toISOString(),
      };

      const logoValue = logoUrl.trim() || null;

      let { error } = await supabase
        .from('organizations')
        .upsert({ ...payload, tax_id: taxId.trim() || null, logo: logoValue });

      if (error) {
        const missing = getMissingColumn(error.message);

        if (missing === 'tax_id') {
          const retry = await supabase
            .from('organizations')
            .upsert({ ...payload, vat_number: taxId.trim() || null, logo: logoValue });
          error = retry.error;
        }

        if (missing === 'logo') {
          const retry2 = await supabase
            .from('organizations')
            .upsert({ ...payload, tax_id: taxId.trim() || null, logo_url: logoValue });
          error = retry2.error;
        }

        if (error) {
          const missing2 = getMissingColumn(error.message);
          if (missing2 === 'logo_url') {
            const retry3 = await supabase
              .from('organizations')
              .upsert({ ...payload, tax_id: taxId.trim() || null, avatar_url: logoValue });
            error = retry3.error;
          }
        }
      }

      if (error) throw error;

      await loadBusinessProfile(false);
      Alert.alert('Saved', 'Your business profile has been updated.');
      setIsEditing(false);
    } catch (error: any) {
      console.error('Error saving business profile:', error);
      Alert.alert('Error', error?.message || 'Failed to save business information');
    } finally {
      setIsSaving(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <LoadingView style={styles.loadingContainer} />
      </View>
    );
  }

  if (!isOrgUser || !organizationId) {
    return (
      <View style={styles.container}>
        <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
        <BubbleBackground accountType="business" />
        <SafeAreaView style={styles.container} edges={['top']}>
          <AppHeader title="Profile" accountType="business" />
          <View style={styles.loadingContainer}>
            <Ionicons name="alert-circle-outline" size={42} color={iconColors.primary} style={{ opacity: 0.85 }} />
            <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
              This business account isn't linked to an organization yet.
              {'\n'}Log out and back in, or contact support.
            </Text>
          </View>
        </SafeAreaView>
      </View>
    );
  }

  const TitleRight = () => (
    <TouchableOpacity
      onPress={async () => {
        await hapticFeedback('light');
        router.push('/business/settings' as any);
      }}
      style={styles.headerAction}
      activeOpacity={0.85}
    >
      <Ionicons name="settings-outline" size={22} color={textColors.primary} />
    </TouchableOpacity>
  );

  const CircleLogo = () => {
    if (logoUrl) {
      return <Image source={{ uri: logoUrl }} style={styles.logoCircleImg} />;
    }
    return (
      <View style={styles.logoCircleFallback}>
        <Ionicons name="business" size={34} color={iconColors.primary} />
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <LinearGradient colors={businessTheme.background} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="business" />
      <SafeAreaView style={styles.container} edges={['top']}>
        <AppHeader
          title="Profile"
          accountType="business"
          rightAction={<TitleRight />}
        />

      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <ScrollView
          style={styles.scrollView}
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} />}
          contentContainerStyle={[
            styles.scrollContent, 
            { 
              paddingTop: HEADER_CONTENT_OFFSET,
              paddingBottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 12,
            }
          ]}
          bounces={true}
          decelerationRate="fast"
          keyboardShouldPersistTaps="handled"
        >
          <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
            {/* ====== PREMIUM PROFILE HERO CARD ====== */}
            <GlassCard style={styles.heroCard} accountType="business">
              <View style={styles.heroTop}>
                <View style={styles.logoSection}>
                  <View style={styles.logoCircleOuter}>
                    <LinearGradient
                      colors={[`${businessTheme.primary}30`, `${businessTheme.primaryAlt}20`]}
                      style={StyleSheet.absoluteFill}
                    />
                    <View style={styles.logoCircleInner}>
                      <CircleLogo />
                    </View>
                  </View>

                  <View style={styles.logoActionButtons}>
                    <TouchableOpacity
                      style={styles.logoEditBtn}
                      onPress={handlePickLogo}
                      activeOpacity={0.85}
                      disabled={isUploadingLogo}
                    >
                      <LinearGradient
                        colors={[businessTheme.primary, businessTheme.primaryAlt]}
                        style={styles.logoEditBtnGradient}
                      >
                        {isUploadingLogo ? (
                          <ActivityIndicator size="small" color={iconOnPrimary} />
                        ) : (
                          <Ionicons name="camera" size={16} color={iconOnPrimary} />
                        )}
                      </LinearGradient>
                    </TouchableOpacity>

                    {!isEditing ? (
                      <TouchableOpacity
                        style={styles.logoEditBtn}
                        onPress={async () => {
                          await hapticFeedback('light');
                          setIsEditing(true);
                        }}
                        activeOpacity={0.85}
                      >
                        <LinearGradient
                          colors={[businessTheme.primary, businessTheme.primaryAlt]}
                          style={styles.logoEditBtnGradient}
                        >
                          <Ionicons name="create-outline" size={16} color={iconOnPrimary} />
                        </LinearGradient>
                      </TouchableOpacity>
                    ) : (
                      <TouchableOpacity
                        style={styles.logoEditBtn}
                        onPress={cancelEditing}
                        activeOpacity={0.85}
                      >
                        <View style={[styles.logoEditBtnGradient, { backgroundColor: 'rgba(239,68,68,0.9)' }]}>
                          <Ionicons name="close" size={16} color={iconOnPrimary} />
                        </View>
                      </TouchableOpacity>
                    )}
                  </View>
                </View>

                <View style={styles.heroTextSection}>
                  <Text style={styles.heroName} numberOfLines={1}>
                    {businessName || 'Your business'}
                  </Text>

                  <View style={styles.heroSubSection}>
                    <Ionicons name="mail-outline" size={14} color={textColors.secondary} />
                    <Text style={styles.heroSub} numberOfLines={1}>
                      {businessEmail || user?.email || 'Add your email'}
                    </Text>
                  </View>

                  {businessPhone && (
                    <View style={styles.heroSubSection}>
                      <Ionicons name="call-outline" size={14} color={textColors.secondary} />
                      <Text style={styles.heroSub} numberOfLines={1}>
                        {businessPhone}
                      </Text>
                    </View>
                  )}
                </View>

                <View style={styles.heroPillsRow}>
                  <View style={styles.pill}>
                    <LinearGradient
                      colors={[`${businessTheme.primary}25`, `${businessTheme.primaryAlt}15`]}
                      style={styles.pillGradient}
                    >
                      <View style={styles.pillIconWrapper}>
                        <Ionicons name="shield-checkmark" size={14} color={iconColors.primary} />
                      </View>
                      <Text style={styles.pillText}>Business Account</Text>
                    </LinearGradient>
                  </View>

                  <View style={styles.pill}>
                    <LinearGradient
                      colors={[`${businessTheme.primary}25`, `${businessTheme.primaryAlt}15`]}
                      style={styles.pillGradient}
                    >
                      <View style={styles.pillIconWrapper}>
                        <Ionicons 
                          name={businessAddress ? "location" : "location-outline"} 
                          size={14} 
                          color={iconColors.primary} 
                        />
                      </View>
                      <Text style={styles.pillText}>
                        {businessAddress ? 'Address set' : 'No address'}
                      </Text>
                    </LinearGradient>
                  </View>
                </View>

                <View style={styles.heroActionsRow}>
                  <TouchableOpacity
                    style={styles.heroBtn}
                    onPress={handlePickLogo}
                    activeOpacity={0.86}
                    disabled={isUploadingLogo}
                  >
                    <LinearGradient
                      colors={[`${businessTheme.primary}30`, `${businessTheme.primaryAlt}20`]}
                      style={styles.heroBtnGradient}
                    >
                      <View style={styles.heroBtnIconWrapper}>
                        <Ionicons name={logoUrl ? "image" : "cloud-upload-outline"} size={18} color={iconColors.primary} />
                      </View>
                      <Text style={styles.heroBtnText}>
                        {logoUrl ? 'Change logo' : 'Upload logo'}
                      </Text>
                    </LinearGradient>
                  </TouchableOpacity>

                  <TouchableOpacity
                    style={[styles.heroBtn, !logoUrl && { opacity: 0.45 }]}
                    onPress={handleRemoveLogo}
                    activeOpacity={0.86}
                    disabled={!logoUrl}
                  >
                    <View style={[styles.heroBtnGradient, { backgroundColor: 'rgba(239,68,68,0.85)' }]}>
                      <View style={[styles.heroBtnIconWrapper, { backgroundColor: 'rgba(220,38,38,0.6)' }]}>
                        <Ionicons name="trash-outline" size={18} color="#FFFFFF" />
                      </View>
                      <Text style={[styles.heroBtnText, { color: '#FFFFFF' }]}>Remove</Text>
                    </View>
                  </TouchableOpacity>
                </View>

                {!isEditing ? (
                  <View style={styles.heroHintContainer}>
                    <Ionicons name="information-circle-outline" size={16} color={textColors.tertiary} />
                    <Text style={[ts.bodySmall, { color: textColors.tertiary, flex: 1 }]}>
                      Tap the pencil to edit details. Use the camera to upload or change your logo.
                    </Text>
                  </View>
                ) : (
                  <View style={[styles.heroHintContainer, { backgroundColor: 'rgba(135,206,235,0.1)' }]}>
                    <Ionicons name="create-outline" size={16} color={iconColors.primary} />
                    <Text style={[ts.bodySmall, { color: iconColors.primary, flex: 1 }]}>
                      Make your changes below, then tap Save to update your profile.
                    </Text>
                  </View>
                )}
              </View>
            </GlassCard>

            {/* ====== PROFILE COMPLETION ====== */}
            <View style={styles.profileCompletionCard}>
              <View style={styles.profileCompletionHeader}>
                <Ionicons name="checkmark-circle-outline" size={20} color={iconColors.primary} />
                <Text style={[ts.sectionTitle, { marginBottom: 0 }]}>Profile completeness</Text>
              </View>
              <View style={styles.profileCompletionBar}>
                <View style={[styles.profileCompletionFill, { width: `${profileCompletion}%` }]} />
              </View>
              <Text style={ts.bodySmall}>{profileCompletion}% complete • Add logo, contact & description</Text>
            </View>

            {/* ====== BUSINESS INFORMATION ====== */}
            <View style={styles.formSectionHeader}>
              <Ionicons name="business-outline" size={20} color={iconColors.primary} />
              <Text style={[ts.sectionTitle, { marginBottom: 0 }]}>Business Information</Text>
            </View>

            <View style={styles.section}>
              <Text style={[ts.captionSemiBold, { color: textColors.tertiary, marginBottom: 8 }]}>Business Name</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={styles.input}
                  value={businessName}
                  onChangeText={setBusinessName}
                  placeholder="Enter business name"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            <View style={styles.section}>
              <Text style={[ts.captionSemiBold, { color: textColors.tertiary, marginBottom: 8 }]}>Email</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={styles.input}
                  value={businessEmail}
                  onChangeText={setBusinessEmail}
                  placeholder="Enter email"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  keyboardType="email-address"
                  autoCapitalize="none"
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            <View style={styles.section}>
              <Text style={[ts.captionSemiBold, { color: textColors.tertiary, marginBottom: 8 }]}>Phone Number</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={styles.input}
                  value={businessPhone}
                  onChangeText={setBusinessPhone}
                  placeholder="Enter phone number"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  keyboardType="phone-pad"
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            <View style={styles.section}>
              <Text style={[ts.captionSemiBold, { color: textColors.tertiary, marginBottom: 8 }]}>Business Address</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={[styles.input, styles.textArea]}
                  value={businessAddress}
                  onChangeText={setBusinessAddress}
                  placeholder="Enter business address"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  multiline
                  numberOfLines={3}
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            <View style={styles.section}>
              <Text style={[ts.captionSemiBold, { color: textColors.tertiary, marginBottom: 8 }]}>Business Description</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={[styles.input, styles.textArea, { minHeight: 120 }]}
                  value={businessDescription}
                  onChangeText={setBusinessDescription}
                  placeholder="What do you do? (e.g. premium detailing, fleet washing…) "
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  multiline
                  numberOfLines={4}
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            <View style={styles.section}>
              <Text style={[ts.captionSemiBold, { color: textColors.tertiary, marginBottom: 8 }]}>Tax ID / VAT Number</Text>
              <GlassCard style={styles.inputCard} accountType="business">
                <TextInput
                  style={styles.input}
                  value={taxId}
                  onChangeText={setTaxId}
                  placeholder="Enter tax ID"
                  placeholderTextColor="rgba(249,250,251,0.5)"
                  editable={isEditing}
                />
              </GlassCard>
            </View>

            {/* ====== NOTIFICATION SETTINGS ====== */}
            <View style={styles.section}>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  const newValue = !notificationSettingsExpanded;
                  setNotificationSettingsExpanded(newValue);
                  Animated.timing(notificationChevronRotate, {
                    toValue: newValue ? 1 : 0,
                    duration: 200,
                    useNativeDriver: true,
                  }).start();
                }}
                style={styles.sectionHeaderButton}
                activeOpacity={0.7}
              >
                <View style={styles.sectionHeader}>
                  <Ionicons name="notifications-outline" size={20} color={iconAccent.warning} />
                  <Text style={[styles.sectionTitle, { color: textColors.tertiary }]}>Notification Settings</Text>
                </View>
                <Animated.View
                  style={{
                    transform: [{
                      rotate: notificationChevronRotate.interpolate({
                        inputRange: [0, 1],
                        outputRange: ['0deg', '180deg'],
                      }),
                    }],
                  }}
                >
                  <Ionicons name="chevron-down" size={20} color={iconAccent.primary} />
                </Animated.View>
              </TouchableOpacity>
              
              {notificationSettingsExpanded && (
                <View>
                  <Text style={styles.sectionDescription}>
                    Choose which notifications you want to receive
                  </Text>

                  <View style={styles.notificationList}>
                    {notificationSettings.map((setting) => (
                      <GlassCard key={setting.id} style={styles.notificationCard} accountType="business">
                        <View style={styles.notificationContent}>
                          <View style={styles.notificationLeft}>
                            <View style={[
                              styles.notificationIconWrapper,
                              setting.enabled && { backgroundColor: `${businessTheme.primary}25` }
                            ]}>
                              <Ionicons
                                name={setting.enabled ? 'notifications' : 'notifications-off'}
                                size={18}
                                color={setting.enabled ? iconAccent.warning : iconColors.inactive}
                              />
                            </View>
                            <View style={styles.notificationInfo}>
                              <Text style={styles.notificationLabel}>{setting.label}</Text>
                              <Text style={styles.notificationDescription}>{setting.description}</Text>
                            </View>
                          </View>
                          <Switch
                            value={setting.enabled}
                            onValueChange={async () => {
                              await hapticFeedback('light');
                              setNotificationSettings(prev =>
                                prev.map(s => (s.id === setting.id ? { ...s, enabled: !s.enabled } : s))
                              );
                            }}
                            trackColor={{ false: 'rgba(255,255,255,0.15)', true: businessTheme.primary }}
                            thumbColor={setting.enabled ? '#FFFFFF' : '#9CA3AF'}
                            ios_backgroundColor="rgba(255,255,255,0.15)"
                          />
                        </View>
                      </GlassCard>
                    ))}
                  </View>
                </View>
              )}
            </View>

            {/* ====== AVAILABILITY SETTINGS ====== */}
            <View style={styles.section}>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  const newValue = !availabilitySettingsExpanded;
                  setAvailabilitySettingsExpanded(newValue);
                  Animated.timing(availabilityChevronRotate, {
                    toValue: newValue ? 1 : 0,
                    duration: 200,
                    useNativeDriver: true,
                  }).start();
                }}
                style={styles.sectionHeaderButton}
                activeOpacity={0.7}
              >
                <View style={styles.sectionHeader}>
                  <Ionicons name="time-outline" size={20} color={iconAccent.primary} />
                  <Text style={[styles.sectionTitle, { color: textColors.tertiary }]}>Availability Settings</Text>
                </View>
                <Animated.View
                  style={{
                    transform: [{
                      rotate: availabilityChevronRotate.interpolate({
                        inputRange: [0, 1],
                        outputRange: ['0deg', '180deg'],
                      }),
                    }],
                  }}
                >
                  <Ionicons name="chevron-down" size={20} color={iconAccent.primary} />
                </Animated.View>
              </TouchableOpacity>
              
              {availabilitySettingsExpanded && (
                <View>
                  <Text style={styles.sectionDescription}>
                    Control when your business is available for bookings
                  </Text>

                  <GlassCard style={styles.availabilityCard} accountType="business">
                    <View style={styles.availabilityContent}>
                      <View style={styles.availabilityLeft}>
                        <View style={[styles.availabilityIconWrapper, { backgroundColor: `${businessTheme.primary}25` }]}>
                          <Ionicons name="calendar" size={18} color={iconAccent.primary} />
                        </View>
                        <View style={styles.availabilityInfo}>
                          <Text style={styles.availabilityLabel}>Accept New Bookings</Text>
                          <Text style={styles.availabilityDescription}>
                            Allow customers to book services at your locations
                          </Text>
                        </View>
                      </View>
                      <Switch
                        value={isAvailable}
                        onValueChange={async () => {
                          await hapticFeedback('light');
                          setIsAvailable(!isAvailable);
                        }}
                        trackColor={{ false: 'rgba(255,255,255,0.15)', true: businessTheme.primary }}
                        thumbColor={isAvailable ? '#FFFFFF' : '#9CA3AF'}
                        ios_backgroundColor="rgba(255,255,255,0.15)"
                      />
                    </View>
                  </GlassCard>

                  <GlassCard style={styles.availabilityCard} accountType="business">
                    <View style={styles.availabilityContent}>
                      <View style={styles.availabilityLeft}>
                        <View style={[styles.availabilityIconWrapper, { backgroundColor: `${businessTheme.primaryAlt}25` }]}>
                          <Ionicons name="flash" size={18} color={iconAccent.highlight} />
                        </View>
                        <View style={styles.availabilityInfo}>
                          <Text style={styles.availabilityLabel}>Auto-Accept Bookings</Text>
                          <Text style={styles.availabilityDescription}>
                            Automatically confirm bookings without manual approval
                          </Text>
                        </View>
                      </View>
                      <Switch
                        value={autoAcceptBookings}
                        onValueChange={async () => {
                          await hapticFeedback('light');
                          setAutoAcceptBookings(!autoAcceptBookings);
                        }}
                        trackColor={{ false: 'rgba(255,255,255,0.15)', true: businessTheme.primary }}
                        thumbColor={autoAcceptBookings ? '#FFFFFF' : '#9CA3AF'}
                        ios_backgroundColor="rgba(255,255,255,0.15)"
                      />
                    </View>
                  </GlassCard>
                </View>
              )}
            </View>

            {/* ====== SAVE / CANCEL ====== */}
            {isEditing ? (
              <View style={{ gap: 12, marginTop: 22 }}>
                <TouchableOpacity
                  style={[styles.saveButton, (!hasChanges || isSaving) && { opacity: 0.6 }]}
                  onPress={handleSave}
                  disabled={!hasChanges || isSaving}
                  activeOpacity={0.86}
                >
                  <LinearGradient
                    colors={[businessTheme.primaryAlt, businessTheme.primary]}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={styles.saveButtonGradient}
                  >
                    {isSaving ? (
                      <ActivityIndicator size="small" color="#fff" />
                    ) : (
                      <>
                        <Ionicons name="checkmark" size={18} color="#fff" />
                        <Text style={styles.saveButtonText}>Save</Text>
                      </>
                    )}
                  </LinearGradient>
                </TouchableOpacity>

                <TouchableOpacity
                  style={[styles.secondaryButton, isSaving && { opacity: 0.7 }]}
                  onPress={cancelEditing}
                  disabled={isSaving}
                  activeOpacity={0.86}
                >
                  <Ionicons name="close" size={18} color={textColors.primary} />
                  <Text style={[styles.secondaryButtonText, isLightMode && { color: textColors.primary }]}>Cancel</Text>
                </TouchableOpacity>

                {!hasChanges && <Text style={styles.hintText}>No changes to save.</Text>}
              </View>
            ) : (
              <View style={styles.tipCard}>
                <Ionicons name="bulb-outline" size={18} color={iconColors.primary} />
                <Text style={[ts.bodySmall, { flex: 1 }]}>Add a logo and description to make your business profile stand out to customers.</Text>
              </View>
            )}

            {/* ====== ACCOUNT: ORDERS & DELETE ====== */}
            <View style={styles.section}>
              <View style={styles.formSectionHeader}>
                <Ionicons name="settings-outline" size={20} color={iconColors.primary} />
                <Text style={[ts.sectionTitle, { marginBottom: 0 }]}>Account</Text>
              </View>
              <TouchableOpacity
                onPress={async () => {
                  await hapticFeedback('light');
                  router.push('/business/orders' as any);
                }}
                activeOpacity={0.9}
                style={{ marginBottom: 12 }}
              >
                <GlassCard style={styles.ordersCard} accountType="business" borderColor="rgba(135,206,235,0.35)">
                  <View style={styles.ordersContent}>
                    <View style={styles.ordersIconWrapper}>
                      <Ionicons name="receipt-outline" size={22} color={iconColors.primary} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.ordersTitle}>Orders</Text>
                      <Text style={styles.ordersSubtitle}>View completed orders and receipts</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color={iconAccent.primary} />
                  </View>
                </GlassCard>
              </TouchableOpacity>
              <TouchableOpacity
                onPress={handleDeleteAccount}
                activeOpacity={0.9}
              >
                <GlassCard style={styles.deleteCard} accountType="business" borderColor="rgba(239,68,68,0.35)">
                  <View style={styles.deleteContent}>
                    <View style={styles.deleteIconWrapper}>
                      <Ionicons name="trash-outline" size={22} color={iconAccent.destructive} />
                    </View>
                    <View style={{ flex: 1 }}>
                      <Text style={styles.deleteTitle}>Delete Account</Text>
                      <Text style={styles.deleteSubtitle}>Permanently delete your account and all data</Text>
                    </View>
                    <Ionicons name="chevron-forward" size={20} color={iconAccent.destructive} />
                  </View>
                </GlassCard>
              </TouchableOpacity>
            </View>

            <View style={{ height: 22 }} />
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
      </SafeAreaView>
    </View>
  );
}

const CIRCLE = 120;

const styles = StyleSheet.create({
  container: { flex: 1 },

  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
    paddingHorizontal: 24,
  },
  loadingText: { color: LIGHT_TEXT, fontSize: 14, fontWeight: '700' },

  scrollView: { flex: 1 },
  scrollContent: { padding: 20, flexGrow: 1 },

  content: { gap: 22 },
  section: { gap: 8, marginBottom: 12 },

  profileCompletionCard: {
    padding: 18,
    marginBottom: 14,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    gap: 12,
  },
  profileCompletionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  profileCompletionBar: {
    height: 6,
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.15)',
    overflow: 'hidden',
  },
  profileCompletionFill: {
    height: '100%',
    borderRadius: 3,
    backgroundColor: SKY,
  },
  formSectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 16,
    marginTop: 8,
  },
  tipCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 16,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.15)',
  },

  label: { color: MUTED_TEXT, fontSize: 13, fontWeight: '800', marginBottom: 8, letterSpacing: 0.2 },

  heroCard: {
    padding: 24,
    marginBottom: 22,
    borderRadius: 24,
  },
  heroTop: {
    alignItems: 'center',
  },

  // === Premium logo section ===
  logoSection: {
    position: 'relative',
    marginBottom: 20,
  },
  logoCircleOuter: {
    width: 120,
    height: 120,
    borderRadius: 60,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2.5,
    borderColor: `${businessThemeStatic.primary}40`,
    overflow: 'hidden',
    shadowColor: businessThemeStatic.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  logoCircleInner: {
    width: 108,
    height: 108,
    borderRadius: 54,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.05)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: `${businessThemeStatic.primary}30`,
  },
  logoCircleImg: {
    width: '100%',
    height: '100%',
  },
  logoCircleFallback: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: `${businessThemeStatic.primary}20`,
  },
  logoActionButtons: {
    position: 'absolute',
    right: -4,
    bottom: -4,
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  logoEditBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 3,
    borderColor: 'rgba(255,255,255,0.4)',
    shadowColor: businessThemeStatic.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
  },
  logoEditBtnGradient: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },

  heroTextSection: {
    alignItems: 'center',
    marginBottom: 18,
    gap: 8,
  },
  heroName: { 
    color: LIGHT_TEXT, 
    fontSize: isSmallScreen ? 22 : 24, 
    fontWeight: '900', 
    letterSpacing: 0.3, 
    textAlign: 'center',
    marginBottom: 4,
  },
  heroSubSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 2,
  },
  heroSub: { 
    color: MUTED_TEXT, 
    fontSize: 14, 
    fontWeight: '600', 
    textAlign: 'center',
  },

  heroPillsRow: { 
    flexDirection: 'row', 
    gap: 10, 
    marginBottom: 20, 
    flexWrap: 'wrap', 
    justifyContent: 'center',
    width: '100%',
  },
  pill: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: `${businessThemeStatic.primary}40`,
    shadowColor: businessThemeStatic.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  pillGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 9,
    paddingHorizontal: 14,
  },
  pillIconWrapper: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: `${businessThemeStatic.primary}30`,
    alignItems: 'center',
    justifyContent: 'center',
  },
  pillText: { 
    color: LIGHT_TEXT, 
    fontSize: 13, 
    fontWeight: '800',
    letterSpacing: 0.2,
  },

  heroActionsRow: { 
    flexDirection: 'row', 
    gap: 12, 
    marginBottom: 20, 
    width: '100%' 
  },
  heroBtn: {
    flex: 1,
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: `${businessThemeStatic.primary}40`,
  },
  heroBtnGradient: {
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 14,
  },
  heroBtnIconWrapper: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: `${businessThemeStatic.primary}25`,
    alignItems: 'center',
    justifyContent: 'center',
  },
  heroBtnText: { 
    color: LIGHT_TEXT, 
    fontSize: 14, 
    fontWeight: '800',
    letterSpacing: 0.2,
  },

  heroHintContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    width: '100%',
  },
  heroHint: { 
    color: MUTED_TEXT, 
    fontSize: 12, 
    fontWeight: '600', 
    lineHeight: 18, 
    flex: 1,
  },

  // inputs
  inputCard: { ...CARD_SIZES.small, overflow: 'hidden', padding: 16 },
  input: { color: LIGHT_TEXT, fontSize: 16, padding: 0, fontWeight: '800' },
  textArea: { minHeight: 80, textAlignVertical: 'top' },

  headerAction: {
    width: 36,
    height: 36,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(132,204,22,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(132,204,22,0.3)',
  },

  saveButton: { borderRadius: 16, overflow: 'hidden' },
  saveButtonGradient: {
    height: 52,
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 18,
  },
  saveButtonText: { color: '#fff', fontSize: 16, fontWeight: '900' },

  secondaryButton: {
    height: 48,
    borderRadius: 16,
    backgroundColor: 'rgba(132,204,22,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(132,204,22,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'row',
    gap: 8,
  },
  secondaryButtonText: { color: LIGHT_TEXT, fontSize: 15, fontWeight: '900' },

  hintText: {
    color: MUTED_TEXT,
    fontSize: 12,
    lineHeight: 18,
    marginTop: 8,
    textAlign: 'center',
    fontWeight: '700',
  },
  ordersCard: {
    padding: 16,
    backgroundColor: 'rgba(135,206,235,0.06)',
  },
  ordersContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  ordersIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.14)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.22)',
  },
  ordersTitle: {
    color: LIGHT_TEXT,
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 2,
  },
  ordersSubtitle: {
    color: MUTED_TEXT,
    fontSize: 12,
    fontWeight: '600',
  },
  deleteCard: {
    padding: 16,
    backgroundColor: 'rgba(239,68,68,0.06)',
  },
  deleteContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  deleteIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(239,68,68,0.14)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.22)',
  },
  deleteTitle: {
    color: LIGHT_TEXT,
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 2,
  },
  deleteSubtitle: {
    color: MUTED_TEXT,
    fontSize: 12,
    fontWeight: '600',
  },
  sectionHeaderButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  sectionHeader: {
    ...ICON_TEXT_LAYOUT.sectionHeader,
    flex: 1,
    marginBottom: 8,
  },
  sectionTitle: {
    color: LIGHT_TEXT,
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: 0.3,
  },
  sectionDescription: {
    color: MUTED_TEXT,
    fontSize: 13,
    marginBottom: 16,
    lineHeight: 18,
    fontWeight: '600',
  },
  settingsButton: {
    marginTop: 8,
  },
  settingsCard: {
    padding: 0,
    overflow: 'hidden',
  },
  settingsContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  settingsLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    flex: 1,
  },
  settingsIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 14,
    overflow: 'hidden',
  },
  settingsIconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  settingsText: {
    flex: 1,
    gap: 4,
  },
  settingsTitle: {
    color: LIGHT_TEXT,
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  settingsSubtitle: {
    color: MUTED_TEXT,
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '600',
  },

  // Notification Settings
  notificationList: {
    gap: 12,
    marginTop: 12,
  },
  notificationCard: {
    borderRadius: 20,
    padding: 0,
  },
  notificationContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  notificationLeft: {
    ...ICON_TEXT_LAYOUT.itemRow,
    flex: 1,
  },
  notificationIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  notificationInfo: {
    flex: 1,
    gap: 4,
  },
  notificationLabel: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: 0.1,
  },
  notificationDescription: {
    color: 'rgba(249,250,251,0.70)',
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '500',
  },

  // Availability Settings
  availabilityCard: {
    borderRadius: 20,
    padding: 0,
    marginBottom: 12,
  },
  availabilityContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: 16,
  },
  availabilityLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    gap: 12,
  },
  availabilityIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  availabilityInfo: {
    flex: 1,
    gap: 4,
  },
  availabilityLabel: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    letterSpacing: 0.1,
  },
  availabilityDescription: {
    color: 'rgba(249,250,251,0.70)',
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '500',
  },
});
