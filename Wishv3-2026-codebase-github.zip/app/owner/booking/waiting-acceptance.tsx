import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  Animated,
  Image,
  TouchableOpacity,
  Modal,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Region, Marker, Circle } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import { router, useLocalSearchParams } from 'expo-router';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import UnifiedBookingCard from '../../../src/components/booking/UnifiedBookingCard';
import AppHeader from '../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';
import { DEFAULT_MAP_REGION } from '../../../src/constants/mapConstants';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import SuccessOverlay from '../../../src/components/booking/SuccessOverlay';
import ValeterDeclinedOverlay from '../../../src/components/booking/ValeterDeclinedOverlay';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

function getWaitingMessageIcon(index: number): 'checkmark-circle' | 'time-outline' | 'card-outline' {
  if (index === 0) return 'checkmark-circle';
  if (index === 1) return 'time-outline';
  return 'card-outline';
}

function getWaitingMessageLabel(index: number): string {
  if (index === 0) return 'Request sent';
  if (index === 1) return '5 min to respond';
  return 'Pay on acceptance';
}

type BookingRow = { status: string; valeter_id?: string };

export default function WaitingAcceptance() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;

  const [booking, setBooking] = useState<BookingRow | null>(null);
  const [valeter, setValeter] = useState<{ full_name?: string; profile_photo_url?: string; company_name?: string } | null>(null);
  const [valeterLocation, setValeterLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [valeterLocationOffset, setValeterLocationOffset] = useState<{ latOffset: number; lngOffset: number } | null>(null);
  const [countdown, setCountdown] = useState(300); // 5 minutes
  const [status, setStatus] = useState<string>('pending_valeter_acceptance');
  const [showAcceptedOverlay, setShowAcceptedOverlay] = useState(false);
  const [showValeterDeclinedOverlay, setShowValeterDeclinedOverlay] = useState(false);
  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);
  const [showExpandingMessage, setShowExpandingMessage] = useState(false);
  const [showStillLookingSheet, setShowStillLookingSheet] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const timeProgressAnim = useRef(new Animated.Value(1)).current;
  const messageSlideAnim = useRef(new Animated.Value(0)).current; // Start visible (0 = opacity 1)
  const clockSpinAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    if (liveCoords) {
      setUserLocation({ latitude: liveCoords.latitude, longitude: liveCoords.longitude });
      setRegion({
        latitude: liveCoords.latitude,
        longitude: liveCoords.longitude,
        latitudeDelta: 0.002,
        longitudeDelta: 0.002,
      });
    }
    loadBooking();
    const unsubscribe = subscribeToBooking();
    getCurrentLocation();

    return () => {
      unsubscribe?.();
    };
  }, [bookingId, liveCoords]);

  // Spinning clock icon (loop)
  useEffect(() => {
    const runSpin = () => {
      clockSpinAnim.setValue(0);
      Animated.timing(clockSpinAnim, {
        toValue: 1,
        duration: 2000,
        useNativeDriver: true,
      }).start(({ finished }) => {
        if (finished) runSpin();
      });
    };
    runSpin();
  }, []);

  // Rotate messages every 3 seconds
  useEffect(() => {
    const messageCount = 3;
    const onFadeOutComplete = () => {
      setCurrentMessageIndex((prev) => (prev + 1) % messageCount);
      messageSlideAnim.setValue(1);
      Animated.timing(messageSlideAnim, {
        toValue: 0,
        duration: 300,
        useNativeDriver: true,
      }).start();
    };
    const runMessageTransition = () => {
      Animated.timing(messageSlideAnim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start(onFadeOutComplete);
    };
    const interval = setInterval(runMessageTransition, 3000);
    return () => clearInterval(interval);
  }, []);

  // Timer countdown effect
  useEffect(() => {
    if (countdown <= 0) {
      handleCountdownComplete();
      return;
    }

    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleCountdownComplete();
          return 0;
        }
        if (prev === 211) setShowExpandingMessage(true); // ~90s elapsed
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [countdown]);

  // Update time progress animation
  useEffect(() => {
    const progress = countdown / 300; // 300 seconds = 5 minutes
    Animated.timing(timeProgressAnim, {
      toValue: progress,
      duration: 1000,
      useNativeDriver: false,
    }).start();
  }, [countdown]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.warn('Location permission not granted');
        return;
      }

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };

      setUserLocation(coords);
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.002,
        longitudeDelta: 0.002,
      });
    } catch (error) {
      console.warn('Error getting location:', error);
    }
  };

  const loadBooking = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', bookingId)
        .single();

      if (error) throw error;
      setBooking(data as BookingRow);
      setStatus((data as BookingRow).status);

      if (data?.valeter_id) {
        // Load valeter profile
        const { data: valeterProfile, error: valeterError } = await supabase
          .from('valeter_profiles')
          .select('full_name, profile_photo_url, company_name')
          .eq('user_id', data.valeter_id)
          .maybeSingle();

        if (!valeterError && valeterProfile) {
          setValeter(valeterProfile);
        } else {
          setValeter(null);
        }

        // Load valeter location from presence
        const { data: presenceData, error: presenceError } = await supabase
          .from('valeter_presence')
          .select('last_lat, last_lng')
          .eq('user_id', data.valeter_id)
          .maybeSingle();

        if (!presenceError && presenceData?.last_lat && presenceData?.last_lng) {
          const valeterCoords = {
            latitude: Number(presenceData.last_lat),
            longitude: Number(presenceData.last_lng),
          };
          setValeterLocation(valeterCoords);
          
          // Generate random offset once to blur exact location (within ~100m)
          const latOffset = (Math.random() - 0.5) * 0.001;
          const lngOffset = (Math.random() - 0.5) * 0.001;
          setValeterLocationOffset({ latOffset, lngOffset });
          
          setRegion({
            latitude: valeterCoords.latitude,
            longitude: valeterCoords.longitude,
            latitudeDelta: 0.002,
            longitudeDelta: 0.002,
          });
        }
      } else {
        setValeter(null);
        setValeterLocation(null);
      }
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const subscribeToBooking = () => {
    const channel = supabase
      .channel(`booking-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        async (payload) => {
          const updated = payload.new as BookingRow;
          setStatus(updated.status);

          if (updated.status === 'pending_payment') {
            // Show success overlay when booking is accepted
            setShowAcceptedOverlay(true);
            hapticFeedback('success');

            // Navigate to payment after overlay
            setTimeout(() => {
              router.replace({
                pathname: '/owner/booking/payment',
                params: { bookingId },
              });
            }, 2000);
            return;
          }
          if (updated.status === 'confirmed' || updated.status === 'valeter_assigned' || updated.status === 'en_route' || updated.status === 'in_progress' || updated.status === 'scheduled') {
            router.replace('/owner/owner-dashboard');
            return;
          }
          // Real-time sync: valeter declined, timeout, or job cancelled → show gamified overlay
          if (
            updated.status === 'cancelled' ||
            updated.status === 'valeter_declined' ||
            updated.status === 'valeter_timeout'
          ) {
            setShowValeterDeclinedOverlay(true);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleCountdownComplete = () => {
    setShowStillLookingSheet(true);
  };

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return {
      minutes: mins.toString().padStart(2, '0'),
      seconds: secs.toString().padStart(2, '0'),
    };
  };

  const timeDisplay = formatTime(countdown);
  const isUrgent = countdown <= 60; // Red when under 1 minute

  return (
    <SafeAreaView key={`${booking ? 'loaded' : 'pending'}-${status}`} style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map – real map with default region until location loads */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region ?? DEFAULT_MAP_REGION}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image
                  source={require('../../../assets/car.png')}
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {valeterLocation && valeterLocationOffset && (
            <>
              <Circle
                center={{ latitude: valeterLocation.latitude, longitude: valeterLocation.longitude }}
                radius={150}
                fillColor="rgba(15, 23, 42, 0.4)"
                strokeColor="rgba(135,206,235,0.2)"
                strokeWidth={1}
              />
              <Marker
                coordinate={{
                  latitude: valeterLocation.latitude + valeterLocationOffset.latOffset,
                  longitude: valeterLocation.longitude + valeterLocationOffset.lngOffset,
                }}
              >
                <View style={styles.valeterMarkerContainer}>
                  <View style={styles.valeterMarkerBlur}>
                    <Image
                      source={require('../../../assets/cleaning.png')}
                      style={styles.valeterMarker}
                      resizeMode="contain"
                    />
                  </View>
                </View>
              </Marker>
            </>
          )}
        </MapView>
      </View>

      {/* Header floating over the map */}
      <AppHeader 
        title="Booking Request" 
        subtitle="Connecting to your pro"
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
      />

      {/* Booking Request Card - same style as valeter/vehicle cards with side strip + spinning clock */}
      <Animated.View
        style={[
          styles.messageCardContainer,
          {
            opacity: fadeAnim,
            bottom: Math.max(insets.bottom, 20) + TAB_BAR_TOTAL_HEIGHT + 12,
          },
        ]}
      >
        <View style={styles.waitingCardWrap}>
          <UnifiedBookingCard stripColor={SKY} style={styles.waitingCard}>
            <View style={styles.waitingCardHeader}>
              <View style={[styles.waitingStatusDot, isUrgent && styles.waitingStatusDotUrgent]}>
                <Animated.View
                  style={{
                    transform: [{
                      rotate: clockSpinAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: ['0deg', '360deg'],
                      }),
                    }],
                  }}
                >
                  <Ionicons name="time-outline" size={20} color={isUrgent ? '#EF4444' : SKY} />
                </Animated.View>
              </View>
              <View style={styles.waitingCardTitleWrap}>
                <Text style={styles.waitingCardTitle}>Connecting to your pro</Text>
                <Text style={styles.waitingCardSubtitle}>
                  {valeter ? `Connecting you with ${valeter.full_name || 'your pro'}` : 'We\'re finding your pro'}
                </Text>
              </View>
              {countdown > 0 && (
                <View style={[styles.timerBadge, isUrgent && styles.timerBadgeUrgent]}>
                  <Text style={[styles.timerBadgeText, isUrgent && styles.timerBadgeTextUrgent]}>
                    {timeDisplay.minutes}:{timeDisplay.seconds}
                  </Text>
                </View>
              )}
            </View>
            {countdown > 0 && (
              <View style={styles.waitingProgressWrap}>
                <View style={styles.progressBarBackground}>
                  <Animated.View
                    style={[
                      styles.progressBarFill,
                      isUrgent && styles.progressBarFillUrgent,
                      {
                        width: timeProgressAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: ['0%', '100%'],
                        }),
                      },
                    ]}
                  />
                </View>
              </View>
            )}
            <View style={styles.waitingMessageRow}>
              <View style={[styles.waitingMsgIcon, { backgroundColor: SKY + '18' }]}>
                <Ionicons name={getWaitingMessageIcon(currentMessageIndex)} size={18} color={SKY} />
              </View>
              <Text style={styles.waitingMsgLabel}>
                {getWaitingMessageLabel(currentMessageIndex)}
              </Text>
            </View>
            {showExpandingMessage && (
              <Text style={styles.expandingLine}>Still searching — expanding the area</Text>
            )}
            <View style={styles.reassuranceChips}>
              <View style={styles.reassuranceRow}>
                <Ionicons name="checkmark-circle" size={14} color={colors.ecoGreen} />
                <Text style={styles.reassuranceText}>No payment taken yet</Text>
              </View>
              <View style={styles.reassuranceRow}>
                <Ionicons name="checkmark-circle" size={14} color={colors.ecoGreen} />
                <Text style={styles.reassuranceText}>You'll be notified instantly</Text>
              </View>
            </View>
            <View style={styles.escapeActions}>
              <TouchableOpacity
                style={styles.escapeBtn}
                onPress={() => { hapticFeedback('light'); router.back(); }}
                activeOpacity={0.8}
              >
                <Ionicons name="person-outline" size={16} color={SKY} />
                <Text style={styles.escapeBtnText}>Change washer</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.escapeBtn}
                onPress={() => { hapticFeedback('light'); router.back(); }}
                activeOpacity={0.8}
              >
                <Ionicons name="calendar-outline" size={16} color={SKY} />
                <Text style={styles.escapeBtnText}>Book for later</Text>
              </TouchableOpacity>
            </View>
          </UnifiedBookingCard>
        </View>
      </Animated.View>

      {/* Success Overlay when booking is accepted */}
      <SuccessOverlay
        visible={showAcceptedOverlay}
        type="accepted"
        message="Booking Accepted!"
        onComplete={() => setShowAcceptedOverlay(false)}
      />

      {/* Gamified overlay when valeter declines / job cancelled */}
      <ValeterDeclinedOverlay
        visible={showValeterDeclinedOverlay}
        onFindNewValeter={() => {
          setShowValeterDeclinedOverlay(false);
          void (async () => {
            try {
              const { error } = await supabase
                .from('bookings')
                .update({
                  status: 'pending_valeter_acceptance',
                  valeter_id: null,
                  request_sent_at: new Date().toISOString(),
                })
                .eq('id', bookingId);
              if (error) throw error;
              router.replace({ pathname: '/owner/booking/valeter-selection', params: { bookingId } } as any);
            } catch (e) {
              console.error('Error reopening booking:', e);
              router.replace('/owner/owner-dashboard');
            }
          })();
        }}
        onBackToDashboard={() => {
          setShowValeterDeclinedOverlay(false);
          router.replace('/owner/owner-dashboard');
        }}
      />

      {/* Still looking — gentle bottom sheet when no acceptance in time */}
      <Modal
        visible={showStillLookingSheet}
        transparent
        animationType="slide"
        onRequestClose={() => setShowStillLookingSheet(false)}
      >
        <Pressable style={styles.stillLookingOverlay} onPress={() => setShowStillLookingSheet(false)}>
          <Pressable style={[styles.stillLookingSheet, { paddingBottom: Math.max(insets.bottom, 20) + 24 }]} onPress={(e) => e.stopPropagation()}>
            <View style={styles.stillLookingHandle} />
            <Text style={styles.stillLookingTitle}>Still looking…</Text>
            <Text style={styles.stillLookingBody}>
              It's busy right now, but we're still searching nearby.
            </Text>
            <View style={styles.stillLookingActions}>
              <TouchableOpacity
                style={styles.stillLookingBtn}
                onPress={() => { setShowStillLookingSheet(false); router.back(); }}
                activeOpacity={0.8}
              >
                <Ionicons name="calendar-outline" size={20} color={SKY} />
                <Text style={styles.stillLookingBtnText}>Schedule for later</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.stillLookingBtn, styles.stillLookingBtnPrimary]}
                onPress={() => { setShowStillLookingSheet(false); router.back(); }}
                activeOpacity={0.8}
              >
                <Ionicons name="refresh-outline" size={20} color="#FFF" />
                <Text style={[styles.stillLookingBtnText, styles.stillLookingBtnTextPrimary]}>Try again</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.stillLookingBtn}
                onPress={() => { setShowStillLookingSheet(false); router.back(); }}
                activeOpacity={0.8}
              >
                <Ionicons name="location-outline" size={20} color={SKY} />
                <Text style={styles.stillLookingBtnText}>Change location</Text>
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  statusCardContainer: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 100,
  },
  statusCardBlur: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  statusCardContent: {
    padding: 16,
    backgroundColor: 'transparent',
  },
  statusCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  statusCardHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  statusIndicator: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statusIndicatorUrgent: {
    backgroundColor: 'rgba(239,68,68,0.2)',
    borderColor: '#EF4444',
  },
  statusCardTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 2,
  },
  statusCardSubtitle: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: 12,
    fontWeight: '600',
  },
  timerBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 1,
    borderColor: SKY,
  },
  timerBadgeUrgent: {
    backgroundColor: 'rgba(239,68,68,0.2)',
    borderColor: '#EF4444',
  },
  timerBadgeText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '900',
    fontVariant: ['tabular-nums'],
  },
  timerBadgeTextUrgent: {
    color: '#EF4444',
  },
  progressBarContainer: {
    gap: 8,
  },
  progressBarBackground: {
    height: 6,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: SKY,
    borderRadius: 3,
  },
  progressBarFillUrgent: {
    backgroundColor: '#EF4444',
  },
  progressBarLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 10,
    fontWeight: '600',
    textAlign: 'right',
  },
  valeterMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  valeterMarkerBlur: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderWidth: 3,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
    elevation: 5,
    overflow: 'hidden',
  },
  valeterMarker: {
    width: 48,
    height: 48,
  },
  messageCardContainer: {
    position: 'absolute',
    left: 12,
    right: 12,
    zIndex: 1000,
  },
  waitingCardWrap: {
    position: 'relative',
    borderRadius: 18,
    overflow: 'hidden',
  },
  waitingCardStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 5,
    borderTopLeftRadius: 16,
    borderBottomLeftRadius: 16,
    zIndex: 1,
  },
  waitingCard: {
    padding: 24,
    minHeight: 168,
  },
  waitingCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  waitingStatusDot: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: SKY + '18',
    borderWidth: 1.5,
    borderColor: SKY + '40',
    justifyContent: 'center',
    alignItems: 'center',
  },
  waitingStatusDotUrgent: {
    backgroundColor: 'rgba(239,68,68,0.15)',
    borderColor: '#EF4444',
  },
  waitingCardTitleWrap: {
    flex: 1,
    minWidth: 0,
  },
  waitingCardTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
  },
  waitingCardSubtitle: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: 13,
    fontWeight: '600',
    marginTop: 2,
  },
  waitingProgressWrap: {
    marginBottom: 12,
  },
  waitingMessageRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  waitingMsgIcon: {
    width: 40,
    height: 40,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  waitingMsgLabel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    flex: 1,
  },
  expandingLine: {
    color: SKY,
    fontSize: 12,
    fontWeight: '600',
    marginTop: 6,
    marginBottom: 2,
  },
  reassuranceChips: {
    marginTop: 10,
    gap: 4,
  },
  reassuranceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  reassuranceText: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 12,
    fontWeight: '600',
  },
  escapeActions: {
    flexDirection: 'row',
    marginTop: 14,
    gap: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  escapeBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  escapeBtnText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
  },
  stillLookingOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10,25,41,0.6)',
    justifyContent: 'flex-end',
  },
  stillLookingSheet: {
    backgroundColor: colors.BG,
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 40,
  },
  stillLookingHandle: {
    width: 36,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.3)',
    alignSelf: 'center',
    marginBottom: 16,
  },
  stillLookingTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
    textAlign: 'center',
  },
  stillLookingBody: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 15,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 22,
  },
  stillLookingActions: {
    gap: 10,
  },
  stillLookingBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  stillLookingBtnPrimary: {
    backgroundColor: SKY,
    borderColor: SKY,
  },
  stillLookingBtnText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  stillLookingBtnTextPrimary: {
    color: '#FFFFFF',
  },
  messageCardBlur: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  messageCardContent: {
    padding: 18,
    backgroundColor: 'transparent',
    minHeight: 80,
    justifyContent: 'center',
  },
  messageContent: {
    justifyContent: 'center',
  },
  messageContentWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  messageIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  messageTextWrapper: {
    flex: 1,
    gap: 4,
  },
  messageText: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
  },
  messageSubtext: {
    color: 'rgba(255,255,255,0.65)',
    fontSize: 12,
    fontWeight: '600',
  },
});

