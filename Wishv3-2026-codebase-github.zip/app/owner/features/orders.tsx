import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Platform,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import AppHeader from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { getScrollContentPadding } from '../../../src/constants/layoutConstants';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import EmptyState from '../../../src/components/shared/EmptyState';
import * as Print from 'expo-print';
import * as Sharing from 'expo-sharing';

const SKY = colors.SKY;

const PLATFORM_FEE = 1.5;

type CompletedBooking = {
  id: string;
  service_name: string | null;
  service_type: string | null;
  price: number;
  completed_at: string | null;
  created_at: string;
  valeter_name: string | null;
  valeter_organization_name: string | null;
  location_address: string | null;
  tip_amount: number | null;
  rating: number | null;
  payment_completed_at: string | null;
};

function buildReceiptHTML(
  booking: CompletedBooking,
  customerName: string,
  customerEmail: string
): string {
  const date = booking.completed_at || booking.created_at;
  const formattedDate = new Date(date).toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
  const serviceName = getServiceDisplayName(booking.service_type, booking.service_name);
  const price = Number(booking.price) || 0;
  const serviceAmount = Math.max(0, price - PLATFORM_FEE);
  const tip = Number(booking.tip_amount) || 0;
  const total = price + tip;

  const paymentStatus = booking.payment_completed_at
    ? `Paid on ${new Date(booking.payment_completed_at).toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'short',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })}`
    : 'Payment completed';

  const valeterLine =
    booking.valeter_name || booking.valeter_organization_name
      ? [
          booking.valeter_name ? `Valeter: ${booking.valeter_name}` : null,
          booking.valeter_organization_name ? `(${booking.valeter_organization_name})` : null,
        ]
          .filter(Boolean)
          .join(' ')
      : '';

  return `
    <div style="font-family: system-ui, -apple-system, sans-serif; padding: 32px; max-width: 420px; background: linear-gradient(180deg, #152238 0%, #0A1929 100%); min-height: 100vh; color: #FFFFFF;">
      <h1 style="color: #87CEEB; font-size: 26px; margin-bottom: 4px; font-weight: 700; letter-spacing: 0.5px;">Wish a Wash</h1>
      <p style="color: rgba(255,255,255,0.9); font-size: 13px; margin-bottom: 24px; font-weight: 500;">Wash Receipt</p>
      <hr style="border: none; border-top: 1px solid rgba(135,206,235,0.4); margin: 20px 0;" />
      <p style="font-size: 15px; margin: 10px 0; color: #FFFFFF;"><strong style="color: rgba(255,255,255,0.9);">Receipt #</strong> ${String(booking.id).slice(0, 8).toUpperCase()}</p>
      <p style="font-size: 15px; margin: 10px 0; color: #FFFFFF;"><strong style="color: rgba(255,255,255,0.9);">Date</strong> ${formattedDate}</p>
      <p style="font-size: 14px; margin: 10px 0; color: #FFFFFF;"><strong style="color: rgba(255,255,255,0.9);">Payment status</strong> ${paymentStatus}</p>
      <hr style="border: none; border-top: 1px solid rgba(135,206,235,0.4); margin: 20px 0;" />
      <p style="font-size: 14px; margin: 6px 0; color: rgba(255,255,255,0.9);"><strong>Customer</strong></p>
      <p style="font-size: 15px; margin: 4px 0; color: #FFFFFF;">${customerName || '—'}</p>
      <p style="font-size: 14px; color: #FFFFFF; margin: 4px 0; opacity: 0.95;">${customerEmail || '—'}</p>
      <hr style="border: none; border-top: 1px solid rgba(135,206,235,0.4); margin: 20px 0;" />
      <p style="font-size: 17px; margin: 12px 0; color: #FFFFFF; font-weight: 600;">${serviceName}</p>
      ${valeterLine ? `<p style="font-size: 14px; color: #FFFFFF; margin: 6px 0; opacity: 0.95;">${valeterLine}</p>` : ''}
      ${booking.location_address ? `<p style="font-size: 13px; color: #FFFFFF; margin: 6px 0; opacity: 0.9;">${booking.location_address}</p>` : ''}
      <hr style="border: none; border-top: 1px solid rgba(135,206,235,0.4); margin: 20px 0;" />
      <p style="font-size: 14px; color: rgba(255,255,255,0.95); margin-bottom: 12px; font-weight: 600;">Pricing breakdown</p>
      <div style="display: flex; justify-content: space-between; margin: 10px 0; color: #FFFFFF; font-size: 15px;">
        <span>${serviceName}</span>
        <span>£${serviceAmount.toFixed(2)}</span>
      </div>
      <div style="display: flex; justify-content: space-between; margin: 10px 0; color: #FFFFFF; font-size: 15px;">
        <span>Wish a Wash platform fee</span>
        <span>£${PLATFORM_FEE.toFixed(2)}</span>
      </div>
      ${tip > 0 ? `
      <div style="display: flex; justify-content: space-between; margin: 10px 0; color: #FFFFFF; font-size: 15px;">
        <span>Tip</span>
        <span>£${tip.toFixed(2)}</span>
      </div>
      ` : ''}
      <div style="display: flex; justify-content: space-between; font-size: 19px; font-weight: 700; margin-top: 20px; padding-top: 16px; border-top: 2px solid #87CEEB; color: #FFFFFF;">
        <span>Total</span>
        <span>£${total.toFixed(2)}</span>
      </div>
      <p style="color: #FFFFFF; font-size: 12px; margin-top: 28px; text-align: center; opacity: 0.9;">Thank you for choosing Wish a Wash</p>
    </div>
  `;
}

export default function PastWashesScreen() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [orders, setOrders] = useState<CompletedBooking[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [generatingId, setGeneratingId] = useState<string | null>(null);

  const loadOrders = useCallback(async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('id, service_name, service_type, price, completed_at, created_at, valeter_name, location_address, tip_amount, rating, payment_completed_at, valeter_id')
        .eq('user_id', user.id)
        .eq('status', 'completed')
        .order('completed_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      const rows = data || [];
      const valeterIds = [...new Set(rows.map((r) => (r as any).valeter_id).filter(Boolean))] as string[];
      let orgByValeter: Record<string, string> = {};
      if (valeterIds.length > 0) {
        try {
          const { data: profiles } = await supabase
            .from('profiles')
            .select('id, organization_name')
            .in('id', valeterIds);
          if (profiles) {
            orgByValeter = Object.fromEntries(
              profiles
                .map((p) => [p.id, (p as { organization_name?: string }).organization_name ?? ''] as [string, string])
                .filter(([, v]) => v.length > 0)
            );
          }
        } catch {
          // ignore
        }
      }
      setOrders(
        rows.map((r) => {
          const raw = r as any;
          return {
            id: r.id,
            service_name: r.service_name,
            service_type: r.service_type,
            price: Number(r.price) || 0,
            completed_at: r.completed_at,
            created_at: r.created_at,
            valeter_name: r.valeter_name ?? null,
            valeter_organization_name: raw.valeter_organization || (raw.valeter_id && orgByValeter[raw.valeter_id]) || null,
            location_address: r.location_address ?? null,
            tip_amount: r.tip_amount == null ? null : Number(r.tip_amount),
            rating: r.rating == null ? null : Number(r.rating),
            payment_completed_at: r.payment_completed_at ?? null,
          };
        })
      );
    } catch (e) {
      console.error('[Past washes] load error:', e);
      Alert.alert('Error', 'Failed to load past washes');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id]);

  useEffect(() => {
    loadOrders();
  }, [loadOrders]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadOrders();
  }, [loadOrders]);

  const handleGeneratePDF = async (booking: CompletedBooking) => {
    if (Platform.OS === 'web') {
      Alert.alert('PDF', 'PDF receipts are not available on web. Try the mobile app.');
      return;
    }
    setGeneratingId(booking.id);
    try {
      const printFn = Print.printToFileAsync;
      if (typeof printFn === 'function') {
        const customerName =
          (user?.user_metadata?.full_name as string) || (user?.user_metadata?.name as string) || user?.email?.split('@')[0] || '';
        const customerEmail = user?.email || '';
        const html = `
        <!DOCTYPE html>
        <html>
          <head><meta charset="utf-8"><title>Wash Receipt</title></head>
          <body style="margin:0; background: #0A1929;">${buildReceiptHTML(booking, customerName, customerEmail)}</body>
        </html>
      `;

        const { uri } = await printFn({
          html,
          base64: false,
        });

        const canShare = await Sharing.isAvailableAsync();
        if (canShare) {
          await Sharing.shareAsync(uri, {
            mimeType: 'application/pdf',
            dialogTitle: `Wash receipt - ${getServiceDisplayName(booking.service_type, booking.service_name)}`,
          });
        } else {
          Alert.alert('Receipt saved', `PDF saved to: ${uri}`);
        }
      } else {
        Alert.alert('Error', 'PDF generation is not available on this device.');
      }
    } catch (e: any) {
      console.error('[Orders] PDF error:', e);
      Alert.alert('Error', e?.message || 'Failed to generate receipt');
    } finally {
      setGeneratingId(null);
    }
  };

  const formatDate = (d: string | null) => {
    if (!d) return '—';
    return new Date(d).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  };

  const washPluralSuffix = orders.length === 1 ? '' : 'es';
  const subtitleText = loading ? 'Loading…' : `${orders.length} past wash${washPluralSuffix}`;

  let mainContent: React.ReactNode;
  if (loading) {
    mainContent = (
      <View style={styles.centerContainer}>
        <ActivityIndicator size="large" color={SKY} />
        <Text style={styles.loadingText}>Loading past washes…</Text>
      </View>
    );
  } else if (orders.length === 0) {
    mainContent = (
      <View style={styles.centerContainer}>
        <EmptyState
          icon="checkmark-done-circle-outline"
          title="No past washes yet"
          subtitle="Your completed washes will appear here"
          actionLabel="Book a Wash"
          onAction={() => router.push('/owner/booking')}
          iconColor={SKY}
        />
      </View>
    );
  } else {
    mainContent = (
      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          getScrollContentPadding(insets, true),
        ]}
        showsVerticalScrollIndicator={false}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />
        }
      >
        {orders.map((order) => (
          <View key={order.id} style={styles.orderCard}>
            <View style={styles.orderHeader}>
              <View style={styles.orderIconWrap}>
                <Ionicons name="car-outline" size={22} color={SKY} />
              </View>
              <View style={styles.orderInfo}>
                <Text style={styles.orderService}>{getServiceDisplayName(order.service_type, order.service_name)}</Text>
                <Text style={styles.orderDate}>{formatDate(order.completed_at || order.created_at)}</Text>
                {order.valeter_name && (
                  <Text style={styles.orderValeter}>{order.valeter_name}</Text>
                )}
              </View>
              <Text style={styles.orderPrice}>£{(order.price + (order.tip_amount || 0)).toFixed(2)}</Text>
            </View>
            <TouchableOpacity
              style={styles.receiptButton}
              onPress={() => handleGeneratePDF(order)}
              disabled={!!generatingId}
              activeOpacity={0.8}
            >
              {generatingId === order.id ? (
                <ActivityIndicator size="small" color={SKY} />
              ) : (
                <>
                  <Ionicons name="document-text-outline" size={18} color={SKY} />
                  <Text style={styles.receiptText}>Receipt</Text>
                </>
              )}
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Past washes"
        subtitle={subtitleText}
        variant="dashboard"
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
        accountType="customer"
      />

      {mainContent}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    marginTop: 12,
  },
  scrollView: { flex: 1 },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  orderCard: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  orderHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  orderIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  orderInfo: {
    flex: 1,
    minWidth: 0,
  },
  orderService: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 2,
  },
  orderDate: {
    color: '#94A3B8',
    fontSize: 13,
    marginBottom: 2,
  },
  orderValeter: {
    color: '#94A3B8',
    fontSize: 12,
  },
  orderPrice: {
    color: SKY,
    fontSize: 18,
    fontWeight: '800',
  },
  receiptButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  receiptText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
  },
});
