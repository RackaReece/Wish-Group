/**
 * Format a full name for display: spaced and title case (e.g. "Dean Lingard").
 * Handles "deanlingard", "dean lingard", "DeanLingard" -> "Dean Lingard".
 */
export function formatDisplayName(name: string | null | undefined): string {
  if (name == null || !String(name).trim()) return name ? String(name) : '';
  const s = String(name).trim();
  const withSpaces = s.replaceAll(/([a-z])([A-Z])/g, '$1 $2');
  return withSpaces
    .split(/\s+/)
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(' ');
}
