import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../../constants/colors';

const SKY = colors.SKY;

const DEFAULT_COLOR_CYCLE = [SKY, '#10B981', '#8B5CF6', '#F59E0B'];

interface AnimatedProgressProps {
  progress: number; // 0-100
  size?: number;
  strokeWidth?: number;
  showPercentage?: boolean;
  /** Font size for the percentage number; smaller values for small rings (e.g. 14 for size=72) */
  percentageFontSize?: number;
  color?: string;
  /** When true, the ring rotates continuously */
  spin?: boolean;
  /** Cycle through these colours over time; when set, spin is implied */
  colorCycle?: string[];
}

export default function AnimatedProgress({ 
  progress, 
  size = 120, 
  strokeWidth = 8,
  showPercentage = true,
  percentageFontSize,
  color = SKY,
  spin = false,
  colorCycle,
}: AnimatedProgressProps) {
  const animatedProgress = useRef(new Animated.Value(0)).current;
  const [displayProgress, setDisplayProgress] = useState(0);
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const spinAnim = useRef(new Animated.Value(0)).current;
  const colors = colorCycle ?? DEFAULT_COLOR_CYCLE;
  const colorsRef = useRef(colors);
  colorsRef.current = colors;
  const [colorIndex, setColorIndex] = useState(0);
  const effectiveColor = colorCycle ? colors[colorIndex % colors.length] : color;
  const shouldSpin = spin || !!colorCycle;

  useEffect(() => {
    Animated.parallel([
      Animated.spring(animatedProgress, {
        toValue: progress,
        useNativeDriver: false,
        tension: 50,
        friction: 7,
      }),
      Animated.sequence([
        Animated.timing(scaleAnim, {
          toValue: 1.05,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(scaleAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]),
    ]).start();

    const listener = animatedProgress.addListener(({ value }) => {
      setDisplayProgress(Math.round(value));
    });
    
    return () => {
      animatedProgress.removeListener(listener);
    };
  }, [progress]);

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.02,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [pulseAnim]);

  // Continuous spin
  useEffect(() => {
    if (!shouldSpin) return;
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(spinAnim, {
          toValue: 1,
          duration: 3000,
          useNativeDriver: true,
        }),
        Animated.timing(spinAnim, {
          toValue: 0,
          duration: 0,
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [shouldSpin]);

  // Cycle through colours when colorCycle is provided
  useEffect(() => {
    if (!colorCycle || colorCycle.length === 0) return;
    const id = setInterval(() => {
      setColorIndex((i) => (i + 1) % colorsRef.current.length);
    }, 1600);
    return () => clearInterval(id);
  }, [!!colorCycle]);

  const progressWidth = animatedProgress.interpolate({
    inputRange: [0, 100],
    outputRange: ['0%', '100%'],
  });

  const rotation = spinAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0deg', '360deg'],
  });

  return (
    <Animated.View
      style={[
        styles.container,
        {
          width: size,
          height: size,
          transform: [{ scale: pulseAnim }],
        },
      ]}
    >
      <Animated.View
        style={[
          styles.ringWrapper,
          {
            width: size,
            height: size,
            transform: shouldSpin ? [{ rotate: rotation }] : undefined,
          },
        ]}
      >
        {/* Outer ring with gradient – color / cycled color */}
        <LinearGradient
          colors={[effectiveColor + '50', effectiveColor + '25']}
          style={[
            styles.outerRing,
            {
              width: size,
              height: size,
              borderRadius: size / 2,
              borderWidth: strokeWidth,
              borderColor: effectiveColor,
            },
          ]}
        />

        {/* Progress fill ring */}
        <View
          style={[
            styles.progressRing,
            {
              width: size,
              height: size,
              borderRadius: size / 2,
              borderWidth: strokeWidth,
              borderColor: effectiveColor + '20',
            },
          ]}
        >
          <Animated.View
            style={[
              styles.progressFill,
              {
                width: progressWidth,
                height: '100%',
                backgroundColor: effectiveColor,
                opacity: 0.7,
              },
            ]}
          />
        </View>
      </Animated.View>

      {/* Center circle with content – no rotation */}
      <Animated.View
        style={[
          styles.centerCircle,
          {
            width: size - strokeWidth * 4,
            height: size - strokeWidth * 4,
            borderRadius: (size - strokeWidth * 4) / 2,
            transform: [{ scale: scaleAnim }],
          },
        ]}
      >
        <LinearGradient
          colors={['rgba(10,25,41,0.95)', 'rgba(10,25,41,0.98)']}
          style={StyleSheet.absoluteFill}
        />
        {showPercentage && (
          <View style={styles.percentageContainer}>
            <Text style={[styles.percentageText, percentageFontSize != null && { fontSize: percentageFontSize }]}>{displayProgress}</Text>
            <Text style={[styles.percentSymbol, percentageFontSize != null && { fontSize: Math.round(percentageFontSize * 0.6) }]}>%</Text>
          </View>
        )}
      </Animated.View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  ringWrapper: {
    position: 'absolute',
    justifyContent: 'center',
    alignItems: 'center',
  },
  outerRing: {
    position: 'absolute',
  },
  progressRing: {
    position: 'absolute',
    overflow: 'hidden',
  },
  progressFill: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    borderRadius: 60,
  },
  centerCircle: {
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    zIndex: 1,
  },
  percentageContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  percentageText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  percentSymbol: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
    marginLeft: 2,
  },
});
