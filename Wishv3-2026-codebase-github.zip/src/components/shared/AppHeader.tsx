import React, { useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Animated,
  Dimensions,
  Platform,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { AccountType, getAccountTheme } from '../../constants/accountThemes';
import { useAccountTheme } from './AccountThemeProvider';

const { width } = Dimensions.get('window');
const HEADER_MARGIN_H = 20;
const HEADER_RADIUS = 24;

// Header content heights – unified to match bookings header size app-wide
export const HEADER_CONTENT_HEIGHT = 44;
export const DASHBOARD_HEADER_CONTENT_HEIGHT = 44;
export const HEADER_HEIGHT = HEADER_CONTENT_HEIGHT + 16;
export const DASHBOARD_HEADER_HEIGHT = HEADER_HEIGHT;

// Standard spacing to position content directly beneath the header.
export const HEADER_CONTENT_OFFSET = 100;
export const DASHBOARD_HEADER_CONTENT_OFFSET = 100;

interface AppHeaderProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  rightAction?: React.ReactNode;
  variant?: 'default' | 'dashboard';
  scrollY?: Animated.Value;
  enableScrollAnimation?: boolean;
  accountType?: AccountType;
  showBack?: boolean;
  points?: number;
  businessName?: string;
  businessAddress?: string;
  businessRating?: number;
  primaryColor?: string;
}

export default function AppHeader({
  title,
  subtitle,
  onBack,
  rightAction,
  variant = 'default',
  scrollY,
  enableScrollAnimation = false,
  accountType,
  showBack = true,
  points,
  businessName,
  businessAddress,
  primaryColor,
}: AppHeaderProps) {
  const insets = useSafeAreaInsets();
  const defaultScrollY = useRef(new Animated.Value(0)).current;
  const scrollPosition = scrollY || defaultScrollY;

  const contextTheme = useAccountTheme();
  const theme = accountType
    ? getAccountTheme(accountType)
    : contextTheme.theme;
  const accentColor = primaryColor || theme.primary;

  const isDashboard = variant === 'dashboard';

  const headerOpacity = enableScrollAnimation
    ? scrollPosition.interpolate({
        inputRange: [0, 50, 100],
        outputRange: [1, 0.98, 0.96],
        extrapolate: 'clamp',
      })
    : 1;

  const handleBack = async () => {
    if (!router.canGoBack()) return;
    await hapticFeedback('light');
    if (onBack) {
      onBack();
    } else {
      router.back();
    }
  };

  const greeting =
    new Date().getHours() < 12
      ? 'Good morning'
      : new Date().getHours() < 17
        ? 'Good afternoon'
        : 'Good evening';

  const headerWidth = width - HEADER_MARGIN_H * 2;
  const borderRadius = isDashboard ? 28 : HEADER_RADIUS;
  const finalWidth = isDashboard ? width : headerWidth;
  const finalMarginTop = isDashboard ? insets.top : insets.top + 8;
  const finalMarginHorizontal = isDashboard ? 0 : HEADER_MARGIN_H;

  // Valeter-style header: glass gradient + border + glow (from Archive)
  const headerGradient: [string, string] = [
    'rgba(135,206,235,0.35)',
    'rgba(30,58,138,0.25)',
  ];
  const headerBorderColor = 'rgba(135,206,235,0.4)';
  const headerGlowColor = 'rgba(135,206,235,0.6)';
  const headerTextPrimary = '#F1F5F9';
  const headerTextSecondary = 'rgba(241,245,249,0.9)';
  const headerIconPrimary = '#FFFFFF';

  const headerContentHeight = HEADER_CONTENT_HEIGHT;

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <Animated.View
        style={[
          styles.wrapper,
          {
            opacity: headerOpacity,
          },
        ]}
        pointerEvents="box-none"
      >
        <View
          style={[
            styles.container,
            {
              width: finalWidth,
              borderRadius,
              marginTop: finalMarginTop,
              marginHorizontal: finalMarginHorizontal,
            },
          ]}
        >
          <BlurView
            intensity={Platform.OS === 'ios' ? 25 : 20}
            tint="dark"
            style={StyleSheet.absoluteFill}
          />
          <LinearGradient
            colors={headerGradient}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
          <View style={StyleSheet.absoluteFill} pointerEvents="none">
            <LinearGradient
              colors={['rgba(125,211,252,0.12)', 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 0, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
          </View>

          <View style={[styles.glassStroke, { borderColor: headerBorderColor, borderRadius }]} />
          <View style={[styles.glowLine, { backgroundColor: headerGlowColor, shadowColor: accentColor }]} />

          <View
            style={[
              styles.content,
              {
                paddingTop: 12,
                minHeight: headerContentHeight,
                paddingBottom: 16,
              },
            ]}
          >
            <View style={styles.leftSection}>
              {showBack ? (
                <TouchableOpacity
                  onPress={handleBack}
                  style={styles.backButton}
                  activeOpacity={0.7}
                  accessibilityLabel="Go back"
                  accessibilityRole="button"
                >
                  <Ionicons name="chevron-back" size={22} color={headerIconPrimary} />
                </TouchableOpacity>
              ) : (
                <View style={styles.backButtonPlaceholder} />
              )}
            </View>

            <View style={styles.centerSection}>
              <View style={styles.titleContainer}>
                {isDashboard && businessName ? (
                  <>
                    <Text style={[styles.headerGreeting, { color: headerTextSecondary }]}>
                      {greeting}
                    </Text>
                    <Text
                      style={[styles.headerName, { color: headerTextPrimary }]}
                      numberOfLines={1}
                      ellipsizeMode="tail"
                    >
                      {businessName}
                    </Text>
                    {businessAddress && (
                      <View style={styles.headerLocationRow}>
                        <Ionicons name="location-outline" size={12} color={headerIconPrimary} style={{ marginRight: 4 }} />
                        <Text
                          style={[styles.headerLocationText, { color: headerTextSecondary }]}
                          numberOfLines={1}
                          ellipsizeMode="tail"
                        >
                          {businessAddress}
                        </Text>
                      </View>
                    )}
                  </>
                ) : (
                  <>
                    <Text
                      style={[
                        styles.title,
                        { color: headerTextPrimary },
                      ]}
                      numberOfLines={1}
                      ellipsizeMode="tail"
                    >
                      {title || ' '}
                    </Text>
                    {subtitle != null && subtitle !== '' && (
                      <Text
                        style={[styles.subtitle, { color: headerTextSecondary }]}
                        numberOfLines={1}
                        ellipsizeMode="tail"
                      >
                        {subtitle}
                      </Text>
                    )}
                  </>
                )}
              </View>
            </View>

            <View style={styles.rightSection}>
              {isDashboard && points !== undefined && (
                <View style={styles.pointsBadge}>
                  <Ionicons name="trophy-outline" size={14} color="#FFD700" />
                  <Text style={styles.pointsText}>{points} pts</Text>
                </View>
              )}
              {rightAction && <View style={styles.rightActionContainer}>{rightAction}</View>}
            </View>
          </View>
        </View>
      </Animated.View>
    </>
  );
}

const styles = StyleSheet.create({
  wrapper: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    alignItems: 'center',
    pointerEvents: 'box-none',
  },
  container: {
    overflow: 'hidden',
    backgroundColor: 'transparent',
    shadowColor: 'rgba(15,23,42,0.4)',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.32,
    shadowRadius: 20,
    elevation: 24,
  },
  glassStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
  },
  glowLine: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 6,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    zIndex: 200,
    position: 'relative',
  },
  leftSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    zIndex: 200,
  },
  centerSection: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    minWidth: 0,
    paddingHorizontal: 8,
    zIndex: 200,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(148,163,184,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
    flexShrink: 0,
  },
  backButtonPlaceholder: {
    width: 40,
    height: 40,
    flexShrink: 0,
  },
  titleContainer: {
    width: '100%',
    gap: 2,
    minWidth: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  title: {
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
    textAlign: 'center',
    textShadowColor: 'rgba(0,0,0,0.5)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
    includeFontPadding: false,
    lineHeight: 22,
  },
  headerGreeting: {
    fontSize: 12,
    fontWeight: '600',
    letterSpacing: 0.2,
    marginBottom: 2,
    textAlign: 'center',
  },
  headerName: {
    fontSize: 22,
    fontWeight: '800',
    lineHeight: 26,
    letterSpacing: -0.3,
    marginBottom: 4,
    textAlign: 'center',
  },
  headerLocationRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerLocationText: {
    fontSize: 12,
    fontWeight: '500',
    flex: 1,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 13,
    fontWeight: '500',
    opacity: 0.9,
    marginTop: 1,
    textAlign: 'center',
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 2,
    includeFontPadding: false,
  },
  rightSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    justifyContent: 'flex-end',
    zIndex: 200,
    elevation: 12,
  },
  pointsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(255,215,0,0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,215,0,0.3)',
  },
  pointsText: {
    color: '#FFD700',
    fontSize: 12,
    fontWeight: '600',
  },
  rightActionContainer: {},
});
