# Asset usage

All image and video assets are defined in **`app/assets/assetExports.ts`**. Some are re-exported from **`src/constants/appAssets.ts`** for boot preloading and shared usage. Import from either file as indicated below.

---

## Source of truth

| Export | File | Description |
|--------|------|-------------|
| **assetExports.ts** | `app/assets/assetExports.ts` | Single source for all `require()` paths. |
| **appAssets.ts** | `src/constants/appAssets.ts` | Re-exports a subset for boot preload, `APP_LOGO_SOURCE`, `CAR_IMAGE`, `ONBOARDING_VIDEO`, and wash/valeter images. |

---

## Video

| Asset | File | Usage |
|-------|------|--------|
| **AUTH_VIDEO** | `authpages.mp4` | Login (`app/auth/login.tsx`), Signup (`app/auth/signup.tsx`) – background video. Re-exported in appAssets as `AUTH_VID` (internal). |
| **AUTH_PAGES_VIDEO** | `authpages.mp4` | Same file as AUTH_VIDEO; alternate export name for auth screens. |
| **ONBOARDING_VIDEO** | `onboarding.mp4` | Owner onboarding (`app/onboarding.tsx`), Customer onboarding (`app/owner/customer-onboarding.tsx`). Re-exported from `src/constants/appAssets.ts`. |

---

## Auth & app shell

| Asset | File | Usage |
|-------|------|--------|
| **ICON_AUTH** | `icon-auth.png` | Login, Signup (hero icon); `APP_LOGO_SOURCE` in appAssets; LoadingScreen; boot preload. **Expo config:** `app.config.ts` uses this for `icon`, `splash.image`, and Android `adaptiveIcon.foregroundImage`. |
| **ICON** | `icon.png` | Boot preload in appAssets. Exported for general app icon use. |
| **SPLASH_IMAGE** | `splash.png` | Exported in assetExports only. Not used in app.config (config uses `icon-auth.png` for splash). Available for custom splash or legacy use. |
| **ADAPTIVE_ICON** | `adaptive-icon.png` | Exported in assetExports only. Not used in app.config (Android uses `icon-auth.png`). Available for adaptive icon use. |

---

## Vehicle & map markers

| Asset | File | Usage |
|-------|------|--------|
| **CAR_IMAGE** | `car.png` | Customer/vehicle marker on maps and in booking flows. Used in: tracking, valeter-selection (mobile & eco), waiting-acceptance, location picker, create, schedule, vehicle step, confirm, payment, current-trip, chat, explore; dashboard map markers; detailing physical flow. Often imported via `appAssets.CAR_IMAGE`. Boot preload. |

---

## Wash hub & cleaning

| Asset | File | Usage |
|-------|------|--------|
| **CARWASH_IMAGE** | `carwash.png` | Hub hero/placeholders (explore, hub-details hero fallback); wash hub location/schedule/confirm; tracking job type; dashboard hub icon. Boot preload. |
| **CLEANING_IMAGE** | `carwash.png` | Same file as CARWASH_IMAGE. Used in track.tsx (marker fallback) and appAssets boot preload. |

---

## Wash tier cards (hub details & physical booking)

| Asset | File | Usage |
|-------|------|--------|
| **BRONZE_IMAGE** | `bronze.png` | Hub details – Bronze wash card. |
| **SILVER_IMAGE** | `silver.png` | Hub details – Silver wash card. |
| **GOLD_IMAGE** | `Gold.png` | Hub details – Gold wash card. |
| **PLATINUM_IMAGE** | `platinum.png` | Hub details – Platinum wash card. |
| **EMERALD_IMAGE** | `emerald.png` | Hub details – Emerald wash card. |

---

## Detailing

| Asset | File | Usage |
|-------|------|--------|
| **DETAILING_IMAGE** | `Detailing1.png` | Default detailing card image; boot preload in appAssets. |
| **DETAILING_HUB_IMAGE** | `Detailing1.png` | Same file. Detailing hub flows: physical location/schedule/confirm/service, tracking (detailing job type). |
| **CERAMIC_DETAIL_IMAGE** | `Ceramic.png` | Hub details – Ceramic Coating detailing card background. |
| **SOFTOP_DETAIL_IMAGE** | `Softop.png` | Hub details – Soft Top Restoration detailing card background. |
| **MOULD_DETAIL_IMAGE** | `mould.png` | Hub details – Mould Removal detailing card background. |
| **HEADLIGHT_DETAIL_IMAGE** | `headlight.png` | Hub details – Headlight Restoration detailing card background. |

---

## Valeter

| Asset | File | Usage |
|-------|------|--------|
| **VALETER_IMAGE** | `valeter.png` | Valeter avatar: valeter-selection (mobile & eco), chat, explore, track profile; dashboard profile modal and cards. |
| **VALETER_MAP_IMAGE** | `valeter-map.png` | Map marker for valeter position: tracking, valeter-selection, waiting-acceptance, track; dashboard map. |

---

## Boot preload

`src/constants/appAssets.ts` defines:

- **preloadAppLogo()** – preloads `ICON_AUTH` so splash and loading screens show it instantly.
- **preloadBootAssets()** – preloads: **ICON_AUTH**, **CARWASH_IMAGE**, **ICON**, **CAR_IMAGE**, **CLEANING_IMAGE**, **DETAILING_IMAGE**. Used by BootContext. Videos are not preloaded to avoid launch memory spikes.

---

## Import paths

- From app routes (e.g. `app/owner/...`):  
  `import { … } from '../assets/assetExports'` (adjust `../` by depth).
- From `src/`:  
  `import { … } from '../constants/appAssets'` for re-exported assets (logo, car, wash, valeter, ONBOARDING_VIDEO), or  
  `import { … } from '../app/assets/assetExports'` for the full list.
