# Upload to TestFlight

**Current iOS build number:** `27` (set in `app.config.ts` → `ios.buildNumber`). Each new EAS build will use this until you bump it.

## Prerequisites

- [Expo EAS CLI](https://docs.expo.dev/build/setup/): `npm install -g eas-cli`
- Log in: `eas login`
- Apple Developer account and app created in [App Store Connect](https://appstoreconnect.apple.com)

## Build 23 → TestFlight

To upload **build 27** to TestFlight, run the one-command build + submit below. The version in `app.config.ts` is already set to build number `27`.

## One-command build + submit (recommended)

**This both builds and submits to TestFlight.** EAS builds on the cloud, then automatically submits the IPA to App Store Connect when the build finishes.

```bash
npm run testflight
```

Or directly:

```bash
eas build --platform ios --profile preview --auto-submit
```

When prompted, sign in with your Apple ID and choose your app/team if needed. The build will be submitted to TestFlight automatically after it completes—no extra step required.

## Step by step

**1. Build only** (run on EAS; get a build URL when done):

```bash
npm run build:testflight
# or: eas build --platform ios --profile preview
```

**2. Submit the latest build to TestFlight** (after a build has completed):

```bash
npm run submit:ios
# or: eas submit --platform ios --latest --profile preview
```

To submit a specific build:

```bash
eas submit --platform ios --id <BUILD_ID> --profile preview
```

## First-time setup

- **Credentials**: On first iOS build, EAS will prompt to create or use existing distribution certificate and provisioning profile. Choose “Let EAS manage” for the simplest setup.
- **App Store Connect App ID**: If submit asks for it, find it in App Store Connect → Your App → App Information → **Apple ID** (numeric). You can add it to `eas.json` under `submit.preview.ios.ascAppId` to skip the prompt next time.

## After upload

1. In [App Store Connect](https://appstoreconnect.apple.com) → TestFlight, wait for the build to finish processing (often 5–15 minutes).
2. Complete any required compliance (e.g. export compliance, encryption).
3. Add internal or external testers and send the build for testing.
