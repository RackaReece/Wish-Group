/**
 * Explore: Available Now, Mobile Only, Top Rated, and Hub Only sections.
 * Each section is a horizontal scroll of cards. Radius filter limits results by distance.
 */
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Image,
  TextInput,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as Location from 'expo-location';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import AppHeader from '../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { getScrollContentPadding, HEADER_CONTENT_OFFSET } from '../../src/constants/layoutConstants';
import { colors } from '../../src/constants/colors';
import { formatDisplayName } from '../../src/utils/formatDisplayName';
import { ValeterStatsService } from '../../src/services/Valeterstatsservice';
import { BOOKING_CARD, HEADER_STYLE_CARD_GRADIENT, HEADER_STYLE_CARD_BORDER } from '../../src/constants/bookingCardTheme';
import { getActiveBookingForCustomer } from '../../src/utils/activeBookingGuard';
import EmptyState from '../../src/components/shared/EmptyState';
import { useThemeOptional } from '../../src/contexts/ThemeContext';
import { CARWASH_IMAGE, VALETER_IMAGE } from '../assets/assetExports';
import { distanceKm, distanceMiles, etaMinutes } from '../../src/utils/mapUtils';

const SKY = colors.SKY;
const BG = colors.BG ?? '#0A1929';
const TEXT_LIGHT = '#F9FAFB';
const TEXT_MUTED_LIGHT = '#94A3B8';
const TEXT_DARK = '#1E293B';
const TEXT_MUTED_DARK = '#64748B';
const CARD_BG_DARK = 'rgba(30,41,59,0.6)';
const CARD_BG_LIGHT = 'rgba(255,255,255,0.4)';
const CARD_BORDER_DARK = 'rgba(148,163,184,0.2)';
const CARD_BORDER_LIGHT = 'rgba(30,41,59,0.15)';

type TabId = 'hubs' | 'valeters' | 'favourites';

type RadiusOption = 5 | 10 | 20 | null; // null = Any

const DAY_NAMES = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

function formatOpeningHoursSummary(hours: { day_of_week: number; is_open: boolean; open_time?: string | null; close_time?: string | null }[]): string {
  if (!hours?.length) return '';
  const byDay = new Map(hours.map((h) => [h.day_of_week, h]));
  return DAY_NAMES.map((name, i) => {
    const h = byDay.get(i);
    if (!h) return `${name} —`;
    if (h.is_open && h.open_time && h.close_time) {
      return `${name} ${(h.open_time || '').slice(0, 5)}–${(h.close_time || '').slice(0, 5)}`;
    }
    return `${name} Closed`;
  }).join(' · ');
}

type HubRow = {
  id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  status?: string | null;
  eco_washing?: boolean | null;
  detailing_offered?: boolean | null;
  rating?: number | null;
  total_reviews?: number | null;
  base_price?: number | null;
  priority_price?: number | null;
  operating_hours?: unknown;
  services_offered?: string[] | null;
  phone?: string | null;
  openingHoursSummary?: string;
  /** When true, show "Mobile & static"; otherwise "Static only". Backend may add column later. */
  offers_mobile?: boolean | null;
  distanceMiles?: number | null;
  etaMins?: number | null;
};

type ValeterRow = {
  id: string;
  name: string;
  rating: number;
  totalJobs: number;
  distance: number | null; // miles
  etaMins: number | null;
  isOnline: boolean;
  profilePicture?: string | null;
  isFavourite: boolean;
  specializations?: string[];
  lastLat?: number | null;
  lastLng?: number | null;
};

type FavouriteRow = {
  id: string;
  valeter_id: string;
  valeter_profiles?: { user_id: string; full_name?: string | null; profile_photo_url?: string | null } | null;
  rating?: number;
  totalJobs?: number;
  specializations?: string[];
};

export default function Explore() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ q?: string }>();
  const { user } = useAuth();
  const themeContext = useThemeOptional();
  const isDark = themeContext?.isDark ?? true;
  const [tab, setTab] = useState<TabId>('hubs');
  const [radiusMiles, setRadiusMiles] = useState<RadiusOption>(null);
  const [hubs, setHubs] = useState<HubRow[]>([]);
  const [valeters, setValeters] = useState<ValeterRow[]>([]);
  const [favourites, setFavourites] = useState<FavouriteRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [favouriteIds, setFavouriteIds] = useState<Set<string>>(new Set());
  const [favouriteHubIds, setFavouriteHubIds] = useState<Set<string>>(new Set());
  const [favouriteHubs, setFavouriteHubs] = useState<HubRow[]>([]);
  const qParam = (() => {
    const p = params?.q;
    if (typeof p === 'string') return p;
    if (Array.isArray(p) && p[0]) return String(p[0]);
    return '';
  })();
  const [searchQuery, setSearchQuery] = useState(qParam);
  const [userCoords, setUserCoords] = useState<{ latitude: number; longitude: number } | null>(null);

  // When navigated from dashboard (or elsewhere) with ?q=..., show that search on Explore
  useEffect(() => {
    if (qParam) setSearchQuery(qParam);
  }, [qParam]);

  // Clear search when leaving Explore so nothing is saved when you come back
  useFocusEffect(
    useCallback(() => () => {
      setSearchQuery('');
    }, [])
  );

  const loadHubs = useCallback(async () => {
    const minimalSelect = 'id,name,address,latitude,longitude,status,eco_washing,detailing_offered,rating';
    const fullSelect = 'id,name,address,latitude,longitude,status,eco_washing,detailing_offered,rating,total_reviews,base_price,priority_price,operating_hours,services_offered,phone,is_active,offers_mobile';
    let rows: (HubRow & { is_active?: boolean })[] = [];
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select(fullSelect);
      if (error) throw error;
      rows = (data || []) as (HubRow & { is_active?: boolean })[];
      if (rows.length > 0 && rows[0].is_active !== undefined) {
        rows = rows.filter((h) => h.is_active !== false);
      }
    } catch {
      try {
        const { data, error } = await supabase
          .from('car_wash_locations')
          .select(minimalSelect);
        if (error) throw error;
        rows = (data || []) as (HubRow & { is_active?: boolean })[];
      } catch {
        setHubs([]);
        return;
      }
    }
    const ids = rows.map((r) => r.id);
    let hoursMap: Record<string, string> = {};
    if (ids.length > 0) {
      try {
        const { data: hoursData } = await supabase
          .from('location_opening_hours')
          .select('location_id,day_of_week,is_open,open_time,close_time')
          .in('location_id', ids);
        const byLocation: Record<string, typeof hoursData> = {};
        (hoursData || []).forEach((h: any) => {
          if (!byLocation[h.location_id]) byLocation[h.location_id] = [];
          byLocation[h.location_id].push(h);
        });
        ids.forEach((id) => {
          hoursMap[id] = formatOpeningHoursSummary(byLocation[id] || []);
        });
      } catch {
        // ignore
      }
    }
    setHubs(rows.map((h) => ({ ...h, openingHoursSummary: hoursMap[h.id] || '' })));
  }, []);

  const loadFavourites = useCallback(async (): Promise<FavouriteRow[]> => {
    if (!user?.id) return [];
    try {
      const { data, error } = await supabase
        .from('favourites')
        .select('id, valeter_id, valeter_profiles(user_id, full_name, profile_photo_url, specializations)')
        .eq('user_id', user.id);
      if (error && error.code !== 'PGRST116') throw error;
      const raw = (data || []) as (FavouriteRow & { valeter_profiles?: { specializations?: string[] } | null })[];
      const enriched: FavouriteRow[] = await Promise.all(
        raw.map(async (f) => {
          const specs = f.valeter_profiles?.specializations;
          const stats = await ValeterStatsService.getValeterStats(f.valeter_id).catch(() => null);
          return {
            ...f,
            rating: stats?.averageRating,
            totalJobs: stats?.totalJobs ?? 0,
            specializations: Array.isArray(specs) ? specs : [],
          };
        })
      );
      setFavourites(enriched);
      setFavouriteIds(new Set(enriched.map((f) => f.valeter_id)));
      return enriched;
    } catch {
      setFavourites([]);
      setFavouriteIds(new Set());
      return [];
    }
  }, [user?.id]);

  /** Loads saved wash hubs from hub_favourites (table: user_id, location_id). Create in Supabase if missing. */
  const loadHubFavourites = useCallback(async (): Promise<HubRow[]> => {
    if (!user?.id) return [];
    try {
      const { data: favData, error: favError } = await supabase
        .from('hub_favourites')
        .select('location_id')
        .eq('user_id', user.id);
      if (favError) {
        if (favError.code === '42P01') return [];
        throw favError;
      }
      const locationIds = (favData || []).map((r: { location_id: string }) => r.location_id).filter(Boolean);
      if (locationIds.length === 0) {
        setFavouriteHubIds(new Set());
        setFavouriteHubs([]);
        return [];
      }
      const fullSelect = 'id,name,address,latitude,longitude,status,eco_washing,detailing_offered,rating,total_reviews,base_price,priority_price,operating_hours,services_offered,phone,is_active,offers_mobile';
      const { data: hubData, error: hubError } = await supabase
        .from('car_wash_locations')
        .select(fullSelect)
        .in('id', locationIds);
      if (hubError) throw hubError;
      const rows = (hubData || []) as (HubRow & { is_active?: boolean })[];
      const ids = rows.map((r) => r.id);
      let hoursMap: Record<string, string> = {};
      if (ids.length > 0) {
        try {
          const { data: hoursData } = await supabase
            .from('location_opening_hours')
            .select('location_id,day_of_week,is_open,open_time,close_time')
            .in('location_id', ids);
          const byLocation: Record<string, typeof hoursData> = {};
          (hoursData || []).forEach((h: any) => {
            if (!byLocation[h.location_id]) byLocation[h.location_id] = [];
            byLocation[h.location_id].push(h);
          });
          ids.forEach((id) => {
            hoursMap[id] = formatOpeningHoursSummary(byLocation[id] || []);
          });
        } catch {
          // ignore
        }
      }
      const hubRows: HubRow[] = rows.map((h) => ({ ...h, openingHoursSummary: hoursMap[h.id] || '' }));
      setFavouriteHubIds(new Set(hubRows.map((h) => h.id)));
      setFavouriteHubs(hubRows);
      return hubRows;
    } catch {
      setFavouriteHubIds(new Set());
      setFavouriteHubs([]);
      return [];
    }
  }, [user?.id]);

  const loadValeters = useCallback(async (favIds?: Set<string>) => {
    const favSet = favIds ?? favouriteIds;
    try {
      // Load all valeters with location (not only online) so local valeters show by default; search filters by name
      const { data: presenceData, error: presenceError } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng');
      if (presenceError) throw presenceError;
      const withLocation = (presenceData || []).filter(
        (p: { last_lat?: unknown; last_lng?: unknown }) => p.last_lat != null && p.last_lng != null
      );
      if (!withLocation.length) {
        setValeters([]);
        return;
      }
      const userIds = withLocation.map((p: { user_id: string }) => p.user_id);
      let profilesData: any[] = [];
      const profileSelectFull = 'user_id, full_name, profile_photo_url, specializations';
      const profileSelectMinimal = 'user_id, full_name, profile_photo_url';
      const { data: profilesFull, error: profilesError } = await supabase
        .from('valeter_profiles')
        .select(profileSelectFull)
        .in('user_id', userIds);
      if (!profilesError && profilesFull) {
        profilesData = profilesFull;
      } else {
        try {
          const { data: profilesMin } = await supabase
            .from('valeter_profiles')
            .select(profileSelectMinimal)
            .in('user_id', userIds);
          profilesData = profilesMin || [];
        } catch {
          profilesData = [];
        }
      }
      const statsMap = new Map<string | null, { averageRating?: number; totalJobs?: number }>();
      await Promise.all(
        userIds.map(async (uid) => {
          const s = await ValeterStatsService.getValeterStats(uid).catch(() => null);
          if (s) statsMap.set(uid, { averageRating: s.averageRating, totalJobs: s.totalJobs ?? 0 });
        })
      );
      const list: ValeterRow[] = withLocation.map((p: any) => {
        const profile = profilesData.find((pr: any) => pr.user_id === p.user_id);
        const stats = statsMap.get(p.user_id);
        const specs = profile?.specializations;
        const lat = p.last_lat != null ? Number(p.last_lat) : null;
        const lng = p.last_lng != null ? Number(p.last_lng) : null;
        return {
          id: p.user_id,
          name: profile?.full_name || profile?.display_name || 'Valeter',
          rating: stats?.averageRating ?? 0,
          totalJobs: stats?.totalJobs ?? 0,
          distance: null,
          etaMins: null,
          isOnline: p.is_online,
          profilePicture: profile?.profile_photo_url,
          isFavourite: favSet.has(p.user_id),
          specializations: Array.isArray(specs) ? specs : [],
          lastLat: lat,
          lastLng: lng,
        };
      });
      setValeters(list);
    } catch {
      setValeters([]);
    }
  }, [favouriteIds]);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    await loadFavourites();
    await loadHubFavourites();
    await loadHubs();
    await loadValeters();
    setRefreshing(false);
  }, [loadFavourites, loadHubFavourites, loadHubs, loadValeters]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      const [favList] = await Promise.all([loadFavourites(), loadHubFavourites()]);
      if (cancelled) return;
      const favSet = new Set(favList.map((f) => f.valeter_id));
      await loadHubs();
      if (cancelled) return;
      await loadValeters(favSet);
      if (!cancelled) setLoading(false);
    })();
    return () => { cancelled = true; };
  }, [user?.id]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const { status } = await Location.getForegroundPermissionsAsync();
        if (status !== 'granted') {
          const { status: req } = await Location.requestForegroundPermissionsAsync();
          if (req !== 'granted' || cancelled) return;
        }
        const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
        if (!cancelled) setUserCoords({ latitude: loc.coords.latitude, longitude: loc.coords.longitude });
      } catch {
        // ignore
      }
    })();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!loading) loadValeters();
  }, [favouriteIds, loading]);

  const toggleFavourite = useCallback(
    async (valeterId: string) => {
      if (!user?.id) return;
      await hapticFeedback('light');
      const isFav = favouriteIds.has(valeterId);
      try {
        if (isFav) {
          await supabase.from('favourites').delete().eq('user_id', user.id).eq('valeter_id', valeterId);
          setFavouriteIds((prev) => {
            const next = new Set(prev);
            next.delete(valeterId);
            return next;
          });
          setFavourites((prev) => prev.filter((f) => f.valeter_id !== valeterId));
          setValeters((prev) => prev.map((v) => (v.id === valeterId ? { ...v, isFavourite: false } : v)));
        } else {
          await supabase.from('favourites').insert({ user_id: user.id, valeter_id: valeterId });
          setFavouriteIds((prev) => new Set([...prev, valeterId]));
          setFavourites((prev) => {
            const name = valeters.find((v) => v.id === valeterId)?.name;
            return [...prev, { id: '', valeter_id: valeterId, valeter_profiles: { user_id: valeterId, full_name: name || null, profile_photo_url: null } }];
          });
          setValeters((prev) => prev.map((v) => (v.id === valeterId ? { ...v, isFavourite: true } : v)));
        }
      } catch (e) {
        Alert.alert('Error', 'Could not update favourite.');
      }
    },
    [user?.id, favouriteIds, valeters]
  );

  const toggleHubFavourite = useCallback(
    async (hubId: string) => {
      if (!user?.id) return;
      await hapticFeedback('light');
      const isFav = favouriteHubIds.has(hubId);
      try {
        if (isFav) {
          await supabase.from('hub_favourites').delete().eq('user_id', user.id).eq('location_id', hubId);
          setFavouriteHubIds((prev) => {
            const next = new Set(prev);
            next.delete(hubId);
            return next;
          });
          setFavouriteHubs((prev) => prev.filter((h) => h.id !== hubId));
        } else {
          await supabase.from('hub_favourites').insert({ user_id: user.id, location_id: hubId });
          setFavouriteHubIds((prev) => new Set([...prev, hubId]));
          const hub = hubs.find((h) => h.id === hubId);
          if (hub) setFavouriteHubs((prev) => (prev.some((h) => h.id === hubId) ? prev : [...prev, hub]));
        }
      } catch (e) {
        Alert.alert('Error', 'Could not update favourite.');
      }
    },
    [user?.id, favouriteHubIds, hubs]
  );

  const handleHubPress = useCallback((hub: HubRow) => {
    hapticFeedback('light');
    router.push({
      pathname: '/owner/booking/physical/vehicle',
      params: { locationId: hub.id },
    });
  }, []);

  const handleBookWithValeter = useCallback(
    async (valeterId: string) => {
      await hapticFeedback('light');
      if (user?.id) {
        const active = await getActiveBookingForCustomer(user.id);
        if (active) {
          Alert.alert(
            'One booking at a time',
            'Finish or cancel your current booking first.',
            [
              { text: 'Cancel', style: 'cancel' },
              { text: 'View booking', onPress: () => router.push({ pathname: '/owner/booking/tracking', params: { bookingId: active.id } } as any) },
            ]
          );
          return;
        }
      }
      router.push({ pathname: '/owner/booking/create', params: { preferredValeterId: valeterId } } as any);
    },
    [user?.id]
  );

  const paddingBottom = getScrollContentPadding(insets, true).paddingBottom;

  const q = searchQuery.trim().toLowerCase();

  const valetersWithDistance = useMemo(() => {
    if (!userCoords) return valeters;
    return valeters.map((v) => {
      if (v.lastLat == null || v.lastLng == null) return v;
      const km = distanceKm(userCoords, { latitude: v.lastLat, longitude: v.lastLng });
      const miles = km * 0.621371;
      return { ...v, distance: miles, etaMins: etaMinutes(km) };
    });
  }, [valeters, userCoords]);

  const hubsWithDistance = useMemo(() => {
    if (!userCoords) return hubs;
    return hubs.map((h) => {
      if (h.latitude == null || h.longitude == null) return { ...h, distanceMiles: null as number | null, etaMins: null as number | null };
      const km = distanceKm(userCoords, { latitude: h.latitude, longitude: h.longitude });
      return { ...h, distanceMiles: km * 0.621371, etaMins: etaMinutes(km) };
    });
  }, [hubs, userCoords]);

  const filteredHubsBySearch = useMemo(() => {
    if (!q) return hubsWithDistance;
    return hubsWithDistance.filter(
      (h) =>
        (h.name && h.name.toLowerCase().includes(q)) ||
        (h.address && h.address.toLowerCase().includes(q))
    );
  }, [hubsWithDistance, q]);

  const filteredValetersBySearch = useMemo(() => {
    if (!q) return valetersWithDistance;
    return valetersWithDistance.filter((v) => (v.name && v.name.toLowerCase().includes(q)));
  }, [valetersWithDistance, q]);

  /** Hubs and valeters constrained by radius (when set) */
  const hubsInRadius = useMemo(() => {
    let list = filteredHubsBySearch;
    if (radiusMiles != null) {
      list = list.filter((h) => (h.distanceMiles ?? 999) <= radiusMiles);
    }
    return list;
  }, [filteredHubsBySearch, radiusMiles]);

  const valetersInRadius = useMemo(() => {
    let list = filteredValetersBySearch;
    if (radiusMiles != null) {
      list = list.filter((v) => (v.distance ?? 999) <= radiusMiles);
    }
    return list;
  }, [filteredValetersBySearch, radiusMiles]);

  const filteredFavouriteHubs = useMemo(() => {
    if (!q) return favouriteHubs;
    return favouriteHubs.filter(
      (h) =>
        (h.name && h.name.toLowerCase().includes(q)) ||
        (h.address && h.address.toLowerCase().includes(q))
    );
  }, [favouriteHubs, q]);
  const filteredFavourites = useMemo(() => {
    if (!q) return favourites;
    return favourites.filter((f) => {
      const name = f.valeter_profiles?.full_name || '';
      return name.toLowerCase().includes(q);
    });
  }, [favourites, q]);

  const themeStyles = {
    container: { backgroundColor: 'transparent' as const },
    card: {
      backgroundColor: isDark ? CARD_BG_DARK : 'rgba(74,122,142,0.42)',
      borderColor: isDark ? CARD_BORDER_DARK : HEADER_STYLE_CARD_BORDER,
    },
    cardTitle: { color: isDark ? TEXT_LIGHT : '#F0F9FF' },
    cardSubtitle: { color: isDark ? TEXT_MUTED_LIGHT : 'rgba(240,249,255,0.85)' },
    metaText: { color: isDark ? TEXT_MUTED_LIGHT : 'rgba(240,249,255,0.85)' },
    onlineBadge: { color: '#10B981' },
  };

  return (
    <SafeAreaView style={[styles.container, themeStyles.container]} edges={[]}>
      <AppHeader
        title="Explore"
        subtitle="Local hubs & valeters · Search to filter"
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
        accountType="customer"
      />

      <View style={[styles.contentBelowHeader, { paddingTop: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET }]}>
        <View style={styles.tabRow}>
          {(['hubs', 'valeters', 'favourites'] as TabId[]).map((t) => {
            const tabIcon: Record<TabId, string> = { hubs: 'business', valeters: 'car-sport', favourites: 'heart' };
            const tabLabelMap: Record<TabId, string> = { hubs: 'Wash Hubs', valeters: 'Valeters', favourites: 'Favourites' };
            const isActive = tab === t;
            return (
              <TouchableOpacity
                key={t}
                onPress={() => { hapticFeedback('light'); setTab(t); }}
                style={[styles.availabilityFilterPill, isActive && styles.availabilityFilterPillActive]}
                activeOpacity={0.8}
              >
                <Ionicons name={tabIcon[t] as any} size={16} color={isActive ? '#E0F2FE' : 'rgba(255,255,255,0.78)'} />
                <Text style={[styles.availabilityFilterText, isActive && styles.availabilityFilterTextActive]} numberOfLines={1}>
                  {tabLabelMap[t]}
                </Text>
              </TouchableOpacity>
            );
          })}
        </View>

        {/* Search bar – same style as dashboard */}
        <View style={styles.exploreSearchBarWrap}>
          <View style={styles.exploreSearchBarInner}>
            <Ionicons name="search" size={18} color="rgba(255,255,255,0.7)" />
            <TextInput
              style={styles.exploreSearchInput}
              placeholder="Search to filter by place or name..."
              placeholderTextColor="rgba(255,255,255,0.5)"
              value={searchQuery}
              onChangeText={setSearchQuery}
              returnKeyType="search"
              autoCapitalize="words"
              autoCorrect={true}
              spellCheck={true}
            />
            {searchQuery.length > 0 && (
              <TouchableOpacity onPress={() => setSearchQuery('')} hitSlop={8} style={styles.searchClear}>
                <Ionicons name="close-circle" size={18} color="rgba(255,255,255,0.5)" />
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Radius – same style as tabs above (hidden on Favourites tab) */}
        {tab !== 'favourites' && (
          <View style={styles.radiusRow}>
            <Text style={styles.radiusLabel}>Radius</Text>
            {([null, 5, 10, 20] as RadiusOption[]).map((r) => {
              const label = r == null ? 'Any' : `${r} mi`;
              const active = radiusMiles === r;
              return (
                <TouchableOpacity
                  key={label}
                  onPress={() => { hapticFeedback('light'); setRadiusMiles(r); }}
                  style={[styles.availabilityFilterPill, active && styles.availabilityFilterPillActive]}
                  activeOpacity={0.8}
                >
                  <Text style={[styles.availabilityFilterText, active && styles.availabilityFilterTextActive]}>{label}</Text>
                </TouchableOpacity>
              );
            })}
          </View>
        )}

        {/* Number of search results */}
        {!loading && (
          <View style={styles.resultsCountRow}>
            <Text style={styles.resultsCountText}>
              {tab === 'hubs' && `${hubsInRadius.length} ${hubsInRadius.length === 1 ? 'hub' : 'hubs'}`}
              {tab === 'valeters' && `${valetersInRadius.length} ${valetersInRadius.length === 1 ? 'valeter' : 'valeters'}`}
              {tab === 'favourites' && `${filteredFavouriteHubs.length + filteredFavourites.length} ${filteredFavouriteHubs.length + filteredFavourites.length === 1 ? 'favourite' : 'favourites'}`}
            </Text>
          </View>
        )}

      {loading ? (
        <View style={styles.centered}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      ) : (
        <ScrollView
          style={styles.scroll}
          contentContainerStyle={[styles.scrollContent, { paddingBottom }]}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={SKY} />}
          showsVerticalScrollIndicator={false}
        >
          {tab === 'hubs' && (
            <>
              {hubsInRadius.length === 0 ? (
                <EmptyState
                  icon="business-outline"
                  title={q ? 'No matching hubs' : 'No wash hubs'}
                  subtitle={q ? `No hubs or areas match "${searchQuery.trim()}"` : 'Try a larger radius or search'}
                  iconColor={SKY}
                  style={styles.empty}
                />
              ) : (
                hubsInRadius.map((hub) => {
                  const rating = hub.rating != null ? Number(hub.rating) : null;
                  const reviewCount = hub.total_reviews != null ? Number(hub.total_reviews) : null;
                  const baseNum = hub.base_price != null ? Number(hub.base_price) : null;
                  const priorityNum = hub.priority_price != null ? Number(hub.priority_price) : null;
                  const fromPrice = baseNum ?? priorityNum;
                  const services = Array.isArray(hub.services_offered) ? hub.services_offered : [];
                  const isOpen = (hub.status || '').toLowerCase() === 'open';
                  const distMiles = hub.distanceMiles != null ? hub.distanceMiles : null;
                  const etaM = hub.etaMins != null ? hub.etaMins : null;
                  return (
                    <View key={hub.id} style={[styles.uberCard, themeStyles.card]}>
                      <View style={styles.uberCardPressable}>
                        <View style={styles.hubHero}>
                          <View style={styles.typeBadgeHub}>
                            <Ionicons name="business" size={12} color="#fff" />
                            <Text style={styles.typeBadgeText}>Hub</Text>
                          </View>
                          <LinearGradient
                            colors={isDark ? [SKY + '40', SKY + '15'] : [SKY + '50', SKY + '25']}
                            style={StyleSheet.absoluteFill}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 1 }}
                          />
                          <Image source={CARWASH_IMAGE} style={styles.hubHeroImage} resizeMode="contain" />
                          {rating != null && (
                            <View style={styles.ratingPill}>
                              <Ionicons name="star" size={12} color="#FBBF24" />
                              <Text style={styles.ratingPillText}>{rating.toFixed(1)}</Text>
                              {reviewCount != null && reviewCount > 0 && (
                                <Text style={[styles.ratingPillSub, themeStyles.cardSubtitle]}> ({reviewCount})</Text>
                              )}
                            </View>
                          )}
                          <View style={[styles.statusBadge, isOpen ? styles.statusOpen : styles.statusClosed]}>
                            <Text style={styles.statusBadgeText}>{isOpen ? 'Open' : 'Closed'}</Text>
                          </View>
                        </View>
                        <View style={styles.uberCardBody}>
                          <View style={styles.hubNameRow}>
                            <Text style={[styles.uberCardTitle, themeStyles.cardTitle]} numberOfLines={1}>{hub.name}</Text>
                            <TouchableOpacity onPress={() => toggleHubFavourite(hub.id)} hitSlop={8} style={styles.heartBtn}>
                              <Ionicons name={favouriteHubIds.has(hub.id) ? 'heart' : 'heart-outline'} size={22} color={favouriteHubIds.has(hub.id) ? '#EF4444' : (isDark ? SKY : TEXT_DARK)} />
                            </TouchableOpacity>
                          </View>
                          {(distMiles != null || etaM != null) && (
                            <View style={styles.distanceEtaRow}>
                              {distMiles != null && (
                                <Text style={[styles.distanceEtaText, themeStyles.metaText]}>📍 {distMiles.toFixed(1)} miles away</Text>
                              )}
                              {etaM != null && (
                                <Text style={[styles.distanceEtaText, themeStyles.metaText]}>⏱ Can arrive in ~{etaM} mins</Text>
                              )}
                            </View>
                          )}
                          {hub.address ? (
                            <View style={styles.addressRow}>
                              <Ionicons name="location-outline" size={14} color={isDark ? TEXT_MUTED_LIGHT : 'rgba(240,249,255,0.8)'} />
                              <Text style={[styles.addressText, themeStyles.cardSubtitle]} numberOfLines={2}>{hub.address}</Text>
                            </View>
                          ) : null}
                          {(fromPrice != null || true) && (
                            <View style={styles.metaRowWrap}>
                              {fromPrice != null && (
                                <Text style={[styles.fromPriceText, themeStyles.cardSubtitle]}>From £{fromPrice.toFixed(0)}</Text>
                              )}
                              <View style={styles.hoursRow}>
                                <Ionicons name="time-outline" size={12} color={isDark ? TEXT_MUTED_LIGHT : 'rgba(240,249,255,0.8)'} />
                                <Text style={[styles.hoursText, themeStyles.cardSubtitle]} numberOfLines={1}>Hours vary</Text>
                              </View>
                            </View>
                          )}
                          {services.length > 0 && (
                            <View style={styles.servicePreviewChipsRow}>
                              <Text style={[styles.servicePreviewLabel, themeStyles.cardSubtitle]}>Services: </Text>
                              <View style={styles.chipRow}>
                                {services.slice(0, 4).map((s) => (
                                  <View key={s} style={[styles.serviceChip, isDark ? styles.serviceChipDark : styles.serviceChipLight]}>
                                    <Text style={[styles.serviceChipText, themeStyles.cardSubtitle]} numberOfLines={1}>{s}</Text>
                                  </View>
                                ))}
                              </View>
                            </View>
                          )}
                          <View style={styles.hubCardFooter}>
                            <TouchableOpacity
                              style={styles.hubFooterLeft}
                              onPress={() => { hapticFeedback('light'); router.push({ pathname: '/owner/hub-details', params: { locationId: hub.id } }); }}
                              activeOpacity={0.8}
                            >
                              <Text style={[styles.viewDetailsText, { color: SKY }]}>Services</Text>
                              <Ionicons name="information-circle-outline" size={20} color={SKY} />
                            </TouchableOpacity>
                            <TouchableOpacity
                              style={[styles.hubBookBtn, { backgroundColor: SKY }]}
                              onPress={() => handleHubPress(hub)}
                              activeOpacity={0.9}
                            >
                              <Text style={styles.bookChipText}>Book</Text>
                              <Ionicons name="arrow-forward" size={14} color="#fff" />
                            </TouchableOpacity>
                          </View>
                        </View>
                      </View>
                    </View>
                  );
                })
              )}
            </>
          )}

          {tab === 'valeters' && (
            <>
              {valetersInRadius.length === 0 ? (
                <EmptyState
                  icon="car-outline"
                  title={q ? 'No matching valeters' : 'No valeters'}
                  subtitle={q ? `No valeters match "${searchQuery.trim()}"` : 'Try a larger radius'}
                  iconColor={SKY}
                  style={styles.empty}
                />
              ) : (
                valetersInRadius.map((v) => {
                  const inactiveHeartColor = isDark ? SKY : TEXT_DARK;
                  const heartColor = v.isFavourite ? '#EF4444' : inactiveHeartColor;
                  return (
                    <View key={v.id} style={[styles.uberValeterCard, themeStyles.card]}>
                      <View style={styles.valeterCardMain}>
                        <View style={styles.valeterAvatarWrap}>
                          <View style={styles.typeBadgeValeter}>
                            <Ionicons name="car-sport" size={10} color="#fff" />
                            <Text style={styles.typeBadgeTextSmall}>Mobile</Text>
                          </View>
                          {v.profilePicture ? (
                            <Image source={{ uri: v.profilePicture }} style={styles.valeterAvatar} resizeMode="cover" />
                          ) : (
                            <View style={styles.valeterAvatarPlaceholder}>
                              <Image source={VALETER_IMAGE} style={styles.valeterAvatar} resizeMode="cover" />
                            </View>
                          )}
                          {v.isOnline && <View style={styles.onlineDot} />}
                        </View>
                        <View style={styles.valeterCardBody}>
                          <View style={styles.valeterNameRow}>
                            <Text style={[styles.uberCardTitle, themeStyles.cardTitle]} numberOfLines={1}>{formatDisplayName(v.name)}</Text>
                            <TouchableOpacity onPress={() => toggleFavourite(v.id)} hitSlop={8} style={styles.heartBtn}>
                              <Ionicons name={v.isFavourite ? 'heart' : 'heart-outline'} size={22} color={heartColor} />
                            </TouchableOpacity>
                          </View>
                          <View style={styles.valeterStatsRow}>
                            <View style={styles.statItem}>
                              <Ionicons name="star" size={12} color="#FBBF24" />
                              <Text style={[styles.statItemText, themeStyles.metaText]}>{v.rating > 0 ? v.rating.toFixed(1) : 'New'}</Text>
                            </View>
                            <View style={styles.statItem}>
                              <Ionicons name="checkmark-done-outline" size={12} color={isDark ? TEXT_MUTED_LIGHT : TEXT_MUTED_DARK} />
                              <Text style={[styles.statItemText, themeStyles.metaText]}>{v.totalJobs} jobs</Text>
                            </View>
                            {v.isOnline && (
                              <View style={styles.availabilityBadge}>
                                <Text style={styles.availabilityBadgeText}>Available</Text>
                              </View>
                            )}
                          </View>
                          {(v.distance != null || v.etaMins != null) && (
                            <View style={styles.distanceEtaRow}>
                              {v.distance != null && <Text style={[styles.distanceEtaText, themeStyles.metaText]}>📍 {v.distance.toFixed(1)} mi</Text>}
                              {v.etaMins != null && <Text style={[styles.distanceEtaText, themeStyles.metaText]}>~{v.etaMins} min</Text>}
                            </View>
                          )}
                          <View style={styles.valeterCardFooter}>
                            <TouchableOpacity
                              onPress={() => { hapticFeedback('light'); router.push({ pathname: '/owner/valeter-details', params: { valeterId: v.id } }); }}
                              style={styles.viewDetailsBtn}
                              activeOpacity={0.8}
                            >
                              <Text style={[styles.viewDetailsText, { color: SKY }]}>View details</Text>
                              <Ionicons name="chevron-forward" size={16} color={SKY} />
                            </TouchableOpacity>
                            <TouchableOpacity onPress={() => handleBookWithValeter(v.id)} style={[styles.bookChip, styles.valeterBookBtn]} activeOpacity={0.8}>
                              <Text style={styles.bookChipText}>Book now</Text>
                              <Ionicons name="arrow-forward" size={14} color="#fff" />
                            </TouchableOpacity>
                          </View>
                        </View>
                      </View>
                    </View>
                  );
                })
              )}
            </>
          )}

          {tab === 'favourites' && (
            <>
              {filteredFavouriteHubs.length === 0 && filteredFavourites.length === 0 ? (
                <EmptyState
                  icon="heart-outline"
                  title="No favourites yet"
                  subtitle="Save hubs and valeters from the other tabs"
                  iconColor={SKY}
                  style={styles.empty}
                />
              ) : (
                <>
                  {filteredFavouriteHubs.map((hub) => {
                    const rating = hub.rating != null ? Number(hub.rating) : null;
                    const baseNum = hub.base_price != null ? Number(hub.base_price) : null;
                    const priorityNum = hub.priority_price != null ? Number(hub.priority_price) : null;
                    const fromPrice = baseNum ?? priorityNum;
                    const isOpen = (hub.status || '').toLowerCase() === 'open';
                    const distMiles = hub.distanceMiles != null ? hub.distanceMiles : null;
                    const etaM = hub.etaMins != null ? hub.etaMins : null;
                    return (
                      <View key={hub.id} style={[styles.uberCard, themeStyles.card]}>
                        <View style={styles.uberCardPressable}>
                          <View style={styles.hubHero}>
                            <View style={styles.typeBadgeHub}>
                              <Ionicons name="business" size={12} color="#fff" />
                              <Text style={styles.typeBadgeText}>Hub</Text>
                            </View>
                            <LinearGradient
                              colors={isDark ? [SKY + '40', SKY + '15'] : [SKY + '50', SKY + '25']}
                              style={StyleSheet.absoluteFill}
                              start={{ x: 0, y: 0 }}
                              end={{ x: 1, y: 1 }}
                            />
                            <Image source={CARWASH_IMAGE} style={styles.hubHeroImage} resizeMode="contain" />
                            {rating != null && (
                              <View style={styles.ratingPill}>
                                <Ionicons name="star" size={12} color="#FBBF24" />
                                <Text style={styles.ratingPillText}>{rating.toFixed(1)}</Text>
                              </View>
                            )}
                            <View style={[styles.statusBadge, isOpen ? styles.statusOpen : styles.statusClosed]}>
                              <Text style={styles.statusBadgeText}>{isOpen ? 'Open' : 'Closed'}</Text>
                            </View>
                          </View>
                          <View style={styles.uberCardBody}>
                            <View style={styles.hubNameRow}>
                              <Text style={[styles.uberCardTitle, themeStyles.cardTitle]} numberOfLines={1}>{hub.name}</Text>
                              <TouchableOpacity onPress={() => toggleHubFavourite(hub.id)} hitSlop={8} style={styles.heartBtn}>
                                <Ionicons name="heart" size={22} color="#EF4444" />
                              </TouchableOpacity>
                            </View>
                            {(distMiles != null || etaM != null) && (
                              <View style={styles.distanceEtaRow}>
                                {distMiles != null && <Text style={[styles.distanceEtaText, themeStyles.metaText]}>📍 {distMiles.toFixed(1)} mi</Text>}
                                {etaM != null && <Text style={[styles.distanceEtaText, themeStyles.metaText]}>~{etaM} min</Text>}
                              </View>
                            )}
                            {hub.address ? (
                              <Text style={[styles.addressText, themeStyles.cardSubtitle]} numberOfLines={1}>{hub.address}</Text>
                            ) : null}
                            {fromPrice != null && (
                              <Text style={[styles.fromPriceText, themeStyles.cardSubtitle]}>From £{fromPrice.toFixed(0)}</Text>
                            )}
                            <TouchableOpacity style={[styles.hubBookBtn, { backgroundColor: SKY }]} onPress={() => handleHubPress(hub)} activeOpacity={0.9}>
                              <Text style={styles.bookChipText}>Book</Text>
                              <Ionicons name="arrow-forward" size={14} color="#fff" />
                            </TouchableOpacity>
                          </View>
                        </View>
                      </View>
                    );
                  })}
                  {filteredFavourites.map((f) => {
                    const vId = f.valeter_id;
                    const name = f.valeter_profiles?.full_name ?? 'Valeter';
                    const rating = f.rating ?? 0;
                    const totalJobs = f.totalJobs ?? 0;
                    return (
                      <View key={f.id} style={[styles.uberValeterCard, themeStyles.card]}>
                        <View style={styles.valeterCardMain}>
                          <View style={styles.valeterAvatarWrap}>
                            <View style={styles.typeBadgeValeter}>
                              <Ionicons name="car-sport" size={10} color="#fff" />
                              <Text style={styles.typeBadgeTextSmall}>Mobile</Text>
                            </View>
                            {f.valeter_profiles?.profile_photo_url ? (
                              <Image source={{ uri: f.valeter_profiles.profile_photo_url }} style={styles.valeterAvatar} resizeMode="cover" />
                            ) : (
                              <View style={styles.valeterAvatarPlaceholder}>
                                <Image source={VALETER_IMAGE} style={styles.valeterAvatar} resizeMode="cover" />
                              </View>
                            )}
                          </View>
                          <View style={styles.valeterCardBody}>
                            <View style={styles.valeterNameRow}>
                              <Text style={[styles.uberCardTitle, themeStyles.cardTitle]} numberOfLines={1}>{formatDisplayName(name)}</Text>
                              <TouchableOpacity onPress={() => toggleFavourite(vId)} hitSlop={8} style={styles.heartBtn}>
                                <Ionicons name="heart" size={22} color="#EF4444" />
                              </TouchableOpacity>
                            </View>
                            <View style={styles.valeterStatsRow}>
                              <View style={styles.statItem}>
                                <Ionicons name="star" size={12} color="#FBBF24" />
                                <Text style={[styles.statItemText, themeStyles.metaText]}>{rating > 0 ? rating.toFixed(1) : 'New'}</Text>
                              </View>
                              <View style={styles.statItem}>
                                <Ionicons name="checkmark-done-outline" size={12} color={isDark ? TEXT_MUTED_LIGHT : TEXT_MUTED_DARK} />
                                <Text style={[styles.statItemText, themeStyles.metaText]}>{totalJobs} jobs</Text>
                              </View>
                            </View>
                            <View style={styles.valeterCardFooter}>
                              <TouchableOpacity
                                onPress={() => { hapticFeedback('light'); router.push({ pathname: '/owner/valeter-details', params: { valeterId: vId } }); }}
                                style={styles.viewDetailsBtn}
                                activeOpacity={0.8}
                              >
                                <Text style={[styles.viewDetailsText, { color: SKY }]}>View details</Text>
                                <Ionicons name="chevron-forward" size={16} color={SKY} />
                              </TouchableOpacity>
                              <TouchableOpacity onPress={() => handleBookWithValeter(vId)} style={[styles.bookChip, styles.valeterBookBtn]} activeOpacity={0.8}>
                                <Text style={styles.bookChipText}>Book now</Text>
                                <Ionicons name="arrow-forward" size={14} color="#fff" />
                              </TouchableOpacity>
                            </View>
                          </View>
                        </View>
                      </View>
                    );
                  })}
                </>
              )}
            </>
          )}

        </ScrollView>
      )}

      </View>
    </SafeAreaView>
  );
}

const CARD_RADIUS = 16;

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  contentBelowHeader: { flex: 1 },
  tabRow: {
    flexDirection: 'row',
    gap: 8,
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  exploreSearchBarWrap: {
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderRadius: 24,
    padding: 4,
    marginHorizontal: 16,
    marginBottom: 12,
  },
  exploreSearchBarInner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 20,
  },
  exploreSearchInput: {
    flex: 1,
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    fontWeight: '600',
    paddingVertical: 0,
  },
  searchWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 16,
    marginBottom: 12,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 12,
    gap: 10,
  },
  searchWrapDark: {
    backgroundColor: 'rgba(30,41,59,0.8)',
    borderWidth: 1,
    borderColor: CARD_BORDER_DARK,
  },
  searchWrapLight: {
    backgroundColor: 'rgba(255,255,255,0.5)',
    borderWidth: 1,
    borderColor: CARD_BORDER_LIGHT,
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
    paddingVertical: 4,
  },
  searchClear: {
    padding: 4,
  },
  radiusRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 16,
    marginBottom: 16,
  },
  radiusLabel: {
    fontSize: 13,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.78)',
    marginRight: 0,
    minWidth: 44,
  },
  resultsCountRow: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginBottom: 4,
  },
  resultsCountText: {
    fontSize: 13,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.7)',
  },
  horizontalScrollContent: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    paddingRight: 32,
  },
  horizontalEmpty: {
    minWidth: 280,
    paddingVertical: 24,
  },
  horizontalCard: {
    width: 280,
    marginRight: 14,
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
    padding: 12,
    borderWidth: 1,
  },
  horizontalHubCard: {
    padding: 0,
    overflow: 'hidden',
  },
  hubHeroCompact: {
    height: 80,
  },
  availabilityFilterPill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 10,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  availabilityFilterPillActive: {
    borderColor: 'rgba(135,206,235,0.45)',
    backgroundColor: 'rgba(135,206,235,0.22)',
  },
  availabilityFilterText: {
    color: 'rgba(255,255,255,0.78)',
    fontSize: 12,
    fontWeight: '700',
  },
  availabilityFilterTextActive: {
    color: '#E0F2FE',
  },
  centered: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  scroll: { flex: 1 },
  scrollContent: { paddingHorizontal: 16, paddingTop: 8 },
  empty: { minHeight: 220 },
  card: {
    backgroundColor: 'rgba(30,41,59,0.6)',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  cardTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '700', marginBottom: 2 },
  cardSubtitle: { color: '#94A3B8', fontSize: 13 },
  metaText: { color: '#94A3B8', fontSize: 12 },
  heartBtn: { padding: 4 },
  bookChip: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
    backgroundColor: SKY + '20',
    borderWidth: 1,
    borderColor: SKY + '40',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  bookChipPrimary: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
    backgroundColor: SKY,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  bookChipFull: { alignSelf: 'flex-start', marginTop: 8 },
  bookChipText: { color: '#fff', fontSize: 13, fontWeight: '800' },
  // Uber-style hub card
  uberCard: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
    marginBottom: 14,
    borderWidth: 1,
  },
  uberCardPressable: { flex: 1 },
  hubHero: {
    height: 120,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  typeBadgeHub: {
    position: 'absolute',
    top: 8,
    left: 8,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    zIndex: 1,
  },
  typeBadgeText: {
    color: '#fff',
    fontSize: 11,
    fontWeight: '700',
  },
  hubHeroImage: { width: 72, height: 72, opacity: 0.9 },
  ratingPill: {
    position: 'absolute',
    bottom: 8,
    left: 12,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    gap: 4,
  },
  ratingPillText: { color: '#FBBF24', fontSize: 13, fontWeight: '700' },
  ratingPillSub: { fontSize: 12 },
  statusBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  statusOpen: { backgroundColor: '#10B981' },
  statusClosed: { backgroundColor: '#6B7280' },
  statusBadgeText: { color: '#fff', fontSize: 11, fontWeight: '700' },
  uberCardBody: { padding: 14 },
  hubNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
    gap: 8,
  },
  uberCardTitle: { fontSize: 17, fontWeight: '800', flex: 1 },
  distanceEtaRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    gap: 10,
    marginBottom: 6,
  },
  distanceEtaText: {
    fontSize: 12,
  },
  servicePreviewChipsRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    gap: 6,
    marginBottom: 8,
  },
  servicePreviewLabel: {
    fontSize: 12,
    marginRight: 2,
  },
  savedBadgeHub: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#EF4444',
    justifyContent: 'center',
    alignItems: 'center',
  },
  addressRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 6, marginBottom: 6 },
  addressText: { flex: 1, fontSize: 13 },
  metaRowWrap: { flexDirection: 'row', flexWrap: 'wrap', alignItems: 'center', gap: 12, marginBottom: 8 },
  fromPriceText: { fontSize: 13, fontWeight: '600' },
  hoursRow: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  hoursText: { fontSize: 12 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap', gap: 6, marginBottom: 8 },
  serviceChip: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  serviceChipDark: { backgroundColor: 'rgba(148,163,184,0.2)' },
  serviceChipLight: { backgroundColor: 'rgba(30,41,59,0.1)' },
  serviceChipText: { fontSize: 11 },
  hubCardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 10,
    gap: 12,
  },
  hubFooterLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  hubBookBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
  },
  viewDetailsText: { fontSize: 13, fontWeight: '700' },
  viewDetailsBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  valeterCardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 10,
    gap: 12,
  },
  valeterViewDetailsWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  valeterBookBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
  },
  // Uber-style valeter card
  uberValeterCard: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
    marginBottom: 14,
    padding: 14,
    borderWidth: 1,
  },
  valeterCardMain: { flexDirection: 'row' },
  typeBadgeValeter: {
    position: 'absolute',
    top: -2,
    left: -2,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 2,
    backgroundColor: SKY,
    paddingHorizontal: 5,
    paddingVertical: 2,
    borderRadius: 6,
    zIndex: 1,
  },
  typeBadgeTextSmall: {
    color: '#fff',
    fontSize: 9,
    fontWeight: '700',
  },
  valeterAvatarWrap: {
    width: 64,
    height: 64,
    borderRadius: 32,
    marginRight: 12,
    position: 'relative',
  },
  valeterAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
  },
  valeterAvatarPlaceholder: {
    width: 64,
    height: 64,
    borderRadius: 32,
    overflow: 'hidden',
    backgroundColor: SKY + '25',
  },
  onlineDot: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#10B981',
    borderWidth: 2,
    borderColor: 'rgba(30,41,59,0.8)',
  },
  savedBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#EF4444',
    justifyContent: 'center',
    alignItems: 'center',
  },
  valeterCardBody: { flex: 1, minWidth: 0 },
  valeterNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 2,
  },
  valeterStatsRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 4 },
  statItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  statItemText: { fontSize: 12 },
  availabilityBadge: {
    backgroundColor: '#10B98120',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
    marginLeft: 4,
  },
  availabilityBadgeText: { color: '#10B981', fontSize: 11, fontWeight: '700' },
  savedLabel: { fontSize: 12, marginTop: 0 },
});
