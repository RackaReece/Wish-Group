import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import AppHeader from '../../../src/components/shared/AppHeader';
import LoadingScreen from '../../../src/components/LoadingScreen';
import EmptyState from '../../../src/components/shared/EmptyState';
import GlassCard from '@/components/booking/GlassCard';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { getScrollContentPadding } from '../../../src/constants/layoutConstants';
import { CONTENT_PADDING_H } from '../../../src/constants/pageStyles';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';
import { formatDisplayName } from '../../../src/utils/formatDisplayName';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function Favourites() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [favourites, setFavourites] = useState<any[]>([]);

  const loadFavourites = async () => {
    if (!user?.id) return;
    try {
      // Load from favourites table (when implemented)
      // Expected schema: favourites table with user_id and valeter_id columns
      const { data, error } = await supabase
        .from('favourites')
        .select('*, valeter_profiles(*)')
        .eq('user_id', user.id);
      
      if (error && error.code !== 'PGRST116') { // PGRST116 = table doesn't exist
        throw error;
      }
      
      setFavourites(data || []);
    } catch {
      // Favourites feature may not be implemented yet; show empty list
      setFavourites([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadFavourites();
  }, [user?.id]);

  const onRefresh = () => {
    setRefreshing(true);
    loadFavourites();
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LoadingScreen />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      <AppHeader
        title="Favourites"
        variant="dashboard"
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
        accountType="customer"
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingHorizontal: CONTENT_PADDING_H, ...getScrollContentPadding(insets, true) },
        ]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {favourites.length === 0 ? (
          <EmptyState
            icon="star-outline"
            title="No Favourites Yet"
            subtitle="Save your favourite valeters for quick booking"
            actionLabel="Book a Service"
            onAction={() => router.push('/owner/booking')}
            iconColor={SKY}
            style={styles.emptyState}
          />
        ) : (
          favourites.map((valeter) => (
            <GlassCard key={valeter.id} style={styles.valeterCard} accountType="customer">
              <View style={styles.valeterRow}>
                <View style={styles.valeterIconWrapper}>
                  <Ionicons name="person" size={24} color={SKY} />
                </View>
                <View style={styles.valeterContent}>
                  <Text style={styles.valeterName}>{formatDisplayName(valeter.name)}</Text>
                  <View style={styles.valeterMeta}>
                    <Ionicons name="star" size={14} color="#F59E0B" />
                    <Text style={styles.valeterRating}>{valeter.rating?.toFixed(1) || '4.5'}</Text>
                    {valeter.distance != null && (
                      <>
                        <Text style={styles.metaSeparator}>•</Text>
                        <Text style={styles.valeterDistance}>{(valeter.distance * 0.621371).toFixed(1)} mi</Text>
                      </>
                    )}
                  </View>
                </View>
                <TouchableOpacity style={styles.bookButton}>
                  <Ionicons name="calendar" size={20} color={SKY} />
                </TouchableOpacity>
              </View>
            </GlassCard>
          ))
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  scrollView: { flex: 1 },
  scrollContent: {},
  emptyState: { minHeight: 280 },
  valeterCard: { marginBottom: 12, padding: 16, borderRadius: 16 },
  valeterRow: { flexDirection: 'row', alignItems: 'center' },
  valeterIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  valeterContent: {
    flex: 1,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '700',
    marginBottom: 6,
  },
  valeterMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  valeterRating: {
    color: '#F59E0B',
    fontSize: 13,
    fontWeight: '600',
  },
  metaSeparator: {
    color: '#87CEEB',
    fontSize: 13,
  },
  valeterDistance: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '600',
  },
  bookButton: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
});



