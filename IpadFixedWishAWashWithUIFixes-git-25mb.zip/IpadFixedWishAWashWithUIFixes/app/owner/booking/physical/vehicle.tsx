import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Image,
  Modal,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../../src/lib/supabase';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { MAP_LOCKED_DARK, RECENTER_BUTTON_RIGHT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '../../../../src/constants/mapConstants';
import InfoIconButton from '../../../../src/components/shared/InfoIconButton';
import { colors } from '../../../../src/constants/colors';
import { BOOKING_CARD, CURVED_BOOKING_CARD } from '../../../../src/constants/bookingCardTheme';
import UnifiedBookingCard from '../../../../src/components/booking/UnifiedBookingCard';
import { VehicleInfoOverlay } from '../../../../src/components/booking/VehicleInfoOverlay';
import { fetchVehicleStats } from '../../../../src/utils/vehicleStats';
import { DEFAULT_MAP_REGION } from '../../../../src/constants/mapConstants';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../components/NavigationTab';
import { CAR_IMAGE } from '../../../assets/assetExports';
import { HEADER_BORDER_RADIUS } from '../../../../src/constants/layoutConstants';

const { width } = Dimensions.get('window');
const CARD_WIDTH = BOOKING_CARD.CARD_WIDTH;
const SKY = colors.SKY;

// Uber-style dark map theme (same as book-a-wash flow)
const uberDarkMapStyle = [
  { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.stroke', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
  { featureType: 'administrative.locality', elementType: 'labels.text.fill', stylers: [{ color: '#d59563' }] },
  { featureType: 'poi', elementType: 'labels.text.fill', stylers: [{ color: '#d59563' }] },
  { featureType: 'poi.park', elementType: 'geometry', stylers: [{ color: '#263c3f' }] },
  { featureType: 'poi.park', elementType: 'labels.text.fill', stylers: [{ color: '#6b9a76' }] },
  { featureType: 'road', elementType: 'geometry', stylers: [{ color: '#38414e' }] },
  { featureType: 'road', elementType: 'geometry.stroke', stylers: [{ color: '#212a37' }] },
  { featureType: 'road', elementType: 'labels.text.fill', stylers: [{ color: '#9ca5b3' }] },
  { featureType: 'road.highway', elementType: 'geometry', stylers: [{ color: '#746855' }] },
  { featureType: 'road.highway', elementType: 'geometry.stroke', stylers: [{ color: '#1f2835' }] },
  { featureType: 'road.highway', elementType: 'labels.text.fill', stylers: [{ color: '#f3d19c' }] },
  { featureType: 'transit', elementType: 'geometry', stylers: [{ color: '#2f3948' }] },
  { featureType: 'transit.station', elementType: 'labels.text.fill', stylers: [{ color: '#d59563' }] },
  { featureType: 'water', elementType: 'geometry', stylers: [{ color: '#17263c' }] },
  { featureType: 'water', elementType: 'labels.text.fill', stylers: [{ color: '#515c6d' }] },
  { featureType: 'water', elementType: 'labels.text.stroke', stylers: [{ color: '#17263c' }] },
];

type VehicleSize = 'small' | 'medium' | 'large' | 'xl' | 'xxl';

type Vehicle = {
  id: string;
  type?: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
  image_url?: string | null;
  created_at?: string | null;
  photo?: string | null;
  size?: VehicleSize | string | null;
};

function formatVehicleSize(size: VehicleSize | string | null | undefined): string {
  if (!size) return '';
  const s = String(size).toLowerCase();
  if (s === 'small') return 'S';
  if (s === 'medium') return 'M';
  if (s === 'large') return 'L';
  if (s === 'xl') return 'XL';
  if (s === 'xxl') return 'XXL';
  return s.charAt(0).toUpperCase() + s.slice(1);
}

export default function PhysicalVehicleSelection() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams<{ locationId?: string; scheduledAt?: string; serviceId?: string }>();
  const locationId = params.locationId;
  const scheduledAt = params.scheduledAt;
  const serviceId = params.serviceId;

  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedImageUri, setExpandedImageUri] = useState<string | null>(null);
  const [infoModalVehicle, setInfoModalVehicle] = useState<Vehicle | null>(null);
  const [vehicleStats, setVehicleStats] = useState<{ washCount: number; lastCleanedAt: string | null; cleanRating: number | null }>({ washCount: 0, lastCleanedAt: null, cleanRating: null });

  const { coords: liveCoords } = useLiveLocation();
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region | null>(null);

  const mapRef = useRef<MapView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 500, useNativeDriver: true }).start();
    loadVehicles();
  }, [user?.id]);

  useEffect(() => {
    if (liveCoords) {
      const coords = { latitude: liveCoords.latitude, longitude: liveCoords.longitude };
      setUserLocation(coords);
      setRegion({ ...coords, latitudeDelta: 0.001, longitudeDelta: 0.001 });
    } else {
      getCurrentLocation();
    }
  }, [liveCoords]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = { latitude: location.coords.latitude, longitude: location.coords.longitude };
      setUserLocation(coords);
      setRegion({ ...coords, latitudeDelta: 0.001, longitudeDelta: 0.001 });
    } catch {}
  };

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;

      const rows = (data || []).map((r: any) => ({
        ...r,
        image_url: r.image_url ?? r.photo ?? null,
        created_at: r.created_at ?? null,
      }));
      setVehicles(rows);
      if (rows.length > 0) {
        setSelectedVehicle(rows.find((v: Vehicle) => v.is_default)?.id ?? rows[0].id);
      }
    } catch (e) {
      console.error('Failed to load vehicles', e);
    } finally {
      setLoading(false);
    }
  };

  const openVehicleInfo = async (vehicle: Vehicle) => {
    hapticFeedback('light');
    setInfoModalVehicle(vehicle);
    setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    try {
      const stats = await fetchVehicleStats(vehicle.id);
      setVehicleStats({ washCount: stats.washCount, lastCleanedAt: stats.lastCleanedAt, cleanRating: stats.cleanRating });
    } catch {
      setVehicleStats({ washCount: 0, lastCleanedAt: null, cleanRating: null });
    }
  };

  const handleSelect = async (vehicleId: string) => {
    await hapticFeedback('light');
    setSelectedVehicle(vehicleId);
  };

  const handleContinue = async () => {
    if (!selectedVehicle) return;
    await hapticFeedback('medium');
    if (locationId) {
      router.push({
        pathname: '/owner/booking/physical/service',
        params: {
          locationId,
          vehicleId: selectedVehicle,
          ...(serviceId ? { serviceId } : {}),
          ...(scheduledAt && { scheduledAt }),
        },
      });
    } else {
      router.push({
        pathname: '/owner/booking/physical/location',
        params: { vehicleId: selectedVehicle },
      });
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <View style={StyleSheet.absoluteFill}>
        <MapView
          ref={mapRef}
          style={StyleSheet.absoluteFill}
          region={region ?? DEFAULT_MAP_REGION}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={uberDarkMapStyle}
          userInterfaceStyle={MAP_LOCKED_DARK}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image
                  source={CAR_IMAGE}
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      <TouchableOpacity
        onPress={async () => {
          hapticFeedback('light');
          let center = userLocation;
          if (!center) {
            try {
              const { status } = await Location.requestForegroundPermissionsAsync();
              if (status === 'granted') {
                const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
                center = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
                setUserLocation(center);
              }
            } catch {}
          }
          if (center) {
            const r = { ...center, latitudeDelta: 0.001, longitudeDelta: 0.001 };
            setRegion(r);
            mapRef.current?.animateToRegion(r, 350);
          }
        }}
        style={[styles.recenterButtonFloating, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS, right: RECENTER_BUTTON_RIGHT }]}
        activeOpacity={0.7}
      >
        <Ionicons name="locate" size={22} color={SKY} />
      </TouchableOpacity>

      <AppHeader
        title="Confirm vehicle"
        subtitle="We've found your vehicles – swipe to pick"
        showBack
        onBack={() => router.back()}
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.replace('/owner/owner-dashboard' as any);
            }}
            style={styles.exitButton}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={22} color="#FFFFFF" />
          </TouchableOpacity>
        }
      />

      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            paddingBottom: Math.max(insets.bottom, 14) + 14 + TAB_BAR_TOTAL_HEIGHT + 12,
          },
        ]}
      >
        {loading ? (
          <View style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
            <UnifiedBookingCard stripColor={SKY}>
              <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color={SKY} />
                <Text style={styles.loadingText}>Loading vehicles…</Text>
              </View>
            </UnifiedBookingCard>
          </View>
        ) : vehicles.length === 0 ? (
          <View style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
            <UnifiedBookingCard stripColor={SKY}>
              <View style={styles.emptyContent}>
                <View style={[styles.iconWrap, { backgroundColor: SKY + '20', borderColor: SKY + '40' }]}>
                  <Ionicons name="car-outline" size={28} color={SKY} />
                </View>
                <Text style={styles.emptyText}>No vehicles found</Text>
                <Text style={styles.emptySubtext}>Add a vehicle to continue</Text>
                <TouchableOpacity onPress={() => router.push('/owner/settings/vehicle-management')} style={styles.addButton} activeOpacity={0.85}>
                  <LinearGradient colors={[SKY, '#60A5FA']} style={styles.addButtonGradient}>
                    <Ionicons name="add-circle" size={20} color="#FFFFFF" />
                    <Text style={styles.addButtonText}>Add Vehicle</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </UnifiedBookingCard>
          </View>
        ) : (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.cardsScrollContent}
            snapToInterval={BOOKING_CARD.SNAP_INTERVAL}
            decelerationRate="fast"
            snapToAlignment="start"
          >
            {vehicles.map(vehicle => {
              const isSelected = selectedVehicle === vehicle.id;
              return (
                <View key={vehicle.id} style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
                  <UnifiedBookingCard
                    stripColor={SKY}
                    onPress={() => handleSelect(vehicle.id)}
                  >
                    <View style={styles.vehicleCardInner}>
                      {isSelected && (
                        <LinearGradient colors={[SKY + '15', SKY + '08', 'transparent']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
                      )}
                      <View style={styles.vehicleCardInfoIcon}>
                        <InfoIconButton
                          onPress={() => { hapticFeedback('light'); openVehicleInfo(vehicle); }}
                          accentColor={SKY}
                        />
                      </View>
                      <View style={styles.cardTop}>
                        <View style={[styles.vehicleCardCarIcon, { backgroundColor: (isSelected ? SKY : '#94A3B8') + '18', borderColor: (isSelected ? SKY : '#94A3B8') + '30' }]}>
                          <Ionicons name="car-sport" size={28} color={isSelected ? SKY : '#94A3B8'} />
                        </View>
                        <View style={styles.cardContent}>
                          <Text style={styles.cardTitle} numberOfLines={1}>{vehicle.make} {vehicle.model}</Text>
                          <View style={styles.cardColourRow}>
                            <Text style={styles.cardSubtitle} numberOfLines={1}>{vehicle.color}</Text>
                            {vehicle.is_default && (
                              <View style={[styles.quickHint, { backgroundColor: '#10B98115' }]}>
                                <Ionicons name="star" size={12} color="#10B981" />
                                <Text style={[styles.quickHintText, { color: '#10B981' }]}>Default vehicle</Text>
                              </View>
                            )}
                          </View>
                          <View style={styles.cardMetaRow}>
                            <View style={[styles.quickHint, { backgroundColor: (isSelected ? SKY : '#94A3B8') + '18' }]}>
                              <Ionicons name="card-outline" size={12} color={isSelected ? SKY : '#94A3B8'} />
                              <Text style={[styles.quickHintText, { color: isSelected ? SKY : '#94A3B8' }]} numberOfLines={1}>{vehicle.registration}</Text>
                            </View>
                            {vehicle.size ? (
                              <View style={[styles.quickHint, { backgroundColor: (isSelected ? SKY : '#94A3B8') + '18' }]}>
                                <Text style={[styles.quickHintText, { color: isSelected ? SKY : '#94A3B8' }]}>{formatVehicleSize(vehicle.size)}</Text>
                              </View>
                            ) : null}
                          </View>
                        </View>
                        {vehicle.image_url ? (
                          <View style={styles.carPhotoBox}>
                            <TouchableOpacity
                              onPress={(e) => {
                                e.stopPropagation();
                                hapticFeedback('light');
                                setExpandedImageUri(vehicle.image_url || null);
                              }}
                              activeOpacity={0.9}
                              style={styles.carPhotoTouch}
                            >
                              <Image source={{ uri: vehicle.image_url }} style={styles.carPhotoSmall} resizeMode="cover" />
                              <View style={styles.carPhotoExpandHint}>
                                <Ionicons name="expand" size={12} color="#fff" />
                              </View>
                            </TouchableOpacity>
                          </View>
                        ) : null}
                      </View>
                    </View>
                </UnifiedBookingCard>
              </View>
            );
          })}
          </ScrollView>
        )}
      </Animated.View>

      {/* Continue button */}
      <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12 }]}>
        <TouchableOpacity
          onPress={handleContinue}
          disabled={!selectedVehicle}
          style={[styles.ctaButton, { width: CARD_WIDTH }]}
          activeOpacity={0.9}
        >
          <LinearGradient
            colors={selectedVehicle ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 0 }}
            style={styles.ctaGradient}
          >
            <Text style={styles.ctaText}>{selectedVehicle ? 'Continue' : 'Select a vehicle'}</Text>
            <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      </View>

      <VehicleInfoOverlay
        visible={!!infoModalVehicle}
        vehicle={infoModalVehicle ? { ...infoModalVehicle, mot_expiry: (infoModalVehicle as any).mot_expiry ?? null, mot_expiry_date: (infoModalVehicle as any).mot_expiry_date ?? null, mileage: (infoModalVehicle as any).mileage ?? null, tax_status: (infoModalVehicle as any).tax_status ?? null, tax_due_date: (infoModalVehicle as any).tax_due_date ?? null, tax_expiry: (infoModalVehicle as any).tax_expiry ?? null } : null}
        stats={vehicleStats}
        accentColor={SKY}
        onClose={() => setInfoModalVehicle(null)}
      />

      {/* Expanded car photo modal */}
      <Modal
        visible={!!expandedImageUri}
        transparent
        animationType="fade"
        onRequestClose={() => setExpandedImageUri(null)}
      >
        <Pressable
          style={styles.imageModalOverlay}
          onPress={() => setExpandedImageUri(null)}
        >
          <Pressable onPress={(e) => e.stopPropagation()} style={styles.imageModalContent}>
            {expandedImageUri && (
              <Image
                source={{ uri: expandedImageUri }}
                style={styles.imageModalImage}
                resizeMode="contain"
              />
            )}
            <TouchableOpacity
              onPress={() => setExpandedImageUri(null)}
              style={styles.imageModalClose}
              hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
            >
              <Ionicons name="close-circle" size={36} color="#fff" />
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  recenterButton: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 100,
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 1000,
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerLocateButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 8,
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  cardWrapper: {
    marginRight: 12,
  },
  curvedCard: {
    ...CURVED_BOOKING_CARD,
  },
  modernCardSelected: {
    borderWidth: 0,
    borderColor: 'transparent',
    shadowColor: SKY,
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  vehicleCardInner: {
    position: 'relative',
    padding: 20,
  },
  vehicleCardInfoIcon: {
    position: 'absolute',
    top: 14,
    right: 14,
    zIndex: 1,
  },
  vehicleCardCarIcon: {
    width: 52,
    height: 52,
    borderRadius: 18,
    marginRight: 14,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 52,
    height: 52,
    borderRadius: 18,
    marginRight: 14,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    flex: 1,
    minWidth: 0,
    paddingRight: 44,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    flex: 1,
    marginBottom: 4,
  },
  cardColourRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 6,
    marginBottom: 6,
  },
  cardSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '500',
  },
  badgeSmall: {
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
  },
  cardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 6,
  },
  quickHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 8,
  },
  quickHintText: {
    fontSize: 12,
    fontWeight: '600',
  },
  infoIconBtn: {
    padding: 6,
    borderRadius: 10,
  },
  ctaDivider: {
    height: 1,
    marginTop: 14,
    marginBottom: 12,
    borderRadius: 1,
  },
  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
    alignItems: 'center',
  },
  ctaButton: {
    borderRadius: HEADER_BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
  emptyContent: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginTop: 14,
    marginBottom: 4,
  },
  emptySubtext: {
    color: '#94A3B8',
    fontSize: 13,
    textAlign: 'center',
    marginBottom: 16,
  },
  loadingContainer: {
    paddingVertical: 40,
    paddingHorizontal: 20,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  addButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginTop: 16,
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
    gap: 8,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  carPhotoBox: {
    width: 56,
    height: 56,
    borderRadius: 14,
    overflow: 'hidden',
    marginLeft: 10,
  },
  carPhotoTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  carPhotoSmall: {
    width: 56,
    height: 56,
  },
  carPhotoExpandHint: {
    position: 'absolute',
    bottom: 4,
    right: 4,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  carPhotoPlaceholder: {
    width: 56,
    height: 56,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.85)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageModalContent: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  imageModalImage: {
    width: '100%',
    height: '80%',
  },
  imageModalClose: {
    position: 'absolute',
    top: 60,
    right: 24,
  },

  // Vehicle info modal – same card opacity as other info popups
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  infoModalContentWrap: {
    width: '100%',
    maxWidth: 360,
    maxHeight: '88%',
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1.5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 12,
  },
  infoModalCard: {
    flex: 1,
    overflow: 'hidden',
    backgroundColor: 'transparent',
  },
  infoModalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    paddingLeft: 24,
    borderBottomWidth: 1,
    position: 'relative',
  },
  infoModalAccent: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 4,
    borderTopLeftRadius: 2,
    borderBottomLeftRadius: 2,
  },
  infoModalTitle: {
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.8,
    textTransform: 'uppercase',
    flex: 1,
  },
  infoModalCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoModalScroll: {
    maxHeight: 400,
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  infoModalCover: {
    height: 120,
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: SKY + '30',
  },
  infoModalPhoto: {
    width: '100%',
    height: '100%',
  },
  infoModalPhotoPlaceholder: {
    flex: 1,
    width: '100%',
    height: '100%',
    backgroundColor: SKY + '18',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoModalVehicleTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 16,
    letterSpacing: 0.2,
  },
  infoModalBody: {
    gap: 12,
    marginBottom: 18,
  },
  infoModalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoModalText: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 20,
  },
  infoModalBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 10,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: '#10B98122',
    borderWidth: 1,
    borderColor: '#10B98140',
    alignSelf: 'flex-start',
  },
  infoModalBadgeText: {
    color: '#10B981',
    fontSize: 13,
    fontWeight: '700',
  },
  infoModalDone: {
    marginHorizontal: 20,
    marginTop: 8,
    marginBottom: 20,
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
  },
  infoModalDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
  },
});
