import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Dimensions,
  Animated,
  Alert,
  TouchableOpacity,
  Image,
} from 'react-native';
import MapView, { Region, Marker, Circle } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { customerTheme } from '../../../src/constants/customerTheme';
import { DEFAULT_MAP_REGION, MAP_LOCKED_DARK, RECENTER_BUTTON_RIGHT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '../../../src/constants/mapConstants';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { VALETER_MAP_IMAGE } from '../../assets/assetExports';
import CountdownTimer from '../../../src/components/booking/CountdownTimer';
import ValeterDeclinedOverlay from '../../../src/components/booking/ValeterDeclinedOverlay';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  WWBottomSheet,
  WWPrimaryButton,
  WWSecondaryButton,
  WWStepper,
} from '../../../src/components/ui';
import type { BottomSheetState, StepperStatus } from '../../../src/components/ui';

const { width, height } = Dimensions.get('window');
const SKY = '#5B8FA8';

// Dark map style
const darkMapStyle = [
  { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
  { featureType: 'water', stylers: [{ color: '#17263c' }] },
];

export default function WaitingAcceptance() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;

  const [booking, setBooking] = useState<any | null>(null);
  const [valeter, setValeter] = useState<any | null>(null);
  const [countdown, setCountdown] = useState(300); // 5 minutes
  const [status, setStatus] = useState<'pending_valeter_acceptance' | 'confirmed' | 'cancelled'>('pending_valeter_acceptance');
  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [customerLocation, setCustomerLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [valeterLocation, setValeterLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [showValeterDeclinedOverlay, setShowValeterDeclinedOverlay] = useState(false);
  const [sheetState, setSheetState] = useState<BottomSheetState>('half');
  const insets = useSafeAreaInsets();
  const mapRef = useRef<MapView>(null);

  useEffect(() => {
    if (!customerLocation && liveCoords) {
      setRegion({
        latitude: liveCoords.latitude,
        longitude: liveCoords.longitude,
        latitudeDelta: 0.001,
        longitudeDelta: 0.001,
      });
    }
  }, [liveCoords, customerLocation]);

  const pulseAnim = useRef(new Animated.Value(1)).current;
  const pulseLoopRef = useRef<Animated.CompositeAnimation | null>(null);
  const handleCountdownCompleteRef = useRef<() => void>(() => {});
  const countdownIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const [countdownStarted, setCountdownStarted] = useState(false);

  useEffect(() => {
    loadBooking();
    subscribeToBooking();
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    );
    pulseLoopRef.current = loop;
    loop.start();
    return () => {
      if (pulseLoopRef.current) {
        pulseLoopRef.current.stop();
        pulseLoopRef.current = null;
      }
    };
  }, [bookingId]);

  useEffect(() => {
    if (!countdownStarted || countdown <= 0) return;
    countdownIntervalRef.current = setInterval(() => {
      setCountdown(prev => {
        const next = Math.max(0, prev - 1);
        if (next === 0) {
          if (countdownIntervalRef.current) {
            clearInterval(countdownIntervalRef.current);
            countdownIntervalRef.current = null;
          }
          handleCountdownCompleteRef.current?.();
        }
        return next;
      });
    }, 1000);
    return () => {
      if (countdownIntervalRef.current) {
        clearInterval(countdownIntervalRef.current);
        countdownIntervalRef.current = null;
      }
    };
  }, [countdownStarted]);

  const loadBooking = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*, valeter_profiles(*)')
        .eq('id', bookingId)
        .single();

      if (error) throw error;
      if (!data) return;

      setBooking(data);
      
      if (data.valeter_profiles) {
        setValeter(data.valeter_profiles);
      }

      // Set locations
      if (data.location_lat != null && data.location_lng != null) {
        const loc = {
          latitude: data.location_lat,
          longitude: data.location_lng,
        };
        setCustomerLocation(loc);
        setRegion({ ...loc, latitudeDelta: 0.001, longitudeDelta: 0.001 });
      }

      // Calculate remaining time
      if (data.request_sent_at) {
        const sentAt = new Date(data.request_sent_at).getTime();
        const now = Date.now();
        const elapsed = Math.floor((now - sentAt) / 1000);
        const remaining = Math.max(0, 300 - elapsed);
        setCountdown(remaining);
        setCountdownStarted(true);
      }

      setStatus(data.status as any);
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const subscribeToBooking = () => {
    const channel = supabase
      .channel(`waiting-acceptance-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          setStatus(updated.status);

          if (updated.status === 'confirmed') {
            router.push({
              pathname: '/owner/booking/tracking',
              params: { bookingId },
            });
            return;
          }
          // Real-time sync: valeter declined, timeout, or job cancelled → show gamified overlay
          if (
            updated.status === 'cancelled' ||
            updated.status === 'valeter_declined' ||
            updated.status === 'valeter_timeout'
          ) {
            setShowValeterDeclinedOverlay(true);
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleCountdownComplete = () => {
    Alert.alert(
      'Time Expired',
      'The valeter did not respond in time. Would you like to request another valeter?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Request Another', onPress: handleCancelRequest },
      ]
    );
  };

  useEffect(() => {
    handleCountdownCompleteRef.current = handleCountdownComplete;
  });

  const handleCancelRequest = async () => {
    await hapticFeedback('medium');
    
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ status: 'cancelled' })
        .eq('id', bookingId);

      if (error) throw error;

      router.replace('/owner/owner-dashboard');
    } catch (error) {
      console.error('Error cancelling booking:', error);
      Alert.alert('Error', 'Failed to cancel request');
    }
  };

  const handleSendToAnother = async () => {
    await hapticFeedback('light');
    // Navigate back to valeter selection
    router.back();
  };

  const getStepperSteps = (): Array<{ label: string; status: StepperStatus }> => {
    return [
      {
        label: 'Request Sent',
        status: status === 'pending_valeter_acceptance' ? 'active' : 'completed',
      },
      {
        label: 'Connecting to your pro',
        status: status === 'pending_valeter_acceptance' ? 'active' : 'pending',
      },
      {
        label: 'Accepted',
        status: status === 'confirmed' ? 'active' : 'pending',
      },
      {
        label: 'On the Way',
        status: 'pending',
      },
    ];
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>

      {/* Full Screen Map – real map with default region until location loads */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          ref={mapRef}
          style={StyleSheet.absoluteFill}
          region={region ?? DEFAULT_MAP_REGION}
          customMapStyle={darkMapStyle}
          userInterfaceStyle={MAP_LOCKED_DARK}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
        >
          {customerLocation && (
            <>
              <Marker coordinate={customerLocation}>
                <View style={styles.customerMarker}>
                  <Animated.View style={[styles.pulseRing, { transform: [{ scale: pulseAnim }] }]} />
                  <View style={styles.markerInner}>
                    <Ionicons name="person" size={16} color={SKY} />
                  </View>
                </View>
              </Marker>
              <Circle
                center={customerLocation}
                radius={500}
                strokeColor={`${SKY}30`}
                fillColor={`${SKY}10`}
              />
            </>
          )}

          {valeterLocation && (
            <Marker coordinate={valeterLocation}>
              <View style={styles.valeterMarker}>
                <Image source={VALETER_MAP_IMAGE} style={styles.valeterMarkerImage} resizeMode="contain" />
              </View>
            </Marker>
          )}
        </MapView>
        <TouchableOpacity
          onPress={() => {
            hapticFeedback('light');
            const loc = customerLocation ?? (region ? { latitude: region.latitude, longitude: region.longitude } : null);
            if (loc && mapRef.current) {
              const r = { ...loc, latitudeDelta: 0.001, longitudeDelta: 0.001 };
              mapRef.current.animateToRegion(r, 350);
            }
          }}
          style={[styles.recenterButtonFloating, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS, right: RECENTER_BUTTON_RIGHT }]}
          activeOpacity={0.7}
        >
          <Ionicons name="locate" size={22} color={SKY} />
        </TouchableOpacity>
      </View>

      <AppHeader
        title="Request sent"
        subtitle="Connecting to your pro"
        showBack
        onBack={() => router.back()}
        rightAction={
          (customerLocation || region) ? (
            <TouchableOpacity
              onPress={() => {
                const loc = customerLocation ?? (region ? { latitude: region.latitude, longitude: region.longitude } : null);
                if (loc) setRegion({ ...loc, latitudeDelta: 0.001, longitudeDelta: 0.001 });
              }}
              style={{ padding: 8 }}
              activeOpacity={0.7}
            >
              <Ionicons name="locate" size={22} color={SKY} />
            </TouchableOpacity>
          ) : undefined
        }
      />

      {/* Bottom Sheet */}
      <WWBottomSheet
        state={sheetState}
        onStateChange={setSheetState}
        collapsedHeight={height * 0.15}
        halfHeight={height * 0.6}
        fullHeight={height * 0.85}
        previewContent={
          <View style={styles.previewContent}>
            <Text style={styles.previewText}>
              {status === 'pending_valeter_acceptance' 
                ? 'Connecting to your pro...'
                : 'Request sent'}
            </Text>
          </View>
        }
      >
        <View style={styles.headerSection}>
          <Text style={styles.title}>Request Sent</Text>
          <Text style={styles.subtitle}>
            {valeter?.full_name || 'Valeter'} has up to 5 minutes to accept
          </Text>
        </View>

        {/* Timer */}
        <View style={styles.timerContainer}>
          <CountdownTimer seconds={countdown} size="large" />
        </View>

        {/* Stepper */}
        <View style={styles.stepperContainer}>
          <WWStepper steps={getStepperSteps()} />
        </View>

        {/* Info Message */}
        <View style={styles.infoContainer}>
          <Ionicons name="information-circle-outline" size={20} color={SKY} />
          <Text style={styles.infoText}>
            You'll be notified as soon as the valeter accepts your request
          </Text>
        </View>
      </WWBottomSheet>

      {/* Action Buttons */}
      <View style={styles.footer}>
        <WWPrimaryButton
          title="Cancel Request"
          onPress={handleCancelRequest}
          style={styles.cancelButton}
        />
        <View style={styles.spacer} />
        <WWSecondaryButton
          title="Send to Another Pro"
          onPress={handleSendToAnother}
        />
      </View>

      {/* Gamified overlay when valeter declines / job cancelled */}
      <ValeterDeclinedOverlay
        visible={showValeterDeclinedOverlay}
        onFindNewValeter={() => {
          setShowValeterDeclinedOverlay(false);
          void (async () => {
            try {
              const { error } = await supabase
                .from('bookings')
                .update({
                  status: 'pending_valeter_acceptance',
                  valeter_id: null,
                  request_sent_at: new Date().toISOString(),
                })
                .eq('id', bookingId);
              if (error) throw error;
              router.replace({ pathname: '/owner/booking/valeter-selection', params: { bookingId } } as any);
            } catch (e) {
              console.error('Error reopening booking:', e);
              router.replace('/owner/owner-dashboard');
            }
          })();
        }}
        onBackToDashboard={() => {
          setShowValeterDeclinedOverlay(false);
          router.replace('/owner/owner-dashboard');
        }}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 100,
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  customerMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  pulseRing: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: `${SKY}20`,
  },
  markerInner: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#0A1929',
    borderWidth: 3,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  valeterMarker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#0A1929',
    borderWidth: 2,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  valeterMarkerImage: {
    width: 24,
    height: 24,
  },
  previewContent: {
    paddingVertical: 4,
  },
  previewText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  headerSection: {
    marginBottom: 24,
  },
  title: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 8,
  },
  subtitle: {
    color: '#94A3B8',
    fontSize: 14,
  },
  timerContainer: {
    alignItems: 'center',
    marginBottom: 32,
  },
  stepperContainer: {
    marginBottom: 24,
  },
  infoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: `${SKY}15`,
    padding: 12,
    borderRadius: 12,
    marginTop: 8,
  },
  infoText: {
    color: '#E2E8F0',
    fontSize: 13,
    marginLeft: 8,
    flex: 1,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 20,
    paddingBottom: 20,
    paddingTop: 12,
    backgroundColor: 'rgba(15, 23, 42, 0.95)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    flexDirection: 'row',
  },
  cancelButton: {
    flex: 1,
  },
  spacer: {
    width: 12,
  },
});
