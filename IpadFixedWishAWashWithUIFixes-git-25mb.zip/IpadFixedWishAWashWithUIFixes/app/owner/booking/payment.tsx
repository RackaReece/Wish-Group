import React, { useState, useEffect, useRef, useMemo, useCallback } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Platform,
  Image,
  StatusBar,
  ActivityIndicator,
} from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import { useAuth } from "../../../src/providers/enhanced-auth-context";
import { supabase } from "../../../src/lib/supabase";
import { hapticFeedback } from "../../../src/services/HapticFeedbackService";
import UnifiedBookingCard from "../../../src/components/booking/UnifiedBookingCard";
import CountdownTimer from "../../../src/components/booking/CountdownTimer";
import { getServiceDisplayName } from "../../../src/utils/serviceNameMapper";
import { colors } from "../../../src/constants/colors";
import MapView, { Region, Marker } from "react-native-maps";
import AppHeader, { HEADER_CONTENT_OFFSET } from "../../../src/components/shared/AppHeader";
import * as Location from "expo-location";
import useLiveLocation from "../../../src/hooks/useLiveLocation";
import SuccessOverlay from "../../../src/components/booking/SuccessOverlay";
import SwipeToContinueBar from "../../../src/components/booking/SwipeToContinueBar";
import GlassCard from '@/components/booking/GlassCard';
import { CAR_IMAGE } from '../../assets/assetExports';

// Stripe (native only). Use a no-op hook when unavailable so hooks are always called unconditionally.
function useStripeNoop(): null {
  return null;
}
let useStripeImpl: () => ReturnType<typeof useStripeNoop> | { initPaymentSheet: unknown; presentPaymentSheet: unknown } = useStripeNoop;
if (Platform.OS !== "web") {
  try {
    const stripe = require("@stripe/stripe-react-native");
    useStripeImpl = stripe.useStripe;
  } catch (e) {
    console.warn("Stripe not available:", e);
  }
}

import { BOOKING_CARD } from "../../../src/constants/bookingCardTheme";
import { DEFAULT_MAP_REGION, BOOKING_MAP_STYLE, MAP_LOCKED_DARK, MAP_CAMERA_ANIMATION_DURATION, RECENTER_BUTTON_LEFT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from "../../../src/constants/mapConstants";

const { width } = Dimensions.get("window");
const SKY = colors.SKY;
const CARD_WIDTH = BOOKING_CARD.CARD_WIDTH;

type PrepState = "idle" | "preparing" | "ready" | "error";

type BookingPaymentRecord = {
  id?: string;
  price?: number;
  add_ons_total?: number;
  service_type?: string;
  service_name?: string | null;
  [key: string]: unknown;
};

function asStringParam(v: unknown): string | null {
  if (!v) return null;
  if (Array.isArray(v)) return typeof v[0] === "string" ? v[0] : null;
  return typeof v === "string" ? v : null;
}

function moneyGBP(value: any) {
  const n = Number(value);
  if (!Number.isFinite(n)) return "0.00";
  return n.toFixed(2);
}

export default function BookingPayment() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams();

  // ✅ handles string | string[] | undefined
  const bookingId = useMemo(() => asStringParam((params as { bookingId?: string | string[] })?.bookingId), [params]);

  const stripeHook = useStripeImpl();
  const hookObj = stripeHook && typeof stripeHook === "object" ? (stripeHook as Record<string, unknown>) : null;
  const initPaymentSheet = typeof hookObj?.initPaymentSheet === "function" ? hookObj.initPaymentSheet : undefined;
  const presentPaymentSheet = typeof hookObj?.presentPaymentSheet === "function" ? hookObj.presentPaymentSheet : undefined;

  const [booking, setBooking] = useState<BookingPaymentRecord | null>(null);
  const [loadingBooking, setLoadingBooking] = useState(false);

  const [processing, setProcessing] = useState(false);
  const [countdown] = useState(600);
  const [showSuccessOverlay, setShowSuccessOverlay] = useState(false);

  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [prepState, setPrepState] = useState<PrepState>("idle");
  const [lastError, setLastError] = useState<string | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region | null>(null);

  const { coords } = useLiveLocation();
  const mapRef = useRef<MapView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const cardAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;

  const sheetReady = prepState === "ready";
  const hasAutoPresentedRef = useRef(false);

  /** Same as wishv3: on successful sheet completion, immediately mark booking paid in DB then show success and navigate. */
  const markBookingPaid = useCallback(async () => {
    if (!bookingId) return;
    const { error } = await supabase
      .from("bookings")
      .update({
        status: "confirmed",
        payment_completed_at: new Date().toISOString(),
      })
      .eq("id", bookingId);
    if (error) throw error;
  }, [bookingId]);

  /** Present the Stripe sheet and handle result. Same logic as wishv3: call presentPaymentSheet() directly, then on success mark booking paid and navigate. */
  const presentSheetAndHandleResult = useCallback(async () => {
    if (!presentPaymentSheet) return;
    setProcessing(true);
    await hapticFeedback("medium");
    try {
      console.log("[Payment] presenting sheet…");
      const { error } = await presentPaymentSheet();
      console.log("[Payment] presentPaymentSheet result:", error);
      if (error) {
        if (error.code === "Canceled") {
          setProcessing(false);
          return;
        }
        throw error;
      }
      await markBookingPaid();
      setShowSuccessOverlay(true);
      setTimeout(() => {
        router.replace({
          pathname: "/owner/booking/tracking",
          params: { bookingId },
        });
      }, 2500);
    } catch (e: any) {
      console.error("[Payment] failed:", e);
      Alert.alert("Payment Failed", e?.message || "Please try again.");
    } finally {
      setProcessing(false);
    }
  }, [presentPaymentSheet, markBookingPaid, bookingId]);

  useEffect(() => {
    if (coords) {
      setUserLocation(coords);
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.001,
        longitudeDelta: 0.001,
      });
    } else {
      getCurrentLocation();
    }
  }, [coords]);

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [markerPulse]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") return;
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const c = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };
      setUserLocation(c);
      setRegion({
        latitude: c.latitude,
        longitude: c.longitude,
        latitudeDelta: 0.001,
        longitudeDelta: 0.001,
      });
    } catch {}
  };

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(cardAnim, { toValue: 1, tension: 50, friction: 8, useNativeDriver: true }),
    ]).start();
  }, []);

  useEffect(() => {
    if (!bookingId) return;
    loadBooking();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookingId]);

  useEffect(() => {
    // Auto-prepare once booking is loaded
    if (booking?.id && user?.id && Platform.OS !== "web") {
      preparePaymentSheet();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [booking?.id, user?.id]);

  // Auto-present sheet when ready (e.g. after swiping on confirm → land on payment → sheet opens)
  useEffect(() => {
    if (
      Platform.OS === "web" ||
      prepState !== "ready" ||
      !presentPaymentSheet ||
      hasAutoPresentedRef.current ||
      processing
    ) {
      return;
    }
    hasAutoPresentedRef.current = true;
    presentSheetAndHandleResult();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [prepState, presentPaymentSheet]);

  const loadBooking = async () => {
    if (!bookingId) return;

    try {
      setLoadingBooking(true);
      setLastError(null);

      const { data, error } = await supabase
        .from("bookings")
        .select("*")
        .eq("id", bookingId)
        .single();

      if (error) throw error;
      setBooking(data);
      if (data?.status === "confirmed" && data.payment_completed_at) {
        setShowSuccessOverlay(true);
        setTimeout(
          () => router.replace({ pathname: "/owner/booking/tracking", params: { bookingId } }),
          1500
        );
      }
    } catch (e: any) {
      console.error("Error loading booking:", e);
      setBooking(null);
      setPrepState("error");
      setLastError(
        e?.message ||
          "Couldn’t load booking. If this is your booking, check RLS policies allow the customer to select it."
      );
    } finally {
      setLoadingBooking(false);
    }
  };

  const extractClientSecret = (data: any): string | null => {
    return (
      data?.clientSecret ??
      data?.client_secret ??
      data?.paymentIntentClientSecret ??
      data?.payment_intent_client_secret ??
      data?.paymentIntent?.clientSecret ??
      data?.paymentIntent?.client_secret ??
      data?.payment_intent?.client_secret ??
      null
    );
  };

  /** Prepares the Stripe payment sheet. Returns true if ready to present. */
  const preparePaymentSheet = async (): Promise<boolean> => {
    if (Platform.OS === "web") return false;
    if (!booking || !user?.id || !bookingId) return false;

    if (!initPaymentSheet || !presentPaymentSheet) {
      const msg =
        "Stripe not initialised. Check StripeProvider is mounted at the app root, and that @stripe/stripe-react-native is installed correctly.";
      console.error("[Payment] Stripe hook missing:", { initPaymentSheet, presentPaymentSheet });
      setLastError(msg);
      setPrepState("error");
      return false;
    }

    setPrepState("preparing");
    setLastError(null);
    setClientSecret(null);

    const priceNumber = Number(booking.price);
    const amountPence = Math.round((Number.isFinite(priceNumber) ? priceNumber : 0) * 100);

    console.log("[Payment] preparing", {
      bookingId,
      price: booking.price,
      amountPence,
      platform: Platform.OS,
    });

    if (!amountPence || Number.isNaN(amountPence) || amountPence < 50) {
      const msg = `Invalid amount: ${amountPence}. Check booking.price is a number in pounds (e.g. 12.99).`;
      console.error("[Payment]", msg, booking?.price);
      setLastError(msg);
      setPrepState("error");
      return false;
    }

    try {
      const { data, error } = await supabase.functions.invoke("hyper-endpoint", {
        body: {
          bookingId,
          amount: amountPence,
          currency: "gbp",
          customerId: user.id,
          description: `Wish a Wash booking ${bookingId}`,
        },
      });

      console.log("[Payment] edge response", { data, error });

      if (error) {
        const msg = error?.message || "Edge function failed creating payment intent.";
        console.error("[Payment] Edge function error:", error);
        setLastError(msg);
        setPrepState("error");
        return false;
      }

      const cs = extractClientSecret(data);
      if (!cs) {
        const msg =
          "No client secret returned. Your edge function response shape likely differs. Check logs for data keys.";
        console.error("[Payment] Missing client secret. Data:", data);
        setLastError(msg);
        setPrepState("error");
        return false;
      }

      setClientSecret(cs);

      const { error: sheetError } = await initPaymentSheet({
        paymentIntentClientSecret: cs,
        merchantDisplayName: "Wish a Wash",
        returnURL: "waw://stripe-redirect",
        style: "automatic",
      });

      console.log("[Payment] initPaymentSheet result", sheetError);

      if (sheetError) {
        const msg = sheetError.message || "initPaymentSheet failed.";
        console.error("[Payment] initPaymentSheet error:", sheetError);
        setLastError(msg);
        setPrepState("error");
        return false;
      }

      setPrepState("ready");
      return true;
    } catch (e: any) {
      const msg = e?.message || "Unexpected error preparing payment.";
      console.error("[Payment] preparePaymentSheet exception:", e);
      setLastError(msg);
      setPrepState("error");
      return false;
    }
  };

  const handlePayment = async () => {
    if (!bookingId) {
      Alert.alert("Missing booking", "No bookingId was passed to payment screen.");
      return;
    }
    if (!booking || !user?.id) return;
    if (processing) return;

    if (Platform.OS === "web") {
      Alert.alert("Not supported", "This payment flow is native-only.");
      return;
    }

    if (!presentPaymentSheet) {
      Alert.alert("Stripe not ready", "Stripe is not initialised in the app.");
      return;
    }

    // Block auto-present effect from also firing when we prepare below (user-initiated swipe)
    setProcessing(true);

    // If sheet isn't ready yet, prepare it then open (so one swipe can do both)
    let ready = sheetReady && !!clientSecret;
    if (!ready) {
      if (prepState === "preparing") {
        setProcessing(false);
        Alert.alert("Hold up", "Payment is still preparing… Swipe again in a moment.");
        return;
      }
      ready = await preparePaymentSheet();
      if (!ready) {
        setProcessing(false);
        Alert.alert("Hold up", lastError || "Payment isn’t ready. Tap Retry to try again.");
        return;
      }
    }

    await presentSheetAndHandleResult();
  };

  const handleCountdownComplete = () => {
    Alert.alert("Payment Timeout", "The payment window has expired. Please try again.", [
      { text: "OK", onPress: () => router.back() },
    ]);
  };

  const handleCancelBooking = () => {
    Alert.alert(
      "Cancel booking",
      "Are you sure you want to cancel this booking? You can book again anytime.",
      [
        { text: "Keep booking", style: "cancel" },
        {
          text: "Cancel booking",
          style: "destructive",
          onPress: () => {
            void (async () => {
              if (!bookingId || !user?.id) return;
              try {
                setCancelling(true);
                const { error } = await supabase
                  .from("bookings")
                  .update({
                    status: "cancelled",
                    cancelled_at: new Date().toISOString(),
                    cancelled_by: "customer",
                    cancellation_reason: "Cancelled by customer on payment screen",
                  })
                  .eq("id", bookingId);

                if (error) throw error;
                hapticFeedback("light");
                router.replace("/owner/owner-dashboard" as any);
              } catch (e) {
                console.warn("[BookingPayment] cancelBooking error", e);
                Alert.alert("Could not cancel", "Please try again in a moment.");
              } finally {
                setCancelling(false);
              }
            })();
          },
        },
      ]
    );
  };

  // ✅ explicit missing bookingId UI (this is the real “missing booking info” case)
  if (!bookingId) {
    return (
      <SafeAreaView style={[styles.container, { justifyContent: "center", alignItems: "center", padding: 20 }]}>
        <Text style={{ color: "#fff", fontWeight: "800", fontSize: 16, textAlign: "center" }}>
          Missing bookingId
        </Text>
        <Text style={{ color: "rgba(255,255,255,0.75)", marginTop: 8, textAlign: "center" }}>
          Payment screen was opened without a booking reference.
        </Text>
        <TouchableOpacity
          onPress={() => router.back()}
          style={{ marginTop: 14, paddingVertical: 10, paddingHorizontal: 14, borderRadius: 10, borderWidth: 1, borderColor: "rgba(135,206,235,0.35)" }}
        >
          <Text style={{ color: SKY, fontWeight: "800" }}>Go back</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  // Screen-level loading: keep layout, show inline loader (no full-screen takeover)
  if (loadingBooking && !booking) {
    return (
      <SafeAreaView style={styles.container}>
        <AppHeader title="Payment" subtitle="Loading…" showBack onBack={() => router.back()} />
        <View style={{ flex: 1, justifyContent: "center", alignItems: "center", paddingTop: HEADER_CONTENT_OFFSET }}>
          <GlassCard style={{ padding: 24, minWidth: 200, alignItems: "center" }} accountType="customer">
            <ActivityIndicator size="small" color={SKY} />
            <Text style={{ color: "rgba(255,255,255,0.9)", marginTop: 12, fontWeight: "600" }}>Loading booking…</Text>
          </GlassCard>
        </View>
      </SafeAreaView>
    );
  }

  // ✅ booking failed to load UI
  if (!booking) {
    return (
      <SafeAreaView style={styles.container}>
        <AppHeader title="Payment" subtitle="Booking not found" showBack onBack={() => router.back()} />
        <View style={{ padding: 20, paddingTop: HEADER_CONTENT_OFFSET + 20 }}>
          <GlassCard style={{ padding: 18 }} accountType="customer">
            <Text style={{ color: "#F9FAFB", fontSize: 16, fontWeight: "900" }}>Couldn’t load booking</Text>
            <Text style={{ color: "rgba(249,250,251,0.8)", marginTop: 8, lineHeight: 18 }}>
              {lastError || "Unknown error."}
            </Text>

            <View style={{ flexDirection: "row", gap: 10, marginTop: 14 }}>
              <TouchableOpacity
                onPress={loadBooking}
                style={{ flex: 1, paddingVertical: 12, borderRadius: 12, borderWidth: 1, borderColor: "rgba(135,206,235,0.35)", alignItems: "center" }}
              >
                <Text style={{ color: SKY, fontWeight: "900" }}>Retry</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => router.back()}
                style={{ flex: 1, paddingVertical: 12, borderRadius: 12, borderWidth: 1, borderColor: "rgba(255,255,255,0.12)", alignItems: "center" }}
              >
                <Text style={{ color: "#F9FAFB", fontWeight: "900" }}>Back</Text>
              </TouchableOpacity>
            </View>
          </GlassCard>
        </View>
      </SafeAreaView>
    );
  }

  const statusText = (() => {
    if (prepState === "ready") return "Payment ready";
    if (prepState === "preparing") return "Preparing payment…";
    if (prepState === "error") return "Payment setup failed";
    return "Tap Retry to prepare";
  })();

  const totalAmount = Number(booking.price) || 0;
  const addOnsTotal = Number(booking.add_ons_total) || 0;
  const serviceSubtotal = totalAmount - addOnsTotal;
  const totalDisplay = moneyGBP(booking.price);
  const showAddOnsBreakdown = addOnsTotal > 0;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <StatusBar hidden={true} />

      {/* Fullscreen map – real map with default region until location loads */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          ref={mapRef}
          style={StyleSheet.absoluteFill}
          region={region ?? DEFAULT_MAP_REGION}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={BOOKING_MAP_STYLE}
          userInterfaceStyle={MAP_LOCKED_DARK}
          scrollEnabled={false}
          zoomEnabled={false}
          rotateEnabled={false}
          pitchEnabled={false}
        >
          {userLocation && (
            <Marker coordinate={userLocation} anchor={{ x: 0.5, y: 0.5 }}>
              <Animated.View style={[styles.userMarkerContainer, { transform: [{ scale: markerPulse }] }]}>
                <View style={styles.userMarkerPulse} />
                <Image
                  source={CAR_IMAGE}
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </Animated.View>
            </Marker>
          )}
        </MapView>
      </View>

      <TouchableOpacity
        onPress={() => {
          hapticFeedback("light");
          if (userLocation) {
            const r = {
              latitude: userLocation.latitude,
              longitude: userLocation.longitude,
              latitudeDelta: 0.001,
              longitudeDelta: 0.001,
            };
            setRegion(r);
            mapRef.current?.animateToRegion(r, MAP_CAMERA_ANIMATION_DURATION);
          } else {
            getCurrentLocation();
          }
        }}
        style={[styles.recenterButton, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS, left: RECENTER_BUTTON_LEFT }]}
        activeOpacity={0.7}
      >
        <Ionicons name="locate" size={22} color={SKY} />
      </TouchableOpacity>

      <AppHeader
        title="Payment"
        subtitle={booking ? getServiceDisplayName(booking.service_type, booking.service_name) : undefined}
        showBack
        onBack={() => router.back()}
      />

      {/* Chat & Cancel floating on map – same as tracking */}
      <View
        style={[styles.mapActionButtons, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + 16 }]}
        pointerEvents="box-none"
      >
        <TouchableOpacity
          onPress={() => {
            hapticFeedback("light");
            if (bookingId) router.push({ pathname: "/owner/booking/chat", params: { bookingId } } as any);
          }}
          style={styles.mapActionBtn}
          activeOpacity={0.85}
        >
          <View style={styles.mapActionBtnInner}>
            <Ionicons name="chatbubble-ellipses-outline" size={24} color={SKY} />
          </View>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={handleCancelBooking}
          disabled={cancelling}
          style={[styles.mapActionBtn, cancelling && styles.mapActionBtnDisabled]}
          activeOpacity={0.85}
        >
          <View style={[styles.mapActionBtnInner, cancelling && styles.mapActionBtnInnerDisabled]}>
            {cancelling ? (
              <ActivityIndicator size="small" color="#EF4444" />
            ) : (
              <Ionicons name="close-circle-outline" size={24} color="#EF4444" />
            )}
          </View>
        </TouchableOpacity>
      </View>

      {/* Payment card – same position as confirmation card (bottom above CTA) */}
      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            transform: [{ scale: cardAnim }],
            bottom: 96 + Math.max(insets?.bottom ?? 0, 14),
          },
        ]}
      >
        <View style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
          <UnifiedBookingCard stripColor={SKY} intensity={28}>
            <View style={styles.paymentCard}>
            <LinearGradient
              colors={sheetReady ? [SKY + "08", SKY + "04", "transparent"] : ["transparent", "transparent"]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <View style={styles.cardContentRow}>
              <View style={styles.cardMain}>
                <View style={styles.cardHeader}>
                  <View style={styles.cardHeaderLeft}>
                    <View style={styles.paymentIconWrap}>
                      <Ionicons name="wallet-outline" size={28} color={SKY} />
                    </View>
                    <View style={styles.secureIconWrap}>
                      <Ionicons name="lock-closed" size={20} color={SKY} />
                      <Text style={styles.secureLabel}>Secure</Text>
                    </View>
                  </View>
                  <View style={styles.statusBadge}>
                    <View
                      style={[
                        styles.dot,
                        {
                          backgroundColor: (() => {
                            if (sheetReady) return "#10B981";
                            if (prepState === "error") return "#EF4444";
                            return SKY;
                          })(),
                          opacity: sheetReady ? 1 : 0.6,
                        },
                      ]}
                    />
                    <Text style={styles.statusText}>{statusText}</Text>
                  </View>
                </View>
                <Text style={styles.serviceName}>
                  {getServiceDisplayName(booking.service_type, booking.service_name)}
                </Text>
                <View style={styles.metaRow}>
                  <Ionicons name="location-outline" size={12} color="#94A3B8" />
                  <Text style={styles.metaText} numberOfLines={2}>
                    {booking.location_address || "—"}
                  </Text>
                </View>
                <View style={styles.breakdownSection}>
                  <Text style={styles.breakdownSectionTitle}>Price breakdown</Text>
                  <View style={styles.breakdownRow}>
                    <Text style={styles.breakdownLabel} numberOfLines={1}>
                      {getServiceDisplayName(booking.service_type, booking.service_name)}
                    </Text>
                    <Text style={styles.breakdownValue}>£{moneyGBP(serviceSubtotal)}</Text>
                  </View>
                  {showAddOnsBreakdown && (
                    <View style={styles.breakdownRow}>
                      <Text style={styles.breakdownLabel}>Add-ons</Text>
                      <Text style={styles.breakdownValue}>£{moneyGBP(addOnsTotal)}</Text>
                    </View>
                  )}
                  {Number(booking?.discount_amount) > 0 && (
                    <View style={styles.breakdownRow}>
                      <Text style={styles.breakdownLabel}>Discount (water/power)</Text>
                      <Text style={[styles.breakdownValue, styles.breakdownDiscount]}>
                        -£{moneyGBP(booking.discount_amount)}
                      </Text>
                    </View>
                  )}
                </View>
                <View style={styles.totalRow}>
                  <Text style={styles.totalLabel}>Total</Text>
                  <Text style={styles.totalValue}>£{totalDisplay}</Text>
                </View>
                {(prepState === "error" || prepState === "idle") && (
                  <TouchableOpacity onPress={preparePaymentSheet} style={styles.retryBtn} activeOpacity={0.85}>
                    <Text style={styles.retryText}>Retry</Text>
                  </TouchableOpacity>
                )}
                {!!lastError && (
                  <Text style={styles.errorText} numberOfLines={2}>{lastError}</Text>
                )}
                <View style={styles.timerRow}>
                  <CountdownTimer seconds={countdown} onComplete={handleCountdownComplete} size="small" variant="integrated" />
                </View>
              </View>
            </View>
            </View>
          </UnifiedBookingCard>
        </View>
      </Animated.View>

      <SuccessOverlay
        visible={showSuccessOverlay}
        type="payment"
        message="Payment Successful!"
        onComplete={() => setShowSuccessOverlay(false)}
      />

      {/* CTA - Book wash (final reassurance) */}
      <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12 }]}>
        <SwipeToContinueBar
          onComplete={handlePayment}
          label={(() => {
            if (processing) return "Processing…";
            if (sheetReady) return `Book wash – £${totalDisplay}`;
            if (prepState === "error") return "Payment setup failed – tap Retry";
            if (prepState === "preparing") return "Preparing…";
            return `Book wash – £${totalDisplay}`;
          })()}
          accentColor={SKY}
          disabled={processing || prepState === "error"}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "transparent" },
  userMarkerContainer: {
    alignItems: "center",
    justifyContent: "center",
    position: "relative",
  },
  userMarkerPulse: {
    position: "absolute",
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: "rgba(135,206,235,0.25)",
    borderWidth: 2,
    borderColor: "rgba(135,206,235,0.4)",
  },
  userMarker: {
    width: 48,
    height: 48,
    zIndex: 1,
  },
  cardsContainer: {
    position: "absolute",
    left: 0,
    right: 0,
    paddingHorizontal: 16,
  },
  cardWrapper: {
    width: CARD_WIDTH,
  },
  paymentCard: {
    width: "100%",
    padding: 18,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
  },
  mapActionButtons: {
    position: "absolute",
    right: 16,
    zIndex: 100,
    gap: 10,
  },
  mapActionBtn: {
    width: 48,
    height: 48,
  },
  mapActionBtnDisabled: { opacity: 0.6 },
  mapActionBtnInner: {
    width: "100%",
    height: "100%",
    borderRadius: 18,
    backgroundColor: "rgba(15,23,42,0.85)",
    borderWidth: 1.5,
    borderColor: "rgba(135,206,235,0.35)",
    justifyContent: "center",
    alignItems: "center",
  },
  mapActionBtnInnerDisabled: {
    backgroundColor: "rgba(100,116,139,0.25)",
    borderColor: "rgba(100,116,139,0.3)",
  },
  cardContentRow: {
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
  },
  cardMain: { flex: 1, minWidth: 0 },
  cardHeader: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 12,
  },
  cardHeaderLeft: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  paymentIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: "rgba(135,206,235,0.15)",
    justifyContent: "center",
    alignItems: "center",
  },
  secureIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: "rgba(135,206,235,0.08)",
    borderWidth: 1,
    borderColor: "rgba(135,206,235,0.25)",
    justifyContent: "center",
    alignItems: "center",
  },
  statusBadge: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    gap: 6,
  },
  dot: { width: 8, height: 8, borderRadius: 4 },
  statusText: { color: "#94A3B8", fontSize: 12, fontWeight: "600" },
  serviceName: {
    color: "#F9FAFB",
    fontSize: 16,
    fontWeight: "800",
    marginBottom: 6,
  },
  metaRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginBottom: 6,
  },
  metaText: {
    color: "#94A3B8",
    fontSize: 13,
    fontWeight: "500",
    flex: 1,
  },
  breakdownSection: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: "rgba(135,206,235,0.15)",
  },
  breakdownSectionTitle: {
    color: "#94A3B8",
    fontSize: 12,
    fontWeight: "600",
    marginBottom: 8,
    textTransform: "uppercase",
    letterSpacing: 0.5,
  },
  breakdownRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 4,
  },
  breakdownLabel: { color: "#94A3B8", fontSize: 13, fontWeight: "500", flex: 1, marginRight: 8 },
  breakdownValue: { color: "#E2E8F0", fontSize: 14, fontWeight: "600" },
  breakdownDiscount: { color: "#10B981" },
  totalRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: "rgba(135,206,235,0.2)",
  },
  totalLabel: { color: "#F9FAFB", fontSize: 15, fontWeight: "700" },
  totalValue: { color: SKY, fontSize: 20, fontWeight: "800" },
  retryBtn: {
    alignSelf: "flex-start",
    marginTop: 10,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "rgba(135,206,235,0.4)",
  },
  retryText: { color: SKY, fontWeight: "700", fontSize: 14 },
  errorText: {
    color: "#FCA5A5",
    fontSize: 12,
    marginTop: 8,
    lineHeight: 16,
  },
  secureLabel: {
    color: SKY,
    fontSize: 9,
    fontWeight: "700",
    marginTop: 2,
  },
  timerRow: {
    marginTop: 12,
    marginBottom: 0,
  },
  ctaWrapper: {
    position: "absolute",
    left: 16,
    right: 16,
    bottom: 0,
  },
  ctaButton: {
    borderRadius: 18,
    overflow: "hidden",
    elevation: 4,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  ctaGradient: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 10,
  },
  ctaText: {
    color: "#FFFFFF",
    fontSize: 17,
    fontWeight: "900",
  },
  recenterButton: {
    position: "absolute",
    zIndex: 100,
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: "rgba(15,23,42,0.85)",
    borderWidth: 1.5,
    borderColor: "rgba(135,206,235,0.4)",
    justifyContent: "center",
    alignItems: "center",
  },
});
