import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  FlatList,
  ViewToken,
  Dimensions,
  StatusBar,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { Video, ResizeMode, AVPlaybackStatus } from 'expo-av';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import { formatDisplayName } from '../../src/utils/formatDisplayName';

import { ONBOARDING_VIDEO } from '../../src/constants/appAssets';

const { width } = Dimensions.get('window');

interface Step {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  iconName: keyof typeof Ionicons.glyphMap;
  accent: string;
  bullets?: { icon: keyof typeof Ionicons.glyphMap; text: string }[];
}

export default function CustomerOnboarding() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const [index, setIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);
  const fadeAnim = useRef(new Animated.Value(1)).current;
  const progressAnim = useRef(new Animated.Value(0)).current;
  const videoRef = useRef<Video>(null);

  const handlePlaybackStatusUpdate = (status: AVPlaybackStatus) => {
    if (!status.isLoaded || !videoRef.current) return;
    if (status.didJustFinish) {
      videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
    }
  };

  const displayName = formatDisplayName(
    user?.name ?? user?.user_metadata?.full_name ?? user?.email?.split('@')[0] ?? ''
  ) || 'there';
  const steps: Step[] = [
    {
      id: '1',
      title: `Hi ${displayName}!`,
      subtitle: "You're in",
      description: "You've joined Wish a Wash — valeter comes to you or book at local wash & detail hubs when you're on the go. Your first wash is just a few taps away.",
      iconName: 'sparkles',
      accent: '#10B981',
    },
    {
      id: '2',
      title: 'Book Your Wash',
      subtitle: 'Choose what fits your day',
      description: "Pick a quick Bronze wash, a full Silver or Gold valet, or go premium with Platinum or detailing. Valeter comes to you, or book a time slot at a local wash or detail hub when you're on the go.",
      iconName: 'car-sport',
      accent: '#60A5FA',
      bullets: [
        { icon: 'flash', text: 'Instant or scheduled' },
        { icon: 'location', text: 'At home, work, or anywhere' },
        { icon: 'calendar', text: 'Pick your slot' },
      ],
    },
    {
      id: '3',
      title: 'Vetted Valeters',
      subtitle: 'Safe and skilled',
      description: 'Every valeter is vetted, trained, and insured. Your car is in professional hands from start to finish.',
      iconName: 'shield-checkmark',
      accent: '#8B5CF6',
      bullets: [
        { icon: 'checkmark-circle', text: 'Background checked' },
        { icon: 'ribbon', text: 'Trained professionals' },
        { icon: 'shield-checkmark', text: 'Fully insured' },
      ],
    },
    {
      id: '4',
      title: 'Rewards & Perks',
      subtitle: 'Wash more, get more',
      description: 'Earn points on every wash, unlock discounts, and use referrals to give friends credit while you earn too.',
      iconName: 'gift',
      accent: '#F59E0B',
      bullets: [
        { icon: 'gift', text: 'Points on every wash' },
        { icon: 'wallet', text: 'Member discounts' },
        { icon: 'people', text: 'Referral rewards' },
      ],
    },
    {
      id: '5',
      title: 'Stay in the Loop',
      subtitle: 'From book to finish',
      description: "Watch your valeter on the map, get live ETA and updates, and see before & after photos. Chat directly if you need anything.",
      iconName: 'navigate',
      accent: '#EF4444',
      bullets: [
        { icon: 'navigate', text: 'Live map tracking' },
        { icon: 'camera', text: 'Before & after photos' },
        { icon: 'chatbubble-ellipses', text: 'In-app chat' },
      ],
    },
    {
      id: '6',
      title: "You're All Set",
      subtitle: 'Time for your first wash',
      description: "Head to the dashboard to book. We'll match you with a valeter and bring premium car care to you.",
      iconName: 'checkmark-circle',
      accent: '#10B981',
    },
  ];

  useEffect(() => {
    Animated.timing(progressAnim, {
      toValue: (index + 1) / steps.length,
      duration: 350,
      useNativeDriver: false,
    }).start();
  }, [index]);

  const onViewableItemsChanged = useRef(({ viewableItems }: { viewableItems: ViewToken[] }) => {
    if (viewableItems[0]?.index != null) {
      fadeAnim.setValue(0);
      setIndex(viewableItems[0].index);
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 400,
        useNativeDriver: true,
      }).start();
    }
  }).current;

  const completeOnboarding = async () => {
    try {
      await AsyncStorage.setItem('customer_onboarding_seen', 'true');
      await AsyncStorage.setItem('onboarding_seen', 'customer');
    } catch {
      // ignore
    }
    router.replace('/owner/owner-dashboard');
  };

  const handleNext = () => {
    if (index < steps.length - 1) {
      flatListRef.current?.scrollToIndex({ index: index + 1, animated: true });
    } else {
      completeOnboarding();
    }
  };

  const currentStep = steps[index];

  const renderStep = ({ item }: { item: Step }) => (
    <View style={[styles.slide, { width }]}>
      <View style={[styles.iconWrap, { backgroundColor: item.accent + '22', borderColor: item.accent + '44' }]}>
        <Ionicons name={item.iconName} size={56} color={item.accent} />
      </View>

      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.subtitle}>{item.subtitle}</Text>
      <Text style={styles.description}>{item.description}</Text>

      {item.bullets && (
        <View style={styles.bulletList}>
          {item.bullets.map((b) => (
            <View key={`${item.id}-${b.icon}-${b.text}`} style={styles.bulletRow}>
              <Ionicons name={b.icon} size={20} color={item.accent} style={styles.bulletIcon} />
              <Text style={styles.bulletText}>{b.text}</Text>
            </View>
          ))}
        </View>
      )}

      {item.id === '6' && (
        <View style={styles.readyCard}>
          <Text style={styles.readyTitle}>Book your first wash</Text>
          <Text style={styles.readyText}>
            Tap "Get Started" to open your dashboard and choose your wash. Valeter comes to you or book at a local hub when you're out.
          </Text>
        </View>
      )}
    </View>
  );

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <Video
        ref={videoRef}
        source={ONBOARDING_VIDEO}
        style={styles.videoBackground}
        resizeMode={ResizeMode.COVER}
        shouldPlay
        isLooping
        isMuted
        onPlaybackStatusUpdate={handlePlaybackStatusUpdate}
      />
      <LinearGradient
        colors={['rgba(10,25,41,0.85)', 'rgba(26,47,74,0.75)', 'rgba(10,25,41,0.9)']}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <SafeAreaView style={styles.safe} edges={[]}>
        <AppHeader
          title="Get started"
          showBack={false}
        />
        {/* Progress row – below header (header is absolute; use inset + offset so Skip/progress clear it) */}
        <View style={[styles.header, { paddingTop: insets.top + HEADER_CONTENT_OFFSET }]}>
          <TouchableOpacity onPress={completeOnboarding} style={styles.skip} activeOpacity={0.8}>
            <Text style={styles.skipText}>Skip</Text>
          </TouchableOpacity>
          <View style={styles.progressTrack}>
            <Animated.View
              style={[
                styles.progressFill,
                {
                  width: progressAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['0%', '100%'],
                  }),
                },
              ]}
            />
          </View>
          <View style={styles.placeholder} />
        </View>

        {/* Steps */}
        <Animated.View style={[styles.listWrap, { opacity: fadeAnim }]}>
          <FlatList
            ref={flatListRef}
            data={steps}
            renderItem={renderStep}
            keyExtractor={(s) => s.id}
            horizontal
            pagingEnabled
            showsHorizontalScrollIndicator={false}
            onViewableItemsChanged={onViewableItemsChanged}
            viewabilityConfig={{ viewAreaCoveragePercentThreshold: 50 }}
            getItemLayout={(_, i) => ({ length: width, offset: width * i, index: i })}
            scrollEventThrottle={16}
          />
        </Animated.View>

        {/* Footer */}
        <View style={styles.footer}>
          <View style={styles.dots}>
            {steps.map((step, i) => (
              <View
                key={step.id}
                style={[
                  styles.dot,
                  i === index && styles.dotActive,
                  i < index && styles.dotDone,
                ]}
              />
            ))}
          </View>
          <TouchableOpacity
            style={[styles.nextBtn, { backgroundColor: currentStep?.accent ?? '#10B981' }]}
            onPress={handleNext}
            activeOpacity={0.9}
          >
            <Text style={styles.nextText}>
              {index === steps.length - 1 ? 'Get Started' : 'Next'}
            </Text>
            <Ionicons name="arrow-forward" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  videoBackground: {
    ...StyleSheet.absoluteFillObject,
  },
  safe: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 8,
    paddingBottom: 16,
  },
  skip: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    width: 60,
  },
  skipText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 15,
    fontWeight: '600',
  },
  progressTrack: {
    flex: 1,
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.12)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#10B981',
    borderRadius: 2,
  },
  placeholder: {
    width: 60,
  },
  listWrap: {
    flex: 1,
  },
  slide: {
    flex: 1,
    paddingHorizontal: 28,
    paddingTop: 24,
    paddingBottom: 20,
    justifyContent: 'flex-start',
    alignItems: 'center',
  },
  iconWrap: {
    width: 110,
    height: 110,
    borderRadius: 55,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 28,
    borderWidth: 2,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 6,
    letterSpacing: -0.3,
  },
  subtitle: {
    fontSize: 16,
    color: '#5B8FA8',
    textAlign: 'center',
    marginBottom: 12,
    fontWeight: '600',
  },
  description: {
    fontSize: 15,
    color: 'rgba(255,255,255,0.88)',
    textAlign: 'center',
    lineHeight: 23,
    marginBottom: 20,
  },
  bulletList: {
    width: '100%',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 14,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  bulletRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  bulletIcon: {
    marginRight: 12,
  },
  bulletText: {
    color: '#fff',
    fontSize: 15,
    flex: 1,
  },
  readyCard: {
    width: '100%',
    backgroundColor: 'rgba(16,185,129,0.12)',
    borderRadius: 14,
    padding: 18,
    marginTop: 12,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.4)',
  },
  readyTitle: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 8,
    textAlign: 'center',
  },
  readyText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 21,
  },
  footer: {
    paddingHorizontal: 24,
    paddingBottom: 36,
    paddingTop: 20,
    alignItems: 'center',
    gap: 18,
  },
  dots: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.25)',
  },
  dotActive: {
    width: 24,
    backgroundColor: '#10B981',
  },
  dotDone: {
    backgroundColor: 'rgba(16,185,129,0.6)',
  },
  nextBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 14,
    minWidth: 180,
    gap: 8,
  },
  nextText: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '700',
  },
});
