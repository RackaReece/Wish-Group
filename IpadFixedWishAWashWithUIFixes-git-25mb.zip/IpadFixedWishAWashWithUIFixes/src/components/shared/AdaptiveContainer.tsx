/**
 * Wraps content with adaptive width and centering for iPad.
 * On tablet: applies maxWidth and alignSelf center so content doesn’t stretch.
 * On phone: passes through with optional horizontal padding.
 */
import React from 'react';
import { View, ViewStyle } from 'react-native';
import { useAdaptiveLayout } from '../../constants/adaptiveLayout';

type AdaptiveContainerProps = {
  children: React.ReactNode;
  style?: ViewStyle;
  /** If true, apply horizontal padding from adaptive layout. Default true. */
  withPadding?: boolean;
  /** If true, constrain and center on tablet. Default true. */
  constrainOnTablet?: boolean;
};

export default function AdaptiveContainer({
  children,
  style,
  withPadding = true,
  constrainOnTablet = true,
}: AdaptiveContainerProps) {
  const adaptive = useAdaptiveLayout();

  const containerStyle: ViewStyle = {
    ...(withPadding && { paddingHorizontal: adaptive.horizontalPadding }),
    ...(constrainOnTablet && adaptive.isTablet && {
      maxWidth: adaptive.contentMaxWidth,
      alignSelf: 'center',
      width: '100%',
    }),
  };

  return <View style={[containerStyle, style]}>{children}</View>;
}
