import React from 'react';
import { TouchableOpacity, StyleSheet, View, ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { BOOKING_CARD } from '../../constants/bookingCardTheme';

const SIZE = 32;
const ICON_SIZE = 20;

export interface InfoIconButtonProps {
  onPress: () => void;
  /** Accent color for icon and border (e.g. SKY, service color). */
  accentColor: string;
  style?: ViewStyle;
  /** Hit slop for touch area. Default 14. */
  hitSlop?: number;
  /** Optional icon name (Ionicons). Default "information-circle". */
  icon?: keyof typeof Ionicons.glyphMap;
}

/**
 * Info icon button for booking flow cards. Uses a solid background so it
 * renders reliably on all platforms (BlurView can fail on Android/some contexts).
 */
export default function InfoIconButton({
  onPress,
  accentColor,
  style,
  hitSlop = 14,
  icon = 'information-circle',
}: Readonly<InfoIconButtonProps>) {
  const borderColor = accentColor + '50';
  const backgroundColor = accentColor + '22';

  return (
    <TouchableOpacity
      onPress={onPress}
      hitSlop={{ top: hitSlop, bottom: hitSlop, left: hitSlop, right: hitSlop }}
      style={[styles.wrap, style]}
      activeOpacity={0.8}
    >
      <View style={[styles.btn, { borderColor, backgroundColor }]}>
        <Ionicons name={icon} size={ICON_SIZE} color={accentColor} />
      </View>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  wrap: {
    marginLeft: 4,
  },
  btn: {
    width: SIZE,
    height: SIZE,
    borderRadius: Math.min(BOOKING_CARD.BORDER_RADIUS, 12),
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
  },
});
