import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  Modal,
  Pressable,
  ScrollView,
  TouchableOpacity,
  Image,
  Dimensions,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

const { width: WINDOW_WIDTH, height: WINDOW_HEIGHT } = Dimensions.get('window');
const CARD_MAX_WIDTH = Math.min(WINDOW_WIDTH - 32, 360);
const CARD_MAX_HEIGHT = Math.min(WINDOW_HEIGHT * 0.88, 620);

export type VehicleInfoOverlayVehicle = {
  id: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  image_url?: string | null;
  photo?: string | null;
  type?: string | null;
  size?: string | null;
  mot_expiry?: string | null;
  mot_expiry_date?: string | null;
  tax_status?: string | null;
  tax_due_date?: string | null;
  tax_expiry?: string | null;
  mileage?: string | number | null;
};

export type VehicleStats = {
  washCount: number;
  lastCleanedAt: string | null;
  cleanRating: number | null;
};

type VehicleInfoOverlayProps = {
  visible: boolean;
  vehicle: VehicleInfoOverlayVehicle | null;
  stats: VehicleStats;
  accentColor: string;
  onClose: () => void;
};

function formatSize(size: string | null | undefined): string {
  if (!size) return '';
  const s = String(size).toLowerCase();
  if (s === 'small') return 'S';
  if (s === 'medium') return 'M';
  if (s === 'large') return 'L';
  if (s === 'xl') return 'XL';
  if (s === 'xxl') return 'XXL';
  return s.charAt(0).toUpperCase() + s.slice(1);
}

function formatDate(iso: string | null | undefined): string {
  if (!iso) return '—';
  try {
    return new Date(iso).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch {
    return '—';
  }
}

function formatMot(expiry: string | null | undefined): string {
  if (!expiry) return '—';
  try {
    return new Date(expiry).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
  } catch {
    return String(expiry);
  }
}

function getMotStatus(expiry: string | null | undefined): string {
  if (!expiry) return '—';
  try {
    const d = new Date(expiry);
    const dateStr = d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
    return d >= new Date() ? `Valid until ${dateStr}` : `Expired ${dateStr}`;
  } catch {
    return String(expiry);
  }
}

function getTaxStatus(
  status: string | null | undefined,
  dueDate: string | null | undefined,
  expiry: string | null | undefined
): string {
  const dateStr = dueDate || expiry;
  if (dateStr) {
    try {
      const d = new Date(dateStr);
      const formatted = d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
      if (d >= new Date()) return `Valid until ${formatted}`;
      return `Expired ${formatted}`;
    } catch {
      // fall through
    }
  }
  if (status && String(status).trim()) return String(status).trim();
  return '—';
}

export function VehicleInfoOverlay({
  visible,
  vehicle,
  stats,
  accentColor,
  onClose,
}: VehicleInfoOverlayProps) {
  const insets = useSafeAreaInsets();

  if (!visible) return null;

  const imageUri = vehicle?.image_url ?? vehicle?.photo ?? null;
  const motDate = vehicle?.mot_expiry_date ?? vehicle?.mot_expiry ?? null;
  const taxDue = vehicle?.tax_due_date ?? vehicle?.tax_expiry ?? null;
  const mileage =
    vehicle?.mileage != null && vehicle.mileage !== ''
      ? typeof vehicle.mileage === 'number'
        ? vehicle.mileage.toLocaleString()
        : String(vehicle.mileage)
      : null;

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      onRequestClose={onClose}
      statusBarTranslucent
      supportedOrientations={['portrait', 'portrait-upside-down', 'landscape']}
      presentationStyle="overFullScreen"
    >
      <Pressable style={[styles.overlay, { paddingTop: insets.top, paddingBottom: insets.bottom }]} onPress={onClose}>
        <Pressable
          style={[
            styles.contentWrap,
            {
              width: CARD_MAX_WIDTH,
              height: CARD_MAX_HEIGHT,
              marginHorizontal: 16,
            },
          ]}
          onPress={(e) => e.stopPropagation()}
        >
          <View style={styles.cardOuter}>
            <LinearGradient
              colors={['rgba(30,41,59,0.98)', 'rgba(15,23,42,0.98)']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
            />
            <View style={[styles.cardBorder, { borderColor: accentColor + '40' }]}>
              {/* Header */}
              <View style={[styles.header, { borderBottomColor: accentColor + '30' }]}>
                <View style={[styles.accentPill, { backgroundColor: accentColor + '25' }]}>
                  <Ionicons name="car-sport" size={18} color={accentColor} />
                  <Text style={[styles.headerTitle, { color: accentColor }]}>Vehicle details</Text>
                </View>
                <TouchableOpacity onPress={onClose} style={styles.closeBtn} hitSlop={12} activeOpacity={0.8}>
                  <Ionicons name="close" size={24} color="#94A3B8" />
                </TouchableOpacity>
              </View>

              {!vehicle ? (
                <View style={styles.loadingState}>
                  <Text style={styles.loadingText}>Loading…</Text>
                  <TouchableOpacity onPress={onClose} style={[styles.doneBtn, { backgroundColor: accentColor }]} activeOpacity={0.9}>
                    <Text style={styles.doneText}>Close</Text>
                  </TouchableOpacity>
                </View>
              ) : (
                <>
                  <ScrollView
                    style={styles.scroll}
                    contentContainerStyle={[styles.scrollContent, { paddingBottom: 32 }]}
                    showsVerticalScrollIndicator={true}
                    scrollEnabled={true}
                    bounces={true}
                    nestedScrollEnabled={true}
                  >
                    {/* Photo */}
                    <View style={[styles.photoWrap, { borderColor: accentColor + '35' }]}>
                      {imageUri ? (
                        <Image source={{ uri: imageUri }} style={styles.photo} resizeMode="cover" />
                      ) : (
                        <View style={[styles.photoPlaceholder, { backgroundColor: accentColor + '15' }]}>
                          <Ionicons name="car-sport-outline" size={52} color={accentColor} style={{ opacity: 0.6 }} />
                        </View>
                      )}
                    </View>

                    <Text style={styles.makeModel} numberOfLines={2}>
                      {vehicle.make} {vehicle.model}
                    </Text>
                    <Text style={styles.regLine}>{vehicle.color} · {vehicle.registration}</Text>

                    {/* Service history – compact, so it fits with MOT/tax */}
                    <View style={styles.sectionCompact}>
                      <Text style={styles.sectionLabel}>Service history</Text>
                      <View style={styles.statsGrid}>
                        <View style={[styles.statChip, { borderColor: '#10B981' + '40', backgroundColor: '#10B981' + '12' }]}>
                          <Ionicons name="water" size={14} color="#10B981" />
                          <Text style={styles.statChipText}>{stats.washCount} wash{stats.washCount !== 1 ? 'es' : ''}</Text>
                        </View>
                        <View style={[styles.statChip, { borderColor: accentColor + '40', backgroundColor: accentColor + '12' }]}>
                          <Ionicons name="calendar" size={14} color={accentColor} />
                          <Text style={styles.statChipText}>{formatDate(stats.lastCleanedAt)}</Text>
                        </View>
                        <View style={[styles.statChip, { borderColor: '#EAB308' + '40', backgroundColor: '#EAB308' + '12' }]}>
                          <Ionicons name="star" size={14} color="#EAB308" />
                          <Text style={styles.statChipText}>{stats.cleanRating != null ? `${stats.cleanRating}/5` : '—'}</Text>
                        </View>
                      </View>
                    </View>

                    {/* MOT & Tax & details */}
                    <View style={styles.sectionCompact}>
                      <Text style={styles.sectionLabel}>MOT & tax</Text>
                      <View style={styles.rows}>
                        {[
                          { icon: 'shield-checkmark' as const, label: 'MOT status', value: getMotStatus(motDate) },
                          { icon: 'receipt-outline' as const, label: 'Tax status', value: getTaxStatus(vehicle.tax_status, vehicle.tax_due_date, taxDue) },
                          mileage != null ? { icon: 'speedometer' as const, label: 'Mileage', value: `${mileage} miles` } : null,
                          vehicle.size ? { icon: 'resize' as const, label: 'Size', value: formatSize(vehicle.size) } : null,
                          vehicle.type ? { icon: 'shapes' as const, label: 'Type', value: vehicle.type } : null,
                        ]
                          .filter(Boolean)
                          .map((item, index, arr) => (
                            <View
                              key={item!.label}
                              style={[styles.row, index === arr.length - 1 && styles.rowLast]}
                            >
                              <Ionicons name={item!.icon} size={18} color={accentColor} />
                              <Text style={styles.rowLabel}>{item!.label}</Text>
                              <Text style={styles.rowValue}>{item!.value}</Text>
                            </View>
                          ))}
                      </View>
                    </View>
                  </ScrollView>

                  <TouchableOpacity
                    onPress={onClose}
                    style={[styles.doneBtn, { backgroundColor: accentColor }]}
                    activeOpacity={0.9}
                  >
                    <Text style={styles.doneText}>Done</Text>
                  </TouchableOpacity>
                </>
              )}
            </View>
          </View>
        </Pressable>
      </Pressable>
    </Modal>
  );
}

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 9999,
    elevation: 9999,
  },
  contentWrap: {
    width: '100%',
    borderRadius: 20,
    overflow: 'hidden',
    zIndex: 10000,
    elevation: 10000,
    ...Platform.select({
      ios: {
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 8 },
        shadowOpacity: 0.4,
        shadowRadius: 20,
      },
      android: {
        elevation: 16,
      },
    }),
  },
  cardOuter: {
    flex: 1,
    minHeight: 0,
    borderRadius: 20,
    overflow: 'hidden',
  },
  cardBorder: {
    flex: 1,
    minHeight: 0,
    borderRadius: 20,
    borderWidth: 1,
    overflow: 'hidden',
    backgroundColor: 'transparent',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 16,
    paddingHorizontal: 18,
    borderBottomWidth: 1,
  },
  accentPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 12,
  },
  headerTitle: {
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  closeBtn: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(148,163,184,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingState: {
    padding: 24,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: 160,
  },
  loadingText: {
    color: '#94A3B8',
    fontSize: 16,
    marginBottom: 16,
  },
  scroll: {
    flex: 1,
    minHeight: 0,
  },
  scrollContent: {
    paddingHorizontal: 18,
    paddingTop: 16,
    paddingBottom: 20,
    flexGrow: 0,
  },
  photoWrap: {
    height: 88,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 10,
    borderWidth: 1,
  },
  photo: {
    width: '100%',
    height: '100%',
  },
  photoPlaceholder: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  makeModel: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 4,
    letterSpacing: 0.2,
  },
  regLine: {
    color: '#B8C5D6',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 12,
  },
  section: {
    marginBottom: 18,
  },
  sectionCompact: {
    marginBottom: 12,
  },
  sectionLabel: {
    color: '#B8C5D6',
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.8,
    marginBottom: 10,
  },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  statChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 8,
    borderWidth: 1,
  },
  statChipText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '600',
  },
  rows: {
    backgroundColor: 'rgba(30,41,59,0.95)',
    borderRadius: 10,
    padding: 10,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.35)',
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 8,
    paddingHorizontal: 4,
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(148,163,184,0.25)',
  },
  rowLast: {
    borderBottomWidth: 0,
  },
  rowLabel: {
    color: '#B8C5D6',
    fontSize: 14,
    flex: 0,
    minWidth: 80,
  },
  rowValue: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
    flex: 1,
    textAlign: 'right',
  },
  doneBtn: {
    marginHorizontal: 18,
    marginTop: 4,
    marginBottom: 18,
    paddingVertical: 16,
    borderRadius: 14,
    alignItems: 'center',
  },
  doneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
  },
});
