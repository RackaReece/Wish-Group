import React, { useState, useEffect, useRef, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Easing,
  Dimensions,
  ScrollView,
  ActivityIndicator,
  StatusBar,
  Alert,
  Image,
  Pressable,
  Modal,
  TextInput,
} from 'react-native';
import MapView, { Marker, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useFocusEffect } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../providers/enhanced-auth-context';
import { supabase } from '../../lib/supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import GradientNotificationBell from '../shared/GradientNotificationBell';
import AppHeader from '../shared/AppHeader';
import BubbleBackground from '../shared/BubbleBackground';
import useLiveLocation from '../../hooks/useLiveLocation';
import { customerTheme } from '../../constants/customerTheme';
import { colors } from '../../constants/colors';
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;
import { getServiceDisplayName } from '../../utils/serviceNameMapper';
import { ValeterStatsService } from '../../services/Valeterstatsservice';
import { WashHubStatsService } from '../../services/WashHubStatsService';
import { fetchProfileById } from '../../utils/customerProfiles';
import { formatDisplayName } from '../../utils/formatDisplayName';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../app/components/NavigationTab';
import { getDashboardHeaderTopOffset } from '../../constants/layoutConstants';
import { SkeletonList } from '../shared/SkeletonLoader';
import AnimatedProgress from '../booking/AnimatedProgress';
import { CAR_IMAGE, CARWASH_IMAGE, VALETER_IMAGE, VALETER_MAP_IMAGE } from '../../constants/appAssets';
import { HEADER_STYLE_CARD_GRADIENT } from '../../constants/bookingCardTheme';
import { BlurView } from 'expo-blur';
import { useAdaptiveLayout } from '../../constants/adaptiveLayout';
import { BOOKING_MAP_STYLE, MAP_LOCKED_DARK } from '../../constants/mapConstants';

const { width } = Dimensions.get('window');

const HERO_SUBTEXTS = [
  'Wash, valet & detailing services',
  'Available in your area now',
  'Average arrival: 12 mins',
  'Evening slots filling fast',
];

function getValeterInitials(name: string | null): string {
  if (!name?.trim()) return '—';
  const parts = name.trim().split(/\s+/);
  if (parts.length >= 2) {
    const lastInitial = parts.at(-1)?.[0] ?? '';
    return (parts[0][0] + lastInitial).toUpperCase().slice(0, 2);
  }
  return name.slice(0, 2).toUpperCase();
}
const CUSTOMER_RADIUS_MILES = 25;
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY;

interface NearbyValeter {
  id: string;
  name: string;
  organization: string;
  rating: number;
  distance: number | null;
  isOnline: boolean;
}

interface ValeterReview {
  rating: number;
  review?: string | null;
}

interface TopValeter {
  id: string;
  name: string;
  organization: string;
  rating: number;
  jobsCompleted: number;
  isOnline: boolean;
  profilePicture?: string | null;
  joinedAt?: string | null;
  reviews?: ValeterReview[];
}

interface CarWashReview {
  rating: number;
  review?: string | null;
}

interface TopCarWash {
  id: string;
  name: string;
  address: string;
  rating: number;
  jobsCompleted: number;
  distanceMiles: number | null;
  imageUrl?: string | null;
  joinedAt?: string | null;
  reviews?: CarWashReview[];
}

interface LoyaltyData {
  points: number;
  tier: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  pointsToNextTier: number;
  nextReward?: string;
}

type DbBookingStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled' | 'pending_payment' | 'pending_valeter_acceptance' | 'pending' | 'confirmed' | 'valeter_assigned' | 'en_route' | 'arrived';

type ActiveBooking = {
  id: string;
  status: DbBookingStatus;
  service_type: string;
  service_name: string | null;
  location_address: string | null;
  scheduled_at: string;
  price: number;
  valeter_name: string | null;
  valeter_id: string | null;
  latitude: number | null;
  longitude: number | null;
};

const ACTIVE_STATUSES: DbBookingStatus[] = ['scheduled', 'in_progress', 'pending_payment', 'pending_valeter_acceptance', 'pending', 'confirmed', 'valeter_assigned', 'en_route', 'arrived'];

function getStatusProgress(status: string): number {
  switch (status) {
    case 'pending_valeter_acceptance':
    case 'pending_payment':
    case 'pending':
      return 20;
    case 'confirmed':
    case 'valeter_assigned':
      return 40;
    case 'en_route':
      return 60;
    case 'arrived':
      return 80;
    case 'in_progress':
      return 90;
    case 'completed':
    case 'cancelled':
      return 100;
    default:
      return 0;
  }
}

function getStatusRingColor(status: string): string {
  switch (status) {
    case 'pending_valeter_acceptance':
    case 'pending_payment':
    case 'pending':
      return '#F59E0B';
    case 'confirmed':
    case 'valeter_assigned':
      return '#8B5CF6';
    case 'en_route':
    case 'arrived':
      return '#10B981';
    case 'in_progress':
      return SKY;
    default:
      return SKY;
  }
}

type ActiveBookingSectionProps = Readonly<{
  activeBookingLoading: boolean;
  activeBooking: ActiveBooking | null;
  activeBookingMapRegion: Region | null;
  userLocation: { latitude: number; longitude: number } | null;
  valeterLocation: { latitude: number; longitude: number } | null;
  onResumeTracking: () => void;
  styles: Record<string, object>;
  eta?: number | null;
  loyaltyData?: LoyaltyData | null;
  reservedCounts?: { nearbyValeters: number; carWashCount: number; detailingHubCount: number; recentBookingsLoading: boolean };
  sectionStyle?: any;
}>;

function ActiveBookingSection({
  activeBookingLoading,
  activeBooking,
  activeBookingMapRegion,
  userLocation,
  valeterLocation,
  onResumeTracking,
  styles: s,
  eta: _eta,
  loyaltyData: _loyaltyData,
  reservedCounts: _reservedCounts,
  sectionStyle,
}: ActiveBookingSectionProps) {
  if (activeBookingLoading) {
    return (
      <View style={[s.activeBookingSection, sectionStyle]}>
        <View style={s.activeBookingSkeleton}>
          <ActivityIndicator size="small" color={SKY} />
          <Text style={s.activeBookingLoadingText}>Checking active trip…</Text>
        </View>
      </View>
    );
  }
  if (activeBooking?.status === 'pending_payment') {
    return (
      <View style={[s.activeBookingSection, sectionStyle]}>
        <TouchableOpacity
          activeOpacity={0.9}
          onPress={() => activeBooking?.id && router.push({ pathname: '/owner/booking/payment', params: { bookingId: activeBooking.id } } as any)}
          style={s.activeBookingCard}
          disabled={false}
        >
          <View style={s.activeBookingMapContainer}>
            {activeBookingMapRegion && userLocation ? (
              <>
                <MapView
                  style={StyleSheet.absoluteFill}
                  region={activeBookingMapRegion}
                  scrollEnabled={false}
                  zoomEnabled={false}
                  pitchEnabled={false}
                  rotateEnabled={false}
                  customMapStyle={BOOKING_MAP_STYLE}
                  userInterfaceStyle={MAP_LOCKED_DARK}
                >
                  <Marker coordinate={userLocation}>
                    <View style={s.mapMarkerContainer}>
                      <Image source={CAR_IMAGE} style={s.mapMarkerImage} resizeMode="contain" />
                    </View>
                  </Marker>
                  {activeBooking.latitude != null && activeBooking.longitude != null && (
                    <Marker coordinate={{ latitude: activeBooking.latitude, longitude: activeBooking.longitude }}>
                      <View style={[s.mapMarkerContainer, { backgroundColor: 'rgba(245,158,11,0.9)' }]}>
                        <Ionicons name="location" size={20} color="#0A1929" />
                      </View>
                    </Marker>
                  )}
                </MapView>
                <LinearGradient colors={['transparent', 'rgba(0,0,0,0.75)']} style={StyleSheet.absoluteFill} />
              </>
            ) : (
              <LinearGradient colors={['rgba(245,158,11,0.2)', 'rgba(217,119,6,0.25)']} style={StyleSheet.absoluteFill} />
            )}
            <View style={s.activeBookingCardOverlay}>
              <View style={s.activeBookingRingWrap}>
                <AnimatedProgress progress={getStatusProgress(activeBooking.status)} size={72} strokeWidth={8} showPercentage={true} percentageFontSize={14} color={getStatusRingColor(activeBooking.status)} colorCycle={[SKY, '#10B981', '#8B5CF6', '#F59E0B']} />
              </View>
              <View style={s.activeBookingCardContent}>
                <Text style={s.activeBookingTitle}>Payment due</Text>
                <Text style={s.activeBookingSubtitle} numberOfLines={1}>
                  {getServiceDisplayName(activeBooking.service_type, activeBooking.service_name)}
                </Text>
                {!!activeBooking.valeter_name && (
                  <Text style={s.activeBookingValeter} numberOfLines={1}>
                    {activeBooking.service_type?.includes('detailing') ? 'Detailer' : 'Valeter'}: {activeBooking.valeter_name}
                  </Text>
                )}
                <View style={[s.activeBookingStatusPill, { backgroundColor: '#F59E0B' }]}>
                  <Text style={[s.activeBookingStatusText, { color: '#0A1929' }]}>Pay now</Text>
                  <Ionicons name="chevron-forward" size={14} color="#0A1929" />
                </View>
              </View>
            </View>
            <View style={s.activeBookingBottomRow}>
              <View style={s.activeBookingPriceWrap}>
                <Ionicons name="wallet-outline" size={15} color={LIGHT_SKY} />
                <Text style={s.activeBookingPrice}>£{Number(activeBooking.price || 0).toFixed(2)}</Text>
              </View>
              <TouchableOpacity
                onPress={(e) => { e?.stopPropagation?.(); hapticFeedback('light'); router.push({ pathname: '/owner/booking/chat', params: { bookingId: activeBooking.id } } as any); }}
                style={s.activeBookingChatBtn}
                hitSlop={8}
              >
                <Ionicons name="chatbubble-ellipses-outline" size={20} color="#F59E0B" />
              </TouchableOpacity>
              <View style={s.activeBookingCta}>
                <Text style={s.activeBookingMetaCta}>Complete payment</Text>
                <Ionicons name="chevron-forward" size={18} color="#F59E0B" />
              </View>
            </View>
          </View>
        </TouchableOpacity>
      </View>
    );
  }
  if (activeBooking) {
    return (
      <View style={[s.activeBookingSection, sectionStyle]}>
        <TouchableOpacity activeOpacity={0.9} onPress={onResumeTracking} style={s.activeBookingCard}>
          <View style={s.activeBookingMapContainer}>
            {activeBookingMapRegion && userLocation ? (
              <>
                <MapView
                  style={StyleSheet.absoluteFill}
                  region={activeBookingMapRegion}
                  scrollEnabled={false}
                  zoomEnabled={false}
                  pitchEnabled={false}
                  rotateEnabled={false}
                  customMapStyle={BOOKING_MAP_STYLE}
                  userInterfaceStyle={MAP_LOCKED_DARK}
                >
                  <Marker coordinate={userLocation}>
                    <View style={s.mapMarkerContainer}>
                      <Image source={CAR_IMAGE} style={s.mapMarkerImage} resizeMode="contain" />
                    </View>
                  </Marker>
                  {valeterLocation && (
                    <Marker coordinate={valeterLocation}>
                      <View style={s.mapMarkerContainer}>
                        <Image source={VALETER_MAP_IMAGE} style={s.mapMarkerImage} resizeMode="contain" />
                      </View>
                    </Marker>
                  )}
                  {activeBooking.latitude != null && activeBooking.longitude != null && !valeterLocation && (
                    <Marker coordinate={{ latitude: activeBooking.latitude, longitude: activeBooking.longitude }}>
                      <View style={[s.mapMarkerContainer, { backgroundColor: 'rgba(135,206,235,0.9)' }]}>
                        <Ionicons name="location" size={20} color="#0A1929" />
                      </View>
                    </Marker>
                  )}
                </MapView>
                <LinearGradient colors={['transparent', 'rgba(0,0,0,0.75)']} style={StyleSheet.absoluteFill} />
              </>
            ) : (
              <LinearGradient colors={['rgba(135,206,235,0.24)', 'rgba(30,58,138,0.3)']} style={StyleSheet.absoluteFill} />
            )}
            <View style={s.activeBookingCardOverlay}>
              <View style={s.activeBookingRingWrap}>
                <AnimatedProgress progress={getStatusProgress(activeBooking.status)} size={72} strokeWidth={8} showPercentage={true} percentageFontSize={14} color={getStatusRingColor(activeBooking.status)} colorCycle={[SKY, '#10B981', '#8B5CF6', '#F59E0B']} />
              </View>
              <View style={s.activeBookingCardContent}>
                <Text style={s.activeBookingTitle}>Active trip</Text>
                <Text style={s.activeBookingSubtitle} numberOfLines={1}>
                  {getServiceDisplayName(activeBooking.service_type, activeBooking.service_name)}
                </Text>
                {!!activeBooking.valeter_name && (
                  <Text style={s.activeBookingValeter} numberOfLines={1}>
                    {activeBooking.service_type?.includes('detailing') ? 'Detailer' : 'Valeter'}: {activeBooking.valeter_name}
                  </Text>
                )}
                <View style={s.activeBookingStatusPill}>
                  <Text style={s.activeBookingStatusText}>Track on map</Text>
                  <Ionicons name="chevron-forward" size={14} color="#0A1929" />
                </View>
              </View>
            </View>
            <View style={s.activeBookingBottomRow}>
              <View style={s.activeBookingPriceWrap}>
                <Ionicons name="wallet-outline" size={15} color={LIGHT_SKY} />
                <Text style={s.activeBookingPrice}>£{Number(activeBooking.price || 0).toFixed(2)}</Text>
              </View>
              <TouchableOpacity
                onPress={(e) => { e?.stopPropagation?.(); hapticFeedback('light'); router.push({ pathname: '/owner/booking/chat', params: { bookingId: activeBooking.id } } as any); }}
                style={s.activeBookingChatBtn}
                hitSlop={8}
              >
                <Ionicons name="chatbubble-ellipses-outline" size={20} color={SKY} />
              </TouchableOpacity>
              <View style={s.activeBookingCta}>
                <Text style={s.activeBookingMetaCta}>Track trip</Text>
                <Ionicons name="chevron-forward" size={18} color={SKY} />
              </View>
            </View>
          </View>
        </TouchableOpacity>
      </View>
    );
  }
  return null;
}

function getValetersEmptyMessage(availabilityFilter: 'today' | 'tomorrow' | 'next_week'): string {
  if (availabilityFilter === 'today') return 'No valeters available today';
  if (availabilityFilter === 'tomorrow') return 'No valeters scheduled for tomorrow';
  return 'No valeters available next week';
}

export default function EnhancedCustomerDashboard() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const adaptive = useAdaptiveLayout();
  const isTabletLayout = adaptive.isTablet;
  const horizontalInset = adaptive.horizontalPadding;
  const contentMaxWidth = adaptive.isTablet ? adaptive.contentMaxWidth : undefined;
  const sectionContainerStyle = isTabletLayout
    ? { width: '100%' as const, maxWidth: contentMaxWidth, alignSelf: 'center' as const }
    : undefined;
  const tabletSectionMarginReset = isTabletLayout ? { marginHorizontal: 0 } : undefined;

  const [nearbyValeters, setNearbyValeters] = useState<NearbyValeter[]>([]); // value reserved for future UI
  const [carWashCount, setCarWashCount] = useState(0); // value reserved for future UI
  const [detailingHubCount, setDetailingHubCount] = useState(0); // value reserved for future UI
  const [loading, setLoading] = useState(true);
  const [profileName, setProfileName] = useState<string>('');
  const [headerProfilePicture, setHeaderProfilePicture] = useState<string | null>(null);
  const [notificationCount, setNotificationCount] = useState(0);
  const [weeklyStats, setWeeklyStats] = useState({
    washesToday: 0,
    washesThisWeek: 0,
    totalWashes: 0,
  });

  const [activeBooking, setActiveBooking] = useState<ActiveBooking | null>(null);
  const [activeBookingLoading, setActiveBookingLoading] = useState(false);
  const [recentBookings, setRecentBookings] = useState<ActiveBooking[]>([]);
  const [recentBookingsLoading, setRecentBookingsLoading] = useState(false); // value reserved for future UI
  const [valeterLocation, setValeterLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [eta, setEta] = useState<number | null>(null); // value reserved for future ETA display
  const valeterPresenceChannelRef = useRef<any>(null);

  const [topValeters, setTopValeters] = useState<TopValeter[]>([]);
  const [topCarWashes, setTopCarWashes] = useState<TopCarWash[]>([]);
  const [topRatedTab, setTopRatedTab] = useState<'valeters' | 'carwash'>('valeters');
  const [availabilityFilter, setAvailabilityFilter] = useState<'today' | 'tomorrow' | 'next_week'>('today');
  const [showAvailabilityPicker, setShowAvailabilityPicker] = useState(false);
  const [infoValeter, setInfoValeter] = useState<TopValeter | null>(null);
  const [infoCarWash, setInfoCarWash] = useState<TopCarWash | null>(null);
  const [failedValeterImageIds, setFailedValeterImageIds] = useState<Set<string>>(new Set());

  const [heroSubtextIndex, setHeroSubtextIndex] = useState(0);
  const [dashboardSearchQuery, setDashboardSearchQuery] = useState('');
  const heroGradientAnim = useRef(new Animated.Value(0)).current;
  const quickScale0 = useRef(new Animated.Value(1)).current;
  const quickScale1 = useRef(new Animated.Value(1)).current;
  const quickScale2 = useRef(new Animated.Value(1)).current;
  const quickScale3 = useRef(new Animated.Value(1)).current;
  const quickScale4 = useRef(new Animated.Value(1)).current;

  // Reserved for header points + notifications logic (values reserved for future UI)
  const loyaltyData = useMemo<LoyaltyData | null>(
    () => ({
      points: 850,
      tier: 'Silver',
      pointsToNextTier: 150,
      nextReward: '50 points = 10% off next wash',
    }),
    []
  );

  const { refresh } = useLiveLocation();

  const notificationStatuses = useMemo(
    () => [
      'pending',
      'pending_valeter_acceptance',
      'pending_payment',
      'confirmed',
      'valeter_assigned',
      'en_route',
      'arrived',
      'in_progress',
      'scheduled',
      'completed',
      'cancelled',
    ],
    []
  );

  const filteredTopValeters = useMemo(() => {
    if (availabilityFilter === 'today') return topValeters.filter((v) => v.isOnline);
    if (availabilityFilter === 'tomorrow') return topValeters.filter((v) => !v.isOnline);
    return topValeters;
  }, [topValeters, availabilityFilter]);

  const refreshRef = useRef(refresh);
  useEffect(() => {
    refreshRef.current = refresh;
  }, [refresh]);

  useEffect(() => {
    const interval = setInterval(() => {
      refreshRef.current?.();
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const scrollY = useRef(new Animated.Value(0)).current;

  // Animated bubbles for header background
  const bubbleData = useRef(
    Array.from({ length: 8 }, (_, index) => {
      const random = Math.random();
      return {
        translateY: new Animated.Value(0),
        opacity: new Animated.Value(0.2 + random * 0.2),
        scale: new Animated.Value(0.6 + random * 0.3),
        size: 20 + random * 30,
        leftPosition: width * 0.6 + random * width * 0.3,
        delay: index * 800,
        duration: 12000 + random * 8000,
        startY: 120 + random * 40,
        endY: -60,
        initialOpacity: 0.2 + random * 0.2,
      };
    })
  ).current;

  useEffect(() => {
    bubbleData.forEach((bubble) => {
      bubble.translateY.setValue(bubble.startY);
      bubble.opacity.setValue(bubble.initialOpacity);

      Animated.parallel([
        Animated.loop(
          Animated.sequence([
            Animated.delay(bubble.delay),
            Animated.timing(bubble.translateY, {
              toValue: bubble.endY,
              duration: bubble.duration,
              useNativeDriver: true,
            }),
            Animated.timing(bubble.translateY, {
              toValue: bubble.startY,
              duration: 0,
              useNativeDriver: true,
            }),
          ])
        ),
        Animated.loop(
          Animated.sequence([
            Animated.timing(bubble.opacity, {
              toValue: 0.35,
              duration: bubble.duration / 3,
              easing: Easing.inOut(Easing.ease),
              useNativeDriver: true,
            }),
            Animated.timing(bubble.opacity, {
              toValue: 0.15,
              duration: bubble.duration / 3,
              easing: Easing.inOut(Easing.ease),
              useNativeDriver: true,
            }),
            Animated.timing(bubble.opacity, {
              toValue: bubble.initialOpacity,
              duration: bubble.duration / 3,
              easing: Easing.inOut(Easing.ease),
              useNativeDriver: true,
            }),
          ])
        ),
      ]).start();
    });
  }, [bubbleData]);

  useEffect(() => {
    const t = setInterval(() => {
      setHeroSubtextIndex((i) => (i + 1) % HERO_SUBTEXTS.length);
    }, 4000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const loop = () => {
      heroGradientAnim.setValue(0);
      Animated.sequence([
        Animated.timing(heroGradientAnim, {
          toValue: 1,
          duration: 3500,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(heroGradientAnim, {
          toValue: 0,
          duration: 3500,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ]).start(() => loop());
    };
    loop();
  }, [heroGradientAnim]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.warn('Location permission not granted');
        return;
      }

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };

      setUserLocation(coords);
      // Recalculate ETA if valeter location exists
      if (valeterLocation) {
        calculateETA(valeterLocation);
      }
      return coords;
    } catch (error) {
      console.warn('Error getting location:', error);
      return null;
    }
  };

  const loadValeterLocation = async (valeterId: string) => {
    try {
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', valeterId)
        .maybeSingle();

      if (error) {
        console.warn('Error loading valeter location:', error);
        return;
      }

      if (data?.last_lat && data?.last_lng) {
        const valeterCoords = {
          latitude: Number(data.last_lat),
          longitude: Number(data.last_lng),
        };
        setValeterLocation(valeterCoords);
        calculateETA(valeterCoords);
      } else {
        setValeterLocation(null);
        setEta(null);
      }
    } catch (error) {
      console.warn('Error loading valeter location:', error);
    }
  };

  const calculateETA = (valeterCoords: { latitude: number; longitude: number }) => {
    if (!userLocation) return;

    const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
      const R = 3959; // Earth radius in miles
      const dLat = ((lat2 - lat1) * Math.PI) / 180;
      const dLon = ((lon2 - lon1) * Math.PI) / 180;
      const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos((lat1 * Math.PI) / 180) *
          Math.cos((lat2 * Math.PI) / 180) *
          Math.sin(dLon / 2) *
          Math.sin(dLon / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      return R * c;
    };

    const distance = calculateDistance(
      userLocation.latitude,
      userLocation.longitude,
      valeterCoords.latitude,
      valeterCoords.longitude
    );

    // Average speed: 25 mph in city, estimate ETA in minutes
    const averageSpeed = 25; // mph
    const timeInHours = distance / averageSpeed;
    const timeInMinutes = Math.round(timeInHours * 60);
    
    setEta(timeInMinutes);
  };

  const subscribeToValeterPresence = (valeterId: string) => {
    // Remove existing subscription
    if (valeterPresenceChannelRef.current) {
      supabase.removeChannel(valeterPresenceChannelRef.current);
      valeterPresenceChannelRef.current = null;
    }

    const channel = supabase
      .channel(`valeter-presence-dashboard-${valeterId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${valeterId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          if (updated?.last_lat && updated?.last_lng) {
            const valeterCoords = {
              latitude: Number(updated.last_lat),
              longitude: Number(updated.last_lng),
            };
            setValeterLocation(valeterCoords);
            calculateETA(valeterCoords);
          }
        }
      )
      .subscribe();

    valeterPresenceChannelRef.current = channel;
  };

  const loadActiveBooking = async () => {
    if (!user?.id) return;

    try {
      setActiveBookingLoading(true);

      const { data, error } = await supabase
        .from('bookings')
        .select('id,status,service_type,service_name,location_address,location_lat,location_lng,scheduled_at,price,valeter_name,valeter_id')
        .eq('user_id', user.id)
        .in('status', ACTIVE_STATUSES as any)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        console.warn('[CustomerDashboard] loadActiveBooking error:', error);
        setActiveBooking(null);
        return;
      }

      if (!data) {
        setActiveBooking(null);
        setValeterLocation(null);
        setEta(null);
        return;
      }

      const lat = data.location_lat == null ? null : Number(data.location_lat);
      const lng = data.location_lng == null ? null : Number(data.location_lng);

      setActiveBooking({
        id: data.id,
        status: data.status as DbBookingStatus,
        service_type: data.service_type,
        service_name: data.service_name ?? null,
        location_address: data.location_address ?? null,
        scheduled_at: data.scheduled_at,
        price: Number(data.price ?? 0),
        valeter_name: data.valeter_name ?? null,
        valeter_id: data.valeter_id ?? null,
        latitude: lat,
        longitude: lng,
      });

      if (data.valeter_id) {
        loadValeterLocation(data.valeter_id);
        subscribeToValeterPresence(data.valeter_id);
      } else {
        setValeterLocation(null);
        setEta(null);
      }
    } catch (e) {
      console.warn('[CustomerDashboard] loadActiveBooking exception:', e);
      setActiveBooking(null);
    } finally {
      setActiveBookingLoading(false);
    }
  };

  const loadRecentBookings = async () => {
    if (!user?.id) return;

    try {
      setRecentBookingsLoading(true);

      const { data, error } = await supabase
        .from('bookings')
        .select('id,status,service_type,service_name,location_address,scheduled_at,price,valeter_name,valeter_id')
        .eq('user_id', user.id)
        .is('cancelled_at', null)
        .in('status', ['completed', 'cancelled'] as any)
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) {
        console.warn('[CustomerDashboard] loadRecentBookings error:', error);
        setRecentBookings([]);
        return;
      }

      if (!data || data.length === 0) {
        setRecentBookings([]);
        return;
      }

      setRecentBookings(
        data.map((booking) => ({
          id: booking.id,
          status: booking.status as DbBookingStatus,
          service_type: booking.service_type,
          service_name: booking.service_name ?? null,
          location_address: booking.location_address ?? null,
          scheduled_at: booking.scheduled_at,
          price: Number(booking.price ?? 0),
          valeter_name: booking.valeter_name ?? null,
          valeter_id: booking.valeter_id ?? null,
          latitude: null,
          longitude: null,
        }))
      );
      // Keep washes today / week in sync with same completed-bookings source
      loadWeeklyStats();
    } catch (e) {
      console.warn('[CustomerDashboard] loadRecentBookings exception:', e);
      setRecentBookings([]);
    } finally {
      setRecentBookingsLoading(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;

    getCurrentLocation();
    loadActiveBooking();
    loadRecentBookings();

    const channel = supabase
      .channel(`customer-active-booking-${user.id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        () => {
          loadActiveBooking();
          loadRecentBookings();
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        (payload) => {
          const updated = payload.new as any;

          if (activeBooking?.id && updated?.id === activeBooking.id) {
            const newStatus = updated.status as DbBookingStatus;
            const terminalStatuses = ['completed', 'cancelled', 'valeter_declined', 'valeter_timeout'];

            if (terminalStatuses.includes(newStatus)) {
              setActiveBooking(null);
              loadRecentBookings();
              loadWeeklyStats();
            } else {
              setActiveBooking((prev) =>
                prev
                  ? {
                      ...prev,
                      status: newStatus,
                      valeter_name: updated.valeter_name ?? prev.valeter_name,
                      price: Number(updated.price ?? prev.price),
                      service_name: updated.service_name ?? prev.service_name,
                      location_address: updated.location_address ?? prev.location_address,
                    }
                  : prev
              );
            }
            return;
          }

          loadActiveBooking();
          loadRecentBookings();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      if (valeterPresenceChannelRef.current) {
        supabase.removeChannel(valeterPresenceChannelRef.current);
        valeterPresenceChannelRef.current = null;
      }
    };
  }, [user?.id, activeBooking?.id]);

  // Notifications count (unchanged)
  useEffect(() => {
    if (!user?.id) return;
    let isMounted = true;
    const DISMISSED_STORAGE_KEY = 'wishawash:dismissed-notifications-v1';

    const fetchVehicleReminders = async (
      userId: string
    ): Promise<Array<{ id: string; type: 'vehicle_reminder' }>> => {
      try {
        const { data: vehicles, error } = await supabase
          .from('customer_vehicles')
          .select('id,make,model,registration,tax_expiry,mot_expiry')
          .eq('user_id', userId);

        if (error || !vehicles) return [];

        const reminders: Array<{ id: string; type: 'vehicle_reminder' }> = [];
        const now = new Date();
        const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

        vehicles.forEach((vehicle) => {
          if (vehicle.tax_expiry) {
            const taxExpiry = new Date(vehicle.tax_expiry);
            if (taxExpiry <= thirtyDaysFromNow && taxExpiry >= now) {
              reminders.push({ id: `tax-reminder-${vehicle.id}`, type: 'vehicle_reminder' });
            }
          }
          if (vehicle.mot_expiry) {
            const motExpiry = new Date(vehicle.mot_expiry);
            if (motExpiry <= thirtyDaysFromNow && motExpiry >= now) {
              reminders.push({ id: `mot-reminder-${vehicle.id}`, type: 'vehicle_reminder' });
            }
          }
        });

        return reminders;
      } catch (error) {
        console.warn('[CustomerDashboard] Vehicle reminders error', error);
        return [];
      }
    };

    const fetchRewardNotifications = async (userId: string): Promise<Array<{ id: string; type: 'reward' }>> => {
      try {
        const { data: userData, error } = await supabase
          .from('users')
          .select('tier_points,tier')
          .eq('id', userId)
          .single();

        if (error || !userData) return [];

        const notifications: Array<{ id: string; type: 'reward' }> = [];
        const points = userData.tier_points || 0;
        const milestones = [500, 1000, 2000, 3000, 5000];
        const nextMilestone = milestones.find((m) => m > points);

        if (nextMilestone && points > 0) {
          const pointsNeeded = nextMilestone - points;
          if (pointsNeeded <= 100) {
            notifications.push({ id: `reward-milestone-${nextMilestone}`, type: 'reward' });
          }
        }

        return notifications;
      } catch (error) {
        console.warn('[CustomerDashboard] Reward notifications error', error);
        return [];
      }
    };

    const fetchNotificationCount = async () => {
      try {
        const [bookingsResult, vehicleReminders, rewardNotifications] = await Promise.all([
          supabase
            .from('bookings')
            .select(
              'id,status,service_name,service_type,price,created_at,updated_at,scheduled_at,time_slot,location_address,address,valeter_name'
            )
            .eq('user_id', user.id)
            .in('status', notificationStatuses as any)
            .order('created_at', { ascending: false })
            .limit(100),
          fetchVehicleReminders(user.id),
          fetchRewardNotifications(user.id),
        ]);

        if (!isMounted) return;

        const bookingNotifications: Array<{ id: string; type: 'booking' }> = [];
        if (!bookingsResult.error && bookingsResult.data) {
          bookingNotifications.push(
            ...bookingsResult.data.map((b) => ({
              id: `booking-${b.id}`,
              type: 'booking' as const,
            }))
          );
        }

        const allNotifications = [...bookingNotifications, ...vehicleReminders, ...rewardNotifications];

        try {
          const raw = await AsyncStorage.getItem(DISMISSED_STORAGE_KEY);
          const dismissedStore = raw ? JSON.parse(raw) : {};
          const dismissedIds = new Set(dismissedStore[user.id] || []);
          const visibleNotifications = allNotifications.filter((notif) => !dismissedIds.has(notif.id));
          setNotificationCount(visibleNotifications.length);
        } catch (storageError) {
          console.warn('[CustomerDashboard] Storage read error:', storageError);
          setNotificationCount(allNotifications.length);
        }
      } catch (error) {
        if (isMounted) {
          console.warn('[CustomerDashboard] Notification count exception:', error);
          setNotificationCount(0);
        }
      }
    };

    fetchNotificationCount();
    const interval = setInterval(fetchNotificationCount, 45000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [user?.id, notificationStatuses]);

  // Load profile name
  useEffect(() => {
    if (!user?.id) return;
    const loadProfile = async () => {
      const { data: profileData } = await supabase
        .from('profiles')
        .select('full_name, profile_picture')
        .eq('id', user.id)
        .maybeSingle();

      if (profileData) {
        setProfileName(profileData.full_name || user.name || 'Customer');
        const pic = (profileData as { profile_picture?: string | null }).profile_picture;
        setHeaderProfilePicture(pic && typeof pic === 'string' ? pic : null);
      } else {
        setProfileName(user.name || 'Customer');
        setHeaderProfilePicture(null);
      }
    };
    loadProfile();
  }, [user?.id]);

  const loadWeeklyStats = async () => {
    if (!user?.id) return;

    try {
      const now = new Date();
      const startOfToday = new Date(now);
      startOfToday.setHours(0, 0, 0, 0);
      const startOfWeek = new Date(now);
      startOfWeek.setDate(now.getDate() - now.getDay());
      startOfWeek.setHours(0, 0, 0, 0);

      // Fetch all completed bookings with date fields (use completed_at, updated_at, created_at for fallback)
      const { data: allBookings, error } = await supabase
        .from('bookings')
        .select('id, status, completed_at, updated_at, created_at')
        .eq('user_id', user.id)
        .eq('status', 'completed');

      if (error) {
        console.warn('[Dashboard] loadWeeklyStats error:', error);
        return;
      }

      const list = allBookings || [];
      const totalWashes = list.length;

      const toDate = (row: any) => {
        const raw = row?.completed_at ?? row?.updated_at ?? row?.created_at;
        if (!raw) return null;
        const d = new Date(raw);
        return Number.isFinite(d.getTime()) ? d : null;
      };

      let washesToday = 0;
      let washesThisWeek = 0;
      for (const row of list) {
        const d = toDate(row);
        if (!d) continue;
        if (d >= startOfToday) washesToday += 1;
        if (d >= startOfWeek) washesThisWeek += 1;
      }

      setWeeklyStats({
        washesToday,
        washesThisWeek,
        totalWashes,
      });
    } catch (err) {
      console.warn('[Dashboard] loadWeeklyStats exception:', err);
    }
  };

  const loadNearbyValeters = async () => {
    if (!user?.id) return;
    try {
      const { data: presence, error: presErr } = await supabase.from('valeter_presence').select('user_id, is_online').eq('is_online', true);

      if (presErr) console.warn('[NearbyValeters] presence error:', presErr);
      if (!presence || presence.length === 0) {
        setNearbyValeters([]);
        return;
      }

      const ids = presence.map((p) => p.user_id);
      const { data: profiles } = await supabase.from('valeter_profiles').select('user_id, display_name, company_name').in('user_id', ids);

      const list: NearbyValeter[] = (presence || []).map((p) => {
        const profile = profiles?.find((pr) => pr.user_id === p.user_id);
        return {
          id: p.user_id,
          name: profile?.display_name || 'Valeter',
          organization: profile?.company_name || 'Independent',
          rating: 4.5,
          distance: null,
          isOnline: p.is_online,
        };
      });

      setNearbyValeters(list.slice(0, 8));
    } catch (e) {
      console.error('[NearbyValeters] load error:', e);
      setNearbyValeters([]);
    }
  };

  const loadCarWashCount = async () => {
    try {
      const { count, error } = await supabase
        .from('car_wash_locations')
        .select('*', { count: 'exact', head: true });

      if (error) {
        console.warn('[CarWashCount] error:', error);
        return;
      }

      setCarWashCount(count || 0);
    } catch (e) {
      console.error('[CarWashCount] load error:', e);
    }
  };

  const loadDetailingHubCount = async () => {
    try {
      // Check if there's a separate detailing_hubs table, or filter car_wash_locations by service_type
      const { count, error } = await supabase
        .from('car_wash_locations')
        .select('*', { count: 'exact', head: true })
        .or('service_types.cs.{detailing},service_type.eq.detailing');

      if (error) {
        // If that doesn't work, try a different approach - just count all for now
        const { count: allCount, error: allError } = await supabase
          .from('car_wash_locations')
          .select('*', { count: 'exact', head: true });
        
        if (allError) {
          console.warn('[DetailingHubCount] error:', allError);
          return;
        }
        
        // For now, estimate detailing hubs as a portion of total (you can refine this later)
        setDetailingHubCount(Math.floor((allCount || 0) * 0.3));
        return;
      }

      setDetailingHubCount(count || 0);
    } catch (e) {
      console.error('[DetailingHubCount] load error:', e);
    }
  };

  const loadTopValeters = async () => {
    try {
      const { data: completed } = await supabase
        .from('bookings')
        .select('valeter_id, rating')
        .eq('status', 'completed')
        .not('valeter_id', 'is', null)
        .not('rating', 'is', null);
      const byValeter = new Map<string, { sum: number; count: number }>();
      for (const row of completed || []) {
        const v = row.valeter_id as string;
        if (!v) continue;
        const cur = byValeter.get(v) || { sum: 0, count: 0 };
        const r = Number((row as any).rating) || 0;
        cur.sum += r;
        cur.count += 1;
        byValeter.set(v, cur);
      }
      const ranked = Array.from(byValeter.entries())
        .map(([id, { sum, count }]) => ({ id, avgRating: sum / count }))
        .sort((a, b) => b.avgRating - a.avgRating)
        .slice(0, 3);
      const ids = ranked.map((r) => r.id);
      if (ids.length === 0) {
        setTopValeters([]);
        return;
      }
      const { data: presence } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online')
        .in('user_id', ids);
      const { data: profiles } = await supabase
        .from('valeter_profiles')
        .select('user_id, display_name, company_name, profile_photo_url, created_at')
        .in('user_id', ids);
      const list: TopValeter[] = await Promise.all(
        ranked.map(async (r) => {
          const p = presence?.find((x) => x.user_id === r.id);
          const pr = profiles?.find((x) => x.user_id === r.id);
          const stats = await ValeterStatsService.getValeterStats(r.id);
          const profileFallback = await fetchProfileById(r.id);
          const name = (pr as any)?.display_name || profileFallback?.full_name || 'Valeter';
          let profilePicture: string | null = (pr as any)?.profile_photo_url ?? null;
          let joinedAt: string | null = (pr as any)?.created_at ?? null;
          if (!profilePicture && profileFallback) {
            const { data: prof } = await supabase.from('profiles').select('profile_picture, created_at').eq('id', r.id).maybeSingle();
            if (prof?.profile_picture) profilePicture = (prof as any).profile_picture;
            if (!joinedAt && (prof as any)?.created_at) joinedAt = (prof as any).created_at;
          } else if (!joinedAt) {
            const { data: prof } = await supabase.from('profiles').select('created_at').eq('id', r.id).maybeSingle();
            if ((prof as any)?.created_at) joinedAt = (prof as any).created_at;
          }
          const { data: reviewRows } = await supabase
            .from('bookings')
            .select('rating, review')
            .eq('valeter_id', r.id)
            .eq('status', 'completed')
            .not('rating', 'is', null)
            .order('completed_at', { ascending: false })
            .limit(5);
          const reviews: ValeterReview[] = (reviewRows || []).map((row: any) => ({
            rating: Number(row.rating) || 0,
            review: row.review ?? null,
          }));
          return {
            id: r.id,
            name,
            organization: (pr as any)?.company_name || 'Independent',
            rating: r.avgRating,
            jobsCompleted: stats.totalJobs,
            isOnline: !!p?.is_online,
            profilePicture: profilePicture || undefined,
            joinedAt: joinedAt || undefined,
            reviews: reviews.length > 0 ? reviews : undefined,
          };
        })
      );
      setTopValeters(list);
    } catch (e) {
      console.error('[TopValeters] load error:', e);
      setTopValeters([]);
    }
  };

  const loadTopCarWashes = async () => {
    try {
      const { data: hubs, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, latitude, longitude, rating, total_reviews, created_at')
        .eq('is_active', true);
      if (error) throw error;
      const coords = userLocation;
      const calcDist = (lat1: number, lon1: number, lat2: number, lon2: number) => {
        const R = 3959;
        const dLat = ((lat2 - lat1) * Math.PI) / 180;
        const dLon = ((lon2 - lon1) * Math.PI) / 180;
        const a =
          Math.sin(dLat / 2) ** 2 +
          Math.cos((lat1 * Math.PI) / 180) *
            Math.cos((lat2 * Math.PI) / 180) *
            Math.sin(dLon / 2) ** 2;
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
      };
      const withDistance = (hubs || []).map((h) => {
        let dist: number | null = null;
        if (coords && h.latitude != null && h.longitude != null) {
          dist = calcDist(coords.latitude, coords.longitude, h.latitude, h.longitude);
        }
        return { ...h, distanceMiles: dist };
      });
      const withinRadius = coords
        ? withDistance.filter((h) => h.distanceMiles != null && h.distanceMiles <= CUSTOMER_RADIUS_MILES)
        : withDistance;
      const sorted = [...withinRadius].sort((a, b) => {
        const ra = Number(a.rating) || 0;
        const rb = Number(b.rating) || 0;
        if (rb !== ra) return rb - ra;
        const ja = Number(a.total_reviews) || 0;
        const jb = Number(b.total_reviews) || 0;
        return jb - ja;
      });
      const top3 = sorted.slice(0, 3);
      const withStats = await Promise.all(
        top3.map(async (h) => {
          const stats = await WashHubStatsService.getHubStats(h.id);
          const hubRow = (hubs || []).find((x: any) => x.id === h.id) as any;
          const { data: reviewRows } = await supabase
            .from('bookings')
            .select('rating, review')
            .eq('location_id', h.id)
            .eq('status', 'completed')
            .not('rating', 'is', null)
            .order('completed_at', { ascending: false })
            .limit(5);
          const reviews: CarWashReview[] = (reviewRows || []).map((row: any) => ({
            rating: Number(row.rating) || 0,
            review: row.review ?? null,
          }));
          return {
            id: h.id,
            name: h.name || 'Wash Hub',
            address: h.address || '',
            rating: Number(h.rating) || stats.averageRating || 0,
            jobsCompleted: stats.totalJobs || Number(h.total_reviews) || 0,
            distanceMiles: h.distanceMiles,
            imageUrl: undefined,
            joinedAt: hubRow?.created_at ?? undefined,
            reviews: reviews.length > 0 ? reviews : undefined,
          };
        })
      );
      setTopCarWashes(withStats);
    } catch (e) {
      console.error('[TopCarWashes] load error:', e);
      setTopCarWashes([]);
    }
  };

  useEffect(() => {
    loadTopCarWashes();
  }, [userLocation?.latitude, userLocation?.longitude]);

  useEffect(() => {
    loadNearbyValeters();
    loadCarWashCount();
    loadDetailingHubCount();
    loadWeeklyStats();
    loadTopValeters();
    loadTopCarWashes();
    const interval = setInterval(() => {
      loadNearbyValeters();
      loadCarWashCount();
      loadDetailingHubCount();
      loadWeeklyStats();
      loadTopValeters();
      loadTopCarWashes();
    }, 30000);
    return () => clearInterval(interval);
  }, [user?.id]);

  // Refresh weekly/today washes count when user returns to dashboard (e.g. after completing a wash)
  useFocusEffect(
    useCallback(() => {
      if (user?.id) {
        loadWeeklyStats();
        loadRecentBookings();
      }
    }, [user?.id])
  );

  // Clear search bar when leaving dashboard so nothing is saved when you come back
  useFocusEffect(
    useCallback(() => () => {
      setDashboardSearchQuery('');
    }, [])
  );

  useEffect(() => {
    if (user?.id) {
      const timer = setTimeout(() => setLoading(false), 500);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, [user?.id]);

  const handleNotificationPress = () => {
    router.push('/owner/features/notifications');
  };

  const handleResumeTracking = () => {
    if (!activeBooking?.id) return;
    router.push({
      pathname: '/owner/booking/tracking',
      params: { bookingId: activeBooking.id },
    } as any);
  };

  const handleAttemptNewBooking = (route: string, params?: Record<string, string>) => {
    if (!activeBooking?.id) {
      if (params != null && Object.keys(params).length > 0) {
        router.push({ pathname: route, params } as any);
      } else {
        router.push(route as any);
      }
      return;
    }

    Alert.alert(
      'Active booking in progress',
      'You already have an active booking. You can resume tracking it now.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'View booking',
          onPress: handleResumeTracking,
        },
      ]
    );
  };

  const activeBookingMapRegion: Region | null = useMemo(() => {
    if (!userLocation) return null;
    const points: { latitude: number; longitude: number }[] = [userLocation];
    if (valeterLocation) points.push(valeterLocation);
    if (activeBooking?.latitude != null && activeBooking?.longitude != null) {
      points.push({ latitude: activeBooking.latitude, longitude: activeBooking.longitude });
    }
    const lats = points.map((p) => p.latitude);
    const lngs = points.map((p) => p.longitude);
    const minLat = Math.min(...lats);
    const maxLat = Math.max(...lats);
    const minLng = Math.min(...lngs);
    const maxLng = Math.max(...lngs);
    const pad = 0.002;
    return {
      latitude: (minLat + maxLat) / 2,
      longitude: (minLng + maxLng) / 2,
      latitudeDelta: Math.max(0.001, maxLat - minLat + pad * 2),
      longitudeDelta: Math.max(0.001, maxLng - minLng + pad * 2),
    };
  }, [userLocation, valeterLocation, activeBooking?.latitude, activeBooking?.longitude]);

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" />
      <BubbleBackground accountType="customer" />

      <AppHeader
        title={formatDisplayName(profileName || user?.name || 'Customer')}
        subtitle={(() => {
          const h = new Date().getHours();
          if (h < 12) return 'Good morning!';
          if (h < 17) return 'Good afternoon!';
          return 'Good evening!';
        })()}
        variant="dashboard"
        accountType="customer"
        showBack={false}
        scrollY={scrollY}
        enableScrollAnimation={true}
        leftAction={
          <TouchableOpacity
            onPress={() => { hapticFeedback('light'); router.push('/owner/owner-profile' as any); }}
            style={styles.headerProfilePicWrap}
            activeOpacity={0.8}
            accessibilityLabel="Profile"
            accessibilityRole="button"
          >
            {headerProfilePicture ? (
              <Image source={{ uri: headerProfilePicture }} style={styles.headerProfilePic} resizeMode="cover" />
            ) : (
              <View style={styles.headerProfilePicPlaceholder}>
                <Ionicons name="person" size={22} color={SKY} />
              </View>
            )}
          </TouchableOpacity>
        }
        rightAction={
          <GradientNotificationBell count={notificationCount} onPress={handleNotificationPress} />
        }
      />

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        contentContainerStyle={{
          paddingTop: getDashboardHeaderTopOffset(insets) - 32,
          paddingBottom: TAB_BAR_TOTAL_HEIGHT + 24,
        }}
        showsVerticalScrollIndicator={false}
      >
        {loading ? (
          <View style={[styles.bookingButtonsSection, sectionContainerStyle, tabletSectionMarginReset]}>
            <View style={[styles.bookingButton, styles.bookingButtonTall, { justifyContent: 'center', minHeight: 76 }]}>
              <ActivityIndicator size="small" color={SKY} />
              <Text style={[styles.loadingText, { marginTop: 8 }]}>Loading…</Text>
            </View>
            <View style={{ marginHorizontal: horizontalInset, marginTop: 16 }}>
              <SkeletonList count={4} />
            </View>
          </View>
        ) : (
          <View style={{ flex: 1 }}>
            {/* Booking Button with Quick Actions */}
            <View style={[styles.bookingButtonsSection, sectionContainerStyle, tabletSectionMarginReset]}>
          <TouchableOpacity
            style={[styles.bookingButton, styles.bookingButtonTall]}
            onPress={() => handleAttemptNewBooking('/owner/booking')}
            activeOpacity={0.9}
          >
            <View style={StyleSheet.absoluteFill}>
              <LinearGradient colors={['rgba(135,206,235,0.55)', 'rgba(59,130,246,0.55)']} style={StyleSheet.absoluteFill} />
              <Animated.View
                pointerEvents="none"
                style={[
                  StyleSheet.absoluteFill,
                  {
                    backgroundColor: 'rgba(255,255,255,0.08)',
                    opacity: heroGradientAnim.interpolate({
                      inputRange: [0, 0.5, 1],
                      outputRange: [0, 0.12, 0],
                    }),
                  },
                ]}
              />
            </View>
            <View style={styles.bookingButtonGradientTall}>
              <View style={styles.bookingButtonIconWrap}>
                <Ionicons name="water" size={22} color={LIGHT_SKY} />
              </View>
              <View style={styles.bookingButtonTextWrap}>
                <Text style={styles.bookingButtonTitle}>Book a Wash</Text>
                <Text style={styles.bookingButtonSubtitle}>
                  {activeBooking ? 'Finish your active booking first' : HERO_SUBTEXTS[heroSubtextIndex]}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.85)" />
            </View>
          </TouchableOpacity>

          {/* Search bar - same shape/style as Top Rated tabs */}
          <View style={styles.dashboardSearchBarWrap}>
            <View style={styles.dashboardSearchBarInner}>
              <Ionicons name="search" size={18} color="rgba(255,255,255,0.7)" />
              <TextInput
                style={styles.dashboardSearchInput}
                placeholder="Search areas, car wash names, valeters..."
                placeholderTextColor="rgba(255,255,255,0.5)"
                value={dashboardSearchQuery}
                onChangeText={setDashboardSearchQuery}
                onFocus={() => hapticFeedback('light')}
                returnKeyType="search"
                onSubmitEditing={() => {
                  hapticFeedback('light');
                  const query = dashboardSearchQuery.trim();
                  if (query) {
                    router.push({ pathname: '/owner/explore', params: { q: query } } as any);
                  } else {
                    router.push('/owner/explore');
                  }
                }}
                autoCapitalize="words"
                autoCorrect={true}
                spellCheck={true}
              />
            </View>
          </View>

          {/* Quick Actions - Horizontal Scroll */}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.quickActionsScrollContent}
            style={styles.quickActionsScroll}
          >
            <Pressable
              onPressIn={() => Animated.spring(quickScale4, { toValue: 0.96, useNativeDriver: true, speed: 120 }).start()}
              onPressOut={() => Animated.spring(quickScale4, { toValue: 1, useNativeDriver: true, speed: 120 }).start()}
              onPress={() => {
                hapticFeedback('light');
                router.push('/owner/explore');
              }}
            >
              <Animated.View style={[styles.quickActionItem, isTabletLayout && styles.quickActionItemTablet, { transform: [{ scale: quickScale4 }] }]}>
                <View style={[styles.quickActionIconBox, isTabletLayout && styles.quickActionIconBoxTablet, { backgroundColor: '#8B5CF6' }]}>
                  <Ionicons name="map" size={20} color="#FFFFFF" />
                </View>
                <Text style={styles.quickActionItemLabel}>Explore</Text>
                <Text style={styles.quickActionBadge}>Hubs & Valeters</Text>
              </Animated.View>
            </Pressable>

            <Pressable
              onPressIn={() => Animated.spring(quickScale0, { toValue: 0.96, useNativeDriver: true, speed: 120 }).start()}
              onPressOut={() => Animated.spring(quickScale0, { toValue: 1, useNativeDriver: true, speed: 120 }).start()}
              onPress={() => {
                hapticFeedback('light');
                router.push('/owner/settings/vehicle-management');
              }}
            >
              <Animated.View style={[styles.quickActionItem, isTabletLayout && styles.quickActionItemTablet, { transform: [{ scale: quickScale0 }] }]}>
                <View style={[styles.quickActionIconBox, isTabletLayout && styles.quickActionIconBoxTablet, { backgroundColor: '#3B82F6' }]}>
                  <Ionicons name="car-sport" size={20} color="#FFFFFF" />
                </View>
                <Text style={styles.quickActionItemLabel}>Vehicles</Text>
                <Text style={styles.quickActionBadge}>MOT & Tax</Text>
              </Animated.View>
            </Pressable>

            <Pressable
              onPressIn={() => Animated.spring(quickScale1, { toValue: 0.96, useNativeDriver: true, speed: 120 }).start()}
              onPressOut={() => Animated.spring(quickScale1, { toValue: 1, useNativeDriver: true, speed: 120 }).start()}
              onPress={() => {
                hapticFeedback('light');
                router.push('/owner/features/rewards');
              }}
            >
              <Animated.View style={[styles.quickActionItem, isTabletLayout && styles.quickActionItemTablet, { transform: [{ scale: quickScale1 }] }]}>
                <View style={[styles.quickActionIconBox, isTabletLayout && styles.quickActionIconBoxTablet, { backgroundColor: '#10B981' }]}>
                  <Ionicons name="trophy" size={20} color="#FFFFFF" />
                </View>
                <Text style={styles.quickActionItemLabel}>Rewards</Text>
                <Text style={styles.quickActionBadge}>£8 earned</Text>
              </Animated.View>
            </Pressable>

            <Pressable
              onPressIn={() => Animated.spring(quickScale2, { toValue: 0.96, useNativeDriver: true, speed: 120 }).start()}
              onPressOut={() => Animated.spring(quickScale2, { toValue: 1, useNativeDriver: true, speed: 120 }).start()}
              onPress={() => {
                hapticFeedback('light');
                router.push('/owner/features/referral-system');
              }}
            >
              <Animated.View style={[styles.quickActionItem, isTabletLayout && styles.quickActionItemTablet, { transform: [{ scale: quickScale2 }] }]}>
                <View style={[styles.quickActionIconBox, isTabletLayout && styles.quickActionIconBoxTablet, { backgroundColor: '#EAB308' }]}>
                  <Ionicons name="people-circle" size={20} color="#FFFFFF" />
                </View>
                <Text style={styles.quickActionItemLabel}>Referrals</Text>
                <Text style={styles.quickActionBadge}>Give £5, get £5</Text>
              </Animated.View>
            </Pressable>

            <Pressable
              onPressIn={() => Animated.spring(quickScale3, { toValue: 0.96, useNativeDriver: true, speed: 120 }).start()}
              onPressOut={() => Animated.spring(quickScale3, { toValue: 1, useNativeDriver: true, speed: 120 }).start()}
              onPress={() => {
                hapticFeedback('light');
                router.push('/owner/wash-history');
              }}
            >
              <Animated.View style={[styles.quickActionItem, isTabletLayout && styles.quickActionItemTablet, { transform: [{ scale: quickScale3 }] }]}>
                <View style={[styles.quickActionIconBox, isTabletLayout && styles.quickActionIconBoxTablet, { backgroundColor: '#0EA5E9' }]}>
                  <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                </View>
                <Text style={styles.quickActionValue}>{weeklyStats.totalWashes}</Text>
                <Text style={styles.quickActionItemLabel}>Total Washes</Text>
              </Animated.View>
            </Pressable>

          </ScrollView>
        </View>

        {/* Payment due / active trip card */}
        <ActiveBookingSection
          activeBookingLoading={activeBookingLoading}
          activeBooking={activeBooking}
          activeBookingMapRegion={activeBookingMapRegion}
          userLocation={userLocation}
          valeterLocation={valeterLocation}
          onResumeTracking={handleResumeTracking}
          styles={styles}
          eta={eta}
          loyaltyData={loyaltyData}
          reservedCounts={{ nearbyValeters: nearbyValeters.length, carWashCount, detailingHubCount, recentBookingsLoading }}
          sectionStyle={[sectionContainerStyle, tabletSectionMarginReset]}
        />

        {/* Recent Bookings Section */}
        {recentBookings.length > 0 && (
          <View style={[styles.recentBookingsSection, sectionContainerStyle, tabletSectionMarginReset]}>
            <View style={styles.recentBookingsHeader}>
              <View style={styles.recentBookingsHeaderLeft}>
                <View style={styles.recentBookingsIconWrapper}>
                  <Ionicons name="time-outline" size={18} color={SKY} />
                </View>
                <View>
                  <Text style={styles.recentBookingsTitle}>Recent Bookings</Text>
                  <Text style={styles.recentBookingsSubtitle}>
                    {recentBookings.length} booking{recentBookings.length === 1 ? '' : 's'}
                  </Text>
                </View>
              </View>
              <TouchableOpacity
                onPress={() => router.push('/owner/wash-history')}
                activeOpacity={0.7}
              >
                <Text style={styles.recentBookingsViewAll}>View all</Text>
              </TouchableOpacity>
            </View>

            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.recentBookingsScrollContent}
            >
              {recentBookings.map((booking) => (
                <TouchableOpacity
                  key={booking.id}
                  style={[
                    styles.recentBookingCard,
                    {
                      borderLeftWidth: 4,
                      borderLeftColor: booking.status === 'completed' ? '#10B981' : '#EF4444',
                    },
                  ]}
                  activeOpacity={0.9}
                  onPress={() => router.push(`/owner/wash-history?highlightId=${booking.id}`)}
                >
                  <View style={styles.recentBookingCardContent}>
                    <View style={styles.recentBookingTopRow}>
                      <View style={styles.recentBookingIconWrap}>
                        <Ionicons
                          name={booking.status === 'completed' ? 'checkmark-circle' : 'close-circle'}
                          size={18}
                          color={booking.status === 'completed' ? '#10B981' : '#EF4444'}
                        />
                      </View>
                      <View style={styles.recentBookingInfo}>
                        <Text style={styles.recentBookingService} numberOfLines={1}>
                          {getServiceDisplayName(booking.service_type, booking.service_name)}
                        </Text>
                        <Text style={styles.recentBookingStatus} numberOfLines={1}>
                          {booking.status === 'completed' ? 'Completed' : 'Cancelled'}
                        </Text>
                      </View>
                      <View style={styles.recentBookingValeterAvatar}>
                        <Text style={styles.recentBookingValeterInitials}>
                          {getValeterInitials(booking.valeter_name)}
                        </Text>
                      </View>
                    </View>
                    {booking.location_address && (
                      <View style={styles.recentBookingLocation}>
                        <Ionicons name="location-outline" size={12} color="rgba(255,255,255,0.6)" />
                        <Text style={styles.recentBookingLocationText} numberOfLines={1}>
                          {booking.location_address}
                        </Text>
                      </View>
                    )}
                    <View style={styles.recentBookingBottomRow}>
                      <Text style={styles.recentBookingPrice}>£{Number(booking.price || 0).toFixed(2)}</Text>
                      {booking.scheduled_at ? (
                        <Text style={styles.recentBookingDate}>
                          {new Date(booking.scheduled_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                        </Text>
                      ) : null}
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}

        {/* Top Rated - Valeters & Car Washes */}
        <View style={[styles.availabilitySectionBottom, sectionContainerStyle, tabletSectionMarginReset]}>
          <View style={styles.topRatedHeader}>
            <View style={styles.topRatedTitleRow}>
              <View style={styles.topRatedTitleLeft}>
                <View style={styles.topRatedIconWrap}>
                  <Ionicons name="trophy" size={18} color="#FBBF24" />
                </View>
                <Text style={styles.topRatedTitle}>Top Rated</Text>
                <Text style={styles.topRatedCount}>
                  {topRatedTab === 'valeters'
                    ? `${filteredTopValeters.length}`
                    : `${topCarWashes.length}`}
                </Text>
              </View>
              {topRatedTab === 'valeters' && (
                <TouchableOpacity
                  style={styles.availabilityDropdown}
                  onPress={() => { hapticFeedback('light'); setShowAvailabilityPicker(true); }}
                  activeOpacity={0.8}
                >
                  <Text style={styles.availabilityDropdownText}>
                    {availabilityFilter === 'today' ? 'Today' : availabilityFilter === 'tomorrow' ? 'Tomorrow' : 'Next Week'}
                  </Text>
                  <Ionicons name="chevron-down" size={16} color="rgba(255,255,255,0.8)" />
                </TouchableOpacity>
              )}
            </View>
            <View style={[styles.availabilityFiltersRow, { marginTop: 10 }]}>
              <TouchableOpacity
                style={[styles.availabilityFilterPill, topRatedTab === 'valeters' && styles.availabilityFilterPillActive]}
                onPress={() => { hapticFeedback('light'); setTopRatedTab('valeters'); }}
                activeOpacity={0.8}
              >
                <Text style={[styles.availabilityFilterText, topRatedTab === 'valeters' && styles.availabilityFilterTextActive]}>
                  Valeters
                </Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.availabilityFilterPill, topRatedTab === 'carwash' && styles.availabilityFilterPillActive]}
                onPress={() => { hapticFeedback('light'); setTopRatedTab('carwash'); }}
                activeOpacity={0.8}
              >
                <Text style={[styles.availabilityFilterText, topRatedTab === 'carwash' && styles.availabilityFilterTextActive]}>
                  Wash Hubs
                </Text>
              </TouchableOpacity>
            </View>
          </View>

          {/* Availability picker modal (Today / Tomorrow / Next Week) */}
          <Modal visible={showAvailabilityPicker} transparent animationType="fade" onRequestClose={() => setShowAvailabilityPicker(false)}>
            <Pressable style={styles.availabilityPickerOverlay} onPress={() => setShowAvailabilityPicker(false)}>
              <Pressable style={styles.availabilityPickerContent} onPress={(e) => e.stopPropagation()}>
                <Text style={styles.availabilityPickerTitle}>When</Text>
                {(['today', 'tomorrow', 'next_week'] as const).map((option) => (
                  <TouchableOpacity
                    key={option}
                    style={[styles.availabilityPickerOption, availabilityFilter === option && styles.availabilityPickerOptionActive]}
                    onPress={() => {
                      hapticFeedback('light');
                      setAvailabilityFilter(option);
                      setShowAvailabilityPicker(false);
                    }}
                    activeOpacity={0.8}
                  >
                    <Text style={[styles.availabilityPickerOptionText, availabilityFilter === option && styles.availabilityPickerOptionTextActive]}>
                      {option === 'today' ? 'Today' : option === 'tomorrow' ? 'Tomorrow' : 'Next Week'}
                    </Text>
                    {availabilityFilter === option && <Ionicons name="checkmark" size={18} color={SKY} />}
                  </TouchableOpacity>
                ))}
              </Pressable>
            </Pressable>
          </Modal>

          {/* Valeters Tab – same card design as Explore */}
          {topRatedTab === 'valeters' && (
            <View style={styles.prosNearbyContainer}>
              {filteredTopValeters.length > 0 ? (
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.prosScrollContent}>
                  {filteredTopValeters.map((v) => (
                    <View key={v.id} style={styles.exploreCardWrap}>
                      <Pressable style={styles.exploreValeterCard} onPress={() => handleAttemptNewBooking('/owner/booking')}>
                        <View style={styles.exploreValeterMain}>
                          <View style={styles.exploreValeterAvatarWrap}>
                            {v.profilePicture && !failedValeterImageIds.has(v.id) ? (
                              <Image
                                source={{ uri: v.profilePicture }}
                                style={styles.exploreValeterAvatar}
                                resizeMode="cover"
                                onError={() => setFailedValeterImageIds((prev) => new Set(prev).add(v.id))}
                              />
                            ) : (
                              <View style={styles.exploreValeterAvatarPlaceholder}>
                                <Image source={VALETER_IMAGE} style={styles.exploreValeterAvatar} resizeMode="cover" />
                              </View>
                            )}
                            {v.isOnline && <View style={styles.exploreOnlineDot} />}
                          </View>
                          <View style={styles.exploreValeterBody}>
                            <View style={styles.exploreValeterNameRow}>
                              <Text style={styles.exploreCardTitle} numberOfLines={1}>{formatDisplayName(v.name) || v.name || 'Valeter'}</Text>
                              <TouchableOpacity style={styles.exploreInfoBtn} onPress={(e) => { e.stopPropagation(); hapticFeedback('light'); setInfoValeter(v); }} hitSlop={8}>
                                <Ionicons name="information-circle-outline" size={22} color={SKY} />
                              </TouchableOpacity>
                            </View>
                            <View style={styles.exploreValeterStatsRow}>
                              <View style={styles.exploreStatItem}>
                                <Ionicons name="star" size={12} color="#FBBF24" />
                                <Text style={styles.exploreStatItemText}>{v.rating > 0 ? v.rating.toFixed(1) : 'New'}</Text>
                              </View>
                              <View style={styles.exploreStatItem}>
                                <Ionicons name="checkmark-done-outline" size={12} color="#94A3B8" />
                                <Text style={styles.exploreStatItemText}>{v.jobsCompleted} jobs</Text>
                              </View>
                              {v.isOnline && (
                                <View style={styles.exploreAvailabilityBadge}>
                                  <Text style={styles.exploreAvailabilityBadgeText}>Available</Text>
                                </View>
                              )}
                            </View>
                            <View style={styles.exploreValeterFooter}>
                              <TouchableOpacity
                                style={styles.exploreFooterLeft}
                                onPress={(e) => { e.stopPropagation(); hapticFeedback('light'); router.push({ pathname: '/owner/valeter-details', params: { valeterId: v.id } }); }}
                                activeOpacity={0.8}
                              >
                                <Text style={styles.exploreViewDetailsText}>Services</Text>
                                <Ionicons name="information-circle-outline" size={20} color={SKY} />
                              </TouchableOpacity>
                              <TouchableOpacity style={styles.exploreBookBtnSmall} onPress={() => handleAttemptNewBooking('/owner/booking')} activeOpacity={0.9}>
                                <Text style={styles.exploreBookBtnTextSmall}>Book now</Text>
                                <Ionicons name="arrow-forward" size={12} color="#fff" />
                              </TouchableOpacity>
                            </View>
                          </View>
                        </View>
                      </Pressable>
                    </View>
                  ))}
                </ScrollView>
              ) : (
                <View style={styles.prosEmptyState}>
                  <Ionicons name="people-outline" size={32} color="rgba(255,255,255,0.3)" />
                  <Text style={styles.prosEmptyText}>
                    {getValetersEmptyMessage(availabilityFilter)}
                  </Text>
                </View>
              )}
            </View>
          )}

          {/* Car Wash Tab – same card design as Explore */}
          {topRatedTab === 'carwash' && (
            <View style={styles.prosNearbyContainer}>
              {topCarWashes.length > 0 ? (
                <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.prosScrollContent}>
                  {topCarWashes.map((h) => (
                    <View key={h.id} style={styles.exploreCardWrap}>
                      <Pressable style={styles.exploreCard} onPress={() => handleAttemptNewBooking('/owner/booking/physical/vehicle', { locationId: h.id })}>
                        <View style={styles.exploreHubHero}>
                          <LinearGradient
                            colors={[SKY + '40', SKY + '15']}
                            style={StyleSheet.absoluteFill}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 1 }}
                          />
                          <Image source={CARWASH_IMAGE} style={styles.exploreHubHeroImage} resizeMode="contain" />
                          <View style={styles.exploreRatingPill}>
                            <Ionicons name="star" size={12} color="#FBBF24" />
                            <Text style={styles.exploreRatingPillText}>{h.rating.toFixed(1)}</Text>
                          </View>
                          <TouchableOpacity
                            style={{ position: 'absolute', top: 8, right: 8, padding: 4 }}
                            onPress={(e) => { e.stopPropagation(); hapticFeedback('light'); setInfoCarWash(h); }}
                            hitSlop={8}
                          >
                            <Ionicons name="information-circle-outline" size={22} color={SKY} />
                          </TouchableOpacity>
                        </View>
                        <View style={styles.exploreCardBody}>
                          <View style={styles.exploreHubNameRow}>
                            <Text style={styles.exploreCardTitle} numberOfLines={1}>{h.name}</Text>
                          </View>
                          {h.address ? (
                            <View style={styles.exploreAddressRow}>
                              <Ionicons name="location-outline" size={14} color="#94A3B8" />
                              <Text style={styles.exploreAddressText} numberOfLines={2}>{h.address}</Text>
                            </View>
                          ) : null}
                          {(h.distanceMiles != null) && (
                            <View style={styles.exploreDistancePill}>
                              <Ionicons name="location" size={12} color={SKY} />
                              <Text style={styles.exploreDistanceText}>{h.distanceMiles.toFixed(1)} mi away</Text>
                            </View>
                          )}
                          <View style={styles.exploreCardFooter}>
                            <TouchableOpacity
                              style={styles.exploreFooterLeft}
                              onPress={(e) => { e.stopPropagation(); hapticFeedback('light'); router.push({ pathname: '/owner/hub-details', params: { locationId: h.id } }); }}
                              activeOpacity={0.8}
                            >
                              <Text style={styles.exploreViewDetailsText}>Services</Text>
                              <Ionicons name="information-circle-outline" size={20} color={SKY} />
                            </TouchableOpacity>
                            <TouchableOpacity style={styles.exploreBookBtn} onPress={(e) => { e.stopPropagation(); handleAttemptNewBooking('/owner/booking/physical/vehicle', { locationId: h.id }); }} activeOpacity={0.9}>
                              <Text style={styles.exploreBookBtnText}>Book</Text>
                              <Ionicons name="arrow-forward" size={14} color="#fff" />
                            </TouchableOpacity>
                          </View>
                        </View>
                      </Pressable>
                    </View>
                  ))}
                </ScrollView>
              ) : (
                <View style={styles.prosEmptyState}>
                  <Ionicons name="business-outline" size={32} color="rgba(255,255,255,0.3)" />
                  <Text style={styles.prosEmptyText}>
                    {userLocation ? 'No wash hubs within 25 mi' : 'Enable location for nearby hubs'}
                  </Text>
                </View>
              )}
            </View>
          )}
        </View>
      </View>
        )}
      </Animated.ScrollView>

      {/* Valeter Profile Modal */}
      <Modal visible={!!infoValeter} transparent animationType="slide">
        <Pressable style={styles.profileModalOverlay} onPress={() => setInfoValeter(null)}>
          <Pressable style={styles.profileModalContent} onPress={(e) => e.stopPropagation()}>
            <LinearGradient colors={HEADER_STYLE_CARD_GRADIENT} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} />
            <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} />
            {infoValeter && (
              <>
                <View style={styles.profileModalHeader}>
                  <Text style={styles.profileModalTitle}>Valeter Profile</Text>
                  <TouchableOpacity onPress={() => setInfoValeter(null)} hitSlop={12}>
                    <Ionicons name="close" size={24} color="#94A3B8" />
                  </TouchableOpacity>
                </View>
                <ScrollView showsVerticalScrollIndicator={false} style={styles.profileModalScroll}>
                  <View style={styles.profileModalAvatar}>
                    {infoValeter.profilePicture ? (
                      <Image source={{ uri: infoValeter.profilePicture }} style={styles.profileModalAvatarImg} />
                    ) : (
                      <View style={styles.profileModalAvatarInner}>
                        <Image source={VALETER_IMAGE} style={styles.profileModalAvatarImg} resizeMode="cover" />
                      </View>
                    )}
                  </View>
                  <Text style={styles.profileModalName}>{formatDisplayName(infoValeter.name) || 'Valeter'}</Text>
                  <Text style={styles.profileModalOrg}>{infoValeter.organization}</Text>
                  {infoValeter.joinedAt && (
                    <View style={styles.profileModalJoinedRow}>
                      <Ionicons name="calendar-outline" size={16} color={SKY} />
                      <Text style={styles.profileModalJoinedText}>
                        Joined {new Date(infoValeter.joinedAt).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })}
                      </Text>
                    </View>
                  )}
                  <View style={styles.profileModalStats}>
                    <View style={styles.profileModalStat}>
                      <Ionicons name="star" size={18} color="#FBBF24" />
                      <Text style={styles.profileModalStatText}>{infoValeter.rating.toFixed(1)}</Text>
                    </View>
                    <View style={styles.profileModalStat}>
                      <Ionicons name="car" size={18} color={SKY} />
                      <Text style={styles.profileModalStatText}>{infoValeter.jobsCompleted} jobs</Text>
                    </View>
                    <View style={[styles.profileModalPill, !infoValeter.isOnline && styles.profileModalPillOffline]}>
                      <Text style={[styles.profileModalPillText, !infoValeter.isOnline && styles.profileModalPillTextOffline]}>
                        {infoValeter.isOnline ? 'Available now' : 'Offline'}
                      </Text>
                    </View>
                  </View>
                  <View style={styles.profileModalSection}>
                    <Text style={styles.profileModalSectionTitle}>Reviews</Text>
                    {infoValeter.reviews && infoValeter.reviews.length > 0 ? (
                      infoValeter.reviews.map((rev) => (
                        <View key={`review-${rev.rating}-${(rev.review ?? '').slice(0, 40)}`} style={styles.profileModalReviewItem}>
                          <View style={styles.profileModalReviewHeader}>
                            <Ionicons name="star" size={14} color="#FBBF24" />
                            <Text style={styles.profileModalReviewRating}>{rev.rating.toFixed(1)}</Text>
                          </View>
                          {rev.review ? <Text style={styles.profileModalReviewText}>{rev.review}</Text> : null}
                        </View>
                      ))
                    ) : (
                      <View style={styles.profileModalReviewsPlaceholder}>
                        <Ionicons name="chatbubble-ellipses-outline" size={32} color="rgba(148,163,184,0.6)" />
                        <Text style={styles.profileModalPlaceholderText}>Reviews will appear here when available</Text>
                      </View>
                    )}
                  </View>
                </ScrollView>
              </>
            )}
          </Pressable>
        </Pressable>
      </Modal>

      {/* Wash Hub info modal – same slide-up overlay design as Valeter Profile */}
      <Modal visible={!!infoCarWash} transparent animationType="slide" onRequestClose={() => setInfoCarWash(null)}>
        <Pressable style={styles.profileModalOverlay} onPress={() => setInfoCarWash(null)}>
          <Pressable style={styles.profileModalContent} onPress={(e) => e.stopPropagation()}>
            <LinearGradient colors={HEADER_STYLE_CARD_GRADIENT} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1 }} style={StyleSheet.absoluteFill} />
            <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} />
            {infoCarWash && (
              <>
                <View style={styles.profileModalHeader}>
                  <Text style={styles.profileModalTitle}>Wash Hub</Text>
                  <TouchableOpacity onPress={() => setInfoCarWash(null)} hitSlop={12}>
                    <Ionicons name="close" size={24} color="#94A3B8" />
                  </TouchableOpacity>
                </View>
                <ScrollView showsVerticalScrollIndicator={false} style={styles.profileModalScroll}>
                  <View style={styles.profileModalAvatar}>
                    {infoCarWash.imageUrl ? (
                      <Image source={{ uri: infoCarWash.imageUrl }} style={styles.profileModalAvatarImg} />
                    ) : (
                      <View style={styles.profileModalAvatarInner}>
                        <Image source={CARWASH_IMAGE} style={styles.profileModalHubIcon} resizeMode="contain" />
                      </View>
                    )}
                  </View>
                  <Text style={styles.profileModalName}>{infoCarWash.name}</Text>
                  {infoCarWash.address ? (
                    <View style={styles.profileModalAddressRow}>
                      <Ionicons name="location-outline" size={14} color={SKY} />
                      <Text style={styles.profileModalAddress} numberOfLines={2}>{infoCarWash.address}</Text>
                    </View>
                  ) : null}
                  {infoCarWash.joinedAt && (
                    <View style={styles.profileModalJoinedRow}>
                      <Ionicons name="calendar-outline" size={16} color={SKY} />
                      <Text style={styles.profileModalJoinedText}>
                        Joined {new Date(infoCarWash.joinedAt).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })}
                      </Text>
                    </View>
                  )}
                  <View style={styles.profileModalStats}>
                    <View style={styles.profileModalStat}>
                      <Ionicons name="star" size={18} color="#FBBF24" />
                      <Text style={styles.profileModalStatText}>{infoCarWash.rating.toFixed(1)}</Text>
                    </View>
                    <View style={styles.profileModalStat}>
                      <Ionicons name="car" size={18} color={SKY} />
                      <Text style={styles.profileModalStatText}>{infoCarWash.jobsCompleted} washes</Text>
                    </View>
                    {infoCarWash.distanceMiles != null && (
                      <View style={styles.profileModalStat}>
                        <Ionicons name="navigate" size={18} color={SKY} />
                        <Text style={styles.profileModalStatText}>{infoCarWash.distanceMiles.toFixed(1)} mi away</Text>
                      </View>
                    )}
                  </View>
                  <View style={styles.profileModalSection}>
                    <Text style={styles.profileModalSectionTitle}>Reviews</Text>
                    {infoCarWash.reviews && infoCarWash.reviews.length > 0 ? (
                      infoCarWash.reviews.slice(0, 5).map((rev) => (
                        <View key={`review-${rev.rating}-${(rev.review ?? '').slice(0, 40)}`} style={styles.profileModalReviewItem}>
                          <View style={styles.profileModalReviewHeader}>
                            <Ionicons name="star" size={14} color="#FBBF24" />
                            <Text style={styles.profileModalReviewRating}>{rev.rating.toFixed(1)}</Text>
                          </View>
                          {rev.review ? <Text style={styles.profileModalReviewText}>{rev.review}</Text> : null}
                        </View>
                      ))
                    ) : (
                      <View style={styles.profileModalReviewsPlaceholder}>
                        <Ionicons name="chatbubble-ellipses-outline" size={32} color="rgba(148,163,184,0.6)" />
                        <Text style={styles.profileModalPlaceholderText}>Reviews will appear here when available</Text>
                      </View>
                    )}
                  </View>
                </ScrollView>
              </>
            )}
          </Pressable>
        </Pressable>
      </Modal>

    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: 'transparent' },
  loadingText: { color: LIGHT_SKY, fontSize: 16 },
  scrollView: { flex: 1 },

  headerRightRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  headerProfilePicWrap: {
    width: 44,
    height: 44,
    borderRadius: 18,
    overflow: 'hidden',
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  headerProfilePic: {
    width: '100%',
    height: '100%',
  },
  headerProfilePicMirror: {
    transform: [{ scaleX: -1 }],
  },
  headerProfilePicPlaceholder: {
    width: '100%',
    height: '100%',
    alignItems: 'center',
    justifyContent: 'center',
  },

  bookingButtonsSection: {
    flexDirection: 'column',
    gap: 12,
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginTop: 0,
    marginBottom: 12,
  },
  bookingButton: {
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
  },
  bookingButtonTall: {
    minHeight: 76,
  },
  bookingButtonGradientTall: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 18,
    paddingHorizontal: 16,
    gap: 12,
  },
  bookingButtonIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.18)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.25)',
  },
  bookingButtonTextWrap: {
    flex: 1,
    gap: 2,
  },
  bookingButtonTitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  bookingButtonSubtitle: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 12,
    fontWeight: '600',
  },
  quickActionsScroll: {
    marginTop: 12,
  },
  quickActionsScrollContent: {
    gap: 12,
    paddingRight: 4,
  },
  quickActionItem: {
    alignItems: 'center',
    gap: 8,
    minWidth: 70,
    opacity: 0.95,
  },
  quickActionItemTablet: {
    minWidth: 92,
    gap: 10,
  },
  quickActionIconBox: {
    width: 56,
    height: 56,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
    opacity: 0.9,
  },
  quickActionIconBoxTablet: {
    width: 64,
    height: 64,
    borderRadius: 18,
  },
  quickActionItemLabel: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },
  quickActionBadge: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 10,
    fontWeight: '700',
    textAlign: 'center',
    marginTop: 2,
  },
  quickActionValue: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '900',
    textAlign: 'center',
    lineHeight: 22,
  },

  /* Active Booking (bigger + more prominent) */
  activeBookingSection: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 18,
  },
  activeBookingSkeleton: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.28)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    padding: 18,
    alignItems: 'center',
  },
  activeBookingCard: {
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 0,
    borderColor: 'transparent',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 4,
  },
  activeBookingGradient: {
    padding: 18,
  },
  activeBookingCardOverlay: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingBottom: 56,
    gap: 14,
  },
  activeBookingRingWrap: {
    width: 80,
    height: 80,
    alignItems: 'center',
    justifyContent: 'center',
  },
  activeBookingCardContent: {
    flex: 1,
    minWidth: 0,
  },
  activeBookingLoadingText: {
    color: LIGHT_SKY,
    fontSize: 13,
    fontWeight: '600',
    marginTop: 10,
    textAlign: 'center',
  },
  activeBookingTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  activeBookingIconWrap: {
    width: 50,
    height: 50,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  activeBookingTitle: {
    color: LIGHT_SKY,
    fontSize: 15,
    fontWeight: '900',
    letterSpacing: 0.2,
    marginBottom: 3,
  },
  activeBookingSubtitle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 13,
    fontWeight: '700',
  },
  activeBookingValeter: {
    color: 'rgba(255,255,255,0.78)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 4,
  },
  activeBookingStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    backgroundColor: SKY,
  },
  activeBookingStatusText: {
    color: '#0A1929',
    fontSize: 11,
    fontWeight: '900',
  },
  activeBookingMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 6,
  },
  activeBookingMetaText: {
    color: 'rgba(255,255,255,0.88)',
    fontSize: 12,
    fontWeight: '600',
    flex: 1,
  },
  activeBookingBottomRow: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    paddingBottom: 14,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.18)',
    backgroundColor: 'rgba(0,0,0,0.4)',
  },
  activeBookingPriceWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  activeBookingPrice: {
    color: LIGHT_SKY,
    fontSize: 13,
    fontWeight: '900',
  },
  activeBookingCta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  activeBookingMetaCta: {
    color: SKY,
    fontSize: 13,
    fontWeight: '900',
  },
  activeBookingMapContainer: {
    height: 200,
    borderRadius: 12,
    overflow: 'hidden',
    position: 'relative',
  },
  activeBookingMap: {
    width: '100%',
    height: '100%',
  },
  mapMarkerContainer: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapMarkerImage: {
    width: 32,
    height: 32,
  },
  etaOverlay: {
    position: 'absolute',
    top: 12,
    right: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(0,0,0,0.7)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  etaText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '800',
  },

  /* Recent Bookings Section */
  recentBookingsSection: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 18,
  },
  recentBookingsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  recentBookingsHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  recentBookingsIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  recentBookingsTitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  recentBookingsSubtitle: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  recentBookingsViewAll: {
    color: SKY,
    fontSize: 13,
    fontWeight: '700',
  },
  recentBookingsScrollContent: {
    gap: 12,
    paddingRight: 4,
  },
  recentBookingCard: {
    width: 200,
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 4,
  },
  recentBookingCardContent: {
    padding: 14,
    gap: 10,
  },
  recentBookingTopRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  recentBookingIconWrap: {
    marginTop: 2,
  },
  recentBookingValeterAvatar: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  recentBookingValeterInitials: {
    color: LIGHT_SKY,
    fontSize: 10,
    fontWeight: '800',
  },
  recentBookingInfo: {
    flex: 1,
    gap: 4,
  },
  recentBookingService: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
  },
  recentBookingStatus: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 11,
    fontWeight: '600',
  },
  recentBookingLocation: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  recentBookingLocationText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 11,
    fontWeight: '500',
    flex: 1,
  },
  recentBookingBottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  recentBookingPrice: {
    color: LIGHT_SKY,
    fontSize: 15,
    fontWeight: '800',
  },
  recentBookingDate: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 11,
    fontWeight: '600',
  },

  /* Availability - New Design */
  availabilitySection: { 
    marginBottom: 20,
    marginHorizontal: isSmallScreen ? 12 : 20,
  },
  availabilityHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  availabilityHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  availabilitySectionTitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  liveIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
    backgroundColor: 'rgba(239,68,68,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#EF4444',
  },
  liveText: {
    color: '#EF4444',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  availabilityCardNew: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  availabilityGradientNew: { 
    padding: 20,
  },
  availabilityMainDisplay: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 20,
    marginBottom: 16,
  },
  availabilityCountCircle: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1.5,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 2,
  },
  availabilityCountNumber: {
    color: LIGHT_SKY,
    fontSize: 32,
    fontWeight: '900',
    lineHeight: 36,
  },
  availabilityCountLabel: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 11,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  availabilityCountNumberSmall: {
    color: LIGHT_SKY,
    fontSize: 24,
    fontWeight: '900',
    lineHeight: 28,
    marginTop: 4,
  },
  availabilityCountLabelSmall: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 10,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  availabilityQuickInfo: {
    flex: 1,
    gap: 10,
  },
  quickInfoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  quickInfoText: {
    color: LIGHT_SKY,
    fontSize: 13,
    fontWeight: '700',
  },
  availabilityStatusBar: {
    height: 6,
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderRadius: 3,
    overflow: 'hidden',
    marginBottom: 12,
  },
  statusBarFill: {
    height: '100%',
    borderRadius: 3,
  },
  qualityIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
  },
  qualityText: {
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.3,
  },

  poweredBySection: {
    alignItems: 'center',
    paddingVertical: 24,
    paddingHorizontal: isSmallScreen ? 12 : 20,
    marginTop: 8,
  },
  poweredByText: {
    color: LIGHT_SKY,
    fontSize: 12,
    opacity: 0.8,
    fontWeight: '600',
  },
  /* Live Availability - Bottom Redesigned */
  availabilitySectionBottom: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 24,
    marginTop: 8,
  },
  availabilityCardBottom: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
  },
  availabilityGradientBottom: {
    padding: 24,
  },
  availabilityHeaderBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  availabilityHeaderLeftBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  availabilityIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  availabilityTitleBottom: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: 0.3,
    marginBottom: 2,
  },
  availabilitySubtitleBottom: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  liveIndicatorBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: 'rgba(239,68,68,0.2)',
    borderWidth: 1.5,
    borderColor: 'rgba(239,68,68,0.4)',
  },
  liveDotBottom: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#EF4444',
  },
  liveTextBottom: {
    color: '#EF4444',
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 0.8,
  },
  availabilityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    marginBottom: 12,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.15)',
  },
  availabilityRowIcon: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  availabilityRowContent: {
    flex: 1,
  },
  availabilityRowLabel: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  availabilityRowValue: {
    color: SKY,
    fontSize: 18,
    fontWeight: '800',
  },
  /* Top Rated section - redesigned */
  topRatedHeader: {
    marginBottom: 14,
  },
  topRatedTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
    marginBottom: 12,
  },
  topRatedTitleLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
    minWidth: 0,
  },
  availabilityDropdown: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.45)',
    backgroundColor: 'rgba(135,206,235,0.22)',
  },
  availabilityDropdownText: {
    color: '#E0F2FE',
    fontSize: 12,
    fontWeight: '700',
  },
  availabilityPickerOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  availabilityPickerContent: {
    width: '100%',
    maxWidth: 280,
    borderRadius: 16,
    backgroundColor: '#1E293B',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    padding: 16,
  },
  availabilityPickerTitle: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 12,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  availabilityPickerOption: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 12,
    marginBottom: 4,
  },
  availabilityPickerOptionActive: {
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  availabilityPickerOptionText: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 16,
    fontWeight: '600',
  },
  availabilityPickerOptionTextActive: {
    color: '#E0F2FE',
  },
  topRatedIconWrap: {
    width: 32,
    height: 32,
    borderRadius: 10,
    backgroundColor: 'rgba(251,191,36,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  topRatedTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  topRatedCount: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 14,
    fontWeight: '700',
  },
  dashboardSearchBarWrap: {
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderRadius: 24,
    padding: 4,
  },
  dashboardSearchBarInner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 20,
  },
  dashboardSearchInput: {
    flex: 1,
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    fontWeight: '600',
    paddingVertical: 0,
  },
  topRatedTabs: {
    flexDirection: 'row',
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderRadius: 10,
    padding: 4,
  },
  topRatedTab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    borderRadius: 8,
  },
  topRatedTabActive: {
    backgroundColor: 'rgba(255,255,255,0.95)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 3,
    elevation: 2,
  },
  topRatedTabText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 13,
    fontWeight: '700',
  },
  topRatedTabTextActive: {
    color: '#0A1929',
  },
  availabilityFiltersRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 10,
  },
  availabilityFilterPill: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 999,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
    backgroundColor: 'rgba(255,255,255,0.06)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  availabilityFilterPillActive: {
    borderColor: 'rgba(135,206,235,0.45)',
    backgroundColor: 'rgba(135,206,235,0.22)',
  },
  availabilityFilterText: {
    color: 'rgba(255,255,255,0.78)',
    fontSize: 12,
    fontWeight: '700',
  },
  availabilityFilterTextActive: {
    color: '#E0F2FE',
  },
  prosNearbyContainer: {
    marginBottom: 4,
  },
  prosScrollContent: {
    paddingRight: isSmallScreen ? 20 : 24,
    gap: 12,
  },
  // Explore-style cards (same design as Explore page for consistency)
  exploreCardWrap: {
    width: Math.min(320, width - 48),
    marginRight: 14,
  },
  exploreCard: {
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
    backgroundColor: 'rgba(30,41,59,0.6)',
  },
  exploreHubHero: {
    height: 120,
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  exploreHubHeroImage: { width: 72, height: 72, opacity: 0.9 },
  exploreRatingPill: {
    position: 'absolute',
    bottom: 8,
    left: 12,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.5)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    gap: 4,
  },
  exploreRatingPillText: { color: '#FBBF24', fontSize: 13, fontWeight: '700' },
  exploreCardBody: { padding: 14 },
  exploreHubNameRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4, gap: 8 },
  exploreCardTitle: { fontSize: 17, fontWeight: '800', flex: 1, color: '#F9FAFB' },
  exploreAddressRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 6, marginBottom: 6 },
  exploreAddressText: { flex: 1, fontSize: 13, color: '#94A3B8' },
  exploreCardFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 10, gap: 12 },
  exploreFooterLeft: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  exploreViewDetailsText: { fontSize: 13, fontWeight: '700', color: SKY },
  exploreBookBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
    backgroundColor: SKY,
  },
  exploreBookBtnSmall: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 4,
    paddingVertical: 5,
    paddingHorizontal: 10,
    borderRadius: 8,
    backgroundColor: SKY,
  },
  exploreBookBtnText: { color: '#fff', fontSize: 13, fontWeight: '800' },
  exploreBookBtnTextSmall: { color: '#fff', fontSize: 11, fontWeight: '800' },
  exploreFromPrice: { fontSize: 13, fontWeight: '600', color: '#94A3B8', marginBottom: 6 },
  exploreDistancePill: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  exploreDistanceText: { color: SKY, fontSize: 12, fontWeight: '700' },
  exploreValeterCard: {
    borderRadius: 16,
    overflow: 'hidden',
    padding: 14,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
    backgroundColor: 'rgba(30,41,59,0.6)',
  },
  exploreValeterMain: { flexDirection: 'row' },
  exploreValeterAvatarWrap: {
    width: 64,
    height: 64,
    borderRadius: 32,
    marginRight: 12,
    position: 'relative',
  },
  exploreValeterAvatar: { width: 64, height: 64, borderRadius: 32 },
  exploreValeterAvatarPlaceholder: {
    width: 64,
    height: 64,
    borderRadius: 32,
    overflow: 'hidden',
    backgroundColor: SKY + '25',
  },
  exploreOnlineDot: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#10B981',
    borderWidth: 2,
    borderColor: 'rgba(30,41,59,0.8)',
  },
  exploreValeterBody: { flex: 1, minWidth: 0 },
  exploreValeterNameRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 2 },
  exploreValeterStatsRow: { flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 4 },
  exploreStatItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  exploreStatItemText: { fontSize: 12, color: '#94A3B8' },
  exploreAvailabilityBadge: {
    backgroundColor: '#10B98120',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
    marginLeft: 4,
  },
  exploreAvailabilityBadgeText: { color: '#10B981', fontSize: 11, fontWeight: '700' },
  exploreValeterFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: 10, gap: 12 },
  exploreInfoBtn: { padding: 4 },
  proCard: {
    width: width - (isSmallScreen ? 24 : 40),
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(15,23,42,0.6)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.15)',
    flexDirection: 'row',
    alignItems: 'center',
    position: 'relative',
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.06,
    shadowRadius: 4,
    elevation: 2,
  },
  proCardTablet: {
    width: Math.min(980, width) - 56,
    paddingVertical: 8,
    paddingHorizontal: 14,
  },
  proCardTopRow: {
    position: 'absolute',
    top: 6,
    left: 8,
    right: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    zIndex: 5,
  },
  proCardTopRowHub: {
    justifyContent: 'flex-end',
  },
  proCardTopRowValeter: {
    flexDirection: 'row',
    justifyContent: 'flex-end',
    alignItems: 'center',
    gap: 8,
  },
  proCardThumb: {
    width: 24,
    height: 24,
    borderRadius: 12,
  },
  proCardThumbPlaceholder: {
    backgroundColor: 'rgba(135,206,235,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  proCardInfoBtn: {},
  proCardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    minWidth: 0,
  },
  proCardBody: {
    flex: 1,
    minWidth: 0,
    marginLeft: 12,
    justifyContent: 'center',
  },
  proCardAvatarWrap: {
    position: 'relative',
    marginRight: 0,
  },
  proAvatar: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  proAvatarImg: {
    width: 40,
    height: 40,
    borderRadius: 12,
  },
  proAvatarImgRing: {
    width: 40,
    height: 40,
    borderRadius: 10,
  },
  proAvatarRing: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    overflow: 'hidden',
  },
  proAvatarValeterIcon: {
    width: 44,
    height: 44,
  },
  proAvatarHub: {
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  proOnlineBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
    borderWidth: 1.5,
    borderColor: 'rgba(15,23,42,0.8)',
  },
  proName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    textAlign: 'left',
    marginBottom: 1,
    paddingHorizontal: 0,
  },
  proOrganization: {
    color: 'rgba(255,255,255,0.65)',
    fontSize: 11,
    textAlign: 'left',
    marginBottom: 2,
    paddingHorizontal: 0,
  },
  proAddress: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 10,
    textAlign: 'left',
    marginBottom: 2,
    paddingHorizontal: 0,
    lineHeight: 14,
  },
  proCardFooter: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: 4,
    marginBottom: 2,
  },
  proRating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
  },
  proRatingText: {
    color: '#FBBF24',
    fontSize: 12,
    fontWeight: '700',
  },
  proMetaText: {
    color: 'rgba(255,255,255,0.55)',
    fontSize: 11,
    fontWeight: '600',
  },
  proStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    backgroundColor: 'rgba(16,185,129,0.18)',
    alignSelf: 'flex-start',
  },
  proStatusPillOffline: {
    backgroundColor: 'rgba(148,163,184,0.2)',
  },
  proStatusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  proStatusDotOffline: {
    backgroundColor: '#94A3B8',
  },
  proStatusText: {
    color: '#10B981',
    fontSize: 11,
    fontWeight: '700',
  },
  proStatusTextOffline: {
    color: '#94A3B8',
  },
  proDistancePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 0,
  },
  proDistanceText: {
    color: SKY,
    fontSize: 11,
    fontWeight: '700',
  },
  prosEmptyState: {
    paddingVertical: 28,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    backgroundColor: 'rgba(255,255,255,0.03)',
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.1)',
    borderStyle: 'dashed',
  },
  prosEmptyText: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 13,
    fontWeight: '600',
    textAlign: 'center',
  },
  statIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  statNumber: {
    color: LIGHT_SKY,
    fontSize: 32,
    fontWeight: '900',
    lineHeight: 38,
    marginBottom: 4,
  },
  statLabel: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 13,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 8,
  },
  statBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  statBadgeText: {
    color: '#10B981',
    fontSize: 11,
    fontWeight: '700',
  },
  availabilityStatDivider: {
    width: 1,
    height: 80,
    backgroundColor: 'rgba(135,206,235,0.2)',
  },
  availabilityQuickInfoBottom: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  quickInfoCard: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.15)',
  },
  quickInfoContent: {
    flex: 1,
    gap: 2,
  },
  quickInfoLabel: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 11,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  quickInfoValue: {
    color: LIGHT_SKY,
    fontSize: 15,
    fontWeight: '800',
  },
  availabilityQualityBar: {
    gap: 10,
  },
  qualityBarBackground: {
    height: 8,
    backgroundColor: 'rgba(0,0,0,0.25)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  qualityBarFill: {
    height: '100%',
    borderRadius: 4,
  },
  qualityIndicatorBottom: {
    alignItems: 'flex-start',
  },
  qualityBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  qualityDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  qualityTextBottom: {
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  /* Detailing Hub Count - Purple Styled */
  availabilityStatCardPurple: {
    alignItems: 'center',
    padding: 16,
    borderRadius: 18,
    backgroundColor: 'rgba(139,92,246,0.1)',
    borderWidth: 1.5,
    borderColor: 'rgba(139,92,246,0.3)',
    marginTop: 12,
  },
  statIconWrapperPurple: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(139,92,246,0.15)',
    borderWidth: 2,
    borderColor: PREMIUM_PURPLE,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  statNumberPurple: {
    color: PREMIUM_PURPLE,
    fontSize: 32,
    fontWeight: '900',
    lineHeight: 38,
    marginBottom: 4,
  },
  statLabelPurple: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 13,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 8,
  },
  statBadgePurple: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(139,92,246,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
  },
  statBadgeTextPurple: {
    color: PREMIUM_PURPLE,
    fontSize: 11,
    fontWeight: '700',
  },
  availabilityETARow: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  statsSection: {
    marginBottom: 18,
  },
  statsScroll: {
    flexGrow: 0,
  },
  statsScrollContent: {
    paddingHorizontal: isSmallScreen ? 12 : 20,
    paddingVertical: 4,
  },
  statsSlideCard: {
    width: width * 0.52,
    minWidth: 160,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 4,
    marginRight: 10,
  },
  statsSlideIconWrapper: {
    width: 34,
    height: 34,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    marginBottom: 8,
  },
  statsSlideValue: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 2,
  },
  statsSlideLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 11,
    fontWeight: '600',
  },
  etaCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  etaContent: {
    flex: 1,
  },
  etaLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 2,
  },
  etaValue: {
    color: SKY,
    fontSize: 18,
    fontWeight: '800',
  },

  profileModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'flex-end',
  },
  profileModalContent: {
    backgroundColor: 'transparent',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '85%',
    borderWidth: 1,
    borderColor: 'rgba(126,184,212,0.5)',
    overflow: 'hidden',
  },
  profileModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 12,
  },
  profileModalTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  profileModalScroll: {
    paddingHorizontal: 20,
    paddingBottom: 32,
  },
  profileModalAvatar: {
    alignItems: 'center',
    marginBottom: 12,
  },
  profileModalAvatarImg: {
    width: 88,
    height: 88,
    borderRadius: 44,
    borderWidth: 2,
    borderColor: SKY,
  },
  profileModalAvatarInner: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 2,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileModalHubIcon: {
    width: 76,
    height: 76,
  },
  profileModalName: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 4,
  },
  profileModalOrg: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 8,
  },
  profileModalJoinedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    marginBottom: 16,
  },
  profileModalJoinedText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
  },
  profileModalStats: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    justifyContent: 'center',
    marginBottom: 24,
  },
  profileModalStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  profileModalStatText: {
    color: '#E5E7EB',
    fontSize: 14,
    fontWeight: '600',
  },
  profileModalPill: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.4)',
  },
  profileModalPillOffline: {
    backgroundColor: 'rgba(148,163,184,0.2)',
    borderColor: 'rgba(148,163,184,0.3)',
  },
  profileModalPillText: {
    color: '#10B981',
    fontSize: 13,
    fontWeight: '700',
  },
  profileModalPillTextOffline: {
    color: '#94A3B8',
  },
  profileModalSection: {
    marginTop: 8,
  },
  profileModalSectionTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 12,
  },
  profileModalReviewsPlaceholder: {
    padding: 24,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.15)',
    alignItems: 'center',
    gap: 8,
  },
  profileModalPlaceholderText: {
    color: 'rgba(148,163,184,0.7)',
    fontSize: 13,
    fontWeight: '500',
  },
  profileModalReviewItem: {
    padding: 12,
    marginBottom: 8,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.15)',
  },
  profileModalReviewHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  profileModalReviewRating: {
    color: '#FBBF24',
    fontSize: 14,
    fontWeight: '700',
  },
  profileModalReviewText: {
    color: '#E5E7EB',
    fontSize: 14,
    lineHeight: 20,
  },
  activeBookingChatBtn: {
    padding: 6,
  },
  profileModalCover: {
    height: 120,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 8,
  },
  profileModalCoverImg: {
    width: '100%',
    height: '100%',
  },
  profileModalCoverPlaceholder: {
    flex: 1,
    backgroundColor: 'rgba(135,206,235,0.1)',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  profileModalHubLogo: {
    alignItems: 'center',
    marginTop: -28,
    marginBottom: 12,
  },
  profileModalHubLogoImg: {
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 2,
    borderColor: SKY,
  },
  profileModalHubLogoInner: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: '#1E293B',
    borderWidth: 2,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  profileModalAddressRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  profileModalAddress: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    flex: 1,
  },

  washHubModalOverlay: {
    flex: 1,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  washHubModalContentWrap: {
    width: '100%',
    maxWidth: 340,
    maxHeight: '85%',
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: customerTheme.primary + '40',
  },
  washHubModalContent: {
    padding: 24,
    backgroundColor: 'transparent',
  },
  washHubModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  washHubModalTitle: {
    fontSize: 20,
    fontWeight: '800',
  },
  washHubModalName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 8,
  },
  washHubModalAddressRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 6,
    marginBottom: 12,
  },
  washHubModalAddress: {
    color: 'rgba(229,231,235,0.9)',
    fontSize: 14,
    flex: 1,
  },
  washHubModalStats: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 12,
  },
  washHubModalStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  washHubModalStatText: {
    fontSize: 12,
    fontWeight: '700',
  },
  washHubModalJoinedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 12,
  },
  washHubModalJoinedText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
  },
  washHubModalSection: {
    marginTop: 4,
  },
  washHubModalSectionTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 8,
  },
  washHubModalReviewItem: {
    padding: 10,
    marginBottom: 6,
    borderRadius: 10,
    backgroundColor: 'rgba(255,255,255,0.06)',
  },
  washHubModalReviewHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 4,
  },
  washHubModalReviewRating: {
    color: '#FBBF24',
    fontSize: 12,
    fontWeight: '700',
  },
  washHubModalReviewText: {
    color: '#E5E7EB',
    fontSize: 13,
    lineHeight: 18,
  },
  washHubModalReviewsPlaceholder: {
    padding: 16,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    alignItems: 'center',
    gap: 6,
  },
  washHubModalPlaceholderText: {
    color: 'rgba(148,163,184,0.7)',
    fontSize: 12,
    fontWeight: '500',
  },
});
