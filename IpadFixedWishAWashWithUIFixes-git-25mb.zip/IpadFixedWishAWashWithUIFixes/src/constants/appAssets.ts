/**
 * Central app logo asset. Preload at boot so splash and loading screens show it instantly.
 */
import { Asset } from 'expo-asset';
import {
  ICON_AUTH,
  CAR_IMAGE as CAR_IMG,
  AUTH_VIDEO as AUTH_VID,
  CARWASH_IMAGE,
  ICON,
  CLEANING_IMAGE,
  DETAILING_IMAGE,
  VALETER_IMAGE,
  VALETER_MAP_IMAGE,
  ONBOARDING_VIDEO as ONBOARDING_VID,
} from '../../app/assets/assetExports';

export const APP_LOGO_SOURCE = ICON_AUTH;

/** Car marker / vehicle icon used on maps and booking flows. */
export const CAR_IMAGE = CAR_IMG;

export { CARWASH_IMAGE, VALETER_IMAGE, VALETER_MAP_IMAGE };

/** Onboarding background video (used in app/onboarding and app/owner/customer-onboarding). */
export const ONBOARDING_VIDEO = ONBOARDING_VID;

let preloadStarted = false;

/** Call once at app start so the logo is cached and appears immediately on loading/splash screens. */
export async function preloadAppLogo(): Promise<void> {
  if (preloadStarted) return;
  preloadStarted = true;
  try {
    await Asset.fromModule(APP_LOGO_SOURCE).downloadAsync();
  } catch {
    // non-critical; image will still load on first use
  }
}

/** Image-only assets to preload at boot. Videos are excluded to avoid memory spikes and native crashes on launch. */
const BOOT_IMAGE_ASSETS = [
  ICON_AUTH,
  CARWASH_IMAGE,
  ICON,
  CAR_IMG,
  CLEANING_IMAGE,
  DETAILING_IMAGE,
];

let bootPreloadStarted = false;

/** Preload critical image assets at boot. Videos (authpages.mp4, onboarding.mp4) load on first use to avoid launch crashes. */
export async function preloadBootAssets(): Promise<void> {
  if (bootPreloadStarted) return;
  bootPreloadStarted = true;
  const results = await Promise.allSettled(
    BOOT_IMAGE_ASSETS.map((mod) => Asset.fromModule(mod).downloadAsync())
  );
  if (__DEV__) {
    results.forEach((r, i) => {
      if (r.status === 'rejected') {
        console.warn(`Boot asset preload failed [${i}]:`, r.reason);
      }
    });
  }
}
