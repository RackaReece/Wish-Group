export default {
  expo: {
    name: "WishAdmin",
    slug: "wish-admin",
    version: "1.0.0",
    orientation: "portrait",
    userInterfaceStyle: "light",
    splash: {
      backgroundColor: "#001a3a"
    },
    assetBundlePatterns: [
      "**/*"
    ],
    ios: {
      supportsTablet: true,
      bundleIdentifier: "com.wishadmin.app"
    },
    android: {
      adaptiveIcon: {
        backgroundColor: "#001a3a"
      },
      package: "com.wishadmin.app"
    },
    web: {
      bundler: "metro"
    },
    extra: {
      supabaseUrl: process.env.EXPO_PUBLIC_SUPABASE_URL,
      supabaseAnonKey: process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY,
    }
  }
};

