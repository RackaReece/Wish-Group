import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabaseClient'

type DashboardStats = {
  totalBookings: number
  totalRevenue: number
  pendingDocs: number
  pendingOrgs: number
}

export default function WishAWashAdmin() {
  const [stats, setStats] = useState<DashboardStats>({
    totalBookings: 0,
    totalRevenue: 0,
    pendingDocs: 0,
    pendingOrgs: 0,
  })
  const [pendingDocuments, setPendingDocuments] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const load = async () => {
      setLoading(true)

      // 1) total bookings
      const { count: totalBookings, error: bookingsError } = await supabase
        .from('bookings')
        .select('id', { count: 'exact', head: true })

      // 2) total revenue = sum(price) for completed bookings
      const { data: revenueRows, error: revenueError } = await supabase
        .from('bookings')
        .select('price, status')
        .in('status', ['completed', 'in_progress']) // tweak if you only want completed
      const totalRevenue = (revenueRows || []).reduce((sum, row) => {
        return sum + Number(row.price || 0)
      }, 0)

      // 3) pending valeter documents
      const { data: docs, error: docsError, count: pendingDocs } = await supabase
        .from('valeter_documents')
        .select('*', { count: 'exact' })
        .eq('status', 'pending')
        .limit(20)

      // 4) pending organisations
      const { count: pendingOrgs, error: orgsError } = await supabase
        .from('organizations')
        .select('id', { count: 'exact', head: true })
        .eq('status', 'pending')

      if (bookingsError || revenueError || docsError || orgsError) {
        setError(
          bookingsError?.message ||
            revenueError?.message ||
            docsError?.message ||
            orgsError?.message ||
            'Unknown error'
        )
        setLoading(false)
        return
      }

      setStats({
        totalBookings: totalBookings || 0,
        totalRevenue,
        pendingDocs: pendingDocs || 0,
        pendingOrgs: pendingOrgs || 0,
      })

      setPendingDocuments(docs || [])
      setLoading(false)
    }

    load()
  }, [])

  const approveDocument = async (docId: string) => {
    // this will only work if RLS allows it
    const { error } = await supabase
      .from('valeter_documents')
      .update({
        status: 'approved',
        approved_at: new Date().toISOString(),
        // approved_by: (your logged in admin user id) — we’ll wire auth later
      })
      .eq('id', docId)

    if (error) {
      alert('Failed to approve: ' + error.message)
      return
    }

    // update UI
    setPendingDocuments((prev) => prev.filter((p) => p.id !== docId))
    setStats((prev) => ({ ...prev, pendingDocs: prev.pendingDocs - 1 }))
  }

  if (loading) {
    return <div style={{ padding: '2rem', color: 'white' }}>Loading admin data…</div>
  }

  if (error) {
    return <div style={{ padding: '2rem', color: 'red' }}>Error: {error}</div>
  }

  return (
    <div style={{ minHeight: '100vh', background: '#020617', color: 'white' }}>
      <header style={{ padding: '1.5rem 2rem', borderBottom: '1px solid rgba(255,255,255,0.05)' }}>
        <h1 style={{ fontSize: '1.6rem', margin: 0 }}>Wish-a-Wash Admin</h1>
        <p style={{ opacity: 0.6, marginTop: '0.4rem' }}>
          Overview of bookings, documents and organisations
        </p>
      </header>

      <main style={{ padding: '2rem', maxWidth: '1200px', margin: '0 auto' }}>
        {/* KPI cards */}
        <div style={{ display: 'flex', gap: '1rem', flexWrap: 'wrap', marginBottom: '2rem' }}>
          <StatCard title="Total bookings" value={stats.totalBookings.toString()} />
          <StatCard
            title="Total revenue"
            value={`£${stats.totalRevenue.toFixed(2)}`}
          />
          <StatCard title="Pending documents" value={stats.pendingDocs.toString()} />
          <StatCard title="Pending organisations" value={stats.pendingOrgs.toString()} />
        </div>

        {/* Pending documents table */}
        <section>
          <h2 style={{ marginBottom: '1rem' }}>Pending valeter documents</h2>
          {pendingDocuments.length === 0 ? (
            <p style={{ opacity: 0.6 }}>No pending documents 🎉</p>
          ) : (
            <div
              style={{
                background: 'rgba(15,23,42,0.5)',
                border: '1px solid rgba(255,255,255,0.03)',
                borderRadius: '1rem',
                overflow: 'hidden',
              }}
            >
              <table style={{ width: '100%', borderCollapse: 'collapse' }}>
                <thead style={{ background: 'rgba(2,6,23,0.4)' }}>
                  <tr>
                    <th style={th}>Name</th>
                    <th style={th}>Type</th>
                    <th style={th}>Status</th>
                    <th style={th}>Uploaded</th>
                    <th style={th}>File</th>
                    <th style={th}></th>
                  </tr>
                </thead>
                <tbody>
                  {pendingDocuments.map((doc) => (
                    <tr key={doc.id}>
                      <td style={td}>{doc.name}</td>
                      <td style={td}>{doc.type}</td>
                      <td style={td}>{doc.status}</td>
                      <td style={td}>
                        {doc.uploaded_at ? new Date(doc.uploaded_at).toLocaleString() : '-'}
                      </td>
                      <td style={td}>
                        {doc.file_url ? (
                          <a href={doc.file_url} target="_blank" rel="noreferrer">
                            View
                          </a>
                        ) : (
                          '—'
                        )}
                      </td>
                      <td style={td}>
                        <button
                          onClick={() => approveDocument(doc.id)}
                          style={{
                            background: '#22c55e',
                            border: 'none',
                            padding: '0.4rem 0.9rem',
                            borderRadius: '9999px',
                            cursor: 'pointer',
                          }}
                        >
                          Approve
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
      </main>
    </div>
  )
}

const th: React.CSSProperties = {
  textAlign: 'left',
  padding: '0.75rem 1rem',
  fontWeight: 600,
  fontSize: '0.85rem',
}

const td: React.CSSProperties = {
  padding: '0.6rem 1rem',
  borderBottom: '1px solid rgba(255,255,255,0.02)',
  fontSize: '0.8rem',
}

function StatCard({ title, value }: { title: string; value: string }) {
  return (
    <div
      style={{
        background: 'rgba(15,23,42,0.6)',
        border: '1px solid rgba(255,255,255,0.03)',
        borderRadius: '1rem',
        padding: '1.2rem 1.4rem',
        minWidth: '200px',
        flex: '1 1 200px',
      }}
    >
      <p style={{ opacity: 0.6, fontSize: '0.8rem' }}>{title}</p>
      <p style={{ fontSize: '1.4rem', fontWeight: 600, marginTop: '0.25rem' }}>{value}</p>
    </div>
  )
}