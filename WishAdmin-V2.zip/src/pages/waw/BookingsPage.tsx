// src/pages/waw/BookingsPage.tsx
import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'

type Booking = {
  id: string
  service_type: string
  status: string
  price: number
  scheduled_at: string | null
  location_address: string | null
  created_at: string
}

export default function BookingsPage() {
  const [bookings, setBookings] = useState<Booking[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      if (!supabaseUrl || !supabaseAnonKey) {
        setBookings([]);
        setLoading(false);
        return;
      }

      setLoading(true)
      try {
        const { data, error } = await supabase
          .from('bookings')
          .select(
            'id, service_type, status, price, scheduled_at, location_address, created_at'
          )
          .order('created_at', { ascending: false })
          .limit(50)

        if (!error) {
          setBookings((data || []) as Booking[])
        } else {
          console.error('Error loading bookings:', error);
        }
      } catch (error) {
        console.error('Error loading bookings:', error);
      } finally {
        setLoading(false)
      }
    }

    load()
  }, [])

  return (
    <div className="container-fluid px-0">
      <h1 className="h4 mb-3 text-white">Bookings</h1>
      <p className="text-white-50 mb-4">Latest bookings across the platform.</p>

      <div 
        className="card shadow-sm border-0"
        style={{
          background: 'rgba(255, 255, 255, 0.1)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderRadius: 20,
          border: '1px solid rgba(255, 255, 255, 0.2)',
        }}
      >
        <div 
          className="card-header d-flex justify-content-between align-items-center"
          style={{
            background: 'rgba(255, 255, 255, 0.05)',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
          }}
        >
          <h6 className="mb-0 text-white">Recent bookings</h6>
          <span 
            className="badge"
            style={{
              background: 'rgba(255, 255, 255, 0.2)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              color: '#fff',
            }}
          >
            {bookings.length} loaded
          </span>
        </div>

        <div className="table-responsive">
          {loading ? (
            <p className="p-3 mb-0 text-white-50">Loading…</p>
          ) : (
            <table className="table table-sm mb-0 align-middle">
              <thead 
                style={{
                  background: 'rgba(255, 255, 255, 0.05)',
                  backdropFilter: 'blur(10px)',
                }}
              >
                <tr>
                  <th style={{ width: '20%', color: '#fff' }}>Service</th>
                  <th style={{ width: '12%', color: '#fff' }}>Status</th>
                  <th style={{ width: '10%', color: '#fff' }} className="text-end">
                    Price
                  </th>
                  <th style={{ width: '20%', color: '#fff' }}>Scheduled / created</th>
                  <th style={{ color: '#fff' }}>Location</th>
                </tr>
              </thead>
              <tbody>
                {bookings.map((b) => (
                  <tr 
                    key={b.id}
                    style={{
                      borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                      transition: 'all 0.2s ease',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'rgba(255, 255, 255, 0.05)';
                      e.currentTarget.style.backdropFilter = 'blur(10px)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'transparent';
                      e.currentTarget.style.backdropFilter = 'none';
                    }}
                  >
                    <td className="text-white">{b.service_type}</td>
                    <td>{renderStatus(b.status)}</td>
                    <td className="text-end text-white">
                      £{Number(b.price || 0).toFixed(2)}
                    </td>
                    <td className="small text-white-50">
                      {b.scheduled_at
                        ? new Date(b.scheduled_at).toLocaleString()
                        : new Date(b.created_at).toLocaleString()}
                    </td>
                    <td className="small text-white">
                      {b.location_address ? b.location_address : <span className="text-white-50">—</span>}
                    </td>
                  </tr>
                ))}

                {!loading && bookings.length === 0 && (
                  <tr>
                    <td colSpan={5} className="text-center py-4 text-white-50">
                      No bookings found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  )
}

function renderStatus(status: string) {
  const colorMap: Record<string, { bg: string; border: string }> = {
    completed: { bg: 'rgba(34, 197, 94, 0.3)', border: 'rgba(34, 197, 94, 0.5)' },
    in_progress: { bg: 'rgba(0, 115, 255, 0.3)', border: 'rgba(0, 115, 255, 0.5)' },
    scheduled: { bg: 'rgba(14, 165, 233, 0.3)', border: 'rgba(14, 165, 233, 0.5)' },
    cancelled: { bg: 'rgba(239, 68, 68, 0.3)', border: 'rgba(239, 68, 68, 0.5)' },
  }
  const colors = colorMap[status] || { bg: 'rgba(255, 255, 255, 0.2)', border: 'rgba(255, 255, 255, 0.3)' }
  return (
    <span
      className="badge"
      style={{ 
        textTransform: 'capitalize',
        background: colors.bg,
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        border: `1px solid ${colors.border}`,
        color: '#fff',
      }}
    >
      {status.replace('_', ' ')}
    </span>
  )
}