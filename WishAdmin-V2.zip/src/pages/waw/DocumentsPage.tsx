// src/pages/waw/DocumentsPage.tsx
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../../lib/supabaseClient'

type ValeterDoc = {
  id: string
  user_id: string
  name: string
  type: string
  status: string
  file_url: string | null
  uploaded_at: string | null
}

export default function DocumentsPage() {
  const [docs, setDocs] = useState<ValeterDoc[]>([])
  const [loading, setLoading] = useState(true)
  const [openValeter, setOpenValeter] = useState<string | null>(null)

  useEffect(() => {
    const load = async () => {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      if (!supabaseUrl || !supabaseAnonKey) {
        setDocs([]);
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('valeter_documents')
          .select('id, user_id, name, type, status, file_url, uploaded_at')
          .order('created_at', { ascending: false })
          .limit(100)

        if (!error) setDocs((data || []) as ValeterDoc[])
        else console.error('Error loading documents:', error);
      } catch (error) {
        console.error('Error loading documents:', error);
      } finally {
        setLoading(false)
      }
    }
    load()
  }, [])

  const updateStatus = async (id: string, status: 'approved' | 'rejected') => {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
    
    if (!supabaseUrl || !supabaseAnonKey) {
      console.warn('Cannot update status: Supabase credentials missing');
      return;
    }

    try {
      const { error } = await supabase
        .from('valeter_documents')
        .update({
          status,
          approved_at: status === 'approved' ? new Date().toISOString() : null,
        })
        .eq('id', id)

      if (!error) {
        setDocs((prev) => prev.map((d) => (d.id === id ? { ...d, status } : d)))
      } else {
        console.error('Error updating status:', error);
      }
    } catch (error) {
      console.error('Error updating status:', error);
    }
  }

  // group by user_id
  const groups: Record<string, ValeterDoc[]> = docs.reduce((acc, doc) => {
    if (!acc[doc.user_id]) acc[doc.user_id] = []
    acc[doc.user_id].push(doc)
    return acc
  }, {} as Record<string, ValeterDoc[]>)

  const valeterIds = Object.keys(groups)

  return (
    <div className="container-fluid px-0">
      <h1 className="h4 mb-3 text-white">Valeter Documents</h1>
      <p className="text-white-50 mb-4">
        Review and approve documents uploaded by valeters.
      </p>

      <div 
        className="card shadow-sm border-0"
        style={{
          background: 'rgba(255, 255, 255, 0.1)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderRadius: 20,
          border: '1px solid rgba(255, 255, 255, 0.2)',
        }}
      >
        <div 
          className="card-header d-flex justify-content-between align-items-center"
          style={{
            background: 'rgba(255, 255, 255, 0.05)',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
          }}
        >
          <h6 className="mb-0 text-white">Documents</h6>
          <span 
            className="badge"
            style={{
              background: 'rgba(255, 255, 255, 0.2)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              color: '#fff',
            }}
          >
            {docs.length} total
          </span>
        </div>

        {loading ? (
          <p className="p-3 mb-0 text-white-50">Loading…</p>
        ) : valeterIds.length === 0 ? (
          <p className="p-3 mb-0 text-white-50">No documents found.</p>
        ) : (
          <div className="list-group list-group-flush">
            {valeterIds.map((valeterId) => {
              const valsDocs = groups[valeterId]
              const isOpen = openValeter === valeterId

              // count statuses per valeter
              const counts = valsDocs.reduce(
                (acc, d) => {
                  acc[d.status] = (acc[d.status] || 0) + 1
                  return acc
                },
                {} as Record<string, number>
              )

              return (
                <div 
                  key={valeterId} 
                  className="list-group-item"
                  style={{
                    background: 'rgba(255, 255, 255, 0.05)',
                    borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                  }}
                >
                  {/* header row per valeter */}
                  <div className="d-flex justify-content-between align-items-center flex-wrap">
                    <div className="d-flex align-items-center gap-2 flex-wrap">
                      <Link
                        to={`/wish-a-wash/valeters/${valeterId}`}
                        className="text-decoration-none fw-semibold text-white"
                      >
                        Valeter {valeterId.slice(0, 8)}…
                      </Link>

                      <span 
                        className="badge"
                        style={{
                          background: 'rgba(255, 255, 255, 0.2)',
                          backdropFilter: 'blur(10px)',
                          border: '1px solid rgba(255, 255, 255, 0.3)',
                          color: '#fff',
                        }}
                      >
                        {valsDocs.length} total
                      </span>

                      {/* status summary badges */}
                      <StatusCountBadge label="pending" count={counts.pending} color="warning" />
                      <StatusCountBadge label="approved" count={counts.approved} color="success" />
                      <StatusCountBadge label="rejected" count={counts.rejected} color="danger" />
                    </div>

                    <button
                      className="btn btn-sm mt-2 mt-md-0"
                      onClick={() => setOpenValeter(isOpen ? null : valeterId)}
                      style={{
                        background: 'rgba(255, 255, 255, 0.1)',
                        backdropFilter: 'blur(10px)',
                        border: '1px solid rgba(255, 255, 255, 0.2)',
                        color: '#fff',
                      }}
                    >
                      {isOpen ? 'Hide' : 'View'}
                    </button>
                  </div>

                  {isOpen && (
                    <div className="table-responsive mt-3">
                      <table className="table table-sm mb-0 align-middle">
                        <thead 
                          style={{
                            background: 'rgba(255, 255, 255, 0.05)',
                            backdropFilter: 'blur(10px)',
                          }}
                        >
                          <tr>
                            <th style={{ color: '#fff' }}>Name</th>
                            <th style={{ color: '#fff' }}>Type</th>
                            <th style={{ color: '#fff' }}>Status</th>
                            <th style={{ color: '#fff' }}>Uploaded</th>
                            <th style={{ color: '#fff' }}>File</th>
                            <th className="text-end" style={{ color: '#fff' }}>Actions</th>
                          </tr>
                        </thead>
                        <tbody>
                          {valsDocs.map((doc) => (
                            <tr 
                              key={doc.id}
                              style={{
                                borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                                transition: 'all 0.2s ease',
                              }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.background = 'rgba(255, 255, 255, 0.05)';
                                e.currentTarget.style.backdropFilter = 'blur(10px)';
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.background = 'transparent';
                                e.currentTarget.style.backdropFilter = 'none';
                              }}
                            >
                              <td className="text-white">{doc.name}</td>
                              <td className="text-white-50 small">{doc.type}</td>
                              <td>{renderStatus(doc.status)}</td>
                              <td className="small text-white-50">
                                {doc.uploaded_at
                                  ? new Date(doc.uploaded_at).toLocaleString()
                                  : '—'}
                              </td>
                              <td>
                                {doc.file_url ? (
                                  <a
                                    href={doc.file_url}
                                    target="_blank"
                                    rel="noreferrer"
                                    className="btn btn-link btn-sm p-0 text-white"
                                    style={{ textDecoration: 'underline' }}
                                  >
                                    View
                                  </a>
                                ) : (
                                  <span className="text-white-50 small">No file</span>
                                )}
                              </td>
                              <td className="text-end">
                                <div className="btn-group btn-group-sm" role="group">
                                  <button
                                    type="button"
                                    className="btn"
                                    onClick={() => updateStatus(doc.id, 'approved')}
                                    style={{
                                      background: 'rgba(34, 197, 94, 0.3)',
                                      backdropFilter: 'blur(10px)',
                                      border: '1px solid rgba(34, 197, 94, 0.5)',
                                      color: '#fff',
                                    }}
                                  >
                                    Approve
                                  </button>
                                  <button
                                    type="button"
                                    className="btn"
                                    onClick={() => updateStatus(doc.id, 'rejected')}
                                    style={{
                                      background: 'rgba(239, 68, 68, 0.3)',
                                      backdropFilter: 'blur(10px)',
                                      border: '1px solid rgba(239, 68, 68, 0.5)',
                                      color: '#fff',
                                    }}
                                  >
                                    Reject
                                  </button>
                                </div>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

function renderStatus(status: string) {
  const colorMap: Record<string, { bg: string; border: string }> = {
    pending: { bg: 'rgba(249, 115, 22, 0.3)', border: 'rgba(249, 115, 22, 0.5)' },
    approved: { bg: 'rgba(34, 197, 94, 0.3)', border: 'rgba(34, 197, 94, 0.5)' },
    rejected: { bg: 'rgba(239, 68, 68, 0.3)', border: 'rgba(239, 68, 68, 0.5)' },
    not_uploaded: { bg: 'rgba(255, 255, 255, 0.2)', border: 'rgba(255, 255, 255, 0.3)' },
  }
  const colors = colorMap[status] || { bg: 'rgba(255, 255, 255, 0.2)', border: 'rgba(255, 255, 255, 0.3)' }
  return (
    <span
      className="badge"
      style={{ 
        textTransform: 'capitalize',
        background: colors.bg,
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        border: `1px solid ${colors.border}`,
        color: '#fff',
      }}
    >
      {status.replace('_', ' ')}
    </span>
  )
}

function StatusCountBadge({
  label,
  count,
  color,
}: {
  label: string
  count?: number
  color: string
}) {
  if (!count) return null
  const colorMap: Record<string, { bg: string; border: string }> = {
    warning: { bg: 'rgba(249, 115, 22, 0.3)', border: 'rgba(249, 115, 22, 0.5)' },
    success: { bg: 'rgba(34, 197, 94, 0.3)', border: 'rgba(34, 197, 94, 0.5)' },
    danger: { bg: 'rgba(239, 68, 68, 0.3)', border: 'rgba(239, 68, 68, 0.5)' },
  }
  const colors = colorMap[color] || { bg: 'rgba(255, 255, 255, 0.2)', border: 'rgba(255, 255, 255, 0.3)' }
  return (
    <span
      className="badge"
      style={{ 
        textTransform: 'capitalize',
        background: colors.bg,
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        border: `1px solid ${colors.border}`,
        color: '#fff',
      }}
    >
      {label}: {count}
    </span>
  )
}