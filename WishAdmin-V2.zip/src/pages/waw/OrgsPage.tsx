import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { supabase } from '../../lib/supabaseClient'

type Org = {
  id: string
  name: string
  contact_email: string
  status: string
  is_verified: boolean
  insurance_verified: boolean
  license_verified: boolean
  created_at: string
}

export default function OrgsPage() {
  const [orgs, setOrgs] = useState<Org[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      if (!supabaseUrl || !supabaseAnonKey) {
        setOrgs([]);
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('organizations')
          .select(
            'id, name, contact_email, status, is_verified, insurance_verified, license_verified, created_at'
          )
          .order('created_at', { ascending: false })
          .limit(100)

        if (!error) setOrgs((data || []) as Org[])
        else console.error('Error loading organisations:', error);
      } catch (error) {
        console.error('Error loading organisations:', error);
      } finally {
        setLoading(false)
      }
    }

    load()
  }, [])

  const verifyOrg = async (id: string) => {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
    
    if (!supabaseUrl || !supabaseAnonKey) {
      console.warn('Cannot verify organisation: Supabase credentials missing');
      return;
    }

    try {
      const { error } = await supabase
        .from('organizations')
        .update({
          status: 'active',
          is_verified: true,
          updated_at: new Date().toISOString(),
        })
        .eq('id', id)

      if (!error) {
        setOrgs((prev) =>
          prev.map((o) =>
            o.id === id ? { ...o, status: 'active', is_verified: true } : o
          )
        )
      } else {
        console.error('Error verifying organisation:', error);
      }
    } catch (error) {
      console.error('Error verifying organisation:', error);
    }
  }

  return (
    <div className="container-fluid px-0">
      <h1 className="h4 mb-3 text-white">Organisations</h1>
      <p className="text-white-50 mb-4">
        Approve and monitor organisation accounts.
      </p>

      <div 
        className="card shadow-sm border-0"
        style={{
          background: 'rgba(255, 255, 255, 0.1)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderRadius: 20,
          border: '1px solid rgba(255, 255, 255, 0.2)',
        }}
      >
        <div 
          className="card-header d-flex justify-content-between align-items-center"
          style={{
            background: 'rgba(255, 255, 255, 0.05)',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
          }}
        >
          <h6 className="mb-0 text-white">Organisation accounts</h6>
          <span 
            className="badge"
            style={{
              background: 'rgba(255, 255, 255, 0.2)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              color: '#fff',
            }}
          >
            {orgs.length} total
          </span>
        </div>

        <div className="table-responsive">
          {loading ? (
            <p className="p-3 mb-0 text-white-50">Loading…</p>
          ) : (
            <table className="table table-sm mb-0 align-middle">
              <thead 
                style={{
                  background: 'rgba(255, 255, 255, 0.05)',
                  backdropFilter: 'blur(10px)',
                }}
              >
                <tr>
                  <th style={{ width: '20%', color: '#fff' }}>Name</th>
                  <th style={{ width: '22%', color: '#fff' }}>Email</th>
                  <th style={{ width: '12%', color: '#fff' }}>Status</th>
                  <th style={{ width: '10%', color: '#fff' }}>Verified</th>
                  <th style={{ width: '14%', color: '#fff' }}>Created</th>
                  <th style={{ width: '22%', color: '#fff' }}></th>
                </tr>
              </thead>
              <tbody>
                {orgs.map((org) => (
                  <tr 
                    key={org.id}
                    style={{
                      borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                      transition: 'all 0.2s ease',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'rgba(255, 255, 255, 0.05)';
                      e.currentTarget.style.backdropFilter = 'blur(10px)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'transparent';
                      e.currentTarget.style.backdropFilter = 'none';
                    }}
                  >
                    <td className="text-white">{org.name}</td>
                    <td className="small text-white-50">{org.contact_email}</td>
                    <td>{renderStatus(org.status)}</td>
                    <td>
                      {org.is_verified ? (
                        <span 
                          className="badge"
                          style={{
                            background: 'rgba(34, 197, 94, 0.3)',
                            backdropFilter: 'blur(10px)',
                            border: '1px solid rgba(34, 197, 94, 0.5)',
                            color: '#fff',
                          }}
                        >
                          Yes
                        </span>
                      ) : (
                        <span 
                          className="badge"
                          style={{
                            background: 'rgba(255, 255, 255, 0.2)',
                            backdropFilter: 'blur(10px)',
                            border: '1px solid rgba(255, 255, 255, 0.3)',
                            color: '#fff',
                          }}
                        >
                          No
                        </span>
                      )}
                    </td>
                    <td className="small text-white-50">
                      {org.created_at
                        ? new Date(org.created_at).toLocaleDateString()
                        : '—'}
                    </td>
                    <td className="text-end">
                      <div className="btn-group btn-group-sm" role="group">
                        {org.status === 'pending' ? (
                          <button
                            className="btn"
                            onClick={() => verifyOrg(org.id)}
                            style={{
                              background: 'rgba(34, 197, 94, 0.3)',
                              backdropFilter: 'blur(10px)',
                              border: '1px solid rgba(34, 197, 94, 0.5)',
                              color: '#fff',
                              transition: 'all 0.2s ease',
                            }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.background = 'rgba(34, 197, 94, 0.4)';
                              e.currentTarget.style.transform = 'scale(1.02)';
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.background = 'rgba(34, 197, 94, 0.3)';
                              e.currentTarget.style.transform = 'scale(1)';
                            }}
                          >
                            Approve
                          </button>
                        ) : (
                          <button
                            className="btn"
                            disabled
                            style={{
                              background: 'rgba(255, 255, 255, 0.1)',
                              backdropFilter: 'blur(10px)',
                              border: '1px solid rgba(255, 255, 255, 0.2)',
                              color: 'rgba(255, 255, 255, 0.5)',
                            }}
                          >
                            Approved
                          </button>
                        )}
                        <Link
                          to={`/wish-a-wash/organizations/${org.id}/locations`}
                          className="btn"
                          style={{
                            background: 'rgba(0, 115, 255, 0.3)',
                            backdropFilter: 'blur(10px)',
                            border: '1px solid rgba(0, 115, 255, 0.5)',
                            color: '#fff',
                            textDecoration: 'none',
                            transition: 'all 0.2s ease',
                          }}
                          onMouseEnter={(e) => {
                            e.currentTarget.style.background = 'rgba(0, 115, 255, 0.4)';
                            e.currentTarget.style.transform = 'scale(1.02)';
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.background = 'rgba(0, 115, 255, 0.3)';
                            e.currentTarget.style.transform = 'scale(1)';
                          }}
                        >
                          Locations
                        </Link>
                      </div>
                    </td>
                  </tr>
                ))}

                {!loading && orgs.length === 0 && (
                  <tr>
                    <td colSpan={6} className="text-center py-4 text-white-50">
                      No organisations found.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  )
}

function renderStatus(status: string) {
  const colorMap: Record<string, { bg: string; border: string }> = {
    pending: { bg: 'rgba(249, 115, 22, 0.3)', border: 'rgba(249, 115, 22, 0.5)' },
    active: { bg: 'rgba(34, 197, 94, 0.3)', border: 'rgba(34, 197, 94, 0.5)' },
    suspended: { bg: 'rgba(239, 68, 68, 0.3)', border: 'rgba(239, 68, 68, 0.5)' },
  }
  const colors = colorMap[status] || { bg: 'rgba(255, 255, 255, 0.2)', border: 'rgba(255, 255, 255, 0.3)' }

  return (
    <span
      className="badge"
      style={{ 
        textTransform: 'capitalize',
        background: colors.bg,
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        border: `1px solid ${colors.border}`,
        color: '#fff',
      }}
    >
      {status}
    </span>
  )
}