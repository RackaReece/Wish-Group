// src/pages/waw/ReportsPage.tsx
import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'
import { IoDocumentTextOutline, IoDownloadOutline, IoCalendarOutline, IoCashOutline } from 'react-icons/io5'

type Report = {
  id: string
  name: string
  type: string
  generated_at: string
  period_start: string
  period_end: string
  status: 'generating' | 'completed' | 'failed'
  file_url: string | null
  created_by?: string
}

export default function ReportsPage() {
  const [reports, setReports] = useState<Report[]>([])
  const [loading, setLoading] = useState(true)
  const [generating, setGenerating] = useState<string | null>(null)

  useEffect(() => {
    const load = async () => {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      if (!supabaseUrl || !supabaseAnonKey) {
        // Load from localStorage if no Supabase
        const savedReports = localStorage.getItem('waw_reports')
        if (savedReports) {
          try {
            setReports(JSON.parse(savedReports))
          } catch (e) {
            console.error('Error parsing saved reports:', e)
          }
        }
        setLoading(false)
        return
      }

      setLoading(true)
      try {
        // Try to fetch from reports table if it exists
        const { data, error } = await supabase
          .from('reports')
          .select('*')
          .order('generated_at', { ascending: false })
          .limit(100)

        if (!error && data) {
          setReports(data as Report[])
        } else {
          // Fallback to localStorage
          const savedReports = localStorage.getItem('waw_reports')
          if (savedReports) {
            try {
              setReports(JSON.parse(savedReports))
            } catch (e) {
              console.error('Error parsing saved reports:', e)
            }
          }
        }
      } catch (error) {
        console.error('Error loading reports:', error)
        // Fallback to localStorage
        const savedReports = localStorage.getItem('waw_reports')
        if (savedReports) {
          try {
            setReports(JSON.parse(savedReports))
          } catch (e) {
            console.error('Error parsing saved reports:', e)
          }
        }
      } finally {
        setLoading(false)
      }
    }

    load()
  }, [])

  const saveReports = (newReports: Report[]) => {
    setReports(newReports)
    localStorage.setItem('waw_reports', JSON.stringify(newReports))
  }

  const generateReport = async (type: string) => {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
    
    setGenerating(type)
    
    // Calculate period (last 30 days)
    const endDate = new Date()
    const startDate = new Date()
    startDate.setDate(startDate.getDate() - 30)

    const reportName = {
      revenue: 'Monthly Revenue Report',
      bookings: 'Bookings Statistics Report',
      performance: 'Performance Metrics Report',
    }[type] || 'Custom Report'

    const newReport: Report = {
      id: `report_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      name: reportName,
      type: type,
      generated_at: new Date().toISOString(),
      period_start: startDate.toISOString().split('T')[0],
      period_end: endDate.toISOString().split('T')[0],
      status: 'generating',
      file_url: null,
    }

    // Add to list immediately with "generating" status
    const updatedReports = [newReport, ...reports]
    saveReports(updatedReports)

    try {
      // Simulate report generation (2-3 seconds)
      await new Promise(resolve => setTimeout(resolve, 2000 + Math.random() * 1000))

      // Generate CSV data (simulated)
      const csvData = generateCSVData(type, startDate, endDate)
      const blob = new Blob([csvData], { type: 'text/csv' })
      const url = URL.createObjectURL(blob)

      // Update report status to completed
      const completedReport: Report = {
        ...newReport,
        status: 'completed',
        file_url: url,
      }

      const finalReports = updatedReports.map(r => 
        r.id === newReport.id ? completedReport : r
      )
      saveReports(finalReports)

      // Try to save to Supabase if available
      if (supabaseUrl && supabaseAnonKey) {
        try {
          await supabase
            .from('reports')
            .upsert({
              id: completedReport.id,
              name: completedReport.name,
              type: completedReport.type,
              generated_at: completedReport.generated_at,
              period_start: completedReport.period_start,
              period_end: completedReport.period_end,
              status: completedReport.status,
              file_url: completedReport.file_url,
            })
        } catch (dbError) {
          console.warn('Could not save to database, using localStorage:', dbError)
        }
      }
    } catch (error) {
      console.error('Error generating report:', error)
      // Update to failed status
      const failedReport: Report = {
        ...newReport,
        status: 'failed',
      }
      const finalReports = updatedReports.map(r => 
        r.id === newReport.id ? failedReport : r
      )
      saveReports(finalReports)
    } finally {
      setGenerating(null)
    }
  }

  const generateCSVData = (type: string, startDate: Date, endDate: Date): string => {
    const headers = {
      revenue: 'Date,Service Type,Amount,Status\n',
      bookings: 'Date,Service Type,Status,Price,Customer\n',
      performance: 'Valeter ID,Bookings Completed,Total Revenue,Avg Rating\n',
    }[type] || 'Column1,Column2,Column3\n'

    // Generate sample data rows
    const rows: string[] = []
    const days = Math.ceil((endDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24))
    
    for (let i = 0; i < Math.min(days, 30); i++) {
      const date = new Date(startDate)
      date.setDate(date.getDate() + i)
      const dateStr = date.toISOString().split('T')[0]
      
      if (type === 'revenue') {
        rows.push(`${dateStr},Standard Wash,${(Math.random() * 50 + 20).toFixed(2)},Completed\n`)
        rows.push(`${dateStr},Premium Wash,${(Math.random() * 80 + 40).toFixed(2)},Completed\n`)
      } else if (type === 'bookings') {
        rows.push(`${dateStr},Standard Wash,Completed,${(Math.random() * 50 + 20).toFixed(2)},customer@example.com\n`)
      } else if (type === 'performance') {
        rows.push(`valeter_${i},${Math.floor(Math.random() * 10 + 5)},${(Math.random() * 500 + 200).toFixed(2)},${(Math.random() * 2 + 3).toFixed(1)}\n`)
      }
    }

    return headers + rows.join('')
  }

  const deleteReport = (id: string) => {
    if (confirm('Are you sure you want to delete this report?')) {
      const updatedReports = reports.filter(r => r.id !== id)
      saveReports(updatedReports)
      
      // Try to delete from Supabase if available
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      if (supabaseUrl && supabaseAnonKey) {
        supabase.from('reports').delete().eq('id', id).catch(console.error)
      }
    }
  }

  return (
    <div className="container-fluid px-0">
      <h1 className="h4 mb-3 text-white">Reports</h1>
      <p className="text-white-50 mb-4">
        Generate and download financial, booking, and performance reports.
      </p>

      {/* Quick Generate Cards */}
      <div className="row g-3 mb-4">
        <div className="col-12 col-md-4">
          <div
            className="card shadow-sm border-0 h-100"
            style={{
              background: 'rgba(255, 255, 255, 0.1)',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              borderRadius: 20,
              border: '1px solid rgba(255, 255, 255, 0.2)',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-4px)'
              e.currentTarget.style.boxShadow = '0 16px 40px rgba(0,0,0,0.3)'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)'
              e.currentTarget.style.boxShadow = 'none'
            }}
            onClick={() => !generating && generateReport('revenue')}
            style={{
              opacity: generating === 'revenue' ? 0.6 : 1,
              cursor: generating ? 'not-allowed' : 'pointer',
            }}
          >
            <div className="card-body p-4">
              <div className="d-flex align-items-center justify-content-between mb-3">
                <h6 className="mb-0 text-white">
                  {generating === 'revenue' ? 'Generating...' : 'Revenue Report'}
                </h6>
                <IoCashOutline size={24} style={{ color: 'rgba(255, 255, 255, 0.7)' }} />
              </div>
              <p className="small text-white-50 mb-0">
                Monthly revenue breakdown by service type
              </p>
            </div>
          </div>
        </div>

        <div className="col-12 col-md-4">
          <div
            className="card shadow-sm border-0 h-100"
            style={{
              background: 'rgba(255, 255, 255, 0.1)',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              borderRadius: 20,
              border: '1px solid rgba(255, 255, 255, 0.2)',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-4px)'
              e.currentTarget.style.boxShadow = '0 16px 40px rgba(0,0,0,0.3)'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)'
              e.currentTarget.style.boxShadow = 'none'
            }}
            onClick={() => !generating && generateReport('bookings')}
            style={{
              opacity: generating === 'bookings' ? 0.6 : 1,
              cursor: generating ? 'not-allowed' : 'pointer',
            }}
          >
            <div className="card-body p-4">
              <div className="d-flex align-items-center justify-content-between mb-3">
                <h6 className="mb-0 text-white">
                  {generating === 'bookings' ? 'Generating...' : 'Bookings Report'}
                </h6>
                <IoCalendarOutline size={24} style={{ color: 'rgba(255, 255, 255, 0.7)' }} />
              </div>
              <p className="small text-white-50 mb-0">
                Booking statistics and trends
              </p>
            </div>
          </div>
        </div>

        <div className="col-12 col-md-4">
          <div
            className="card shadow-sm border-0 h-100"
            style={{
              background: 'rgba(255, 255, 255, 0.1)',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              borderRadius: 20,
              border: '1px solid rgba(255, 255, 255, 0.2)',
              cursor: 'pointer',
              transition: 'all 0.3s ease',
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.transform = 'translateY(-4px)'
              e.currentTarget.style.boxShadow = '0 16px 40px rgba(0,0,0,0.3)'
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.transform = 'translateY(0)'
              e.currentTarget.style.boxShadow = 'none'
            }}
            onClick={() => !generating && generateReport('performance')}
            style={{
              opacity: generating === 'performance' ? 0.6 : 1,
              cursor: generating ? 'not-allowed' : 'pointer',
            }}
          >
            <div className="card-body p-4">
              <div className="d-flex align-items-center justify-content-between mb-3">
                <h6 className="mb-0 text-white">
                  {generating === 'performance' ? 'Generating...' : 'Performance Report'}
                </h6>
                <IoDocumentTextOutline size={24} style={{ color: 'rgba(255, 255, 255, 0.7)' }} />
              </div>
              <p className="small text-white-50 mb-0">
                Valeter and location performance metrics
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Reports List */}
      <div 
        className="card shadow-sm border-0"
        style={{
          background: 'rgba(255, 255, 255, 0.1)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderRadius: 20,
          border: '1px solid rgba(255, 255, 255, 0.2)',
        }}
      >
        <div 
          className="card-header d-flex justify-content-between align-items-center"
          style={{
            background: 'rgba(255, 255, 255, 0.05)',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
          }}
        >
          <h6 className="mb-0 text-white">Generated Reports</h6>
          <span 
            className="badge"
            style={{
              background: 'rgba(255, 255, 255, 0.2)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              color: '#fff',
            }}
          >
            {reports.length} total
          </span>
        </div>

        <div className="table-responsive">
          {loading ? (
            <p className="p-3 mb-0 text-white-50">Loading…</p>
          ) : reports.length === 0 ? (
            <div className="p-5 text-center">
              <IoDocumentTextOutline size={48} style={{ color: 'rgba(255, 255, 255, 0.3)', marginBottom: '1rem' }} />
              <p className="text-white-50 mb-0">No reports generated yet.</p>
              <p className="text-white-50 small mb-0">Click on a report type above to generate one.</p>
            </div>
          ) : (
            <table className="table table-sm mb-0 align-middle">
              <thead 
                style={{
                  background: 'rgba(255, 255, 255, 0.05)',
                  backdropFilter: 'blur(10px)',
                }}
              >
                <tr>
                  <th style={{ color: '#fff' }}>Report Name</th>
                  <th style={{ color: '#fff' }}>Type</th>
                  <th style={{ color: '#fff' }}>Period</th>
                  <th style={{ color: '#fff' }}>Generated</th>
                  <th style={{ color: '#fff' }}>Status</th>
                  <th className="text-end" style={{ color: '#fff' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {reports.map((report) => (
                  <tr 
                    key={report.id}
                    style={{
                      borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                      transition: 'all 0.2s ease',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'rgba(255, 255, 255, 0.05)';
                      e.currentTarget.style.backdropFilter = 'blur(10px)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'transparent';
                      e.currentTarget.style.backdropFilter = 'none';
                    }}
                  >
                    <td className="text-white">{report.name}</td>
                    <td className="text-white-50 small">{report.type}</td>
                    <td className="small text-white-50">
                      {new Date(report.period_start).toLocaleDateString()} - {new Date(report.period_end).toLocaleDateString()}
                    </td>
                    <td className="small text-white-50">
                      {new Date(report.generated_at).toLocaleString()}
                    </td>
                    <td>{renderStatus(report.status)}</td>
                    <td className="text-end">
                      <div className="d-flex align-items-center gap-2 justify-content-end">
                        {report.file_url && report.status === 'completed' && (
                          <a
                            href={report.file_url}
                            download={`${report.name}_${report.period_start}_${report.period_end}.csv`}
                            className="btn btn-sm"
                            style={{
                              background: 'rgba(0, 115, 255, 0.3)',
                              backdropFilter: 'blur(10px)',
                              border: '1px solid rgba(0, 115, 255, 0.5)',
                              color: '#fff',
                              textDecoration: 'none',
                              transition: 'all 0.2s ease',
                            }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.background = 'rgba(0, 115, 255, 0.4)';
                              e.currentTarget.style.transform = 'scale(1.02)';
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.background = 'rgba(0, 115, 255, 0.3)';
                              e.currentTarget.style.transform = 'scale(1)';
                            }}
                          >
                            <IoDownloadOutline /> Download
                          </a>
                        )}
                        {report.status !== 'generating' && (
                          <button
                            className="btn btn-sm"
                            onClick={() => deleteReport(report.id)}
                            style={{
                              background: 'rgba(239, 68, 68, 0.3)',
                              backdropFilter: 'blur(10px)',
                              border: '1px solid rgba(239, 68, 68, 0.5)',
                              color: '#fff',
                              transition: 'all 0.2s ease',
                            }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.background = 'rgba(239, 68, 68, 0.4)';
                              e.currentTarget.style.transform = 'scale(1.02)';
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.background = 'rgba(239, 68, 68, 0.3)';
                              e.currentTarget.style.transform = 'scale(1)';
                            }}
                          >
                            Delete
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  )
}

function renderStatus(status: string) {
  const colorMap: Record<string, { bg: string; border: string }> = {
    completed: { bg: 'rgba(34, 197, 94, 0.3)', border: 'rgba(34, 197, 94, 0.5)' },
    generating: { bg: 'rgba(249, 115, 22, 0.3)', border: 'rgba(249, 115, 22, 0.5)' },
    failed: { bg: 'rgba(239, 68, 68, 0.3)', border: 'rgba(239, 68, 68, 0.5)' },
  }
  const colors = colorMap[status] || { bg: 'rgba(255, 255, 255, 0.2)', border: 'rgba(255, 255, 255, 0.3)' }
  return (
    <span
      className="badge"
      style={{ 
        textTransform: 'capitalize',
        background: colors.bg,
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        border: `1px solid ${colors.border}`,
        color: '#fff',
      }}
    >
      {status}
    </span>
  )
}

