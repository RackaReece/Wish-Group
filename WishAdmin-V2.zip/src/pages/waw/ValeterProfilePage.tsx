// src/pages/waw/ValeterProfilePage.tsx
import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import { supabase } from '../../lib/supabaseClient'

type Profile = {
  id: string
  email: string | null
  name: string | null
  full_name: string | null
  phone: string | null
  role: string | null
  user_type: string | null
  is_verified: boolean | null
  documents_uploaded: boolean | null
  insurance_verified: boolean | null
  license_verified: boolean | null
  background_check_passed: boolean | null
  tier: string
  tier_points: number
  total_washes: number
  profile_picture: string | null
}

type ValeterDoc = {
  id: string
  name: string
  type: string
  status: string
  file_url: string | null
  uploaded_at: string | null
}

type Booking = {
  id: string
  service_type: string
  status: string
  price: number
  scheduled_at: string | null
  location_address: string | null
}

export default function ValeterProfilePage() {
  const { id } = useParams<{ id: string }>()
  const [profile, setProfile] = useState<Profile | null>(null)
  const [docs, setDocs] = useState<ValeterDoc[]>([])
  const [bookings, setBookings] = useState<Booking[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (!id) return

    const load = async () => {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      if (!supabaseUrl || !supabaseAnonKey) {
        setProfile(null);
        setDocs([]);
        setBookings([]);
        setLoading(false);
        return;
      }

      setLoading(true)

      try {
        // 1) profile from public.profiles
        const { data: profileData } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', id)
          .maybeSingle()

        // 2) docs for this user
        const { data: docData } = await supabase
          .from('valeter_documents')
          .select('id, name, type, status, file_url, uploaded_at')
          .eq('user_id', id)
          .order('created_at', { ascending: false })

        // 3) bookings they handled
        const { data: bookingData } = await supabase
          .from('bookings')
          .select(
            'id, service_type, status, price, scheduled_at, location_address'
          )
          .eq('valeter_id', id)
          .order('created_at', { ascending: false })
          .limit(50)

        setProfile((profileData || null) as Profile | null)
        setDocs((docData || []) as ValeterDoc[])
        setBookings((bookingData || []) as Booking[])
      } catch (error) {
        console.error('Error loading valeter profile:', error);
      } finally {
        setLoading(false)
      }
    }

    load()
  }, [id])

  const displayName =
    profile?.full_name || profile?.name || (id ? id.slice(0, 8) + '…' : 'Valeter')

  return (
    <div className="container-fluid px-0">
      <div className="d-flex justify-content-between align-items-center mb-3">
        <div>
          <h1 className="h4 mb-1 text-white">{displayName}</h1>
          <p className="text-white-50 mb-0">
            {profile?.role ? profile.role.toUpperCase() : 'VALETER'} • {id}
          </p>
        </div>
        <Link 
          to="/wish-a-wash/documents" 
          className="btn btn-sm"
          style={{
            background: 'rgba(255, 255, 255, 0.1)',
            backdropFilter: 'blur(10px)',
            border: '1px solid rgba(255, 255, 255, 0.2)',
            color: '#fff',
            textDecoration: 'none',
          }}
        >
          ← Back to documents
        </Link>
      </div>

      {loading ? (
        <p className="text-white-50">Loading…</p>
      ) : (
        <div className="row g-3">
          {/* left column: profile card */}
          <div className="col-12 col-lg-4">
            <div 
              className="card border-0 shadow-sm mb-3"
              style={{
                background: 'rgba(255, 255, 255, 0.1)',
                backdropFilter: 'blur(20px)',
                WebkitBackdropFilter: 'blur(20px)',
                borderRadius: 20,
                border: '1px solid rgba(255, 255, 255, 0.2)',
              }}
            >
              <div className="card-body">
                <div className="d-flex align-items-center gap-3 mb-3">
                  {profile?.profile_picture ? (
                    <img
                      src={profile.profile_picture}
                      alt="profile"
                      style={{ width: 52, height: 52, borderRadius: '9999px', objectFit: 'cover' }}
                    />
                  ) : (
                    <div
                      style={{
                        width: 52,
                        height: 52,
                        borderRadius: '9999px',
                        background:
                          'linear-gradient(135deg, #0f172a 0%, #38bdf8 100%)',
                      }}
                    />
                  )}
                  <div>
                    <h5 className="mb-0 text-white">{displayName}</h5>
                    <small className="text-white-50">
                      {profile?.email || 'No email'}
                    </small>
                  </div>
                </div>

                <div className="mb-2 d-flex justify-content-between">
                  <span className="text-white-50 small">Phone</span>
                  <span className="small text-white">{profile?.phone || '—'}</span>
                </div>
                <div className="mb-2 d-flex justify-content-between">
                  <span className="text-white-50 small">Tier</span>
                  <span 
                    className="badge text-uppercase"
                    style={{
                      background: 'rgba(14, 165, 233, 0.3)',
                      backdropFilter: 'blur(10px)',
                      border: '1px solid rgba(14, 165, 233, 0.5)',
                      color: '#fff',
                    }}
                  >
                    {profile?.tier || 'bronze'}
                  </span>
                </div>
                <div className="mb-2 d-flex justify-content-between">
                  <span className="text-white-50 small">Total washes</span>
                  <span className="fw-semibold text-white">{profile?.total_washes ?? 0}</span>
                </div>
                <div className="mb-3 d-flex flex-wrap gap-2">
                  {profile?.is_verified && (
                    <span 
                      className="badge"
                      style={{
                        background: 'rgba(34, 197, 94, 0.3)',
                        backdropFilter: 'blur(10px)',
                        border: '1px solid rgba(34, 197, 94, 0.5)',
                        color: '#fff',
                      }}
                    >
                      Platform verified
                    </span>
                  )}
                  {profile?.documents_uploaded && (
                    <span 
                      className="badge"
                      style={{
                        background: 'rgba(255, 255, 255, 0.2)',
                        backdropFilter: 'blur(10px)',
                        border: '1px solid rgba(255, 255, 255, 0.3)',
                        color: '#fff',
                      }}
                    >
                      Docs uploaded
                    </span>
                  )}
                  {profile?.insurance_verified && (
                    <span 
                      className="badge"
                      style={{
                        background: 'rgba(34, 197, 94, 0.3)',
                        backdropFilter: 'blur(10px)',
                        border: '1px solid rgba(34, 197, 94, 0.5)',
                        color: '#fff',
                      }}
                    >
                      Insurance OK
                    </span>
                  )}
                  {profile?.license_verified && (
                    <span 
                      className="badge"
                      style={{
                        background: 'rgba(34, 197, 94, 0.3)',
                        backdropFilter: 'blur(10px)',
                        border: '1px solid rgba(34, 197, 94, 0.5)',
                        color: '#fff',
                      }}
                    >
                      License OK
                    </span>
                  )}
                  {profile?.background_check_passed && (
                    <span 
                      className="badge"
                      style={{
                        background: 'rgba(34, 197, 94, 0.3)',
                        backdropFilter: 'blur(10px)',
                        border: '1px solid rgba(34, 197, 94, 0.5)',
                        color: '#fff',
                      }}
                    >
                      Background check
                    </span>
                  )}
                </div>

                <p className="text-white-50 small mb-0">
                  User type: {profile?.user_type || 'valeter'}
                </p>
              </div>
            </div>

            {/* could add org info if organization_id is set */}
            {profile?.organization_id && (
              <div 
                className="card border-0 shadow-sm"
                style={{
                  background: 'rgba(255, 255, 255, 0.1)',
                  backdropFilter: 'blur(20px)',
                  WebkitBackdropFilter: 'blur(20px)',
                  borderRadius: 20,
                  border: '1px solid rgba(255, 255, 255, 0.2)',
                }}
              >
                <div 
                  className="card-header"
                  style={{
                    background: 'rgba(255, 255, 255, 0.05)',
                    borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                    borderTopLeftRadius: 20,
                    borderTopRightRadius: 20,
                  }}
                >
                  <h6 className="mb-0 text-white">Organisation</h6>
                </div>
                <div className="card-body">
                  <p className="small mb-1 text-white">
                    Org ID: <code style={{ color: '#fff', background: 'rgba(255, 255, 255, 0.1)', padding: '2px 6px', borderRadius: '4px' }}>{profile.organization_id}</code>
                  </p>
                  <p className="small text-white-50 mb-0">
                    Type: {profile.organization_type || '—'}
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* right column: docs + bookings */}
          <div className="col-12 col-lg-8 d-flex flex-column gap-3">
            {/* documents */}
            <div 
              className="card border-0 shadow-sm"
              style={{
                background: 'rgba(255, 255, 255, 0.1)',
                backdropFilter: 'blur(20px)',
                WebkitBackdropFilter: 'blur(20px)',
                borderRadius: 20,
                border: '1px solid rgba(255, 255, 255, 0.2)',
              }}
            >
              <div 
                className="card-header d-flex justify-content-between align-items-center"
                style={{
                  background: 'rgba(255, 255, 255, 0.05)',
                  borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                  borderTopLeftRadius: 20,
                  borderTopRightRadius: 20,
                }}
              >
                <h6 className="mb-0 text-white">Documents</h6>
                <span 
                  className="badge"
                  style={{
                    background: 'rgba(255, 255, 255, 0.2)',
                    backdropFilter: 'blur(10px)',
                    border: '1px solid rgba(255, 255, 255, 0.3)',
                    color: '#fff',
                  }}
                >
                  {docs.length}
                </span>
              </div>
              <div className="table-responsive">
                {docs.length === 0 ? (
                  <p className="p-3 mb-0 text-white-50">No documents for this valeter.</p>
                ) : (
                  <table className="table table-sm mb-0 align-middle">
                    <thead 
                      style={{
                        background: 'rgba(255, 255, 255, 0.05)',
                        backdropFilter: 'blur(10px)',
                      }}
                    >
                      <tr>
                        <th style={{ color: '#fff' }}>Name</th>
                        <th style={{ color: '#fff' }}>Type</th>
                        <th style={{ color: '#fff' }}>Status</th>
                        <th style={{ color: '#fff' }}>Uploaded</th>
                        <th style={{ color: '#fff' }}>File</th>
                      </tr>
                    </thead>
                    <tbody>
                      {docs.map((d) => (
                        <tr 
                          key={d.id}
                          style={{
                            borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                            transition: 'all 0.2s ease',
                          }}
                          onMouseEnter={(e) => {
                            e.currentTarget.style.background = 'rgba(255, 255, 255, 0.05)';
                            e.currentTarget.style.backdropFilter = 'blur(10px)';
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.background = 'transparent';
                            e.currentTarget.style.backdropFilter = 'none';
                          }}
                        >
                          <td className="text-white">{d.name}</td>
                          <td className="small text-white-50">{d.type}</td>
                          <td>{renderStatus(d.status)}</td>
                          <td className="small text-white-50">
                            {d.uploaded_at
                              ? new Date(d.uploaded_at).toLocaleString()
                              : '—'}
                          </td>
                          <td>
                            {d.file_url ? (
                              <a
                                href={d.file_url}
                                target="_blank"
                                rel="noreferrer"
                                className="btn btn-link btn-sm p-0 text-white"
                                style={{ textDecoration: 'underline' }}
                              >
                                View
                              </a>
                            ) : (
                              <span className="text-white-50 small">No file</span>
                            )}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>

            {/* bookings */}
            <div 
              className="card border-0 shadow-sm"
              style={{
                background: 'rgba(255, 255, 255, 0.1)',
                backdropFilter: 'blur(20px)',
                WebkitBackdropFilter: 'blur(20px)',
                borderRadius: 20,
                border: '1px solid rgba(255, 255, 255, 0.2)',
              }}
            >
              <div 
                className="card-header d-flex justify-content-between align-items-center"
                style={{
                  background: 'rgba(255, 255, 255, 0.05)',
                  borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                  borderTopLeftRadius: 20,
                  borderTopRightRadius: 20,
                }}
              >
                <h6 className="mb-0 text-white">Bookings handled</h6>
                <span 
                  className="badge"
                  style={{
                    background: 'rgba(255, 255, 255, 0.2)',
                    backdropFilter: 'blur(10px)',
                    border: '1px solid rgba(255, 255, 255, 0.3)',
                    color: '#fff',
                  }}
                >
                  {bookings.length}
                </span>
              </div>
              <div className="table-responsive">
                {bookings.length === 0 ? (
                  <p className="p-3 mb-0 text-white-50">No bookings linked to this valeter.</p>
                ) : (
                  <table className="table table-sm mb-0 align-middle">
                    <thead 
                      style={{
                        background: 'rgba(255, 255, 255, 0.05)',
                        backdropFilter: 'blur(10px)',
                      }}
                    >
                      <tr>
                        <th style={{ color: '#fff' }}>Service</th>
                        <th style={{ color: '#fff' }}>Status</th>
                        <th className="text-end" style={{ color: '#fff' }}>£</th>
                        <th style={{ color: '#fff' }}>Scheduled</th>
                        <th style={{ color: '#fff' }}>Location</th>
                      </tr>
                    </thead>
                    <tbody>
                      {bookings.map((b) => (
                        <tr 
                          key={b.id}
                          style={{
                            borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                            transition: 'all 0.2s ease',
                          }}
                          onMouseEnter={(e) => {
                            e.currentTarget.style.background = 'rgba(255, 255, 255, 0.05)';
                            e.currentTarget.style.backdropFilter = 'blur(10px)';
                          }}
                          onMouseLeave={(e) => {
                            e.currentTarget.style.background = 'transparent';
                            e.currentTarget.style.backdropFilter = 'none';
                          }}
                        >
                          <td className="text-white">{b.service_type}</td>
                          <td>{renderBookingStatus(b.status)}</td>
                          <td className="text-end text-white">
                            £{Number(b.price || 0).toFixed(2)}
                          </td>
                          <td className="small text-white-50">
                            {b.scheduled_at
                              ? new Date(b.scheduled_at).toLocaleString()
                              : '—'}
                          </td>
                          <td className="small text-white">
                            {b.location_address || <span className="text-white-50">—</span>}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

function renderStatus(status: string) {
  const colorMap: Record<string, { bg: string; border: string }> = {
    pending: { bg: 'rgba(249, 115, 22, 0.3)', border: 'rgba(249, 115, 22, 0.5)' },
    approved: { bg: 'rgba(34, 197, 94, 0.3)', border: 'rgba(34, 197, 94, 0.5)' },
    rejected: { bg: 'rgba(239, 68, 68, 0.3)', border: 'rgba(239, 68, 68, 0.5)' },
  }
  const colors = colorMap[status] || { bg: 'rgba(255, 255, 255, 0.2)', border: 'rgba(255, 255, 255, 0.3)' }
  return (
    <span 
      className="badge" 
      style={{ 
        textTransform: 'capitalize',
        background: colors.bg,
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        border: `1px solid ${colors.border}`,
        color: '#fff',
      }}
    >
      {status}
    </span>
  )
}

function renderBookingStatus(status: string) {
  const colorMap: Record<string, { bg: string; border: string }> = {
    completed: { bg: 'rgba(34, 197, 94, 0.3)', border: 'rgba(34, 197, 94, 0.5)' },
    in_progress: { bg: 'rgba(0, 115, 255, 0.3)', border: 'rgba(0, 115, 255, 0.5)' },
    scheduled: { bg: 'rgba(14, 165, 233, 0.3)', border: 'rgba(14, 165, 233, 0.5)' },
    cancelled: { bg: 'rgba(239, 68, 68, 0.3)', border: 'rgba(239, 68, 68, 0.5)' },
  }
  const colors = colorMap[status] || { bg: 'rgba(255, 255, 255, 0.2)', border: 'rgba(255, 255, 255, 0.3)' }
  return (
    <span 
      className="badge" 
      style={{ 
        textTransform: 'capitalize',
        background: colors.bg,
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        border: `1px solid ${colors.border}`,
        color: '#fff',
      }}
    >
      {status}
    </span>
  )
}