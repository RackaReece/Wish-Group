// src/pages/waw/RefundsPage.tsx
import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'
import { IoArrowBackOutline, IoCheckmarkCircleOutline, IoCloseCircleOutline } from 'react-icons/io5'

type Refund = {
  id: string
  booking_id: string
  amount: number
  reason: string
  status: string
  requested_at: string
  processed_at: string | null
  customer_email: string | null
  service_type: string | null
}

export default function RefundsPage() {
  const [refunds, setRefunds] = useState<Refund[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      if (!supabaseUrl || !supabaseAnonKey) {
        setRefunds([]);
        setLoading(false);
        return;
      }

      setLoading(true)
      try {
        // In a real app, you'd fetch from a refunds table
        // For now, we'll show empty state
        setRefunds([])
      } catch (error) {
        console.error('Error loading refunds:', error);
      } finally {
        setLoading(false)
      }
    }

    load()
  }, [])

  const processRefund = async (id: string, approve: boolean) => {
    const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
    const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
    
    if (!supabaseUrl || !supabaseAnonKey) {
      console.warn('Cannot process refund: Supabase credentials missing');
      return;
    }

    try {
      // In a real app, this would update the refund status
      setRefunds((prev) =>
        prev.map((r) =>
          r.id === id
            ? { ...r, status: approve ? 'approved' : 'rejected', processed_at: new Date().toISOString() }
            : r
        )
      )
    } catch (error) {
      console.error('Error processing refund:', error);
    }
  }

  const pendingRefunds = refunds.filter((r) => r.status === 'pending')
  const totalRefundAmount = refunds
    .filter((r) => r.status === 'approved')
    .reduce((sum, r) => sum + Number(r.amount || 0), 0)

  return (
    <div className="container-fluid px-0">
      <h1 className="h4 mb-3 text-white">Refunds</h1>
      <p className="text-white-50 mb-4">
        Review and process refund requests from customers.
      </p>

      {/* Stats Cards */}
      <div className="row g-3 mb-4">
        <div className="col-12 col-md-4">
          <div
            className="card shadow-sm border-0"
            style={{
              background: 'rgba(255, 255, 255, 0.1)',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              borderRadius: 20,
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            <div className="card-body p-3">
              <div className="d-flex align-items-center justify-content-between">
                <div>
                  <p className="small text-white-50 mb-1">Pending</p>
                  <h4 className="mb-0 text-white">{pendingRefunds.length}</h4>
                </div>
                <div
                  style={{
                    background: 'rgba(249, 115, 22, 0.3)',
                    backdropFilter: 'blur(10px)',
                    borderRadius: '12px',
                    padding: '12px',
                    border: '1px solid rgba(249, 115, 22, 0.5)',
                  }}
                >
                  <IoArrowBackOutline size={24} style={{ color: '#fff' }} />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 col-md-4">
          <div
            className="card shadow-sm border-0"
            style={{
              background: 'rgba(255, 255, 255, 0.1)',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              borderRadius: 20,
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            <div className="card-body p-3">
              <div className="d-flex align-items-center justify-content-between">
                <div>
                  <p className="small text-white-50 mb-1">Total Refunded</p>
                  <h4 className="mb-0 text-white">£{totalRefundAmount.toFixed(2)}</h4>
                </div>
                <div
                  style={{
                    background: 'rgba(34, 197, 94, 0.3)',
                    backdropFilter: 'blur(10px)',
                    borderRadius: '12px',
                    padding: '12px',
                    border: '1px solid rgba(34, 197, 94, 0.5)',
                  }}
                >
                  <IoCheckmarkCircleOutline size={24} style={{ color: '#fff' }} />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="col-12 col-md-4">
          <div
            className="card shadow-sm border-0"
            style={{
              background: 'rgba(255, 255, 255, 0.1)',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              borderRadius: 20,
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            <div className="card-body p-3">
              <div className="d-flex align-items-center justify-content-between">
                <div>
                  <p className="small text-white-50 mb-1">Total Requests</p>
                  <h4 className="mb-0 text-white">{refunds.length}</h4>
                </div>
                <div
                  style={{
                    background: 'rgba(255, 255, 255, 0.2)',
                    backdropFilter: 'blur(10px)',
                    borderRadius: '12px',
                    padding: '12px',
                    border: '1px solid rgba(255, 255, 255, 0.3)',
                  }}
                >
                  <IoArrowBackOutline size={24} style={{ color: '#fff' }} />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Refunds List */}
      <div 
        className="card shadow-sm border-0"
        style={{
          background: 'rgba(255, 255, 255, 0.1)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderRadius: 20,
          border: '1px solid rgba(255, 255, 255, 0.2)',
        }}
      >
        <div 
          className="card-header d-flex justify-content-between align-items-center"
          style={{
            background: 'rgba(255, 255, 255, 0.05)',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
          }}
        >
          <h6 className="mb-0 text-white">Refund Requests</h6>
          <span 
            className="badge"
            style={{
              background: 'rgba(255, 255, 255, 0.2)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              color: '#fff',
            }}
          >
            {refunds.length} total
          </span>
        </div>

        <div className="table-responsive">
          {loading ? (
            <p className="p-3 mb-0 text-white-50">Loading…</p>
          ) : refunds.length === 0 ? (
            <div className="p-5 text-center">
              <IoArrowBackOutline size={48} style={{ color: 'rgba(255, 255, 255, 0.3)', marginBottom: '1rem' }} />
              <p className="text-white-50 mb-0">No refund requests found.</p>
            </div>
          ) : (
            <table className="table table-sm mb-0 align-middle">
              <thead 
                style={{
                  background: 'rgba(255, 255, 255, 0.05)',
                  backdropFilter: 'blur(10px)',
                }}
              >
                <tr>
                  <th style={{ color: '#fff' }}>Booking ID</th>
                  <th style={{ color: '#fff' }}>Service</th>
                  <th style={{ color: '#fff' }}>Customer</th>
                  <th style={{ color: '#fff' }}>Amount</th>
                  <th style={{ color: '#fff' }}>Reason</th>
                  <th style={{ color: '#fff' }}>Requested</th>
                  <th style={{ color: '#fff' }}>Status</th>
                  <th className="text-end" style={{ color: '#fff' }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {refunds.map((refund) => (
                  <tr 
                    key={refund.id}
                    style={{
                      borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                      transition: 'all 0.2s ease',
                    }}
                    onMouseEnter={(e) => {
                      e.currentTarget.style.background = 'rgba(255, 255, 255, 0.05)';
                      e.currentTarget.style.backdropFilter = 'blur(10px)';
                    }}
                    onMouseLeave={(e) => {
                      e.currentTarget.style.background = 'transparent';
                      e.currentTarget.style.backdropFilter = 'none';
                    }}
                  >
                    <td className="text-white small">{refund.booking_id.slice(0, 8)}...</td>
                    <td className="text-white-50 small">{refund.service_type || '—'}</td>
                    <td className="text-white-50 small">{refund.customer_email || '—'}</td>
                    <td className="text-white">£{Number(refund.amount || 0).toFixed(2)}</td>
                    <td className="small text-white-50" style={{ maxWidth: '200px' }}>
                      {refund.reason}
                    </td>
                    <td className="small text-white-50">
                      {new Date(refund.requested_at).toLocaleDateString()}
                    </td>
                    <td>{renderStatus(refund.status)}</td>
                    <td className="text-end">
                      {refund.status === 'pending' && (
                        <div className="btn-group btn-group-sm" role="group">
                          <button
                            className="btn"
                            onClick={() => processRefund(refund.id, true)}
                            style={{
                              background: 'rgba(34, 197, 94, 0.3)',
                              backdropFilter: 'blur(10px)',
                              border: '1px solid rgba(34, 197, 94, 0.5)',
                              color: '#fff',
                              transition: 'all 0.2s ease',
                            }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.background = 'rgba(34, 197, 94, 0.4)';
                              e.currentTarget.style.transform = 'scale(1.02)';
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.background = 'rgba(34, 197, 94, 0.3)';
                              e.currentTarget.style.transform = 'scale(1)';
                            }}
                          >
                            <IoCheckmarkCircleOutline /> Approve
                          </button>
                          <button
                            className="btn"
                            onClick={() => processRefund(refund.id, false)}
                            style={{
                              background: 'rgba(239, 68, 68, 0.3)',
                              backdropFilter: 'blur(10px)',
                              border: '1px solid rgba(239, 68, 68, 0.5)',
                              color: '#fff',
                              transition: 'all 0.2s ease',
                            }}
                            onMouseEnter={(e) => {
                              e.currentTarget.style.background = 'rgba(239, 68, 68, 0.4)';
                              e.currentTarget.style.transform = 'scale(1.02)';
                            }}
                            onMouseLeave={(e) => {
                              e.currentTarget.style.background = 'rgba(239, 68, 68, 0.3)';
                              e.currentTarget.style.transform = 'scale(1)';
                            }}
                          >
                            <IoCloseCircleOutline /> Reject
                          </button>
                        </div>
                      )}
                      {refund.status !== 'pending' && (
                        <span className="small text-white-50">
                          {refund.processed_at
                            ? new Date(refund.processed_at).toLocaleDateString()
                            : '—'}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
      </div>
    </div>
  )
}

function renderStatus(status: string) {
  const colorMap: Record<string, { bg: string; border: string }> = {
    pending: { bg: 'rgba(249, 115, 22, 0.3)', border: 'rgba(249, 115, 22, 0.5)' },
    approved: { bg: 'rgba(34, 197, 94, 0.3)', border: 'rgba(34, 197, 94, 0.5)' },
    rejected: { bg: 'rgba(239, 68, 68, 0.3)', border: 'rgba(239, 68, 68, 0.5)' },
    processed: { bg: 'rgba(14, 165, 233, 0.3)', border: 'rgba(14, 165, 233, 0.5)' },
  }
  const colors = colorMap[status] || { bg: 'rgba(255, 255, 255, 0.2)', border: 'rgba(255, 255, 255, 0.3)' }
  return (
    <span
      className="badge"
      style={{ 
        textTransform: 'capitalize',
        background: colors.bg,
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        border: `1px solid ${colors.border}`,
        color: '#fff',
      }}
    >
      {status}
    </span>
  )
}

