// src/pages/waw/LocationsPage.tsx
import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'

type Location = {
  id: string
  name: string
  address: string
  status: string
  base_price: number
  priority_price: number
  wait_time_minutes: number | null
  organization_id: string | null
  organizations: {
    name: string
  } | null
}

export default function LocationsPage() {
  const [locations, setLocations] = useState<Location[]>([])
  const [loading, setLoading] = useState(true)
  const [openOrg, setOpenOrg] = useState<string | null>(null)

  useEffect(() => {
    const load = async () => {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      if (!supabaseUrl || !supabaseAnonKey) {
        setLocations([]);
        setLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('car_wash_locations')
          .select(
            `
            id,
            name,
            address,
            status,
            base_price,
            priority_price,
            wait_time_minutes,
            organization_id,
            organizations ( name )
          `
          )
          .order('created_at', { ascending: false })
          .limit(100)

        if (!error) {
          setLocations((data || []) as Location[])
        } else {
          console.error('Error loading locations:', error);
        }
      } catch (error) {
        console.error('Error loading locations:', error);
      } finally {
        setLoading(false)
      }
    }

    load()
  }, [])

  // group by organization_id
  const groups: Record<string, Location[]> = locations.reduce((acc, loc) => {
    const key = loc.organization_id || 'unassigned'
    if (!acc[key]) acc[key] = []
    acc[key].push(loc)
    return acc
  }, {} as Record<string, Location[]>)

  const orgKeys = Object.keys(groups)

  return (
    <div className="container-fluid px-0">
      <h1 className="h4 mb-3 text-white">Locations</h1>
      <p className="text-white-50 mb-4">
        Managed car wash locations and their current status.
      </p>

      <div 
        className="card shadow-sm border-0"
        style={{
          background: 'rgba(255, 255, 255, 0.1)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderRadius: 20,
          border: '1px solid rgba(255, 255, 255, 0.2)',
        }}
      >
        <div 
          className="card-header d-flex justify-content-between align-items-center"
          style={{
            background: 'rgba(255, 255, 255, 0.05)',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
            borderTopLeftRadius: 20,
            borderTopRightRadius: 20,
          }}
        >
          <h6 className="mb-0 text-white">Car wash locations</h6>
          <span 
            className="badge"
            style={{
              background: 'rgba(255, 255, 255, 0.2)',
              backdropFilter: 'blur(10px)',
              border: '1px solid rgba(255, 255, 255, 0.3)',
              color: '#fff',
            }}
          >
            {locations.length} total
          </span>
        </div>

        {loading ? (
          <p className="p-3 mb-0 text-white-50">Loading…</p>
        ) : orgKeys.length === 0 ? (
          <p className="p-3 mb-0 text-white-50">No locations found.</p>
        ) : (
          <div className="list-group list-group-flush">
            {orgKeys.map((orgId) => {
              const orgLocations = groups[orgId]
              const first = orgLocations[0]
              const orgName =
                orgId === 'unassigned'
                  ? 'Unassigned'
                  : first.organizations?.name || 'Unknown organisation'
              const isOpen = openOrg === orgId

              // tiny status counts per org
              const statusCounts = orgLocations.reduce(
                (acc, l) => {
                  acc[l.status] = (acc[l.status] || 0) + 1
                  return acc
                },
                {} as Record<string, number>
              )

              return (
                <div 
                  key={orgId} 
                  className="list-group-item"
                  style={{
                    background: 'rgba(255, 255, 255, 0.05)',
                    borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                  }}
                >
                  <div className="d-flex justify-content-between align-items-center flex-wrap">
                    <div className="d-flex align-items-center gap-2 flex-wrap">
                      <span className="fw-semibold text-white">{orgName}</span>
                      <span 
                        className="badge"
                        style={{
                          background: 'rgba(255, 255, 255, 0.2)',
                          backdropFilter: 'blur(10px)',
                          border: '1px solid rgba(255, 255, 255, 0.3)',
                          color: '#fff',
                        }}
                      >
                        {orgLocations.length} location
                        {orgLocations.length > 1 ? 's' : ''}
                      </span>
                      {/* status counts */}
                      <OrgStatusCount label="green" count={statusCounts.green} />
                      <OrgStatusCount label="amber" count={statusCounts.amber} />
                      <OrgStatusCount label="red" count={statusCounts.red} />
                    </div>
                    <button
                      className="btn btn-sm mt-2 mt-md-0"
                      onClick={() => setOpenOrg(isOpen ? null : orgId)}
                      style={{
                        background: 'rgba(255, 255, 255, 0.1)',
                        backdropFilter: 'blur(10px)',
                        border: '1px solid rgba(255, 255, 255, 0.2)',
                        color: '#fff',
                      }}
                    >
                      {isOpen ? 'Hide' : 'View'}
                    </button>
                  </div>

                  {isOpen && (
                    <div className="table-responsive mt-3">
                      <table className="table table-sm mb-0 align-middle">
                        <thead 
                          style={{
                            background: 'rgba(255, 255, 255, 0.05)',
                            backdropFilter: 'blur(10px)',
                          }}
                        >
                          <tr>
                            <th style={{ width: '20%', color: '#fff' }}>Name</th>
                            <th style={{ width: '30%', color: '#fff' }}>Address</th>
                            <th style={{ width: '12%', color: '#fff' }}>Status</th>
                            <th style={{ width: '10%', color: '#fff' }} className="text-end">
                              Base £
                            </th>
                            <th style={{ width: '12%', color: '#fff' }} className="text-end">
                              Priority £
                            </th>
                            <th style={{ width: '8%', color: '#fff' }}>Wait</th>
                          </tr>
                        </thead>
                        <tbody>
                          {orgLocations.map((loc) => (
                            <tr 
                              key={loc.id}
                              style={{
                                borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                                transition: 'all 0.2s ease',
                              }}
                              onMouseEnter={(e) => {
                                e.currentTarget.style.background = 'rgba(255, 255, 255, 0.05)';
                                e.currentTarget.style.backdropFilter = 'blur(10px)';
                              }}
                              onMouseLeave={(e) => {
                                e.currentTarget.style.background = 'transparent';
                                e.currentTarget.style.backdropFilter = 'none';
                              }}
                            >
                              <td className="text-white">{loc.name}</td>
                              <td className="small text-white">{loc.address}</td>
                              <td>{renderStatus(loc.status)}</td>
                              <td className="text-end text-white">
                                £{Number(loc.base_price || 0).toFixed(2)}
                              </td>
                              <td className="text-end text-white">
                                £{Number(loc.priority_price || 0).toFixed(2)}
                              </td>
                              <td className="text-white">{loc.wait_time_minutes ?? '—'}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )
            })}
          </div>
        )}
      </div>
    </div>
  )
}

function renderStatus(status: string) {
  const colorMap: Record<string, { bg: string; border: string }> = {
    green: { bg: 'rgba(34, 197, 94, 0.3)', border: 'rgba(34, 197, 94, 0.5)' },
    amber: { bg: 'rgba(249, 115, 22, 0.3)', border: 'rgba(249, 115, 22, 0.5)' },
    red: { bg: 'rgba(239, 68, 68, 0.3)', border: 'rgba(239, 68, 68, 0.5)' },
  }
  const colors = colorMap[status] || { bg: 'rgba(255, 255, 255, 0.2)', border: 'rgba(255, 255, 255, 0.3)' }
  return (
    <span
      className="badge"
      style={{ 
        textTransform: 'capitalize',
        background: colors.bg,
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        border: `1px solid ${colors.border}`,
        color: '#fff',
      }}
    >
      {status}
    </span>
  )
}

function OrgStatusCount({ label, count }: { label: string; count?: number }) {
  if (!count) return null

  const colorMap: Record<string, { bg: string; border: string }> = {
    green: { bg: 'rgba(34, 197, 94, 0.3)', border: 'rgba(34, 197, 94, 0.5)' },
    amber: { bg: 'rgba(249, 115, 22, 0.3)', border: 'rgba(249, 115, 22, 0.5)' },
    red: { bg: 'rgba(239, 68, 68, 0.3)', border: 'rgba(239, 68, 68, 0.5)' },
  }
  const colors = colorMap[label] || { bg: 'rgba(255, 255, 255, 0.2)', border: 'rgba(255, 255, 255, 0.3)' }

  return (
    <span
      className="badge"
      style={{ 
        textTransform: 'capitalize',
        background: colors.bg,
        backdropFilter: 'blur(10px)',
        WebkitBackdropFilter: 'blur(10px)',
        border: `1px solid ${colors.border}`,
        color: '#fff',
      }}
    >
      {label}: {count}
    </span>
  )
}