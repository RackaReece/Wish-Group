// src/pages/waw/DashboardPage.tsx
import { useEffect, useState } from 'react'
import { supabase } from '../../lib/supabaseClient'
import { 
  IoCubeOutline, 
  IoCashOutline, 
  IoDocumentTextOutline, 
  IoBusinessOutline 
} from 'react-icons/io5'

type ActivityDay = {
  date: string // e.g. "2025-11-11"
  totalBookings: number
  totalRevenue: number
  completed: number
  scheduled: number
}

export default function DashboardPage() {
  const [stats, setStats] = useState({
    totalBookings: 0,
    totalRevenue: 0,
    pendingDocs: 0,
    pendingOrgs: 0,
  })
  const [activity, setActivity] = useState<ActivityDay[]>([])
  const [loading, setLoading] = useState(true)
  const [activityLoading, setActivityLoading] = useState(true)

  useEffect(() => {
    const load = async () => {
      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      // If no credentials, show demo mode
      if (!supabaseUrl || !supabaseAnonKey) {
        setStats({
          totalBookings: 0,
          totalRevenue: 0,
          pendingDocs: 0,
          pendingOrgs: 0,
        });
        setLoading(false);
        return;
      }

      try {
        const [
          { count: totalBookings, error: bookingsError },
          { data: revenueRows, error: revenueError },
          { count: pendingDocs, error: docsError },
          { count: pendingOrgs, error: orgsError },
        ] = await Promise.all([
          supabase.from('bookings').select('id', { count: 'exact', head: true }),
          supabase
            .from('bookings')
            .select('price, status')
            .in('status', ['completed', 'in_progress']),
          supabase
            .from('valeter_documents')
            .select('id', { count: 'exact', head: true })
            .eq('status', 'pending'),
          supabase
            .from('organizations')
            .select('id', { count: 'exact', head: true })
            .eq('status', 'pending'),
        ])

        if (bookingsError || revenueError || docsError || orgsError) {
          console.error('Error loading stats:', { bookingsError, revenueError, docsError, orgsError });
        }

        const totalRevenue = (revenueRows || []).reduce(
          (sum, r) => sum + Number(r.price || 0),
          0
        )

        setStats({
          totalBookings: totalBookings || 0,
          totalRevenue,
          pendingDocs: pendingDocs || 0,
          pendingOrgs: pendingOrgs || 0,
        })
      } catch (error) {
        console.error('Error loading dashboard stats:', error);
      } finally {
        setLoading(false);
      }
    }

    load()
  }, [])

  // load recent bookings for activity
  useEffect(() => {
    const loadActivity = async () => {
      setActivityLoading(true)

      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      // If no credentials, skip loading
      if (!supabaseUrl || !supabaseAnonKey) {
        setActivity([]);
        setActivityLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('id, price, status, created_at, completed_at')
          .order('created_at', { ascending: false })
          .limit(100)

        if (!error && data) {
        // group by date (YYYY-MM-DD)
        const grouped: Record<string, ActivityDay> = {}

        data.forEach((b) => {
          const d = new Date(b.created_at)
          const key = d.toISOString().slice(0, 10) // "2025-11-11"

          if (!grouped[key]) {
            grouped[key] = {
              date: key,
              totalBookings: 0,
              totalRevenue: 0,
              completed: 0,
              scheduled: 0,
            }
          }

          grouped[key].totalBookings += 1
          grouped[key].totalRevenue += Number(b.price || 0)
          if (b.status === 'completed') {
            grouped[key].completed += 1
          }
          if (b.status === 'scheduled' || b.status === 'in_progress') {
            grouped[key].scheduled += 1
          }
        })

        // sort by date desc and take last 7 days
        const days = Object.values(grouped)
          .sort((a, b) => (a.date < b.date ? 1 : -1))
          .slice(0, 7)

          setActivity(days)
        } else {
          console.error('Error loading activity:', error);
          setActivity([])
        }
      } catch (error) {
        console.error('Error loading activity:', error);
        setActivity([]);
      } finally {
        setActivityLoading(false)
      }
    }

    loadActivity()
  }, [])

  return (
    <div className="container-fluid px-0">
      {/* top cards */}
      <div className="row g-3 mb-4">
        <div className="col-12 col-md-6 col-lg-3">
          <GradientCard
            title="Total bookings"
            value={loading ? '…' : stats.totalBookings.toString()}
            gradient="linear-gradient(135deg, rgba(0, 201, 124, 0.3) 0%, rgba(0, 224, 168, 0.3) 100%)"
            icon={<IoCubeOutline />}
          />
        </div>
        <div className="col-12 col-md-6 col-lg-3">
          <GradientCard
            title="Total revenue"
            value={loading ? '…' : `£${stats.totalRevenue.toFixed(2)}`}
            gradient="linear-gradient(135deg, rgba(0, 115, 255, 0.3) 0%, rgba(0, 192, 255, 0.3) 100%)"
            icon={<IoCashOutline />}
          />
        </div>
        <div className="col-12 col-md-6 col-lg-3">
          <GradientCard
            title="Pending documents"
            value={loading ? '…' : stats.pendingDocs.toString()}
            gradient="linear-gradient(135deg, rgba(14, 165, 233, 0.3) 0%, rgba(56, 189, 248, 0.3) 100%)"
            icon={<IoDocumentTextOutline />}
          />
        </div>
        <div className="col-12 col-md-6 col-lg-3">
          <GradientCard
            title="Pending organisations"
            value={loading ? '…' : stats.pendingOrgs.toString()}
            gradient="linear-gradient(135deg, rgba(99, 102, 241, 0.3) 0%, rgba(139, 92, 246, 0.3) 100%)"
            icon={<IoBusinessOutline />}
          />
        </div>
      </div>

      {/* lower area */}
      <div className="row g-3">
        {/* activity */}
        <div className="col-12 col-lg-8">
          <div
            className="card shadow-sm border-0"
            style={{
              background: 'rgba(255, 255, 255, 0.1)',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              borderRadius: 20,
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            <div
              className="card-header d-flex justify-content-between align-items-center"
              style={{ 
                borderTopLeftRadius: 20, 
                borderTopRightRadius: 20,
                background: 'rgba(255, 255, 255, 0.05)',
                borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
              }}
            >
              <h6 className="mb-0 text-white">Activity</h6>
              <small className="text-white-50">Last 7 days</small>
            </div>
            <div className="card-body" style={{ minHeight: 200 }}>
              {activityLoading ? (
                <p className="text-white-50 small mb-0">Loading activity…</p>
              ) : activity.length === 0 ? (
                <p className="text-white-50 small mb-0">No recent bookings.</p>
              ) : (
                <ul className="list-unstyled mb-0">
                  {activity.map((day) => (
                    <li
                      key={day.date}
                      className="d-flex justify-content-between align-items-center py-2"
                      style={{ 
                        fontSize: '0.8rem',
                        borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
                      }}
                    >
                      <div>
                        <strong className="text-white">{formatDate(day.date)}</strong>
                        <span className="text-white-50 ms-2">
                          {day.totalBookings} booking{day.totalBookings !== 1 ? 's' : ''}
                        </span>
                      </div>
                      <div className="d-flex align-items-center gap-2">
                        <span 
                          className="badge"
                          style={{
                            background: 'rgba(255, 255, 255, 0.2)',
                            backdropFilter: 'blur(10px)',
                            border: '1px solid rgba(255, 255, 255, 0.3)',
                            color: '#fff',
                          }}
                        >
                          £{day.totalRevenue.toFixed(2)}
                        </span>
                        {day.completed > 0 && (
                          <span 
                            className="badge"
                            style={{
                              background: 'rgba(34, 197, 94, 0.3)',
                              backdropFilter: 'blur(10px)',
                              border: '1px solid rgba(34, 197, 94, 0.5)',
                              color: '#fff',
                            }}
                          >
                            {day.completed} done
                          </span>
                        )}
                        {day.scheduled > 0 && (
                          <span 
                            className="badge"
                            style={{
                              background: 'rgba(249, 115, 22, 0.3)',
                              backdropFilter: 'blur(10px)',
                              border: '1px solid rgba(249, 115, 22, 0.5)',
                              color: '#fff',
                            }}
                          >
                            {day.scheduled} in progress
                          </span>
                        )}
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>

        {/* right column */}
        <div className="col-12 col-lg-4">
          <div
            className="card shadow-sm border-0 mb-3"
            style={{ 
              background: 'rgba(255, 255, 255, 0.1)',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              borderRadius: 20,
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            <div
              className="card-header"
              style={{ 
                borderTopLeftRadius: 20, 
                borderTopRightRadius: 20,
                background: 'rgba(255, 255, 255, 0.05)',
                borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
              }}
            >
              <h6 className="mb-0 text-white">Quick actions</h6>
            </div>
            <div className="card-body d-grid gap-2">
              <button
                className="btn btn-sm"
                style={{
                  background: 'rgba(0, 201, 124, 0.3)',
                  backdropFilter: 'blur(10px)',
                  color: '#fff',
                  border: '1px solid rgba(0, 201, 124, 0.5)',
                  borderRadius: 9999,
                }}
              >
                Review documents
              </button>
              <button
                className="btn btn-sm"
                style={{ 
                  borderRadius: 14,
                  background: 'rgba(255, 255, 255, 0.1)',
                  backdropFilter: 'blur(10px)',
                  border: '1px solid rgba(255, 255, 255, 0.2)',
                  color: '#fff',
                }}
              >
                Check locations
              </button>
              <button
                className="btn btn-sm"
                style={{ 
                  borderRadius: 14,
                  background: 'rgba(255, 255, 255, 0.1)',
                  backdropFilter: 'blur(10px)',
                  border: '1px solid rgba(255, 255, 255, 0.2)',
                  color: '#fff',
                }}
              >
                View bookings
              </button>
            </div>
          </div>

          <div
            className="card shadow-sm border-0"
            style={{ 
              background: 'rgba(255, 255, 255, 0.1)',
              backdropFilter: 'blur(20px)',
              WebkitBackdropFilter: 'blur(20px)',
              borderRadius: 20,
              border: '1px solid rgba(255, 255, 255, 0.2)',
            }}
          >
            <div
              className="card-header"
              style={{ 
                borderTopLeftRadius: 20, 
                borderTopRightRadius: 20,
                background: 'rgba(255, 255, 255, 0.05)',
                borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
              }}
            >
              <h6 className="mb-0 text-white">System status</h6>
            </div>
            <div className="card-body">
              <StatusRow label="Supabase" value="Online" variant="success" />
              <StatusRow label="Storage" value="OK" variant="success" />
              <StatusRow label="Valeter docs" value="Needs review" variant="warning" />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

function GradientCard({
  title,
  value,
  gradient,
  icon,
}: {
  title: string
  value: string
  gradient: string
  icon?: React.ReactNode
}) {
  return (
    <div
      className="h-100"
      style={{
        background: gradient,
        backdropFilter: 'blur(20px)',
        WebkitBackdropFilter: 'blur(20px)',
        borderRadius: 20,
        boxShadow: '0 12px 30px rgba(0,0,0,0.2)',
        color: '#fff',
        border: '1px solid rgba(255, 255, 255, 0.2)',
        transition: 'all 0.3s ease',
      }}
      onMouseEnter={(e) => {
        e.currentTarget.style.transform = 'translateY(-4px)'
        e.currentTarget.style.boxShadow = '0 16px 40px rgba(0,0,0,0.3)'
      }}
      onMouseLeave={(e) => {
        e.currentTarget.style.transform = 'translateY(0)'
        e.currentTarget.style.boxShadow = '0 12px 30px rgba(0,0,0,0.2)'
      }}
    >
      <div className="p-3 d-flex flex-column gap-1">
        <div className="d-flex justify-content-between align-items-center">
          <p
            className="mb-0"
            style={{ fontSize: 12, textTransform: 'uppercase', opacity: 0.85 }}
          >
            {title}
          </p>
          {icon ? (
            <div style={{ 
              fontSize: 24, 
              display: 'flex', 
              alignItems: 'center',
              background: 'rgba(255, 255, 255, 0.2)',
              backdropFilter: 'blur(10px)',
              borderRadius: '10px',
              padding: '6px',
              border: '1px solid rgba(255, 255, 255, 0.3)',
            }}>
              {icon}
            </div>
          ) : null}
        </div>
        <h3 className="mb-0" style={{ fontWeight: 700 }}>
          {value}
        </h3>
      </div>
    </div>
  )
}

function StatusRow({
  label,
  value,
  variant,
}: {
  label: string
  value: string
  variant: 'success' | 'warning' | 'danger'
}) {
  const colors: Record<typeof variant, { bg: string; border: string }> = {
    success: { bg: 'rgba(34, 197, 94, 0.3)', border: 'rgba(34, 197, 94, 0.5)' },
    warning: { bg: 'rgba(249, 115, 22, 0.3)', border: 'rgba(249, 115, 22, 0.5)' },
    danger: { bg: 'rgba(239, 68, 68, 0.3)', border: 'rgba(239, 68, 68, 0.5)' },
  }
  return (
    <div className="d-flex justify-content-between align-items-center mb-2">
      <span className="small text-white-50">{label}</span>
      <span
        className="badge"
        style={{
          background: colors[variant].bg,
          backdropFilter: 'blur(10px)',
          WebkitBackdropFilter: 'blur(10px)',
          border: `1px solid ${colors[variant].border}`,
          color: '#fff',
          borderRadius: 9999,
        }}
      >
        {value}
      </span>
    </div>
  )
}

function formatDate(isoDate: string) {
  // isoDate = "2025-11-11"
  const d = new Date(isoDate)
  return d.toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  })
}