import { useState } from 'react'
import { NavLink, Outlet } from 'react-router-dom'
import { 
  IoStatsChart, 
  IoDocumentText, 
  IoCarSport, 
  IoLocation, 
  IoBusiness,
  IoMenu,
  IoClose,
  IoBarChartOutline,
  IoArrowBackOutline
} from 'react-icons/io5'

export default function WishAWashLayout() {
  const [open, setOpen] = useState(false)

  return (
    <div className="d-flex" style={{ minHeight: '100vh', background: 'radial-gradient(circle at top right, #013e7d, #001a3a)' }}>
      {/* Sidebar (desktop) */}
      <aside
        className={`d-none d-md-flex flex-column justify-content-between`}
        style={{
          width: '240px',
          background: 'rgba(1, 62, 125, 0.4)',
          backdropFilter: 'blur(20px)',
          WebkitBackdropFilter: 'blur(20px)',
          borderRight: '1px solid rgba(255, 255, 255, 0.1)',
          color: 'white',
        }}
      >
        <Brand />
        <nav className="px-3 flex-grow-1">
          <SideLinks />
        </nav>
        <Footer />
      </aside>

      {/* Offcanvas-style sidebar for mobile */}
      {open && (
        <div
          className="d-md-none position-fixed top-0 start-0 h-100"
          style={{
            width: 230,
            background: 'rgba(1, 62, 125, 0.95)',
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            borderRight: '1px solid rgba(255, 255, 255, 0.1)',
            zIndex: 1050,
          }}
        >
          <div className="p-3 d-flex justify-content-between align-items-center">
            <h5 className="mb-0 text-white">Wish-a-Wash</h5>
            <button 
              className="btn btn-sm"
              onClick={() => setOpen(false)}
              style={{
                background: 'rgba(255, 255, 255, 0.2)',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255, 255, 255, 0.3)',
                color: '#fff',
              }}
            >
              <IoClose />
            </button>
          </div>
          <div className="px-3">
            <SideLinks onClickLink={() => setOpen(false)} />
          </div>
          <Footer />
        </div>
      )}

      {/* Main area */}
      <div className="flex-grow-1 d-flex flex-column" style={{ minWidth: 0 }}>
        {/* Top bar */}
        <header
          className="d-flex align-items-center justify-content-between px-3 px-md-4 py-3"
          style={{
            background: 'rgba(255, 255, 255, 0.1)',
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
          }}
        >
          <div className="d-flex align-items-center gap-2">
            {/* mobile burger */}
            <button
              className="btn btn-sm d-md-none"
              onClick={() => setOpen(true)}
              style={{
                background: 'rgba(255, 255, 255, 0.2)',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255, 255, 255, 0.3)',
                color: '#fff',
              }}
            >
              <IoMenu />
            </button>
            <div>
              <h6 className="mb-0 text-white">Wish-a-Wash Admin</h6>
              <small className="text-white-50 d-none d-sm-block">
                Manage bookings, valeters, locations
              </small>
            </div>
          </div>
          <div className="d-flex align-items-center gap-2">
            <span 
              className="badge d-none d-sm-inline"
              style={{
                background: 'rgba(0, 115, 255, 0.3)',
                backdropFilter: 'blur(10px)',
                border: '1px solid rgba(255, 255, 255, 0.2)',
                color: '#fff',
              }}
            >
              3 alerts
            </span>
            <div
              style={{
                width: 32,
                height: 32,
                borderRadius: '50%',
                background:
                  'url(https://ui-avatars.com/api/?name=Admin&background=0f172a&color=fff) center/cover',
              }}
            />
          </div>
        </header>

        {/* Routed content */}
        <main className="flex-grow-1 p-3 p-md-4" style={{ background: 'transparent' }}>
          <Outlet />
        </main>
      </div>
    </div>
  )
}

function Brand() {
  return (
    <div 
      className="px-3 py-3"
      style={{
        borderBottom: '1px solid rgba(255, 255, 255, 0.1)',
      }}
    >
      <h5 className="mb-0 text-white">Wish-a-Wash</h5>
      <small className="text-white-50">Admin Portal</small>
    </div>
  )
}

function Footer() {
  return (
    <div 
      className="px-3 py-3 small"
      style={{
        borderTop: '1px solid rgba(255, 255, 255, 0.1)',
        color: 'rgba(255, 255, 255, 0.6)',
      }}
    >
      Wish Admin • v1
    </div>
  )
}

function SideLinks({ onClickLink }: { onClickLink?: () => void } = {}) {
  return (
    <>
      <SideLink to="dashboard" label="Dashboard" icon={<IoStatsChart />} onClick={onClickLink} />
      <SideLink to="documents" label="Valeter Docs" icon={<IoDocumentText />} onClick={onClickLink} />
      <SideLink to="bookings" label="Bookings" icon={<IoCarSport />} onClick={onClickLink} />
      <SideLink to="locations" label="Locations" icon={<IoLocation />} onClick={onClickLink} />
      <SideLink to="organizations" label="Organisations" icon={<IoBusiness />} onClick={onClickLink} />
      <SideLink to="reports" label="Reports" icon={<IoBarChartOutline />} onClick={onClickLink} />
      <SideLink to="refunds" label="Refunds" icon={<IoArrowBackOutline />} onClick={onClickLink} />
    </>
  )
}

function SideLink({
  to,
  label,
  icon,
  onClick,
}: {
  to: string
  label: string
  icon: React.ReactNode
  onClick?: () => void
}) {
  return (
    <NavLink
      to={to}
      onClick={onClick}
      className={({ isActive }) =>
        `d-flex align-items-center gap-2 px-2 py-2 rounded text-decoration-none mb-1 ${
          isActive ? '' : ''
        }`
      }
      style={({ isActive }) => ({
        background: isActive 
          ? 'rgba(255, 255, 255, 0.2)' 
          : 'transparent',
        backdropFilter: isActive ? 'blur(10px)' : 'none',
        WebkitBackdropFilter: isActive ? 'blur(10px)' : 'none',
        border: isActive 
          ? '1px solid rgba(255, 255, 255, 0.3)' 
          : '1px solid transparent',
        color: isActive ? '#fff' : 'rgba(255, 255, 255, 0.7)',
        transition: 'all 0.2s ease',
      })}
    >
      <span style={{ fontSize: '18px', display: 'flex', alignItems: 'center' }}>{icon}</span>
      <span className="small">{label}</span>
    </NavLink>
  )
}