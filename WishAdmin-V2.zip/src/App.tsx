// src/App.tsx
import { useNavigate } from 'react-router-dom'
import { IoSparkles } from 'react-icons/io5'
import { IoAdd } from 'react-icons/io5'

export default function App() {
  const navigate = useNavigate()

  return (
    <div
      style={{
        minHeight: '100vh',
        background: 'radial-gradient(circle at top, #013e7d, #001a3a 55%)',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '1.5rem',
        position: 'relative',
      }}
    >
      <div
        style={{
          width: '100%',
          maxWidth: 900,
        }}
      >
        {/* header */}
        <div 
          className="d-flex flex-column flex-md-row justify-content-between align-items-start mb-4 gap-2"
          style={{
            background: 'rgba(255, 255, 255, 0.1)',
            backdropFilter: 'blur(20px)',
            WebkitBackdropFilter: 'blur(20px)',
            borderRadius: '20px',
            padding: '1.5rem',
            border: '1px solid rgba(255, 255, 255, 0.2)',
            boxShadow: '0 8px 32px rgba(0, 0, 0, 0.1)',
          }}
        >
          <div>
            <h1 className="text-white mb-1" style={{ fontWeight: 700 }}>
              Admin Portal
            </h1>
            <p className="text-white-50 mb-0">
              Pick the app you want to manage.
            </p>
          </div>
          <span
            className="badge"
            style={{ 
              alignSelf: 'flex-start',
              background: 'rgba(255, 255, 255, 0.25)',
              backdropFilter: 'blur(10px)',
              color: '#fff',
              border: '1px solid rgba(255, 255, 255, 0.3)',
            }}
          >
            Wish Apps • internal
          </span>
        </div>

        {/* app grid */}
        <div className="row g-3">
          {/* Wish-a-Wash card */}
          <div className="col-12 col-md-6 col-lg-4">
            <button
              onClick={() => navigate('/wish-a-wash')}
              className="btn w-100 h-100 p-0 text-start"
              style={{
                background: 'linear-gradient(135deg, rgba(0, 115, 255, 0.3) 0%, rgba(0, 192, 255, 0.3) 100%)',
                backdropFilter: 'blur(20px)',
                WebkitBackdropFilter: 'blur(20px)',
                border: '1px solid rgba(255, 255, 255, 0.3)',
                borderRadius: 20,
                overflow: 'hidden',
                boxShadow: '0 12px 30px rgba(0,0,0,0.2)',
                transition: 'all 0.3s ease',
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.transform = 'translateY(-4px)'
                e.currentTarget.style.boxShadow = '0 16px 40px rgba(0,0,0,0.3)'
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.transform = 'translateY(0)'
                e.currentTarget.style.boxShadow = '0 12px 30px rgba(0,0,0,0.2)'
              }}
            >
              <div className="p-3 d-flex flex-column gap-2" style={{ minHeight: 160 }}>
                <div
                  style={{
                    width: 44,
                    height: 44,
                    borderRadius: 14,
                    background: 'rgba(255,255,255,0.25)',
                    backdropFilter: 'blur(10px)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: 20,
                    border: '1px solid rgba(255, 255, 255, 0.3)',
                  }}
                >
                  <IoSparkles style={{ color: '#fff', fontSize: '24px' }} />
                </div>
                <div>
                  <h5 className="text-white mb-1">Wish-a-Wash</h5>
                  <p className="mb-0 text-white-75 small">
                    Manage bookings, valeters, locations, orgs.
                  </p>
                </div>
                <div className="mt-auto d-flex justify-content-between align-items-center">
                  <span 
                    className="badge"
                    style={{
                      background: 'rgba(255, 255, 255, 0.3)',
                      backdropFilter: 'blur(10px)',
                      color: '#fff',
                      border: '1px solid rgba(255, 255, 255, 0.4)',
                    }}
                  >
                    Active
                  </span>
                  <span className="text-white-75 small">Open →</span>
                </div>
              </div>
            </button>
          </div>

          {/* placeholder for future apps */}
          <div className="col-12 col-md-6 col-lg-4">
            <div
              className="h-100"
              style={{
                background: 'rgba(255,255,255,0.1)',
                backdropFilter: 'blur(20px)',
                WebkitBackdropFilter: 'blur(20px)',
                border: '1px dashed rgba(255,255,255,0.3)',
                borderRadius: 20,
                minHeight: 160,
                display: 'flex',
                flexDirection: 'column',
                justifyContent: 'center',
                alignItems: 'center',
                color: 'rgba(255,255,255,0.6)',
              }}
            >
              <IoAdd style={{ fontSize: 32, marginBottom: 6 }} />
              <p className="mb-0 small">More admin apps coming soon</p>
            </div>
          </div>
        </div>

        {/* footer */}
        <p 
          className="text-white-50 small mt-4 mb-0"
          style={{
            background: 'rgba(255, 255, 255, 0.05)',
            backdropFilter: 'blur(10px)',
            padding: '0.75rem 1rem',
            borderRadius: '12px',
            border: '1px solid rgba(255, 255, 255, 0.1)',
            textAlign: 'center',
          }}
        >
          Signed in as Admin • {new Date().getFullYear()}
        </p>
      </div>
    </div>
  )
}