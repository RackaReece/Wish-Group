# WishAdmin V2 - Admin Portal

Modern admin portal for managing Wish-a-Wash bookings, valeters, locations, organisations, reports, and refunds.

## ✨ Features

- 🎨 **Glassmorphism Design** - Beautiful frosted glass UI throughout
- 📊 **Dashboard** - Real-time statistics and activity tracking
- 📅 **Bookings Management** - View and manage all bookings
- 📄 **Document Management** - Review and approve valeter documents
- 🏢 **Organisation Management** - Monitor and verify organisation accounts
- 📍 **Location Management** - Manage car wash locations
- 📈 **Reports** - Generate and download revenue, bookings, and performance reports
- 💰 **Refunds** - Process and manage refund requests
- 👤 **Valeter Profiles** - Detailed valeter information and history

## Setup

1. Install dependencies:
```bash
npm install
```

2. Set up environment variables:
Create a `.env` file in the root directory:
```
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
```

**Note:** The app works without Supabase credentials in demo mode, but full functionality requires valid credentials.

3. Start the Expo development server:
```bash
npm start
# or
npm run dev
```

## Available Scripts

- `npm start` or `npm run dev` - Start Expo development server
- `npm run android` - Run on Android device/emulator
- `npm run ios` - Run on iOS device/simulator
- `npm run web` - Run in web browser
- `npm run build` - Build for production
- `npm run dev:web` - Run Vite dev server (for web-only development)
- `npm run build:web` - Build web version with Vite

## Project Structure

- `app/` - Expo Router app directory (file-based routing)
  - `index.tsx` - Home screen
  - `wish-a-wash/` - Wish-a-Wash admin section
    - `index.tsx` - Dashboard
    - `bookings.tsx` - Bookings management
    - `documents.tsx` - Document management
    - `organizations.tsx` - Organisation management
    - `locations.tsx` - Location management
    - `valeters/[id].tsx` - Valeter profile page
- `lib/` - Shared utilities
  - `supabaseClient.ts` - Supabase client configuration
- `src/` - Original web app code (still available for web builds)

## 🚀 Quick Start

### For Web Development (Recommended)
```bash
npm install
npm run dev:web
```
Visit `http://localhost:5173`

### For Expo Development
```bash
npm install
npm start
```

## 📁 Project Structure

- `src/` - Main web application source code
  - `pages/` - All page components
    - `waw/` - Wish-a-Wash admin pages
      - `DashboardPage.tsx` - Main dashboard
      - `BookingsPage.tsx` - Bookings list
      - `DocumentsPage.tsx` - Valeter documents
      - `OrgsPage.tsx` - Organisation management
      - `LocationsPage.tsx` - Location management
      - `ReportsPage.tsx` - Report generation
      - `RefundsPage.tsx` - Refund processing
      - `ValeterProfilePage.tsx` - Individual valeter profiles
  - `lib/` - Utilities and Supabase client
  - `index.css` - Global styles with glassmorphism utilities
- `app/` - Expo Router app directory (for mobile builds)
- `public/` - Static assets

## 🎨 Design Features

- **Glassmorphism UI** - Semi-transparent cards with backdrop blur
- **Ionicons** - Modern icon library throughout
- **Responsive Design** - Works on desktop and mobile
- **Dark Theme** - Beautiful blue gradient background
- **Smooth Animations** - Hover effects and transitions

## 🛠 Tech Stack

- **React 18** - UI framework
- **TypeScript** - Type safety
- **Vite** - Fast build tool for web
- **React Router DOM** - Client-side routing
- **Supabase** - Backend (optional)
- **Bootstrap 5** - UI components
- **React Icons** - Icon library

## 📝 Notes

- Reports are saved to localStorage if Supabase is not configured
- All pages gracefully handle missing Supabase credentials
- The app works in demo mode without backend connection
