import { Tabs } from 'expo-router';
import { Platform, Text } from 'react-native';

export default function WishAWashLayout() {
  return (
    <Tabs
      screenOptions={{
        headerStyle: {
          backgroundColor: '#001a3a',
        },
        headerTintColor: '#fff',
        tabBarActiveTintColor: '#0073ff',
        tabBarInactiveTintColor: '#999',
        tabBarStyle: {
          backgroundColor: '#fff',
          borderTopColor: '#e0e0e0',
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Dashboard',
          tabBarLabel: 'Dashboard',
          tabBarIcon: ({ color }) => (
            <Platform.OS === 'web' ? null : <Text style={{ color }}>📊</Text>
          ),
        }}
      />
      <Tabs.Screen
        name="bookings"
        options={{
          title: 'Bookings',
          tabBarLabel: 'Bookings',
          tabBarIcon: ({ color }) => (
            <Platform.OS === 'web' ? null : <Text style={{ color }}>📅</Text>
          ),
        }}
      />
      <Tabs.Screen
        name="documents"
        options={{
          title: 'Documents',
          tabBarLabel: 'Documents',
          tabBarIcon: ({ color }) => (
            <Platform.OS === 'web' ? null : <Text style={{ color }}>📄</Text>
          ),
        }}
      />
      <Tabs.Screen
        name="organizations"
        options={{
          title: 'Organisations',
          tabBarLabel: 'Orgs',
          tabBarIcon: ({ color }) => (
            <Platform.OS === 'web' ? null : <Text style={{ color }}>🏢</Text>
          ),
        }}
      />
      <Tabs.Screen
        name="locations"
        options={{
          title: 'Locations',
          tabBarLabel: 'Locations',
          tabBarIcon: ({ color }) => (
            <Platform.OS === 'web' ? null : <Text style={{ color }}>📍</Text>
          ),
        }}
      />
      <Tabs.Screen
        name="valeters/[id]"
        options={{
          title: 'Valeter Profile',
          href: null, // Hide from tab bar
        }}
      />
    </Tabs>
  );
}

