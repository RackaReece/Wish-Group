import { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { supabase, hasSupabaseCredentials } from '../../../lib/supabaseClient';

type ActivityDay = {
  date: string;
  totalBookings: number;
  totalRevenue: number;
  completed: number;
  scheduled: number;
};

export default function DashboardPage() {
  const [stats, setStats] = useState({
    totalBookings: 0,
    totalRevenue: 0,
    pendingDocs: 0,
    pendingOrgs: 0,
  });
  const [activity, setActivity] = useState<ActivityDay[]>([]);
  const [loading, setLoading] = useState(true);
  const [activityLoading, setActivityLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      if (!hasSupabaseCredentials) {
        // Demo mode - show zeros
        setStats({
          totalBookings: 0,
          totalRevenue: 0,
          pendingDocs: 0,
          pendingOrgs: 0,
        });
        setLoading(false);
        return;
      }

      try {
        const [
          { count: totalBookings, error: bookingsError },
          { data: revenueRows, error: revenueError },
          { count: pendingDocs, error: docsError },
          { count: pendingOrgs, error: orgsError },
        ] = await Promise.all([
          supabase.from('bookings').select('id', { count: 'exact', head: true }),
          supabase
            .from('bookings')
            .select('price, status')
            .in('status', ['completed', 'in_progress']),
          supabase
            .from('valeter_documents')
            .select('id', { count: 'exact', head: true })
            .eq('status', 'pending'),
          supabase
            .from('organizations')
            .select('id', { count: 'exact', head: true })
            .eq('status', 'pending'),
        ]);

        if (bookingsError || revenueError || docsError || orgsError) {
          console.error('Error loading stats:', { bookingsError, revenueError, docsError, orgsError });
        }

        const totalRevenue = (revenueRows || []).reduce(
          (sum, r) => sum + Number(r.price || 0),
          0
        );

        setStats({
          totalBookings: totalBookings || 0,
          totalRevenue,
          pendingDocs: pendingDocs || 0,
          pendingOrgs: pendingOrgs || 0,
        });
      } catch (error) {
        console.error('Error loading dashboard stats:', error);
      } finally {
        setLoading(false);
      }
    };

    load();
  }, []);

  useEffect(() => {
    const loadActivity = async () => {
      setActivityLoading(true);

      if (!hasSupabaseCredentials) {
        setActivity([]);
        setActivityLoading(false);
        return;
      }

      try {
        const { data, error } = await supabase
          .from('bookings')
          .select('id, price, status, created_at, completed_at')
          .order('created_at', { ascending: false })
          .limit(100);

        if (!error && data) {
          const grouped: Record<string, ActivityDay> = {};

          data.forEach((b) => {
            const d = new Date(b.created_at);
            const key = d.toISOString().slice(0, 10);

            if (!grouped[key]) {
              grouped[key] = {
                date: key,
                totalBookings: 0,
                totalRevenue: 0,
                completed: 0,
                scheduled: 0,
              };
            }

            grouped[key].totalBookings += 1;
            grouped[key].totalRevenue += Number(b.price || 0);
            if (b.status === 'completed') {
              grouped[key].completed += 1;
            }
            if (b.status === 'scheduled' || b.status === 'in_progress') {
              grouped[key].scheduled += 1;
            }
          });

          const days = Object.values(grouped)
            .sort((a, b) => (a.date < b.date ? 1 : -1))
            .slice(0, 7);

          setActivity(days);
        } else {
          console.error('Error loading activity:', error);
          setActivity([]);
        }
      } catch (error) {
        console.error('Error loading activity:', error);
        setActivity([]);
      } finally {
        setActivityLoading(false);
      }
    };

    loadActivity();
  }, []);

  return (
    <ScrollView style={styles.container}>
      {!hasSupabaseCredentials && (
        <View style={styles.warningBanner}>
          <Text style={styles.warningText}>
            ⚠️ Supabase credentials not configured. Running in demo mode. Add EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_ANON_KEY to your .env file.
          </Text>
        </View>
      )}
      <View style={styles.grid}>
        <GradientCard
          title="Total bookings"
          value={loading ? '…' : stats.totalBookings.toString()}
          gradient={['#00c97c', '#00e0a8']}
          icon="📦"
        />
        <GradientCard
          title="Total revenue"
          value={loading ? '…' : `£${stats.totalRevenue.toFixed(2)}`}
          gradient={['#0073ff', '#00c0ff']}
          icon="💷"
        />
        <GradientCard
          title="Pending documents"
          value={loading ? '…' : stats.pendingDocs.toString()}
          gradient={['#0ea5e9', '#38bdf8']}
          icon="📄"
        />
        <GradientCard
          title="Pending organisations"
          value={loading ? '…' : stats.pendingOrgs.toString()}
          gradient={['#6366f1', '#8b5cf6']}
          icon="🏢"
        />
      </View>

      <View style={styles.card}>
        <View style={styles.cardHeader}>
          <Text style={styles.cardTitle}>Activity</Text>
          <Text style={styles.cardSubtitle}>Last 7 days</Text>
        </View>
        <View style={styles.cardBody}>
          {activityLoading ? (
            <ActivityIndicator size="small" color="#0073ff" />
          ) : activity.length === 0 ? (
            <Text style={styles.emptyText}>No recent bookings.</Text>
          ) : (
            <View>
              {activity.map((day) => (
                <View key={day.date} style={styles.activityRow}>
                  <View>
                    <Text style={styles.activityDate}>{formatDate(day.date)}</Text>
                    <Text style={styles.activityCount}>
                      {day.totalBookings} booking{day.totalBookings !== 1 ? 's' : ''}
                    </Text>
                  </View>
                  <View style={styles.activityBadges}>
                    <View style={styles.badge}>
                      <Text style={styles.badgeText}>£{day.totalRevenue.toFixed(2)}</Text>
                    </View>
                    {day.completed > 0 && (
                      <View style={[styles.badge, styles.successBadge]}>
                        <Text style={[styles.badgeText, styles.successBadgeText]}>{day.completed} done</Text>
                      </View>
                    )}
                    {day.scheduled > 0 && (
                      <View style={[styles.badge, styles.warningBadge]}>
                        <Text style={[styles.badgeText, styles.warningBadgeText]}>{day.scheduled} in progress</Text>
                      </View>
                    )}
                  </View>
                </View>
              ))}
            </View>
          )}
        </View>
      </View>
    </ScrollView>
  );
}

function GradientCard({
  title,
  value,
  gradient,
  icon,
}: {
  title: string;
  value: string;
  gradient: [string, string];
  icon?: string;
}) {
  return (
    <LinearGradient
      colors={gradient}
      start={{ x: 0, y: 0 }}
      end={{ x: 1, y: 1 }}
      style={styles.gradientCard}
    >
      <View style={styles.gradientCardContent}>
        <View style={styles.gradientCardHeader}>
          <Text style={styles.gradientCardTitle}>{title}</Text>
          {icon ? <Text style={styles.gradientCardIcon}>{icon}</Text> : null}
        </View>
        <Text style={styles.gradientCardValue}>{value}</Text>
      </View>
    </LinearGradient>
  );
}

function formatDate(isoDate: string) {
  const d = new Date(isoDate);
  return d.toLocaleDateString(undefined, {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    padding: 16,
  },
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 12,
    marginBottom: 16,
  },
  gradientCard: {
    flex: 1,
    minWidth: '45%',
    borderRadius: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.12,
    shadowRadius: 30,
    elevation: 8,
  },
  gradientCardContent: {
    padding: 12,
  },
  gradientCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  gradientCardTitle: {
    fontSize: 12,
    textTransform: 'uppercase',
    color: 'rgba(255, 255, 255, 0.85)',
    fontWeight: '500',
  },
  gradientCardIcon: {
    fontSize: 20,
  },
  gradientCardValue: {
    fontSize: 24,
    fontWeight: '700',
    color: '#fff',
  },
  card: {
    backgroundColor: '#fff',
    borderRadius: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 8,
    elevation: 4,
    marginBottom: 16,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#e0e0e0',
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: '#000',
  },
  cardSubtitle: {
    fontSize: 12,
    color: '#999',
  },
  cardBody: {
    padding: 16,
    minHeight: 200,
  },
  emptyText: {
    fontSize: 14,
    color: '#999',
  },
  activityRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#f0f0f0',
  },
  activityDate: {
    fontSize: 14,
    fontWeight: '600',
    color: '#000',
  },
  activityCount: {
    fontSize: 12,
    color: '#999',
    marginTop: 2,
  },
  activityBadges: {
    flexDirection: 'row',
    gap: 8,
    flexWrap: 'wrap',
  },
  badge: {
    backgroundColor: '#f0f0f0',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  successBadge: {
    backgroundColor: '#22c55e',
  },
  warningBadge: {
    backgroundColor: '#f97316',
  },
  badgeText: {
    fontSize: 12,
    color: '#000',
    fontWeight: '500',
  },
  successBadgeText: {
    color: '#fff',
  },
  warningBadgeText: {
    color: '#fff',
  },
  warningBanner: {
    backgroundColor: '#f97316',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  warningText: {
    color: '#fff',
    fontSize: 14,
    textAlign: 'center',
  },
});

