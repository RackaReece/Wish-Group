import { useRouter } from 'expo-router';
import { View, Text, StyleSheet, TouchableOpacity, Platform } from 'react-native';

export default function HomeScreen() {
  const router = useRouter();

  return (
    <View style={styles.container}>
      <View style={styles.content}>
        {/* header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.title}>Admin Portal</Text>
            <Text style={styles.subtitle}>Pick the app you want to manage.</Text>
          </View>
          <View style={styles.badge}>
            <Text style={styles.badgeText}>Wish Apps • internal</Text>
          </View>
        </View>

        {/* app grid */}
        <View style={styles.grid}>
          {/* Wish-a-Wash card */}
          <TouchableOpacity
            style={styles.card}
            onPress={() => router.push('/wish-a-wash')}
            activeOpacity={0.8}
          >
            <View style={styles.cardContent}>
              <View style={styles.iconContainer}>
                <Text style={styles.icon}>🪄</Text>
              </View>
              <View style={styles.cardText}>
                <Text style={styles.cardTitle}>Wish-a-Wash</Text>
                <Text style={styles.cardDescription}>
                  Manage bookings, valeters, locations, orgs.
                </Text>
              </View>
              <View style={styles.cardFooter}>
                <View style={styles.activeBadge}>
                  <Text style={styles.activeBadgeText}>Active</Text>
                </View>
                <Text style={styles.arrow}>Open →</Text>
              </View>
            </View>
          </TouchableOpacity>

          {/* placeholder for future apps */}
          <View style={styles.placeholderCard}>
            <Text style={styles.placeholderIcon}>＋</Text>
            <Text style={styles.placeholderText}>More admin apps coming soon</Text>
          </View>
        </View>

        {/* footer */}
        <Text style={styles.footer}>
          Signed in as Admin • {new Date().getFullYear()}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#001a3a',
    padding: 24,
  },
  content: {
    flex: 1,
    maxWidth: 900,
    width: '100%',
    alignSelf: 'center',
  },
  header: {
    flexDirection: Platform.OS === 'web' ? 'row' : 'column',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 16,
    gap: 8,
  },
  title: {
    fontSize: 32,
    fontWeight: '700',
    color: '#fff',
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 16,
    color: 'rgba(255, 255, 255, 0.7)',
  },
  badge: {
    backgroundColor: '#fff',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
    alignSelf: 'flex-start',
  },
  badgeText: {
    color: '#000',
    fontSize: 12,
    fontWeight: '500',
  },
  grid: {
    gap: 12,
  },
  card: {
    backgroundColor: '#0073ff',
    borderRadius: 18,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.25,
    shadowRadius: 30,
    elevation: 8,
  },
  cardContent: {
    padding: 16,
    minHeight: 160,
    justifyContent: 'space-between',
  },
  iconContainer: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 8,
  },
  icon: {
    fontSize: 20,
  },
  cardText: {
    flex: 1,
    marginBottom: 8,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#fff',
    marginBottom: 4,
  },
  cardDescription: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.9)',
  },
  cardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 'auto',
  },
  activeBadge: {
    backgroundColor: '#fff',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 4,
  },
  activeBadgeText: {
    color: '#0073ff',
    fontSize: 12,
    fontWeight: '600',
  },
  arrow: {
    color: 'rgba(255, 255, 255, 0.9)',
    fontSize: 14,
  },
  placeholderCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.06)',
    borderWidth: 1,
    borderStyle: 'dashed',
    borderColor: 'rgba(255, 255, 255, 0.25)',
    borderRadius: 18,
    minHeight: 160,
    alignItems: 'center',
    justifyContent: 'center',
  },
  placeholderIcon: {
    fontSize: 28,
    color: 'rgba(255, 255, 255, 0.5)',
    marginBottom: 6,
  },
  placeholderText: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.5)',
  },
  footer: {
    fontSize: 14,
    color: 'rgba(255, 255, 255, 0.7)',
    marginTop: 16,
    textAlign: 'center',
  },
});

