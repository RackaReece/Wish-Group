import React, { useMemo, useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Platform,
  Modal,
  Pressable,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname, useRouter } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import Animated, { useAnimatedStyle, useSharedValue, withSpring, withTiming } from 'react-native-reanimated';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../src/constants/colors';
import { getAccountTheme } from '../../src/constants/accountThemes';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';

const { width } = Dimensions.get('window');

const TAB_BAR_HEIGHT = 80;
const BAR_MARGIN_H = 20;
const BAR_RADIUS = 28;

// Used by screens to pad content above the bar (DO NOT include safe area here)
const TAB_BAR_TOTAL_HEIGHT = TAB_BAR_HEIGHT - 20;
export { TAB_BAR_TOTAL_HEIGHT };

interface Tab {
  name: string;
  icon: keyof typeof Ionicons.glyphMap;
  route: string;
}

const getTabs = (userType?: string): Tab[] => {
  if (userType === 'valeter') {
    return [
      { name: 'Home', icon: 'home', route: '/valeter/valeter-dashboard' },
      { name: 'Jobs', icon: 'car', route: '/valeter/jobs/queue' },
      { name: 'Trip', icon: 'navigate', route: '/valeter/jobs/tracking' },
      { name: 'Earnings', icon: 'wallet', route: '/valeter/valeter-wash-history' },
      { name: 'Profile', icon: 'person', route: '/valeter/profile/valeter-profile' },
    ];
  }

  if (userType === 'organization') {
    return [
      { name: 'Home', icon: 'home', route: '/business/dashboard' },
      { name: 'Locations', icon: 'location', route: '/business/locations' },
      { name: 'Bookings', icon: 'calendar', route: '/business/bookings' },
      { name: 'Team', icon: 'people', route: '/business/team' },
      { name: 'Profile', icon: 'person', route: '/business/profile' },
    ];
  }

  return [
    { name: 'Home', icon: 'home', route: '/owner/owner-dashboard' },
    { name: 'Book', icon: 'calendar', route: '/owner/booking' },
    { name: 'Track', icon: 'navigate', route: '/owner/track' },
    { name: 'History', icon: 'time', route: '/owner/wash-history' },
    { name: 'Profile', icon: 'person', route: '/owner/owner-profile' },
  ];
};

const getActiveIndex = (pathname: string, tabs: Tab[]): number => {
  if (pathname.includes('/booking')) {
    const bookIndex = tabs.findIndex((t) => t.route.includes('/booking'));
    return bookIndex >= 0 ? bookIndex : 0;
  }

  if (pathname.includes('/track')) {
    const trackIndex = tabs.findIndex((t) => t.route === '/owner/track' || t.route.includes('/track'));
    return trackIndex >= 0 ? trackIndex : 0;
  }

  if (pathname.includes('/rewards')) {
    const rewardsIndex = tabs.findIndex((t) => t.route === '/rewards' || t.route.includes('rewards'));
    return rewardsIndex >= 0 ? rewardsIndex : 0;
  }

  if (pathname.includes('/valeter/jobs/')) {
    if (
      pathname.includes('/valeter/jobs/tracking') ||
      pathname.includes('/valeter/jobs/accept') ||
      pathname.includes('/valeter/jobs/complete')
    ) {
      const tripIndex = tabs.findIndex((t) => t.route === '/valeter/jobs/tracking');
      return tripIndex >= 0 ? tripIndex : 0;
    }
    const jobsIndex = tabs.findIndex((t) => t.route === '/valeter/jobs/queue');
    return jobsIndex >= 0 ? jobsIndex : 0;
  }

  if (pathname.includes('/valeter/valeter-wash-history')) {
    const earningsIndex = tabs.findIndex((t) => t.route === '/valeter/valeter-wash-history');
    return earningsIndex >= 0 ? earningsIndex : 0;
  }

  if (pathname.includes('/valeter/profile/valeter-profile') || pathname.includes('/valeter/valeter-profile')) {
    const profileIndex = tabs.findIndex((t) => t.route === '/valeter/profile/valeter-profile');
    return profileIndex >= 0 ? profileIndex : 0;
  }

  if (pathname.includes('/business/dashboard')) {
    const homeIndex = tabs.findIndex((t) => t.route === '/business/dashboard');
    return homeIndex >= 0 ? homeIndex : 0;
  }
  if (pathname.includes('/business/locations')) {
    const locationsIndex = tabs.findIndex((t) => t.route === '/business/locations');
    return locationsIndex >= 0 ? locationsIndex : 0;
  }
  if (pathname.includes('/business/bookings')) {
    const bookingsIndex = tabs.findIndex((t) => t.route === '/business/bookings');
    return bookingsIndex >= 0 ? bookingsIndex : 0;
  }
  if (pathname.includes('/business/team')) {
    const teamIndex = tabs.findIndex((t) => t.route === '/business/team');
    return teamIndex >= 0 ? teamIndex : 0;
  }
  if (pathname.includes('/business/profile')) {
    const profileIndex = tabs.findIndex((t) => t.route === '/business/profile');
    return profileIndex >= 0 ? profileIndex : 0;
  }

  for (let i = 0; i < tabs.length; i++) {
    if (pathname === tabs[i].route || pathname.startsWith(tabs[i].route + '/')) return i;
  }

  return 0;
};

// Separate component for tab items to allow hooks inside
function TabItem({
  tab,
  index,
  isActive,
  glowAnim,
  accent,
  onPress,
}: {
  tab: Tab;
  index: number;
  isActive: boolean;
  glowAnim: Animated.SharedValue<number>;
  accent: string;
  onPress: () => void;
}) {
  const isProfile = tab.name === 'Profile';
  const iconName = isProfile ? 'person-outline' : (`${tab.icon}-outline` as any);

  const glowStyle = useAnimatedStyle(() => {
    const glowOpacity = glowAnim.value;
    const glowScale = 1 + glowAnim.value * 0.15;
    return {
      shadowOpacity: 0.5 + glowOpacity * 0.3,
      shadowRadius: 16 + glowOpacity * 8,
      transform: [{ scale: glowScale }],
    };
  });

  return (
    <TouchableOpacity 
      style={styles.tab} 
      onPress={onPress} 
      activeOpacity={isActive ? 1 : 0.7}
      disabled={isActive}
    >
      <Animated.View
        style={[
          styles.iconContainer,
          isActive && styles.iconContainerActive,
          glowStyle,
          {
            backgroundColor: isActive ? accent : 'rgba(255,255,255,0.08)',
            shadowColor: isActive ? accent : 'transparent',
            borderColor: isActive ? accent : 'rgba(255,255,255,0.12)',
          },
        ]}
      >
        <Ionicons name={iconName as any} size={24} color={isActive ? "#FFFFFF" : "rgba(255,255,255,0.6)"} style={styles.icon} />
      </Animated.View>
    </TouchableOpacity>
  );
}

export default function NavigationTab() {
  const pathname = usePathname();
  const router = useRouter();
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const [showProfileActions, setShowProfileActions] = useState(false);

  const isBusinessRoute =
    pathname.includes('/business/') ||
    pathname.includes('/Business/') ||
    pathname.includes('/organisation/') ||
    pathname.includes('/Organization/');
  const businessTheme = isBusinessRoute ? getAccountTheme('business') : null;

  const isCustomerRoute = pathname.includes('/owner/') || pathname.includes('/customer');
  const customerTheme = isCustomerRoute ? getAccountTheme('customer') : null;

  const tabs = useMemo(() => {
    const userType = user?.userType;

    if (pathname.includes('/owner/') || pathname.includes('/customer')) return getTabs('customer');
    if (pathname.includes('/valeter/')) return getTabs('valeter');
    if (isBusinessRoute) return getTabs('organization');

    const safeUserType =
      userType === 'valeter' || userType === 'organization' || userType === 'business' ? userType : 'customer';

    if (userType === 'valeter' && !pathname.includes('/valeter/') && !pathname.includes('/driver/')) {
      return getTabs('customer');
    }

    return getTabs(safeUserType);
  }, [user?.userType, user?.email, pathname, isBusinessRoute]);

  const activeIndex = useMemo(() => getActiveIndex(pathname, tabs), [pathname, tabs]);

  const accent =
    (isBusinessRoute && businessTheme?.primary) ||
    (isCustomerRoute && customerTheme?.primary) ||
    colors.navActive;

  // Store glow animations for each tab - initialize with max 5 tabs
  const glowAnim0 = useSharedValue(0);
  const glowAnim1 = useSharedValue(0);
  const glowAnim2 = useSharedValue(0);
  const glowAnim3 = useSharedValue(0);
  const glowAnim4 = useSharedValue(0);
  const glowAnimations = [glowAnim0, glowAnim1, glowAnim2, glowAnim3, glowAnim4];

  const shouldHideTab = useMemo(() => {
    const hideRoutes = [
      '/auth/',
      '/onboarding',
      '/customer-onboarding',
      '/valeter/valeter-onboarding',
      '/organisation/organization-onboarding',
      '/owner/booking/',
      '/owner/booking/physical/',
      '/owner/booking/eco/',
      '/owner/booking/detailing/',
      '/owner/booking/create',
      '/owner/booking/payment',
      '/owner/booking/tracking',
      '/valeter/jobs/accept',
      '/valeter/jobs/tracking',
      '/valeter/jobs/complete',
    ];
    return hideRoutes.some((route) => pathname.includes(route));
  }, [pathname]);

  const isProfileTab = (tab: Tab) => tab.name === 'Profile';
  const bottomPad = Math.max(insets.bottom, 10) + 8;

  if (shouldHideTab) {
    return <View style={styles.hidden} />;
  }

  return (
    <View pointerEvents="box-none" style={styles.screenWrap}>
      <View style={[styles.row, { paddingHorizontal: 20, marginBottom: bottomPad }]}>
        {tabs.map((tab, index) => {
          const isActive = index === activeIndex;
          const isProfile = isProfileTab(tab);
          const glowAnim = glowAnimations[index] || glowAnim0;

          const handleTabPress = async () => {
            // Don't allow pressing the active tab
            if (isActive) {
              return;
            }
            
            // Trigger glow animation
            glowAnim.value = withTiming(1, { duration: 200 }, () => {
              glowAnim.value = withTiming(0, { duration: 300 });
            });
            
            if (isProfile && isBusinessRoute) {
              await hapticFeedback('light');
              setShowProfileActions(true);
            } else {
              await hapticFeedback('light');
              router.push(tab.route as any);
            }
          };

          return (
            <TabItem
              key={tab.route}
              tab={tab}
              index={index}
              isActive={isActive}
              glowAnim={glowAnim}
              accent={accent}
              onPress={handleTabPress}
            />
          );
        })}
      </View>

      <Modal
        visible={showProfileActions}
        transparent
        animationType="fade"
        onRequestClose={() => setShowProfileActions(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setShowProfileActions(false)}>
          <Pressable
            style={[
              styles.actionSheet,
              isBusinessRoute &&
                businessTheme && {
                  backgroundColor: businessTheme.background?.[0] || 'rgba(15, 23, 42, 0.95)',
                  borderColor: `${businessTheme.primary}55`,
                },
            ]}
            onPress={(e) => e.stopPropagation()}
          >
            <View style={styles.actionSheetHeader}>
              <Text style={[styles.actionSheetTitle, isBusinessRoute && businessTheme && { color: businessTheme.primary }]}>
                Profile Options
              </Text>
              <TouchableOpacity onPress={() => setShowProfileActions(false)} style={styles.actionSheetClose}>
                <Ionicons name="close" size={22} color={accent} />
              </TouchableOpacity>
            </View>

            <TouchableOpacity
              style={styles.actionSheetItem}
              onPress={async () => {
                await hapticFeedback('light');
                setShowProfileActions(false);
                router.push('/business/profile' as any);
              }}
              activeOpacity={0.85}
            >
              <View style={[styles.actionSheetIconWrapper, { backgroundColor: `${accent}20` }]}>
                <Ionicons name="person" size={20} color={accent} />
              </View>
              <Text style={styles.actionSheetItemText}>Business Profile</Text>
              <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.55)" />
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.actionSheetItem}
              onPress={async () => {
                await hapticFeedback('light');
                setShowProfileActions(false);
                router.push('/business/settings' as any);
              }}
              activeOpacity={0.85}
            >
              <View style={[styles.actionSheetIconWrapper, { backgroundColor: `${accent}20` }]}>
                <Ionicons name="settings" size={20} color={accent} />
              </View>
              <Text style={styles.actionSheetItemText}>Settings</Text>
              <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.55)" />
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  screenWrap: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 9999,
    elevation: 0,
  },

  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',
    width: '100%',
  },

  tab: {
    alignItems: 'center',
    justifyContent: 'center',
  },

  iconContainer: {
    width: 52,
    height: 52,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },

  iconContainerActive: {
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 8,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.3)',
  },

  icon: {
    // Icon styling handled in container
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.55)',
    justifyContent: 'flex-end',
  },

  actionSheet: {
    backgroundColor: 'rgba(15, 23, 42, 0.95)',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingTop: 16,
    paddingBottom: 28,
    borderTopWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },

  actionSheetHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.08)',
    marginBottom: 8,
  },

  actionSheetTitle: {
    fontSize: 18,
    fontWeight: '900',
    color: '#F9FAFB',
  },

  actionSheetClose: {
    width: 34,
    height: 34,
    borderRadius: 17,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },

  actionSheetItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 18,
    paddingVertical: 14,
    gap: 14,
  },

  actionSheetIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.10)',
  },

  actionSheetItemText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '800',
    color: '#F9FAFB',
  },
  hidden: {
    position: 'absolute',
    width: 0,
    height: 0,
  },
});
