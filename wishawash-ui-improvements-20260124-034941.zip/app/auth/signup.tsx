import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ScrollView,
  StatusBar,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Video, ResizeMode, AVPlaybackStatus } from 'expo-av';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import * as AppleAuthentication from 'expo-apple-authentication';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;

export default function SignupScreen() {
  const { register, /* @ts-ignore */ registerWithApple } = useAuth();

  // ✅ Customer app: ONLY customers
  const USER_TYPE = 'customer' as const;

  const [formData, setFormData] = useState({ name: '', email: '', password: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);
  const [isEmailFormOpen, setIsEmailFormOpen] = useState(false);
  const [videoError, setVideoError] = useState<string | null>(null);

  // Animations
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const videoRef = useRef<Video>(null);

  // Initial fade in animation
  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  // Apple availability
  useEffect(() => {
    (async () => {
      try {
        const available = Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  // Ensure video plays and handles seamless looping
  useEffect(() => {
    const playVideo = async () => {
      try {
        if (videoRef.current) {
          await videoRef.current.playAsync();
        }
      } catch (error) {
        console.warn('Video play error:', error);
        setVideoError('Video failed to load');
      }
    };
    playVideo();
  }, []);

  // Handle seamless looping without freeze - restart well before end
  const handlePlaybackStatusUpdate = (status: AVPlaybackStatus) => {
    if (status.isLoaded && status.durationMillis && status.positionMillis) {
      const timeRemaining = status.durationMillis - status.positionMillis;
      // Restart when within 300ms of the end for seamless transition
      if (timeRemaining < 300 && timeRemaining > 50) {
        // Restart before it ends to avoid any freeze
        videoRef.current?.setPositionAsync(0).catch(() => {});
      }
      // Backup: handle when video actually finishes
      if (status.didJustFinish) {
        videoRef.current?.setPositionAsync(0).catch(() => {});
        videoRef.current?.playAsync().catch(() => {});
      }
    }
  };

  const updateFormData = (field: keyof typeof formData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
    setError(null);
  };

  const validateForm = () => {
    if (!formData.name || !formData.email || !formData.password) {
      setError('Please fill in all required fields');
      return false;
    }
    if (!formData.email.includes('@')) {
      setError('Please enter a valid email address');
      return false;
    }
    if (formData.password.length < 6) {
      setError('Password must be at least 6 characters');
      return false;
    }
    return true;
  };

  const handleSignup = async () => {
    if (!validateForm()) return;

    await hapticFeedback('medium');
    setIsLoading(true);
    setError(null);

    try {
      const success = await register({
        email: formData.email,
        name: formData.name,
        userType: USER_TYPE, // ✅ forced
        password: formData.password,
      });

      if (success) {
        Alert.alert('Success!', 'Account created! Please verify your email.', [
          { text: 'OK', onPress: () => router.replace('/auth/login') },
        ]);
      } else {
        setError('Failed to create account. Please try again.');
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to create account. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleSignup = async () => {
    try {
      hapticFeedback('light');
      const cred = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      if (typeof registerWithApple === 'function') {
        const ok = await registerWithApple(cred, { userType: USER_TYPE }); // ✅ forced
        if (!ok) {
          Alert.alert('Apple Sign Up Failed', 'Could not create your account with Apple.');
          return;
        }
      } else {
        Alert.alert(
          'Apple Sign Up',
          'Apple credential received. Wire this to your backend via registerWithApple to finish sign up.'
        );
        return;
      }

      router.replace('/auth/login');
    } catch (error: any) {
      if (error?.code === 'ERR_CANCELED') return;
      Alert.alert('Apple Sign Up Failed', error?.message || 'Please try again.');
    }
  };

  const handleLogin = () => {
    hapticFeedback('light');
    router.replace('/auth/login');
  };

  return (
    <View style={styles.root}>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      {/* Video Background */}
      <Video
        ref={videoRef}
        source={require('../../assets/auth.mp4')}
        style={styles.videoBackground}
        resizeMode={ResizeMode.COVER}
        shouldPlay
        isLooping
        isMuted
        repeat
        ignoreSilentSwitch="ignore"
        progressUpdateIntervalMillis={30}
        onPlaybackStatusUpdate={handlePlaybackStatusUpdate}
        onError={(error) => {
          console.error('Video error:', error);
          setVideoError('Video failed to load');
        }}
        onLoad={() => {
          console.log('Video loaded successfully');
          setVideoError(null);
        }}
      />

      {/* Blue tint overlay */}
      <View style={styles.blueTintOverlay} pointerEvents="none" />

      {/* Dark overlay for better text readability */}
      <View style={styles.videoOverlay} pointerEvents="none" />

      <KeyboardAvoidingView 
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'} 
        style={styles.keyboardView}
        pointerEvents="box-none"
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
        >
          <Animated.View
            style={[
              styles.contentContainer,
              {
                opacity: fadeAnim,
                transform: [{ translateY: slideAnim }],
              },
            ]}
          >
            {/* Header with logo and sign in link */}
            <View style={styles.headerRow}>
              <Image source={require('../../assets/icon2.png')} style={styles.logoImage} resizeMode="contain" />
              <TouchableOpacity onPress={handleLogin} activeOpacity={0.7} style={styles.topLink}>
                <Text style={styles.topLinkText}>Sign in</Text>
              </TouchableOpacity>
            </View>

            {/* Email Form Toggle Button */}
            <TouchableOpacity
              style={styles.toggleButton}
              onPress={() => setIsEmailFormOpen(!isEmailFormOpen)}
              activeOpacity={0.8}
            >
              <View style={styles.toggleButtonContent}>
                <Ionicons name="mail-outline" size={20} color="rgba(255,255,255,0.9)" />
                <Text style={styles.toggleButtonText}>Sign up with Email</Text>
                <Ionicons 
                  name={isEmailFormOpen ? "chevron-up" : "chevron-down"} 
                  size={20} 
                  color="rgba(255,255,255,0.9)" 
                />
              </View>
            </TouchableOpacity>

            {/* Signup Form Card - Collapsible */}
            {isEmailFormOpen && (
              <View style={styles.formCard}>
              <View style={styles.inputWrapper}>
                <View style={styles.inputIconContainer}>
                  <Ionicons name="person-outline" size={20} color="rgba(255,255,255,0.7)" />
                </View>
                <TextInput
                  style={styles.input}
                  placeholder="Full name"
                  placeholderTextColor="rgba(255, 255, 255, 0.5)"
                  value={formData.name}
                  onChangeText={(v) => updateFormData('name', v)}
                  autoCapitalize="words"
                />
              </View>

              <View style={styles.inputWrapper}>
                <View style={styles.inputIconContainer}>
                  <Ionicons name="mail-outline" size={20} color="rgba(255,255,255,0.7)" />
                </View>
                <TextInput
                  style={styles.input}
                  placeholder="Email address"
                  placeholderTextColor="rgba(255, 255, 255, 0.5)"
                  value={formData.email}
                  onChangeText={(v) => updateFormData('email', v)}
                  keyboardType="email-address"
                  autoCapitalize="none"
                  autoCorrect={false}
                />
              </View>

              <View style={styles.inputWrapper}>
                <View style={styles.inputIconContainer}>
                  <Ionicons name="lock-closed-outline" size={20} color="rgba(255,255,255,0.7)" />
                </View>
                <TextInput
                  style={styles.input}
                  placeholder="Password (min. 6 characters)"
                  placeholderTextColor="rgba(255, 255, 255, 0.5)"
                  value={formData.password}
                  onChangeText={(v) => updateFormData('password', v)}
                  secureTextEntry
                />
              </View>

              {error && (
                <View style={styles.errorContainer}>
                  <Ionicons name="warning" size={18} color="#FCA5A5" style={{ marginRight: 8 }} />
                  <Text style={styles.errorText}>{error}</Text>
                </View>
              )}

              <TouchableOpacity
                style={[styles.signupButton, isLoading && styles.signupButtonDisabled]}
                onPress={handleSignup}
                disabled={isLoading}
                activeOpacity={0.9}
              >
                <LinearGradient
                  colors={['#10B981', '#059669']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.signupButtonGradient}
                >
                  <Text style={styles.signupButtonText}>
                    {isLoading ? 'Creating account...' : 'Create account'}
                  </Text>
                </LinearGradient>
              </TouchableOpacity>

              {/* Terms */}
              <View style={styles.termsContainer}>
                <Text style={styles.termsText}>
                  By creating an account, you agree to our <Text style={styles.termsLink}>Terms of Service</Text> and{' '}
                  <Text style={styles.termsLink}>Privacy Policy</Text>
                </Text>
              </View>
              </View>
            )}

            {/* Apple Sign Up - Always visible */}
            {isAppleAvailable && (
              <>
                <View style={styles.dividerContainer}>
                  <View style={styles.dividerLine} />
                  <Text style={styles.dividerText}>or continue with</Text>
                  <View style={styles.dividerLine} />
                </View>

                <AppleAuthentication.AppleAuthenticationButton
                  buttonType={AppleAuthentication.AppleAuthenticationButtonType.SIGN_UP}
                  buttonStyle={AppleAuthentication.AppleAuthenticationButtonStyle.WHITE}
                  cornerRadius={12}
                  style={styles.appleButton}
                  onPress={handleAppleSignup}
                />
              </>
            )}

            {/* Footer - Left aligned */}
            <View style={styles.footer}>
              <Text style={styles.footerText}>Wish a Wash v1.0.0 • © 2025</Text>
            </View>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#0A1929' },
  keyboardView: { flex: 1 },
  scrollContent: {
    flexGrow: 1,
    paddingTop: Platform.OS === 'ios' ? 40 : 30,
    paddingBottom: 40,
    paddingHorizontal: isSmallScreen ? 20 : 24,
  },
  contentContainer: { 
    flex: 1, 
    justifyContent: 'flex-start',
    paddingTop: 20,
    zIndex: 2,
  },

  // Video background
  videoBackground: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 0,
  },
  blueTintOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(135, 206, 235, 0.3)',
    zIndex: 1,
  },
  videoOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0, 0, 0, 0.15)',
    zIndex: 2,
  },

  // Header Section
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 8,
    marginBottom: 24,
    paddingHorizontal: 4,
  },
  logoImage: {
    width: 80,
    height: 80,
  },
  topLink: {
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  topLinkText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#87CEEB',
  },
  toggleButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    zIndex: 3,
  },
  toggleButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  toggleButtonText: {
    flex: 1,
    fontSize: 16,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.9)',
  },

  // Form Card
  formCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderRadius: 20,
    padding: 24,
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
    zIndex: 3,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(135, 206, 235, 0.25)',
    borderRadius: 14,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.5)',
    paddingLeft: 4,
  },
  inputIconContainer: { width: 48, height: 56, justifyContent: 'center', alignItems: 'center' },
  input: { flex: 1, paddingVertical: 16, paddingRight: 16, fontSize: 16, color: '#FFFFFF' },

  // Error
  errorContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    borderRadius: 12,
    padding: 12,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.3)',
  },
  errorText: { flex: 1, color: '#FCA5A5', fontSize: 14, fontWeight: '500' },

  // Signup Button
  signupButton: {
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 16,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  signupButtonDisabled: { opacity: 0.6 },
  signupButtonGradient: { paddingVertical: 18, alignItems: 'center' },
  signupButtonText: { fontSize: 18, fontWeight: 'bold', color: '#FFFFFF' },

  // Divider
  dividerContainer: { flexDirection: 'row', alignItems: 'center', marginVertical: 20 },
  dividerLine: { flex: 1, height: 1, backgroundColor: 'rgba(255, 255, 255, 0.2)' },
  dividerText: {
    color: 'rgba(255, 255, 255, 0.6)',
    fontSize: 12,
    fontWeight: '600',
    marginHorizontal: 12,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },

  // Apple Button
  appleButton: { width: '100%', height: 48, marginBottom: 20 },

  // Terms
  termsContainer: { marginTop: 4 },
  termsText: {
    fontSize: 12,
    color: 'rgba(255, 255, 255, 0.6)',
    textAlign: 'center',
    lineHeight: 18,
  },
  termsLink: { color: '#87CEEB', fontWeight: '600' },

  // Login Link
  loginContainer: { flexDirection: 'row', justifyContent: 'center', alignItems: 'center', marginBottom: 20 },
  loginText: { fontSize: 15, color: 'rgba(255, 255, 255, 0.8)', marginRight: 6 },
  loginLink: { fontSize: 15, color: '#87CEEB', fontWeight: 'bold' },

  // Footer
  footer: { 
    alignItems: 'flex-start', 
    marginTop: 20,
    paddingLeft: 4,
  },
  footerText: { 
    fontSize: 11, 
    color: 'rgba(255, 255, 255, 0.4)',
  },
});
