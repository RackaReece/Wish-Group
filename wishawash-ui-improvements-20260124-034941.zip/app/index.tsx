// app/index.tsx
import React, { useEffect, useState } from 'react';
import { useRouter, useRootNavigationState } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../src/providers/enhanced-auth-context';
import LoadingScreen from '../src/components/LoadingScreen';

function isCustomerOnboarded(user: any, seen: string | null) {
  // Backend flags (whatever you set in your profiles or metadata)
  const flags = {
    generic: Boolean(user?.onboarded || user?.isOnboarded),
    customer: Boolean(user?.customerOnboarded || user?.isCustomerOnboarded),
  };

  // Local flag (null means "not seen")
  const seenGeneric = seen === 'true' || seen === '1';
  const seenCustomer = seen === 'customer' || seenGeneric;

  return flags.generic || flags.customer || seenCustomer;
}

export default function Index() {
  const router = useRouter();
  const navReady = useRootNavigationState()?.key != null;
  const { user, isLoading, authReady } = useAuth();

  const [seenOnboarding, setSeenOnboarding] = useState<string | null>(null);

  useEffect(() => {
    AsyncStorage.getItem('onboarding_seen')
      .then((v) => setSeenOnboarding(v ?? null))
      .catch(() => setSeenOnboarding(null));
  }, []);

  useEffect(() => {
    if (!navReady || !authReady || isLoading) return;

    // 1) Not logged in → auth flow (customer app)
    if (!user) {
      router.replace('/auth/login');
      return;
    }

    // 2) Needs onboarding?
    if (!isCustomerOnboarded(user, seenOnboarding)) {
      router.replace('/owner/customer-onboarding');
      return;
    }

    // 3) Onboarded → customer dashboard
    router.replace('/owner/owner-dashboard');
  }, [navReady, authReady, isLoading, user, seenOnboarding, router]);

  return <LoadingScreen />;
}
