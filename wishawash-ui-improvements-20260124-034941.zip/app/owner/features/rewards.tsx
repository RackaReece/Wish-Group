import React, { useEffect, useMemo, useState, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
  Alert,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { useProfilePicture } from '../../../src/hooks/useProfilePicture';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

type RewardType = 'discount' | 'boost' | 'unlock' | 'badge' | 'service' | 'perk';
type RewardTier = 'common' | 'rare' | 'epic' | 'legendary';

interface Reward {
  id: string;
  title: string;
  description: string;
  points: number;
  icon: string;
  type: RewardType;
  tier: RewardTier;
  available: boolean;
  unlocked?: boolean;
}

export default function Rewards() {
  const { user } = useAuth();
  const profilePicture = useProfilePicture();

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const [completedCount, setCompletedCount] = useState(0);
  const [points, setPoints] = useState(0);
  const [level, setLevel] = useState<'Bronze' | 'Silver' | 'Gold' | 'Platinum' | 'Diamond'>('Bronze');
  const [progressToNext, setProgressToNext] = useState(0);

  const calculateLevel = useCallback((pts: number) => {
    if (pts >= 2000) return 'Diamond';
    if (pts >= 1000) return 'Platinum';
    if (pts >= 500) return 'Gold';
    if (pts >= 200) return 'Silver';
    return 'Bronze';
  }, []);

  const getLevelProgress = useCallback((pts: number, currentLevel: string) => {
    const thresholds: Record<string, { min: number; max: number }> = {
      Bronze: { min: 0, max: 200 },
      Silver: { min: 200, max: 500 },
      Gold: { min: 500, max: 1000 },
      Platinum: { min: 1000, max: 2000 },
      Diamond: { min: 2000, max: Infinity },
    };
    const threshold = thresholds[currentLevel];
    if (!threshold) return 0;
    const progress = Math.min(100, ((pts - threshold.min) / (threshold.max - threshold.min)) * 100);
    return Math.max(0, progress);
  }, []);

  const getLevelColor = (lvl: string) => {
    switch (lvl) {
      case 'Diamond': return '#E0E7FF';
      case 'Platinum': return '#F3F4F6';
      case 'Gold': return '#FCD34D';
      case 'Silver': return '#C0C0C0';
      default: return '#CD7F32';
    }
  };

  const rewards: Reward[] = useMemo(() => {
    const allRewards: Reward[] = [
      // Account Boosts
      { id: 'boost1', title: 'Priority Matching', description: 'Get matched with valeters 2x faster', points: 150, icon: 'flash', type: 'boost', tier: 'common', available: points >= 150 },
      { id: 'boost2', title: 'Account Boost', description: 'Profile appears at top of search results', points: 300, icon: 'rocket', type: 'boost', tier: 'rare', available: points >= 300 },
      { id: 'boost3', title: 'Speed Boost', description: 'Instant valeter matching for 24h', points: 500, icon: 'speedometer', type: 'boost', tier: 'rare', available: points >= 500 },
      { id: 'boost4', title: 'VIP Status', description: 'Premium support & priority booking', points: 1000, icon: 'star', type: 'boost', tier: 'epic', available: points >= 1000 },
      
      // Unlockable Features
      { id: 'unlock1', title: 'AI Scheduling', description: 'Unlock smart booking suggestions', points: 200, icon: 'sparkles', type: 'unlock', tier: 'common', available: points >= 200 },
      { id: 'unlock2', title: 'Advanced Tracking', description: 'Real-time location sharing', points: 400, icon: 'location', type: 'unlock', tier: 'rare', available: points >= 400 },
      { id: 'unlock3', title: 'Premium Themes', description: 'Unlock exclusive app themes', points: 600, icon: 'color-palette', type: 'unlock', tier: 'rare', available: points >= 600 },
      { id: 'unlock4', title: 'Custom Profile Badge', description: 'Show off your achievements', points: 800, icon: 'shield', type: 'unlock', tier: 'epic', available: points >= 800 },
      
      // Badges & Achievements
      { id: 'badge1', title: 'Early Bird Badge', description: 'Complete 5 morning bookings', points: 250, icon: 'sunny', type: 'badge', tier: 'common', available: points >= 250 },
      { id: 'badge2', title: 'Loyalty Champion', description: '50+ completed bookings', points: 750, icon: 'trophy', type: 'badge', tier: 'epic', available: points >= 750 },
      { id: 'badge3', title: 'Perfect Rating', description: 'Maintain 5.0 rating for 10 bookings', points: 500, icon: 'medal', type: 'badge', tier: 'rare', available: points >= 500 },
      { id: 'badge4', title: 'Eco Warrior', description: '10+ eco-friendly services', points: 350, icon: 'leaf', type: 'badge', tier: 'rare', available: points >= 350 },
      { id: 'badge5', title: 'Speed Demon', description: 'Complete booking in under 30min', points: 200, icon: 'flash', type: 'badge', tier: 'common', available: points >= 200 },
      { id: 'badge6', title: 'Legendary Status', description: 'Reach Diamond tier', points: 2000, icon: 'diamond', type: 'badge', tier: 'legendary', available: points >= 2000 },
      
      // Service Discounts
      { id: 'service1', title: '10% Off Next Wash', description: 'Save on your next service', points: 100, icon: 'pricetag', type: 'service', tier: 'common', available: points >= 100 },
      { id: 'service2', title: 'Free Basic Wash', description: 'Complimentary basic service', points: 300, icon: 'car', type: 'service', tier: 'common', available: points >= 300 },
      { id: 'service3', title: '20% Off Premium', description: 'Discount on premium services', points: 400, icon: 'sparkles', type: 'service', tier: 'rare', available: points >= 400 },
      { id: 'service4', title: 'Free Interior Clean', description: 'Complimentary interior service', points: 500, icon: 'brush', type: 'service', tier: 'rare', available: points >= 500 },
      { id: 'service5', title: 'Free Full Valet', description: 'Complete valet service', points: 1200, icon: 'diamond', type: 'service', tier: 'epic', available: points >= 1200 },
      
      // Perks
      { id: 'perk1', title: 'Skip Queue', description: 'Jump to front of booking queue', points: 250, icon: 'arrow-forward-circle', type: 'perk', tier: 'common', available: points >= 250 },
      { id: 'perk2', title: 'Double Points Day', description: 'Earn 2x points for 24 hours', points: 350, icon: 'gift', type: 'perk', tier: 'rare', available: points >= 350 },
      { id: 'perk3', title: 'Referral Bonus', description: 'Get £10 for each referral', points: 150, icon: 'people', type: 'perk', tier: 'common', available: points >= 150 },
      { id: 'perk4', title: 'Free Delivery', description: 'Free delivery on all services', points: 200, icon: 'bicycle', type: 'perk', tier: 'common', available: points >= 200 },
      { id: 'perk5', title: 'Monthly Subscription', description: '20% off monthly plans', points: 600, icon: 'calendar', type: 'perk', tier: 'rare', available: points >= 600 },
    ];
    return allRewards.map(r => ({ ...r, available: points >= r.points }));
  }, [points]);

  const loadPoints = useCallback(async () => {
    if (!user?.id) {
      setCompletedCount(0);
      setPoints(0);
      setLevel('Bronze');
      setProgressToNext(0);
      setLoading(false);
      setRefreshing(false);
      return;
    }

    try {
      if (!refreshing) setLoading(true);

      // Count completed bookings based on completed_at
      const { count, error } = await supabase
        .from('bookings')
        .select('id', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('status', 'completed');

      if (error) throw error;

      const c = count ?? 0;
      const pts = c * 10;
      setCompletedCount(c);
      setPoints(pts);
      const newLevel = calculateLevel(pts);
      setLevel(newLevel);
      setProgressToNext(getLevelProgress(pts, newLevel));
    } catch (e: any) {
      console.warn('[Rewards] Could not count completed bookings.', e);
      // Keep UI working even if query fails
      setCompletedCount(0);
      setPoints(0);
      setLevel('Bronze');
      setProgressToNext(0);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id, refreshing, calculateLevel, getLevelProgress]);

  useEffect(() => {
    loadPoints();
  }, [loadPoints]);

  const onRefresh = () => {
    setRefreshing(true);
    loadPoints();
  };

  const getTierColor = (tier: RewardTier) => {
    switch (tier) {
      case 'legendary': return '#FFD700';
      case 'epic': return '#9D4EDD';
      case 'rare': return '#4A90E2';
      default: return SKY;
    }
  };

  const getTypeIcon = (type: RewardType) => {
    switch (type) {
      case 'boost': return 'rocket';
      case 'unlock': return 'lock-open';
      case 'badge': return 'medal';
      case 'service': return 'car';
      case 'perk': return 'gift';
      default: return 'pricetag';
    }
  };

  const handleRedeem = (reward: Reward) => {
    if (!reward.available) return;
    Alert.alert(
      'Redeem Reward',
      `Unlock "${reward.title}" for ${reward.points} points?`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Redeem',
          onPress: () => {
            Alert.alert('Success!', `You've unlocked: ${reward.title}`);
          },
        },
      ]
    );
  };

  const groupedRewards = useMemo(() => {
    const groups: Record<string, Reward[]> = {
      'Account Boosts': rewards.filter(r => r.type === 'boost'),
      'Unlockables': rewards.filter(r => r.type === 'unlock'),
      'Badges': rewards.filter(r => r.type === 'badge'),
      'Service Discounts': rewards.filter(r => r.type === 'service'),
      'Perks': rewards.filter(r => r.type === 'perk'),
    };
    return Object.entries(groups).filter(([_, items]) => items.length > 0);
  }, [rewards]);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader 
        title="Rewards"
        profilePicture={profilePicture}
        onProfilePress={() => router.push('/owner/owner-profile')}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {/* Compact Points & Level Card */}
        <View style={styles.pointsCard}>
          <BlurView intensity={35} tint="dark" style={styles.pointsBlur}>
            <LinearGradient
              colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.pointsBorder} />
            <View style={styles.pointsContent}>
              <View style={styles.pointsHeader}>
                <View style={styles.pointsLeft}>
                  <View style={[styles.levelBadge, { backgroundColor: `${getLevelColor(level)}20` }]}>
                    <Ionicons name="trophy" size={16} color={getLevelColor(level)} />
                    <Text style={[styles.levelText, { color: getLevelColor(level) }]}>{level}</Text>
              </View>
              {loading ? (
                    <ActivityIndicator color={SKY} size="small" style={{ marginTop: 8 }} />
              ) : (
                <>
                  <Text style={styles.pointsValue}>{points.toLocaleString()}</Text>
                      <Text style={styles.pointsLabel}>Points</Text>
                    </>
                  )}
                </View>
                <View style={styles.pointsRight}>
                  <Ionicons name="gift" size={28} color={SKY} />
                </View>
              </View>
              
              {/* Progress Bar */}
              {!loading && (
                <View style={styles.progressContainer}>
                  <View style={styles.progressBarBg}>
                    <LinearGradient
                      colors={[SKY, '#4A90E2']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 0 }}
                      style={[styles.progressBarFill, { width: `${progressToNext}%` }]}
                    />
                  </View>
                  <Text style={styles.progressText}>
                    {progressToNext.toFixed(0)}% to {level === 'Diamond' ? 'Max' : 'Next Level'}
                  </Text>
                </View>
              )}
            </View>
          </BlurView>
        </View>

        {/* Rewards Grid by Category */}
        {groupedRewards.map(([category, categoryRewards]) => (
          <View key={category} style={styles.rewardsSection}>
            <View style={styles.categoryHeader}>
              <Text style={styles.categoryTitle}>{category}</Text>
              <Text style={styles.categoryCount}>{categoryRewards.filter(r => r.available).length}/{categoryRewards.length}</Text>
            </View>
            
            <View style={styles.rewardsGrid}>
              {categoryRewards.map((reward) => {
                const tierColor = getTierColor(reward.tier);
                const isUnlocked = reward.available;
                
                return (
            <TouchableOpacity
              key={reward.id}
                    style={[
                      styles.rewardCard,
                      !isUnlocked && styles.rewardCardDisabled,
                      { borderColor: isUnlocked ? `${tierColor}40` : 'rgba(107,114,128,0.2)' },
                    ]}
                    disabled={!isUnlocked}
              activeOpacity={0.8}
                    onPress={() => handleRedeem(reward)}
            >
              <BlurView intensity={30} tint="dark" style={styles.rewardBlur}>
                <LinearGradient
                        colors={isUnlocked 
                          ? ['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']
                          : ['rgba(107,114,128,0.05)', 'rgba(107,114,128,0.02)']
                        }
                  style={StyleSheet.absoluteFill}
                />
                      
                      {/* Tier Indicator */}
                      {reward.tier !== 'common' && (
                        <View style={[styles.tierBadge, { backgroundColor: `${tierColor}20` }]}>
                          <Text style={[styles.tierText, { color: tierColor }]}>
                            {reward.tier.toUpperCase()}
                          </Text>
                        </View>
                      )}
                      
                      <View style={styles.rewardContent}>
                  <View
                    style={[
                      styles.rewardIconWrapper,
                      {
                              backgroundColor: isUnlocked ? `${tierColor}20` : 'rgba(107,114,128,0.1)',
                              borderColor: isUnlocked ? `${tierColor}40` : 'rgba(107,114,128,0.2)',
                      },
                    ]}
                  >
                          <Ionicons 
                            name={reward.icon as any} 
                            size={28} 
                            color={isUnlocked ? tierColor : '#6B7280'} 
                          />
                  </View>

                        <Text 
                          style={[
                            styles.rewardTitle, 
                            !isUnlocked && styles.rewardTitleDisabled,
                            { color: isUnlocked ? '#F9FAFB' : '#6B7280' }
                          ]}
                          numberOfLines={2}
                        >
                      {reward.title}
                    </Text>
                        
                        <Text style={[styles.rewardDescription, !isUnlocked && styles.rewardDescriptionDisabled]}>
                          {reward.description}
                        </Text>

                        <View style={styles.rewardFooter}>
                          <View style={styles.pointsBadge}>
                            <Ionicons name="star" size={12} color={isUnlocked ? tierColor : '#6B7280'} />
                            <Text style={[styles.rewardPoints, { color: isUnlocked ? tierColor : '#6B7280' }]}>
                              {reward.points}
                            </Text>
                  </View>

                          {isUnlocked ? (
                            <Ionicons name="checkmark-circle" size={18} color="#10B981" />
                  ) : (
                            <Ionicons name="lock-closed" size={18} color="#6B7280" />
                  )}
                        </View>
                </View>
              </BlurView>
            </TouchableOpacity>
                );
              })}
            </View>
          </View>
          ))}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? 12 : 20 },
  
  // Compact Points Card
  pointsCard: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  pointsBlur: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  pointsBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  pointsContent: {
    padding: 16,
  },
  pointsHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  pointsLeft: {
    flex: 1,
  },
  pointsRight: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  levelBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    marginBottom: 8,
  },
  levelText: {
    fontSize: 11,
    fontWeight: '700',
    marginLeft: 4,
    textTransform: 'uppercase',
  },
  pointsValue: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 28 : 32,
    fontWeight: '800',
    marginBottom: 2,
  },
  pointsLabel: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
    opacity: 0.8,
  },
  progressContainer: {
    marginTop: 4,
  },
  progressBarBg: {
    height: 6,
    backgroundColor: 'rgba(107,114,128,0.2)',
    borderRadius: 3,
    overflow: 'hidden',
    marginBottom: 6,
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 3,
  },
  progressText: {
    color: '#87CEEB',
    fontSize: 11,
    fontWeight: '600',
    opacity: 0.8,
  },
  
  // Rewards Section
  rewardsSection: {
    marginBottom: 28,
  },
  categoryHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  categoryTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
  },
  categoryCount: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '600',
    backgroundColor: 'rgba(135,206,235,0.15)',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  rewardsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    marginHorizontal: -6,
  },
  rewardCard: {
    width: (width - (isSmallScreen ? 24 : 40) - 24) / 2,
    borderRadius: 14,
    overflow: 'hidden',
    margin: 6,
    borderWidth: 1.5,
    minHeight: 180,
  },
  rewardCardDisabled: {
    opacity: 0.6,
  },
  rewardBlur: {
    borderRadius: 14,
    overflow: 'hidden',
    flex: 1,
  },
  tierBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
    zIndex: 1,
  },
  tierText: {
    fontSize: 8,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  rewardContent: {
    padding: 12,
    flex: 1,
    justifyContent: 'space-between',
  },
  rewardIconWrapper: {
    width: 52,
    height: 52,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
    borderWidth: 1.5,
    alignSelf: 'center',
  },
  rewardTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 15,
    fontWeight: '700',
    marginBottom: 4,
    textAlign: 'center',
    minHeight: 36,
  },
  rewardTitleDisabled: {
    color: '#6B7280',
  },
  rewardDescription: {
    color: '#94A3B8',
    fontSize: 11,
    textAlign: 'center',
    marginBottom: 10,
    lineHeight: 14,
    minHeight: 28,
  },
  rewardDescriptionDisabled: {
    color: '#6B7280',
    opacity: 0.6,
  },
  rewardFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 'auto',
  },
  pointsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(135,206,235,0.1)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  rewardPoints: {
    fontSize: 12,
    fontWeight: '700',
    marginLeft: 4,
  },
});
