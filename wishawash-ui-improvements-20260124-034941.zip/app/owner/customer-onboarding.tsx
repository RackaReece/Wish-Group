import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Animated,
  
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { Ionicons } from '@expo/vector-icons';


export default function CustomerOnboarding() {
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState(0);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  const steps = [
    {
      title: 'Welcome to Wish a Wash!',
      subtitle: 'Your journey to premium car care starts here',
      description:
        "You're now part of a community that values quality, convenience, and exceptional service. Get ready to experience car washing like never before.",
      iconName: 'sparkles',
      color: '#10B981',
    },
    {
      title: 'Premium Service at Your Fingertips',
      subtitle: 'Book washes with just a few taps',
      description:
        'Our app makes booking car washes effortless. Choose instant, priority or scheduled services — all from your phone.',
      iconName: 'phone-portrait',
      color: '#60A5FA',
    },
    {
      title: 'Professional Valeters You Can Trust',
      subtitle: 'Vetted and certified professionals',
      description:
        'Every valeter on our platform is thoroughly vetted, trained, and insured. Your vehicle is in safe, professional hands.',
      iconName: 'shield-checkmark',
      color: '#8B5CF6',
    },
    {
      title: 'Earn Rewards as You Wash',
      subtitle: 'Points, discounts, and exclusive perks',
      description:
        'Every wash earns you points towards free services, discounts, and exclusive rewards. The more you wash, the more you save!',
      iconName: 'gift',
      color: '#F59E0B',
    },
    {
      title: 'Real-Time Tracking & Updates',
      subtitle: "Know exactly what's happening",
      description:
        "Track your valeter's location, get real-time updates, and see photos of your completed wash. Transparency throughout the process.",
      iconName: 'navigate',
      color: '#EF4444',
    },
    {
      title: "You're All Set!",
      subtitle: 'Ready to experience premium car care',
      description:
        'Your account is ready! Start by booking your first wash and discover why thousands of customers choose Wish a Wash.',
      iconName: 'checkmark-circle',
      color: '#10B981',
    },
  ];

  React.useEffect(() => {
    animateStep();
  }, [currentStep]);

  const animateStep = () => {
    fadeAnim.setValue(0);
    slideAnim.setValue(50);

    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const completeOnboarding = async () => {
    try {
      // Mark customer onboarding as seen
      await AsyncStorage.setItem('customer_onboarding_seen', 'true');
      (router as any).replace('owner/owner-dashboard');
    } catch (error) {
      console.error('Error marking onboarding as seen:', error);
      (router as any).replace('owner/owner-dashboard');
    }
  };

  const nextStep = () => {
    if (currentStep < steps.length - 1) {
      setCurrentStep(currentStep + 1);
    } else {
      // Complete onboarding
      completeOnboarding();
    }
  };

  const skipOnboarding = () => {
    completeOnboarding();
  };

  const currentStepData = steps[currentStep];

  return (
    <SafeAreaView style={styles.container}>
      {/* Background */}
      <LinearGradient colors={['#0A1929', '#0A1929']} style={StyleSheet.absoluteFill} />

      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity onPress={skipOnboarding} style={styles.skipButton}>
          <Text style={styles.skipText}>Skip</Text>
        </TouchableOpacity>
        
        <View style={styles.progressContainer}>
          {steps.map((_, index) => (
            <View
              key={index}
              style={[
                styles.progressDot,
                index === currentStep && styles.progressDotActive,
                index < currentStep && styles.progressDotCompleted
              ]}
            />
          ))}
        </View>
        
        <View style={styles.placeholder} />
      </View>

      {/* Content */}
      <View style={styles.content}>
        <Animated.View
          style={[
            styles.stepContainer,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <View style={styles.iconContainer}>
            <Ionicons name={currentStepData.iconName as any} size={56} color={'#87CEEB'} />
          </View>

          <Text style={styles.stepTitle}>{currentStepData.title}</Text>
          <Text style={styles.stepSubtitle}>{currentStepData.subtitle}</Text>
          
          <Text style={styles.stepDescription}>{currentStepData.description}</Text>

          {/* Step-specific content */}
          {currentStep === 0 && (
            <View style={styles.welcomeCard}>
              <Text style={styles.welcomeText}>
                Hello, {user?.name || 'Valued Customer'}!
              </Text>
              <Text style={styles.welcomeSubtext}>
                We're excited to have you join our community of car care enthusiasts.
              </Text>
            </View>
          )}

          {currentStep === 1 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>What You Can Do:</Text>
              <View style={styles.featureItem}>
                <Ionicons name="flash" size={20} color="#87CEEB" style={styles.featureIconIon} />
                <Text style={styles.featureText}>Book instant washes</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="star" size={20} color="#87CEEB" style={styles.featureIconIon} />
                <Text style={styles.featureText}>Choose priority service</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="calendar" size={20} color="#87CEEB" style={styles.featureIconIon} />
                <Text style={styles.featureText}>Schedule future appointments</Text>
              </View>
            </View>
          )}

          {currentStep === 2 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Our Valeters:</Text>
              <View style={styles.featureItem}>
                <Ionicons name="checkmark-circle" size={20} color="#10B981" style={styles.featureIconIon} />
                <Text style={styles.featureText}>Background checked</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="ribbon" size={20} color="#87CEEB" style={styles.featureIconIon} />
                <Text style={styles.featureText}>Professionally trained</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="shield-checkmark" size={20} color="#87CEEB" style={styles.featureIconIon} />
                <Text style={styles.featureText}>Fully insured</Text>
              </View>
            </View>
          )}

          {currentStep === 3 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Rewards Include:</Text>
              <View style={styles.featureItem}>
                <Ionicons name="gift" size={20} color="#87CEEB" style={styles.featureIconIon} />
                <Text style={styles.featureText}>Free washes</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="wallet" size={20} color="#87CEEB" style={styles.featureIconIon} />
                <Text style={styles.featureText}>Exclusive discounts</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="star" size={20} color="#87CEEB" style={styles.featureIconIon} />
                <Text style={styles.featureText}>Priority booking</Text>
              </View>
            </View>
          )}

          {currentStep === 4 && (
            <View style={styles.featureCard}>
              <Text style={styles.featureTitle}>Track Everything:</Text>
              <View style={styles.featureItem}>
                <Ionicons name="navigate" size={20} color="#87CEEB" style={styles.featureIconIon} />
                <Text style={styles.featureText}>Real-time location</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="camera" size={20} color="#87CEEB" style={styles.featureIconIon} />
                <Text style={styles.featureText}>Before & after photos</Text>
              </View>
              <View style={styles.featureItem}>
                <Ionicons name="chatbubble-ellipses" size={20} color="#87CEEB" style={styles.featureIconIon} />
                <Text style={styles.featureText}>Direct communication</Text>
              </View>
            </View>
          )}

          {currentStep === 5 && (
            <View style={styles.finalCard}>
              <Text style={styles.finalTitle}>Ready to Get Started?</Text>
              <Text style={styles.finalText}>
                Your first wash is just a tap away. Experience the difference that professional car care makes.
              </Text>
            </View>
          )}
        </Animated.View>
      </View>

      {/* Footer */}
      <View style={styles.footer}>
        <TouchableOpacity
          style={styles.nextButton}
          onPress={nextStep}
        >
          <Text style={styles.nextButtonText}>
            {currentStep === steps.length - 1 ? 'Get Started' : 'Next'}
          </Text>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.15)',
  },
  skipButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  skipText: {
    color: '#60A5FA',
    fontSize: 16,
    fontWeight: '600',
  },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  progressDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.25)',
    marginHorizontal: 4,
  },
  progressDotActive: {
    backgroundColor: '#87CEEB',
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  progressDotCompleted: {
    backgroundColor: '#10B981',
  },
  placeholder: {
    width: 60,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
    paddingHorizontal: 20,
  },
  stepContainer: {
    alignItems: 'center',
  },
  iconContainer: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: 'rgba(135,206,235,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
    borderWidth: 0.8,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  stepIcon: {
    fontSize: 44,
  },
  stepTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 8,
    lineHeight: 30,
  },
  stepSubtitle: {
    color: '#60A5FA',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 16,
    fontWeight: '600',
  },
  stepDescription: {
    color: '#0A1929',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 20,
    opacity: 0.9,
  },
  welcomeCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.06)',
    borderRadius: 14,
    padding: 18,
    marginTop: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
  },
  welcomeText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  welcomeSubtext: {
    color: '#87CEEB',
    fontSize: 16,
    textAlign: 'center',
  },
  featureCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.06)',
    borderRadius: 14,
    padding: 18,
    marginTop: 12,
    width: '100%',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 4,
  },
  featureTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 12,
    textAlign: 'center',
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  featureIcon: {
    fontSize: 20,
    marginRight: 12,
  },
  featureIconIon: {
    marginRight: 12,
  },
  featureText: {
    color: '#FFFFFF',
    fontSize: 14,
    flex: 1,
  },
  finalCard: {
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
    borderWidth: 1.2,
    borderColor: '#10B981',
    borderRadius: 14,
    padding: 18,
    marginTop: 12,
    alignItems: 'center',
  },
  finalTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 10,
  },
  finalText: {
    color: '#FFFFFF',
    fontSize: 14,
    textAlign: 'center',
    lineHeight: 22,
  },
  footer: {
    paddingHorizontal: 20,
    paddingBottom: 36,
  },
  nextButton: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    paddingVertical: 14,
    paddingHorizontal: 22,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.6)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.18,
    shadowRadius: 4,
  },
  nextButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});
