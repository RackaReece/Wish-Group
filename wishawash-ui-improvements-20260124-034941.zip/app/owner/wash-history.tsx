import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Animated as RNAnimated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import { useProfilePicture } from '../../src/hooks/useProfilePicture';
import { colors } from '../../src/constants/colors';
import { customerTheme } from '../../src/constants/customerTheme';
import Animated, { FadeInDown } from 'react-native-reanimated';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY;
const BG = colors.BG;

// Vibrant color palette
const VIBRANT_PURPLE = '#A855F7';
const VIBRANT_PINK = '#EC4899';
const VIBRANT_CYAN = '#06B6D4';
const VIBRANT_ORANGE = '#F97316';
const VIBRANT_GREEN = '#10B981';
const VIBRANT_YELLOW = '#FBBF24';

type CompletedStatus =
  | 'completed'
  | 'rated'
  | 'tipped'
  | 'closed'
  | 'archived'
  | 'complete';

const COMPLETED_STATUSES = new Set<CompletedStatus>([
  'completed',
  'rated',
  'tipped',
  'closed',
  'archived',
  'complete',
]);

const ACTIVE_STATUSES = [
  'pending',
  'pending_valeter_acceptance',
  'pending_payment',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
  'in_progress',
  'scheduled',
];

type NormalizedCompletion = {
  id: string;
  status: string;
  serviceName?: string | null;
  service_type?: string | null;
  price?: number | null;
  completedAt?: string | Date | null;
  createdAt?: string | Date | null;
  scheduledAt?: string | Date | null;
  valeterName?: string | null;
  valeterOrganization?: string | null;
  address?: string | null;
  location?: { latitude: number; longitude: number } | null;
  notes?: string | null;
  rating?: number | null;
  customerReview?: string | null;
  tipAmount?: number | null;
  photos?: any[] | null;
};

export default function WashHistory() {
  const { user } = useAuth();
  const profilePicture = useProfilePicture();
  const params = useLocalSearchParams<{ highlightId?: string | string[] }>();

  const highlightId = useMemo(() => {
    const raw = params?.highlightId;
    if (Array.isArray(raw)) return raw[0] ?? null;
    return raw ?? null;
  }, [params]);

  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [washCompletions, setWashCompletions] = useState<NormalizedCompletion[]>([]);
  const [activeBookings, setActiveBookings] = useState<NormalizedCompletion[]>([]);
  const scrollY = useRef(new RNAnimated.Value(0)).current;

  const formatCurrency = (n?: number | null) =>
    typeof n === 'number' ? `£${n.toFixed(2).replace(/\.00$/, '')}` : '—';

  const numberish = (v: any): number | null => {
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  };

  const isCompleted = (wc: NormalizedCompletion) =>
    COMPLETED_STATUSES.has(((wc?.status || 'completed') as CompletedStatus)) ||
    !!wc.completedAt;

  const sortByCompletedAtDesc = (a: NormalizedCompletion, b: NormalizedCompletion) => {
    const ta = new Date((a.completedAt ?? a.createdAt ?? 0) as any).getTime();
    const tb = new Date((b.completedAt ?? b.createdAt ?? 0) as any).getTime();
    return tb - ta;
  };

  // ✅ Schema-safe mapping for your `public.bookings`
  const normalizeFromBookings = (rows: any[]): NormalizedCompletion[] =>
    rows.map((r) => ({
      id: String(r.id),
      status: r.status ?? 'scheduled',
      serviceName: r.service_name ?? r.service_type ?? r.wash_type ?? 'Car Wash',
      service_type: r.service_type ?? r.wash_type ?? null,
      price: numberish(r.price),
      completedAt: r.completed_at ?? null,
      createdAt: r.created_at ?? null,
      scheduledAt: r.scheduled_at ?? null,
      valeterName: r.valeter_name ?? null,
      valeterOrganization: null, // not in schema
      address: r.location_address ?? null,
      location:
        typeof r.location_lat === 'number' && typeof r.location_lng === 'number'
          ? { latitude: r.location_lat, longitude: r.location_lng }
          : null,
      notes: r.special_instructions ?? null,
      rating: numberish(r.rating),
      customerReview: r.customer_review ?? null,
      tipAmount: numberish(r.tip_amount),
      photos: null, // not in schema
    }));

  const formatDate = (dateLike: Date | string | number | undefined | null) => {
    const d = dateLike ? new Date(dateLike) : new Date();
    return d.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const loadWashHistory = async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }

    setLoading(true);
    try {
      // -------------------------
      // Completed bookings (history)
      // -------------------------
      const { data: completedRows, error: completedError } = await supabase
        .from('bookings')
        .select(
          `
          id,
          user_id,
          status,
          service_name,
          service_type,
          wash_type,
          price,
          scheduled_at,
          created_at,
          completed_at,
          valeter_name,
          location_address,
          location_lat,
          location_lng,
          rating,
          customer_review,
          tip_amount,
          special_instructions,
          cancelled_at
        `
        )
        .eq('user_id', user.id)
        .is('cancelled_at', null)
        // completed_at is the main signal, but allow status=completed too
        .or('completed_at.not.is.null,status.eq.completed')
        .order('completed_at', { ascending: false })
        .limit(200);

      if (completedError) throw completedError;

      const completedList = normalizeFromBookings(completedRows || [])
        .filter(isCompleted)
        .sort(sortByCompletedAtDesc);

      setWashCompletions(completedList);

      // -------------------------
      // Active bookings
      // -------------------------
      const { data: activeRows, error: activeError } = await supabase
        .from('bookings')
        .select(
          `
          id,
          user_id,
          status,
          service_name,
          service_type,
          wash_type,
          price,
          scheduled_at,
          created_at,
          valeter_name,
          location_address,
          location_lat,
          location_lng,
          special_instructions,
          cancelled_at,
          completed_at
        `
        )
        .eq('user_id', user.id)
        .is('cancelled_at', null)
        .is('completed_at', null)
        .order('created_at', { ascending: false })
        .limit(50);

      if (activeError) throw activeError;

      const activeFiltered = (activeRows || []).filter((r: any) =>
        ACTIVE_STATUSES.includes(r.status)
      );

      setActiveBookings(normalizeFromBookings(activeFiltered));
    } catch (error) {
      console.error('[wash-history] Error loading wash history:', error);
      Alert.alert('Error', 'Failed to load wash history');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadWashHistory();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const onRefresh = useCallback(async () => {
    try {
      setRefreshing(true);
      await loadWashHistory();
    } finally {
      setRefreshing(false);
    }
  }, []);

  const formatStatusLabel = (status: string) =>
    (status || '')
      .replace(/_/g, ' ')
      .replace(/\b\w/g, (char) => char.toUpperCase());

  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'en_route':
      case 'arrived':
        return VIBRANT_GREEN;
      case 'in_progress':
        return VIBRANT_CYAN;
      case 'valeter_assigned':
      case 'confirmed':
        return VIBRANT_PURPLE;
      case 'pending_valeter_acceptance':
      case 'pending':
        return VIBRANT_ORANGE;
      default:
        return SKY;
    }
  };

  const getDynamicCTAText = (status: string): string => {
    switch (status) {
      case 'pending_valeter_acceptance':
      case 'pending':
        return 'View Request Status';
      case 'confirmed':
      case 'valeter_assigned':
        return 'View Live Tracking';
      case 'en_route':
        return 'Track Valeter';
      case 'in_progress':
      case 'arrived':
        return 'Live Progress';
      case 'completed':
        return 'View Receipt + Tip';
      case 'pending_payment':
        return 'Pay Now';
      default:
        return 'View Live Tracking';
    }
  };

  const handleRepeatBooking = (completion: NormalizedCompletion) => {
    const serviceType = (completion.service_type || completion.serviceName || '').toLowerCase();

    if (serviceType.includes('detailing')) {
      router.push({
        pathname: '/owner/booking/detailing/create',
        params: {
          ...(completion.address && { address: completion.address }),
          ...(completion.location?.latitude && { latitude: completion.location.latitude.toString() }),
          ...(completion.location?.longitude && { longitude: completion.location.longitude.toString() }),
        },
      });
    } else if (serviceType.includes('eco')) {
      router.push({
        pathname: '/owner/booking/eco/create',
        params: {
          deliveryType: 'comeToYou',
          ...(completion.address && { address: completion.address }),
          ...(completion.location?.latitude && { latitude: completion.location.latitude.toString() }),
          ...(completion.location?.longitude && { longitude: completion.location.longitude.toString() }),
        },
      });
    } else {
      router.push({
        pathname: '/owner/booking/create',
        params: {
          ...(completion.address && { address: completion.address }),
          ...(completion.location?.latitude && { latitude: completion.location.latitude.toString() }),
          ...(completion.location?.longitude && { longitude: completion.location.longitude.toString() }),
        },
      });
    }
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="History"
        scrollY={scrollY}
        rightAction={
          <TouchableOpacity onPress={() => router.push('/owner/booking')} style={styles.bookButton}>
            <Ionicons name="add" size={24} color={SKY} />
          </TouchableOpacity>
        }
        profilePicture={profilePicture}
        onProfilePress={() => router.push('/owner/owner-profile')}
      />

      <RNAnimated.ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
        onScroll={RNAnimated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], {
          useNativeDriver: false,
        })}
        scrollEventThrottle={16}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />}
      >
        {activeBookings.length === 0 && washCompletions.length === 0 ? (
          <Animated.View entering={FadeInDown.delay(100)} style={styles.emptyContainer}>
            <View style={styles.emptyIconContainer}>
              <LinearGradient
                colors={[VIBRANT_CYAN, SKY]}
                style={styles.emptyIconGradient}
              >
                <Ionicons name="time-outline" size={64} color="#FFFFFF" />
              </LinearGradient>
            </View>
            <Text style={styles.emptyTitle}>No Bookings Yet</Text>
            <Text style={styles.emptySubtitle}>Your active and completed bookings will appear here</Text>
            <TouchableOpacity style={styles.bookButtonCard} onPress={() => router.push('/owner/booking')}>
              <LinearGradient colors={[SKY, VIBRANT_CYAN]} style={styles.bookButtonGradient}>
                <Ionicons name="add-circle" size={22} color="#FFFFFF" />
                <Text style={styles.bookButtonText}>Book a Service</Text>
              </LinearGradient>
            </TouchableOpacity>
          </Animated.View>
        ) : (
          <>
            {activeBookings.length > 0 && (
              <View style={styles.sectionContainer}>
                <View style={styles.sectionHeader}>
                  <View style={styles.sectionIconWrapper}>
                    <LinearGradient colors={[VIBRANT_ORANGE, VIBRANT_YELLOW]} style={styles.sectionIconGradient}>
                      <Ionicons name="flash" size={18} color="#FFFFFF" />
                    </LinearGradient>
                  </View>
                  <View>
                    <Text style={styles.sectionHeading}>Active Bookings</Text>
                    <Text style={styles.sectionSubtitle}>{activeBookings.length} in progress</Text>
                  </View>
                </View>
                {activeBookings.map((booking, index) => {
                  const isHighlighted = highlightId === booking.id;
                  const serviceName = booking.serviceName ?? booking.service_type ?? 'Car Wash';
                  const occursAt = booking.scheduledAt ?? booking.createdAt;
                  const valeterName = booking.valeterName;
                  const address = booking.address;
                  const statusColor = getStatusColor(booking.status);

                  return (
                    <Animated.View
                      key={`active-${booking.id}`}
                      entering={FadeInDown.delay(index * 80)}
                      style={[styles.bookingCard, styles.activeCard, isHighlighted && styles.highlightCard]}
                    >
                      <TouchableOpacity
                        activeOpacity={0.9}
                        onPress={() => {
                          // Navigate to tracking page for active bookings
                          const isActive = !isCompleted(booking);
                          if (isActive) {
                            router.push({
                              pathname: '/owner/booking/tracking',
                              params: { bookingId: booking.id },
                            });
                          }
                        }}
                      >
                        <View style={styles.bookingContent}>
                          <View style={styles.bookingHeader}>
                            <View style={[styles.bookingIconWrapper, { backgroundColor: `${statusColor}20` }]}>
                              <LinearGradient
                                colors={[statusColor, `${statusColor}CC`]}
                                style={styles.iconGradient}
                              >
                                <Ionicons name="time" size={20} color="#FFFFFF" />
                              </LinearGradient>
                            </View>
                            <View style={styles.bookingInfo}>
                              <Text style={styles.bookingService} numberOfLines={1} ellipsizeMode="tail">
                                {serviceName}
                              </Text>
                              <Text style={styles.bookingDate}>{formatDate(occursAt)}</Text>
                            </View>
                          </View>
                          <View style={[styles.statusBadge, { backgroundColor: `${statusColor}20`, borderColor: `${statusColor}40` }]}>
                            <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
                            <Text style={[styles.statusText, { color: statusColor }]} numberOfLines={1}>
                              {formatStatusLabel(booking.status)}
                            </Text>
                          </View>

                          <View style={styles.bookingFooter}>
                            <View style={styles.bookingMeta}>
                              {address && (
                                <View style={styles.metaItem}>
                                  <Ionicons name="location-outline" size={14} color={VIBRANT_CYAN} />
                                  <Text style={[styles.metaText, { color: VIBRANT_CYAN }]} numberOfLines={1}>
                                    {address}
                                  </Text>
                                </View>
                              )}
                              <View style={styles.metaItem}>
                                <Ionicons name="time-outline" size={14} color={SKY} />
                                <Text style={[styles.metaText, { color: SKY }]}>
                                  {formatDate(occursAt)}
                                </Text>
                              </View>
                            </View>

                            <View style={styles.priceContainer}>
                              <Text style={styles.bookingPrice}>{formatCurrency(booking.price)}</Text>
                            </View>
                          </View>

                          {/* Dynamic CTA Button */}
                          <View style={styles.trackButtonRow}>
                            <Ionicons name="navigate" size={16} color={SKY} />
                            <Text style={styles.trackButtonText}>
                              {getDynamicCTAText(booking.status)}
                            </Text>
                            <Ionicons name="chevron-forward" size={16} color={SKY} />
                          </View>
                        </View>
                      </TouchableOpacity>
                    </Animated.View>
                  );
                })}
              </View>
            )}

            {washCompletions.length > 0 && (
              <View style={styles.sectionContainer}>
                <View style={styles.sectionHeader}>
                  <View style={styles.sectionIconWrapper}>
                    <LinearGradient colors={[VIBRANT_GREEN, VIBRANT_CYAN]} style={styles.sectionIconGradient}>
                      <Ionicons name="checkmark-circle" size={18} color="#FFFFFF" />
                    </LinearGradient>
                  </View>
                  <View>
                    <Text style={styles.sectionHeading}>
                      {activeBookings.length > 0 ? 'Completed Washes' : 'Wash History'}
                    </Text>
                    <Text style={styles.sectionSubtitle}>{washCompletions.length} completed</Text>
                  </View>
                </View>

                {washCompletions.map((completion, index) => {
                  const isHighlighted = highlightId === completion.id;
                  const serviceName = completion.serviceName ?? completion.service_type ?? 'Car Wash';
                  const price = completion.price ?? 0;
                  const valeterName = completion.valeterName;
                  const address = completion.address;

                  return (
                    <Animated.View
                      key={completion.id}
                      entering={FadeInDown.delay((activeBookings.length + index) * 80)}
                      style={[styles.bookingCard, isHighlighted && styles.highlightCard]}
                    >
                      <View style={styles.bookingContent}>
                        <View style={styles.bookingHeader}>
                          <View style={[styles.bookingIconWrapper, { backgroundColor: `${VIBRANT_GREEN}20` }]}>
                            <LinearGradient
                              colors={[VIBRANT_GREEN, VIBRANT_CYAN]}
                              style={styles.iconGradient}
                            >
                              <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                            </LinearGradient>
                          </View>

                          <View style={styles.bookingInfo}>
                            <Text style={styles.bookingService}>{serviceName}</Text>
                            <Text style={styles.bookingDate}>
                              {formatDate(completion.completedAt ?? completion.createdAt)}
                            </Text>
                          </View>

                          {completion.rating != null && (
                            <View style={[styles.ratingBadge, { backgroundColor: `${VIBRANT_YELLOW}20`, borderColor: `${VIBRANT_YELLOW}40` }]}>
                              <Ionicons name="star" size={14} color={VIBRANT_YELLOW} />
                              <Text style={[styles.ratingText, { color: VIBRANT_YELLOW }]}>{completion.rating}</Text>
                            </View>
                          )}
                        </View>

                        <View style={styles.bookingFooter}>
                          <View style={styles.bookingMeta}>
                            {valeterName && (
                              <View style={styles.metaItem}>
                                <Ionicons name="person-outline" size={14} color={VIBRANT_PURPLE} />
                                <Text style={[styles.metaText, { color: VIBRANT_PURPLE }]}>{valeterName}</Text>
                              </View>
                            )}
                            {address && (
                              <View style={styles.metaItem}>
                                <Ionicons name="location-outline" size={14} color={VIBRANT_CYAN} />
                                <Text style={[styles.metaText, { color: VIBRANT_CYAN }]} numberOfLines={1}>
                                  {address}
                                </Text>
                              </View>
                            )}
                          </View>

                          <View style={styles.priceContainer}>
                            <Text style={styles.bookingPrice}>{formatCurrency(price)}</Text>
                          </View>
                        </View>

                        <TouchableOpacity
                          style={styles.repeatButton}
                          onPress={() => handleRepeatBooking(completion)}
                          activeOpacity={0.8}
                        >
                          <LinearGradient
                            colors={[VIBRANT_GREEN, VIBRANT_CYAN]}
                            style={styles.repeatButtonGradient}
                          >
                            <Ionicons name="repeat" size={16} color="#FFFFFF" />
                            <Text style={styles.repeatButtonText}>Repeat Booking</Text>
                          </LinearGradient>
                        </TouchableOpacity>
                      </View>
                    </Animated.View>
                  );
                })}
              </View>
            )}
          </>
        )}
      </RNAnimated.ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? 12 : 20 },

  bookButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },

  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
  },
  emptyIconContainer: {
    marginBottom: 24,
  },
  emptyIconGradient: {
    width: 120,
    height: 120,
    borderRadius: 60,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 8,
    shadowColor: VIBRANT_CYAN,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
  },
  emptyTitle: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: '800',
    marginBottom: 8,
  },
  emptySubtitle: {
    color: LIGHT_SKY,
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 32,
    opacity: 0.9,
  },

  sectionContainer: {
    width: '100%',
    marginBottom: 24,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
    gap: 12,
  },
  sectionIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    overflow: 'hidden',
  },
  sectionIconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  sectionHeading: {
    color: '#FFFFFF',
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 2,
  },
  sectionSubtitle: {
    color: LIGHT_SKY,
    fontSize: 14,
    opacity: 0.8,
  },

  bookButtonCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  bookButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 8,
  },
  bookButtonText: {
    color: colors.LIGHT_SKY,
    fontSize: 16,
    fontWeight: '700',
  },

  bookingCard: {
    borderRadius: 20,
    marginBottom: 16,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 12,
    overflow: 'hidden',
  },
  activeCard: {
    borderColor: 'rgba(249, 115, 22, 0.4)',
    backgroundColor: 'rgba(249, 115, 22, 0.1)',
  },
  highlightCard: {
    borderColor: SKY,
    shadowColor: SKY,
    shadowOpacity: 0.5,
    shadowRadius: 16,
    borderWidth: 2,
  },

  bookingContent: { padding: 16 },
  bookingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  bookingIconWrapper: {
    width: 52,
    height: 52,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    overflow: 'hidden',
  },
  iconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  bookingInfo: { flex: 1 },
  bookingService: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  bookingDate: {
    color: LIGHT_SKY,
    fontSize: 13,
    fontWeight: '600',
    opacity: 0.9,
  },

  ratingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 12,
    gap: 4,
    borderWidth: 1,
  },
  ratingText: {
    fontSize: 13,
    fontWeight: '700',
  },

  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    borderWidth: 1,
    gap: 6,
    alignSelf: 'flex-start',
    marginBottom: 12,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '700',
  },

  bookingFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  bookingMeta: {
    flexDirection: 'row',
    gap: 12,
    flex: 1,
    paddingRight: 10,
  },
  metaItem: { flexDirection: 'row', alignItems: 'center', gap: 4, flex: 1 },
  metaText: {
    fontSize: 12,
    fontWeight: '600',
    flexShrink: 1,
  },
  priceContainer: {
    alignItems: 'flex-end',
  },
  bookingPrice: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '800',
  },
  trackButtonRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  trackButtonText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    flex: 1,
  },

  repeatButton: {
    borderRadius: 14,
    marginTop: 12,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: VIBRANT_GREEN,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  repeatButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  repeatButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
  },
});