// app/owner/owner-profile.tsx

import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Image,
  ActivityIndicator,
  TextInput,
  Alert,
  Animated,
  Modal,
  Switch,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import * as ImagePicker from 'expo-image-picker';
import { FileUploadService } from '../../src/services/FileUploadService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import { customerTheme } from '../../src/constants/customerTheme';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { colors } from '../../src/constants/colors';
import CarCareInfoHub from '../../src/components/car-care/CarCareInfoHub';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;
const LIGHT_SKY = colors.LIGHT_SKY;

interface Stats {
  totalBookings: number;
  totalSpent: number;
  averageRating: number;
  completedServices: number;
}

const CountUpNumber = ({
  value,
  prefix = '',
  suffix = '',
  decimals = 0,
  duration = 650,
  style,
}: {
  value: number;
  prefix?: string;
  suffix?: string;
  decimals?: number;
  duration?: number;
  style?: any;
}) => {
  const anim = useRef(new Animated.Value(0)).current;
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    anim.stopAnimation();
    anim.setValue(0);
    const listenerId = anim.addListener(({ value: v }) => setDisplay(v));
    Animated.timing(anim, { toValue: value, duration, useNativeDriver: false }).start(() => {
      anim.removeListener(listenerId);
      setDisplay(value);
    });
    return () => anim.removeListener(listenerId);
  }, [value]);

  const shown = useMemo(() => Number(display).toFixed(decimals), [display, decimals]);
  return <Text style={style}>{`${prefix}${shown}${suffix}`}</Text>;
};

const PROFILE_PIC_KEY = 'owner_profile_picture_uri';

const saveProfilePictureLocal = async (uri: string) => {
  await AsyncStorage.setItem(PROFILE_PIC_KEY, uri);
};

const loadProfilePictureLocal = async (): Promise<string | null> => {
  return AsyncStorage.getItem(PROFILE_PIC_KEY);
};

const clearProfilePictureLocal = async () => {
  await AsyncStorage.removeItem(PROFILE_PIC_KEY);
};


const uploadProfilePictureToSupabase = async (imageUri: string, userId: string) => {
  // Fetch file → blob
  const response = await fetch(imageUri);
  const blob = await response.blob();

  const filePath = `users/${userId}/profile_picture.jpg`;

  // Upload (overwrite each time)
  const { error: uploadError } = await supabase.storage
    .from('uploads')
    .upload(filePath, blob, {
      contentType: blob.type || 'image/jpeg',
      upsert: true,
    });

  if (uploadError) throw uploadError;

  // Get public URL
  const { data } = supabase.storage.from('uploads').getPublicUrl(filePath);
  if (!data?.publicUrl) throw new Error('Failed to get public URL');

  return data.publicUrl;
};


const cleanUrl = (u?: string | null) => {
  if (!u) return null;
  const s = String(u);
  return s.split('?')[0];
};

// ✅ Backwards-compatible mediaTypes for expo-image-picker
const getImagePickerMediaTypes = () => {
  const anyPicker: any = ImagePicker;
  if (anyPicker?.MediaType?.Images) return anyPicker.MediaType.Images;
  if (anyPicker?.MediaTypeOptions?.Images) return anyPicker.MediaTypeOptions.Images;
  return anyPicker?.MediaTypeOptions?.All ?? undefined;
};

// ✅ Resolve the actual avatar file in storage so we don’t assume profile_picture.jpg exists
const resolveAvatarUrl = async (userId: string): Promise<string | null> => {
  try {
    const folder = `users/${userId}`;

    const { data: files, error } = await supabase.storage
      .from('uploads')
      .list(folder, {
        limit: 50,
        offset: 0,
        // sortBy exists in newer supabase-js; safe to ignore if unsupported
        // @ts-ignore
        sortBy: { column: 'updated_at', order: 'desc' },
      } as any);

    if (error || !files || files.length === 0) return null;

    // Prefer profile_picture* if present, else newest file
    const preferred =
      (files as any[]).find((f) => String(f?.name || '').toLowerCase().startsWith('profile_picture')) ??
      (files as any[])[0];

    if (!preferred?.name) return null;

    const path = `${folder}/${preferred.name}`;

    const { data: publicData } = supabase.storage.from('uploads').getPublicUrl(path);
    const url = publicData?.publicUrl;

    if (!url) return null;

    return `${cleanUrl(url)}?v=${Date.now()}`;
  } catch {
    return null;
  }
};

export default function OwnerProfile() {
  const { user, logout, updateUser } = useAuth();

  const [profileName, setProfileName] = useState<string>('');
  const [profileEmail, setProfileEmail] = useState<string>('');
  const [profilePicture, setProfilePicture] = useState<string | null>(null); // local file:// or remote https://
  const [profilePictureUri, setProfilePictureUri] = useState<string | null>(null); // local file:// pending save (if needed)
  const [uploadingPicture, setUploadingPicture] = useState(false);

  const [loading, setLoading] = useState(true);
  const [loadingStats, setLoadingStats] = useState(true);

  const [isEditing, setIsEditing] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [showCarCareHub, setShowCarCareHub] = useState(false);

  const [stats, setStats] = useState<Stats>({
    totalBookings: 0,
    totalSpent: 0,
    averageRating: 0,
    completedServices: 0,
  });

  // Fallback + cache
  const lastPickedUriRef = useRef<string | null>(null);
  const savedPublicUrlRef = useRef<string | null>(null);
  const lastFailedUrlRef = useRef<string | null>(null);

  const loadProfile = async (userId: string) => {
    try {
      // 1️⃣ Load local picture FIRST
      const localPic = await loadProfilePictureLocal();
      if (localPic) {
        setProfilePicture(localPic);
      }

      // 2️⃣ Load profile data
      const { data: profileData, error } = await supabase
        .from('profiles')
        .select('full_name, profile_picture')
        .eq('id', userId)
        .maybeSingle();

      if (error) {
        console.warn('[profile] load error', error);
      }

      if (profileData) {
        setProfileName(profileData.full_name || user?.name || 'Customer');

        // 3️⃣ ONLY use Supabase image if NO local image exists
        if (!localPic && profileData.profile_picture) {
          const clean = cleanUrl(profileData.profile_picture);
          setProfilePicture(`${clean}?v=${Date.now()}`);
          savedPublicUrlRef.current = clean;
        }
      } else {
        setProfileName(user?.name || 'Customer');
      }

      setProfileEmail(user?.email || '');
    } catch (err) {
      console.error('[profile] load error', err);
    }
  };


  const loadStats = async (userId: string) => {
    setLoadingStats(true);
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('id, status, completed_at, price, discount_amount, tip_amount, rating')
        .eq('user_id', userId);

      if (error) throw error;

      const rows = data ?? [];
      const completed = rows.filter((b: any) => b?.status === 'completed' || b?.completed_at != null);

      const totalBookings = completed.length;
      const completedServices = completed.length;

      const totalSpent = completed.reduce((sum: number, b: any) => {
        const price = Number(b.price) || 0;
        const discount = Number(b.discount_amount) || 0;
        const tip = Number(b.tip_amount) || 0;
        const net = Math.max(0, price - discount + tip);
        return sum + net;
      }, 0);

      const ratings = completed
        .map((b: any) => Number(b.rating))
        .filter((n: number) => Number.isFinite(n) && n >= 1 && n <= 5);

      const averageRating =
        ratings.length > 0 ? ratings.reduce((a: number, b: number) => a + b, 0) / ratings.length : 0;

      setStats({
        totalBookings,
        totalSpent,
        averageRating,
        completedServices,
      });
    } catch (error) {
      console.error('Error loading stats:', error);
      setStats({
        totalBookings: 0,
        totalSpent: 0,
        averageRating: 0,
        completedServices: 0,
      });
    } finally {
      setLoadingStats(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;

    const loadAll = async () => {
      setLoading(true);
      try {
        await loadProfile(user.id);
        await loadStats(user.id);
      } finally {
        setLoading(false);
      }
    };

    loadAll();
  }, [user?.id]);

  const handlePickImage = async () => {
    try {
      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permission needed', 'Please allow photo library access.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: getImagePickerMediaTypes(),
        allowsEditing: true,
        aspect: [1, 1],
        quality: 0.8,
      } as any);

      if ((result as any).canceled || !(result as any).assets?.[0]?.uri) return;

      const imageUri = (result as any).assets[0].uri as string;

      // Save locally
      await saveProfilePictureLocal(imageUri);

      // Update UI immediately
      setProfilePicture(imageUri);
      setProfilePictureUri(null);
    } catch (err: any) {
      console.error('[profile] local image error', err);
      Alert.alert('Error', 'Failed to pick image');
    }
  };


  const handleSaveProfile = async () => {
    if (!user?.id) return;

    try {
      setIsSaving(true);

      let avatarUrlClean = savedPublicUrlRef.current ?? cleanUrl(profilePicture);

      // If there is a local image URI still pending, upload + persist it (belt & braces)
      if (profilePictureUri && profilePictureUri.startsWith('file://')) {
        setUploadingPicture(true);

        const uploadService = FileUploadService.getInstance();
        const uploadResult = await uploadService.uploadProfilePicture(profilePictureUri, user.id);

        if (!uploadResult.success) {
          Alert.alert('Upload Failed', uploadResult.error || 'Failed to upload profile picture. Please try again.');
          setUploadingPicture(false);
          return;
        }

        const resolved = await resolveAvatarUrl(user.id);
        if (resolved) {
          avatarUrlClean = cleanUrl(resolved);
          savedPublicUrlRef.current = avatarUrlClean;
          setProfilePicture(`${avatarUrlClean}?v=${Date.now()}`);
          setProfilePictureUri(null);
        }

        setUploadingPicture(false);
      }

      // Update profile in profiles table (name + profile_picture)
      const updateData: { full_name: string; profile_picture?: string | null } = { 
        full_name: profileName,
      };
      if (avatarUrlClean && avatarUrlClean.startsWith('http')) updateData.profile_picture = avatarUrlClean;

      const { error: profileError } = await supabase.from('profiles').update(updateData).eq('id', user.id);
      if (profileError) throw profileError;

      // Update email if changed (requires auth update)
      if (profileEmail !== user.email) {
        const { error: emailError } = await supabase.auth.updateUser({ email: profileEmail });
        if (emailError) {
          Alert.alert('Email Update', 'Email verification sent to new email address. Please check your inbox.', [{ text: 'OK' }]);
        }
      }

      // Update user context
      if (updateUser) {
        await updateUser({ name: profileName, email: profileEmail });
      }

      setIsEditing(false);
      Alert.alert('Success', 'Profile updated successfully!');
    } catch (error: any) {
      console.error('Error saving profile:', error);
      Alert.alert('Error', error?.message || 'Failed to save profile');
    } finally {
      setIsSaving(false);
      setUploadingPicture(false);
    }
  };

  const handleCancel = async () => {
    setProfileName(user?.name || '');
    setProfileEmail(user?.email || '');
    setIsEditing(false);

    // Reload from DB/storage to restore saved avatar/name/cab driver status
    if (user?.id) {
      await loadProfile(user.id);
    }
  };

  const handleLogout = async () => {
    await logout();
    router.replace('/auth/login');
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Profile"
        rightAction={
          <TouchableOpacity
            onPress={() => {
              if (isEditing) handleCancel();
              else setIsEditing(true);
            }}
            style={styles.editButton}
          >
            <Text style={styles.editButtonText}>{isEditing ? 'Cancel' : 'Edit'}</Text>
          </TouchableOpacity>
        }
        profilePicture={profilePicture}
        onProfilePress={() => {
          // Scroll to profile picture section or trigger edit
          if (!isEditing) {
            setIsEditing(true);
          }
        }}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
      >
        {/* Profile Picture Section */}
        <View style={styles.profileSection}>
          <TouchableOpacity
            onPress={handlePickImage}
            style={styles.profilePictureContainer}
            disabled={uploadingPicture}
            activeOpacity={0.85}
          >
            {uploadingPicture ? (
              <View style={styles.profilePicturePlaceholder}>
                <ActivityIndicator size="large" color={SKY} />
              </View>
            ) : profilePicture ? (
              <Image
                source={{ uri: profilePicture }}
                style={[styles.profilePicture, uploadingPicture && { opacity: 0.6 }]}
                onError={async (e) => {
                  // Don't spam log for the same URL
                  if (lastFailedUrlRef.current !== profilePicture) {
                    lastFailedUrlRef.current = profilePicture;
                    console.warn('[profile] avatar image failed to load:', profilePicture, e?.nativeEvent);
                  }

                  // If remote fails, fall back to last picked local image
                  if (lastPickedUriRef.current) {
                    setProfilePicture(lastPickedUriRef.current);
                    return;
                  }

                  // Try resolve from storage (actual filename/path)
                  if (user?.id) {
                    const resolved = await resolveAvatarUrl(user.id);
                    if (resolved) {
                      setProfilePicture(resolved);
                      return;
                    }
                  }

                  setProfilePicture(null);
                }}
              />
            ) : (
              <View style={styles.profilePicturePlaceholder}>
                <Ionicons name="person" size={48} color={SKY} />
              </View>
            )}

            {!uploadingPicture && (
              <View style={styles.editBadge}>
                <Ionicons name="camera" size={14} color={BG} />
              </View>
            )}
          </TouchableOpacity>

          {isEditing ? (
            <>
              <TextInput
              style={styles.profileNameInput}
              value={profileName}
              onChangeText={setProfileName}
              placeholder="Enter your name"
              placeholderTextColor="#64748B"
            />
              <TextInput
                style={styles.profileEmailInput}
                value={profileEmail}
                onChangeText={setProfileEmail}
                placeholder="Enter your email"
                placeholderTextColor="#64748B"
                keyboardType="email-address"
                autoCapitalize="none"
              />
            </>
          ) : (
            <>
              <Text style={styles.profileName}>{profileName}</Text>
              <Text style={styles.profileEmail}>{profileEmail}</Text>
            </>
          )}
        </View>

        {/* Stats Overview */}
        <View style={styles.statsSection}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <Text style={styles.sectionTitle}>Overview</Text>
            {loadingStats && <ActivityIndicator size="small" color={SKY} />}
          </View>

          <View style={styles.statsGrid}>
            <View style={styles.statCard}>
              <View style={styles.statCardContent}>
                <View style={styles.statIconWrapper}>
                  <Ionicons name="calendar" size={22} color={SKY} />
                </View>
                <View style={styles.statTextContainer}>
                  <CountUpNumber value={stats.totalBookings} style={styles.statNumber} />
                  <Text style={styles.statLabel}>Completed Bookings</Text>
                </View>
              </View>
            </View>

            <View style={styles.statCard}>
              <View style={styles.statCardContent}>
                <View style={styles.statIconWrapper}>
                  <Ionicons name="wallet" size={22} color={SKY} />
                </View>
                <View style={styles.statTextContainer}>
                  <CountUpNumber value={stats.totalSpent} prefix="£" decimals={0} style={styles.statNumber} />
                  <Text style={styles.statLabel}>Total Spent</Text>
                </View>
              </View>
            </View>

            <View style={styles.statCard}>
              <View style={styles.statCardContent}>
                <View style={[styles.statIconWrapper, styles.statIconWrapperGold]}>
                  <Ionicons name="star" size={22} color="#F59E0B" />
                </View>
                <View style={styles.statTextContainer}>
                  <CountUpNumber value={stats.averageRating} decimals={1} style={styles.statNumber} />
                  <Text style={styles.statLabel}>Avg Rating</Text>
                </View>
              </View>
            </View>

            <View style={styles.statCard}>
              <View style={styles.statCardContent}>
                <View style={[styles.statIconWrapper, styles.statIconWrapperGreen]}>
                  <Ionicons name="checkmark-circle" size={22} color="#10B981" />
                </View>
                <View style={styles.statTextContainer}>
                  <CountUpNumber value={stats.completedServices} style={styles.statNumber} />
                  <Text style={styles.statLabel}>Completed</Text>
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* Analytics Section */}
        <View style={styles.analyticsSection}>
          <View style={styles.analyticsHeader}>
            <Text style={styles.sectionTitle}>Analytics</Text>
          </View>

          <View style={styles.analyticsCard}>
            <View style={styles.analyticsCardContent}>
              <View style={styles.analyticsIconWrapper}>
                <Ionicons name="analytics" size={24} color={SKY} />
              </View>
              <View style={styles.analyticsContent}>
                <Text style={styles.analyticsTitle}>Your Activity</Text>
                <Text style={styles.analyticsSubtitle}>Stats based on completed bookings</Text>

                <View style={styles.analyticsStatsRow}>
                  <View style={styles.analyticsStatItem}>
                    <Text style={styles.analyticsStatValue}>{stats.completedServices}</Text>
                    <Text style={styles.analyticsStatLabel}>Completed</Text>
                  </View>
                  <View style={styles.analyticsDivider} />
                  <View style={styles.analyticsStatItem}>
                    <Text style={styles.analyticsStatValue}>£{stats.totalSpent.toFixed(0)}</Text>
                    <Text style={styles.analyticsStatLabel}>Total Spent</Text>
                  </View>
                  <View style={styles.analyticsDivider} />
                  <View style={styles.analyticsStatItem}>
                    <Text style={styles.analyticsStatValue}>{stats.averageRating.toFixed(1)}</Text>
                    <Text style={styles.analyticsStatLabel}>Avg Rating</Text>
                  </View>
                </View>

                <View style={styles.analyticsProgressContainer}>
                  <View style={styles.analyticsProgressHeader}>
                    <Text style={styles.analyticsProgressLabel}>Completion Rate</Text>
                    <Text style={styles.analyticsProgressValue}>100%</Text>
                  </View>
                  <View style={styles.analyticsProgressBar}>
                    <View style={[styles.analyticsProgressFill, { width: '100%' }]} />
                  </View>
                </View>
              </View>
            </View>
          </View>
        </View>

        {/* Menu Items (payment methods removed) */}
        <View style={styles.menuSection}>
          <TouchableOpacity style={styles.menuItem} onPress={() => router.push('/owner/settings/vehicle-management')}>
            <View style={styles.menuIconWrapper}>
              <Ionicons name="car" size={18} color={SKY} />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>My Vehicles</Text>
              <Text style={styles.menuSubtitle}>Manage your vehicles</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={SKY} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.menuItem} onPress={() => router.push('/owner/settings/privacy-settings')}>
            <View style={styles.menuIconWrapper}>
              <Ionicons name="lock-closed" size={18} color={SKY} />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>Privacy Settings</Text>
              <Text style={styles.menuSubtitle}>Control your privacy</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={SKY} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.menuItem} onPress={() => router.push('/owner/support/help-support')}>
            <View style={styles.menuIconWrapper}>
              <Ionicons name="help-circle" size={18} color={SKY} />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>Help & Support</Text>
              <Text style={styles.menuSubtitle}>Get assistance</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={SKY} />
          </TouchableOpacity>

          <TouchableOpacity style={styles.menuItem} onPress={() => setShowCarCareHub(true)}>
            <View style={styles.menuIconWrapper}>
              <Ionicons name="information-circle" size={18} color={SKY} />
            </View>
            <View style={styles.menuContent}>
              <Text style={styles.menuTitle}>Car Care Hub</Text>
              <Text style={styles.menuSubtitle}>Tips, locations & reminders</Text>
            </View>
            <Ionicons name="chevron-forward" size={18} color={SKY} />
          </TouchableOpacity>

        </View>

        {/* Save Button */}
        {isEditing && (
          <TouchableOpacity style={styles.saveButton} onPress={handleSaveProfile} disabled={isSaving}>
            <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.saveGradient}>
              {isSaving ? (
                <ActivityIndicator size="small" color={LIGHT_SKY} />
              ) : (
                <>
                  <Ionicons name="checkmark" size={18} color={LIGHT_SKY} />
                  <Text style={styles.saveText}>Save Changes</Text>
                </>
              )}
            </LinearGradient>
          </TouchableOpacity>
        )}

        {/* Logout Button */}
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <LinearGradient colors={['#EF4444', '#DC2626']} style={styles.logoutGradient}>
            <Ionicons name="log-out" size={18} color={LIGHT_SKY} />
            <Text style={styles.logoutText}>Log Out</Text>
          </LinearGradient>
        </TouchableOpacity>
      </ScrollView>

      <Modal visible={showCarCareHub} animationType="slide" presentationStyle="fullScreen">
        <CarCareInfoHub userType="customer" onClose={() => setShowCarCareHub(false)} />
      </Modal>
    </SafeAreaView>
  );
}

// styles
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center' },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? 12 : 20 },

  editButton: {
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  editButtonText: { color: '#60A5FA', fontSize: 14, fontWeight: '600' },

  profileSection: { alignItems: 'center', marginBottom: 32, marginTop: 20 },
  profilePictureContainer: { position: 'relative', marginBottom: 16 },
  profilePicture: { width: 100, height: 100, borderRadius: 50, borderWidth: 2.5, borderColor: SKY },
  profilePicturePlaceholder: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2.5,
    borderColor: SKY,
  },
  editBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2.5,
    borderColor: BG,
  },

  profileName: { color: colors.LIGHT_SKY, fontSize: isSmallScreen ? 20 : 22, fontWeight: 'bold', marginBottom: 6 },
  profileEmail: { color: colors.LIGHT_SKY, fontSize: isSmallScreen ? 12 : 14, fontWeight: '600' },

  profileNameInput: {
    color: colors.LIGHT_SKY,
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'center',
    borderBottomWidth: 1,
    borderBottomColor: SKY,
    paddingBottom: 4,
    minWidth: 200,
  },
  profileEmailInput: {
    color: colors.LIGHT_SKY,
    fontSize: isSmallScreen ? 14 : 16,
    fontWeight: '600',
    textAlign: 'center',
    borderBottomWidth: 1,
    borderBottomColor: colors.LIGHT_SKY,
    paddingBottom: 4,
    minWidth: 200,
  },

  saveButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 10,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  saveGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 12, gap: 8 },
  saveText: { color: LIGHT_SKY, fontSize: isSmallScreen ? 14 : 15, fontWeight: '700' },

  menuSection: { marginBottom: 32, gap: 12 },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    padding: 12,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    elevation: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.15,
    shadowRadius: 3,
  },

  menuIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  menuContent: { flex: 1 },
  menuTitle: { color: colors.LIGHT_SKY, fontSize: isSmallScreen ? 14 : 15, fontWeight: '700', marginBottom: 2 },
  menuSubtitle: { color: SKY, fontSize: 11, fontWeight: '600' },

  logoutButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
    elevation: 3,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  logoutGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 12, gap: 8 },
  logoutText: { color: LIGHT_SKY, fontSize: isSmallScreen ? 14 : 15, fontWeight: '700' },

  statsSection: { marginBottom: 32 },
  sectionTitle: { color: colors.LIGHT_SKY, fontSize: isSmallScreen ? 18 : 20, fontWeight: 'bold', marginBottom: 16 },

  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between', gap: 12 },
  statCard: {
    width: (width - (isSmallScreen ? 36 : 40)) / 2 - 6,
    borderRadius: 18,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  statCardContent: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12 },
  statIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  statIconWrapperGold: { backgroundColor: 'rgba(245,158,11,0.15)', borderColor: 'rgba(245,158,11,0.3)' },
  statIconWrapperGreen: { backgroundColor: 'rgba(16,185,129,0.15)', borderColor: 'rgba(16,185,129,0.3)' },
  statTextContainer: { flex: 1 },
  statNumber: { fontSize: isSmallScreen ? 20 : 22, fontWeight: '800', color: colors.LIGHT_SKY, marginBottom: 2, letterSpacing: -0.3 },
  statLabel: { fontSize: 11, color: SKY, fontWeight: '600', letterSpacing: 0.2 },

  analyticsSection: { marginBottom: 32 },
  analyticsHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 },
  analyticsCard: {
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    overflow: 'hidden',
  },
  analyticsCardContent: { flexDirection: 'row', padding: 18, gap: 16 },
  analyticsIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  analyticsContent: { flex: 1 },
  analyticsTitle: { fontSize: 18, fontWeight: '700', color: colors.LIGHT_SKY, marginBottom: 4, letterSpacing: -0.3 },
  analyticsSubtitle: { fontSize: 12, color: SKY, marginBottom: 16, opacity: 0.8 },

  analyticsStatsRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  analyticsStatItem: { flex: 1, alignItems: 'center' },
  analyticsStatValue: { fontSize: 20, fontWeight: '800', color: colors.LIGHT_SKY, marginBottom: 4, letterSpacing: -0.3 },
  analyticsStatLabel: { fontSize: 10, color: SKY, fontWeight: '600', opacity: 0.8 },
  analyticsDivider: { width: 1, height: 32, backgroundColor: 'rgba(135,206,235,0.2)', marginHorizontal: 8 },

  analyticsProgressContainer: { marginTop: 4 },
  analyticsProgressHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 },
  analyticsProgressLabel: { fontSize: 12, color: SKY, fontWeight: '600' },
  analyticsProgressValue: { fontSize: 14, fontWeight: '700', color: colors.LIGHT_SKY },
  analyticsProgressBar: { height: 8, borderRadius: 4, backgroundColor: 'rgba(255,255,255,0.1)', overflow: 'hidden' },
  analyticsProgressFill: { height: '100%', borderRadius: 4, backgroundColor: SKY },

});
