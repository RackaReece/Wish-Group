import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import { useProfilePicture } from '../../src/hooks/useProfilePicture';
import { customerTheme } from '../../src/constants/customerTheme';
import { colors } from '../../src/constants/colors';
import { getServiceDisplayName } from '../../src/utils/serviceNameMapper';
import Animated, { FadeInDown } from 'react-native-reanimated';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY;

const ACTIVE_STATUSES = [
  'pending',
  'pending_valeter_acceptance',
  'pending_payment',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
  'in_progress',
  'scheduled',
];

type ActiveBooking = {
  id: string;
  status: string;
  service_type: string;
  service_name?: string | null;
  price: number | null;
  location_address?: string | null;
  scheduled_at?: string | null;
  valeter_name?: string | null;
  created_at?: string | null;
};

const getStatusColor = (status: string): string => {
  switch (status) {
    case 'en_route':
    case 'arrived':
      return '#10B981'; // Green
    case 'in_progress':
      return '#60A5FA'; // Blue
    case 'valeter_assigned':
    case 'confirmed':
      return '#8B5CF6'; // Purple
    case 'pending_valeter_acceptance':
    case 'pending':
      return '#F59E0B'; // Amber
    default:
      return SKY;
  }
};

const getDynamicCTAText = (status: string): string => {
  switch (status) {
    case 'pending_valeter_acceptance':
    case 'pending':
      return 'View Request Status';
    case 'confirmed':
    case 'valeter_assigned':
      return 'View Live Tracking';
    case 'en_route':
      return 'Track Valeter';
    case 'in_progress':
    case 'arrived':
      return 'Live Progress';
    case 'completed':
      return 'View Receipt + Tip';
    case 'pending_payment':
      return 'Pay Now';
    default:
      return 'View Live Tracking';
  }
};

const getStatusLabel = (status: string): string => {
  switch (status) {
    case 'en_route':
      return 'Valeter En Route';
    case 'arrived':
      return 'Valeter Arrived';
    case 'in_progress':
      return 'In Progress';
    case 'valeter_assigned':
      return 'Valeter Assigned';
    case 'confirmed':
      return 'Confirmed';
    case 'pending_valeter_acceptance':
      return 'Waiting for Valeter';
    case 'pending':
      return 'Pending';
    case 'scheduled':
      return 'Scheduled';
    default:
      return status.replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase());
  }
};

export default function CustomerTrackPage() {
  const { user } = useAuth();
  const profilePicture = useProfilePicture();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeBookings, setActiveBookings] = useState<ActiveBooking[]>([]);

  const loadActiveBookings = async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(
          `id,
          status,
          service_type,
          service_name,
          price,
          location_address,
          scheduled_at,
          valeter_name,
          created_at`
        )
        .eq('user_id', user.id)
        .in('status', ACTIVE_STATUSES as any)
        .order('created_at', { ascending: false });

      if (error) throw error;

      setActiveBookings((data || []) as ActiveBooking[]);
    } catch (error) {
      console.error('Error loading active bookings:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadActiveBookings();

    // Subscribe to booking updates
    const channel = supabase
      .channel('customer-active-bookings')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'bookings',
          filter: `user_id=eq.${user?.id}`,
        },
        () => {
          loadActiveBookings();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await loadActiveBookings();
  };

  const formatCurrency = (n?: number | null) =>
    typeof n === 'number' ? `£${n.toFixed(2).replace(/\.00$/, '')}` : '—';

  const formatDate = (dateString?: string | null) => {
    if (!dateString) return '—';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader 
          title="Track Bookings" 
          accountType="customer"
          profilePicture={profilePicture}
          onProfilePress={() => router.push('/owner/owner-profile')}
        />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
      <AppHeader title="Track Bookings" accountType="customer" />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={handleRefresh} tintColor={SKY} />}
      >
        {activeBookings.length === 0 ? (
          <View style={styles.emptyContainer}>
            <View style={styles.emptyIconContainer}>
              <Ionicons name="navigate-outline" size={64} color={SKY} />
            </View>
            <Text style={styles.emptyTitle}>No Active Bookings</Text>
            <Text style={styles.emptySubtitle}>You don't have any bookings to track right now</Text>
            <TouchableOpacity
              style={styles.bookButton}
              onPress={() => router.push('/owner/booking')}
              activeOpacity={0.8}
            >
              <LinearGradient
                colors={[SKY, LIGHT_SKY]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={styles.bookButtonGradient}
              >
                <Ionicons name="calendar-outline" size={20} color="#FFFFFF" />
                <Text style={styles.bookButtonText}>Book a Wash</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        ) : (
          <>
            <View style={styles.headerSection}>
              <Text style={styles.sectionTitle}>Active Bookings</Text>
              <Text style={styles.sectionSubtitle}>{activeBookings.length} booking{activeBookings.length !== 1 ? 's' : ''} in progress</Text>
            </View>

            {activeBookings.map((booking, index) => {
              const statusColor = getStatusColor(booking.status);
              const statusLabel = getStatusLabel(booking.status);

              return (
                <Animated.View
                  key={booking.id}
                  entering={FadeInDown.delay(index * 100)}
                  style={styles.bookingCard}
                >
                  <TouchableOpacity
                    activeOpacity={0.8}
                    onPress={() => router.push(`/owner/booking/tracking?bookingId=${booking.id}`)}
                  >
                    <View style={styles.cardHeader}>
                      <View style={styles.serviceInfo}>
                        <Ionicons name="car-outline" size={20} color={SKY} />
                        <Text style={styles.serviceName}>
                          {getServiceDisplayName(booking.service_type, booking.service_name)}
                        </Text>
                      </View>
                      <View style={[styles.statusBadge, { backgroundColor: `${statusColor}20` }]}>
                        <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
                        <Text style={[styles.statusText, { color: statusColor }]}>{statusLabel}</Text>
                      </View>
                    </View>

                    {booking.location_address && (
                      <View style={styles.infoRow}>
                        <Ionicons name="location-outline" size={16} color={LIGHT_SKY} />
                        <Text style={styles.infoText} numberOfLines={2}>
                          {booking.location_address}
                        </Text>
                      </View>
                    )}

                    <View style={styles.cardFooter}>
                      <View style={styles.footerItem}>
                        <Ionicons name="time-outline" size={16} color={LIGHT_SKY} />
                        <Text style={styles.footerText}>{formatDate(booking.scheduled_at || booking.created_at)}</Text>
                      </View>
                      <View style={styles.footerItem}>
                        <Ionicons name="wallet-outline" size={16} color={LIGHT_SKY} />
                        <Text style={styles.footerText}>{formatCurrency(booking.price)}</Text>
                      </View>
                      {booking.valeter_name && (
                        <View style={styles.footerItem}>
                          <Ionicons name="person-outline" size={16} color={LIGHT_SKY} />
                          <Text style={styles.footerText} numberOfLines={1}>
                            {booking.valeter_name}
                          </Text>
                        </View>
                      )}
                    </View>

                    <View style={styles.trackButton}>
                      <Ionicons name="navigate" size={18} color={SKY} />
                      <Text style={styles.trackButtonText}>
                        {getDynamicCTAText(booking.status)}
                      </Text>
                      <Ionicons name="chevron-forward" size={18} color={SKY} />
                    </View>
                  </TouchableOpacity>
                </Animated.View>
              );
            })}
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: HEADER_CONTENT_OFFSET,
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 120,
    paddingHorizontal: 20,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
  },
  emptyIconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(135, 206, 235, 0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
  },
  emptyTitle: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: '800',
    marginBottom: 8,
  },
  emptySubtitle: {
    color: LIGHT_SKY,
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 32,
    opacity: 0.9,
  },
  bookButton: {
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
  },
  bookButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    gap: 10,
  },
  bookButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
  headerSection: {
    marginBottom: 20,
    marginTop: 8,
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 28,
    fontWeight: '800',
    marginBottom: 4,
  },
  sectionSubtitle: {
    color: LIGHT_SKY,
    fontSize: 15,
    opacity: 0.9,
  },
  bookingCard: {
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.2)',
    marginBottom: 16,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: 16,
    paddingBottom: 12,
  },
  serviceInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    flex: 1,
  },
  serviceName: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '700',
    flex: 1,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    gap: 6,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusText: {
    fontSize: 12,
    fontWeight: '700',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingHorizontal: 16,
    paddingBottom: 12,
    gap: 8,
  },
  infoText: {
    color: LIGHT_SKY,
    fontSize: 14,
    flex: 1,
    opacity: 0.9,
  },
  cardFooter: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    paddingHorizontal: 16,
    paddingBottom: 12,
    gap: 16,
  },
  footerItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  footerText: {
    color: LIGHT_SKY,
    fontSize: 13,
    opacity: 0.8,
  },
  trackButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135, 206, 235, 0.15)',
    gap: 8,
    backgroundColor: 'rgba(135, 206, 235, 0.05)',
  },
  trackButtonText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
    flex: 1,
    textAlign: 'center',
  },
});
