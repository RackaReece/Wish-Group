import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Dimensions,
  Animated,
  Alert,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Region, Marker, Circle } from 'react-native-maps';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Location from 'expo-location';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../app/components/NavigationTab';
import SuccessOverlay from '../../../src/components/booking/SuccessOverlay';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function WaitingAcceptance() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;

  const [booking, setBooking] = useState<any | null>(null);
  const [valeter, setValeter] = useState<any | null>(null);
  const [valeterLocation, setValeterLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [valeterLocationOffset, setValeterLocationOffset] = useState<{ latOffset: number; lngOffset: number } | null>(null);
  const [countdown, setCountdown] = useState(300); // 5 minutes
  const [status, setStatus] = useState<'pending_valeter_acceptance' | 'pending_payment' | 'confirmed'>('pending_valeter_acceptance');
  const [showAcceptedOverlay, setShowAcceptedOverlay] = useState(false);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const timeProgressAnim = useRef(new Animated.Value(1)).current;
  const messageSlideAnim = useRef(new Animated.Value(0)).current; // Start visible (0 = opacity 1)

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();


    loadBooking();
    subscribeToBooking();
    getCurrentLocation();
  }, [bookingId]);

  // Rotate messages every 3 seconds
  useEffect(() => {
    const messages = [
      'Valeter received your request',
      'They have 5 minutes to respond',
      'You\'ll pay once they accept',
    ];

    const interval = setInterval(() => {
      // Fade out
      Animated.timing(messageSlideAnim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start(() => {
        // Change message
        setCurrentMessageIndex((prev) => (prev + 1) % messages.length);
        // Fade in - animate from 1 to 0 (which makes opacity go from 0 to 1)
        messageSlideAnim.setValue(1);
        Animated.timing(messageSlideAnim, {
          toValue: 0,
          duration: 300,
          useNativeDriver: true,
        }).start();
      });
    }, 3000);

    return () => clearInterval(interval);
  }, []);

  // Timer countdown effect
  useEffect(() => {
    if (countdown <= 0) {
      handleCountdownComplete();
      return;
    }

    const timer = setInterval(() => {
      setCountdown(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          handleCountdownComplete();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [countdown]);

  // Update time progress animation
  useEffect(() => {
    const progress = countdown / 300; // 300 seconds = 5 minutes
    Animated.timing(timeProgressAnim, {
      toValue: progress,
      duration: 1000,
      useNativeDriver: false,
    }).start();
  }, [countdown]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.warn('Location permission not granted');
        return;
      }

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };

      setUserLocation(coords);
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    } catch (error) {
      console.warn('Error getting location:', error);
    }
  };

  const loadBooking = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', bookingId)
        .single();

      if (error) throw error;
      setBooking(data);
      setStatus(data.status);

      if (data?.valeter_id) {
        // Load valeter profile
        const { data: valeterProfile, error: valeterError } = await supabase
          .from('valeter_profiles')
          .select('full_name, profile_photo_url, company_name')
          .eq('user_id', data.valeter_id)
          .maybeSingle();

        if (!valeterError && valeterProfile) {
          setValeter(valeterProfile);
        } else {
          setValeter(null);
        }

        // Load valeter location from presence
        const { data: presenceData, error: presenceError } = await supabase
          .from('valeter_presence')
          .select('last_lat, last_lng')
          .eq('user_id', data.valeter_id)
          .maybeSingle();

        if (!presenceError && presenceData?.last_lat && presenceData?.last_lng) {
          const valeterCoords = {
            latitude: Number(presenceData.last_lat),
            longitude: Number(presenceData.last_lng),
          };
          setValeterLocation(valeterCoords);
          
          // Generate random offset once to blur exact location (within ~100m)
          const latOffset = (Math.random() - 0.5) * 0.001;
          const lngOffset = (Math.random() - 0.5) * 0.001;
          setValeterLocationOffset({ latOffset, lngOffset });
          
          // Zoom to valeter location (blurred - wider view)
          setRegion({
            latitude: valeterCoords.latitude,
            longitude: valeterCoords.longitude,
            latitudeDelta: 0.05, // Wider view to blur exact location
            longitudeDelta: 0.05,
          });
        }
      } else {
        setValeter(null);
        setValeterLocation(null);
      }
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const subscribeToBooking = () => {
    const channel = supabase
      .channel(`booking-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        async (payload) => {
          const updated = payload.new as any;
          setStatus(updated.status);
          
          if (updated.status === 'pending_payment') {
            // Show success overlay when booking is accepted
            setShowAcceptedOverlay(true);
            hapticFeedback('success');
            
            // Navigate to payment after overlay
            setTimeout(() => {
              router.replace({
                pathname: '/owner/booking/payment',
                params: { bookingId },
              });
            }, 2000);
          } else if (updated.status === 'confirmed' || updated.status === 'valeter_assigned' || updated.status === 'en_route' || updated.status === 'in_progress' || updated.status === 'scheduled') {
            // Redirect to dashboard when booking is accepted
            router.replace('/owner/owner-dashboard');
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleCountdownComplete = () => {
    // Timeout - valeter didn't accept
    Alert.alert(
      'Request Expired',
      'The valeter didn\'t respond in time. Would you like to select another valeter?',
      [
        { text: 'Cancel', style: 'cancel', onPress: () => router.back() },
        { text: 'Select Another', onPress: () => router.back() },
      ]
    );
  };

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return {
      minutes: mins.toString().padStart(2, '0'),
      seconds: secs.toString().padStart(2, '0'),
    };
  };

  const timeDisplay = formatTime(countdown);
  const isUrgent = countdown <= 60; // Red when under 1 minute

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image 
                  source={require('../../../assets/washing.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {/* Valeter location marker with blur effect (approximate location) */}
          {valeterLocation && valeterLocationOffset && (
            <>
              {/* Blur circle overlay to hide exact location */}
              <Circle
                center={{
                  latitude: valeterLocation.latitude,
                  longitude: valeterLocation.longitude,
                }}
                radius={150} // ~150m radius blur
                fillColor="rgba(15, 23, 42, 0.4)"
                strokeColor="rgba(135,206,235,0.2)"
                strokeWidth={1}
              />
              <Marker 
                coordinate={{
                  // Use stored offset to blur exact location (within ~100m)
                  latitude: valeterLocation.latitude + valeterLocationOffset.latOffset,
                  longitude: valeterLocation.longitude + valeterLocationOffset.lngOffset,
                }}
              >
                <View style={styles.valeterMarkerContainer}>
                  <View style={styles.valeterMarkerBlur}>
                    <Image 
                      source={require('../../../assets/cleaning.png')} 
                      style={styles.valeterMarker}
                      resizeMode="contain"
                    />
                  </View>
                </View>
              </Marker>
            </>
          )}
        </MapView>
      </View>

      {/* Enhanced Status Card at top */}
      {countdown > 0 && (
        <View style={[styles.statusCardContainer, { top: insets.top + 68 }]}>
          <BlurView intensity={80} style={styles.statusCardBlur}>
            <View style={styles.statusCardContent}>
              <View style={styles.statusCardHeader}>
                <View style={styles.statusCardHeaderLeft}>
                  <View style={[styles.statusIndicator, isUrgent && styles.statusIndicatorUrgent]}>
                    <Ionicons name="time" size={16} color={isUrgent ? '#EF4444' : SKY} />
                  </View>
                  <View>
                    <Text style={styles.statusCardTitle}>Waiting for Acceptance</Text>
                    <Text style={styles.statusCardSubtitle}>
                      {valeter ? `Connecting to ${valeter.full_name || 'Valeter'}` : 'Valeter is reviewing your request'}
                    </Text>
                  </View>
                </View>
                <View style={[styles.timerBadge, isUrgent && styles.timerBadgeUrgent]}>
                  <Text style={[styles.timerBadgeText, isUrgent && styles.timerBadgeTextUrgent]}>
                    {timeDisplay.minutes}:{timeDisplay.seconds}
                  </Text>
                </View>
              </View>
              
              <View style={styles.progressBarContainer}>
                <View style={styles.progressBarBackground}>
                  <Animated.View 
                    style={[
                      styles.progressBarFill,
                      isUrgent && styles.progressBarFillUrgent,
                      {
                        width: timeProgressAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: ['0%', '100%'],
                        }),
                      },
                    ]}
                  />
                </View>
                <Text style={styles.progressBarLabel}>
                  {Math.round((countdown / 300) * 100)}% time remaining
                </Text>
              </View>
            </View>
          </BlurView>
        </View>
      )}

      {/* Header floating over the map */}
      <AppHeader 
        title="Booking Request" 
        subtitle="Waiting for valeter response" 
      />

      {/* Enhanced Message Card at Bottom */}
      <Animated.View
        style={[
          styles.messageCardContainer,
          {
            opacity: fadeAnim,
            bottom: Math.max(insets.bottom, 20) + TAB_BAR_TOTAL_HEIGHT + 12,
          },
        ]}
      >
        <BlurView intensity={90} style={styles.messageCardBlur}>
          <View style={styles.messageCardContent}>
            <Animated.View 
              style={[
                styles.messageContent,
                {
                  opacity: messageSlideAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [1, 0],
                  }),
                },
              ]}
            >
              {(() => {
                const messages = [
                  { icon: 'checkmark-circle', color: '#10B981', text: 'Valeter received your request', subtext: 'Request sent successfully' },
                  { icon: 'time-outline', color: SKY, text: 'They have 5 minutes to respond', subtext: 'Response window active' },
                  { icon: 'card-outline', color: SKY, text: 'You\'ll pay once they accept', subtext: 'Payment on acceptance' },
                ];
                const currentMsg = messages[currentMessageIndex];
                return (
                  <View style={styles.messageContentWrapper}>
                    <View style={[styles.messageIconWrapper, { backgroundColor: currentMsg.color + '20' }]}>
                      <Ionicons name={currentMsg.icon as any} size={22} color={currentMsg.color} />
                    </View>
                    <View style={styles.messageTextWrapper}>
                      <Text style={styles.messageText}>{currentMsg.text}</Text>
                      <Text style={styles.messageSubtext}>{currentMsg.subtext}</Text>
                    </View>
                  </View>
                );
              })()}
            </Animated.View>
          </View>
        </BlurView>
      </Animated.View>

      {/* Success Overlay when booking is accepted */}
      <SuccessOverlay
        visible={showAcceptedOverlay}
        type="accepted"
        message="Booking Accepted!"
        onComplete={() => setShowAcceptedOverlay(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  statusCardContainer: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 100,
  },
  statusCardBlur: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  statusCardContent: {
    padding: 16,
    backgroundColor: 'transparent',
  },
  statusCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  statusCardHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  statusIndicator: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  statusIndicatorUrgent: {
    backgroundColor: 'rgba(239,68,68,0.2)',
    borderColor: '#EF4444',
  },
  statusCardTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 2,
  },
  statusCardSubtitle: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: 12,
    fontWeight: '600',
  },
  timerBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 1,
    borderColor: SKY,
  },
  timerBadgeUrgent: {
    backgroundColor: 'rgba(239,68,68,0.2)',
    borderColor: '#EF4444',
  },
  timerBadgeText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '900',
    fontVariant: ['tabular-nums'],
  },
  timerBadgeTextUrgent: {
    color: '#EF4444',
  },
  progressBarContainer: {
    gap: 8,
  },
  progressBarBackground: {
    height: 6,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    borderRadius: 3,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    backgroundColor: SKY,
    borderRadius: 3,
  },
  progressBarFillUrgent: {
    backgroundColor: '#EF4444',
  },
  progressBarLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 10,
    fontWeight: '600',
    textAlign: 'right',
  },
  valeterMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  valeterMarkerBlur: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderWidth: 3,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
    elevation: 5,
    overflow: 'hidden',
  },
  valeterMarker: {
    width: 48,
    height: 48,
  },
  messageCardContainer: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 1000,
  },
  messageCardBlur: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  messageCardContent: {
    padding: 18,
    backgroundColor: 'transparent',
    minHeight: 80,
    justifyContent: 'center',
  },
  messageContent: {
    justifyContent: 'center',
  },
  messageContentWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  messageIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
  },
  messageTextWrapper: {
    flex: 1,
    gap: 4,
  },
  messageText: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
  },
  messageSubtext: {
    color: 'rgba(255,255,255,0.65)',
    fontSize: 12,
    fontWeight: '600',
  },
});

