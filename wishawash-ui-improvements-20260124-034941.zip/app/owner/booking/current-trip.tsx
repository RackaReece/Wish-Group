import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Dimensions,
  Animated,
  TouchableOpacity,
  ScrollView,
  Linking,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Region, Marker, Polyline } from 'react-native-maps';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Location from 'expo-location';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';

const { width, height } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;

type BookingStatus = 'en_route' | 'arrived' | 'in_progress' | 'nearly_there';

type TripStep = {
  id: BookingStatus | 'complete';
  label: string;
  completed: boolean;
  active: boolean;
};

export default function CurrentTrip() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;

  const [booking, setBooking] = useState<any | null>(null);
  const [status, setStatus] = useState<BookingStatus>('en_route');
  const [eta, setEta] = useState<string>('5 min');
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [destinationLocation, setDestinationLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });

  const slideAnim = useRef(new Animated.Value(0)).current;
  const progressAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.spring(slideAnim, {
      toValue: 1,
      tension: 50,
      friction: 8,
      useNativeDriver: true,
    }).start();

    loadBooking();
    getCurrentLocation();
    subscribeToBooking();
  }, [bookingId]);

  useEffect(() => {
    // Animate progress based on status
    const progressMap: Record<BookingStatus, number> = {
      en_route: 0.25,
      nearly_there: 0.5,
      arrived: 0.75,
      in_progress: 0.9,
    };
    Animated.spring(progressAnim, {
      toValue: progressMap[status] || 0,
      tension: 50,
      friction: 8,
      useNativeDriver: false,
    }).start();
  }, [status]);

  const getCurrentLocation = async () => {
    try {
      const { status: permStatus } = await Location.requestForegroundPermissionsAsync();
      if (permStatus !== 'granted') return;

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };

      setUserLocation(coords);
      updateMapRegion(coords);
    } catch (error) {
      console.warn('Error getting location:', error);
    }
  };

  const updateMapRegion = (center: { latitude: number; longitude: number }) => {
    setRegion({
      latitude: center.latitude,
      longitude: center.longitude,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    });
  };

  const loadBooking = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select(`
          *,
          customer_vehicles:customer_vehicles(*),
          profiles:user_id(full_name, phone)
        `)
        .eq('id', bookingId)
        .single();

      if (error) throw error;
      setBooking(data);

      // Set status
      if (data.status === 'en_route') setStatus('en_route');
      else if (data.status === 'arrived') setStatus('arrived');
      else if (data.status === 'in_progress') setStatus('in_progress');

      // Get destination coordinates
      if (data.latitude && data.longitude) {
        const dest = {
          latitude: Number(data.latitude),
          longitude: Number(data.longitude),
        };
        setDestinationLocation(dest);
        updateMapRegion(dest);
      }
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const subscribeToBooking = () => {
    const channel = supabase
      .channel(`booking-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          setBooking(updated);
          if (updated.status === 'arrived') setStatus('arrived');
          else if (updated.status === 'in_progress') setStatus('in_progress');
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleMarkAsArriving = async () => {
    await hapticFeedback('medium');
    // Update booking status
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ status: 'arrived' })
        .eq('id', bookingId);
      if (error) throw error;
      setStatus('arrived');
    } catch (error) {
      console.error('Error updating status:', error);
    }
  };

  const handleCall = () => {
    if (booking?.profiles?.phone) {
      Linking.openURL(`tel:${booking.profiles.phone}`);
    }
  };

  const handleMessage = () => {
    // Navigate to chat or open messaging
    router.push({
      pathname: '/owner/booking/chat',
      params: { bookingId },
    });
  };

  const getStatusLabel = () => {
    switch (status) {
      case 'en_route':
        return 'On the way!';
      case 'nearly_there':
        return 'Nearly there!';
      case 'arrived':
        return 'Arrived!';
      case 'in_progress':
        return 'Washing';
      default:
        return 'On the way!';
    }
  };

  const getStatusColor = () => {
    switch (status) {
      case 'en_route':
        return '#10B981';
      case 'nearly_there':
        return '#F59E0B';
      case 'arrived':
        return '#3B82F6';
      case 'in_progress':
        return PREMIUM_PURPLE;
      default:
        return '#10B981';
    }
  };

  const steps: TripStep[] = [
    { id: 'en_route', label: 'On the way', completed: false, active: status === 'en_route' },
    { id: 'nearly_there', label: 'Nearly there', completed: status !== 'en_route', active: status === 'nearly_there' },
    { id: 'in_progress', label: 'Washing', completed: ['arrived', 'in_progress'].includes(status), active: status === 'in_progress' },
    { id: 'complete', label: 'Complete', completed: false, active: false },
  ];

  const activeStepIndex = steps.findIndex(s => s.active);
  const progressWidth = progressAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ['0%', '100%'],
  });

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {/* Fullscreen Map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
        >
          {/* User/Valeter Location */}
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <View style={styles.userMarkerCircle}>
                  <Ionicons name="car-sport" size={24} color={SKY} />
                </View>
              </View>
            </Marker>
          )}

          {/* Destination Marker */}
          {destinationLocation && (
            <Marker coordinate={destinationLocation}>
              <View style={styles.destinationMarkerContainer}>
                <View style={styles.destinationMarkerPin}>
                  <Ionicons name="location" size={28} color="#EF4444" />
                </View>
                <View style={styles.destinationMarkerLabel}>
                  <Text style={styles.destinationMarkerText}>Destination</Text>
                </View>
              </View>
            </Marker>
          )}

          {/* Route Line */}
          {userLocation && destinationLocation && (
            <Polyline
              coordinates={[userLocation, destinationLocation]}
              strokeColor={SKY}
              strokeWidth={4}
              lineDashPattern={[5, 5]}
            />
          )}
        </MapView>
      </View>

      {/* Header */}
      <View style={[styles.header, { paddingTop: insets.top }]}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          activeOpacity={0.7}
        >
          <Ionicons name="arrow-back" size={24} color="#FFFFFF" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Current Trip</Text>
        <View style={styles.headerRight} />
      </View>

      {/* Status Bar */}
      <Animated.View
        style={[
          styles.statusBar,
          {
            opacity: slideAnim,
            transform: [
              {
                translateY: slideAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [-50, 0],
                }),
              },
            ],
          },
        ]}
      >
        <BlurView intensity={90} tint="dark" style={styles.statusBarBlur}>
          <Text style={styles.statusBarText}>
            Current: <Text style={styles.statusBarHighlight}>{getStatusLabel()}</Text>
          </Text>
        </BlurView>
      </Animated.View>

      {/* Action Button */}
      {status === 'en_route' && (
        <Animated.View
          style={[
            styles.actionButtonContainer,
            {
              opacity: slideAnim,
              transform: [
                {
                  translateY: slideAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [50, 0],
                  }),
                },
              ],
            },
          ]}
        >
          <TouchableOpacity
            onPress={handleMarkAsArriving}
            style={styles.actionButton}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={[SKY, '#0EA5E9']}
              style={styles.actionButtonGradient}
            >
              <Ionicons name="location" size={20} color="#FFFFFF" />
              <Text style={styles.actionButtonText}>Mark as arriving</Text>
            </LinearGradient>
          </TouchableOpacity>
        </Animated.View>
      )}

      {/* Main Trip Details Card */}
      <Animated.View
        style={[
          styles.tripCard,
          {
            opacity: slideAnim,
            transform: [
              {
                translateY: slideAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: [100, 0],
                }),
              },
            ],
          },
        ]}
      >
        <BlurView intensity={90} tint="dark" style={styles.tripCardBlur}>
          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={styles.tripCardContent}
          >
            {/* Status Section */}
            <View style={styles.statusSection}>
              <View style={styles.statusLeft}>
                <View style={[styles.statusDot, { backgroundColor: getStatusColor() }]} />
                <Text style={styles.statusText}>{getStatusLabel()}</Text>
              </View>
              <View style={styles.statusRight}>
                <Text style={styles.etaText}>ETA: {eta}</Text>
                <TouchableOpacity style={styles.etaButton} activeOpacity={0.7}>
                  <Ionicons name="chevron-up" size={16} color="rgba(255,255,255,0.7)" />
                </TouchableOpacity>
              </View>
            </View>

            {/* Customer/Destination Info */}
            <View style={styles.customerSection}>
              <View style={styles.customerLeft}>
                <View style={styles.customerAvatar}>
                  <Ionicons name="person" size={24} color={SKY} />
                </View>
                <View style={styles.customerInfo}>
                  <Text style={styles.customerAddress} numberOfLines={2}>
                    {booking?.address || '289 Ordsall Lane, M5 3HP, Salford, England, United Kingdom'}
                  </Text>
                  <Text style={styles.serviceInfo}>
                    {booking?.service_type || 'priority_wash'} • £{booking?.price || '62.00'}
                  </Text>
                </View>
              </View>
              <View style={styles.customerActions}>
                <TouchableOpacity
                  onPress={handleCall}
                  style={styles.contactButton}
                  activeOpacity={0.7}
                >
                  <Ionicons name="call" size={20} color="rgba(255,255,255,0.8)" />
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={handleMessage}
                  style={styles.contactButton}
                  activeOpacity={0.7}
                >
                  <Ionicons name="chatbubble-ellipses" size={20} color="rgba(255,255,255,0.8)" />
                </TouchableOpacity>
              </View>
            </View>

            {/* Progress Steps */}
            <View style={styles.progressSection}>
              <View style={styles.progressBarContainer}>
                <View style={styles.progressBarBackground}>
                  <Animated.View
                    style={[
                      styles.progressBarFill,
                      {
                        width: progressWidth,
                        backgroundColor: getStatusColor(),
                      },
                    ]}
                  />
                </View>
              </View>
              <View style={styles.stepsContainer}>
                {steps.map((step, index) => (
                  <View key={step.id} style={styles.stepItem}>
                    <View
                      style={[
                        styles.stepDot,
                        step.completed && styles.stepDotCompleted,
                        step.active && styles.stepDotActive,
                        step.completed && { backgroundColor: getStatusColor() },
                        step.active && { backgroundColor: getStatusColor() },
                      ]}
                    />
                    <Text
                      style={[
                        styles.stepLabel,
                        step.active && styles.stepLabelActive,
                        step.completed && styles.stepLabelCompleted,
                      ]}
                    >
                      {step.label}
                    </Text>
                  </View>
                ))}
              </View>
            </View>

            {/* Location Details */}
            <View style={styles.locationSection}>
              <Text style={styles.locationTitle}>Location</Text>
              <Text style={styles.locationAddress}>
                {booking?.address || '289 Ordsall Lane, M5 3HP, Salford, England, United Kingdom'}
              </Text>
            </View>
          </ScrollView>
        </BlurView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingBottom: 12,
    zIndex: 1000,
    backgroundColor: 'rgba(15, 23, 42, 0.7)',
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  headerRight: {
    width: 40,
  },
  statusBar: {
    position: 'absolute',
    top: 100,
    left: 16,
    right: 16,
    zIndex: 999,
  },
  statusBarBlur: {
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  statusBarText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
    padding: 12,
    textAlign: 'center',
  },
  statusBarHighlight: {
    color: SKY,
    fontWeight: '900',
  },
  actionButtonContainer: {
    position: 'absolute',
    top: 160,
    left: 16,
    right: 16,
    zIndex: 998,
  },
  actionButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 12,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  actionButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 24,
    gap: 10,
  },
  actionButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  tripCard: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    maxHeight: height * 0.6,
    zIndex: 997,
  },
  tripCardBlur: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: 'hidden',
    borderTopWidth: 1,
    borderLeftWidth: 1,
    borderRightWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  tripCardContent: {
    padding: 20,
    paddingBottom: 40,
  },
  statusSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.1)',
  },
  statusLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  statusDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  statusText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  statusRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  etaText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    fontWeight: '700',
  },
  etaButton: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  customerSection: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    marginBottom: 24,
  },
  customerLeft: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    flex: 1,
  },
  customerAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  customerInfo: {
    flex: 1,
    gap: 6,
  },
  customerAddress: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '700',
    lineHeight: 20,
  },
  serviceInfo: {
    color: SKY,
    fontSize: 13,
    fontWeight: '700',
  },
  customerActions: {
    flexDirection: 'row',
    gap: 8,
  },
  contactButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  progressSection: {
    marginBottom: 24,
  },
  progressBarContainer: {
    marginBottom: 16,
  },
  progressBarBackground: {
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.2)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 2,
  },
  stepsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  stepItem: {
    alignItems: 'center',
    gap: 6,
    flex: 1,
  },
  stepDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.3)',
  },
  stepDotCompleted: {
    backgroundColor: SKY,
  },
  stepDotActive: {
    width: 12,
    height: 12,
    borderRadius: 6,
  },
  stepLabel: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 11,
    fontWeight: '600',
    textAlign: 'center',
  },
  stepLabelActive: {
    color: '#FFFFFF',
    fontWeight: '800',
  },
  stepLabelCompleted: {
    color: 'rgba(255,255,255,0.8)',
  },
  locationSection: {
    gap: 8,
  },
  locationTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 4,
  },
  locationAddress: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarkerCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: SKY,
    borderWidth: 3,
    borderColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
    elevation: 5,
  },
  destinationMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  destinationMarkerPin: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: '#EF4444',
    borderWidth: 3,
    borderColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#EF4444',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
    elevation: 5,
  },
  destinationMarkerLabel: {
    marginTop: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(0,0,0,0.7)',
  },
  destinationMarkerText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '700',
  },
});
