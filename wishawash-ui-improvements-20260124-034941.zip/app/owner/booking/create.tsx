import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Image,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import MapView, { Region, Marker, MapPressEvent } from 'react-native-maps';
import * as Location from 'expo-location';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import FloatingMapButton from '../../../src/components/booking/FloatingMapButton';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { serviceOptions } from '../../../src/constants/serviceOptions';
import AppHeader from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import { 
  calculateDisplayPrice, 
  getVehicleSize, 
  mapServiceIdToWashId,
  FrontendPricingInput 
} from '../../../src/pricing/pricingEngine';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;

// Uber-style dark map theme
const uberDarkMapStyle = [
  {
    elementType: 'geometry',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.fill',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'administrative.locality',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'geometry',
    stylers: [{ color: '#263c3f' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#6b9a76' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry',
    stylers: [{ color: '#38414e' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#212a37' }],
  },
  {
    featureType: 'road',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#9ca5b3' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#1f2835' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#f3d19c' }],
  },
  {
    featureType: 'transit',
    elementType: 'geometry',
    stylers: [{ color: '#2f3948' }],
  },
  {
    featureType: 'transit.station',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [{ color: '#17263c' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#515c6d' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#17263c' }],
  },
];

type Vehicle = {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
};

type BookingStep = 'location' | 'vehicle' | 'service';

export default function BookingCreate() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState<BookingStep>('location');
  const [selectedLocation, setSelectedLocation] = useState<{ latitude: number; longitude: number; address: string } | null>(null);
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [washType, setWashType] = useState<'exterior' | 'interior' | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [valeterCount, setValeterCount] = useState<number>(0);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [mapLocation, setMapLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [address, setAddress] = useState('');
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    loadVehicles();
  }, [user?.id]);

  // Get user location and load nearby valeters
  useEffect(() => {
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') {
          console.warn('Location permission not granted');
          return;
        }

        const location = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Balanced,
        });

        const coords = {
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        };

        setUserLocation(coords);
        setMapLocation(coords);
        setRegion({
          latitude: coords.latitude,
          longitude: coords.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });

        // Reverse geocode to get address
        try {
          const [result] = await Location.reverseGeocodeAsync(coords);
          if (result) {
            const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current Location';
            setAddress(addr);
            setSelectedLocation({ ...coords, address: addr });
          }
        } catch (e) {
          console.warn('Reverse geocode error:', e);
        }

        // Load nearby valeters count
        await loadNearbyValetersCount(coords.latitude, coords.longitude);
      } catch (error) {
        console.warn('Error getting location:', error);
      }
    })();
  }, []);

  const handleMapPress = async (event: MapPressEvent) => {
    const coords = event.nativeEvent.coordinate;
    setMapLocation(coords);
    setRegion({
      latitude: coords.latitude,
      longitude: coords.longitude,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    });

    try {
      const [result] = await Location.reverseGeocodeAsync(coords);
      if (result) {
        const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Selected Location';
        setAddress(addr);
        setSelectedLocation({ ...coords, address: addr });
        await hapticFeedback('light');
      }
    } catch (e) {
      console.warn('Reverse geocode error:', e);
    }
  };

  const handleUseCurrentLocation = async () => {
    await hapticFeedback('medium');
    if (userLocation) {
      setMapLocation(userLocation);
      setRegion({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
      try {
        const [result] = await Location.reverseGeocodeAsync(userLocation);
        if (result) {
          const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current Location';
          setAddress(addr);
          setSelectedLocation({ ...userLocation, address: addr });
        }
      } catch (e) {
        console.warn('Reverse geocode error:', e);
      }
    }
  };

  const loadNearbyValetersCount = async (latitude: number, longitude: number) => {
    try {
      const { data: presenceData, error } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng')
        .eq('is_online', true);

      if (error) {
        console.warn('Error loading valeters:', error);
        return;
      }

      if (!presenceData || presenceData.length === 0) {
        setValeterCount(0);
        return;
      }

      const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
        const R = 3959;
        const dLat = ((lat2 - lat1) * Math.PI) / 180;
        const dLon = ((lon2 - lon1) * Math.PI) / 180;
        const a =
          Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos((lat1 * Math.PI) / 180) *
            Math.cos((lat2 * Math.PI) / 180) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
      };

      const nearbyValeters = presenceData.filter((presence) => {
        if (!presence.last_lat || !presence.last_lng) return false;
        const distance = calculateDistance(latitude, longitude, presence.last_lat, presence.last_lng);
        return distance <= 10;
      });

      setValeterCount(nearbyValeters.length);
    } catch (error) {
      console.warn('Error counting valeters:', error);
    }
  };

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      setVehicles(data || []);
      if (data && data.length > 0) {
        const defaultVehicle = data.find(v => v.is_default) || data[0];
        setSelectedVehicle(defaultVehicle.id);
      }
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLocationContinue = async () => {
    if (!selectedLocation) {
      Alert.alert('Location Required', 'Please select a location on the map or use your current location.');
      return;
    }
    await hapticFeedback('medium');
    setCurrentStep('vehicle');
  };

  const handleVehicleContinue = async () => {
    if (!selectedVehicle) {
      Alert.alert('Vehicle Required', 'Please select a vehicle.');
      return;
    }
    await hapticFeedback('medium');
    setCurrentStep('service');
  };

  const handleServiceSelect = async (serviceId: string) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
    if (serviceId !== 'bronze-wash') {
      setWashType(null);
    }
  };

  const handleWashTypeSelect = async (type: 'exterior' | 'interior') => {
    await hapticFeedback('light');
    setWashType(type);
  };

  const handleServiceContinue = async () => {
    if (!selectedService || !selectedVehicle || !selectedLocation) {
      return;
    }
    if (selectedService === 'bronze-wash' && !washType) {
      return;
    }
    await hapticFeedback('medium');
    router.push({
      pathname: '/owner/booking/valeter-selection',
      params: {
        serviceId: selectedService,
        vehicleId: selectedVehicle,
        latitude: selectedLocation.latitude.toString(),
        longitude: selectedLocation.longitude.toString(),
        address: selectedLocation.address,
        washType: washType || '',
      },
    });
  };

  const selectedServiceData = serviceOptions.find(s => s.id === selectedService);
  const selectedVehicleData = vehicles.find(v => v.id === selectedVehicle);

  const pricingBreakdown = selectedService && selectedVehicleData ? (() => {
    const washId = mapServiceIdToWashId(selectedService);
    if (!washId) return null;
    const vehicleSize = getVehicleSize(selectedVehicleData);
    const input: FrontendPricingInput = {
      washId,
      vehicleSize,
      isMobile: true,
      isPhysicalLocation: false,
      scheduledDateTime: new Date(),
    };
    return calculateDisplayPrice(input);
  })() : null;


  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {/* Fullscreen map - always visible */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          onPress={currentStep === 'location' ? handleMapPress : undefined}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={uberDarkMapStyle}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image 
                  source={require('../../../assets/washing.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
          {mapLocation && currentStep === 'location' && (
            <Marker coordinate={mapLocation}>
              <Animated.View style={[styles.selectedLocationMarker, { transform: [{ scale: markerPulse }] }]}>
                <View style={styles.selectedLocationMarkerInner}>
                  <Ionicons name="location" size={20} color="#FFFFFF" />
                </View>
              </Animated.View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Header floating over the map */}
      <AppHeader 
        title={
          currentStep === 'location' ? 'Select Location' :
          currentStep === 'vehicle' ? 'Select Vehicle' :
          'Select Service'
        }
        subtitle={
          currentStep === 'location' ? 'Tap on map to choose location' :
          currentStep === 'vehicle' ? 'Swipe to see all vehicles' :
          'Swipe to see all services'
        }
        showBack={currentStep !== 'location'}
        onBack={
          currentStep === 'service' 
            ? () => {
                setCurrentStep('vehicle');
              }
            : currentStep === 'vehicle' 
            ? () => {
                setCurrentStep('location');
              }
            : undefined
        }
        rightAction={
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            {currentStep === 'location' && (
              <TouchableOpacity onPress={handleUseCurrentLocation} style={styles.currentLocationButton}>
                <Ionicons name="locate" size={20} color={SKY} />
              </TouchableOpacity>
            )}
            <TouchableOpacity 
              onPress={async () => {
                await hapticFeedback('light');
                router.replace('/owner/owner-dashboard' as any);
              }} 
              style={styles.exitButton}
              activeOpacity={0.7}
            >
              <Ionicons name="close" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        }
      />

      {/* Valeter count badge */}
      <Animated.View
        style={[
          styles.valeterCountBadge,
          {
            opacity: fadeAnim,
            top: insets.top + 92,
          },
        ]}
      >
        <View style={styles.valeterCountContent}>
          <Ionicons name="people-outline" size={18} color={SKY} />
          <Text style={styles.valeterCountText}>{valeterCount}</Text>
        </View>
      </Animated.View>

      {/* Floating cards container */}
      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            paddingBottom: Math.max(insets.bottom, 14) + 14 + TAB_BAR_TOTAL_HEIGHT + 12,
          },
        ]}
      >
        {/* Step 1: Location Selection */}
        {currentStep === 'location' && (
          <>
            {!selectedLocation ? (
              <GlassCard style={styles.card}>
                <View style={styles.emptyContent}>
                  <Ionicons name="location-outline" size={48} color={SKY} style={{ opacity: 0.5 }} />
                  <Text style={styles.emptyText}>Tap on the map</Text>
                  <Text style={styles.emptySubtext}>Select your location to continue</Text>
                </View>
              </GlassCard>
            ) : (
              <GlassCard
                style={[styles.card, styles.cardSelected]}
                borderColor={SKY}
                accountType="customer"
                intensity={30}
              >
                <View style={styles.locationCardContent}>
                  <View style={styles.locationHeader}>
                    <Ionicons name="location" size={24} color={SKY} />
                    <Text style={styles.locationTitle} numberOfLines={2}>
                      {selectedLocation.address}
                    </Text>
                  </View>
                  <TouchableOpacity
                    onPress={handleLocationContinue}
                    style={styles.continueBtn}
                    activeOpacity={0.9}
                  >
                    <LinearGradient
                      colors={[SKY, '#60A5FA']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 0 }}
                      style={styles.continueBtnGradient}
                    >
                      <Text style={styles.continueBtnText}>Continue</Text>
                      <Ionicons name="arrow-forward" size={16} color="#FFFFFF" />
                    </LinearGradient>
                  </TouchableOpacity>
                </View>
              </GlassCard>
            )}
          </>
        )}

        {/* Step 2: Vehicle Selection */}
        {currentStep === 'vehicle' && (
          <>
            {loading ? (
              <GlassCard style={styles.card}>
                <View style={styles.loadingContainer}>
                  <ActivityIndicator size="large" color={SKY} />
                  <Text style={styles.loadingText}>Loading vehicles...</Text>
                </View>
              </GlassCard>
            ) : vehicles.length === 0 ? (
              <GlassCard style={styles.card}>
                <View style={styles.emptyContent}>
                  <Ionicons name="car-outline" size={48} color={SKY} style={{ opacity: 0.5 }} />
                  <Text style={styles.emptyText}>No vehicles found</Text>
                  <Text style={styles.emptySubtext}>Add a vehicle to continue booking</Text>
                  <TouchableOpacity
                    onPress={() => router.push('/owner/settings/vehicle-management')}
                    style={styles.addButton}
                    activeOpacity={0.85}
                  >
                    <LinearGradient
                      colors={[SKY, '#0EA5E9']}
                      style={styles.addButtonGradient}
                    >
                      <Ionicons name="add-circle" size={20} color="#FFFFFF" />
                      <Text style={styles.addButtonText}>Add Vehicle</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </View>
              </GlassCard>
            ) : (
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.cardsScrollContent}
                snapToInterval={width * 0.75}
                decelerationRate="fast"
                pagingEnabled
                snapToAlignment="start"
              >
                {vehicles.map((vehicle) => {
                  const isSelected = selectedVehicle === vehicle.id;
                  return (
                    <View key={vehicle.id} style={[styles.cardWrapper, { width: width * 0.75 }]}>
                      <GlassCard
                        onPress={() => {
                          hapticFeedback('light');
                          setSelectedVehicle(vehicle.id);
                        }}
                        style={[styles.card, isSelected && styles.cardSelected]}
                        borderColor={isSelected ? SKY : 'rgba(135,206,235,0.3)'}
                        accountType="customer"
                        intensity={30}
                      >
                        <View style={styles.vehicleCardContent}>
                          <View style={styles.vehicleHeader}>
                            <View style={[styles.vehicleIconWrapper, isSelected && styles.vehicleIconWrapperSelected]}>
                              <Ionicons name="car-sport" size={28} color={isSelected ? SKY : 'rgba(135,206,235,0.8)'} />
                            </View>
                            <View style={styles.vehicleInfo}>
                              <View style={styles.vehicleNameRow}>
                                <Text style={styles.vehicleName} numberOfLines={1}>
                                  {vehicle.make} {vehicle.model}
                                </Text>
                                {vehicle.is_default && (
                                  <View style={styles.defaultBadge}>
                                    <Ionicons name="star" size={10} color="#10B981" />
                                    <Text style={styles.defaultBadgeText}>Default</Text>
                                  </View>
                                )}
                                {isSelected && (
                                  <Ionicons name="checkmark-circle" size={20} color={SKY} />
                                )}
                              </View>
                              <View style={styles.vehicleDetailsRow}>
                                <View style={styles.detailItem}>
                                  <Ionicons name="color-palette-outline" size={12} color={SKY} />
                                  <Text style={styles.detailText}>{vehicle.color}</Text>
                                </View>
                                <View style={styles.detailDivider} />
                                <View style={styles.detailItem}>
                                  <Ionicons name="document-text-outline" size={12} color={SKY} />
                                  <Text style={styles.detailText}>{vehicle.registration}</Text>
                                </View>
                              </View>
                              <Text style={styles.vehicleTypeText}>{vehicle.type}</Text>
                            </View>
                          </View>
                          {isSelected && (
                            <TouchableOpacity
                              onPress={handleVehicleContinue}
                              style={styles.continueBtn}
                              activeOpacity={0.9}
                            >
                              <LinearGradient
                                colors={[SKY, '#60A5FA']}
                                start={{ x: 0, y: 0 }}
                                end={{ x: 1, y: 0 }}
                                style={styles.continueBtnGradient}
                              >
                                <Text style={styles.continueBtnText}>Continue</Text>
                                <Ionicons name="arrow-forward" size={16} color="#FFFFFF" />
                              </LinearGradient>
                            </TouchableOpacity>
                          )}
                        </View>
                      </GlassCard>
                    </View>
                  );
                })}
              </ScrollView>
            )}
          </>
        )}

        {/* Step 3: Service Selection */}
        {currentStep === 'service' && (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.cardsScrollContent}
            snapToInterval={width * 0.75}
            decelerationRate="fast"
            pagingEnabled
            snapToAlignment="start"
          >
            {serviceOptions.map((service) => {
              const isSelected = selectedService === service.id;
              const showWashTypeSelection = isSelected && service.id === 'bronze-wash';
              return (
                <View key={service.id} style={[styles.cardWrapper, { width: width * 0.75 }]}>
                  <GlassCard
                    onPress={() => handleServiceSelect(service.id)}
                    style={[styles.card, isSelected && styles.cardSelected]}
                    borderColor={isSelected ? service.colors[0] : 'rgba(135,206,235,0.3)'}
                    accountType="customer"
                    intensity={30}
                  >
                    <View style={styles.serviceCardContent}>
                      <View style={styles.serviceHeader}>
                        <View style={[styles.serviceIconWrapper, { backgroundColor: service.colors[0] + '20' }]}>
                          <Ionicons name={service.icon as any} size={24} color={service.colors[0]} />
                        </View>
                        <View style={styles.serviceInfo}>
                          <Text style={styles.serviceName} numberOfLines={1}>
                            {service.name}
                          </Text>
                          <Text style={styles.serviceDesc} numberOfLines={2}>
                            {service.desc}
                          </Text>
                        </View>
                        <Text style={styles.servicePriceText}>£{service.price}</Text>
                      </View>
                      
                      <View style={styles.serviceDetails}>
                        <View style={styles.serviceDetailItem}>
                          <Ionicons name="time-outline" size={12} color={SKY} />
                          <Text style={styles.serviceDetailText}>{service.dur}</Text>
                        </View>
                        <View style={styles.serviceDetailItem}>
                          <Ionicons name="car-outline" size={12} color={SKY} />
                          <Text style={styles.serviceDetailText}>All sizes</Text>
                        </View>
                      </View>

                      {/* Wash Type Selection for Bronze Wash */}
                      {showWashTypeSelection && (
                        <View style={styles.washTypeSection}>
                          <Text style={styles.washTypeTitle}>Select Wash Type</Text>
                          <View style={styles.washTypeOptions}>
                            <TouchableOpacity
                              onPress={() => handleWashTypeSelect('exterior')}
                              style={[styles.washTypePill, washType === 'exterior' && styles.washTypePillSelected]}
                              activeOpacity={0.85}
                            >
                              <Ionicons 
                                name="car-sport-outline" 
                                size={18} 
                                color={washType === 'exterior' ? SKY : 'rgba(249,250,251,0.6)'} 
                              />
                              <Text style={[styles.washTypePillText, washType === 'exterior' && { color: SKY, fontWeight: '800' }]}>
                                Exterior
                              </Text>
                              {washType === 'exterior' && (
                                <Ionicons name="checkmark-circle" size={16} color={SKY} />
                              )}
                            </TouchableOpacity>

                            <TouchableOpacity
                              onPress={() => handleWashTypeSelect('interior')}
                              style={[styles.washTypePill, washType === 'interior' && styles.washTypePillSelected]}
                              activeOpacity={0.85}
                            >
                              <Ionicons 
                                name="home-outline" 
                                size={18} 
                                color={washType === 'interior' ? SKY : 'rgba(249,250,251,0.6)'} 
                              />
                              <Text style={[styles.washTypePillText, washType === 'interior' && { color: SKY, fontWeight: '800' }]}>
                                Interior
                              </Text>
                              {washType === 'interior' && (
                                <Ionicons name="checkmark-circle" size={16} color={SKY} />
                              )}
                            </TouchableOpacity>
                          </View>
                        </View>
                      )}

                      {isSelected && selectedVehicle && (selectedService !== 'bronze-wash' || washType) && (
                        <TouchableOpacity
                          onPress={handleServiceContinue}
                          style={styles.continueBtn}
                          activeOpacity={0.9}
                        >
                          <LinearGradient
                            colors={[SKY, '#60A5FA']}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 0 }}
                            style={styles.continueBtnGradient}
                          >
                            <Text style={styles.continueBtnText}>Choose {service.name}</Text>
                            <Ionicons name="arrow-forward" size={16} color="#FFFFFF" />
                          </LinearGradient>
                        </TouchableOpacity>
                      )}
                    </View>
                  </GlassCard>
                </View>
              );
            })}
          </ScrollView>
        )}
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  selectedLocationMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedLocationMarkerInner: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
  },
  valeterCountBadge: {
    position: 'absolute',
    right: 16,
    zIndex: 1000,
  },
  valeterCountContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(15, 23, 42, 0.7)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  valeterCountText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  currentLocationButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(15, 23, 42, 0.7)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 4,
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  card: {
    padding: 20,
    backgroundColor: 'transparent',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    borderRadius: 20,
    minHeight: 120,
    overflow: 'hidden',
  },
  cardWrapper: {
    marginRight: 12,
    marginLeft: 0,
  },
  cardSelected: {
    elevation: 16,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    borderWidth: 2,
    borderColor: SKY,
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  locationCardContent: {
    gap: 16,
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 14,
  },
  locationTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    flex: 1,
    lineHeight: 22,
  },
  emptyContent: {
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtext: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
  },
  loadingText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  emptyContainer: {
    alignItems: 'center',
    padding: 40,
    gap: 16,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
  },
  emptySubtext: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
  },
  addButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginTop: 8,
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
    gap: 8,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  horizontalScrollContent: {
    paddingRight: 20,
    gap: 12,
  },
  horizontalCard: {
    marginRight: 12,
  },
  vehicleCardContent: {
    gap: 16,
  },
  vehicleHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 14,
  },
  vehicleIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.12)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  vehicleIconWrapperSelected: {
    backgroundColor: SKY + '20',
    borderColor: SKY,
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 8,
  },
  vehicleInfo: {
    flex: 1,
    gap: 10,
  },
  vehicleNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    gap: 8,
  },
  vehicleName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    flex: 1,
    letterSpacing: -0.3,
  },
  defaultBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.4)',
  },
  defaultBadgeText: {
    color: '#10B981',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  vehicleDetailsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flexWrap: 'wrap',
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(135,206,235,0.15)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  detailDivider: {
    width: 1,
    height: 18,
    backgroundColor: 'rgba(135,206,235,0.3)',
  },
  detailText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '700',
  },
  vehicleTypeText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  serviceCardContent: {
    gap: 16,
  },
  serviceHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 14,
  },
  serviceIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
  },
  serviceInfo: {
    flex: 1,
    gap: 6,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.4,
  },
  serviceDesc: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 13,
    fontWeight: '600',
    lineHeight: 18,
  },
  servicePriceText: {
    color: SKY,
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  serviceDetails: {
    flexDirection: 'row',
    gap: 10,
    flexWrap: 'wrap',
  },
  serviceDetailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(135,206,235,0.15)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  serviceDetailText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '700',
  },
  washTypeSection: {
    marginTop: 12,
    gap: 12,
  },
  washTypeTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 8,
    letterSpacing: -0.2,
  },
  washTypeOptions: {
    flexDirection: 'row',
    gap: 10,
  },
  washTypePill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  washTypePillSelected: {
    borderColor: SKY,
    backgroundColor: SKY + '20',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  washTypePillText: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 14,
    fontWeight: '700',
  },
  continueBtn: {
    height: 48,
    borderRadius: 14,
    overflow: 'hidden',
    marginTop: 12,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 8,
  },
  continueBtnGradient: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingHorizontal: 20,
  },
  continueBtnText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  addButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginTop: 12,
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 20,
    paddingVertical: 12,
    gap: 8,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
});
