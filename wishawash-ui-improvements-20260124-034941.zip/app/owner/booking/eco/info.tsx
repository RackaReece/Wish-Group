import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Dimensions,
  Animated,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import AppHeader, { HEADER_HEIGHT } from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;
const ECO_GREEN = colors.ECO_GREEN;

interface InfoSlide {
  id: number;
  title: string;
  subtitle: string;
  description: string;
  iconName: keyof typeof Ionicons.glyphMap;
  color: string;
}

const slides: InfoSlide[] = [
  {
    id: 1,
    title: 'Our Eco Mission',
    subtitle: 'A Green Revolution in Car Care',
    description: 'Wish a Wash is committed to being the UK\'s most environmentally responsible car care platform. Every eco wash service uses 100% biodegradable products and carbon-neutral delivery methods.',
    iconName: 'leaf',
    color: ECO_GREEN,
  },
  {
    id: 2,
    title: 'Biodegradable Products',
    subtitle: '100% Plant-Based Solutions',
    description: 'All our cleaning products are completely biodegradable and non-toxic. Made from natural ingredients, they protect your vehicle while being safe for the environment and waterways.',
    iconName: 'recycle',
    color: '#10B981',
  },
  {
    id: 3,
    title: 'Water Conservation',
    subtitle: 'Advanced Technology',
    description: 'Our eco wash process uses up to 80% less water than traditional car washes. Advanced water-saving technology and recycling systems ensure minimal environmental impact.',
    iconName: 'water',
    color: '#60A5FA',
  },
  {
    id: 4,
    title: 'Carbon Neutral',
    subtitle: 'Zero Net Emissions',
    description: 'Every eco wash service is fully carbon-neutral. We offset all emissions through verified environmental projects, making your car care completely sustainable.',
    iconName: 'earth',
    color: '#059669',
  },
  {
    id: 5,
    title: 'Premium Quality',
    subtitle: 'Eco Doesn\'t Mean Compromise',
    description: 'Our eco-friendly products deliver the same premium results as traditional methods. Expert valeters ensure your vehicle receives exceptional care while protecting the planet.',
    iconName: 'shield-checkmark',
    color: ECO_GREEN,
  },
  {
    id: 6,
    title: 'Join the Movement',
    subtitle: 'Make a Difference',
    description: 'By choosing eco wash, you\'re contributing to a cleaner environment. Together, we\'re building a sustainable future for car care. Every wash makes a difference.',
    iconName: 'people',
    color: '#10B981',
  },
];

export default function EcoInfo() {
  const insets = useSafeAreaInsets();
  const [currentSlide, setCurrentSlide] = useState(0);
  const scrollViewRef = useRef<ScrollView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const iconAnim = useRef(new Animated.Value(0)).current;
  const progressAnim = useRef(new Animated.Value(0)).current;

  // Calculate available space for slides
  const progressHeight = 60; // Progress bar + padding
  const navHeight = 120; // Navigation buttons + padding
  const availableHeight = height - (insets.top + HEADER_HEIGHT + progressHeight + navHeight + insets.bottom);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.timing(iconAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();

    Animated.timing(progressAnim, {
      toValue: (currentSlide + 1) / slides.length,
      duration: 300,
      useNativeDriver: false,
    }).start();
  }, [currentSlide]);

  const handleNext = () => {
    if (currentSlide < slides.length - 1) {
      const nextSlide = currentSlide + 1;
      setCurrentSlide(nextSlide);
      scrollViewRef.current?.scrollTo({
        x: nextSlide * width,
        animated: true,
      });
    } else {
      router.back();
    }
  };

  const handlePrev = () => {
    if (currentSlide > 0) {
      const prevSlide = currentSlide - 1;
      setCurrentSlide(prevSlide);
      scrollViewRef.current?.scrollTo({
        x: prevSlide * width,
        animated: true,
      });
    }
  };

  const handleScroll = (event: any) => {
    const offsetX = event.nativeEvent.contentOffset.x;
    const slideIndex = Math.round(offsetX / width);
    if (slideIndex !== currentSlide && slideIndex >= 0 && slideIndex < slides.length) {
      setCurrentSlide(slideIndex);
    }
  };

  const renderSlide = (slide: InfoSlide, index: number) => {
    const iconSize = isSmallScreen ? 44 : 48;
    const iconContainerSize = isSmallScreen ? 100 : 120;
    
    return (
      <View key={slide.id} style={[styles.slide, { width, minHeight: availableHeight }]}>
        <Animated.View
          style={[
            styles.iconContainer,
            {
              width: iconContainerSize,
              height: iconContainerSize,
              borderRadius: iconContainerSize / 2,
              backgroundColor: slide.color + '20',
              borderColor: slide.color,
              transform: [
                {
                  scale: iconAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: [0.5, 1],
                  }),
                },
              ],
            },
          ]}
        >
          <Ionicons name={slide.iconName} size={iconSize} color={slide.color} />
        </Animated.View>

        <Animated.View
          style={[
            styles.content,
            {
              opacity: fadeAnim,
              transform: [{ translateY: slideAnim }],
            },
          ]}
        >
          <Text style={styles.title} numberOfLines={2}>{slide.title}</Text>
          <Text style={styles.subtitle} numberOfLines={2}>{slide.subtitle}</Text>
          <Text style={styles.description} numberOfLines={6}>{slide.description}</Text>
        </Animated.View>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Eco Wash Mission" />

      {/* Progress Bar */}
      <View style={[styles.progressContainer, { paddingTop: insets.top + HEADER_HEIGHT + 20 }]}>
        <View style={styles.progressBar}>
          <Animated.View
            style={[
              styles.progressFill,
              {
                width: progressAnim.interpolate({
                  inputRange: [0, 1],
                  outputRange: ['0%', '100%'],
                }),
                backgroundColor: ECO_GREEN,
              },
            ]}
          />
        </View>
        <Text style={styles.slideCounter}>
          {currentSlide + 1} / {slides.length}
        </Text>
      </View>

      {/* Slides */}
      <ScrollView
        ref={scrollViewRef}
        horizontal
        pagingEnabled
        showsHorizontalScrollIndicator={false}
        onScroll={handleScroll}
        scrollEventThrottle={16}
        style={styles.scrollView}
      >
        {slides.map((slide, index) => renderSlide(slide, index))}
      </ScrollView>

      {/* Navigation */}
      <View style={[styles.navigation, { paddingBottom: Math.max(insets.bottom, 24) }]}>
        <View style={styles.dots}>
          {slides.map((_, index) => (
            <View
              key={index}
              style={[
                styles.dot,
                index === currentSlide && [styles.activeDot, { backgroundColor: ECO_GREEN }],
              ]}
            />
          ))}
        </View>

        <View style={styles.navButtons}>
          {currentSlide > 0 && (
            <TouchableOpacity style={styles.navButton} onPress={handlePrev}>
              <Ionicons name="chevron-back" size={20} color={ECO_GREEN} />
              <Text style={styles.navButtonText}>Previous</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            style={[styles.nextButton, { backgroundColor: ECO_GREEN }]}
            onPress={handleNext}
          >
            <Text style={styles.nextButtonText}>
              {currentSlide === slides.length - 1 ? 'Done' : 'Next'}
            </Text>
            <Ionicons name="chevron-forward" size={20} color="#FFFFFF" />
          </TouchableOpacity>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  progressContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingBottom: 14,
    gap: 16,
  },
  progressBar: {
    flex: 1,
    height: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 2,
  },
  progressFill: {
    height: '100%',
    borderRadius: 2,
  },
  slideCounter: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
    minWidth: 50,
    textAlign: 'right',
  },
  scrollView: {
    flex: 1,
  },
  slide: {
    flex: 1,
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: isSmallScreen ? 24 : 32,
    paddingTop: 24,
    paddingBottom: 16,
  },
  iconContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: isSmallScreen ? 24 : 32,
    borderWidth: 3,
    shadowColor: ECO_GREEN,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 20,
    elevation: 12,
  },
  content: {
    alignItems: 'center',
    flex: 1,
    justifyContent: 'center',
    maxWidth: width - (isSmallScreen ? 48 : 64),
    paddingHorizontal: 4,
  },
  title: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 26 : 30,
    fontWeight: '800',
    textAlign: 'center',
    marginBottom: 12,
    lineHeight: isSmallScreen ? 32 : 36,
    flexShrink: 1,
  },
  subtitle: {
    color: ECO_GREEN,
    fontSize: isSmallScreen ? 16 : 18,
    textAlign: 'center',
    marginBottom: 20,
    fontWeight: '700',
    lineHeight: isSmallScreen ? 22 : 24,
    flexShrink: 1,
  },
  description: {
    color: 'rgba(249,250,251,0.95)',
    fontSize: isSmallScreen ? 15 : 17,
    textAlign: 'center',
    lineHeight: isSmallScreen ? 22 : 26,
    paddingHorizontal: 4,
    flexShrink: 1,
  },
  navigation: {
    paddingHorizontal: 24,
    paddingTop: 18,
    gap: 18,
  },
  dots: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 10,
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  activeDot: {
    width: 28,
  },
  navButtons: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 12,
  },
  navButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
    borderRadius: 28,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 1.5,
    borderColor: 'rgba(16,185,129,0.4)',
    gap: 8,
  },
  navButtonText: {
    color: ECO_GREEN,
    fontSize: 16,
    fontWeight: '600',
  },
  nextButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 28,
    gap: 8,
    minWidth: 140,
    justifyContent: 'center',
    shadowColor: ECO_GREEN,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  nextButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});
