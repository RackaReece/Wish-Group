import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Dimensions,
  Animated,
  TouchableOpacity,
  Alert,
  ActivityIndicator,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Region, Polyline } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import GlassCard from '../../../src/components/booking/GlassCard';
import StatusBadge from '../../../src/components/booking/StatusBadge';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import AppHeader from '../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../app/components/NavigationTab';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;

type BookingStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled';

type BookingRow = {
  id: string;
  status: BookingStatus;
  service_type: string;
  service_name?: string | null;
  price: number | string | null;
  location_address?: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
  valeter_id?: string | null;
  updated_at?: string;
  completed_at?: string | null;
  scheduled_at?: string | null;
  created_at?: string | null;
  location_id?: string | null;
};

type WashHub = {
  id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
};

type ProcessStage = 'pickup' | 'travel_to_hub' | 'at_hub' | 'washing' | 'travel_back' | 'delivery' | 'completed';

export default function BookingTracking() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;

  const [booking, setBooking] = useState<BookingRow | null>(null);
  const [status, setStatus] = useState<BookingStatus>('scheduled');
  const [valeterLocation, setValeterLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [washHub, setWashHub] = useState<WashHub | null>(null);
  const [processStage, setProcessStage] = useState<ProcessStage>('pickup');
  const [routeCoordinates, setRouteCoordinates] = useState<Array<{ latitude: number; longitude: number }>>([]);

  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });

  const [cancelling, setCancelling] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState<number | null>(null);
  const [estimatedDuration, setEstimatedDuration] = useState<number>(30 * 60); // Default 30 minutes in seconds

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const timeProgressAnim = useRef(new Animated.Value(0)).current;
  const stageProgressAnim = useRef(new Animated.Value(0)).current;

  // Channel refs so we can cleanly re-subscribe
  const bookingChannelRef = useRef<any>(null);
  const presenceChannelRef = useRef<any>(null);
  const presenceValeterIdRef = useRef<string | null>(null);

  useEffect(() => {
    Animated.timing(fadeAnim, { toValue: 1, duration: 450, useNativeDriver: true }).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  // Timer calculation based on status
  useEffect(() => {
    if (!booking || status === 'completed' || status === 'cancelled') {
      setTimeRemaining(null);
      timeProgressAnim.setValue(0);
      return;
    }

    const calculateTimeRemaining = () => {
      if (status === 'in_progress') {
        // Calculate time remaining for service completion
        // Assume service started when status changed to in_progress
        const startTime = booking.updated_at ? new Date(booking.updated_at).getTime() : Date.now();
        const endTime = startTime + (estimatedDuration * 1000);
        const remaining = Math.max(0, Math.floor((endTime - Date.now()) / 1000));
        setTimeRemaining(remaining);
        
        // Update progress bar (time elapsed / estimated duration)
        const elapsed = Math.max(0, (Date.now() - startTime) / 1000);
        const progress = Math.min(1, elapsed / estimatedDuration);
        timeProgressAnim.setValue(progress);
      } else if (status === 'scheduled' && booking.scheduled_at) {
        // Calculate time until scheduled start
        const scheduledTime = new Date(booking.scheduled_at).getTime();
        const remaining = Math.max(0, Math.floor((scheduledTime - Date.now()) / 1000));
        setTimeRemaining(remaining);
        
        // Progress bar shows time until start (inverse)
        const totalWait = scheduledTime - (booking.created_at ? new Date(booking.created_at).getTime() : Date.now());
        const elapsed = totalWait - (remaining * 1000);
        const progress = totalWait > 0 ? Math.min(1, Math.max(0, elapsed / totalWait)) : 0;
        timeProgressAnim.setValue(progress);
      } else {
        // Default: estimate based on creation time
        const createdTime = booking.created_at ? new Date(booking.created_at).getTime() : Date.now();
        const estimatedEnd = createdTime + (estimatedDuration * 1000);
        const remaining = Math.max(0, Math.floor((estimatedEnd - Date.now()) / 1000));
        setTimeRemaining(remaining);
        
        // Progress bar
        const elapsed = (Date.now() - createdTime) / 1000;
        const progress = Math.min(1, Math.max(0, elapsed / estimatedDuration));
        timeProgressAnim.setValue(progress);
      }
    };

    calculateTimeRemaining();
    const interval = setInterval(calculateTimeRemaining, 1000);

    return () => clearInterval(interval);
  }, [booking, status, estimatedDuration]);

  useEffect(() => {
    if (!bookingId) return;

    const start = async () => {
      await loadBooking();
      subscribeToBooking();
    };

    start();

    return () => {
      if (bookingChannelRef.current) supabase.removeChannel(bookingChannelRef.current);
      if (presenceChannelRef.current) supabase.removeChannel(presenceChannelRef.current);

      bookingChannelRef.current = null;
      presenceChannelRef.current = null;
      presenceValeterIdRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookingId]);

  const loadBooking = async () => {
    try {
      const { data, error } = await supabase.from('bookings').select('*').eq('id', bookingId).single();
      if (error) throw error;

      const row = data as BookingRow;

      setBooking(row);
      setStatus(row.status);

      // Set estimated duration based on service type (in seconds)
      if (row.service_type) {
        const serviceDurations: { [key: string]: number } = {
          'bronze-wash': 20 * 60, // 20 minutes
          'silver-wash': 30 * 60, // 30 minutes
          'gold-wash': 45 * 60, // 45 minutes
          'detailing': 60 * 60, // 60 minutes
        };
        setEstimatedDuration(serviceDurations[row.service_type] || 30 * 60);
      }

      // Load wash hub if location_id exists
      if (row.location_id) {
        await loadWashHub(row.location_id);
      }

      // Determine process stage based on status
      updateProcessStage(row.status, row);

      // Update map region to show all relevant points
      updateMapRegion(row);

      if (row.valeter_id) {
        ensurePresenceSubscription(row.valeter_id);
        await loadValeterPresenceOnce(row.valeter_id);
      }
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const subscribeToBooking = () => {
    if (bookingChannelRef.current) supabase.removeChannel(bookingChannelRef.current);

    const channel = supabase
      .channel(`booking-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        async (payload) => {
          const updated = payload.new as BookingRow;

          setBooking(updated);
          setStatus(updated.status);
          updateProcessStage(updated.status, updated);

          if (updated.location_id && !washHub) {
            await loadWashHub(updated.location_id);
          }

          if (updated.valeter_id) {
            ensurePresenceSubscription(updated.valeter_id);
            await loadValeterPresenceOnce(updated.valeter_id);
          }

          if (updated.status === 'completed') {
            router.replace({
              pathname: '/owner/booking/completion',
              params: { bookingId },
            });
          }

          // Optional: if cancelled, bounce back to dashboard after a moment
          if (updated.status === 'cancelled') {
            // keep them on screen so they can see it changed, then go home
            setTimeout(() => {
              router.replace('owner/owner-dashboard');
            }, 700);
          }
        }
      )
      .subscribe();

    bookingChannelRef.current = channel;
  };

  const ensurePresenceSubscription = (valeterId: string) => {
    if (presenceValeterIdRef.current === valeterId && presenceChannelRef.current) return;

    if (presenceChannelRef.current) {
      supabase.removeChannel(presenceChannelRef.current);
      presenceChannelRef.current = null;
    }

    presenceValeterIdRef.current = valeterId;

    const presenceChannel = supabase
      .channel(`valeter-presence-${valeterId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${valeterId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          if (updated?.last_lat && updated?.last_lng) {
            setValeterLocation({ latitude: updated.last_lat, longitude: updated.last_lng });
            if (booking) {
              updateProcessStage(status, booking);
            }
          }
        }
      )
      .subscribe();

    presenceChannelRef.current = presenceChannel;
  };

  const loadValeterPresenceOnce = async (valeterId: string) => {
    try {
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('last_lat,last_lng')
        .eq('user_id', valeterId)
        .maybeSingle();

      if (error) return;

      if (data?.last_lat && data?.last_lng) {
        setValeterLocation({ latitude: data.last_lat, longitude: data.last_lng });
        updateRoute();
      }
    } catch {}
  };

  const loadWashHub = async (locationId: string) => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, latitude, longitude')
        .eq('id', locationId)
        .maybeSingle();

      if (error) throw error;

      if (data && data.latitude && data.longitude) {
        setWashHub({
          id: data.id,
          name: data.name || 'Wash Hub',
          address: data.address,
          latitude: data.latitude,
          longitude: data.longitude,
        });
        updateRoute();
      }
    } catch (error) {
      console.error('Error loading wash hub:', error);
    }
  };

  const updateProcessStage = (currentStatus: BookingStatus, bookingData: BookingRow) => {
    // Determine process stage based on status and location
    // For on-demand valeters: they come to your location, wash it there, and leave
    // For physical hubs: you go to hub, wait, get it washed, then leave
    
    if (washHub) {
      // Physical hub flow
      if (currentStatus === 'scheduled' || currentStatus === 'pending_payment' || currentStatus === 'confirmed') {
        // Customer should travel to hub
        setProcessStage('travel_to_hub');
      } else if (currentStatus === 'en_route') {
        // Customer traveling to hub
        setProcessStage('travel_to_hub');
      } else if (currentStatus === 'arrived') {
        // Customer arrived at hub
        setProcessStage('at_hub');
      } else if (currentStatus === 'in_progress') {
        // Washing at hub
        setProcessStage('washing');
      } else if (currentStatus === 'completed') {
        setProcessStage('completed');
      } else {
        setProcessStage('travel_to_hub');
      }
    } else {
      // On-demand valeter flow
      if (currentStatus === 'scheduled' || currentStatus === 'pending_valeter_acceptance' || currentStatus === 'pending_payment' || currentStatus === 'confirmed') {
        setProcessStage('pickup');
      } else if (currentStatus === 'en_route') {
        // Valeter traveling to customer
        setProcessStage('pickup');
      } else if (currentStatus === 'arrived') {
        // Valeter arrived at customer location
        setProcessStage('pickup');
      } else if (currentStatus === 'in_progress') {
        // Washing at customer location
        setProcessStage('washing');
      } else if (currentStatus === 'completed') {
        setProcessStage('completed');
      } else {
        setProcessStage('pickup');
      }
    }
  };

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371; // Earth's radius in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const updateRoute = () => {
    if (!booking) return;

    const coordinates: Array<{ latitude: number; longitude: number }> = [];

    if (washHub) {
      // Physical hub flow: Customer location → Hub location
      if (booking.location_lat && booking.location_lng) {
        coordinates.push({
          latitude: booking.location_lat,
          longitude: booking.location_lng,
        });
      }
      if (washHub.latitude && washHub.longitude) {
        const lastPoint = coordinates[coordinates.length - 1];
        if (!lastPoint || 
            Math.abs(washHub.latitude - lastPoint.latitude) > 0.001 ||
            Math.abs(washHub.longitude - lastPoint.longitude) > 0.001) {
          coordinates.push({
            latitude: washHub.latitude,
            longitude: washHub.longitude,
          });
        }
      }
    } else {
      // On-demand valeter flow: Valeter location → Customer location (valeter comes to customer)
      if (valeterLocation) {
        coordinates.push(valeterLocation);
      }
      if (booking.location_lat && booking.location_lng) {
        const lastPoint = coordinates[coordinates.length - 1];
        if (!lastPoint || 
            Math.abs(booking.location_lat - lastPoint.latitude) > 0.001 ||
            Math.abs(booking.location_lng - lastPoint.longitude) > 0.001) {
          coordinates.push({
            latitude: booking.location_lat,
            longitude: booking.location_lng,
          });
        }
      }
    }

    // Generate intermediate points for smooth route visualization
    if (coordinates.length >= 2) {
      const smoothRoute: Array<{ latitude: number; longitude: number }> = [];
      for (let i = 0; i < coordinates.length - 1; i++) {
        smoothRoute.push(coordinates[i]);
        // Add 3 intermediate points between each pair
        for (let j = 1; j <= 3; j++) {
          const ratio = j / 4;
          smoothRoute.push({
            latitude: coordinates[i].latitude + (coordinates[i + 1].latitude - coordinates[i].latitude) * ratio,
            longitude: coordinates[i].longitude + (coordinates[i + 1].longitude - coordinates[i].longitude) * ratio,
          });
        }
      }
      smoothRoute.push(coordinates[coordinates.length - 1]);
      setRouteCoordinates(smoothRoute);
    } else {
      setRouteCoordinates(coordinates);
    }
  };

  // Update route when locations change
  useEffect(() => {
    updateRoute();
    if (booking) {
      updateMapRegion(booking);
    }
  }, [booking, valeterLocation, washHub]);

  const updateMapRegion = (bookingData: BookingRow) => {
    const points: Array<{ latitude: number; longitude: number }> = [];

    // Add customer location
    if (bookingData.location_lat && bookingData.location_lng) {
      points.push({
        latitude: bookingData.location_lat,
        longitude: bookingData.location_lng,
      });
    }

    // Add valeter location
    if (valeterLocation) {
      points.push(valeterLocation);
    }

    // Add hub location
    if (washHub && washHub.latitude && washHub.longitude) {
      points.push({
        latitude: washHub.latitude,
        longitude: washHub.longitude,
      });
    }

    if (points.length === 0) {
      // Default to customer location if available
      if (bookingData.location_lat && bookingData.location_lng) {
        setRegion({
          latitude: bookingData.location_lat,
          longitude: bookingData.location_lng,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        });
      }
      return;
    }

    // Calculate bounds
    const lats = points.map(p => p.latitude);
    const lngs = points.map(p => p.longitude);
    const minLat = Math.min(...lats);
    const maxLat = Math.max(...lats);
    const minLng = Math.min(...lngs);
    const maxLng = Math.max(...lngs);

    // Add padding
    const latPadding = (maxLat - minLat) * 0.3;
    const lngPadding = (maxLng - minLng) * 0.3;

    setRegion({
      latitude: (minLat + maxLat) / 2,
      longitude: (minLng + maxLng) / 2,
      latitudeDelta: Math.max(0.01, (maxLat - minLat) + latPadding * 2),
      longitudeDelta: Math.max(0.01, (maxLng - minLng) + lngPadding * 2),
    });
  };

  const canCancel = status !== 'completed' && status !== 'cancelled' && status !== 'pending_payment';

  const cancelBooking = async () => {
    if (!bookingId || !user?.id) return;
    if (!canCancel) return;

    try {
      setCancelling(true);

      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_at: new Date().toISOString(),
          cancelled_by: 'customer',
          cancellation_reason: 'Cancelled by customer',
        })
        .eq('id', bookingId);

      if (error) throw error;

      // UI will update via realtime, but do this for instant feedback
      setStatus('cancelled');
    } catch (e) {
      console.warn('[BookingTracking] cancelBooking error', e);
      Alert.alert('Could not cancel', 'Please try again in a moment.');
    } finally {
      setCancelling(false);
    }
  };

  const onPressCancel = () => {
    Alert.alert(
      'Cancel booking?',
      'This will cancel your booking. If a valeter is already on the way, you may still be charged depending on your policy.',
      [
        { text: 'Keep booking', style: 'cancel' },
        { text: 'Cancel booking', style: 'destructive', onPress: cancelBooking },
      ]
    );
  };

  const getStatusProgress = (): number => {
    switch (status) {
      case 'scheduled':
        return 35;
      case 'in_progress':
        return 75;
      case 'completed':
        return 100;
      case 'cancelled':
        return 100;
      default:
        return 0;
    }
  };

  const getStatusMessage = (): string => {
    switch (status) {
      case 'scheduled':
        return 'Booked! Your valeter will start at the scheduled time';
      case 'in_progress':
        return 'Service in progress';
      case 'completed':
        return 'Service completed';
      case 'cancelled':
        return 'This booking was cancelled';
      default:
        return 'Tracking your booking';
    }
  };

  const getStatusSteps = () => {
    if (washHub) {
      // Physical hub flow: Travel to hub → At hub → Washing → Completed
      return [
        { label: 'Traveling', completed: ['travel_to_hub', 'at_hub', 'washing', 'completed'].includes(processStage) },
        { label: 'At Hub', completed: ['at_hub', 'washing', 'completed'].includes(processStage) },
        { label: 'Washing', completed: ['washing', 'completed'].includes(processStage) },
        { label: 'Completed', completed: processStage === 'completed' },
      ];
    } else {
      // On-demand valeter flow: En route → Arrived → Washing → Completed
      return [
        { label: 'En Route', completed: ['pickup', 'washing', 'completed'].includes(processStage) },
        { label: 'Arrived', completed: ['washing', 'completed'].includes(processStage) },
        { label: 'Washing', completed: ['washing', 'completed'].includes(processStage) },
        { label: 'Completed', completed: processStage === 'completed' },
      ];
    }
  };

  const getProcessStageLabel = (stage: ProcessStage): string => {
    switch (stage) {
      case 'pickup':
        return washHub ? `Heading to ${washHub.name}` : 'Valeter on the way to your location';
      case 'travel_to_hub':
        return washHub ? `Traveling to ${washHub.name}` : 'Traveling to wash hub';
      case 'at_hub':
        return washHub ? `At ${washHub.name} - waiting for service` : 'At wash hub - waiting for service';
      case 'washing':
        return washHub ? `Vehicle being washed at ${washHub.name}` : 'Vehicle being washed at your location';
      case 'travel_back':
        return 'Returning with your vehicle';
      case 'delivery':
        return 'Delivering your vehicle';
      case 'completed':
        return 'Service completed';
      default:
        return 'Tracking your booking';
    }
  };

  const getProcessStageProgress = (): number => {
    switch (processStage) {
      case 'pickup':
        return washHub ? 10 : 25; // On-demand: valeter en route
      case 'travel_to_hub':
        return 30; // Physical: traveling to hub
      case 'at_hub':
        return 50; // Physical: at hub
      case 'washing':
        return 75; // Washing in progress
      case 'travel_back':
        return 85;
      case 'delivery':
        return 90;
      case 'completed':
        return 100;
      default:
        return 0;
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map (no gaps) */}
      <View style={StyleSheet.absoluteFill}>
        <MapView 
          style={StyleSheet.absoluteFill} 
          region={region} 
          showsUserLocation={false}
        >
          {/* Route polyline */}
          {routeCoordinates.length > 1 && (
            <Polyline
              coordinates={routeCoordinates}
              strokeColor={SKY}
              strokeWidth={4}
              lineDashPattern={[5, 5]}
              lineCap="round"
              lineJoin="round"
            />
          )}

          {/* Customer location marker */}
          {!!booking?.location_lat && !!booking?.location_lng && (
            <Marker 
              coordinate={{ latitude: booking.location_lat!, longitude: booking.location_lng! }}
              title="Your Location"
            >
              <View style={styles.customerMarkerContainer}>
                <Image 
                  source={require('../../../assets/washing.png')} 
                  style={styles.customerMarker}
                  resizeMode="contain"
                />
                <View style={styles.markerLabel}>
                  <Text style={styles.markerLabelText}>You</Text>
                </View>
              </View>
            </Marker>
          )}

          {/* Wash hub marker or Detailing hub marker */}
          {washHub && washHub.latitude && washHub.longitude && (
            <Marker 
              coordinate={{ latitude: washHub.latitude, longitude: washHub.longitude }}
              title={washHub.name}
            >
              <View style={styles.hubMarkerContainer}>
                <Image 
                  source={
                    booking?.service_type?.includes('detailing') 
                      ? require('../../../assets/detailing.png')
                      : require('../../../assets/washing.png')
                  } 
                  style={styles.hubMarkerImage}
                  resizeMode="contain"
                />
                <View style={styles.markerLabel}>
                  <Text style={styles.markerLabelText}>
                    {booking?.service_type?.includes('detailing') ? 'Detail Hub' : 'Wash Hub'}
                  </Text>
                </View>
              </View>
            </Marker>
          )}

          {/* Valeter location marker or Detailer location marker */}
          {!!valeterLocation && (
            <Marker coordinate={valeterLocation} title={booking?.service_type?.includes('detailing') ? 'Detailer' : 'Valeter'}>
              <Animated.View style={[styles.valeterMarkerContainer, { transform: [{ scale: markerPulse }] }]}>
                <Image 
                  source={
                    booking?.service_type?.includes('detailing')
                      ? require('../../../assets/detailing.png')
                      : require('../../../assets/cleaning.png')
                  } 
                  style={styles.valeterMarker}
                  resizeMode="contain"
                />
                <View style={styles.markerLabel}>
                  <Text style={styles.markerLabelText}>
                    {booking?.service_type?.includes('detailing') ? 'Detailer' : 'Valeter'}
                  </Text>
                </View>
              </Animated.View>
            </Marker>
          )}

          {/* Process stage indicators - only show for physical hubs */}
          {processStage !== 'completed' && washHub && (
            <>
              {processStage === 'travel_to_hub' && booking?.location_lat && booking?.location_lng && (
                <Marker coordinate={{ latitude: booking.location_lat, longitude: booking.location_lng }}>
                  <View style={styles.stageIndicator}>
                    <Text style={styles.stageIndicatorText}>1</Text>
                  </View>
                </Marker>
              )}
              {processStage === 'at_hub' && washHub.latitude && washHub.longitude && (
                <Marker coordinate={{ latitude: washHub.latitude, longitude: washHub.longitude }}>
                  <View style={styles.stageIndicator}>
                    <Text style={styles.stageIndicatorText}>2</Text>
                  </View>
                </Marker>
              )}
              {processStage === 'washing' && washHub.latitude && washHub.longitude && (
                <Marker coordinate={{ latitude: washHub.latitude, longitude: washHub.longitude }}>
                  <View style={styles.stageIndicator}>
                    <Text style={styles.stageIndicatorText}>3</Text>
                  </View>
                </Marker>
              )}
            </>
          )}
        </MapView>

        {/* Time progress bar at top of map with timer text */}
        {timeRemaining !== null && timeRemaining > 0 && status !== 'completed' && (
          <View style={[styles.timeBarContainer, { top: insets.top + 68 }]}>
            <View style={styles.timeBarBackground}>
              <Animated.View 
                style={[
                  styles.timeBarFill,
                  {
                    width: timeProgressAnim.interpolate({
                      inputRange: [0, 1],
                      outputRange: ['0%', '100%'],
                    }),
                  },
                ]}
              />
            </View>
            {/* Timer text on top of progress bar */}
            <View style={styles.timerTextOverlay}>
              <Text style={styles.timerTextSmall}>
                {Math.floor(timeRemaining / 60)}:{(timeRemaining % 60).toString().padStart(2, '0')}
              </Text>
            </View>
          </View>
        )}
      </View>

      {/* Header floating over the map */}
      <AppHeader 
        title="Live Tracking"
        rightAction={
          <TouchableOpacity
            onPress={() => router.replace('/owner/owner-dashboard')}
            style={styles.headerExitButton}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={22} color="#FFFFFF" />
          </TouchableOpacity>
        }
      />

      {/* Enhanced bottom tracking card */}
      <Animated.View
        style={[
          styles.cardContainer,
          {
            opacity: fadeAnim,
            paddingBottom: Math.max(insets.bottom, 14) + 14 + TAB_BAR_TOTAL_HEIGHT + 12,
          },
        ]}
      >
        <GlassCard style={styles.trackingCard} intensity={30} accountType="customer">
          {/* Header Section */}
          <View style={styles.trackingHeader}>
            <View style={styles.headerContent}>
              <StatusBadge status={status} size="medium" />
              <View style={styles.headerTextContainer}>
                <Text style={styles.statusTitle}>{getProcessStageLabel(processStage)}</Text>
                {timeRemaining !== null && timeRemaining > 0 && status !== 'completed' && (
                  <View style={styles.timeRemainingBadge}>
                    <Ionicons name="time" size={14} color={SKY} />
                    <Text style={styles.timeRemainingText}>
                      {Math.floor(timeRemaining / 60)}:{(timeRemaining % 60).toString().padStart(2, '0')}
                    </Text>
                  </View>
                )}
              </View>
            </View>
          </View>

          {/* Progress Circle */}
          <View style={styles.progressContainer}>
            <AnimatedProgress progress={getProcessStageProgress()} size={140} />
            <View style={styles.progressCenterContent}>
              <Text style={styles.progressPercentage}>{getProcessStageProgress()}%</Text>
              <Text style={styles.progressLabel}>Complete</Text>
            </View>
          </View>

          {/* Enhanced Steps Timeline */}
          <View style={styles.stepsContainer}>
            {getStatusSteps().map((step, index) => {
              const isActive = step.completed;
              const isCurrent = !step.completed && getStatusSteps().findIndex(s => !s.completed) === index;
              
              return (
                <View key={index} style={styles.stepItem}>
                  <View style={styles.stepLineContainer}>
                    {index > 0 && (
                      <View style={[
                        styles.stepLine,
                        isActive && styles.stepLineActive
                      ]} />
                    )}
                    <View style={[
                      styles.stepDot,
                      isActive && styles.stepDotCompleted,
                      isCurrent && styles.stepDotCurrent
                    ]}>
                      {isActive ? (
                        <Ionicons name="checkmark" size={16} color="#FFFFFF" />
                      ) : isCurrent ? (
                        <View style={styles.currentDotInner} />
                      ) : null}
                    </View>
                    {index < getStatusSteps().length - 1 && (
                      <View style={[
                        styles.stepLine,
                        isActive && styles.stepLineActive
                      ]} />
                    )}
                  </View>
                  <Text style={[
                    styles.stepLabel,
                    isActive && styles.stepLabelCompleted,
                    isCurrent && styles.stepLabelCurrent
                  ]}>
                    {step.label}
                  </Text>
                </View>
              );
            })}
          </View>

          {/* Booking Details Card */}
          {!!booking && (
            <View style={styles.bookingDetailsCard}>
              <View style={styles.detailsHeader}>
                <Ionicons name="information-circle" size={20} color={SKY} />
                <Text style={styles.detailsTitle}>Booking Details</Text>
              </View>
              
              <View style={styles.detailsGrid}>
                <View style={styles.detailItem}>
                  <View style={[styles.detailIconWrapper, { backgroundColor: SKY + '20' }]}>
                    <Ionicons name="water" size={18} color={SKY} />
                  </View>
                  <View style={styles.detailContent}>
                    <Text style={styles.detailLabel}>Service</Text>
                    <Text style={styles.detailValue} numberOfLines={1}>
                      {getServiceDisplayName(booking.service_type, booking.service_name || undefined)}
                    </Text>
                  </View>
                </View>

                <View style={styles.detailItem}>
                  <View style={[styles.detailIconWrapper, { backgroundColor: SKY + '20' }]}>
                    <Ionicons name={washHub ? "business" : "location"} size={18} color={SKY} />
                  </View>
                  <View style={styles.detailContent}>
                    <Text style={styles.detailLabel}>
                      {washHub ? 'Wash Hub' : 'Location'}
                    </Text>
                    <Text style={styles.detailValue} numberOfLines={2}>
                      {washHub ? washHub.name : (booking.location_address || '—')}
                    </Text>
                  </View>
                </View>

                <View style={styles.detailItem}>
                  <View style={[styles.detailIconWrapper, { backgroundColor: SKY + '20' }]}>
                    <Ionicons name="wallet" size={18} color={SKY} />
                  </View>
                  <View style={styles.detailContent}>
                    <Text style={styles.detailLabel}>Price</Text>
                    <Text style={styles.detailValue}>£{Number(booking.price ?? 0).toFixed(2)}</Text>
                  </View>
                </View>

                {washHub && washHub.address && (
                  <View style={styles.detailItem}>
                    <View style={[styles.detailIconWrapper, { backgroundColor: SKY + '20' }]}>
                      <Ionicons name="map" size={18} color={SKY} />
                    </View>
                    <View style={styles.detailContent}>
                      <Text style={styles.detailLabel}>Address</Text>
                      <Text style={styles.detailValue} numberOfLines={2}>{washHub.address}</Text>
                    </View>
                  </View>
                )}
              </View>
            </View>
          )}

          {/* Distance/ETA Info for On-Demand */}
          {!washHub && valeterLocation && booking?.location_lat && booking?.location_lng && (
            <View style={styles.etaCard}>
              <View style={styles.etaContent}>
                <Ionicons name="navigate" size={24} color={SKY} />
                <View style={styles.etaTextContainer}>
                  <Text style={styles.etaLabel}>Distance to you</Text>
                  <Text style={styles.etaValue}>
                    {calculateDistance(
                      valeterLocation.latitude,
                      valeterLocation.longitude,
                      booking.location_lat,
                      booking.location_lng
                    ).toFixed(1)} km
                  </Text>
                </View>
              </View>
            </View>
          )}

          {/* Action Buttons */}
          {canCancel && (
            <TouchableOpacity
              activeOpacity={0.9}
              onPress={onPressCancel}
              disabled={cancelling}
              style={[styles.cancelBtn, cancelling && styles.cancelBtnDisabled]}
            >
              {cancelling ? (
                <ActivityIndicator size="small" color="#F9FAFB" />
              ) : (
                <>
                  <Ionicons name="close-circle" size={20} color="#F9FAFB" />
                  <Text style={styles.cancelBtnText}>Cancel Booking</Text>
                </>
              )}
            </TouchableOpacity>
          )}

          {status === 'completed' && (
            <View style={styles.completedActions}>
              <TouchableOpacity
                activeOpacity={0.9}
                onPress={() => router.push(`/owner/wash-rating?washCompletionId=${bookingId}`)}
                style={styles.rateButton}
              >
                <LinearGradient
                  colors={[SKY, '#60A5FA']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.rateButtonGradient}
                >
                  <Ionicons name="star" size={20} color="#FFFFFF" />
                  <Text style={styles.rateButtonText}>Rate & Tip</Text>
                </LinearGradient>
              </TouchableOpacity>
              <TouchableOpacity
                activeOpacity={0.9}
                onPress={() => router.push('/owner/wash-history')}
                style={styles.viewHistoryButton}
              >
                <Text style={styles.viewHistoryText}>View History</Text>
                <Ionicons name="arrow-forward" size={16} color={SKY} />
              </TouchableOpacity>
            </View>
          )}
        </GlassCard>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },

  customerMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  customerMarker: {
    width: 48,
    height: 48,
  },

  valeterMarkerContainer: { 
    alignItems: 'center', 
    justifyContent: 'center',
  },
  valeterMarker: {
    width: 48,
    height: 48,
  },
  valeterPulse: {
    display: 'none',
  },

  hubMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  hubMarker: {
    width: 48,
    height: 48,
    justifyContent: 'center',
    alignItems: 'center',
  },
  hubMarkerImage: {
    width: 48,
    height: 48,
  },
  hubPulse: {
    display: 'none',
  },

  markerLabel: {
    marginTop: 4,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.3)',
  },
  markerLabelText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '700',
  },

  stageIndicator: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
    borderColor: '#FFFFFF',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.6,
    shadowRadius: 6,
  },
  stageIndicatorText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '900',
  },

  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },

  trackingCard: {
    padding: 24,
    backgroundColor: 'transparent',
    borderRadius: 24,
    minHeight: 400,
  },

  timeBarContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    height: 40,
    paddingHorizontal: 20,
    justifyContent: 'center',
    zIndex: 100,
  },
  timerTextOverlay: {
    position: 'absolute',
    left: 20,
    right: 20,
    top: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 101,
    pointerEvents: 'none',
  },
  timerTextSmall: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
    textShadowColor: 'rgba(0, 0, 0, 0.75)',
    textShadowOffset: { width: 0, height: 1 },
    textShadowRadius: 3,
  },
  timeBarBackground: {
    height: 6,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    borderRadius: 3,
    overflow: 'hidden',
  },
  timeBarFill: {
    height: '100%',
    backgroundColor: SKY,
    borderRadius: 3,
  },

  trackingHeader: { 
    marginBottom: 20,
  },
  headerContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  headerTextContainer: {
    flex: 1,
    gap: 8,
  },
  statusTitle: { 
    color: '#F9FAFB', 
    fontSize: 18, 
    fontWeight: '800',
    lineHeight: 24,
    letterSpacing: -0.3,
  },
  timeRemainingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    backgroundColor: SKY + '20',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: SKY + '40',
  },
  timeRemainingText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '800',
    fontVariant: ['tabular-nums'],
  },

  progressContainer: { 
    alignItems: 'center', 
    marginBottom: 24,
    position: 'relative',
    height: 140,
    justifyContent: 'center',
  },
  progressCenterContent: {
    position: 'absolute',
    alignItems: 'center',
    justifyContent: 'center',
    width: 140,
    height: 140,
  },
  progressPercentage: {
    color: '#F9FAFB',
    fontSize: 28,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  progressLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 2,
  },

  stepsContainer: { 
    flexDirection: 'row', 
    justifyContent: 'space-between', 
    marginBottom: 24,
    paddingHorizontal: 4,
  },
  stepItem: { 
    alignItems: 'center', 
    flex: 1,
    gap: 10,
  },
  stepLineContainer: {
    alignItems: 'center',
    width: '100%',
    marginBottom: 4,
  },
  stepLine: {
    position: 'absolute',
    top: 16,
    width: '50%',
    height: 2,
    backgroundColor: 'rgba(135,206,235,0.2)',
    zIndex: 0,
  },
  stepLineActive: {
    backgroundColor: SKY,
  },
  stepDot: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
    zIndex: 1,
  },
  stepDotCompleted: { 
    backgroundColor: SKY,
    borderColor: SKY,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 4,
    elevation: 4,
  },
  stepDotCurrent: {
    backgroundColor: SKY + '30',
    borderColor: SKY,
    borderWidth: 3,
  },
  currentDotInner: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: SKY,
  },
  stepLabel: { 
    color: 'rgba(249,250,251,0.6)', 
    fontSize: 11, 
    textAlign: 'center',
    fontWeight: '600',
  },
  stepLabelCompleted: { 
    color: SKY, 
    fontWeight: '800',
  },
  stepLabelCurrent: {
    color: '#F9FAFB',
    fontWeight: '800',
  },

  bookingDetailsCard: {
    backgroundColor: 'rgba(135,206,235,0.08)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  detailsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
  },
  detailsTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  detailsGrid: {
    gap: 12,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  detailIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  detailContent: {
    flex: 1,
    gap: 4,
  },
  detailLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  detailValue: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    lineHeight: 20,
  },
  etaCard: {
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1.5,
    borderColor: SKY + '40',
  },
  etaContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
  },
  etaTextContainer: {
    flex: 1,
    gap: 4,
  },
  etaLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  etaValue: {
    color: SKY,
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },

  actionsRow: {
    marginTop: 14,
  },
  cancelBtn: {
    height: 52,
    borderRadius: 16,
    backgroundColor: 'rgba(239,68,68,0.9)',
    borderWidth: 1.5,
    borderColor: 'rgba(239,68,68,0.5)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    shadowColor: '#EF4444',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  cancelBtnDisabled: {
    opacity: 0.5,
  },
  cancelBtnText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  completedActions: {
    marginTop: 16,
    gap: 12,
  },
  rateButton: {
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 8,
  },
  rateButtonGradient: {
    height: 52,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingHorizontal: 24,
  },
  rateButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  viewHistoryButton: {
    height: 48,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingHorizontal: 20,
  },
  viewHistoryText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  headerCancelButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(239,68,68,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
  },
  headerExitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
});
