import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import MapView, { Region, Marker, MapPressEvent } from 'react-native-maps';
import * as Location from 'expo-location';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../../src/lib/supabase';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import UberBottomSheet, { BottomSheetState } from '../../../../src/components/booking/UberBottomSheet';
import { detailingServiceOptions } from '../../../../src/constants/serviceOptions';
import AppHeader from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;

type Vehicle = {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
};

type BookingStep = 'location' | 'vehicle' | 'service';

export default function DetailingCreate() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState<BookingStep>('location');
  const [sheetState, setSheetState] = useState<BottomSheetState>('half');
  const [selectedLocation, setSelectedLocation] = useState<{ latitude: number; longitude: number; address: string } | null>(null);
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [valeterCount, setValeterCount] = useState<number>(0);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [mapLocation, setMapLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [address, setAddress] = useState('');
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    loadVehicles();
  }, [user?.id]);

  // Get user location and load nearby detailers
  useEffect(() => {
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') {
          console.warn('Location permission not granted');
          return;
        }

        const location = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Balanced,
        });

        const coords = {
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        };

        setUserLocation(coords);
        setMapLocation(coords);
        setRegion({
          latitude: coords.latitude,
          longitude: coords.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });

        // Reverse geocode to get address and auto-fill location
        try {
          const [result] = await Location.reverseGeocodeAsync(coords);
          if (result) {
            const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current Location';
            setAddress(addr);
            setSelectedLocation({ ...coords, address: addr });
          }
        } catch (e) {
          console.warn('Reverse geocode error:', e);
          setAddress('Current Location');
          setSelectedLocation({ ...coords, address: 'Current Location' });
        }

        // Load nearby detailers count
        await loadNearbyDetailersCount(coords.latitude, coords.longitude);
      } catch (error) {
        console.warn('Error getting location:', error);
      }
    })();
  }, []);

  const loadNearbyDetailersCount = async (latitude: number, longitude: number) => {
    try {
      const { data: presenceData, error } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng')
        .eq('is_online', true);

      if (error) {
        console.warn('Error loading detailers:', error);
        return;
      }

      if (!presenceData || presenceData.length === 0) {
        setValeterCount(0);
        return;
      }

      const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
        const R = 3959;
        const dLat = ((lat2 - lat1) * Math.PI) / 180;
        const dLon = ((lon2 - lon1) * Math.PI) / 180;
        const a =
          Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos((lat1 * Math.PI) / 180) *
            Math.cos((lat2 * Math.PI) / 180) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
      };

      const nearbyDetailers = presenceData.filter((presence) => {
        if (!presence.last_lat || !presence.last_lng) return false;
        const distance = calculateDistance(latitude, longitude, presence.last_lat, presence.last_lng);
        return distance <= 10;
      });

      setValeterCount(nearbyDetailers.length);
    } catch (error) {
      console.warn('Error counting detailers:', error);
    }
  };

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      setVehicles(data || []);
      if (data && data.length > 0) {
        const defaultVehicle = data.find(v => v.is_default) || data[0];
        setSelectedVehicle(defaultVehicle.id);
      }
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleMapPress = async (event: MapPressEvent) => {
    const { latitude, longitude } = event.nativeEvent.coordinate;
    setMapLocation({ latitude, longitude });
    
    try {
      const [result] = await Location.reverseGeocodeAsync({ latitude, longitude });
      const addr = result
        ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim()
        : 'Selected Location';
      
      setSelectedLocation({ latitude, longitude, address: addr });
      setAddress(addr);
      await hapticFeedback('light');
    } catch (error) {
      console.warn('Error reverse geocoding:', error);
      setSelectedLocation({ latitude, longitude, address: 'Selected Location' });
      setAddress('Selected Location');
    }
  };

  const handleUseCurrentLocation = async () => {
    await hapticFeedback('medium');
    if (!userLocation) return;
    
    try {
      const [result] = await Location.reverseGeocodeAsync(userLocation);
      const addr = result
        ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim()
        : 'Current Location';
      
      setSelectedLocation({ ...userLocation, address: addr });
      setMapLocation(userLocation);
      setAddress(addr);
    } catch (error) {
      console.warn('Error reverse geocoding:', error);
      setSelectedLocation({ ...userLocation, address: 'Current Location' });
      setMapLocation(userLocation);
      setAddress('Current Location');
    }
  };

  const handleLocationContinue = async () => {
    if (!selectedLocation) {
      Alert.alert('Location Required', 'Please select a location on the map or use your current location.');
      return;
    }
    await hapticFeedback('medium');
    setCurrentStep('vehicle');
    setSheetState('half');
  };

  const handleVehicleContinue = async () => {
    if (!selectedVehicle) {
      Alert.alert('Vehicle Required', 'Please select a vehicle.');
      return;
    }
    await hapticFeedback('medium');
    setCurrentStep('service');
    setSheetState('half');
  };

  const handleServiceSelect = async (serviceId: string) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
  };

  const handleServiceContinue = async () => {
    if (!selectedService || !selectedVehicle || !selectedLocation) {
      return;
    }
    await hapticFeedback('medium');
    router.push({
      pathname: '/owner/booking/detailing/valeter-selection',
      params: {
        serviceId: selectedService,
        vehicleId: selectedVehicle,
        latitude: selectedLocation.latitude.toString(),
        longitude: selectedLocation.longitude.toString(),
        address: selectedLocation.address,
      },
    });
  };

  const selectedServiceData = detailingServiceOptions.find(s => s.id === selectedService);
  const selectedVehicleData = vehicles.find(v => v.id === selectedVehicle);

  // Preview content for bottom sheet
  const getPreviewContent = () => {
    if (currentStep === 'location') {
      return selectedLocation ? (
        <View style={styles.previewContent}>
          <View style={styles.previewRow}>
            <Ionicons name="location" size={18} color={PREMIUM_PURPLE} />
            <Text style={styles.previewText} numberOfLines={1}>
              {selectedLocation.address.split(',')[0] || 'Selected Location'}
            </Text>
          </View>
          <Text style={styles.previewDetails} numberOfLines={1}>
            {selectedLocation.address}
          </Text>
        </View>
      ) : null;
    } else if (currentStep === 'vehicle') {
      return selectedVehicleData ? (
        <View style={styles.previewContent}>
          <View style={styles.previewRow}>
            <Ionicons name="diamond" size={18} color={PREMIUM_PURPLE} />
            <Text style={styles.previewText} numberOfLines={1}>
              {selectedVehicleData.make} {selectedVehicleData.model}
            </Text>
          </View>
          <Text style={styles.previewDetails}>
            {selectedVehicleData.color} • {selectedVehicleData.registration}
          </Text>
        </View>
      ) : null;
    } else if (currentStep === 'service') {
      return selectedServiceData ? (
        <View style={styles.previewContent}>
          <View style={styles.previewRow}>
            <Ionicons name={selectedServiceData.icon as any} size={18} color={PREMIUM_PURPLE} />
            <Text style={styles.previewText} numberOfLines={1}>
              {selectedServiceData.name}
            </Text>
          </View>
          <Text style={styles.previewDetails}>
            {selectedServiceData.dur} • £{selectedServiceData.price}
          </Text>
        </View>
      ) : null;
    }
    return null;
  };

  // Footer button for bottom sheet
  const getFooterButton = () => {
    if (currentStep === 'location' && selectedLocation) {
      return (
        <TouchableOpacity
          onPress={handleLocationContinue}
          style={styles.footerButton}
          activeOpacity={0.85}
        >
          <LinearGradient
            colors={[PREMIUM_PURPLE, '#7C3AED']}
            style={styles.footerButtonGradient}
          >
            <Text style={styles.footerButtonText}>Continue</Text>
            <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      );
    } else if (currentStep === 'vehicle' && selectedVehicle) {
      return (
        <TouchableOpacity
          onPress={handleVehicleContinue}
          style={styles.footerButton}
          activeOpacity={0.85}
        >
          <LinearGradient
            colors={[PREMIUM_PURPLE, '#7C3AED']}
            style={styles.footerButtonGradient}
          >
            <Text style={styles.footerButtonText}>Continue</Text>
            <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      );
    } else if (currentStep === 'service' && selectedService && selectedVehicle) {
      return (
        <TouchableOpacity
          onPress={handleServiceContinue}
          style={styles.footerButton}
          activeOpacity={0.85}
        >
          <LinearGradient
            colors={[PREMIUM_PURPLE, '#7C3AED']}
            style={styles.footerButtonGradient}
          >
            <Text style={styles.footerButtonText}>Choose {selectedServiceData?.name}</Text>
            <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      );
    }
    return null;
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {/* Fullscreen map - always visible */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          onPress={currentStep === 'location' ? handleMapPress : undefined}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image 
                  source={require('../../../../assets/detailing.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
          {mapLocation && currentStep === 'location' && (
            <Marker coordinate={mapLocation}>
              <Animated.View style={[styles.selectedLocationMarker, { transform: [{ scale: markerPulse }] }]}>
                <View style={styles.selectedLocationMarkerInner}>
                  <Ionicons name="location" size={20} color="#FFFFFF" />
                </View>
              </Animated.View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Header floating over the map */}
      <AppHeader 
        title={
          currentStep === 'location' ? 'Select Location' :
          currentStep === 'vehicle' ? 'Select Vehicle' :
          'Select Service'
        }
        subtitle={
          currentStep === 'location' ? 'Tap on map to choose location' :
          currentStep === 'vehicle' ? 'Swipe to see all vehicles' :
          'Swipe to see all services'
        }
        showBack={currentStep !== 'location'}
        onBack={
          currentStep === 'service' 
            ? () => {
                setCurrentStep('vehicle');
                setSheetState('half');
              }
            : currentStep === 'vehicle' 
            ? () => {
                setCurrentStep('location');
                setSheetState('half');
              }
            : undefined
        }
        rightAction={
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            {currentStep === 'location' && (
              <TouchableOpacity onPress={handleUseCurrentLocation} style={styles.currentLocationButton}>
                <Ionicons name="locate" size={20} color={PREMIUM_PURPLE} />
              </TouchableOpacity>
            )}
            <TouchableOpacity 
              onPress={async () => {
                await hapticFeedback('light');
                router.replace('/owner/owner-dashboard' as any);
              }} 
              style={styles.exitButton}
              activeOpacity={0.7}
            >
              <Ionicons name="close" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        }
      />

      {/* Detailer count badge */}
      <Animated.View
        style={[
          styles.valeterCountBadge,
          {
            opacity: fadeAnim,
            top: insets.top + 92,
          },
        ]}
      >
        <View style={styles.valeterCountContent}>
          <Ionicons name="people-outline" size={18} color={PREMIUM_PURPLE} />
          <Text style={styles.valeterCountText}>{valeterCount}</Text>
        </View>
      </Animated.View>

      {/* Uber-style bottom sheet */}
      <UberBottomSheet
        state={sheetState}
        onStateChange={setSheetState}
        previewContent={getPreviewContent()}
        footerButton={getFooterButton()}
      >
        {/* Step 1: Location Selection */}
        {currentStep === 'location' && (
          <View style={styles.stepContent}>
            <Text style={styles.stepTitle}>Where should we come to you?</Text>
            <Text style={styles.stepSubtitle}>Tap on the map to select your location</Text>
            
            {!selectedLocation && (
              <View style={styles.instructionCard}>
                <Ionicons name="location-outline" size={32} color={PREMIUM_PURPLE} style={{ opacity: 0.6 }} />
                <Text style={styles.instructionText}>Tap anywhere on the map to set your location</Text>
              </View>
            )}

            {selectedLocation && (
              <View style={styles.locationCard}>
                <View style={styles.locationCardHeader}>
                  <View style={styles.locationIconWrapper}>
                    <Ionicons name="location" size={24} color={PREMIUM_PURPLE} />
                  </View>
                  <View style={styles.locationInfo}>
                    <Text style={styles.locationTitle} numberOfLines={2}>
                      {selectedLocation.address}
                    </Text>
                  </View>
                </View>
              </View>
            )}
          </View>
        )}

        {/* Step 2: Vehicle Selection */}
        {currentStep === 'vehicle' && (
          <View style={styles.stepContent}>
            <Text style={styles.stepTitle}>Choose Your Vehicle</Text>
            <Text style={styles.stepSubtitle}>Swipe horizontally to see all options</Text>
            
            {loading ? (
              <View style={styles.loadingContainer}>
                <Text style={styles.loadingText}>Loading vehicles...</Text>
              </View>
            ) : vehicles.length === 0 ? (
              <View style={styles.emptyContainer}>
                <Ionicons name="diamond-outline" size={64} color={PREMIUM_PURPLE} style={{ opacity: 0.5 }} />
                <Text style={styles.emptyTitle}>No vehicles found</Text>
                <Text style={styles.emptySubtext}>Add a vehicle to continue booking</Text>
                <TouchableOpacity
                  onPress={() => router.push('/owner/settings/vehicle-management')}
                  style={styles.addButton}
                  activeOpacity={0.85}
                >
                  <LinearGradient
                    colors={[PREMIUM_PURPLE, '#7C3AED']}
                    style={styles.addButtonGradient}
                  >
                    <Ionicons name="add-circle" size={20} color="#FFFFFF" />
                    <Text style={styles.addButtonText}>Add Vehicle</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            ) : (
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.horizontalScrollContent}
                snapToInterval={width - 40}
                decelerationRate="fast"
                pagingEnabled
                snapToAlignment="start"
              >
                {vehicles.map((vehicle) => {
                  const isSelected = selectedVehicle === vehicle.id;
                  return (
                    <View key={vehicle.id} style={[styles.horizontalCard, { width: width - 40 }]}>
                      <GlassCard
                        onPress={() => {
                          hapticFeedback('light');
                          setSelectedVehicle(vehicle.id);
                        }}
                        style={[styles.vehicleCard, isSelected && styles.vehicleCardSelected]}
                        borderColor={isSelected ? PREMIUM_PURPLE : 'rgba(139,92,246,0.25)'}
                      >
                        <LinearGradient
                          colors={isSelected ? [PREMIUM_PURPLE + '20', PREMIUM_PURPLE + '10'] : ['transparent', 'transparent']}
                          style={StyleSheet.absoluteFill}
                        />
                        <View style={styles.vehicleCardContent}>
                          <View style={[styles.vehicleIconWrapper, isSelected && styles.vehicleIconWrapperSelected]}>
                            <Ionicons name="diamond" size={28} color={isSelected ? PREMIUM_PURPLE : 'rgba(139,92,246,0.8)'} />
                          </View>
                          <View style={styles.vehicleInfo}>
                            <View style={styles.vehicleNameRow}>
                              <Text style={styles.vehicleName} numberOfLines={1}>
                                {vehicle.make} {vehicle.model}
                              </Text>
                              {vehicle.is_default && (
                                <View style={styles.defaultBadge}>
                                  <Ionicons name="star" size={10} color="#10B981" />
                                  <Text style={styles.defaultBadgeText}>Default</Text>
                                </View>
                              )}
                              {isSelected && (
                                <View style={styles.selectedCheck}>
                                  <Ionicons name="checkmark-circle" size={24} color={PREMIUM_PURPLE} />
                                </View>
                              )}
                            </View>
                            <View style={styles.vehicleDetailsRow}>
                              <View style={styles.detailItem}>
                                <Ionicons name="color-palette-outline" size={14} color={PREMIUM_PURPLE} />
                                <Text style={styles.detailText}>{vehicle.color}</Text>
                              </View>
                              <View style={styles.detailDivider} />
                              <View style={styles.detailItem}>
                                <Ionicons name="document-text-outline" size={14} color={PREMIUM_PURPLE} />
                                <Text style={styles.detailText}>{vehicle.registration}</Text>
                              </View>
                            </View>
                            <View style={styles.vehicleTypeRow}>
                              <Ionicons name="information-circle-outline" size={12} color="rgba(249,250,251,0.6)" />
                              <Text style={styles.vehicleTypeText}>{vehicle.type}</Text>
                            </View>
                          </View>
                        </View>
                      </GlassCard>
                    </View>
                  );
                })}
              </ScrollView>
            )}
          </View>
        )}

        {/* Step 3: Service Selection */}
        {currentStep === 'service' && (
          <View style={styles.stepContent}>
            <Text style={styles.stepTitle}>Choose Your Service</Text>
            <Text style={styles.stepSubtitle}>Swipe horizontally to see all options</Text>
            
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.horizontalScrollContent}
              snapToInterval={width - 40}
              decelerationRate="fast"
              pagingEnabled
              snapToAlignment="start"
            >
              {detailingServiceOptions.map((service) => {
                const isSelected = selectedService === service.id;
                return (
                  <View key={service.id} style={[styles.horizontalCard, { width: width - 40 }]}>
                    <GlassCard
                      onPress={() => handleServiceSelect(service.id)}
                      style={[styles.serviceCard, isSelected && styles.serviceCardSelected]}
                      borderColor={isSelected ? service.colors[0] : 'rgba(139,92,246,0.25)'}
                    >
                      <LinearGradient
                        colors={isSelected ? [service.colors[0] + '20', service.colors[1] + '10'] : ['transparent', 'transparent']}
                        style={StyleSheet.absoluteFill}
                      />
                      <View style={styles.serviceCardContent}>
                        <View style={styles.serviceHeader}>
                          <View style={[styles.serviceIconWrapper, { backgroundColor: service.colors[0] + '20' }]}>
                            <Ionicons name={service.icon as any} size={28} color={service.colors[0]} />
                          </View>
                          <View style={styles.serviceInfo}>
                            <Text style={styles.serviceName} numberOfLines={1}>
                              {service.name}
                            </Text>
                            <Text style={styles.serviceDesc} numberOfLines={2}>
                              {service.desc}
                            </Text>
                          </View>
                          <View style={styles.servicePrice}>
                            <Text style={styles.servicePriceText}>£{service.price}</Text>
                          </View>
                        </View>
                        
                        <View style={styles.serviceDetails}>
                          <View style={styles.serviceDetailItem}>
                            <Ionicons name="time-outline" size={14} color={PREMIUM_PURPLE} />
                            <Text style={styles.serviceDetailText}>{service.dur}</Text>
                          </View>
                          <View style={styles.serviceDetailItem}>
                            <Ionicons name="car-outline" size={14} color={PREMIUM_PURPLE} />
                            <Text style={styles.serviceDetailText}>All sizes</Text>
                          </View>
                        </View>

                        {isSelected && (
                          <View style={styles.selectedIndicator}>
                            <Ionicons name="checkmark-circle" size={24} color={service.colors[0]} />
                            <Text style={styles.selectedText}>Selected</Text>
                          </View>
                        )}
                      </View>
                    </GlassCard>
                  </View>
                );
              })}
            </ScrollView>
          </View>
        )}
      </UberBottomSheet>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  selectedLocationMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedLocationMarkerInner: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: PREMIUM_PURPLE,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: PREMIUM_PURPLE,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
  },
  valeterCountBadge: {
    position: 'absolute',
    right: 16,
    zIndex: 1000,
  },
  valeterCountContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(15, 23, 42, 0.7)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
  },
  valeterCountText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  currentLocationButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(15, 23, 42, 0.7)',
    borderWidth: 1.5,
    borderColor: 'rgba(139,92,246,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 4,
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  previewContent: {
    gap: 6,
  },
  previewRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  previewText: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    flex: 1,
  },
  previewDetails: {
    color: PREMIUM_PURPLE,
    fontSize: 13,
    fontWeight: '600',
    marginLeft: 26,
  },
  footerButton: {
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: PREMIUM_PURPLE,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 12,
  },
  footerButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 24,
    gap: 10,
  },
  footerButtonText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: 0.3,
  },
  stepContent: {
    gap: 16,
  },
  stepTitle: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: -0.5,
    marginBottom: 4,
  },
  stepSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  instructionCard: {
    alignItems: 'center',
    padding: 32,
    backgroundColor: 'rgba(139,92,246,0.1)',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.2)',
    gap: 12,
  },
  instructionText: {
    color: PREMIUM_PURPLE,
    fontSize: 15,
    fontWeight: '700',
    textAlign: 'center',
  },
  locationCard: {
    marginTop: 8,
  },
  locationCardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 16,
    backgroundColor: 'rgba(139,92,246,0.1)',
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.2)',
  },
  locationIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: PREMIUM_PURPLE + '20',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: PREMIUM_PURPLE,
  },
  locationInfo: {
    flex: 1,
  },
  locationTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    lineHeight: 22,
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
  },
  loadingText: {
    color: PREMIUM_PURPLE,
    fontSize: 15,
    fontWeight: '700',
  },
  emptyContainer: {
    alignItems: 'center',
    padding: 40,
    gap: 16,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
  },
  emptySubtext: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
  },
  addButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginTop: 8,
    elevation: 8,
    shadowColor: PREMIUM_PURPLE,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
    gap: 8,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  horizontalScrollContent: {
    paddingRight: 20,
    gap: 12,
  },
  horizontalCard: {
    marginRight: 12,
  },
  vehicleCard: {
    padding: 20,
    borderRadius: 20,
  },
  vehicleCardSelected: {
    elevation: 12,
    shadowColor: PREMIUM_PURPLE,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    borderWidth: 2,
  },
  vehicleCardContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 16,
  },
  vehicleIconWrapper: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(139,92,246,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(139,92,246,0.3)',
  },
  vehicleIconWrapperSelected: {
    backgroundColor: PREMIUM_PURPLE + '25',
    borderColor: PREMIUM_PURPLE,
  },
  vehicleInfo: {
    flex: 1,
    gap: 10,
  },
  vehicleNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
  },
  vehicleName: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
    flex: 1,
  },
  defaultBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.4)',
    marginLeft: 8,
  },
  defaultBadgeText: {
    color: '#10B981',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  selectedCheck: {
    marginLeft: 8,
  },
  vehicleDetailsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(139,92,246,0.12)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.2)',
  },
  detailDivider: {
    width: 1,
    height: 20,
    backgroundColor: 'rgba(139,92,246,0.3)',
  },
  detailText: {
    color: PREMIUM_PURPLE,
    fontSize: 13,
    fontWeight: '700',
  },
  vehicleTypeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  vehicleTypeText: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    fontWeight: '600',
  },
  serviceCard: {
    padding: 20,
    borderRadius: 20,
  },
  serviceCardSelected: {
    elevation: 12,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    borderWidth: 2,
  },
  serviceCardContent: {
    gap: 16,
  },
  serviceHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  serviceIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(139,92,246,0.3)',
  },
  serviceInfo: {
    flex: 1,
    gap: 6,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  serviceDesc: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
  },
  servicePrice: {
    alignItems: 'flex-end',
  },
  servicePriceText: {
    color: PREMIUM_PURPLE,
    fontSize: 24,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  serviceDetails: {
    flexDirection: 'row',
    gap: 12,
    flexWrap: 'wrap',
  },
  serviceDetailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(139,92,246,0.12)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.2)',
  },
  serviceDetailText: {
    color: PREMIUM_PURPLE,
    fontSize: 13,
    fontWeight: '700',
  },
  selectedIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    marginTop: 8,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
  },
  selectedText: {
    color: PREMIUM_PURPLE,
    fontSize: 14,
    fontWeight: '800',
  },
});
