import React, { useEffect, useState, useRef, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Animated,
  Alert,
  Image,
  ScrollView,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import * as Location from 'expo-location';
import MapView, { Region, Marker } from 'react-native-maps';

import { supabase } from '../../../../src/lib/supabase';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import GlassCard from '../../../../src/components/booking/GlassCard';
import StatusDot, { StatusType } from '../../../../src/components/shared/StatusDot';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { colors } from '../../../../src/constants/colors';
import { Hub } from '../../../../src/types/booking';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../components/NavigationTab';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const SKY = colors.SKY;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;
const LIGHT_SKY = colors.LIGHT_SKY;

type LatLng = { latitude: number; longitude: number };

// Local extension for this screen (no need to touch shared Hub type)
type HubRow = Hub & {
  eco_washing?: boolean | null;
  detailing_offered?: boolean | null;
};

const safeBool = (v: any) => v === true;

export default function DetailingPhysicalLocation() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ vehicleId?: string }>();
  const { coords } = useLiveLocation();
  const vehicleId = params.vehicleId;

  const [loading, setLoading] = useState(true);
  const [hubs, setHubs] = useState<HubRow[]>([]);
  const [selectedHub, setSelectedHub] = useState<HubRow | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: coords?.latitude || 51.5074,
    longitude: coords?.longitude || -0.1278,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  });
  const [userLocation, setUserLocation] = useState<LatLng | null>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();

    loadHubs();
    getCurrentLocation();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (coords) {
      setUserLocation(coords);
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.05,
        longitudeDelta: 0.05,
      });
    }
  }, [coords]);

  const normalizeHubs = (rows: any[]): HubRow[] =>
    (rows || [])
      .map((h) => ({
        ...h,
        latitude: Number(h.latitude),
        longitude: Number(h.longitude),
        eco_washing: safeBool(h.eco_washing),
        detailing_offered: safeBool(h.detailing_offered),
      }))
      .filter((h) => Number.isFinite(h.latitude) && Number.isFinite(h.longitude));

  const loadHubs = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude,status,eco_washing,detailing_offered')
        .eq('detailing_offered', true);

      if (error) throw error;
      const normalized = normalizeHubs(data || []);
      setHubs(normalized);

      // Update map region to fit all hubs and user location
      if (normalized.length > 0) {
        const lats = normalized.map(h => h.latitude).filter(Number.isFinite);
        const lngs = normalized.map(h => h.longitude).filter(Number.isFinite);
        
        // Include user location if available
        if (coords) {
          lats.push(coords.latitude);
          lngs.push(coords.longitude);
        }
        
        if (lats.length > 0 && lngs.length > 0) {
          const minLat = Math.min(...lats);
          const maxLat = Math.max(...lats);
          const minLng = Math.min(...lngs);
          const maxLng = Math.max(...lngs);
          
          // Add padding to ensure all markers are visible
          const latPadding = (maxLat - minLat) * 0.2;
          const lngPadding = (maxLng - minLng) * 0.2;
          
          setRegion({
            latitude: (minLat + maxLat) / 2,
            longitude: (minLng + maxLng) / 2,
            latitudeDelta: Math.max((maxLat - minLat) * 1.4 + latPadding, 0.1),
            longitudeDelta: Math.max((maxLng - minLng) * 1.4 + lngPadding, 0.1),
          });
        }
      }
    } catch (err: any) {
      Alert.alert('Hubs Error', err?.message || 'Failed to load hubs');
      setHubs([]);
    } finally {
      setLoading(false);
    }
  };

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };
      setUserLocation(coords);
    } catch {}
  };

  const calculateDistance = useCallback(
    (hub: HubRow) => {
      if (!coords || !hub.latitude || !hub.longitude) return null;
      const toRad = (v: number) => (v * Math.PI) / 180;
      const R = 3959;

      const dLat = toRad(hub.latitude - coords.latitude);
      const dLon = toRad(hub.longitude - coords.longitude);
      const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(toRad(coords.latitude)) *
          Math.cos(toRad(hub.latitude)) *
          Math.sin(dLon / 2) ** 2;

      return (R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)))).toFixed(1);
    },
    [coords]
  );

  const filteredHubs = useMemo(() => {
    if (!coords) return hubs;
    return hubs
      .map(hub => ({ hub, distance: calculateDistance(hub) }))
      .filter(({ distance }) => distance && Number(distance) <= 10)
      .sort((a, b) => Number(a.distance) - Number(b.distance))
      .map(({ hub }) => hub);
  }, [hubs, coords, calculateDistance]);

  const getStatusType = (status?: string | null): StatusType => {
    if (!status) return 'offline';
    if (status.toLowerCase().includes('busy')) return 'busy';
    if (status.toLowerCase().includes('available')) return 'available';
    return 'offline';
  };

  const handleHubSelect = (hub: HubRow) => {
    setSelectedHub(hub);
    if (hub.latitude && hub.longitude) {
      setRegion({
        latitude: hub.latitude,
        longitude: hub.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    }
  };

  const handleContinue = () => {
    if (!selectedHub || !vehicleId) return;
    router.push({
      pathname: '/owner/booking/detailing/service',
      params: { locationId: selectedHub.id, vehicleId },
    });
  };

  const handleExitBooking = async () => {
    await hapticFeedback('light');
    router.replace('/owner/owner-dashboard' as any);
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (coords) {
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.05,
        longitudeDelta: 0.05,
      });
    } else if (userLocation) {
      setRegion({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.05,
        longitudeDelta: 0.05,
      });
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
          zIndex={0}
        >
          {/* User location marker */}
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image 
                  source={require('../../../../assets/washing.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {/* Hub markers - show ALL hubs on map, not just filtered ones */}
          {hubs.map((hub) => {
            if (!hub.latitude || !hub.longitude) return null;
            const isSelected = selectedHub?.id === hub.id;
            const distance = calculateDistance(hub);
            const isWithinRange = distance && Number(distance) <= 10;
            
            return (
              <Marker
                key={hub.id}
                coordinate={{ latitude: hub.latitude, longitude: hub.longitude }}
                onPress={() => handleHubSelect(hub)}
              >
                <View style={styles.hubMarkerContainer}>
                  <Image 
                    source={require('../../../../assets/detailing.png')} 
                    style={[
                      styles.hubMarkerImage,
                      isSelected && styles.hubMarkerImageSelected,
                      !isWithinRange && styles.hubMarkerImageOutOfRange
                    ]}
                    resizeMode="contain"
                  />
                  {getStatusType(hub.status) === 'available' && (
                    <View style={styles.hubOnlineBadge}>
                      <View style={styles.hubOnlineDot} />
                    </View>
                  )}
                  {!isWithinRange && (
                    <View style={styles.outOfRangeBadge}>
                      <Text style={styles.outOfRangeText}>Far</Text>
                    </View>
                  )}
                </View>
              </Marker>
            );
          })}
        </MapView>
      </View>

      {/* Header floating over the map */}
      <AppHeader 
        title="Nearby Detail Hubs" 
        subtitle="Select a premium detailing hub near you"
        showBack={true}
        onBack={() => router.back()}
        rightAction={
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            <TouchableOpacity 
              onPress={handleRecenter} 
              style={styles.recenterButton}
              activeOpacity={0.7}
            >
              <Ionicons name="locate" size={22} color={PREMIUM_PURPLE} />
            </TouchableOpacity>
            <TouchableOpacity 
              onPress={handleExitBooking} 
              style={styles.exitButton}
              activeOpacity={0.7}
            >
              <Ionicons name="close" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        }
      />

      {/* Hub cards - floating style matching on-demand cards */}
      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            paddingBottom: Math.max(insets.bottom, 14) + 14 + TAB_BAR_TOTAL_HEIGHT + 12,
          },
        ]}
      >
        {loading ? (
          <GlassCard style={styles.card}>
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color={PREMIUM_PURPLE} />
              <Text style={styles.loadingText}>Finding nearby hubs...</Text>
            </View>
          </GlassCard>
        ) : filteredHubs.length === 0 ? (
          <GlassCard style={styles.card}>
            <View style={styles.emptyContent}>
              <Ionicons name="map-outline" size={48} color={PREMIUM_PURPLE} style={{ opacity: 0.5 }} />
              <Text style={styles.emptyText}>No hubs available</Text>
              <Text style={styles.emptySubtext}>Try again later or adjust your location</Text>
            </View>
          </GlassCard>
        ) : (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.cardsScrollContent}
            snapToInterval={width - 32}
            decelerationRate="fast"
            pagingEnabled
            snapToAlignment="start"
          >
            {filteredHubs.map((hub) => {
              const isSelected = selectedHub?.id === hub.id;
              const distance = calculateDistance(hub);
              
              return (
                <View key={hub.id} style={[styles.cardWrapper, { width: width - 32 }]}>
                  <GlassCard
                    onPress={() => handleHubSelect(hub)}
                    style={[styles.card, isSelected && styles.cardSelected]}
                    borderColor={isSelected ? PREMIUM_PURPLE : 'rgba(139,92,246,0.3)'}
                    accountType="customer"
                  >
                    <LinearGradient
                      colors={isSelected ? [PREMIUM_PURPLE + '30', PREMIUM_PURPLE + '20'] : ['transparent', 'transparent']}
                      style={StyleSheet.absoluteFill}
                    />
                    
                    <View style={styles.hubHeader}>
                      <View style={styles.hubIconWrapper}>
                        <Ionicons name="business" size={24} color={PREMIUM_PURPLE} />
                      </View>
                      <View style={styles.hubInfo}>
                        <View style={styles.hubNameRow}>
                          <Text style={styles.hubName}>{hub.name}</Text>
                          {isSelected && (
                            <View style={styles.selectedCheck}>
                              <Ionicons name="checkmark-circle" size={24} color={PREMIUM_PURPLE} />
                              <Text style={styles.selectedLabel}>Selected</Text>
                            </View>
                          )}
                        </View>
                        <View style={styles.verifiedRow}>
                          <Ionicons name="shield-checkmark" size={12} color={PREMIUM_PURPLE} />
                          <Text style={styles.verifiedText}>Premium Detail Hub</Text>
                        </View>
                      </View>
                    </View>

                    <View style={styles.hubDetails}>
                      {distance && (
                        <View style={styles.infoRow}>
                          <Ionicons name="navigate" size={16} color={PREMIUM_PURPLE} />
                          <Text style={styles.distanceText}>{distance} miles away</Text>
                        </View>
                      )}
                      <View style={styles.infoRow}>
                        <Ionicons name="location" size={14} color="rgba(139,92,246,0.6)" />
                        <Text style={styles.addressText} numberOfLines={2}>{hub.address}</Text>
                      </View>
                      <View style={styles.statusRow}>
                        <View style={[
                          styles.statusPill,
                          getStatusType(hub.status) === 'available' && styles.statusPillAvailable,
                          getStatusType(hub.status) === 'busy' && styles.statusPillBusy,
                          getStatusType(hub.status) === 'offline' && styles.statusPillOffline,
                        ]}>
                          <View style={[
                            styles.statusDot,
                            getStatusType(hub.status) === 'available' && styles.statusDotAvailable,
                            getStatusType(hub.status) === 'busy' && styles.statusDotBusy,
                            getStatusType(hub.status) === 'offline' && styles.statusDotOffline,
                          ]} />
                          <Text style={[
                            styles.statusText,
                            getStatusType(hub.status) === 'available' && styles.statusTextAvailable,
                            getStatusType(hub.status) === 'busy' && styles.statusTextBusy,
                            getStatusType(hub.status) === 'offline' && styles.statusTextOffline,
                          ]}>
                            {getStatusType(hub.status) === 'available' ? 'Available' : 
                             getStatusType(hub.status) === 'busy' ? 'Busy' : 'Offline'}
                          </Text>
                        </View>
                      </View>
                    </View>

                    {isSelected && (
                      <View style={styles.actionsRow}>
                        <TouchableOpacity
                          onPress={handleContinue}
                          style={styles.continueBtn}
                          activeOpacity={0.9}
                        >
                          <LinearGradient
                            colors={[PREMIUM_PURPLE, '#7C3AED']}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 0 }}
                            style={styles.continueBtnGradient}
                          >
                            <Text style={styles.continueBtnText}>Continue</Text>
                            <Ionicons name="arrow-forward" size={20} color="#FFFFFF" style={{ fontWeight: '700' }} />
                          </LinearGradient>
                        </TouchableOpacity>
                      </View>
                    )}
                  </GlassCard>
                </View>
              );
            })}
          </ScrollView>
        )}
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 10,
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  hubMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    zIndex: 10,
  },
  hubMarkerImage: {
    width: 48,
    height: 48,
  },
  hubMarkerImageSelected: {
    width: 56,
    height: 56,
  },
  hubMarkerImageOutOfRange: {
    opacity: 0.6,
    tintColor: '#9CA3AF',
  },
  hubOnlineBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: '#10B981',
    borderWidth: 2,
    borderColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  hubOnlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#FFFFFF',
  },
  outOfRangeBadge: {
    position: 'absolute',
    top: -20,
    backgroundColor: 'rgba(0,0,0,0.7)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 4,
  },
  outOfRangeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '600',
  },
  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(139,92,246,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  cardWrapper: {
    marginRight: 12,
    marginLeft: 0,
  },
  card: {
    padding: 20,
    minHeight: 200,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderWidth: 2,
    borderColor: 'rgba(139,92,246,0.2)',
  },
  cardSelected: {
    elevation: 12,
    shadowColor: PREMIUM_PURPLE,
    shadowOpacity: 0.4,
    borderWidth: 1.5,
  },
  loadingContainer: {
    padding: 32,
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: PREMIUM_PURPLE,
    fontSize: 14,
    fontWeight: '600',
  },
  emptyContent: {
    padding: 32,
    alignItems: 'center',
    gap: 12,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  emptySubtext: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 13,
    textAlign: 'center',
  },
  hubHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 16,
  },
  hubIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: PREMIUM_PURPLE + '20',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: PREMIUM_PURPLE + '40',
  },
  hubInfo: {
    flex: 1,
  },
  hubNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  hubName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    flex: 1,
  },
  selectedCheck: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  selectedLabel: {
    color: PREMIUM_PURPLE,
    fontSize: 12,
    fontWeight: '700',
  },
  verifiedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  verifiedText: {
    color: PREMIUM_PURPLE,
    fontSize: 12,
    fontWeight: '600',
  },
  hubDetails: {
    gap: 10,
    marginBottom: 16,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  distanceText: {
    color: PREMIUM_PURPLE,
    fontSize: 14,
    fontWeight: '700',
  },
  addressText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    flex: 1,
  },
  statusRow: {
    marginTop: 4,
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(156, 163, 175, 0.2)',
    alignSelf: 'flex-start',
  },
  statusPillAvailable: {
    backgroundColor: 'rgba(16, 185, 129, 0.2)',
  },
  statusPillBusy: {
    backgroundColor: 'rgba(239, 68, 68, 0.2)',
  },
  statusPillOffline: {
    backgroundColor: 'rgba(156, 163, 175, 0.2)',
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#9CA3AF',
  },
  statusDotAvailable: {
    backgroundColor: '#10B981',
  },
  statusDotBusy: {
    backgroundColor: '#EF4444',
  },
  statusDotOffline: {
    backgroundColor: '#9CA3AF',
  },
  statusText: {
    color: '#9CA3AF',
    fontSize: 12,
    fontWeight: '600',
  },
  statusTextAvailable: {
    color: '#10B981',
  },
  statusTextBusy: {
    color: '#EF4444',
  },
  statusTextOffline: {
    color: '#9CA3AF',
  },
  actionsRow: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(139,92,246,0.2)',
  },
  continueBtn: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  continueBtnGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 8,
  },
  continueBtnText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});
