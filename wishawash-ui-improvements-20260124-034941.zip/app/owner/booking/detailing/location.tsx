import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import * as Location from 'expo-location';
import Slider from '@react-native-community/slider';

import { supabase } from '../../../../src/lib/supabase';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { Hub } from '../../../../src/types/booking';

const { height } = Dimensions.get('window');
const BG = colors.BG;
const SKY = colors.SKY;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;
const LIGHT_SKY = colors.LIGHT_SKY;

function toRad(value: number) {
  return (value * Math.PI) / 180;
}

function distanceMiles(aLat: number, aLng: number, bLat: number, bLng: number) {
  const R = 3959; // miles
  const dLat = toRad(bLat - aLat);
  const dLon = toRad(bLng - aLng);
  const lat1 = toRad(aLat);
  const lat2 = toRad(bLat);

  const aa =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.sin(dLon / 2) * Math.sin(dLon / 2) * Math.cos(lat1) * Math.cos(lat2);

  const c = 2 * Math.atan2(Math.sqrt(aa), Math.sqrt(1 - aa));
  return R * c;
}

export default function DetailingLocation() {
  const params = useLocalSearchParams();
  const vehicleId = params.vehicleId as string;
  const { coords } = useLiveLocation();

  const [selectedHub, setSelectedHub] = useState<Hub | null>(null);

  const [loading, setLoading] = useState(true);
  const [loadingLocation, setLoadingLocation] = useState(false);

  const [hubs, setHubs] = useState<Hub[]>([]);
  const [radiusMilesState, setRadiusMilesState] = useState(10); // slider value

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const listAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(listAnim, { toValue: 1, tension: 50, friction: 8, useNativeDriver: true }),
    ]).start();

    loadHubs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const loadHubs = async () => {
    try {
      setLoading(true);

      // 1) find location IDs that offer detailing (enabled)
      // If your schema uses service_type/service_key instead of service_name, change the filter below.
      const { data: svcRows, error: svcErr } = await supabase
        .from('location_services')
        .select('location_id, service_name, is_enabled')
        .eq('is_enabled', true);

      if (svcErr) throw svcErr;

      const detailingLocationIds = new Set<string>();
      (svcRows || []).forEach((r: any) => {
        const name = String(r.service_name || '').toLowerCase();
        if (name.includes('detail')) detailingLocationIds.add(r.location_id);
      });

      if (detailingLocationIds.size === 0) {
        setHubs([]);
        return;
      }

      const ids = Array.from(detailingLocationIds);

      // 2) load only those hubs
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude,status,wait_time_minutes,organization_id')
        .in('id', ids)
        .order('created_at', { ascending: true });

      if (error) throw error;

      setHubs((data || []) as Hub[]);
    } catch (err) {
      console.error('[detailing-location] load hubs error', err);
      setHubs([]);
    } finally {
      setLoading(false);
    }
  };

  const handleUseCurrentLocation = async () => {
    await hapticFeedback('medium');

    try {
      setLoadingLocation(true);
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Location', 'Location permission not granted.');
        return;
      }
      await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      // your useLiveLocation hook should pick this up
    } catch (e) {
      console.error('[detailing-location] getCurrentLocation error', e);
      Alert.alert('Location', 'Could not fetch your current location.');
    } finally {
      setLoadingLocation(false);
    }
  };

  const formatWait = (minutes?: number | null) => {
    if (!minutes) return 'Instant availability';
    if (minutes < 15) return 'Under 15 min wait';
    return `${minutes} min wait`;
  };

  const hubsWithDistance = useMemo(() => {
    const hasCoords = !!coords?.latitude && !!coords?.longitude;

    return hubs
      .map((hub) => {
        const hasHubCoords = !!hub.latitude && !!hub.longitude;
        const dist =
          hasCoords && hasHubCoords
            ? distanceMiles(coords!.latitude, coords!.longitude, hub.latitude!, hub.longitude!)
            : null;

        return {
          hub,
          distance: dist, // number | null
        };
      })
      .filter(({ hub, distance }) => {
        // if we have coords, apply radius filter; if not, show everything with coords
        if (coords?.latitude && coords?.longitude) {
          if (distance == null) return false;
          return distance <= radiusMilesState;
        }
        // no coords available: show hubs that at least have coordinates
        return !!hub.latitude && !!hub.longitude;
      })
      .sort((a, b) => {
        const ad = a.distance ?? 999999;
        const bd = b.distance ?? 999999;
        return ad - bd;
      });
  }, [hubs, coords?.latitude, coords?.longitude, radiusMilesState]);

  const handleSelectHub = async (hub: Hub) => {
    await hapticFeedback('light');
    setSelectedHub(hub);
  };

  const handleContinue = async () => {
    if (!selectedHub) {
      Alert.alert('Hub Required', 'Please select a hub from the list.');
      return;
    }
    await hapticFeedback('medium');

    router.push({
      pathname: '/owner/booking/detailing/service',
      params: {
        locationId: selectedHub.id,
        vehicleId: vehicleId || '',
      },
    });
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={[BG, colors.premiumPurple]} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Choose detailing hub"
        rightAction={
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            <TouchableOpacity
              onPress={handleUseCurrentLocation}
              style={styles.currentLocationButton}
              activeOpacity={0.85}
            >
              {loadingLocation ? (
                <ActivityIndicator size="small" color={SKY} />
              ) : (
                <Ionicons name="locate" size={20} color={SKY} />
              )}
            </TouchableOpacity>
            <TouchableOpacity 
              onPress={async () => {
                await hapticFeedback('light');
                router.replace('/owner/owner-dashboard' as any);
              }} 
              style={styles.exitButton}
              activeOpacity={0.7}
            >
              <Ionicons name="close" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        }
      />

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={PREMIUM_PURPLE} />
          <Text style={styles.loadingText}>Finding detailing hubs…</Text>
        </View>
      ) : (
        <Animated.View
          style={[
            styles.content,
            {
              opacity: fadeAnim,
              transform: [{ scale: listAnim }],
            },
          ]}
        >
          <ScrollView
            showsVerticalScrollIndicator={false}
            contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET + 8 }]}
          >
            {/* Radius slider */}
            <GlassCard style={styles.radiusCard}>
              <View style={styles.radiusHeader}>
                <View style={styles.radiusTitleRow}>
                  <Ionicons name="radio-outline" size={18} color={PREMIUM_PURPLE} />
                  <Text style={styles.radiusTitle}>Search radius</Text>
                </View>

                <View style={styles.radiusPill}>
                  <Text style={styles.radiusPillText}>{Math.round(radiusMilesState)} mi</Text>
                </View>
              </View>

              <Text style={styles.radiusSub}>
                {coords?.latitude
                  ? 'Slide to widen or narrow results around you.'
                  : 'Tap locate to use radius filtering.'}
              </Text>

              <View style={styles.sliderWrap}>
                <Text style={styles.sliderEdge}>1</Text>
                <Slider
                  style={{ flex: 1 }}
                  minimumValue={1}
                  maximumValue={50}
                  step={1}
                  value={radiusMilesState}
                  onValueChange={(v) => setRadiusMilesState(v)}
                  minimumTrackTintColor={PREMIUM_PURPLE}
                  maximumTrackTintColor={'rgba(255,255,255,0.18)'}
                  thumbTintColor={LIGHT_SKY}
                  disabled={!coords?.latitude}
                />
                <Text style={styles.sliderEdge}>50</Text>
              </View>
            </GlassCard>

            {/* List */}
            <View style={styles.sectionHead}>
              <Text style={styles.sectionTitle}>Available hubs</Text>
              <Text style={styles.sectionSub}>
                {coords?.latitude
                  ? `${hubsWithDistance.length} within ${Math.round(radiusMilesState)} miles`
                  : `${hubsWithDistance.length} hubs`}
              </Text>
            </View>

            {hubsWithDistance.length === 0 ? (
              <GlassCard style={styles.emptyCard}>
                <View style={styles.emptyContent}>
                  <Ionicons name="diamond-outline" size={44} color={PREMIUM_PURPLE} style={{ opacity: 0.6 }} />
                  <Text style={styles.emptyText}>No hubs found</Text>
                  <Text style={styles.emptySubtext}>
                    {coords?.latitude
                      ? 'Try increasing the radius.'
                      : 'Tap locate to use your current location.'}
                  </Text>
                </View>
              </GlassCard>
            ) : (
              <View style={{ gap: 12 }}>
                {hubsWithDistance.map(({ hub, distance }) => {
                  const isSelected = selectedHub?.id === hub.id;

                  return (
                    <GlassCard
                      key={hub.id}
                      onPress={() => handleSelectHub(hub)}
                      style={[styles.hubCard, isSelected && styles.hubCardSelected]}
                      borderColor={isSelected ? PREMIUM_PURPLE : 'rgba(139,92,246,0.28)'}
                    >
                      <View style={styles.hubTopRow}>
                        <View style={styles.hubIcon}>
                          <Ionicons name="diamond" size={18} color={PREMIUM_PURPLE} />
                        </View>

                        <View style={{ flex: 1 }}>
                          <Text style={styles.hubName} numberOfLines={1}>
                            {hub.name}
                          </Text>
                          <Text style={styles.hubAddress} numberOfLines={2}>
                            {hub.address || 'Address coming soon'}
                          </Text>
                        </View>

                        <View style={styles.rightCol}>
                          {distance != null && (
                            <View style={styles.distancePill}>
                              <Ionicons name="navigate" size={12} color={BG} />
                              <Text style={styles.distanceText}>{distance.toFixed(1)} mi</Text>
                            </View>
                          )}
                          {isSelected && (
                            <Ionicons name="checkmark-circle" size={22} color={PREMIUM_PURPLE} />
                          )}
                        </View>
                      </View>

                      <View style={styles.metaRow}>
                        <View style={styles.metaItem}>
                          <Ionicons name="time-outline" size={14} color={PREMIUM_PURPLE} />
                          <Text style={styles.metaText}>{formatWait(hub.wait_time_minutes)}</Text>
                        </View>

                        {!!hub.status && (
                          <View style={styles.metaItem}>
                            <Ionicons name="sparkles-outline" size={14} color={PREMIUM_PURPLE} />
                            <Text style={styles.metaText}>{hub.status}</Text>
                          </View>
                        )}
                      </View>
                    </GlassCard>
                  );
                })}
              </View>
            )}

            {/* Continue */}
            <TouchableOpacity
              onPress={handleContinue}
              disabled={!selectedHub}
              activeOpacity={0.85}
              style={[styles.continueButton, !selectedHub && { opacity: 0.55 }]}
            >
              <LinearGradient colors={[PREMIUM_PURPLE, '#6D28D9']} style={styles.continueGradient}>
                <Text style={styles.continueText}>{selectedHub ? 'Select Hub' : 'Select a hub'}</Text>
                <Ionicons name="arrow-forward" size={20} color={LIGHT_SKY} />
              </LinearGradient>
            </TouchableOpacity>

            <View style={{ height: 24 }} />
          </ScrollView>
        </Animated.View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },

  currentLocationButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },

  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', gap: 12 },
  loadingText: { color: '#E5E7EB', fontSize: 14 },

  content: { flex: 1 },
  scrollContent: { paddingHorizontal: 16, paddingBottom: 24 },

  radiusCard: { padding: 14, marginBottom: 14 },
  radiusHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  radiusTitleRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  radiusTitle: { color: LIGHT_SKY, fontSize: 15, fontWeight: '800' },
  radiusPill: {
    backgroundColor: 'rgba(139,92,246,0.22)',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.35)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 999,
  },
  radiusPillText: { color: PREMIUM_PURPLE, fontWeight: '900', fontSize: 12 },
  radiusSub: { color: 'rgba(249,250,251,0.75)', marginTop: 8, fontSize: 12 },

  sliderWrap: { marginTop: 12, flexDirection: 'row', alignItems: 'center', gap: 10 },
  sliderEdge: { color: 'rgba(249,250,251,0.6)', fontSize: 12, width: 18, textAlign: 'center' },

  sectionHead: { marginTop: 6, marginBottom: 10 },
  sectionTitle: { color: '#F9FAFB', fontSize: 20, fontWeight: '900' },
  sectionSub: { color: 'rgba(249,250,251,0.70)', marginTop: 4, fontSize: 12 },

  emptyCard: { padding: 24, marginTop: 10 },
  emptyContent: { alignItems: 'center', gap: 8 },
  emptyText: { color: '#F9FAFB', fontSize: 16, fontWeight: '900', marginTop: 6 },
  emptySubtext: { color: 'rgba(249,250,251,0.7)', fontSize: 12, textAlign: 'center', lineHeight: 16 },

  hubCard: { padding: 14 },
  hubCardSelected: {
    shadowColor: PREMIUM_PURPLE,
    shadowOpacity: 0.35,
    elevation: 10,
  },

  hubTopRow: { flexDirection: 'row', alignItems: 'flex-start', gap: 12 },
  hubIcon: {
    width: 34,
    height: 34,
    borderRadius: 12,
    backgroundColor: 'rgba(139,92,246,0.18)',
    alignItems: 'center',
    justifyContent: 'center',
  },

  hubName: { color: '#F9FAFB', fontSize: 16, fontWeight: '900' },
  hubAddress: { color: 'rgba(249,250,251,0.75)', fontSize: 12, marginTop: 4, lineHeight: 16 },

  rightCol: { alignItems: 'flex-end', gap: 8 },

  distancePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: PREMIUM_PURPLE,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 999,
  },
  distanceText: { color: BG, fontSize: 12, fontWeight: '900' },

  metaRow: { flexDirection: 'row', gap: 14, marginTop: 12, flexWrap: 'wrap' },
  metaItem: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  metaText: { color: '#E5E7EB', fontSize: 12, fontWeight: '700' },

  continueButton: {
    borderRadius: 16,
    overflow: 'hidden',
    marginTop: 14,
    elevation: 8,
    shadowColor: PREMIUM_PURPLE,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
  },
  continueGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 14, paddingHorizontal: 16, gap: 8 },
  continueText: { color: LIGHT_SKY, fontSize: 17, fontWeight: '900' },
});
