import React, { useState, useEffect, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Dimensions,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { detailingServiceOptions } from '../../../../src/constants/serviceOptions';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader from '../../../../src/components/shared/AppHeader';
import AISchedulingSuggestions from '../../../../src/components/booking/AISchedulingSuggestions';
import UberBottomSheet, { BottomSheetState } from '../../../../src/components/booking/UberBottomSheet';
import FloatingMapButton from '../../../../src/components/booking/FloatingMapButton';
import { supabase } from '../../../../src/lib/supabase';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { Hub } from '../../../../src/types/booking';
import { generateTimeSlots } from '../../../../src/utils/timeSlots';

const SKY = colors.SKY;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;
const BG = colors.BG;
const { width, height } = Dimensions.get('window');

export default function DetailingSchedule() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ serviceId?: string; vehicleId?: string; locationId?: string; latitude?: string; longitude?: string; address?: string; customerOffersWater?: string; customerOffersElectricity?: string; discountAmount?: string }>();
  const { serviceId, vehicleId, locationId, latitude, longitude, address, customerOffersWater, customerOffersElectricity, discountAmount } = params;
  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [hub, setHub] = useState<Hub | null>(null);
  const [loading, setLoading] = useState(false);
  const [sheetState, setSheetState] = useState<BottomSheetState>('half');
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const timeSlots = useMemo(() => generateTimeSlots(), []);
  const service = detailingServiceOptions.find((opt) => opt.id === serviceId);

  useEffect(() => {
    // Get user location
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status === 'granted') {
          const location = await Location.getCurrentPositionAsync({
            accuracy: Location.Accuracy.Balanced,
          });
          const coords = {
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
          };
          setUserLocation(coords);
          setRegion({
            latitude: coords.latitude,
            longitude: coords.longitude,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          });
        }
      } catch (error) {
        console.warn('Error getting location:', error);
      }
    })();

    if (!locationId) return;
    const loadHub = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude')
        .eq('id', locationId)
        .maybeSingle();
      if (!error && data) {
        setHub(data);
        if (data.latitude && data.longitude) {
          setRegion({
            latitude: Number(data.latitude),
            longitude: Number(data.longitude),
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          });
        }
      }
      setLoading(false);
    };
    loadHub();
  }, [locationId]);

  const handleContinue = async () => {
    if (!selectedSlot || !serviceId || !vehicleId) return;
    await hapticFeedback('medium');
    
    // For "You Go to Them" (has locationId), use locationId
    // For "They Come to You" (has latitude/longitude), use coordinates
    if (locationId) {
      router.push({
        pathname: '/owner/booking/detailing/confirm',
        params: {
          serviceId,
          vehicleId,
          locationId,
          scheduledAt: selectedSlot,
        },
      });
    } else if (latitude && longitude && address) {
      router.push({
        pathname: '/owner/booking/detailing/confirm',
        params: {
          serviceId,
          vehicleId,
          latitude,
          longitude,
          address,
          scheduledAt: selectedSlot,
          customerOffersWater: customerOffersWater || 'false',
          customerOffersElectricity: customerOffersElectricity || 'false',
          discountAmount: discountAmount || '0',
        },
      });
    }
  };

  if (!serviceId || !vehicleId) {
    return (
      <SafeAreaView style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ color: '#fff' }}>Missing booking information.</Text>
      </SafeAreaView>
    );
  }

  const selectedDate = selectedSlot ? new Date(selectedSlot) : null;
  const previewText = selectedSlot
    ? `${selectedDate!.toLocaleDateString('en-GB', { weekday: 'short', day: 'numeric', month: 'short' })} at ${selectedDate!.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}`
    : 'Select a time slot';

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {/* Fullscreen map - always visible */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image 
                  source={require('../../../../assets/washing.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
          {hub?.latitude && hub?.longitude && (
            <Marker coordinate={{ latitude: Number(hub.latitude), longitude: Number(hub.longitude) }}>
              <View style={styles.hubMarkerContainer}>
                <Ionicons name="diamond" size={32} color={PREMIUM_PURPLE} />
              </View>
            </Marker>
          )}
          {!locationId && latitude && longitude && (
            <Marker coordinate={{ latitude: parseFloat(latitude), longitude: parseFloat(longitude) }}>
              <View style={styles.hubMarkerContainer}>
                <Ionicons name="location" size={32} color={PREMIUM_PURPLE} />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Header floating over map */}
      <AppHeader 
        title="Schedule appointment"
        showBack={true}
        onBack={() => router.back()}
      />

      {/* Uber-style bottom sheet */}
      <UberBottomSheet
        state={sheetState}
        onStateChange={setSheetState}
        previewContent={
          <View style={styles.previewContent}>
            {service && (
              <View style={styles.previewRow}>
                <Ionicons name={service.icon as any} size={18} color={PREMIUM_PURPLE} />
                <Text style={styles.previewText} numberOfLines={1}>
                  {service.name} • {hub?.name || address || 'Location'}
                </Text>
              </View>
            )}
            <Text style={styles.previewSlot}>{previewText}</Text>
          </View>
        }
        footerButton={
          <TouchableOpacity
            style={[styles.continueButton, !selectedSlot && styles.continueButtonDisabled]}
            disabled={!selectedSlot}
            onPress={handleContinue}
            activeOpacity={0.85}
          >
            <LinearGradient
              colors={!selectedSlot ? ['rgba(255,255,255,0.1)', 'rgba(255,255,255,0.05)'] : [PREMIUM_PURPLE, '#7C3AED']}
              style={styles.continueGradient}
            >
              <Text style={styles.continueText}>
                {selectedSlot ? 'Continue' : 'Select a time slot'}
              </Text>
              <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
            </LinearGradient>
          </TouchableOpacity>
        }
      >
        {/* Service summary */}
        {service && (
          <View style={styles.serviceSummary}>
            <View style={styles.serviceHeader}>
              <View style={styles.serviceIconWrapper}>
                <Ionicons name={service.icon as any} size={24} color={PREMIUM_PURPLE} />
              </View>
              <View style={styles.serviceInfo}>
                <Text style={styles.serviceName}>{service.name}</Text>
                <Text style={styles.serviceDesc}>{service.desc}</Text>
              </View>
              <Text style={styles.servicePrice}>£{service.price}</Text>
            </View>
            <View style={styles.serviceMeta}>
              <View style={styles.metaItem}>
                <Ionicons name="time-outline" size={14} color={PREMIUM_PURPLE} />
                <Text style={styles.metaText}>{service.dur}</Text>
              </View>
            </View>
          </View>
        )}

        {/* Location summary */}
        {(hub || address) && (
          <View style={styles.locationSummary}>
            <View style={styles.locationHeader}>
              <Ionicons name="location" size={18} color={PREMIUM_PURPLE} />
              <View style={styles.locationInfo}>
                <Text style={styles.locationName} numberOfLines={1}>
                  {hub?.name || 'Your Location'}
                </Text>
                <Text style={styles.locationAddress} numberOfLines={2}>
                  {hub?.address || address}
                </Text>
              </View>
            </View>
          </View>
        )}

        {/* AI Scheduling Suggestions */}
        {!locationId && latitude && longitude && (
          <AISchedulingSuggestions
            location={{ latitude: parseFloat(latitude), longitude: parseFloat(longitude) }}
            onSelectSuggestion={(date, timeSlot) => {
              const matchingSlot = timeSlots.find(slot => {
                const slotDate = new Date(slot);
                const slotDateStr = slotDate.toISOString().split('T')[0];
                const slotTime = slotDate.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
                return slotDateStr === date && slotTime === timeSlot;
              });
              if (matchingSlot) {
                setSelectedSlot(matchingSlot);
                setSheetState('half');
              }
            }}
          />
        )}

        {/* Time slots - horizontal scroll */}
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Choose appointment time</Text>
          <Text style={styles.sectionSubtitle}>Swipe to see more options</Text>
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.slotScrollContent}
          >
            {timeSlots.map((slot) => {
              const date = new Date(slot);
              const isSelected = selectedSlot === slot;
              return (
                <TouchableOpacity
                  key={slot}
                  style={[styles.slotCard, isSelected && styles.slotCardSelected]}
                  onPress={() => {
                    hapticFeedback('light');
                    setSelectedSlot(slot);
                  }}
                  activeOpacity={0.85}
                >
                  <Text style={styles.slotDay}>
                    {date.toLocaleDateString('en-GB', { weekday: 'short' })}
                  </Text>
                  <Text style={styles.slotDate}>
                    {date.toLocaleDateString('en-GB', { day: 'numeric', month: 'short' })}
                  </Text>
                  <Text style={styles.slotTime}>
                    {date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
                  </Text>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        </View>
      </UberBottomSheet>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: BG },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  hubMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(139,92,246,0.2)',
    borderWidth: 2,
    borderColor: PREMIUM_PURPLE,
  },
  previewContent: {
    gap: 6,
  },
  previewRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  previewText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    flex: 1,
  },
  previewSlot: {
    color: PREMIUM_PURPLE,
    fontSize: 13,
    fontWeight: '600',
  },
  serviceSummary: {
    backgroundColor: 'rgba(139,92,246,0.12)',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1.5,
    borderColor: 'rgba(139,92,246,0.25)',
    marginBottom: 16,
  },
  serviceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 10,
  },
  serviceIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(139,92,246,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  serviceInfo: {
    flex: 1,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '900',
    flex: 1,
    letterSpacing: -0.3,
  },
  serviceDesc: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 15,
    marginBottom: 12,
    lineHeight: 20,
  },
  serviceMeta: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  metaText: {
    color: '#E5E7EB',
    fontSize: 14,
    fontWeight: '700',
  },
  servicePrice: {
    color: '#F9FAFB',
    fontWeight: '900',
    fontSize: 20,
    letterSpacing: 0.3,
  },
  locationSummary: {
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 14,
    borderWidth: 1.5,
    borderColor: 'rgba(139,92,246,0.2)',
    marginBottom: 16,
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  locationInfo: {
    flex: 1,
  },
  locationName: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    marginBottom: 4,
  },
  locationAddress: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  section: {
    gap: 16,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  sectionSubtitle: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 14,
    marginBottom: 8,
    fontWeight: '600',
  },
  slotScrollContent: {
    paddingRight: 20,
    gap: 12,
  },
  slotCard: {
    width: 100,
    borderRadius: 16,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.15)',
    paddingVertical: 14,
    paddingHorizontal: 12,
    backgroundColor: 'rgba(255,255,255,0.06)',
    alignItems: 'center',
    marginRight: 12,
  },
  slotCardSelected: {
    borderColor: PREMIUM_PURPLE,
    backgroundColor: 'rgba(139,92,246,0.25)',
    shadowColor: PREMIUM_PURPLE,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 8,
  },
  slotDay: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 11,
    fontWeight: '700',
    textTransform: 'uppercase',
    marginBottom: 4,
  },
  slotDate: {
    color: '#E5E7EB',
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 6,
  },
  slotTime: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '900',
    letterSpacing: 0.2,
  },
  continueButton: {
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: PREMIUM_PURPLE,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 12,
  },
  continueButtonDisabled: {
    opacity: 0.5,
  },
  continueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 24,
    gap: 10,
  },
  continueText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: 0.3,
  },
});

