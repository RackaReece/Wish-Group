import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { supabase } from '../../../../src/lib/supabase';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { detailingServiceOptions } from '../../../../src/constants/serviceOptions';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { colors } from '../../../../src/constants/colors';

const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;
const BG = colors.BG;

export default function DetailingConfirm() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams<{ serviceId?: string; vehicleId?: string; latitude?: string; longitude?: string; address?: string; scheduledAt?: string; customerOffersWater?: string; customerOffersElectricity?: string; discountAmount?: string }>();
  const { serviceId, vehicleId, latitude, longitude, address, scheduledAt, customerOffersWater, customerOffersElectricity, discountAmount } = params;
  const [submitting, setSubmitting] = useState(false);
  const service = detailingServiceOptions.find((opt) => opt.id === serviceId);

  const handleConfirm = async () => {
    if (!user?.id || !service || !vehicleId || !latitude || !longitude || !address || !scheduledAt) return;
    try {
      setSubmitting(true);
      await hapticFeedback('medium');
      
      const basePrice = service.price;
      const discount = parseFloat(discountAmount || '0');
      const finalPrice = basePrice - discount;
      const offersWater = customerOffersWater === 'true';
      const offersElectricity = customerOffersElectricity === 'true';
      
      const { data, error } = await supabase
        .from('bookings')
        .insert({
          user_id: user.id,
          service_type: service.id,
          service_name: service.name,
          price: finalPrice,
          status: 'scheduled',
          location_address: address,
          location_lat: parseFloat(latitude),
          location_lng: parseFloat(longitude),
          customer_offers_water: offersWater,
          customer_offers_electricity: offersElectricity,
          discount_amount: discount,
          request_sent_at: new Date().toISOString(),
          scheduled_at: scheduledAt,
        })
        .select()
        .single();

      if (error) throw error;

      router.replace({
        pathname: '/owner/booking/detailing/confirmation',
        params: { bookingId: data.id },
      });
    } catch (err: any) {
      console.error('[detailing-confirm] booking error', err);
      Alert.alert('Error', err?.message || 'Unable to create booking');
    } finally {
      setSubmitting(false);
    }
  };

  if (!service || !scheduledAt || !address) {
    return (
      <SafeAreaView style={[styles.container, { justifyContent: 'center', alignItems: 'center' }]}>
        <Text style={{ color: '#fff' }}>Missing booking information.</Text>
      </SafeAreaView>
    );
  }

  const formattedTime = new Date(scheduledAt as string).toLocaleString('en-GB', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader title="Confirm detailing" />

      <ScrollView contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]} showsVerticalScrollIndicator={false}>
        <View style={styles.premiumBanner}>
          <Ionicons name="diamond" size={24} color={PREMIUM_PURPLE} />
          <Text style={styles.premiumBannerText}>Premium Detailing Service</Text>
        </View>

        <View style={styles.summaryCard}>
          <Text style={styles.summaryLabel}>Service</Text>
          <Text style={styles.summaryTitle}>{service.name}</Text>
          <Text style={styles.summarySubtitle}>{service.desc}</Text>
          <View style={styles.summaryRow}>
            <Text style={styles.summaryMeta}>Duration: {service.dur}</Text>
            <Text style={[styles.summaryPrice, { color: PREMIUM_PURPLE }]}>£{service.price}</Text>
          </View>
        </View>

        <View style={styles.summaryCard}>
          <Text style={styles.summaryLabel}>Location</Text>
          <Text style={styles.summaryTitle} numberOfLines={2}>{address}</Text>
        </View>

        <View style={styles.summaryCard}>
          <Text style={styles.summaryLabel}>Appointment Time</Text>
          <Text style={styles.summaryTitle}>{formattedTime}</Text>
          <Text style={styles.summarySubtitle}>Arrive 10 minutes early for your premium detailing appointment.</Text>
        </View>
      </ScrollView>

      <View style={[styles.footer, { paddingBottom: insets.bottom + 16 }]}>
        <TouchableOpacity
          style={[styles.confirmButton, submitting && { opacity: 0.6 }]}
          onPress={handleConfirm}
          disabled={submitting}
          activeOpacity={0.85}
        >
          {submitting ? (
            <ActivityIndicator color={BG} />
          ) : (
            <>
              <Ionicons name="diamond" size={18} color={BG} />
              <Text style={styles.confirmText}>Confirm detailing</Text>
            </>
          )}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  scrollContent: {
    padding: 20,
    paddingBottom: 140,
    gap: 16,
  },
  premiumBanner: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: 'rgba(139,92,246,0.15)',
    borderRadius: 12,
    padding: 12,
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
  },
  premiumBannerText: {
    color: PREMIUM_PURPLE,
    fontSize: 14,
    fontWeight: '700',
  },
  summaryCard: {
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.06)',
    backgroundColor: 'rgba(255,255,255,0.03)',
    padding: 18,
  },
  summaryLabel: {
    color: 'rgba(139,92,246,0.8)',
    fontSize: 12,
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 6,
  },
  summaryTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
  },
  summarySubtitle: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 14,
    marginTop: 4,
  },
  summaryRow: {
    marginTop: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  summaryMeta: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
  },
  summaryPrice: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
  },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 20,
    backgroundColor: customerTheme.backgroundColor,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.05)',
  },
  confirmButton: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 8,
    backgroundColor: PREMIUM_PURPLE,
    borderRadius: 18,
    paddingVertical: 14,
  },
  confirmText: {
    color: BG,
    fontSize: 16,
    fontWeight: '700',
  },
});

