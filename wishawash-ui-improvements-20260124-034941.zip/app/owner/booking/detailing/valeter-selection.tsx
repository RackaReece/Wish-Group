import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Image,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../../src/lib/supabase';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import { detailingServiceOptions } from '../../../../src/constants/serviceOptions';
import AppHeader from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../../app/components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;
const BG = colors.BG;

interface Valeter {
  id: string;
  name: string;
  rating: number;
  totalJobs: number;
  distance: number;
  isOnline: boolean;
  profilePicture?: string;
  lastLat?: number;
  lastLng?: number;
}

export default function DetailingValeterSelection() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const serviceId = params.serviceId as string;
  const vehicleId = params.vehicleId as string;
  const latitude = parseFloat(params.latitude as string);
  const longitude = parseFloat(params.longitude as string);
  const address = params.address as string;
  const customerOffersWater = params.customerOffersWater === 'true';
  const customerOffersElectricity = params.customerOffersElectricity === 'true';
  const discountAmount = parseFloat(params.discountAmount as string) || 0;

  const [valeters, setValeters] = useState<Valeter[]>([]);
  const [selectedValeter, setSelectedValeter] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [region, setRegion] = useState<Region>({
    latitude: latitude || 51.5074,
    longitude: longitude || -0.1278,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  });

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();

    loadNearbyValeters();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 3959; // Earth's radius in miles
    const dLat = ((lat2 - lat1) * Math.PI) / 180;
    const dLon = ((lon2 - lon1) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos((lat1 * Math.PI) / 180) *
        Math.cos((lat2 * Math.PI) / 180) *
        Math.sin(dLon / 2) *
        Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const loadNearbyValeters = async () => {
    try {
      setLoading(true);

      // 1) Online presence
      const { data: presenceData, error: presenceError } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng')
        .eq('is_online', true);

      if (presenceError) throw presenceError;

      if (!presenceData || presenceData.length === 0) {
        setValeters([]);
        return;
      }

      const userIds = presenceData.map((p) => p.user_id);

      // 2) Profiles (includes optional detailing flags)
      const { data: profilesData, error: profilesError } = await supabase
        .from('valeter_profiles')
        .select('user_id, full_name, profile_photo_url')
        .in('user_id', userIds);

      if (profilesError) throw profilesError;

      // 3) Determine which valeters offer detailing (schema-flexible)
      const detailingAllowedIds = new Set<string>();

      // Try valeter_services first (preferred)
      const { data: capsData, error: capsError } = await supabase
        .from('valeter_services')
        .select('user_id, service_type, is_enabled')
        .in('user_id', userIds)
        .eq('is_enabled', true);

      if (!capsError && capsData && capsData.length > 0) {
        // If your service_type is exact key: "detailing" -> perfect.
        // If you store service IDs -> we also allow matching the incoming serviceId.
        const allowedTypes = new Set<string>([
          'detailing',
          'detail',
          'valeter_detailing',
          String(serviceId || ''),
        ]);

        capsData.forEach((row: any) => {
          const type = String(row.service_type || '').toLowerCase();
          if (allowedTypes.has(type) || type.includes('detail')) {
            detailingAllowedIds.add(row.user_id);
          }
        });
      }

      // If we still have nothing, assume nobody offers detailing (better than showing wrong people)
      if (detailingAllowedIds.size === 0) {
        setValeters([]);
        return;
      }

      // 4) Combine + distance + capability filter
      const valetersList: Valeter[] = presenceData
        .map((presence) => {
          const profile = profilesData?.find((p: any) => p.user_id === presence.user_id);
          const hasLocation = presence.last_lat != null && presence.last_lng != null;

          const distance = hasLocation
            ? calculateDistance(latitude, longitude, presence.last_lat!, presence.last_lng!)
            : Number.POSITIVE_INFINITY;

          return {
            id: presence.user_id,
            name: profile?.full_name || 'Valeter',
            rating: 4.8,
            totalJobs: 0,
            distance: hasLocation ? Math.round(distance * 10) / 10 : 999,
            isOnline: presence.is_online,
            profilePicture: profile?.profile_photo_url,
            lastLat: presence.last_lat,
            lastLng: presence.last_lng,
          };
        })
        // ✅ Only show valeters who offer detailing
        .filter((v) => detailingAllowedIds.has(v.id))
        // keep your distance rule
        .filter((v) => v.distance <= 10 || v.distance === 999)
        .sort((a, b) => a.distance - b.distance);

      setValeters(valetersList);
    } catch (error) {
      console.error('Error loading valeters:', error);
      setValeters([]);
    } finally {
      setLoading(false);
    }
  };

  const handleValeterSelect = async (valeterId: string) => {
    await hapticFeedback('light');
    setSelectedValeter(valeterId);
  };

  const selectedServiceOption = detailingServiceOptions.find((option) => option.id === serviceId);

  const handleContinue = async () => {
    if (!selectedValeter || !selectedServiceOption) return;
    await hapticFeedback('medium');

    if (!user?.id) return;

    try {
      const scheduledAt = new Date().toISOString();
      const basePrice = selectedServiceOption.price || 60;
      const finalPrice = basePrice - discountAmount;

      const { data, error } = await supabase
        .from('bookings')
        .insert({
          user_id: user.id,
          valeter_id: selectedValeter,
          service_type: serviceId,
          service_name: selectedServiceOption.name || serviceId,
          status: 'pending_valeter_acceptance',
          price: finalPrice,
          location_address: address,
          location_lat: latitude,
          location_lng: longitude,
          customer_offers_water: customerOffersWater,
          customer_offers_electricity: customerOffersElectricity,
          discount_amount: discountAmount,
          request_sent_at: new Date().toISOString(),
          scheduled_at: scheduledAt,
        })
        .select()
        .single();

      if (error) throw error;

      router.push({
        pathname: '/owner/booking/waiting-acceptance',
        params: { bookingId: data.id },
      });
    } catch (error: any) {
      console.error('Error creating booking:', error);
      Alert.alert('Error', error?.message || 'Failed to create booking');
    }
  };

  // Update region when valeters are loaded
  useEffect(() => {
    if (valeters.length > 0 && latitude && longitude) {
      const lats = valeters.map(v => v.lastLat).filter((lat): lat is number => lat !== undefined);
      const lngs = valeters.map(v => v.lastLng).filter((lng): lng is number => lng !== undefined);
      
      if (lats.length > 0 && lngs.length > 0) {
        lats.push(latitude);
        lngs.push(longitude);
        
        const minLat = Math.min(...lats);
        const maxLat = Math.max(...lats);
        const minLng = Math.min(...lngs);
        const maxLng = Math.max(...lngs);
        
        const latPadding = (maxLat - minLat) * 0.2;
        const lngPadding = (maxLng - minLng) * 0.2;
        
        setRegion({
          latitude: (minLat + maxLat) / 2,
          longitude: (minLng + maxLng) / 2,
          latitudeDelta: Math.max((maxLat - minLat) * 1.4 + latPadding, 0.05),
          longitudeDelta: Math.max((maxLng - minLng) * 1.4 + lngPadding, 0.05),
        });
      }
    }
  }, [valeters, latitude, longitude]);

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
        >
          {/* User location marker */}
          {latitude && longitude && (
            <Marker coordinate={{ latitude, longitude }}>
              <View style={styles.userMarkerContainer}>
                <Image 
                  source={require('../../../../assets/washing.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {/* Valeter markers */}
          {valeters.map((valeter) => {
            if (!valeter.lastLat || !valeter.lastLng) return null;
            const isSelected = selectedValeter === valeter.id;
            return (
              <Marker
                key={valeter.id}
                coordinate={{ latitude: valeter.lastLat, longitude: valeter.lastLng }}
                onPress={() => handleValeterSelect(valeter.id)}
              >
                <View style={styles.valeterMarkerContainer}>
                  <Image 
                    source={require('../../../../assets/detailing.png')} 
                    style={[
                      styles.valeterMarker,
                      isSelected && styles.valeterMarkerSelected
                    ]}
                    resizeMode="contain"
                  />
                  {valeter.isOnline && (
                    <View style={styles.valeterOnlineBadge}>
                      <View style={styles.valeterOnlineDot} />
                    </View>
                  )}
                </View>
              </Marker>
            );
          })}
        </MapView>
      </View>

      {/* Header floating over the map */}
      <AppHeader 
        title="Select Detailer" 
        subtitle="Choose your preferred detailing specialist"
        showBack={true}
        onBack={() => router.back()}
        rightAction={
          <TouchableOpacity 
            onPress={async () => {
              await hapticFeedback('light');
              router.replace('/owner/owner-dashboard' as any);
            }} 
            style={styles.exitButton}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={22} color="#FFFFFF" />
          </TouchableOpacity>
        }
      />

      {/* Valeter profile cards - horizontal scroll */}
      <Animated.View
        style={[
          styles.cardContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            paddingBottom: Math.max(insets.bottom, 14) + 14 + TAB_BAR_TOTAL_HEIGHT + 12,
          },
        ]}
      >
        {loading ? (
          <GlassCard style={styles.trackingCard}>
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color={PREMIUM_PURPLE} />
              <Text style={styles.loadingText}>Finding nearby detailers...</Text>
            </View>
          </GlassCard>
        ) : valeters.length === 0 ? (
          <GlassCard style={styles.trackingCard}>
            <View style={styles.emptyContent}>
              <Ionicons name="person-outline" size={48} color={PREMIUM_PURPLE} style={{ opacity: 0.5 }} />
              <Text style={styles.emptyText}>No detailers available</Text>
              <Text style={styles.emptySubtext}>Try again later or adjust your location</Text>
            </View>
          </GlassCard>
        ) : (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.cardsScrollContent}
            snapToInterval={width - 32}
            decelerationRate="fast"
            pagingEnabled
          >
            {valeters.map((valeter) => {
              const isSelected = selectedValeter === valeter.id;
              return (
                <View key={valeter.id} style={[styles.cardWrapper, { width: width - 32 }]}>
                  <GlassCard
                    onPress={() => handleValeterSelect(valeter.id)}
                    style={[styles.trackingCard, isSelected && styles.cardSelected]}
                    borderColor={isSelected ? PREMIUM_PURPLE : 'rgba(139,92,246,0.3)'}
                  >
                    <LinearGradient
                      colors={isSelected ? [PREMIUM_PURPLE + '30', PREMIUM_PURPLE + '20'] : ['transparent', 'transparent']}
                      style={StyleSheet.absoluteFill}
                    />
                    <View style={styles.valeterHeader}>
                      <View style={styles.valeterLeft}>
                        {valeter.profilePicture ? (
                          <Image
                            source={{ uri: valeter.profilePicture }}
                            style={styles.profileImage}
                          />
                        ) : (
                          <Image
                            source={require('../../../../assets/detailing.png')}
                            style={styles.profileImage}
                            resizeMode="contain"
                          />
                        )}
                        {valeter.isOnline && (
                          <View style={styles.onlineBadge}>
                            <View style={styles.onlineDot} />
                          </View>
                        )}
                      </View>
                      <View style={styles.valeterInfo}>
                        <View style={styles.valeterNameRow}>
                          <View style={styles.nameContainer}>
                            <Text style={styles.valeterName}>{valeter.name}</Text>
                            <View style={styles.verifiedRow}>
                              <Text style={styles.verifiedText}>Premium Detailer</Text>
                            </View>
                          </View>
                          {isSelected && (
                            <View style={styles.selectedCheck}>
                              <Ionicons name="checkmark-circle" size={24} color={PREMIUM_PURPLE} />
                              <Text style={styles.selectedLabel}>Selected</Text>
                            </View>
                          )}
                        </View>
                      </View>
                    </View>
                    <View style={styles.bookingInfo}>
                      <View style={styles.infoRow}>
                        <Ionicons name="star" size={16} color="#FBBF24" />
                        <Text style={styles.infoText}>{valeter.rating.toFixed(1)} Rating</Text>
                      </View>
                      <View style={styles.infoRow}>
                        {valeter.totalJobs < 3 ? (
                          <>
                            <Ionicons name="sparkles" size={16} color={PREMIUM_PURPLE} />
                            <Text style={styles.infoText}>New on Wish-a-Wash</Text>
                          </>
                        ) : (
                          <>
                            <Ionicons name="car" size={16} color={PREMIUM_PURPLE} />
                            <Text style={styles.infoText}>{valeter.totalJobs} Completed Jobs</Text>
                          </>
                        )}
                      </View>
                      <View style={styles.infoRow}>
                        <Ionicons name="location" size={16} color={PREMIUM_PURPLE} />
                        <Text style={styles.infoText}>{valeter.distance.toFixed(1)} miles away</Text>
                      </View>
                    </View>
                    {isSelected && (
                      <View style={styles.actionsRow}>
                        <TouchableOpacity
                          onPress={handleContinue}
                          style={styles.continueBtn}
                          activeOpacity={0.9}
                        >
                          <Text style={styles.continueBtnText}>Continue</Text>
                          <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
                        </TouchableOpacity>
                      </View>
                    )}
                  </GlassCard>
                </View>
              );
            })}
          </ScrollView>
        )}
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  valeterMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  valeterMarker: {
    width: 48,
    height: 48,
  },
  valeterMarkerSelected: {
    width: 56,
    height: 56,
  },
  valeterOnlineBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: '#10B981',
    borderWidth: 2,
    borderColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  valeterOnlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#FFFFFF',
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  cardWrapper: {
    marginRight: 12,
    marginLeft: 0,
  },
  trackingCard: {
    padding: 20,
    backgroundColor: 'rgba(15, 23, 42, 0.4)',
  },
  cardSelected: {
    elevation: 10,
    shadowColor: PREMIUM_PURPLE,
    shadowOpacity: 0.3,
    borderWidth: 1.5,
  },
  loadingContainer: {
    padding: 32,
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: PREMIUM_PURPLE,
    fontSize: 14,
    fontWeight: '600',
  },
  emptyContent: {
    padding: 32,
    alignItems: 'center',
    gap: 12,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  emptySubtext: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 13,
    textAlign: 'center',
  },
  valeterHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  valeterLeft: {
    position: 'relative',
  },
  profileImage: {
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 2,
    borderColor: PREMIUM_PURPLE + '40',
  },
  onlineBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: '#10B981',
    borderWidth: 2,
    borderColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
  },
  onlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#FFFFFF',
  },
  valeterInfo: {
    flex: 1,
  },
  valeterNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  nameContainer: {
    flex: 1,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  verifiedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  verifiedText: {
    color: PREMIUM_PURPLE,
    fontSize: 12,
    fontWeight: '600',
  },
  selectedCheck: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  selectedLabel: {
    color: PREMIUM_PURPLE,
    fontSize: 12,
    fontWeight: '700',
  },
  bookingInfo: {
    gap: 10,
    marginTop: 8,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  infoText: {
    color: '#E5E7EB',
    fontSize: 13,
    fontWeight: '600',
  },
  actionsRow: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(139,92,246,0.2)',
  },
  continueBtn: {
    backgroundColor: PREMIUM_PURPLE,
    paddingVertical: 14,
    paddingHorizontal: 24,
    borderRadius: 12,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  continueBtnText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
  valeterCardSelected: { elevation: 12, shadowColor: PREMIUM_PURPLE, shadowOpacity: 0.4 },

  valeterContent: { flexDirection: 'row', alignItems: 'center', gap: 16 },
  valeterLeft: { position: 'relative' },

  profileImage: { width: 64, height: 64, borderRadius: 32, borderWidth: 2, borderColor: PREMIUM_PURPLE },
  profilePlaceholder: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(139,92,246,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: PREMIUM_PURPLE,
  },

  onlineBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: '#0A1929',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  onlineDot: { width: 10, height: 10, borderRadius: 5, backgroundColor: '#10B981' },

  valeterInfo: { flex: 1 },
  valeterHeader: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 },
  valeterName: { color: '#F9FAFB', fontSize: 18, fontWeight: 'bold' },
  selectedBadge: { marginLeft: 'auto' },

  valeterStats: { flexDirection: 'row', gap: 16, flexWrap: 'wrap' },
  statItem: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  statText: { color: PREMIUM_PURPLE, fontSize: 12, fontWeight: '600' },

  continueButton: {
    marginTop: 20,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: PREMIUM_PURPLE,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  continueGradient: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 16, paddingHorizontal: 32, gap: 8 },
  continueText: { color: '#FFFFFF', fontSize: 18, fontWeight: 'bold' },
});
