import React, { useEffect } from 'react';
import { router } from 'expo-router';

export default function DetailingBooking() {
  useEffect(() => {
    // Redirect to main booking page with detailing toggle active
    router.replace({
      pathname: '/owner/booking',
      params: { serviceType: 'detailing' },
    });
  }, []);

  return null;
}
