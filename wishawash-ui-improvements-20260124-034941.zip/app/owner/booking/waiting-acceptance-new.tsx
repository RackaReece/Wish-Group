import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Dimensions,
  Animated,
  Alert,
} from 'react-native';
import MapView, { Region, Marker, Circle } from 'react-native-maps';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { customerTheme } from '../../../src/constants/customerTheme';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import CountdownTimer from '../../../src/components/booking/CountdownTimer';
import {
  WWBottomSheet,
  WWPrimaryButton,
  WWSecondaryButton,
  WWMapHeaderControls,
  WWStepper,
} from '../../../src/components/ui';
import type { BottomSheetState, StepperStatus } from '../../../src/components/ui';

const { width, height } = Dimensions.get('window');
const SKY = '#5B8FA8';

// Dark map style
const darkMapStyle = [
  { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
  { featureType: 'water', stylers: [{ color: '#17263c' }] },
];

export default function WaitingAcceptance() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;

  const [booking, setBooking] = useState<any | null>(null);
  const [valeter, setValeter] = useState<any | null>(null);
  const [countdown, setCountdown] = useState(300); // 5 minutes
  const [status, setStatus] = useState<'pending_valeter_acceptance' | 'confirmed' | 'cancelled'>('pending_valeter_acceptance');
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const [customerLocation, setCustomerLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [valeterLocation, setValeterLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [sheetState, setSheetState] = useState<BottomSheetState>('half');

  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    loadBooking();
    subscribeToBooking();
    startPulseAnimation();
  }, [bookingId]);

  useEffect(() => {
    if (countdown <= 0) {
      handleCountdownComplete();
      return;
    }

    const timer = setInterval(() => {
      setCountdown(prev => Math.max(0, prev - 1));
    }, 1000);

    return () => clearInterval(timer);
  }, [countdown]);

  const startPulseAnimation = () => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  };

  const loadBooking = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*, valeter_profiles(*)')
        .eq('id', bookingId)
        .single();

      if (error) throw error;
      if (!data) return;

      setBooking(data);
      
      if (data.valeter_profiles) {
        setValeter(data.valeter_profiles);
      }

      // Set locations
      if (data.location_lat && data.location_lng) {
        const loc = {
          latitude: data.location_lat,
          longitude: data.location_lng,
        };
        setCustomerLocation(loc);
        setRegion({
          ...loc,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      }

      // Calculate remaining time
      if (data.request_sent_at) {
        const sentAt = new Date(data.request_sent_at).getTime();
        const now = Date.now();
        const elapsed = Math.floor((now - sentAt) / 1000);
        const remaining = Math.max(0, 300 - elapsed);
        setCountdown(remaining);
      }

      setStatus(data.status as any);
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const subscribeToBooking = () => {
    const channel = supabase
      .channel(`waiting-acceptance-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          setStatus(updated.status);
          
          if (updated.status === 'confirmed') {
            router.push({
              pathname: '/owner/booking/tracking',
              params: { bookingId },
            });
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  };

  const handleCountdownComplete = () => {
    Alert.alert(
      'Time Expired',
      'The valeter did not respond in time. Would you like to request another valeter?',
      [
        { text: 'Cancel', style: 'cancel' },
        { text: 'Request Another', onPress: handleCancelRequest },
      ]
    );
  };

  const handleCancelRequest = async () => {
    await hapticFeedback('medium');
    
    try {
      const { error } = await supabase
        .from('bookings')
        .update({ status: 'cancelled' })
        .eq('id', bookingId);

      if (error) throw error;

      router.replace('/owner/owner-dashboard');
    } catch (error) {
      console.error('Error cancelling booking:', error);
      Alert.alert('Error', 'Failed to cancel request');
    }
  };

  const handleSendToAnother = async () => {
    await hapticFeedback('light');
    // Navigate back to valeter selection
    router.back();
  };

  const getStepperSteps = (): Array<{ label: string; status: StepperStatus }> => {
    return [
      {
        label: 'Request Sent',
        status: status === 'pending_valeter_acceptance' ? 'active' : 'completed',
      },
      {
        label: 'Waiting for Acceptance',
        status: status === 'pending_valeter_acceptance' ? 'active' : 'pending',
      },
      {
        label: 'Accepted',
        status: status === 'confirmed' ? 'active' : 'pending',
      },
      {
        label: 'On the Way',
        status: 'pending',
      },
    ];
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Full Screen Map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          customMapStyle={darkMapStyle}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
        >
          {/* Customer Location */}
          {customerLocation && (
            <>
              <Marker coordinate={customerLocation}>
                <View style={styles.customerMarker}>
                  <Animated.View
                    style={[
                      styles.pulseRing,
                      { transform: [{ scale: pulseAnim }] },
                    ]}
                  />
                  <View style={styles.markerInner}>
                    <Ionicons name="person" size={16} color={SKY} />
                  </View>
                </View>
              </Marker>
              <Circle
                center={customerLocation}
                radius={500}
                strokeColor={`${SKY}30`}
                fillColor={`${SKY}10`}
              />
            </>
          )}

          {/* Valeter Location (if available) */}
          {valeterLocation && (
            <Marker coordinate={valeterLocation}>
              <View style={styles.valeterMarker}>
                <Ionicons name="car" size={20} color={SKY} />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Map Header Controls */}
      <WWMapHeaderControls
        onBack={() => router.back()}
        onLocate={() => {
          if (customerLocation) {
            setRegion({
              ...customerLocation,
              latitudeDelta: 0.01,
              longitudeDelta: 0.01,
            });
          }
        }}
        showClose={false}
      />

      {/* Bottom Sheet */}
      <WWBottomSheet
        state={sheetState}
        onStateChange={setSheetState}
        collapsedHeight={height * 0.15}
        halfHeight={height * 0.6}
        fullHeight={height * 0.85}
        previewContent={
          <View style={styles.previewContent}>
            <Text style={styles.previewText}>
              {status === 'pending_valeter_acceptance' 
                ? `Waiting for ${valeter?.full_name || 'valeter'}...`
                : 'Request sent'}
            </Text>
          </View>
        }
      >
        <View style={styles.headerSection}>
          <Text style={styles.title}>Request Sent</Text>
          <Text style={styles.subtitle}>
            {valeter?.full_name || 'Valeter'} has up to 5 minutes to accept
          </Text>
        </View>

        {/* Timer */}
        <View style={styles.timerContainer}>
          <CountdownTimer seconds={countdown} size="large" />
        </View>

        {/* Stepper */}
        <View style={styles.stepperContainer}>
          <WWStepper steps={getStepperSteps()} />
        </View>

        {/* Info Message */}
        <View style={styles.infoContainer}>
          <Ionicons name="information-circle-outline" size={20} color={SKY} />
          <Text style={styles.infoText}>
            You'll be notified as soon as the valeter accepts your request
          </Text>
        </View>
      </WWBottomSheet>

      {/* Action Buttons */}
      <View style={styles.footer}>
        <WWPrimaryButton
          title="Cancel Request"
          onPress={handleCancelRequest}
          style={styles.cancelButton}
        />
        <View style={styles.spacer} />
        <WWSecondaryButton
          title="Send to Another Pro"
          onPress={handleSendToAnother}
        />
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  customerMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  pulseRing: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: `${SKY}20`,
  },
  markerInner: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#0A1929',
    borderWidth: 3,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  valeterMarker: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#0A1929',
    borderWidth: 2,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  previewContent: {
    paddingVertical: 4,
  },
  previewText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  headerSection: {
    marginBottom: 24,
  },
  title: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: '700',
    marginBottom: 8,
  },
  subtitle: {
    color: '#94A3B8',
    fontSize: 14,
  },
  timerContainer: {
    alignItems: 'center',
    marginBottom: 32,
  },
  stepperContainer: {
    marginBottom: 24,
  },
  infoContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: `${SKY}15`,
    padding: 12,
    borderRadius: 12,
    marginTop: 8,
  },
  infoText: {
    color: '#E2E8F0',
    fontSize: 13,
    marginLeft: 8,
    flex: 1,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 20,
    paddingBottom: 20,
    paddingTop: 12,
    backgroundColor: 'rgba(15, 23, 42, 0.95)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
    flexDirection: 'row',
  },
  cancelButton: {
    flex: 1,
  },
  spacer: {
    width: 12,
  },
});
