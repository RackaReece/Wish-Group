import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Location from 'expo-location';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../../src/lib/supabase';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import AppHeader from '../../../../src/components/shared/AppHeader';
import UberBottomSheet, { BottomSheetState } from '../../../../src/components/booking/UberBottomSheet';
import FloatingMapButton from '../../../../src/components/booking/FloatingMapButton';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

type Vehicle = {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
};

export default function PhysicalVehicleSelection() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [sheetState, setSheetState] = useState<BottomSheetState>('half');
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();

    getCurrentLocation();
    loadVehicles();
  }, []);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };
      setUserLocation(coords);
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    } catch {}
  };

  useEffect(() => {
    loadVehicles();
  }, [user?.id]);

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      setVehicles(data || []);
      if (data && data.length > 0) {
        const defaultVehicle = data.find(v => v.is_default) || data[0];
        setSelectedVehicle(defaultVehicle.id);
      }
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleVehicleSelect = async (vehicleId: string) => {
    await hapticFeedback('light');
    setSelectedVehicle(vehicleId);
  };

  const handleContinue = async () => {
    if (!selectedVehicle) return;
    await hapticFeedback('medium');
    router.push({
      pathname: '/owner/booking/physical/location',
      params: { vehicleId: selectedVehicle },
    });
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (userLocation) {
      setRegion({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    }
  };

  const handleExitBooking = async () => {
    await hapticFeedback('light');
    router.replace('/owner/owner-dashboard' as any);
  };

  const selectedVehicleData = vehicles.find(v => v.id === selectedVehicle);
  const previewText = selectedVehicleData
    ? `${selectedVehicleData.make} ${selectedVehicleData.model} • ${selectedVehicleData.registration}`
    : 'Select a vehicle';

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {/* Fullscreen map - always visible */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
        >
          {/* User location marker */}
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image 
                  source={require('../../../../assets/washing.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Header floating over the map */}
      <AppHeader 
        title="Select Vehicle" 
        subtitle="Choose your vehicle for the wash"
        showBack={true}
        onBack={() => router.back()}
        rightAction={
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            <TouchableOpacity 
              onPress={handleRecenter} 
              style={styles.recenterButton}
              activeOpacity={0.7}
            >
              <Ionicons name="locate" size={22} color={SKY} />
            </TouchableOpacity>
            <TouchableOpacity 
              onPress={handleExitBooking} 
              style={styles.exitButton}
              activeOpacity={0.7}
            >
              <Ionicons name="close" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        }
      />

      {/* Uber-style bottom sheet */}
      <UberBottomSheet
        state={sheetState}
        onStateChange={setSheetState}
        previewContent={
          <View style={styles.previewContent}>
            <View style={styles.previewRow}>
              <Ionicons name="car-sport" size={18} color={SKY} />
              <Text style={styles.previewText} numberOfLines={1}>
                {previewText}
              </Text>
            </View>
            {selectedVehicleData && (
              <Text style={styles.previewDetails}>
                {selectedVehicleData.color} • {selectedVehicleData.type}
              </Text>
            )}
          </View>
        }
        footerButton={
          selectedVehicle ? (
            <TouchableOpacity
              onPress={handleContinue}
              style={styles.continueButton}
              activeOpacity={0.85}
            >
              <LinearGradient
                colors={[SKY, '#0EA5E9']}
                style={styles.continueGradient}
              >
                <Text style={styles.continueText}>Continue</Text>
                <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
              </LinearGradient>
            </TouchableOpacity>
          ) : null
        }
      >
        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={SKY} />
            <Text style={styles.loadingText}>Loading vehicles...</Text>
          </View>
        ) : vehicles.length === 0 ? (
          <View style={styles.emptyContainer}>
            <View style={styles.emptyIconWrapper}>
              <Ionicons name="car-outline" size={64} color={SKY} style={{ opacity: 0.6 }} />
            </View>
            <Text style={styles.emptyTitle}>No vehicles found</Text>
            <Text style={styles.emptySubtext}>Add a vehicle to continue booking</Text>
            <TouchableOpacity
              onPress={() => router.push('/owner/settings/vehicle-management')}
              style={styles.addVehicleButton}
              activeOpacity={0.85}
            >
              <LinearGradient
                colors={[SKY, '#0EA5E9']}
                style={styles.addVehicleGradient}
              >
                <Ionicons name="add-circle" size={20} color="#FFFFFF" />
                <Text style={styles.addVehicleText}>Add Vehicle</Text>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Your Vehicles</Text>
            <Text style={styles.sectionSubtitle}>Swipe to see all options</Text>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.cardsScrollContent}
              snapToInterval={width - 40}
              decelerationRate="fast"
              pagingEnabled
              snapToAlignment="start"
            >
              {vehicles.map((vehicle) => {
                const isSelected = selectedVehicle === vehicle.id;
                return (
                  <View key={vehicle.id} style={[styles.cardWrapper, { width: width - 40 }]}>
                    <GlassCard
                      onPress={() => {
                        hapticFeedback('light');
                        handleVehicleSelect(vehicle.id);
                      }}
                      style={[styles.vehicleCard, isSelected && styles.vehicleCardSelected]}
                      borderColor={isSelected ? SKY : 'rgba(135,206,235,0.25)'}
                    >
                      <LinearGradient
                        colors={isSelected ? [SKY + '20', SKY + '10'] : ['transparent', 'transparent']}
                        style={StyleSheet.absoluteFill}
                      />
                      
                      <View style={styles.vehicleHeader}>
                        <View style={[styles.vehicleIconWrapper, isSelected && styles.vehicleIconWrapperSelected]}>
                          <Ionicons name="car-sport" size={28} color={isSelected ? SKY : 'rgba(135,206,235,0.8)'} />
                        </View>
                        <View style={styles.vehicleInfo}>
                          <View style={styles.vehicleNameRow}>
                            <View style={styles.vehicleNameContainer}>
                              <Text style={styles.vehicleName} numberOfLines={1}>
                                {vehicle.make} {vehicle.model}
                              </Text>
                              {vehicle.is_default && (
                                <View style={styles.defaultBadge}>
                                  <Ionicons name="star" size={10} color="#10B981" />
                                  <Text style={styles.defaultBadgeText}>Default</Text>
                                </View>
                              )}
                            </View>
                            {isSelected && (
                              <View style={styles.selectedCheck}>
                                <Ionicons name="checkmark-circle" size={24} color={SKY} />
                              </View>
                            )}
                          </View>
                          <View style={styles.vehicleDetailsRow}>
                            <View style={styles.detailItem}>
                              <Ionicons name="color-palette-outline" size={14} color={SKY} />
                              <Text style={styles.detailText}>{vehicle.color}</Text>
                            </View>
                            <View style={styles.detailDivider} />
                            <View style={styles.detailItem}>
                              <Ionicons name="document-text-outline" size={14} color={SKY} />
                              <Text style={styles.detailText}>{vehicle.registration}</Text>
                            </View>
                          </View>
                          <View style={styles.vehicleTypeRow}>
                            <Ionicons name="information-circle-outline" size={12} color="rgba(249,250,251,0.6)" />
                            <Text style={styles.vehicleTypeText}>{vehicle.type}</Text>
                          </View>
                        </View>
                      </View>
                    </GlassCard>
                  </View>
                );
              })}
            </ScrollView>
          </View>
        )}
      </UberBottomSheet>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  previewContent: {
    gap: 6,
  },
  previewRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  previewText: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '800',
    flex: 1,
  },
  previewDetails: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
    marginLeft: 26,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '900',
    marginBottom: 6,
    letterSpacing: -0.5,
  },
  sectionSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    marginBottom: 16,
    fontWeight: '600',
  },
  cardsScrollContent: {
    paddingRight: 20,
    gap: 12,
  },
  cardWrapper: {
    marginRight: 12,
  },
  vehicleCard: {
    padding: 20,
    borderRadius: 20,
  },
  vehicleCardSelected: {
    elevation: 12,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    borderWidth: 2,
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  emptyContainer: {
    alignItems: 'center',
    padding: 40,
  },
  emptyIconWrapper: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
  },
  emptySubtext: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
  },
  addVehicleButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addVehicleGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
    gap: 8,
  },
  addVehicleText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  vehicleHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 16,
  },
  vehicleIconWrapper: {
    width: 60,
    height: 60,
    borderRadius: 30,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  vehicleIconWrapperSelected: {
    backgroundColor: SKY + '25',
    borderColor: SKY,
  },
  defaultBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.4)',
    marginLeft: 8,
    flexShrink: 0,
  },
  defaultBadgeText: {
    color: '#10B981',
    fontSize: 10,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  vehicleInfo: {
    flex: 1,
  },
  vehicleNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 10,
  },
  vehicleNameContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
    flexWrap: 'wrap',
  },
  vehicleName: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  selectedCheck: {
    marginLeft: 8,
  },
  vehicleDetailsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 10,
  },
  detailItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(135,206,235,0.12)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  detailDivider: {
    width: 1,
    height: 20,
    backgroundColor: 'rgba(135,206,235,0.3)',
  },
  detailText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '700',
  },
  vehicleTypeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  vehicleTypeText: {
    color: 'rgba(249,250,251,0.6)',
    fontSize: 12,
    fontWeight: '600',
  },
  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(15, 23, 42, 0.7)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    elevation: 4,
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  continueButton: {
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 12,
  },
  continueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 24,
    gap: 10,
  },
  continueText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: 0.3,
  },
});
