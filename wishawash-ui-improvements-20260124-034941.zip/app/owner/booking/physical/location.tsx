import React, { useEffect, useState, useRef, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Animated,
  Alert,
  Image,
  ScrollView,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import * as Location from 'expo-location';
import MapView, { Region, Marker } from 'react-native-maps';

import { supabase } from '../../../../src/lib/supabase';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import GlassCard from '../../../../src/components/booking/GlassCard';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { colors } from '../../../../src/constants/colors';
import { Hub } from '../../../../src/types/booking';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../components/NavigationTab';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const BG = colors.BG;
const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY;

type LatLng = { latitude: number; longitude: number };

// Local extension for this screen (no need to touch shared Hub type)
type HubRow = Hub & {
  eco_washing?: boolean | null;
  detailing_offered?: boolean | null;
};

const safeBool = (v: any) => v === true;

export default function PhysicalLocationSelect() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ vehicleId?: string }>();
  const { coords } = useLiveLocation();
  const vehicleId = params.vehicleId;

  const [loading, setLoading] = useState(true);
  const [hubs, setHubs] = useState<HubRow[]>([]);
  const [selectedHub, setSelectedHub] = useState<HubRow | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: coords?.latitude || 51.5074,
    longitude: coords?.longitude || -0.1278,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  });
  const [userLocation, setUserLocation] = useState<LatLng | null>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();

    loadHubs();
    getCurrentLocation();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (coords) {
      setUserLocation(coords);
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.05,
        longitudeDelta: 0.05,
      });
    }
  }, [coords]);

  const normalizeHubs = (rows: any[]): HubRow[] =>
    (rows || [])
      .map((h) => ({
        ...h,
        latitude: Number(h.latitude),
        longitude: Number(h.longitude),
        eco_washing: safeBool(h.eco_washing),
        detailing_offered: safeBool(h.detailing_offered),
      }))
      .filter((h) => Number.isFinite(h.latitude) && Number.isFinite(h.longitude));

  const loadHubs = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude,status,eco_washing,detailing_offered');

      if (error) throw error;
      const normalized = normalizeHubs(data || []);
      setHubs(normalized);

      // Update map region to fit all hubs and user location
      if (normalized.length > 0) {
        const lats = normalized.map(h => h.latitude).filter(Number.isFinite);
        const lngs = normalized.map(h => h.longitude).filter(Number.isFinite);
        
        // Include user location if available
        if (coords) {
          lats.push(coords.latitude);
          lngs.push(coords.longitude);
        }
        
        if (lats.length > 0 && lngs.length > 0) {
          const minLat = Math.min(...lats);
          const maxLat = Math.max(...lats);
          const minLng = Math.min(...lngs);
          const maxLng = Math.max(...lngs);
          
          // Add padding to ensure all markers are visible
          const latPadding = (maxLat - minLat) * 0.2;
          const lngPadding = (maxLng - minLng) * 0.2;
          
          setRegion({
            latitude: (minLat + maxLat) / 2,
            longitude: (minLng + maxLng) / 2,
            latitudeDelta: Math.max((maxLat - minLat) * 1.4 + latPadding, 0.1),
            longitudeDelta: Math.max((maxLng - minLng) * 1.4 + lngPadding, 0.1),
          });
        }
      }
    } catch (err: any) {
      Alert.alert('Hubs Error', err?.message || 'Failed to load hubs');
      setHubs([]);
    } finally {
      setLoading(false);
    }
  };

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };
      setUserLocation(coords);
    } catch {}
  };

  const calculateDistance = useCallback(
    (hub: HubRow) => {
      if (!coords || !hub.latitude || !hub.longitude) return null;
      const toRad = (v: number) => (v * Math.PI) / 180;
      const R = 3959;

      const dLat = toRad(hub.latitude - coords.latitude);
      const dLon = toRad(hub.longitude - coords.longitude);
      const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(toRad(coords.latitude)) *
          Math.cos(toRad(hub.latitude)) *
          Math.sin(dLon / 2) ** 2;

      return (R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)))).toFixed(1);
    },
    [coords]
  );

  const filteredHubs = useMemo(() => {
    if (!coords) return hubs;
    return hubs
      .map(hub => ({ hub, distance: calculateDistance(hub) }))
      .filter(({ distance }) => distance && Number(distance) <= 10)
      .sort((a, b) => Number(a.distance) - Number(b.distance))
      .map(({ hub }) => hub);
  }, [hubs, coords, calculateDistance]);


  const handleHubSelect = (hub: HubRow) => {
    setSelectedHub(hub);
    if (hub.latitude && hub.longitude) {
      setRegion({
        latitude: hub.latitude,
        longitude: hub.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    }
  };

  const handleContinue = async () => {
    if (!selectedHub) {
      Alert.alert('Hub Required', 'Please select a wash hub to continue.');
      return;
    }
    if (!vehicleId) {
      Alert.alert('Vehicle Required', 'Please select a vehicle first.');
      router.push('/owner/settings/vehicle-management');
      return;
    }
    await hapticFeedback('medium');
    router.push({
      pathname: '/owner/booking/physical/service',
      params: { locationId: selectedHub.id, vehicleId },
    });
  };

  const handleExitBooking = async () => {
    await hapticFeedback('light');
    router.replace('/owner/owner-dashboard' as any);
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (coords) {
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.05,
        longitudeDelta: 0.05,
      });
    } else if (userLocation) {
      setRegion({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.05,
        longitudeDelta: 0.05,
      });
    }
  };


  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill} pointerEvents="box-none">
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          zIndex={0}
        >
          {/* User location marker */}
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image 
                  source={require('../../../../assets/washing.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {/* Hub markers - show ALL hubs on map, not just filtered ones */}
          {hubs.map((hub) => {
            if (!hub.latitude || !hub.longitude) return null;
            const isSelected = selectedHub?.id === hub.id;
            const distance = calculateDistance(hub);
            const isWithinRange = distance && Number(distance) <= 10;
            
            return (
              <Marker
                key={hub.id}
                coordinate={{ latitude: hub.latitude, longitude: hub.longitude }}
                onPress={() => handleHubSelect(hub)}
              >
                <View style={styles.hubMarkerContainer}>
                  <Image 
                    source={require('../../../../assets/washing.png')} 
                    style={[
                      styles.hubMarkerImage,
                      isSelected && styles.hubMarkerImageSelected,
                      !isWithinRange && styles.hubMarkerImageOutOfRange
                    ]}
                    resizeMode="contain"
                  />
                  {!isWithinRange && (
                    <View style={styles.outOfRangeBadge}>
                      <Text style={styles.outOfRangeText}>Far</Text>
                    </View>
                  )}
                </View>
              </Marker>
            );
          })}
        </MapView>
      </View>

      {/* Header floating over the map */}
      <AppHeader 
        title="Nearby Wash Hubs" 
        subtitle="Select a verified wash hub near you"
        showBack={true}
        onBack={() => router.back()}
        rightAction={
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            <TouchableOpacity 
              onPress={handleRecenter} 
              style={styles.recenterButton}
              activeOpacity={0.7}
            >
              <Ionicons name="locate" size={22} color={SKY} />
            </TouchableOpacity>
            <TouchableOpacity 
              onPress={handleExitBooking} 
              style={styles.exitButton}
              activeOpacity={0.7}
            >
              <Ionicons name="close" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        }
      />

      {/* Hub cards - floating style matching on-demand cards */}
      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            paddingBottom: Math.max(insets.bottom, 14) + 14 + TAB_BAR_TOTAL_HEIGHT + 12,
          },
        ]}
      >
        {loading ? (
          <GlassCard style={styles.card}>
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color={SKY} />
              <Text style={styles.loadingText}>Finding nearby hubs...</Text>
            </View>
          </GlassCard>
        ) : filteredHubs.length === 0 ? (
          <GlassCard style={styles.card}>
            <View style={styles.emptyContent}>
              <Ionicons name="map-outline" size={48} color={SKY} style={{ opacity: 0.5 }} />
              <Text style={styles.emptyText}>No hubs available</Text>
              <Text style={styles.emptySubtext}>Try again later or adjust your location</Text>
            </View>
          </GlassCard>
        ) : (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.cardsScrollContent}
            snapToInterval={width * 0.75}
            decelerationRate="fast"
            pagingEnabled
            snapToAlignment="start"
          >
            {filteredHubs.map((hub) => {
              const isSelected = selectedHub?.id === hub.id;
              const distance = calculateDistance(hub);
              
              return (
                <View key={hub.id} style={[styles.cardWrapper, { width: width * 0.75 }]}>
                  <GlassCard
                    onPress={() => handleHubSelect(hub)}
                    style={[styles.card, isSelected && styles.cardSelected]}
                    borderColor={isSelected ? SKY : 'rgba(135,206,235,0.3)'}
                    accountType="customer"
                    intensity={30}
                  >
                    <View style={styles.hubHeader}>
                      <View style={styles.hubIconWrapper}>
                        <Ionicons name="location" size={20} color={SKY} />
                      </View>
                      <View style={styles.hubInfo}>
                        <Text style={styles.hubName}>{hub.name}</Text>
                        <Text style={styles.addressText} numberOfLines={2}>{hub.address}</Text>
                      </View>
                      {distance && (
                        <View style={styles.distanceBadge}>
                          <Text style={styles.distanceText}>{distance} mi</Text>
                        </View>
                      )}
                    </View>

                    {isSelected && (
                      <View style={styles.actionsRow}>
                        <TouchableOpacity
                          onPress={handleContinue}
                          style={styles.continueBtn}
                          activeOpacity={0.9}
                        >
                          <LinearGradient
                            colors={[SKY, '#60A5FA']}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 0 }}
                            style={styles.continueBtnGradient}
                          >
                            <Text style={styles.continueBtnText}>Continue</Text>
                            <Ionicons name="arrow-forward" size={16} color="#FFFFFF" />
                          </LinearGradient>
                        </TouchableOpacity>
                      </View>
                    )}
                  </GlassCard>
                </View>
              );
            })}
          </ScrollView>
        )}
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 10, // Ensure user marker is above card overlay
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  hubMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
    zIndex: 10, // Ensure hub markers are above card overlay
  },
  hubMarkerImage: {
    width: 48,
    height: 48,
  },
  hubMarkerImageSelected: {
    width: 56,
    height: 56,
  },
  hubMarkerImageOutOfRange: {
    opacity: 0.6,
    tintColor: '#9CA3AF',
  },
  outOfRangeBadge: {
    position: 'absolute',
    bottom: -18,
    left: '50%',
    transform: [{ translateX: -20 }],
    backgroundColor: 'rgba(15, 23, 42, 0.9)',
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#6B7280',
  },
  outOfRangeText: {
    color: '#9CA3AF',
    fontSize: 9,
    fontWeight: '600',
  },
  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  card: {
    padding: 20,
    backgroundColor: 'transparent',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    borderRadius: 20,
    minHeight: 120,
    overflow: 'hidden',
  },
  cardWrapper: {
    marginRight: 12,
    marginLeft: 0,
  },
  cardSelected: {
    elevation: 16,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.4,
    shadowRadius: 16,
    borderWidth: 2,
    borderColor: SKY,
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
  },
  emptyContent: {
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtext: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
  },
  hubHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 4,
  },
  hubIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.12)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  hubInfo: {
    flex: 1,
    gap: 4,
  },
  hubName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  addressText: {
    color: 'rgba(249,250,251,0.75)',
    fontSize: 13,
    lineHeight: 18,
  },
  distanceBadge: {
    backgroundColor: 'rgba(135,206,235,0.15)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  distanceText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '700',
  },
  actionsRow: {
    marginTop: 14,
  },
  continueBtn: {
    height: 48,
    borderRadius: 14,
    overflow: 'hidden',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 8,
  },
  continueBtnGradient: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingHorizontal: 20,
  },
  continueBtnText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
});
