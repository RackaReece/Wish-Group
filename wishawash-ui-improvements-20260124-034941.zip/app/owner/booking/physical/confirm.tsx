import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Image,
  Animated,
  StatusBar,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { supabase } from '../../../../src/lib/supabase';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { serviceOptions } from '../../../../src/constants/serviceOptions';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { colors } from '../../../../src/constants/colors';
import { Hub } from '../../../../src/types/booking';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../components/NavigationTab';

const SKY = colors.SKY;
const BG = colors.BG;

export default function PhysicalConfirm() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();

  const params = useLocalSearchParams<{
    locationId?: string;
    serviceId?: string;
    vehicleId?: string;
    washType?: string;
    scheduledAt?: string;
  }>();

  const { locationId, serviceId, vehicleId, washType, scheduledAt } = params;

  const [hub, setHub] = useState<Hub | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const { coords } = useLiveLocation();
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  const service = serviceOptions.find((opt) => opt.id === serviceId);

  /* ------------------ Load location ------------------ */
  useEffect(() => {
    if (!locationId) return;

    const fetchHub = async () => {
      setLoading(true);

      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude')
        .eq('id', locationId)
        .maybeSingle();

      if (!error && data) {
        const hubData = data as Hub;
        setHub(hubData);
        
        // Update map region if hub has coordinates
        if (hubData.latitude && hubData.longitude) {
          setRegion({
            latitude: Number(hubData.latitude),
            longitude: Number(hubData.longitude),
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          });
        }
      } else {
        setHub(null);
      }

      setLoading(false);
    };

    fetchHub();
    getCurrentLocation();
  }, [locationId]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    if (coords) {
      setUserLocation(coords);
    }
  }, [coords]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };
      setUserLocation(coords);
    } catch {}
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (hub?.latitude && hub?.longitude) {
      setRegion({
        latitude: Number(hub.latitude),
        longitude: Number(hub.longitude),
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    } else if (coords) {
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    }
  };

  /* ------------------ Confirm booking ------------------ */
  const handleConfirm = async () => {
    if (!user?.id || !service || !hub || !scheduledAt || !vehicleId) return;

    try {
      setSubmitting(true);
      await hapticFeedback('medium');

      // ✅ IMPORTANT:
      // Your DB does NOT have `customer_id`. Most schemas use `user_id` for the customer.
      // If yours is different (eg `owner_id`), change THIS ONE KEY.
      const BOOKING_CUSTOMER_COL = 'user_id';

      const insertPayload: any = {
        [BOOKING_CUSTOMER_COL]: user.id,
        vehicle_id: vehicleId,
        location_id: hub.id,
        service_type: service.id,
        service_name: service.name,
        price: service.price,
        wash_type: washType || null,
        status: 'pending_payment',
        scheduled_at: scheduledAt,
        location_address: hub.address,
        location_lat: hub.latitude,
        location_lng: hub.longitude,
        // created_at: new Date().toISOString(), // usually handled by DB default
      };

      const { data, error } = await supabase
        .from('bookings')
        .insert(insertPayload)
        .select('id')
        .single();

      if (error) throw error;

      router.replace({
        pathname: '/owner/booking/payment',
        params: { bookingId: data.id },
      });
    } catch (err: any) {
      console.error('[physical-confirm] booking error', err);
      Alert.alert('Error', err?.message || 'Unable to create booking');
    } finally {
      setSubmitting(false);
    }
  };

  /* ------------------ Guard ------------------ */
  if (!service || !scheduledAt || !locationId || !vehicleId) {
    return (
      <SafeAreaView style={[styles.container, styles.center]} edges={[]}>
        <Text style={{ color: '#fff' }}>Missing booking information.</Text>
      </SafeAreaView>
    );
  }

  const formattedTime = new Date(scheduledAt).toLocaleString('en-GB', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
    hour: '2-digit',
    minute: '2-digit',
  });

  /* ------------------ UI ------------------ */
  // Custom map style to blur/hide labels for privacy
  const mapStyle = [
    {
      featureType: 'all',
      elementType: 'labels',
      stylers: [{ visibility: 'off' }],
    },
    {
      featureType: 'poi',
      elementType: 'labels',
      stylers: [{ visibility: 'off' }],
    },
    {
      featureType: 'road',
      elementType: 'labels',
      stylers: [{ visibility: 'off' }],
    },
    {
      featureType: 'transit',
      elementType: 'labels',
      stylers: [{ visibility: 'off' }],
    },
  ];

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <StatusBar hidden={true} />
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={mapStyle}
        >
          {/* User location marker */}
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image 
                  source={require('../../../../assets/washing.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {/* Hub location marker */}
          {hub?.latitude && hub?.longitude && (
            <Marker coordinate={{ latitude: Number(hub.latitude), longitude: Number(hub.longitude) }}>
              <View style={styles.hubMarkerContainer}>
                <Image 
                  source={require('../../../../assets/washing.png')} 
                  style={styles.hubMarkerImage}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Back button only */}
      <View style={[styles.headerContainer, { top: insets.top + 16 }]}>
        <TouchableOpacity 
          onPress={() => router.back()}
          style={styles.backButton}
          activeOpacity={0.7}
        >
          <Ionicons name="arrow-back" size={22} color={SKY} />
        </TouchableOpacity>
      </View>

      {/* Booking summary card - floating over map */}
      <Animated.View
        style={[
          styles.summaryContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            paddingBottom: Math.max(insets.bottom, 14) + 100, // Space for payment button
          },
        ]}
      >
        {loading ? (
          <GlassCard style={styles.loadingCard} accountType="customer">
            <ActivityIndicator size="large" color={SKY} />
            <Text style={styles.loadingText}>Loading booking details...</Text>
          </GlassCard>
        ) : (
          <GlassCard style={styles.summaryCard} accountType="customer" intensity={60}>
            <View style={styles.summaryHeader}>
              <View style={styles.summaryIcon}>
                <Ionicons name="calendar-outline" size={24} color={SKY} />
              </View>
              <Text style={styles.summaryTitle}>Booking Summary</Text>
            </View>

            <View style={styles.summarySection}>
              <Text style={styles.summaryLabel}>Service</Text>
              <Text style={styles.summaryValue}>{service?.name || 'Service'}</Text>
              <Text style={styles.summarySubtitle}>{service?.desc || ''}</Text>
              <View style={styles.summaryRow}>
                <View style={styles.summaryMetaContainer}>
                  <Ionicons name="time-outline" size={14} color="rgba(249,250,251,0.7)" />
                  <Text style={styles.summaryMeta}>{service?.dur || ''}</Text>
                </View>
                <Text style={styles.summaryPrice}>£{service?.price || '0'}</Text>
              </View>
            </View>

            {hub && (
              <View style={styles.summarySection}>
                <Text style={styles.summaryLabel}>Location</Text>
                <Text style={styles.summaryValue}>{hub.name}</Text>
                <Text style={styles.summarySubtitle}>{hub.address}</Text>
              </View>
            )}

            <View style={[styles.summarySection, styles.summarySectionLast]}>
              <Text style={styles.summaryLabel}>Time Slot</Text>
              <Text style={styles.summaryValue}>{formattedTime}</Text>
              <Text style={styles.summarySubtitle}>Arrive 5 minutes early to keep your slot.</Text>
            </View>
          </GlassCard>
        )}
      </Animated.View>

      {/* Floating payment button */}
      <View style={[styles.footer, { paddingBottom: insets.bottom + 16 }]}>
        <TouchableOpacity
          style={[styles.paymentButton, submitting && { opacity: 0.6 }]}
          onPress={handleConfirm}
          disabled={submitting || loading || !hub}
          activeOpacity={0.85}
        >
          {submitting ? (
            <ActivityIndicator color={BG} />
          ) : (
            <Ionicons name="wallet" size={24} color={BG} />
          )}
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

/* ------------------ Styles ------------------ */
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  hubMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  hubMarkerImage: {
    width: 48,
    height: 48,
  },
  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  summaryContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
    backgroundColor: 'transparent',
  },
  loadingCard: {
    padding: 20,
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  summaryCard: {
    padding: 24,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  summaryHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 20,
  },
  summaryIcon: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.18)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  summaryTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  summarySection: {
    marginBottom: 20,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.18)',
  },
  summarySectionLast: {
    marginBottom: 0,
    paddingBottom: 0,
    borderBottomWidth: 0,
  },
  summaryLabel: {
    color: 'rgba(135,206,235,0.85)',
    fontSize: 11,
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: 8,
    fontWeight: '800',
  },
  summaryValue: {
    color: '#F9FAFB',
    fontSize: 19,
    fontWeight: '800',
    marginBottom: 6,
    letterSpacing: -0.3,
  },
  summarySubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    marginTop: 4,
    lineHeight: 20,
  },
  summaryRow: {
    marginTop: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  summaryMetaContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  summaryMeta: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  summaryPrice: {
    color: '#F9FAFB',
    fontSize: 19,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  headerContainer: {
    position: 'absolute',
    left: 16,
    zIndex: 1000,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 20,
    backgroundColor: 'transparent',
    justifyContent: 'flex-end',
    alignItems: 'flex-end',
  },
  paymentButton: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
});
