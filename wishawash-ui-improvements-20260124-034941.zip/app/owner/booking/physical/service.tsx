import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Alert,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Location from 'expo-location';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { supabase } from '../../../../src/lib/supabase';
import { serviceOptions } from '../../../../src/constants/serviceOptions';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../components/NavigationTab';

const { width, height } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;

// Uber-style dark map theme
const uberDarkMapStyle = [
  {
    elementType: 'geometry',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.fill',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'administrative.locality',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'geometry',
    stylers: [{ color: '#263c3f' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#6b9a76' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry',
    stylers: [{ color: '#38414e' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#212a37' }],
  },
  {
    featureType: 'road',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#9ca5b3' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#1f2835' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#f3d19c' }],
  },
  {
    featureType: 'transit',
    elementType: 'geometry',
    stylers: [{ color: '#2f3948' }],
  },
  {
    featureType: 'transit.station',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [{ color: '#17263c' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#515c6d' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#17263c' }],
  },
];

type TierId = 'bronze-wash' | 'silver-wash' | 'gold-wash' | 'platinum-wash';

type ServiceUI = {
  id: TierId;
  name: string;
  desc: string;
  dur: string;
  minutes: number;
  price: number;
  is_enabled: boolean;
  badge?: 'Quick & Affordable' | 'Most Popular' | 'Premium Detail';
  bulletPoints?: string[];
};

const TIERS: Array<{
  id: TierId;
  service_name: 'Bronze Wash' | 'Silver Wash' | 'Gold Wash' | 'Platinum Wash';
  defaultDesc: string;
  defaultMinutes: number;
  badge?: 'Quick & Affordable' | 'Most Popular' | 'Premium Detail';
}> = [
  {
    id: 'bronze-wash',
    service_name: 'Bronze Wash',
    defaultDesc: 'Mini Valet - Quick and efficient basic clean',
    defaultMinutes: 30,
    badge: 'Quick & Affordable',
  },
  {
    id: 'silver-wash',
    service_name: 'Silver Wash',
    defaultDesc: 'Standard Valet - Complete interior & exterior clean',
    defaultMinutes: 45,
  },
  {
    id: 'gold-wash',
    service_name: 'Gold Wash',
    defaultDesc: 'Full Valet - Comprehensive deep clean service',
    defaultMinutes: 60,
    badge: 'Most Popular',
  },
  {
    id: 'platinum-wash',
    service_name: 'Platinum Wash',
    defaultDesc: 'Ultimate Valet - Premium luxury detailing service',
    defaultMinutes: 90,
    badge: 'Premium Detail',
  },
];

function money(n: any) {
  const v = typeof n === 'string' ? Number(n) : typeof n === 'number' ? n : 0;
  if (!Number.isFinite(v)) return 0;
  return v;
}

export default function PhysicalServiceSelection() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams();
  const locationId = params.locationId as string;
  const vehicleId = params.vehicleId as string;

  const [selectedService, setSelectedService] = useState<TierId | null>(null);
  const [washType, setWashType] = useState<'exterior' | 'interior' | 'both' | null>(null);
  const [expandedFeatures, setExpandedFeatures] = useState<Set<TierId>>(new Set());
  const scrollViewRef = useRef<ScrollView>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  const [loading, setLoading] = useState(true);
  const [services, setServices] = useState<ServiceUI[]>([]);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [hubLocation, setHubLocation] = useState<{ latitude: number; longitude: number; name: string; address: string } | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    getCurrentLocation();
    if (!locationId) {
      setLoading(false);
      setLoadError('Missing location.');
      return;
    }
    loadHubLocation();
    loadTierPrices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locationId]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };
      setUserLocation(coords);
    } catch {}
  };

  const loadHubLocation = async () => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, latitude, longitude')
        .eq('id', locationId)
        .single();

      if (error) throw error;
      if (data && data.latitude && data.longitude) {
        const hub = {
          latitude: Number(data.latitude),
          longitude: Number(data.longitude),
          name: data.name || 'Wash Hub',
          address: data.address || '',
        };
        setHubLocation(hub);
        setRegion({
          latitude: hub.latitude,
          longitude: hub.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      }
    } catch (err) {
      console.error('Error loading hub location:', err);
    }
  };

  const loadTierPrices = async () => {
    try {
      setLoading(true);
      setLoadError(null);

      const { data, error } = await supabase
        .from('location_services')
        .select('service_name, price, duration_minutes, is_enabled')
        .eq('location_id', locationId);

      if (error) throw error;

      const rows = (data || []) as Array<{
        service_name: string | null;
        price: number | null;
        duration_minutes: number | null;
        is_enabled: boolean | null;
      }>;

      const map = new Map<string, { price: number; minutes: number; enabled: boolean }>();
      rows.forEach((r) => {
        const name = (r.service_name || '').trim();
        if (!name) return;
        map.set(name, {
          price: money(r.price),
          minutes: typeof r.duration_minutes === 'number' && r.duration_minutes > 0 ? r.duration_minutes : 0,
          enabled: r.is_enabled === null || r.is_enabled === undefined ? true : !!r.is_enabled,
        });
      });

      const built: ServiceUI[] = TIERS.map((t) => {
        const hit = map.get(t.service_name);
        const minutes = hit?.minutes ? hit.minutes : t.defaultMinutes;
        const durText = `${minutes} min`;
        const serviceOption = serviceOptions.find(so => so.id === t.id);
        
        return {
          id: t.id,
          name: t.service_name,
          desc: t.defaultDesc,
          minutes,
          dur: durText,
          price: hit?.price ?? 0,
          is_enabled: hit?.enabled ?? false,
          badge: t.badge,
          bulletPoints: serviceOption?.bulletPoints || [],
        };
      }).filter((s) => s.is_enabled);

      setServices(built);

      setSelectedService((prev) => {
        if (!prev) return prev;
        const stillThere = built.some((b) => b.id === prev);
        return stillThere ? prev : null;
      });
    } catch (e: any) {
      console.error('[PhysicalServiceSelection] loadTierPrices error:', e);
      setLoadError(e?.message || 'Failed to load pricing.');
      setServices([]);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceSelect = async (serviceId: TierId) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
    if (serviceId !== 'bronze-wash') {
      setWashType('both');
    } else {
      setWashType(null);
    }
  };

  const handleWashTypeSelect = async (type: 'exterior' | 'interior' | 'both') => {
    await hapticFeedback('light');
    setWashType(type);
  };

  const toggleFeatures = (serviceId: TierId) => {
    setExpandedFeatures(prev => {
      const next = new Set(prev);
      if (next.has(serviceId)) {
        next.delete(serviceId);
      } else {
        next.add(serviceId);
      }
      return next;
    });
  };

  const selectedServiceData = useMemo(
    () => services.find((s) => s.id === selectedService) || null,
    [services, selectedService]
  );

  // Calculate pricing tiers (small/medium/large)
  const getPriceTiers = (basePrice: number) => {
    return {
      small: basePrice,
      medium: Math.round(basePrice * 1.2 * 100) / 100,
      large: Math.round(basePrice * 1.4 * 100) / 100,
    };
  };

  const bronzeExteriorPrice = selectedServiceData?.price ?? 0;
  const bronzeInteriorPrice = selectedServiceData?.price ?? 0;

  const canContinue =
    !!selectedService &&
    !!locationId &&
    !!vehicleId &&
    (selectedService !== 'bronze-wash' || !!washType);

  const handleContinue = async () => {
    if (!canContinue) return;

    if (!selectedServiceData || !Number.isFinite(selectedServiceData.price) || selectedServiceData.price <= 0) {
      Alert.alert('Unavailable', 'This service does not have a price set yet. Please pick another option.');
      return;
    }

    await hapticFeedback('medium');

    let finalPrice = selectedServiceData.price;
    if (selectedService === 'bronze-wash') {
      if (washType === 'interior') finalPrice = bronzeInteriorPrice;
      else finalPrice = bronzeExteriorPrice; // Default to exterior if not specified
    }

    router.push({
      pathname: '/owner/booking/physical/schedule',
      params: {
        serviceId: selectedService,
        vehicleId,
        locationId,
        washType: washType || '',
        price: String(finalPrice),
      },
    });
  };

  const handleExitBooking = async () => {
    await hapticFeedback('light');
    router.replace('/owner/owner-dashboard' as any);
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (hubLocation) {
      setRegion({
        latitude: hubLocation.latitude,
        longitude: hubLocation.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    } else if (userLocation) {
      setRegion({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    }
  };


  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader 
          title="Select Service" 
          showBack={true}
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading prices...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (loadError) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader 
          title="Select Service" 
          showBack={true}
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <Ionicons name="alert-circle-outline" size={44} color={SKY} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>{loadError}</Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              loadTierPrices();
            }}
            style={styles.retryBtn}
            activeOpacity={0.85}
          >
            <LinearGradient colors={[SKY, '#60A5FA']} style={styles.retryGrad}>
              <Ionicons name="refresh" size={18} color="#fff" />
              <Text style={styles.retryText}>Retry</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (!services.length) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader 
          title="Select Service" 
          showBack={true}
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <Ionicons name="pricetag-outline" size={44} color={SKY} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This location hasn't enabled any services yet.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={uberDarkMapStyle}
        >
          {/* User location marker */}
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image 
                  source={require('../../../../assets/washing.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {/* Hub location marker */}
          {hubLocation && (
            <Marker coordinate={{ latitude: hubLocation.latitude, longitude: hubLocation.longitude }}>
              <View style={styles.hubMarkerContainer}>
                <Image 
                  source={require('../../../../assets/washing.png')} 
                  style={styles.hubMarkerImage}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Header floating over the map */}
      <AppHeader 
        title="Select Service" 
        subtitle={hubLocation?.name || 'Choose your wash service'}
        showBack={true}
        onBack={() => router.back()}
        rightAction={
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            <TouchableOpacity 
              onPress={handleRecenter} 
              style={styles.recenterButton}
              activeOpacity={0.7}
            >
              <Ionicons name="locate" size={22} color={SKY} />
            </TouchableOpacity>
            <TouchableOpacity 
              onPress={handleExitBooking} 
              style={styles.exitButton}
              activeOpacity={0.7}
            >
              <Ionicons name="close" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        }
      />

      {/* Service cards - floating at bottom */}
      <Animated.View
        style={[
          styles.cardContainer,
          {
            opacity: fadeAnim,
            paddingBottom: Math.max(insets.bottom, 14) + 14,
          },
        ]}
      >
        <ScrollView
          ref={scrollViewRef}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          snapToInterval={width - 32}
          decelerationRate="fast"
          contentContainerStyle={styles.cardsScrollContent}
          onMomentumScrollEnd={(e) => {
            const index = Math.round(e.nativeEvent.contentOffset.x / (width - 32));
            if (services[index]) {
              handleServiceSelect(services[index].id);
            }
          }}
        >
            {services.map((service, index) => {
              const isSelected = selectedService === service.id;
              const isExpanded = expandedFeatures.has(service.id);
              const priceTiers = getPriceTiers(service.price);
              const visibleFeatures = service.bulletPoints?.slice(0, 4) || [];
              const hiddenFeatures = service.bulletPoints?.slice(4) || [];
              const hasMoreFeatures = hiddenFeatures.length > 0;

              return (
                <View key={service.id} style={[styles.cardWrapper, { width: width - 32 }]}>
                  <TouchableOpacity
                    onPress={() => handleServiceSelect(service.id)}
                    activeOpacity={0.8}
                    style={[
                      styles.uberServiceCard,
                      isSelected && styles.uberServiceCardSelected,
                    ]}
                  >
                    <View style={styles.uberServiceCardContent}>
                      {/* Wish-a-Wash branding */}
                      <View style={styles.brandingContainer}>
                        <Ionicons name="sparkles" size={16} color={SKY} />
                        <Text style={styles.brandingText}>Wish Certified</Text>
                      </View>

                      {/* Header */}
                      <View style={styles.uberServiceHeader}>
                        <View style={styles.uberServiceIconContainer}>
                          <Ionicons 
                            name={service.id === 'bronze-wash' ? 'water' : service.id === 'gold-wash' ? 'diamond' : service.id === 'platinum-wash' ? 'star' : 'sparkles'} 
                            size={24} 
                            color={SKY} 
                          />
                        </View>
                        <View style={styles.uberServiceInfo}>
                          <View style={styles.uberServiceTitleRow}>
                            <Text style={styles.uberServiceName}>{service.name}</Text>
                            {service.badge && (
                              <View style={[
                                styles.badge,
                                service.badge === 'Most Popular' && styles.badgePopular,
                                service.badge === 'Premium Detail' && styles.badgePremium,
                              ]}>
                                <Text style={[
                                  styles.badgeText,
                                  service.badge === 'Most Popular' && styles.badgePopularText,
                                  service.badge === 'Premium Detail' && styles.badgePremiumText,
                                ]}>
                                  {service.badge === 'Most Popular' && '⭐ '}
                                  {service.badge === 'Premium Detail' && '👑 '}
                                  {service.badge}
                                </Text>
                              </View>
                            )}
                          </View>
                          <View style={styles.uberServiceTimeRow}>
                            <Ionicons name="time-outline" size={14} color="rgba(255,255,255,0.7)" />
                            <Text style={styles.uberServiceTime}>{service.dur}</Text>
                          </View>
                        </View>
                        <View style={styles.uberServicePrice}>
                          <Text style={styles.uberServicePriceText}>£{service.price.toFixed(0)}</Text>
                        </View>
                      </View>

                      {/* Description */}
                      <Text style={styles.serviceDesc}>{service.desc}</Text>

                      {/* Features - max 4 visible */}
                      {service.bulletPoints && service.bulletPoints.length > 0 && (
                        <View style={styles.featuresContainer}>
                          {visibleFeatures.map((feature, idx) => (
                            <View key={idx} style={styles.featureRow}>
                              <Ionicons name="checkmark-circle" size={16} color={SKY} />
                              <Text style={styles.featureText}>{feature}</Text>
                            </View>
                          ))}
                          {isExpanded && hiddenFeatures.map((feature, idx) => (
                            <View key={idx + 4} style={styles.featureRow}>
                              <Ionicons name="checkmark-circle" size={16} color={SKY} />
                              <Text style={styles.featureText}>{feature}</Text>
                            </View>
                          ))}
                          {hasMoreFeatures && (
                            <TouchableOpacity
                              onPress={() => toggleFeatures(service.id)}
                              style={styles.expandButton}
                            >
                              <Text style={styles.expandText}>
                                {isExpanded ? 'Show less' : `+${hiddenFeatures.length} more`}
                              </Text>
                              <Ionicons 
                                name={isExpanded ? 'chevron-up' : 'chevron-down'} 
                                size={14} 
                                color={SKY} 
                              />
                            </TouchableOpacity>
                          )}
                        </View>
                      )}

                      {/* Price tiers */}
                      <View style={styles.priceTiersContainer}>
                        <Text style={styles.priceTiersLabel}>Vehicle size pricing:</Text>
                        <View style={styles.priceTiersRow}>
                          <View style={styles.priceTierItem}>
                            <Text style={styles.priceTierLabel}>Small</Text>
                            <Text style={styles.priceTierValue}>£{priceTiers.small.toFixed(0)}</Text>
                          </View>
                          <View style={styles.priceTierItem}>
                            <Text style={styles.priceTierLabel}>Medium</Text>
                            <Text style={styles.priceTierValue}>£{priceTiers.medium.toFixed(0)}</Text>
                          </View>
                          <View style={styles.priceTierItem}>
                            <Text style={styles.priceTierLabel}>Large</Text>
                            <Text style={styles.priceTierValue}>£{priceTiers.large.toFixed(0)}</Text>
                          </View>
                        </View>
                      </View>

                      {/* Wash Type Selection - only for Bronze wash */}
                      {isSelected && selectedService === 'bronze-wash' && (
                        <View style={styles.washTypeSection}>
                          <Text style={styles.washTypeTitle}>Select Wash Type</Text>
                          <View style={styles.washTypeGrid}>
                            <TouchableOpacity
                              onPress={() => handleWashTypeSelect('exterior')}
                              style={[styles.washTypeCard, washType === 'exterior' && styles.washTypeCardSelected]}
                              activeOpacity={0.8}
                            >
                              <LinearGradient
                                colors={washType === 'exterior' ? [SKY + '30', SKY + '20'] : ['transparent', 'transparent']}
                                style={StyleSheet.absoluteFill}
                              />
                              <Ionicons name="car-sport-outline" size={28} color={washType === 'exterior' ? SKY : '#9CA3AF'} />
                              <Text style={[styles.washTypeLabel, washType === 'exterior' && { color: SKY }]}>
                                Exterior
                              </Text>
                              {washType === 'exterior' && (
                                <View style={styles.washTypeCheck}>
                                  <Ionicons name="checkmark-circle" size={16} color={SKY} />
                                </View>
                              )}
                            </TouchableOpacity>

                            <TouchableOpacity
                              onPress={() => handleWashTypeSelect('interior')}
                              style={[styles.washTypeCard, washType === 'interior' && styles.washTypeCardSelected]}
                              activeOpacity={0.8}
                            >
                              <LinearGradient
                                colors={washType === 'interior' ? [SKY + '30', SKY + '20'] : ['transparent', 'transparent']}
                                style={StyleSheet.absoluteFill}
                              />
                              <Ionicons name="home-outline" size={28} color={washType === 'interior' ? SKY : '#9CA3AF'} />
                              <Text style={[styles.washTypeLabel, washType === 'interior' && { color: SKY }]}>
                                Interior
                              </Text>
                              {washType === 'interior' && (
                                <View style={styles.washTypeCheck}>
                                  <Ionicons name="checkmark-circle" size={16} color={SKY} />
                                </View>
                              )}
                            </TouchableOpacity>
                          </View>
                        </View>
                      )}

                      {/* Action Button */}
                      {isSelected && (selectedService !== 'bronze-wash' || washType) && (
                        <View style={styles.uberServiceActionRow}>
                          <TouchableOpacity
                            onPress={handleContinue}
                            style={styles.uberServiceButton}
                            activeOpacity={0.9}
                          >
                            <Text style={styles.uberServiceButtonText}>Choose {service.name}</Text>
                          </TouchableOpacity>
                        </View>
                      )}
                    </View>
                  </TouchableOpacity>
                </View>
              );
            })}
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
    backgroundColor: 'transparent',
    zIndex: 100,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  hubMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  hubMarkerImage: {
    width: 48,
    height: 48,
  },
  content: { flex: 1 },
  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: 24 },
  loadingText: { color: SKY, fontSize: 14 },
  retryBtn: { marginTop: 10, borderRadius: 16, overflow: 'hidden' },
  retryGrad: { flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', paddingVertical: 12, paddingHorizontal: 18 },
  retryText: { color: '#fff', fontWeight: '800' },

  cardWrapper: {
    marginRight: 12,
    marginLeft: 0,
  },
  uberServiceCard: {
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderRadius: 20,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.2)',
    overflow: 'hidden',
    marginBottom: 12,
  },
  uberServiceCardSelected: {
    borderColor: SKY,
    borderWidth: 2,
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  uberServiceCardContent: {
    padding: 20,
  },
  uberServiceHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  uberServiceIconContainer: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: SKY + '15',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  uberServiceInfo: {
    flex: 1,
  },
  uberServiceTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 6,
  },
  uberServiceName: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
    flex: 1,
  },
  uberServiceCapacity: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginLeft: 8,
  },
  uberServiceCapacityText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    fontWeight: '500',
  },
  uberServiceTimeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  uberServiceTime: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '500',
  },
  uberServicePrice: {
    alignItems: 'flex-end',
    justifyContent: 'center',
  },
  uberServicePriceText: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '700',
  },
  uberServiceActionRow: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  uberServiceButton: {
    backgroundColor: SKY,
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  uberServiceButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.5,
  },

  brandingContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 12,
    alignSelf: 'flex-end',
  },
  brandingText: {
    color: SKY,
    fontSize: 11,
    fontWeight: '600',
    opacity: 0.8,
  },

  serviceHeader: {
    marginBottom: 12,
  },
  serviceTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  titleContainer: {
    flex: 1,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 6,
    letterSpacing: 0.3,
  },
  badge: {
    alignSelf: 'flex-start',
    backgroundColor: SKY + '20',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: SKY + '40',
  },
  badgePopular: {
    backgroundColor: '#FFD700' + '20',
    borderColor: '#FFD700' + '40',
  },
  badgePremium: {
    backgroundColor: '#E5E4E2' + '20',
    borderColor: '#E5E4E2' + '40',
  },
  badgeText: {
    color: SKY,
    fontSize: 11,
    fontWeight: '700',
  },
  badgePopularText: {
    color: '#FFD700',
    fontSize: 11,
    fontWeight: '700',
  },
  badgePremiumText: {
    color: '#E5E4E2',
    fontSize: 11,
    fontWeight: '700',
  },

  serviceDesc: {
    color: 'rgba(229,231,235,0.85)',
    fontSize: 14,
    marginBottom: 16,
    lineHeight: 20,
  },

  featuresContainer: {
    marginBottom: 16,
  },
  featureRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    marginBottom: 8,
  },
  featureText: {
    color: 'rgba(229,231,235,0.9)',
    fontSize: 13,
    flex: 1,
    lineHeight: 18,
  },
  expandButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 4,
    paddingVertical: 4,
  },
  expandText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '600',
  },

  metaRow: {
    flexDirection: 'row',
    gap: 16,
    marginBottom: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  metaText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
  },

  priceTiersContainer: {
    marginBottom: 16,
    padding: 14,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  priceTiersLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 11,
    marginBottom: 8,
    fontWeight: '600',
  },
  priceTiersRow: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  priceTierItem: {
    alignItems: 'center',
  },
  priceTierLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 10,
    marginBottom: 4,
  },
  priceTierValue: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
  },

  washTypeSection: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  washTypeTitle: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 12,
  },
  washTypeGrid: {
    flexDirection: 'row',
    gap: 8,
  },
  washTypeCard: {
    flex: 1,
    borderRadius: 14,
    padding: 10,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
    backgroundColor: 'rgba(255,255,255,0.08)',
    alignItems: 'center',
    position: 'relative',
    minHeight: 90,
    justifyContent: 'center',
  },
  washTypeCardSelected: {
    borderColor: SKY,
    elevation: 4,
    shadowColor: SKY,
    shadowOpacity: 0.3,
  },
  washTypeLabel: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 6,
  },
  washTypeCheck: {
    position: 'absolute',
    top: 6,
    right: 6,
  },

  continueContainer: {
    paddingTop: 12,
    backgroundColor: 'transparent',
  },
  continueButton: {
    backgroundColor: SKY,
    borderRadius: 12,
    paddingVertical: 18,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  continueButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
});
