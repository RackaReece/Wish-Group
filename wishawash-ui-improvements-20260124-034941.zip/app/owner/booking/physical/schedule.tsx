import React, { useEffect, useMemo, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Dimensions,
  Alert,
  Image,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useLocalSearchParams, router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { supabase } from '../../../../src/lib/supabase';
import { serviceOptions } from '../../../../src/constants/serviceOptions';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import GlassCard from '../../../../src/components/booking/GlassCard';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { colors } from '../../../../src/constants/colors';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../../app/components/NavigationTab';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';

const SKY = colors.SKY;
const BG = colors.BG;
const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SLOT_WIDTH = 160; // Increased to match other boxes

type LocationRow = {
  id: string;
  name: string | null;
  address: string | null;
};

type OpeningHoursRow = {
  id: string;
  location_id: string;
  day_of_week: number; // 0=Mon ... 6=Sun
  is_open: boolean;
  open_time: string | null; // "09:00"
  close_time: string | null; // "17:00"
  slot_minutes: number; // 30
};

type LocationServiceRow = {
  id: string;
  location_id: string;
  service_name: string;
  is_enabled: boolean;
  price: number | null;
  duration_minutes: number | null;
};

function pad2(n: number) {
  return String(n).padStart(2, '0');
}

function parseHHMM(raw: string | null): { h: number; m: number } | null {
  const s = String(raw || '').trim();
  if (!s) return null;
  const m = /^(\d{1,2}):(\d{2})$/.exec(s);
  if (!m) return null;
  const hh = Number(m[1]);
  const mm = Number(m[2]);
  if (!Number.isFinite(hh) || !Number.isFinite(mm)) return null;
  if (hh < 0 || hh > 23 || mm < 0 || mm > 59) return null;
  return { h: hh, m: mm };
}

// Convert JS getDay (0=Sun..6=Sat) -> our DB day (0=Mon..6=Sun)
function jsDayToDbDay(jsDay: number) {
  // Sun(0)->6, Mon(1)->0, Tue(2)->1 ... Sat(6)->5
  return (jsDay + 6) % 7;
}

function buildSlotsFromHours(hours: OpeningHoursRow[], daysAhead = 7) {
  const now = new Date();
  const slots: string[] = [];

  // map day -> hours row
  const byDay = new Map<number, OpeningHoursRow>();
  for (const r of hours) byDay.set(r.day_of_week, r);

  for (let offset = 0; offset < daysAhead; offset++) {
    const d = new Date(now);
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() + offset);

    const dbDay = jsDayToDbDay(d.getDay());
    const row = byDay.get(dbDay);
    if (!row || !row.is_open) continue;

    const open = parseHHMM(row.open_time);
    const close = parseHHMM(row.close_time);
    const step = Number(row.slot_minutes || 30);

    if (!open || !close) continue;
    if (!Number.isFinite(step) || step <= 0) continue;

    const start = new Date(d);
    start.setHours(open.h, open.m, 0, 0);

    const end = new Date(d);
    end.setHours(close.h, close.m, 0, 0);

    // if close <= open, ignore (bad config)
    if (end.getTime() <= start.getTime()) continue;

    // generate slots up to (but not including) end
    for (let t = start.getTime(); t + step * 60_000 <= end.getTime(); t += step * 60_000) {
      const slotDate = new Date(t);

      // don't show past slots for today
      if (slotDate.getTime() < now.getTime() + 2 * 60_000) continue;

      slots.push(slotDate.toISOString());
    }
  }

  // sort ascending
  slots.sort((a, b) => new Date(a).getTime() - new Date(b).getTime());
  return slots;
}

export default function PhysicalSchedule() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{
    locationId?: string;
    serviceId?: string;
    vehicleId?: string;
    washType?: string;
  }>();

  const locationId = params.locationId as string | undefined;
  const serviceId = params.serviceId as string | undefined;
  const vehicleId = params.vehicleId as string | undefined;
  const washType = params.washType as string | undefined;

  const [location, setLocation] = useState<LocationRow & { latitude?: number; longitude?: number } | null>(null);
  const [serviceRow, setServiceRow] = useState<LocationServiceRow | null>(null);

  const [loading, setLoading] = useState(true);
  const [loadingSlots, setLoadingSlots] = useState(true);

  const [selectedSlot, setSelectedSlot] = useState<string | null>(null);
  const [timeSlots, setTimeSlots] = useState<string[]>([]);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const { coords } = useLiveLocation();
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const [isMinimized, setIsMinimized] = useState(false);

  // fallback (if your booking flow still passes a local serviceId from constants)
  const fallbackService = useMemo(
    () => serviceOptions.find((opt) => opt.id === serviceId),
    [serviceId]
  );

  // Check if a string is a valid UUID format
  const isValidUUID = (str: string | undefined): boolean => {
    if (!str) return false;
    const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    return uuidRegex.test(str);
  };

  useEffect(() => {
    if (!locationId) return;

    const loadAll = async () => {
      try {
        setLoading(true);

        // Only query location_services if serviceId is a valid UUID
        const shouldQueryService = serviceId && isValidUUID(serviceId);

        const [{ data: loc, error: locErr }, svcRes] = await Promise.all([
          supabase
            .from('car_wash_locations')
            .select('id,name,address,latitude,longitude')
            .eq('id', locationId)
            .maybeSingle(),
          shouldQueryService
            ? supabase
                .from('location_services')
                .select('id,location_id,service_name,is_enabled,price,duration_minutes')
                .eq('id', serviceId)
                .maybeSingle()
            : Promise.resolve({ data: null, error: null } as any),
        ]);

        if (locErr) throw locErr;

        const locationData = (loc as LocationRow & { latitude?: number; longitude?: number }) ?? null;
        setLocation(locationData);
        
        // Update map region if location has coordinates
        if (locationData?.latitude && locationData?.longitude) {
          setRegion({
            latitude: Number(locationData.latitude),
            longitude: Number(locationData.longitude),
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          });
        }

        // Only accept service if it belongs to this location (prevents mismatched IDs)
        if (svcRes?.error) {
          // don’t hard fail, we can still show fallback service from constants
          console.warn('[PhysicalSchedule] service load error:', svcRes.error.message);
          setServiceRow(null);
        } else {
          const svc = (svcRes?.data as LocationServiceRow | null) ?? null;
          if (svc && svc.location_id === locationId) setServiceRow(svc);
          else setServiceRow(null);
        }
      } catch (e: any) {
        console.error('[PhysicalSchedule] loadAll error:', e);
        Alert.alert('Error', e?.message || 'Failed to load booking info');
        setLocation(null);
        setServiceRow(null);
      } finally {
        setLoading(false);
      }
    };

    loadAll();
  }, [locationId, serviceId]);

  const loadSlots = async () => {
    if (!locationId) return;

    try {
      setLoadingSlots(true);

      const { data, error } = await supabase
        .from('location_opening_hours')
        .select('id,location_id,day_of_week,is_open,open_time,close_time,slot_minutes')
        .eq('location_id', locationId);

      if (error) throw error;

      const rows = (data || []) as OpeningHoursRow[];
      const slots = buildSlotsFromHours(rows, 7);

      setTimeSlots(slots);

      // if previously selected slot is no longer valid
      if (selectedSlot && !slots.includes(selectedSlot)) setSelectedSlot(null);
    } catch (e: any) {
      console.error('[PhysicalSchedule] loadSlots error:', e);

      // If table doesn't exist yet / not migrated in this env, show a helpful empty state
      setTimeSlots([]);
    } finally {
      setLoadingSlots(false);
    }
  };

  useEffect(() => {
    loadSlots();
    getCurrentLocation();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locationId]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    if (coords) {
      setUserLocation(coords);
    }
  }, [coords]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };
      setUserLocation(coords);
    } catch {}
  };

  const handleExitBooking = async () => {
    await hapticFeedback('light');
    router.replace('/owner/owner-dashboard' as any);
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (coords) {
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    } else if (userLocation) {
      setRegion({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    }
  };

  const toggleMinimize = async () => {
    await hapticFeedback('light');
    setIsMinimized(!isMinimized);
  };

  const handleContinue = async () => {
    if (!serviceId || !selectedSlot || !locationId || !vehicleId) return;
    await hapticFeedback('medium');

    router.push({
      pathname: '/owner/booking/physical/confirm',
      params: {
        locationId,
        serviceId,
        vehicleId,
        washType: washType || '',
        scheduledAt: selectedSlot,
      },
    });
  };

  if (!locationId || !serviceId || !vehicleId) {
    return (
      <SafeAreaView style={[styles.container, styles.center]} edges={[]}>
        <Text style={{ color: '#fff' }}>Missing booking information.</Text>
      </SafeAreaView>
    );
  }

  const getServiceIcon = () => {
    const name = (serviceRow?.service_name || fallbackService?.name || '').toLowerCase();
    if (name.includes('interior')) return 'car-sport-outline';
    if (name.includes('detail')) return 'sparkles-outline';
    if (name.includes('premium')) return 'diamond-outline';
    if (name.includes('wash')) return 'water-outline';
    if (name.includes('bronze') || name.includes('silver') || name.includes('gold') || name.includes('platinum'))
      return 'medal-outline';
    return 'pricetag-outline';
  };

  const serviceTitle = serviceRow?.service_name || fallbackService?.name || 'Service';
  const servicePrice =
    serviceRow?.price !== null && serviceRow?.price !== undefined
      ? Number(serviceRow.price).toFixed(2)
      : fallbackService?.price
        ? String(fallbackService.price)
        : '—';

  const serviceDuration =
    serviceRow?.duration_minutes !== null && serviceRow?.duration_minutes !== undefined
      ? `${serviceRow.duration_minutes} min`
      : fallbackService?.dur || '';

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
        >
          {/* User location marker */}
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image 
                  source={require('../../../../assets/washing.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {/* Hub location marker */}
          {location?.latitude && location?.longitude && (
            <Marker coordinate={{ latitude: Number(location.latitude), longitude: Number(location.longitude) }}>
              <View style={styles.hubMarkerContainer}>
                <Image 
                  source={require('../../../../assets/washing.png')} 
                  style={styles.hubMarkerImage}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Header floating over the map */}
      <AppHeader 
        title="Pick time slot" 
        subtitle={location?.name || 'Select your preferred time'}
        showBack={true}
        onBack={() => router.back()}
        rightAction={
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            <TouchableOpacity 
              onPress={handleRecenter} 
              style={styles.recenterButton}
              activeOpacity={0.7}
            >
              <Ionicons name="locate" size={22} color={SKY} />
            </TouchableOpacity>
            <TouchableOpacity 
              onPress={handleExitBooking} 
              style={styles.exitButton}
              activeOpacity={0.7}
            >
              <Ionicons name="close" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        }
      />

      {/* Time slots - fixed at half screen with minimize */}
      <View
        style={[
          styles.slotContainer,
          {
            height: isMinimized ? height * 0.25 : height * 0.5,
            paddingBottom: Math.max(insets.bottom, 14) + TAB_BAR_TOTAL_HEIGHT + 8,
          },
        ]}
      >
        <Animated.View style={{ opacity: fadeAnim, flex: 1 }}>
          {/* Minimize button */}
          <TouchableOpacity
          onPress={toggleMinimize}
          style={styles.minimizeButton}
          activeOpacity={0.7}
        >
          <View style={styles.minimizeHandle} />
          <Ionicons 
            name={isMinimized ? "chevron-up" : "chevron-down"} 
            size={20} 
            color={SKY} 
            style={styles.minimizeIcon}
          />
        </TouchableOpacity>
        
        <View style={styles.cardContent}>
          {isMinimized ? (
            <View style={styles.minimizedContent}>
              <Text style={styles.minimizedTitle}>
                {selectedSlot ? `Selected: ${selectedSlot}` : 'Select a time slot'}
              </Text>
            </View>
          ) : (
            <>
              {loading ? (
                <GlassCard style={styles.loadingCard} accountType="customer">
                  <ActivityIndicator size="large" color={SKY} />
                  <Text style={styles.loadingText}>Loading time slots...</Text>
                </GlassCard>
              ) : loadingSlots ? (
                <GlassCard style={styles.loadingCard} accountType="customer">
                  <ActivityIndicator size="large" color={SKY} />
                  <Text style={styles.loadingText}>Loading available slots...</Text>
                </GlassCard>
              ) : timeSlots.length === 0 ? (
                <GlassCard style={styles.emptySlotsCard} accountType="customer">
                  <Ionicons name="time-outline" size={22} color={SKY} style={{ opacity: 0.9 }} />
                  <View style={{ flex: 1 }}>
                    <Text style={styles.emptyTitle}>No slots available</Text>
                    <Text style={styles.emptySub}>
                      This location hasn't set opening hours yet (or they're closed for the next 7 days).
                    </Text>
                  </View>
                </GlassCard>
              ) : (
                <>
                  <View style={styles.slotHeader}>
                    <Text style={styles.slotHeaderTitle}>Choose a time slot</Text>
                    <TouchableOpacity
                      onPress={async () => {
                        await hapticFeedback('light');
                        loadSlots();
                      }}
                      activeOpacity={0.85}
                      style={styles.refreshBtn}
                    >
                      {loadingSlots ? (
                        <ActivityIndicator size="small" color={SKY} />
                      ) : (
                        <Ionicons name="refresh" size={18} color={SKY} />
                      )}
                    </TouchableOpacity>
                  </View>
                  <ScrollView 
                    horizontal 
                    showsHorizontalScrollIndicator={false} 
                    contentContainerStyle={styles.slotRow}
                  >
                    {timeSlots.map((slot) => {
                      const date = new Date(slot);
                      const isSelected = selectedSlot === slot;

                      return (
                        <GlassCard
                          key={slot}
                          onPress={() => {
                            hapticFeedback('light');
                            setSelectedSlot(slot);
                          }}
                          style={[styles.slotCard, isSelected && styles.slotSelected]}
                          accountType="customer"
                        >
                          <Text style={styles.slotDay}>
                            {date.toLocaleDateString('en-GB', {
                              weekday: 'short',
                              day: 'numeric',
                              month: 'short',
                            })}
                          </Text>
                          <Text style={styles.slotTime}>
                            {date.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' })}
                          </Text>

                          {isSelected && (
                            <View style={styles.tick}>
                              <Ionicons name="checkmark" size={12} color={BG} />
                            </View>
                          )}
                        </GlassCard>
                      );
                    })}
                  </ScrollView>
                </>
              )}
            </>
          )}
          </View>
        </Animated.View>
      </View>

      {/* Floating continue button */}
      {selectedSlot && !isMinimized && (
        <View style={[styles.footer, { paddingBottom: insets.bottom + TAB_BAR_TOTAL_HEIGHT + 8 }]}>
          <TouchableOpacity
            onPress={handleContinue}
            activeOpacity={0.85}
            style={styles.continueButton}
          >
            <Text style={styles.continueText}>Continue</Text>
            <Ionicons name="arrow-forward" size={18} color={BG} />
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  hubMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  hubMarkerImage: {
    width: 48,
    height: 48,
  },
  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  slotContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 8,
    backgroundColor: 'transparent',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
  },
  minimizeButton: {
    alignItems: 'center',
    paddingVertical: 8,
    marginBottom: 4,
  },
  minimizeHandle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(135,206,235,0.4)',
    marginBottom: 4,
  },
  minimizeIcon: {
    opacity: 0.7,
  },
  cardContent: {
    flex: 1,
  },
  minimizedContent: {
    padding: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  minimizedTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    textAlign: 'center',
  },
  loadingCard: {
    padding: 20,
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  slotHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  slotHeaderTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  refreshBtn: {
    width: 38,
    height: 38,
    borderRadius: 19,
    backgroundColor: 'rgba(135,206,235,0.10)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  slotRow: { 
    paddingVertical: 4, 
    gap: 12,
    paddingRight: 16,
  },
  slotCard: {
    width: SLOT_WIDTH,
    minHeight: 80, // Match other boxes height
    paddingVertical: 16,
    paddingHorizontal: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  slotSelected: {
    borderWidth: 2,
    borderColor: '#60A5FA',
    backgroundColor: 'rgba(96,165,250,0.15)',
  },
  slotDay: { 
    color: 'rgba(255,255,255,0.7)', 
    fontSize: 11, 
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  slotTime: { 
    color: '#FFFFFF', 
    fontSize: 18, 
    fontWeight: '800', 
    marginTop: 4,
  },
  tick: {
    position: 'absolute',
    top: 8,
    right: 8,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: '#10B981',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
    shadowColor: '#10B981',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.5,
    shadowRadius: 4,
    elevation: 4,
  },
  emptySlotsCard: {
    padding: 14,
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  emptyTitle: { color: '#F9FAFB', fontSize: 14, fontWeight: '900' },
  emptySub: { color: 'rgba(249,250,251,0.75)', fontSize: 12, marginTop: 4, lineHeight: 18 },
  footer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: isSmallScreen ? 14 : 20,
    backgroundColor: 'transparent',
    justifyContent: 'flex-end',
  },
  continueButton: {
    backgroundColor: SKY,
    borderRadius: 18,
    paddingVertical: 14,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  continueText: { color: BG, fontSize: 16, fontWeight: '900' },
});
