import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Dimensions,
  ActivityIndicator,
  Image,
} from 'react-native';
import MapView, { Region, Marker } from 'react-native-maps';
import { LinearGradient } from 'expo-linear-gradient';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { customerTheme } from '../../../src/constants/customerTheme';
import { serviceOptions } from '../../../src/constants/serviceOptions';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import ValeterStatsService from '../../../src/services/Valeterstatsservice';
import {
  WWBottomSheet,
  WWPrimaryButton,
  ValeterCard,
  WWMapHeaderControls,
  WWSectionHeader,
} from '../../../src/components/ui';
import type { BottomSheetState } from '../../../src/components/ui';

const { width, height } = Dimensions.get('window');
const SKY = '#5B8FA8';

// Dark map style
const darkMapStyle = [
  { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
  { featureType: 'water', stylers: [{ color: '#17263c' }] },
];

interface Valeter {
  id: string;
  name: string;
  rating: number;
  totalJobs: number;
  distance: number;
  isOnline: boolean;
  profilePicture?: string;
  lastLat?: number;
  lastLng?: number;
  isVerified: boolean;
  eta: number;
}

export default function ValeterSelection() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const serviceId = params.serviceId as string;
  const vehicleId = params.vehicleId as string;
  const latitude = parseFloat(params.locationLat as string) || 51.5074;
  const longitude = parseFloat(params.locationLng as string) || -0.1278;

  const [valeters, setValeters] = useState<Valeter[]>([]);
  const [selectedValeter, setSelectedValeter] = useState<Valeter | null>(null);
  const [loading, setLoading] = useState(true);
  const [sheetState, setSheetState] = useState<BottomSheetState>('half');
  const [region, setRegion] = useState<Region>({
    latitude,
    longitude,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  });

  const customerLocation = { latitude, longitude };

  useEffect(() => {
    loadNearbyValeters();
  }, []);

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 3959; // Earth's radius in miles
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const loadNearbyValeters = async () => {
    try {
      setLoading(true);
      
      // Load online valeters
      const { data: presenceData, error: presenceError } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng')
        .eq('is_online', true);

      if (presenceError) throw presenceError;

      if (!presenceData || presenceData.length === 0) {
        setValeters([]);
        setLoading(false);
        return;
      }

      // Load valeter profiles
      const userIds = presenceData.map(p => p.user_id);
      const { data: profilesData, error: profilesError } = await supabase
        .from('valeter_profiles')
        .select('user_id, full_name, profile_photo_url, verification_status')
        .in('user_id', userIds);

      if (profilesError) throw profilesError;

      // Fetch stats
      const statsPromises = userIds.map(userId => 
        ValeterStatsService.getValeterStats(userId).catch(() => null)
      );
      const statsResults = await Promise.all(statsPromises);
      const statsMap = new Map(
        userIds.map((userId, index) => [userId, statsResults[index]])
      );

      // Combine data
      const valetersList: Valeter[] = presenceData
        .map((presence) => {
          const profile = profilesData?.find(p => p.user_id === presence.user_id);
          const distance = presence.last_lat && presence.last_lng
            ? calculateDistance(latitude, longitude, presence.last_lat, presence.last_lng)
            : 999;
          
          const stats = statsMap.get(presence.user_id);
          const displayName = profile?.full_name || 'Valeter';
          const isVerified = profile?.verification_status === 'verified';
          const estimatedETA = Math.round(distance * 2);

          return {
            id: presence.user_id,
            name: displayName,
            rating: stats?.averageRating || 0,
            totalJobs: stats?.totalJobs || 0,
            distance: Math.round(distance * 10) / 10,
            isOnline: presence.is_online,
            profilePicture: profile?.profile_photo_url,
            lastLat: presence.last_lat,
            lastLng: presence.last_lng,
            isVerified: isVerified,
            eta: estimatedETA,
          };
        })
        .filter(v => v.distance <= 10)
        .sort((a, b) => a.distance - b.distance);

      setValeters(valetersList);
      
      // Auto-fit map to show all valeters and customer
      if (valetersList.length > 0) {
        const allLats = [latitude, ...valetersList.map(v => v.lastLat).filter(Boolean) as number[]];
        const allLngs = [longitude, ...valetersList.map(v => v.lastLng).filter(Boolean) as number[]];
        
        const minLat = Math.min(...allLats);
        const maxLat = Math.max(...allLats);
        const minLng = Math.min(...allLngs);
        const maxLng = Math.max(...allLngs);
        
        const latDelta = (maxLat - minLat) * 1.5;
        const lngDelta = (maxLng - minLng) * 1.5;
        
        setRegion({
          latitude: (minLat + maxLat) / 2,
          longitude: (minLng + maxLng) / 2,
          latitudeDelta: Math.max(latDelta, 0.01),
          longitudeDelta: Math.max(lngDelta, 0.01),
        });
      }
    } catch (error) {
      console.error('Error loading valeters:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleValeterSelect = async (valeter: Valeter) => {
    await hapticFeedback('light');
    setSelectedValeter(valeter);
    
    // Zoom map to fit both customer and selected valeter
    if (valeter.lastLat && valeter.lastLng) {
      const minLat = Math.min(latitude, valeter.lastLat);
      const maxLat = Math.max(latitude, valeter.lastLat);
      const minLng = Math.min(longitude, valeter.lastLng);
      const maxLng = Math.max(longitude, valeter.lastLng);
      
      const latDelta = (maxLat - minLat) * 1.5;
      const lngDelta = (maxLng - minLng) * 1.5;
      
      setRegion({
        latitude: (minLat + maxLat) / 2,
        longitude: (minLng + maxLng) / 2,
        latitudeDelta: Math.max(latDelta, 0.01),
        longitudeDelta: Math.max(lngDelta, 0.01),
      });
    }
  };

  const handleContinue = async () => {
    if (!selectedValeter || !user?.id) return;
    await hapticFeedback('medium');
    
    const selectedServiceOption = serviceOptions.find((option) => option.id === serviceId);
    if (!selectedServiceOption) return;
    
    try {
      const scheduledAt = new Date().toISOString();
      const basePrice = selectedServiceOption.price || 25;
      
      const { data, error } = await supabase
        .from('bookings')
        .insert({
          user_id: user.id,
          valeter_id: selectedValeter.id,
          service_type: serviceId,
          service_name: selectedServiceOption.name || serviceId,
          status: 'pending_valeter_acceptance',
          price: basePrice,
          location_address: 'Selected location',
          location_lat: latitude,
          location_lng: longitude,
          request_sent_at: new Date().toISOString(),
          scheduled_at: scheduledAt,
        })
        .select()
        .single();

      if (error) throw error;

      router.push({
        pathname: '/owner/booking/waiting-acceptance',
        params: { bookingId: data.id },
      });
    } catch (error: any) {
      console.error('Error creating booking:', error);
      // Handle error
    }
  };

  const handleBack = () => {
    router.back();
  };

  const handleLocate = () => {
    setRegion({
      latitude,
      longitude,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    });
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Full Screen Map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          customMapStyle={darkMapStyle}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
        >
          {/* Customer Marker */}
          <Marker coordinate={customerLocation}>
            <View style={styles.customerMarker}>
              <View style={styles.markerPulse} />
              <View style={styles.markerInner}>
                <Ionicons name="person" size={16} color={SKY} />
              </View>
            </View>
          </Marker>

          {/* Valeter Markers */}
          {valeters.map((valeter) => {
            if (!valeter.lastLat || !valeter.lastLng) return null;
            const isSelected = selectedValeter?.id === valeter.id;
            
            return (
              <Marker
                key={valeter.id}
                coordinate={{ latitude: valeter.lastLat, longitude: valeter.lastLng }}
                onPress={() => handleValeterSelect(valeter)}
              >
                <View style={[styles.valeterMarker, isSelected && styles.valeterMarkerSelected]}>
                  {isSelected && <View style={styles.selectedGlow} />}
                  <View style={styles.valeterMarkerInner}>
                    <Ionicons name="car" size={20} color={isSelected ? SKY : '#94A3B8'} />
                  </View>
                </View>
              </Marker>
            );
          })}
        </MapView>
      </View>

      {/* Map Header Controls */}
      <WWMapHeaderControls
        onBack={handleBack}
        onLocate={handleLocate}
        showClose={false}
      />

      {/* Bottom Sheet */}
      <WWBottomSheet
        state={sheetState}
        onStateChange={setSheetState}
        collapsedHeight={height * 0.15}
        halfHeight={height * 0.55}
        fullHeight={height * 0.85}
        previewContent={
          selectedValeter ? (
            <View style={styles.previewContent}>
              <Text style={styles.previewText} numberOfLines={1}>
                {selectedValeter.name} • {selectedValeter.eta} min ETA
              </Text>
            </View>
          ) : (
            <View style={styles.previewContent}>
              <Text style={styles.previewText}>
                {valeters.length} {valeters.length === 1 ? 'valeter' : 'valeters'} available
              </Text>
            </View>
          )
        }
      >
        <WWSectionHeader
          title="Choose Valeter"
          subtitle={`${valeters.length} ${valeters.length === 1 ? 'pro' : 'pros'} nearby`}
        />

        {loading ? (
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={SKY} />
            <Text style={styles.loadingText}>Finding nearby valeters...</Text>
          </View>
        ) : valeters.length === 0 ? (
          <View style={styles.emptyContainer}>
            <Ionicons name="person-outline" size={48} color="#94A3B8" />
            <Text style={styles.emptyText}>No valeters available</Text>
            <Text style={styles.emptySubtext}>Try again later or adjust your location</Text>
          </View>
        ) : (
          <View style={styles.valetersList}>
            {valeters.map((valeter) => (
              <ValeterCard
                key={valeter.id}
                name={valeter.name}
                rating={valeter.rating}
                reviewCount={Math.floor(valeter.totalJobs * 0.3)} // Estimate reviews
                eta={`${valeter.eta} min`}
                distance={`${valeter.distance.toFixed(1)} mi`}
                jobsCompleted={valeter.totalJobs}
                profileImage={valeter.profilePicture}
                isCertified={valeter.isVerified}
                selected={selectedValeter?.id === valeter.id}
                onPress={() => handleValeterSelect(valeter)}
              />
            ))}
          </View>
        )}
      </WWBottomSheet>

      {/* Primary CTA */}
      {selectedValeter && (
        <View style={styles.footer}>
          <WWPrimaryButton
            title="Confirm Valeter"
            onPress={handleContinue}
          />
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  customerMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  markerPulse: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: `${SKY}30`,
  },
  markerInner: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#0A1929',
    borderWidth: 2,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  valeterMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  valeterMarkerSelected: {
    transform: [{ scale: 1.2 }],
  },
  selectedGlow: {
    position: 'absolute',
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: `${SKY}20`,
  },
  valeterMarkerInner: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#0A1929',
    borderWidth: 2,
    borderColor: '#94A3B8',
    alignItems: 'center',
    justifyContent: 'center',
  },
  previewContent: {
    paddingVertical: 4,
  },
  previewText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
  },
  loadingContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 40,
  },
  loadingText: {
    color: '#94A3B8',
    fontSize: 14,
    marginTop: 12,
  },
  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 60,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtext: {
    color: '#94A3B8',
    fontSize: 14,
  },
  valetersList: {
    paddingTop: 8,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 20,
    paddingBottom: 20,
    paddingTop: 12,
    backgroundColor: 'rgba(15, 23, 42, 0.95)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
});
