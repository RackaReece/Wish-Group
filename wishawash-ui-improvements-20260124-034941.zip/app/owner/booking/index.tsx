import React, { useRef, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Dimensions,
  Animated,
  Alert,
  ScrollView,
  Image,
  TouchableOpacity,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import AppHeader from '../../../src/components/shared/AppHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;

type DbBookingStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
const ACTIVE_STATUSES: DbBookingStatus[] = ['scheduled', 'in_progress'];

const washTypes = [
  {
    id: 'valeter',
    title: 'On-Demand Valeter',
    subtitle: 'Valeter comes to you',
    description: 'A vetted professional valeter will come to your location with live tracking and real-time updates.',
    eta: '10–25 mins',
    trustLine: 'Vetted professionals',
    icon: 'car-sport',
    gradient: [SKY, '#60A5FA', '#3B82F6'],
    borderColor: 'rgba(135,206,235,0.4)',
    iconColor: SKY,
    route: '/owner/booking/create',
    features: ['Live GPS tracking', 'Pay after acceptance', 'Home or office', 'Real-time updates'],
    badge: 'FASTEST',
  },
  {
    id: 'physical',
    title: 'Wash Hub',
    subtitle: 'Book a time slot',
    description: 'Visit a verified car wash location near you. Book your preferred date and time slot in advance.',
    nextSlot: 'Available today',
    trustLine: 'Verified locations',
    icon: 'business',
    gradient: ['#60A5FA', '#3B82F6', '#2563EB'],
    borderColor: 'rgba(59,130,246,0.4)',
    iconColor: '#60A5FA',
    route: '/owner/booking/physical/vehicle',
    features: ['Certified locations', 'Flexible scheduling', 'Nearby errands', 'Time slots'],
    badge: 'FLEXIBLE',
  },
] as const;

const detailingTypes = [
  {
    id: 'valeter',
    title: 'On-Demand Detailer',
    subtitle: 'Premium detailer to you',
    description: 'A premium detailer will come to your location with professional-grade equipment and live tracking.',
    eta: '15–30 mins',
    trustLine: 'Premium professionals',
    icon: 'diamond',
    gradient: [PREMIUM_PURPLE, '#7C3AED', '#6D28D9'],
    borderColor: 'rgba(139,92,246,0.4)',
    iconColor: PREMIUM_PURPLE,
    route: '/owner/booking/detailing/create',
    features: ['Live GPS tracking', 'Premium equipment', 'Home or office', 'Real-time updates'],
    badge: 'PREMIUM',
  },
  {
    id: 'physical',
    title: 'Detail Hub',
    subtitle: 'Book a time slot',
    description: 'Visit a premium detailing facility near you. Book your preferred date and time slot in advance.',
    nextSlot: 'Available today',
    trustLine: 'Premium facilities',
    icon: 'business',
    gradient: [PREMIUM_PURPLE, '#7C3AED', '#6D28D9'],
    borderColor: 'rgba(139,92,246,0.4)',
    iconColor: PREMIUM_PURPLE,
    route: '/owner/booking/detailing/physical',
    features: ['Premium facilities', 'Flexible scheduling', 'Professional setup', 'Time slots'],
    badge: 'PREMIUM',
  },
] as const;

type ActiveBooking = { id: string; status: DbBookingStatus };

export default function WashTypeSelection() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams();

  const [serviceType, setServiceType] = useState<'wash' | 'detailing'>(
    (params.serviceType as 'wash' | 'detailing') || 'wash'
  );

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;
  const toggleAnim = useRef(new Animated.Value(serviceType === 'wash' ? 0 : 1)).current;
  const cardScaleAnim = useRef(new Animated.Value(1)).current;

  const [activeBooking, setActiveBooking] = useState<ActiveBooking | null>(null);
  const [checkingActive, setCheckingActive] = useState(false);
  const [valeterCount, setValeterCount] = useState<number>(0);
  const [nextSlotText, setNextSlotText] = useState<string>('Available today');

  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);

  const calculateNextSlot = () => {
    const now = new Date();
    const currentHour = now.getHours();
    if (currentHour < 17) {
      setNextSlotText('Available today');
    } else {
      setNextSlotText('Available tomorrow');
    }
  };

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, friction: 8, tension: 60, useNativeDriver: true }),
    ]).start();
    calculateNextSlot();
  }, []);

  useEffect(() => {
    Animated.spring(toggleAnim, {
      toValue: serviceType === 'wash' ? 0 : 1,
      useNativeDriver: false,
      tension: 50,
      friction: 7,
    }).start();
  }, [serviceType]);

  useEffect(() => {
    if (params.serviceType === 'detailing' || params.serviceType === 'wash') {
      setServiceType(params.serviceType as 'wash' | 'detailing');
    }
  }, [params.serviceType]);

  useEffect(() => {
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') return;

        const location = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Balanced,
        });

        const coords = {
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        };

        setUserLocation(coords);
        setRegion({
          latitude: coords.latitude,
          longitude: coords.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });

        await loadNearbyValetersCount(coords.latitude, coords.longitude);
      } catch (error) {
        console.warn('Error getting location:', error);
      }
    })();
  }, []);

  const loadNearbyValetersCount = async (latitude: number, longitude: number) => {
    try {
      const { data: presenceData, error } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng')
        .eq('is_online', true);

      if (error) {
        console.warn('Error loading valeters:', error);
        return;
      }

      if (!presenceData || presenceData.length === 0) {
        setValeterCount(0);
        return;
      }

      const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
        const R = 3959;
        const dLat = ((lat2 - lat1) * Math.PI) / 180;
        const dLon = ((lon2 - lon1) * Math.PI) / 180;
        const a =
          Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos((lat1 * Math.PI) / 180) *
            Math.cos((lat2 * Math.PI) / 180) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
      };

      const nearbyValeters = presenceData.filter((presence) => {
        if (!presence.last_lat || !presence.last_lng) return false;
        const distance = calculateDistance(latitude, longitude, presence.last_lat, presence.last_lng);
        return distance <= 10;
      });

      setValeterCount(nearbyValeters.length);
    } catch (error) {
      console.warn('Error counting valeters:', error);
    }
  };

  const loadActiveBooking = async () => {
    if (!user?.id) return;
    try {
      setCheckingActive(true);
      const { data, error } = await supabase
        .from('bookings')
        .select('id,status')
        .eq('user_id', user.id)
        .in('status', ACTIVE_STATUSES as any)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        console.warn('[WashTypeSelection] loadActiveBooking error:', error);
        setActiveBooking(null);
        return;
      }

      if (!data) {
        setActiveBooking(null);
        return;
      }

      setActiveBooking({ id: data.id, status: data.status as DbBookingStatus });
    } catch (e) {
      console.warn('[WashTypeSelection] loadActiveBooking exception:', e);
      setActiveBooking(null);
    } finally {
      setCheckingActive(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;
    loadActiveBooking();

    const channel = supabase
      .channel(`wash-type-active-booking-${user.id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        () => loadActiveBooking()
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        (payload) => {
          const updated = payload.new as any;
          const status = updated?.status as DbBookingStatus | undefined;
          if (!updated?.id || !status) {
            loadActiveBooking();
            return;
          }
          if (ACTIVE_STATUSES.includes(status)) {
            setActiveBooking({ id: updated.id, status });
          } else if (activeBooking?.id === updated.id) {
            setActiveBooking(null);
          } else {
            loadActiveBooking();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, activeBooking?.id]);

  const goToActiveBooking = () => {
    if (!activeBooking?.id) return;
    router.push({
      pathname: '/owner/booking/tracking',
      params: { bookingId: activeBooking.id },
    } as any);
  };

  const handleSelect = async (option: (typeof washTypes)[number] | (typeof detailingTypes)[number]) => {
    if (checkingActive) return;

    if (activeBooking?.id) {
      Alert.alert(
        'Active booking in progress',
        'You already have an active booking. Want to go back to tracking it?',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'View booking', onPress: goToActiveBooking },
        ]
      );
      return;
    }

    await hapticFeedback('medium');
    
    // Animate card press
    Animated.sequence([
      Animated.timing(cardScaleAnim, { toValue: 0.95, duration: 100, useNativeDriver: true }),
      Animated.timing(cardScaleAnim, { toValue: 1, duration: 100, useNativeDriver: true }),
    ]).start();

    router.push(option.route as any);
  };

  const currentTypes = serviceType === 'wash' ? washTypes : detailingTypes;
  const primaryColor = serviceType === 'detailing' ? PREMIUM_PURPLE : SKY;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={[
            { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
            { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
            { elementType: 'water', stylers: [{ color: '#17263c' }] },
          ]}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image 
                  source={require('../../../assets/washing.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Header */}
      <AppHeader 
        title={serviceType === 'wash' ? "Book Your Wash" : "Premium Detailing"} 
        subtitle={serviceType === 'wash' ? "Choose how you'd like to book" : "Choose your detailing service"} 
        showBack={false}
        primaryColor={primaryColor}
        rightAction={
          <TouchableOpacity
            style={styles.toggleSwitch}
            onPress={async () => {
              await hapticFeedback('light');
              setServiceType(serviceType === 'wash' ? 'detailing' : 'wash');
            }}
            activeOpacity={0.8}
          >
            <View style={[styles.toggleTrack, { backgroundColor: primaryColor + '40' }]}>
              <Animated.View
                style={[
                  styles.toggleThumb,
                  {
                    transform: [
                      {
                        translateX: toggleAnim.interpolate({
                          inputRange: [0, 1],
                          outputRange: [0, 32],
                        }),
                      },
                    ],
                    backgroundColor: primaryColor,
                  },
                ]}
              >
                <Ionicons 
                  name={serviceType === 'wash' ? "water" : "diamond"} 
                  size={18} 
                  color="#FFFFFF" 
                />
              </Animated.View>
            </View>
          </TouchableOpacity>
        }
      />

      {/* Valeter count badge */}
      <Animated.View
        style={[
          styles.valeterCountBadge,
          {
            opacity: fadeAnim,
            top: insets.top + 92,
          },
        ]}
      >
        <GlassCard style={styles.valeterBadgeCard} intensity={30} accountType="customer">
          <View style={styles.valeterCountContent}>
            <Ionicons name="people" size={18} color={primaryColor} />
            <Text style={[styles.valeterCountText, { color: primaryColor }]}>{valeterCount}</Text>
          </View>
        </GlassCard>
      </Animated.View>

      {/* Modern floating cards */}
      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            paddingBottom: Math.max(insets.bottom, 14) + 14 + TAB_BAR_TOTAL_HEIGHT + 12,
          },
        ]}
      >
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.cardsScrollContent}
          snapToInterval={width - 32}
          decelerationRate="fast"
          pagingEnabled
          snapToAlignment="start"
        >
          {currentTypes.map((option, index) => {
            const isValeter = option.id === 'valeter';
            
            return (
              <Animated.View 
                key={option.id} 
                style={[
                  styles.cardWrapper, 
                  { width: width - 32 },
                  { transform: [{ scale: cardScaleAnim }] }
                ]}
              >
                <TouchableOpacity
                  onPress={() => handleSelect(option)}
                  activeOpacity={0.95}
                  disabled={checkingActive}
                >
                  <GlassCard
                    style={styles.modernCard}
                    borderColor={option.borderColor}
                    accountType="customer"
                    intensity={25}
                  >
                    {/* Gradient background overlay */}
                    <LinearGradient
                      colors={[...option.gradient.map(c => c + '15'), 'transparent']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 1 }}
                      style={StyleSheet.absoluteFill}
                    />

                    {/* Badge */}
                    <View style={[styles.badgeContainer, { backgroundColor: primaryColor + '20' }]}>
                      <Ionicons name="sparkles" size={12} color={primaryColor} />
                      <Text style={[styles.badgeText, { color: primaryColor }]}>{option.badge}</Text>
                    </View>

                    {/* Icon and Title Section */}
                    <View style={styles.cardHeader}>
                      <View style={[styles.iconContainer, { backgroundColor: primaryColor + '20', borderColor: primaryColor + '40' }]}>
                        <LinearGradient
                          colors={option.gradient}
                          start={{ x: 0, y: 0 }}
                          end={{ x: 1, y: 1 }}
                          style={styles.iconGradient}
                        >
                          <Ionicons name={option.icon as any} size={32} color="#FFFFFF" />
                        </LinearGradient>
                      </View>
                      <View style={styles.titleSection}>
                        <Text style={styles.cardTitle}>{option.title}</Text>
                        <Text style={styles.cardSubtitle}>{option.subtitle}</Text>
                      </View>
                    </View>

                    {/* Description */}
                    <Text style={styles.cardDescription}>{option.description}</Text>

                    {/* Status Row */}
                    <View style={styles.statusRow}>
                      {isValeter && option.eta && (
                        <View style={[styles.statusBadge, { backgroundColor: primaryColor + '20' }]}>
                          <Ionicons name="time" size={14} color={primaryColor} />
                          <Text style={[styles.statusText, { color: primaryColor }]}>{option.eta}</Text>
                        </View>
                      )}
                      {!isValeter && (
                        <View style={[styles.statusBadge, { backgroundColor: primaryColor + '20' }]}>
                          <Ionicons name="calendar" size={14} color={primaryColor} />
                          <Text style={[styles.statusText, { color: primaryColor }]}>{nextSlotText}</Text>
                        </View>
                      )}
                      <View style={[styles.trustBadge, { backgroundColor: '#10B98120' }]}>
                        <Ionicons name="shield-checkmark" size={12} color="#10B981" />
                        <Text style={[styles.trustText, { color: '#10B981' }]}>{option.trustLine}</Text>
                      </View>
                    </View>

                    {/* Features */}
                    <View style={styles.featuresContainer}>
                      {option.features.map((feature, idx) => (
                        <View key={idx} style={styles.featureItem}>
                          <View style={[styles.featureDot, { backgroundColor: primaryColor }]} />
                          <Text style={styles.featureText}>{feature}</Text>
                        </View>
                      ))}
                    </View>

                    {/* CTA Button */}
                    <TouchableOpacity
                      onPress={() => handleSelect(option)}
                      activeOpacity={0.9}
                      style={styles.ctaButton}
                      disabled={checkingActive}
                    >
                      <LinearGradient
                        colors={option.gradient}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 0 }}
                        style={styles.ctaGradient}
                      >
                        <Text style={styles.ctaText}>Choose {option.title}</Text>
                        <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                      </LinearGradient>
                    </TouchableOpacity>
                  </GlassCard>
                </TouchableOpacity>
              </Animated.View>
            );
          })}
        </ScrollView>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  valeterCountBadge: {
    position: 'absolute',
    right: 16,
    zIndex: 1000,
  },
  valeterBadgeCard: {
    paddingHorizontal: 12,
    paddingVertical: 8,
  },
  valeterCountContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  valeterCountText: {
    fontSize: 16,
    fontWeight: '800',
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  cardWrapper: {
    marginRight: 12,
  },
  modernCard: {
    padding: 24,
    backgroundColor: 'transparent',
    borderRadius: 24,
    minHeight: 480,
    overflow: 'hidden',
  },
  badgeContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    marginBottom: 16,
  },
  badgeText: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 16,
    marginBottom: 16,
  },
  iconContainer: {
    width: 72,
    height: 72,
    borderRadius: 20,
    borderWidth: 2,
    overflow: 'hidden',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  iconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  titleSection: {
    flex: 1,
    gap: 4,
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: 26,
    fontWeight: '900',
    letterSpacing: -0.5,
  },
  cardSubtitle: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 15,
    fontWeight: '600',
  },
  cardDescription: {
    color: 'rgba(249,250,251,0.85)',
    fontSize: 15,
    lineHeight: 22,
    marginBottom: 20,
  },
  statusRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
    marginBottom: 20,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  statusText: {
    fontSize: 13,
    fontWeight: '700',
  },
  trustBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  trustText: {
    fontSize: 12,
    fontWeight: '700',
  },
  featuresContainer: {
    gap: 12,
    marginBottom: 24,
  },
  featureItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  featureDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  featureText: {
    color: 'rgba(249,250,251,0.9)',
    fontSize: 14,
    fontWeight: '600',
    flex: 1,
  },
  ctaButton: {
    borderRadius: 18,
    overflow: 'hidden',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 12,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 24,
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: 0.3,
  },
  toggleSwitch: {
    width: 64,
    height: 32,
  },
  toggleTrack: {
    width: 64,
    height: 32,
    borderRadius: 16,
    justifyContent: 'center',
    paddingHorizontal: 2,
  },
  toggleThumb: {
    width: 28,
    height: 28,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
});
