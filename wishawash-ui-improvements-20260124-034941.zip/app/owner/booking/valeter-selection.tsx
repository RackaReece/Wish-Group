import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Image,
  Alert,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Region, Marker } from 'react-native-maps';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import { serviceOptions } from '../../../src/constants/serviceOptions';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../app/components/NavigationTab';
import { ValeterStatsService } from '../../../src/services/Valeterstatsservice';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

// Uber-style dark map theme
const uberDarkMapStyle = [
  {
    elementType: 'geometry',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.fill',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'administrative.locality',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'geometry',
    stylers: [{ color: '#263c3f' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#6b9a76' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry',
    stylers: [{ color: '#38414e' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#212a37' }],
  },
  {
    featureType: 'road',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#9ca5b3' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#1f2835' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#f3d19c' }],
  },
  {
    featureType: 'transit',
    elementType: 'geometry',
    stylers: [{ color: '#2f3948' }],
  },
  {
    featureType: 'transit.station',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [{ color: '#17263c' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#515c6d' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#17263c' }],
  },
];

interface Valeter {
  id: string;
  name: string;
  rating: number;
  totalJobs: number;
  distance: number;
  isOnline: boolean;
  profilePicture?: string;
  lastLat?: number;
  lastLng?: number;
  isVerified?: boolean;
  responseTime?: number; // in minutes
  eta?: number; // in minutes
  vehicleRegistration?: string;
  vehicleType?: string;
}

export default function ValeterSelection() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const serviceId = params.serviceId as string;
  const vehicleId = params.vehicleId as string;
  const latitude = parseFloat(params.latitude as string);
  const longitude = parseFloat(params.longitude as string);
  const address = params.address as string;
  const customerOffersWater = params.customerOffersWater === 'true';
  const customerOffersElectricity = params.customerOffersElectricity === 'true';
  const discountAmount = parseFloat(params.discountAmount as string) || 0;
  const washType = params.washType as 'exterior' | 'interior' | 'both' | undefined;

  const [valeters, setValeters] = useState<Valeter[]>([]);
  const [selectedValeter, setSelectedValeter] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [region, setRegion] = useState<Region>({
    latitude: latitude || 51.5074,
    longitude: longitude || -0.1278,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  });

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();

    loadNearbyValeters();
  }, []);

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 3959; // Earth's radius in miles
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const loadNearbyValeters = async () => {
    try {
      // Load online valeters with their presence data
      const { data: presenceData, error: presenceError } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng')
        .eq('is_online', true);

      if (presenceError) throw presenceError;

      if (!presenceData || presenceData.length === 0) {
        setValeters([]);
        setLoading(false);
        return;
      }

      // Load valeter profiles
      const userIds = presenceData.map(p => p.user_id);
      const { data: profilesData, error: profilesError } = await supabase
        .from('valeter_profiles')
        .select('user_id, full_name, profile_photo_url, verification_status')
        .in('user_id', userIds);

      if (profilesError) throw profilesError;

      // Load valeter vehicles
      const { data: vehiclesData } = await supabase
        .from('customer_vehicles')
        .select('user_id, registration, type')
        .in('user_id', userIds)
        .eq('is_default', true);

      // Fetch stats for all valeters in parallel
      const statsPromises = userIds.map(userId => 
        ValeterStatsService.getValeterStats(userId).catch(() => null)
      );
      const statsResults = await Promise.all(statsPromises);
      const statsMap = new Map(
        userIds.map((userId, index) => [userId, statsResults[index]])
      );

      // Combine data and calculate distances
      const valetersList: Valeter[] = await Promise.all(
        presenceData.map(async (presence) => {
          const profile = profilesData?.find(p => p.user_id === presence.user_id);
          const distance = presence.last_lat && presence.last_lng
            ? calculateDistance(latitude, longitude, presence.last_lat, presence.last_lng)
            : 999;
          
          const stats = statsMap.get(presence.user_id);
          const displayName = profile?.full_name || 'Valeter';
          const isVerified = profile?.verification_status === 'verified';
          const vehicle = vehiclesData?.find(v => v.user_id === presence.user_id);
          
          // Calculate ETA based on distance (rough estimate: 1 mile = 2 minutes)
          const estimatedETA = Math.round(distance * 2);

          return {
            id: presence.user_id,
            name: displayName,
            rating: stats?.averageRating || 0,
            totalJobs: stats?.totalJobs || 0,
            distance: Math.round(distance * 10) / 10,
            isOnline: presence.is_online,
            profilePicture: profile?.profile_photo_url,
            lastLat: presence.last_lat,
            lastLng: presence.last_lng,
            isVerified: isVerified,
            responseTime: 5, // Default response time
            eta: estimatedETA,
            vehicleRegistration: vehicle?.registration,
            vehicleType: vehicle?.type,
          };
        })
      );

      const filteredValeters = valetersList
        .filter(v => v.distance <= 10) // Within 10 miles
        .sort((a, b) => a.distance - b.distance);

      setValeters(filteredValeters);
    } catch (error) {
      // Error handled by error handling service
      const errorService = await import('../../../src/services/ErrorHandlingService').then(m => m.errorHandlingService);
      errorService.handleBookingError(error as Error, 'valeter_selection');
    } finally {
      setLoading(false);
    }
  };

  const handleValeterSelect = async (valeterId: string) => {
    await hapticFeedback('light');
    setSelectedValeter(valeterId);
  };

  const selectedServiceOption = serviceOptions.find((option) => option.id === serviceId);

  const handleContinue = async () => {
    if (!selectedValeter || !selectedServiceOption) return;
    await hapticFeedback('medium');
    
    // Create booking with pending_valeter_acceptance status
    if (!user?.id) return;
    
    try {
      const scheduledAt = new Date().toISOString();
      const basePrice = selectedServiceOption.price || 25;
      const finalPrice = basePrice - discountAmount;
      
      const { data, error } = await supabase
        .from('bookings')
        .insert({
          user_id: user.id,
          valeter_id: selectedValeter,
          service_type: serviceId,
          service_name: selectedServiceOption.name || serviceId,
          status: 'pending_valeter_acceptance',
          price: finalPrice,
          location_address: address,
          location_lat: latitude,
          location_lng: longitude,
          customer_offers_water: customerOffersWater,
          customer_offers_electricity: customerOffersElectricity,
          discount_amount: discountAmount,
          wash_type: washType,
          request_sent_at: new Date().toISOString(),
          scheduled_at: scheduledAt,
        })
        .select()
        .single();

      if (error) throw error;

      router.push({
        pathname: '/owner/booking/waiting-acceptance',
        params: { bookingId: data.id },
      });
    } catch (error: any) {
      console.error('Error creating booking:', error);
      Alert.alert('Error', error?.message || 'Failed to create booking');
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={uberDarkMapStyle}
        >
          {/* User location marker */}
          {latitude && longitude && (
            <Marker coordinate={{ latitude, longitude }}>
              <View style={styles.userMarkerContainer}>
                <Image 
                  source={require('../../../assets/washing.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {/* Valeter markers */}
          {valeters.map((valeter) => {
            if (!valeter.lastLat || !valeter.lastLng) return null;
            const isSelected = selectedValeter === valeter.id;
            return (
              <Marker
                key={valeter.id}
                coordinate={{ latitude: valeter.lastLat, longitude: valeter.lastLng }}
                onPress={() => handleValeterSelect(valeter.id)}
              >
                <View style={styles.valeterMarkerContainer}>
                  <Image 
                    source={require('../../../assets/cleaning.png')} 
                    style={[
                      styles.valeterMarker,
                      isSelected && styles.valeterMarkerSelected
                    ]}
                    resizeMode="contain"
                  />
                  {valeter.isOnline && (
                    <View style={styles.valeterOnlineBadge}>
                      <View style={styles.valeterOnlineDot} />
                    </View>
                  )}
                </View>
              </Marker>
            );
          })}
        </MapView>
      </View>

      {/* Header floating over the map */}
      <AppHeader 
        title="Select Valeter" 
        subtitle="Choose your preferred valeter"
        showBack={true}
        onBack={() => router.back()}
        rightAction={
          <TouchableOpacity 
            onPress={async () => {
              await hapticFeedback('light');
              router.replace('/owner/owner-dashboard' as any);
            }} 
            style={styles.exitButton}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={22} color="#FFFFFF" />
          </TouchableOpacity>
        }
      />

      {/* Valeter profile cards - horizontal scroll */}
      <Animated.View
        style={[
          styles.cardContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            paddingBottom: Math.max(insets.bottom, 14) + 14 + TAB_BAR_TOTAL_HEIGHT + 12,
          },
        ]}
      >
        {loading ? (
          <GlassCard style={styles.trackingCard}>
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#FFFFFF" />
              <Text style={styles.loadingText}>Finding nearby valeters...</Text>
            </View>
          </GlassCard>
        ) : valeters.length === 0 ? (
          <GlassCard style={styles.trackingCard}>
            <View style={styles.emptyContent}>
              <Ionicons name="person-outline" size={48} color="#FFFFFF" style={{ opacity: 0.5 }} />
              <Text style={styles.emptyText}>No valeters available</Text>
              <Text style={styles.emptySubtext}>Try again later or adjust your location</Text>
            </View>
          </GlassCard>
        ) : (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.cardsScrollContent}
            snapToInterval={width - 32}
            decelerationRate="fast"
            pagingEnabled
          >
            {valeters.map((valeter) => {
              const isSelected = selectedValeter === valeter.id;
              return (
                <View key={valeter.id} style={[styles.cardWrapper, { width: width - 32 }]}>
                  <TouchableOpacity
                    onPress={() => handleValeterSelect(valeter.id)}
                    activeOpacity={0.8}
                    style={[
                      styles.uberValeterCard,
                      isSelected && styles.uberValeterCardSelected,
                    ]}
                  >
                    <View style={styles.uberValeterCardContent}>
                      <View style={styles.uberValeterHeader}>
                        <View style={styles.uberValeterLeft}>
                          {valeter.profilePicture ? (
                            <Image
                              source={{ uri: valeter.profilePicture }}
                              style={styles.uberProfileImage}
                            />
                          ) : (
                            <Image
                              source={require('../../../assets/cleaning.png')}
                              style={styles.uberProfileImage}
                              resizeMode="contain"
                            />
                          )}
                          {valeter.isOnline && (
                            <View style={styles.uberOnlineBadge}>
                              <View style={styles.uberOnlineDot} />
                            </View>
                          )}
                        </View>
                        <View style={styles.uberValeterInfo}>
                          <View style={styles.uberValeterNameRow}>
                            <Text style={styles.uberValeterName}>{valeter.name}</Text>
                            {isSelected && (
                              <View style={styles.uberSelectedBadge}>
                                <Ionicons name="checkmark-circle" size={20} color="#60A5FA" />
                              </View>
                            )}
                          </View>
                          <View style={styles.uberValeterStats}>
                            <View style={styles.uberStatItem}>
                              <Ionicons name="star" size={14} color="#FBBF24" />
                              <Text style={styles.uberStatText}>{valeter.rating.toFixed(1)}</Text>
                            </View>
                            <View style={styles.uberStatItem}>
                              <Ionicons name="car" size={14} color="rgba(255,255,255,0.7)" />
                              <Text style={styles.uberStatText}>{valeter.totalJobs} jobs</Text>
                            </View>
                            <View style={styles.uberStatItem}>
                              <Ionicons name="location" size={14} color="rgba(255,255,255,0.7)" />
                              <Text style={styles.uberStatText}>{valeter.distance.toFixed(1)} mi</Text>
                            </View>
                            {valeter.eta && (
                              <View style={styles.uberStatItem}>
                                <Ionicons name="time" size={14} color="#60A5FA" />
                                <Text style={[styles.uberStatText, { color: '#60A5FA' }]}>{valeter.eta} min</Text>
                              </View>
                            )}
                          </View>
                        </View>
                      </View>
                      {isSelected && (
                        <View style={styles.uberValeterActionRow}>
                          <TouchableOpacity
                            onPress={handleContinue}
                            style={styles.uberValeterButton}
                            activeOpacity={0.9}
                          >
                            <Text style={styles.uberValeterButtonText}>Choose this valeter</Text>
                          </TouchableOpacity>
                        </View>
                      )}
                    </View>
                  </TouchableOpacity>
                </View>
              );
            })}
          </ScrollView>
        )}
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  valeterMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  valeterMarker: {
    width: 48,
    height: 48,
  },
  valeterMarkerSelected: {
    width: 48,
    height: 48,
  },
  valeterOnlineBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#0A1929',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  valeterOnlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  trackingCard: {
    padding: 20,
    backgroundColor: 'rgba(15, 23, 42, 0.4)',
  },
  cardWrapper: {
    marginRight: 12,
  },
  cardSelected: {
    elevation: 10,
    shadowColor: SKY,
    shadowOpacity: 0.3,
    borderWidth: 1.5,
  },
  cardsScrollContent: {
    gap: 12,
    paddingRight: 16,
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: '#FFFFFF',
    fontSize: 14,
  },
  emptyContent: {
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtext: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
  },
  valeterHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 14,
  },
  valeterLeft: {
    position: 'relative',
  },
  profileImage: {
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 2,
    borderColor: SKY,
  },
  profilePlaceholder: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: SKY,
  },
  onlineBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: '#0A1929',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  onlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  valeterInfo: {
    flex: 1,
  },
  valeterNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  nameContainer: {
    flex: 1,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 4,
  },
  verifiedRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  verifiedText: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '500',
  },
  selectedCheck: {
    alignItems: 'center',
    gap: 2,
  },
  selectedLabel: {
    color: SKY,
    fontSize: 10,
    fontWeight: '600',
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  bookingInfo: {
    gap: 8,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  infoText: {
    color: 'rgba(229,231,235,0.9)',
    fontSize: 13,
    flex: 1,
    fontWeight: '500',
  },
  actionsRow: {
    marginTop: 14,
  },
  continueBtn: {
    height: 44,
    borderRadius: 14,
    backgroundColor: SKY,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  continueBtnText: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  // Uber-style valeter card
  uberValeterCard: {
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  uberValeterCardSelected: {
    borderColor: '#60A5FA',
    shadowColor: '#60A5FA',
    shadowOpacity: 0.3,
  },
  uberValeterCardContent: {
    width: '100%',
  },
  uberValeterHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  uberValeterLeft: {
    position: 'relative',
  },
  uberProfileImage: {
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 2,
    borderColor: '#60A5FA',
  },
  uberOnlineBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  uberOnlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  uberValeterInfo: {
    flex: 1,
  },
  uberValeterNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  uberValeterName: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
    flex: 1,
    letterSpacing: 0.2,
  },
  uberSelectedBadge: {
    marginLeft: 8,
  },
  uberValeterStats: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flexWrap: 'wrap',
  },
  uberStatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  uberStatText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '500',
  },
  uberValeterActionRow: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.15)',
  },
  uberValeterButton: {
    backgroundColor: '#60A5FA',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  uberValeterButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
});

