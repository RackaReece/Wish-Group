import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Dimensions,
  Animated,
  Image,
} from 'react-native';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { customerTheme } from '../../../src/constants/customerTheme';
import { serviceOptions } from '../../../src/constants/serviceOptions';
import {
  WWBottomSheet,
  WWPrimaryButton,
  WashTierCard,
  WWMapHeaderControls,
  WWSectionHeader,
} from '../../../src/components/ui';
import type { BottomSheetState, WashTier } from '../../../src/components/ui';

const { width, height } = Dimensions.get('window');
const SKY = '#5B8FA8';

// Dark map style
const darkMapStyle = [
  { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
  { featureType: 'water', stylers: [{ color: '#17263c' }] },
];

export default function ServiceSelection() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const vehicleId = params.vehicleId as string;
  const locationLat = params.locationLat ? parseFloat(params.locationLat as string) : null;
  const locationLng = params.locationLng ? parseFloat(params.locationLng as string) : null;

  const [selectedTier, setSelectedTier] = useState<WashTier | null>(null);
  const [sheetState, setSheetState] = useState<BottomSheetState>('half');
  const [region, setRegion] = useState<Region>({
    latitude: locationLat || 51.5074,
    longitude: locationLng || -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') return;

        const location = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Balanced,
        });

        const coords = {
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        };

        setUserLocation(coords);
        if (!locationLat || !locationLng) {
          setRegion({
            latitude: coords.latitude,
            longitude: coords.longitude,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          });
        }
      } catch (error) {
        console.warn('Error getting location:', error);
      }
    })();
  }, []);

  const handleTierSelect = (tier: WashTier) => {
    setSelectedTier(tier);
    setSheetState('half');
  };

  const handleContinue = () => {
    if (!selectedTier || !vehicleId) return;

    const serviceMap: Record<WashTier, string> = {
      Bronze: 'bronze-wash',
      Silver: 'silver-wash',
      Gold: 'gold-wash',
    };

    router.push({
      pathname: '/owner/booking/valeter-selection',
      params: {
        serviceId: serviceMap[selectedTier],
        vehicleId,
        locationLat: locationLat?.toString() || userLocation?.latitude.toString(),
        locationLng: locationLng?.toString() || userLocation?.longitude.toString(),
      },
    } as any);
  };

  const handleBack = () => {
    router.back();
  };

  const handleLocate = async () => {
    try {
      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });
      setRegion({
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    } catch (error) {
      console.warn('Error locating:', error);
    }
  };

  const bronzeService = serviceOptions.find(s => s.id === 'bronze-wash');
  const silverService = serviceOptions.find(s => s.id === 'silver-wash');
  const goldService = serviceOptions.find(s => s.id === 'gold-wash');

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Full Screen Map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          customMapStyle={darkMapStyle}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarker}>
                <View style={styles.markerPulse} />
                <View style={styles.markerInner}>
                  <Ionicons name="person" size={16} color={SKY} />
                </View>
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Map Header Controls */}
      <WWMapHeaderControls
        onBack={handleBack}
        onLocate={handleLocate}
        showClose={false}
      />

      {/* Bottom Sheet */}
      <WWBottomSheet
        state={sheetState}
        onStateChange={setSheetState}
        collapsedHeight={height * 0.15}
        halfHeight={height * 0.55}
        fullHeight={height * 0.85}
      >
        <WWSectionHeader
          title="Choose a wash"
          subtitle="Select your preferred service tier"
        />

        <View style={styles.servicesContainer}>
          {bronzeService && (
            <WashTierCard
              tier="Bronze"
              duration={bronzeService.dur}
              price={`£${bronzeService.price}`}
              perks={bronzeService.bulletPoints?.slice(0, 3) || []}
              selected={selectedTier === 'Bronze'}
              onPress={() => handleTierSelect('Bronze')}
            />
          )}

          {silverService && (
            <WashTierCard
              tier="Silver"
              duration={silverService.dur}
              price={`£${silverService.price}`}
              perks={silverService.bulletPoints?.slice(0, 3) || []}
              selected={selectedTier === 'Silver'}
              onPress={() => handleTierSelect('Silver')}
            />
          )}

          {goldService && (
            <WashTierCard
              tier="Gold"
              duration={goldService.dur}
              price={`£${goldService.price}`}
              perks={goldService.bulletPoints?.slice(0, 3) || []}
              selected={selectedTier === 'Gold'}
              onPress={() => handleTierSelect('Gold')}
            />
          )}
        </View>
      </WWBottomSheet>

      {/* Primary CTA */}
      {selectedTier && (
        <View style={styles.footer}>
          <WWPrimaryButton
            title="Continue"
            onPress={handleContinue}
          />
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  userMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  markerPulse: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: `${SKY}30`,
  },
  markerInner: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: '#0A1929',
    borderWidth: 2,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  servicesContainer: {
    paddingTop: 8,
  },
  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 20,
    paddingBottom: 20,
    paddingTop: 12,
    backgroundColor: 'rgba(15, 23, 42, 0.95)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
});
