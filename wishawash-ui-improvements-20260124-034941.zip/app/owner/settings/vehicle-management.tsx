// app/owner/settings/vehicle-management.tsx

import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  Modal,
  TextInput,
  Alert,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  Image,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import * as FileSystem from 'expo-file-system';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import dvlaService from '../../../src/services/DVLAService';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { useProfilePicture } from '../../../src/hooks/useProfilePicture';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../app/components/NavigationTab';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;
const LIGHT_SKY = colors.LIGHT_SKY;

type Vehicle = {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;

  mot_status?: string | null;
  mot_expiry_date?: string | null;
  tax_status?: string | null;
  tax_due_date?: string | null;
  dvla_last_checked_at?: string | null;

  image_url?: string | null;
  image_path?: string | null;
};

type AddMode = 'reg' | 'manual';

function pickFirstString(obj: any, keys: string[]) {
  for (const k of keys) {
    const v = obj?.[k];
    if (typeof v === 'string' && v.trim()) return v.trim();
  }
  return '';
}

function normaliseToDateOnly(input: any) {
  if (!input) return '';
  const s = String(input).trim();
  if (!s) return '';
  const d = new Date(s);
  if (Number.isNaN(d.getTime())) return '';
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, '0');
  const dd = String(d.getDate()).padStart(2, '0');
  return `${yyyy}-${mm}-${dd}`;
}

function formatDatePretty(dateOnly: string | null | undefined) {
  if (!dateOnly) return '—';
  const d = new Date(`${dateOnly}T00:00:00`);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

function cleanReg(input: string) {
  return input.replace(/\s/g, '').toUpperCase();
}

function badgeToneFromStatus(status?: string | null) {
  const s = String(status || '').toLowerCase();
  if (!s) return 'neutral';
  if (s.includes('valid') || s.includes('taxed') || s.includes('in force') || s.includes('yes')) return 'good';
  if (s.includes('no') || s.includes('expired') || s.includes('sorn') || s.includes('not')) return 'bad';
  return 'neutral';
}

function base64ToUint8Array(base64: string) {
  const binary = globalThis.atob(base64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

function getDaysUntilExpiry(dateOnly: string | null | undefined): number | null {
  if (!dateOnly) return null;
  const d = new Date(`${dateOnly}T00:00:00`);
  if (Number.isNaN(d.getTime())) return null;
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  d.setHours(0, 0, 0, 0);
  const diff = d.getTime() - now.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

export default function VehicleManagement() {
  const { user } = useAuth();
  const profilePicture = useProfilePicture();
  const insets = useSafeAreaInsets();

  const [loading, setLoading] = useState(true);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);

  const [showModal, setShowModal] = useState(false);
  const [addMode, setAddMode] = useState<AddMode>('reg');

  const [editingVehicleId, setEditingVehicleId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    type: '',
    make: '',
    model: '',
    color: '',
    registration: '',

    mot_status: '',
    mot_expiry_date: '',
    tax_status: '',
    tax_due_date: '',

    image_url: '',
    image_path: '',
  });

  const [dvlaLoading, setDvlaLoading] = useState(false);
  const [dvlaTouched, setDvlaTouched] = useState(false);

  const [busyId, setBusyId] = useState<string | null>(null);
  const [uploadingImage, setUploadingImage] = useState(false);

  const lookupTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 400,
      useNativeDriver: true,
    }).start();
  }, []);

  const resetForm = () => {
    setFormData({
      type: '',
      make: '',
      model: '',
      color: '',
      registration: '',

      mot_status: '',
      mot_expiry_date: '',
      tax_status: '',
      tax_due_date: '',

      image_url: '',
      image_path: '',
    });
    setDvlaLoading(false);
    setDvlaTouched(false);
    setAddMode('reg');
    setEditingVehicleId(null);
    setUploadingImage(false);

    if (lookupTimeoutRef.current) {
      clearTimeout(lookupTimeoutRef.current);
      lookupTimeoutRef.current = null;
    }
  };

  const openAddModal = () => {
    resetForm();
    setShowModal(true);
  };

  const openEditModal = async (vehicle: Vehicle) => {
    if (busyId) return;
    await hapticFeedback('light');
    setEditingVehicleId(vehicle.id);

    setFormData({
      type: vehicle.type || 'Car',
      make: vehicle.make || '',
      model: vehicle.model || '',
      color: vehicle.color || '',
      registration: vehicle.registration || '',

      mot_status: vehicle.mot_status || '',
      mot_expiry_date: vehicle.mot_expiry_date || '',
      tax_status: vehicle.tax_status || '',
      tax_due_date: vehicle.tax_due_date || '',

      image_url: vehicle.image_url || '',
      image_path: vehicle.image_path || '',
    });

    setAddMode('manual');
    setDvlaTouched(false);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    resetForm();
  };

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      setLoading(true);
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      setVehicles((data || []) as Vehicle[]);
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadVehicles();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  useEffect(() => {
    return () => {
      if (lookupTimeoutRef.current) clearTimeout(lookupTimeoutRef.current);
    };
  }, []);

  const doDvlaLookup = async (registration: string) => {
    const reg = cleanReg(registration);
    const validation = dvlaService.validateRegistration(reg);
    if (!validation.isValid) return;

    setDvlaLoading(true);
    try {
      const result = await dvlaService.getVehicleDetails(reg);

      if (result?.success && result?.data) {
        const data = result.data;

        const vehicleType = dvlaService.inferVehicleType(data.make, data.model || '');

        const motStatus = pickFirstString(data, ['motStatus', 'mot_status']);
        const taxStatus = pickFirstString(data, ['taxStatus', 'tax_status']);

        const motExpiry = normaliseToDateOnly(
          pickFirstString(data, ['motExpiryDate', 'motExpiry', 'mot_expiry_date', 'motExpiryDateString'])
        );
        const taxDue = normaliseToDateOnly(
          pickFirstString(data, ['taxDueDate', 'taxDue', 'tax_due_date', 'taxDueDateString'])
        );

        setFormData((prev) => ({
          ...prev,
          registration: data.registrationNumber ? cleanReg(data.registrationNumber) : reg,
          make: data.make || prev.make,
          model: data.model || prev.model,
          color: data.colour || prev.color,
          type: vehicleType || prev.type || 'Car',

          mot_status: motStatus || prev.mot_status,
          mot_expiry_date: motExpiry || prev.mot_expiry_date,
          tax_status: taxStatus || prev.tax_status,
          tax_due_date: taxDue || prev.tax_due_date,
        }));

        setDvlaTouched(true);
      } else {
        if (result?.error && !String(result.error).toLowerCase().includes('mock')) {
          console.warn('[VehicleManagement] DVLA lookup failed:', result.error);
        }
      }
    } catch (error: any) {
      console.error('[VehicleManagement] DVLA lookup error:', error);
    } finally {
      setDvlaLoading(false);
    }
  };

  const handleRegistrationChange = async (registration: string) => {
    const reg = cleanReg(registration);

    setFormData((prev) => ({
      ...prev,
      registration: reg,
    }));

    if (lookupTimeoutRef.current) {
      clearTimeout(lookupTimeoutRef.current);
      lookupTimeoutRef.current = null;
    }

    if (addMode !== 'reg') return;

    lookupTimeoutRef.current = setTimeout(async () => {
      await doDvlaLookup(reg);
    }, 900);
  };

  const uploadVehicleImage = async (uri: string) => {
    if (!user?.id) throw new Error('Not signed in');

    const bucket = 'vehicle-images';

    const base64 = await FileSystem.readAsStringAsync(uri, {
      encoding: FileSystem.EncodingType.Base64,
    });
    const bytes = base64ToUint8Array(base64);

    const extGuess = uri.split('.').pop()?.toLowerCase();
    const ext = extGuess && extGuess.length <= 5 ? extGuess : 'jpg';

    const contentType =
      ext === 'png'
        ? 'image/png'
        : ext === 'webp'
        ? 'image/webp'
        : ext === 'heic'
        ? 'image/heic'
        : 'image/jpeg';

    const fileName = `${Date.now()}-${Math.random().toString(16).slice(2)}.${ext}`;
    const path = `${user.id}/${fileName}`;

    const { error: upErr } = await supabase.storage.from(bucket).upload(path, bytes, {
      contentType,
      upsert: false,
    });
    if (upErr) throw upErr;

    const { data } = supabase.storage.from(bucket).getPublicUrl(path);
    const publicUrl = data?.publicUrl || '';

    return { publicUrl, path };
  };

  const pickAndUploadImage = async () => {
    try {
      await hapticFeedback('light');

      const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (!perm.granted) {
        Alert.alert('Permission needed', 'Please allow photo access to upload a car picture.');
        return;
      }

      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaType.Images,
        quality: 0.9,
        allowsEditing: true,
        aspect: [4, 3],
      });

      if (result.canceled) return;
      const asset = result.assets?.[0];
      if (!asset?.uri) return;

      setUploadingImage(true);
      const { publicUrl, path } = await uploadVehicleImage(asset.uri);

      setFormData((p) => ({
        ...p,
        image_url: publicUrl,
        image_path: path,
      }));
    } catch (e: any) {
      console.error('[VehicleManagement] image upload failed', e);
      Alert.alert('Upload failed', e?.message || 'Failed to upload image');
    } finally {
      setUploadingImage(false);
    }
  };

  const removeImageFromForm = async () => {
    Alert.alert('Remove picture?', 'This will remove the picture from this vehicle.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: () => {
          setFormData((p) => ({ ...p, image_url: '', image_path: '' }));
        },
      },
    ]);
  };

  const handleSaveVehicle = async () => {
    if (!user?.id) return;

    const reg = cleanReg(formData.registration);
    if (!reg) {
      Alert.alert('Error', 'Registration is required (or switch to Manual entry and add details).');
      return;
    }

    const make = (formData.make || '').trim();
    const model = (formData.model || '').trim();
    if (!make || !model) {
      Alert.alert('Error', 'Please fill in Make and Model.');
      return;
    }

    try {
      await hapticFeedback('medium');

      const payload: any = {
        type: formData.type || 'Car',
        make,
        model,
        color: (formData.color || '').trim(),
        registration: reg,

        mot_status: formData.mot_status || null,
        mot_expiry_date: formData.mot_expiry_date || null,
        tax_status: formData.tax_status || null,
        tax_due_date: formData.tax_due_date || null,
        dvla_last_checked_at: dvlaTouched ? new Date().toISOString() : null,

        image_url: formData.image_url || null,
        image_path: formData.image_path || null,
      };

      if (editingVehicleId) {
        const { error } = await supabase
          .from('customer_vehicles')
          .update(payload)
          .eq('user_id', user.id)
          .eq('id', editingVehicleId);

        if (error) throw error;
      } else {
        const { error } = await supabase.from('customer_vehicles').insert({
          user_id: user.id,
          ...payload,
          is_default: vehicles.length === 0,
        });

        if (error) throw error;
      }

      setShowModal(false);
      resetForm();
      await loadVehicles();
    } catch (error: any) {
      console.error('[VehicleManagement] save failed', error);
      Alert.alert('Error', error?.message || 'Failed to save vehicle');
    }
  };

  const setDefaultVehicle = async (vehicleId: string) => {
    if (!user?.id) return;
    if (busyId) return;

    setBusyId(vehicleId);
    try {
      await hapticFeedback('light');

      const { error: clearErr } = await supabase
        .from('customer_vehicles')
        .update({ is_default: false })
        .eq('user_id', user.id)
        .eq('is_default', true);

      if (clearErr) throw clearErr;

      const { error: setErr } = await supabase
        .from('customer_vehicles')
        .update({ is_default: true })
        .eq('user_id', user.id)
        .eq('id', vehicleId);

      if (setErr) throw setErr;

      setVehicles((prev) => prev.map((v) => ({ ...v, is_default: v.id === vehicleId })));
    } catch (e: any) {
      console.error('[VehicleManagement] set default failed', e);
      Alert.alert('Error', e?.message || 'Failed to set default vehicle');
    } finally {
      setBusyId(null);
    }
  };

  const deleteVehicle = async (vehicle: Vehicle) => {
    if (!user?.id) return;
    if (busyId) return;

    const isOnlyVehicle = vehicles.length === 1;
    const isDefault = !!vehicle.is_default;

    const doDelete = async () => {
      setBusyId(vehicle.id);
      try {
        await hapticFeedback('medium');

        const { error } = await supabase.from('customer_vehicles').delete().eq('user_id', user.id).eq('id', vehicle.id);
        if (error) throw error;

        setVehicles((prev) => prev.filter((v) => v.id !== vehicle.id));

        if (isDefault && !isOnlyVehicle) {
          setTimeout(async () => {
            const remaining = vehicles.filter((v) => v.id !== vehicle.id);
            const next = remaining[0];
            if (next) await setDefaultVehicle(next.id);
          }, 0);
        }
      } catch (e: any) {
        console.error('[VehicleManagement] delete failed', e);
        Alert.alert('Error', e?.message || 'Failed to delete vehicle');
      } finally {
        setBusyId(null);
      }
    };

    Alert.alert('Delete vehicle?', `This will remove ${vehicle.registration} from your account.`, [
      { text: 'Cancel', style: 'cancel' },
      { text: 'Delete', style: 'destructive', onPress: doDelete },
    ]);
  };

  const StatusBadge = ({ 
    label, 
    status, 
    expiryDate, 
    icon 
  }: { 
    label: string; 
    status?: string | null; 
    expiryDate?: string | null; 
    icon: string;
  }) => {
    const tone = badgeToneFromStatus(status);
    const daysUntil = getDaysUntilExpiry(expiryDate);
    const isUrgent = daysUntil !== null && daysUntil <= 30 && daysUntil >= 0;

    return (
      <View style={[
        styles.statusBadge,
        tone === 'good' ? styles.statusBadgeGood : 
        tone === 'bad' ? styles.statusBadgeBad : 
        styles.statusBadgeNeutral,
        isUrgent && styles.statusBadgeUrgent
      ]}>
        <Ionicons 
          name={icon as any} 
          size={14} 
          color={
            tone === 'good' ? '#10B981' : 
            tone === 'bad' ? '#EF4444' : 
            isUrgent ? '#F59E0B' : SKY
          } 
        />
        <View style={styles.statusBadgeContent}>
          <Text style={[
            styles.statusBadgeLabel,
            tone === 'good' && styles.statusBadgeLabelGood,
            tone === 'bad' && styles.statusBadgeLabelBad,
            isUrgent && styles.statusBadgeLabelUrgent
          ]}>
            {label}
          </Text>
          <Text style={styles.statusBadgeValue}>
            {status || '—'}
            {expiryDate && ` • ${formatDatePretty(expiryDate)}`}
            {isUrgent && daysUntil !== null && (
              <Text style={styles.statusBadgeUrgentText}> ({daysUntil} days)</Text>
            )}
          </Text>
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading vehicles...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <View style={styles.background} />

      <AppHeader
        title="Vehicles"
        subtitle={vehicles.length > 0 ? `${vehicles.length} vehicle${vehicles.length !== 1 ? 's' : ''}` : 'Manage your vehicles'}
        profilePicture={profilePicture}
        onProfilePress={() => router.push('/owner/owner-profile')}
        rightAction={
          <TouchableOpacity onPress={openAddModal} style={styles.addButton}>
            <Ionicons name="add" size={20} color="#94A3B8" />
          </TouchableOpacity>
        }
      />

      <Animated.View style={[styles.content, { opacity: fadeAnim }]}>
        {vehicles.length === 0 ? (
          <View style={[styles.emptyContainer, { paddingTop: HEADER_CONTENT_OFFSET, paddingBottom: Math.max(insets.bottom, 14) + TAB_BAR_TOTAL_HEIGHT + 40 }]}>
            <View style={styles.emptyIconContainer}>
              <Ionicons name="car-outline" size={48} color="#64748B" />
            </View>
            <Text style={styles.emptyTitle}>No Vehicles Yet</Text>
            <Text style={styles.emptySubtitle}>
              Add your first vehicle to start booking washes{'\n'}and track your car care history
            </Text>

            <TouchableOpacity style={styles.addButtonCard} onPress={openAddModal} activeOpacity={0.85}>
              <View style={styles.addButtonCardGradient}>
                <Ionicons name="add" size={20} color="#64748B" />
                <Text style={styles.addButtonCardText}>Add Your First Vehicle</Text>
              </View>
            </TouchableOpacity>
          </View>
        ) : (
          <View style={[styles.horizontalContainer, { paddingTop: HEADER_CONTENT_OFFSET }]}>
            {/* Horizontal Scrolling Vehicle Cards */}
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={[
                styles.horizontalScrollContent,
                { paddingBottom: Math.max(insets.bottom, 14) + TAB_BAR_TOTAL_HEIGHT + 20 }
              ]}
              snapToInterval={width - 32}
              decelerationRate="fast"
              pagingEnabled
              snapToAlignment="start"
              style={styles.horizontalScrollView}
            >
              {vehicles.map((vehicle, index) => {
                const isBusy = busyId === vehicle.id;

                return (
                  <View key={vehicle.id} style={[styles.vehicleCard, { width: width - 32 }]}>
                    <LinearGradient
                      colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
                      style={styles.vehicleCardGradient}
                    >
                      {/* Vehicle Image */}
                      <View style={styles.vehicleImageContainer}>
                        {vehicle.image_url ? (
                          <Image source={{ uri: vehicle.image_url }} style={styles.vehicleImage} />
                        ) : (
                          <View style={styles.vehicleImagePlaceholder}>
                            <Ionicons name="car" size={32} color="#64748B" />
                          </View>
                        )}
                        {vehicle.is_default && (
                          <View style={styles.defaultBadgeOverlay}>
                            <View style={styles.defaultBadgeGradient}>
                              <Ionicons name="star" size={12} color="#10B981" />
                            </View>
                          </View>
                        )}
                      </View>

                      {/* Vehicle Info */}
                      <View style={styles.vehicleInfo}>
                        <View style={styles.vehicleHeader}>
                          <View style={styles.vehicleTitleContainer}>
                            <Text style={styles.vehicleName} numberOfLines={1}>
                              {vehicle.make} {vehicle.model}
                            </Text>
                            <Text style={styles.vehicleReg}>{vehicle.registration}</Text>
                          </View>
                          <View style={styles.vehicleActions}>
                            <TouchableOpacity
                              onPress={async () => {
                                if (busyId) return;
                                try {
                                  await openEditModal(vehicle);
                                } catch (error) {
                                  console.error('Error opening edit modal:', error);
                                }
                              }}
                              disabled={!!busyId}
                              activeOpacity={0.7}
                              hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
                              style={[
                                styles.actionButton,
                                !!busyId && styles.actionButtonDisabled
                              ]}
                            >
                              <Ionicons
                                name="create-outline"
                                size={16}
                                color={!!busyId ? 'rgba(100,116,139,0.5)' : '#64748B'}
                              />
                            </TouchableOpacity>
                            {!vehicle.is_default && (
                              <TouchableOpacity
                                onPress={() => setDefaultVehicle(vehicle.id)}
                                disabled={!!busyId}
                                activeOpacity={0.7}
                                style={styles.actionButton}
                              >
                                {isBusy ? (
                                  <ActivityIndicator size="small" color="#10B981" />
                                ) : (
                                  <Ionicons name="star-outline" size={16} color="#10B981" />
                                )}
                              </TouchableOpacity>
                            )}
                            <TouchableOpacity
                              onPress={() => deleteVehicle(vehicle)}
                              disabled={!!busyId}
                              activeOpacity={0.7}
                              style={styles.actionButton}
                            >
                              {isBusy ? (
                                <ActivityIndicator size="small" color="#EF4444" />
                              ) : (
                                <Ionicons name="trash-outline" size={16} color="#EF4444" />
                              )}
                            </TouchableOpacity>
                          </View>
                        </View>

                        <View style={styles.vehicleMetaRow}>
                          <Text style={styles.vehicleMetaText}>
                            {vehicle.type}
                            {vehicle.color && ` • ${vehicle.color}`}
                          </Text>
                        </View>

                        {/* Status Badges */}
                        <View style={styles.statusBadgesContainer}>
                          <StatusBadge
                            label="MOT"
                            status={vehicle.mot_status}
                            expiryDate={vehicle.mot_expiry_date}
                            icon="shield-checkmark-outline"
                          />
                          <StatusBadge
                            label="TAX"
                            status={vehicle.tax_status}
                            expiryDate={vehicle.tax_due_date}
                            icon="receipt-outline"
                          />
                        </View>

                        {!!vehicle.dvla_last_checked_at && (
                          <View style={styles.dvlaInfoRow}>
                            <Ionicons name="time-outline" size={12} color="rgba(249,250,251,0.5)" />
                            <Text style={styles.dvlaInfoText}>
                              DVLA checked {new Date(vehicle.dvla_last_checked_at).toLocaleDateString('en-GB', {
                                day: '2-digit',
                                month: 'short',
                              })}
                            </Text>
                          </View>
                        )}
                      </View>
                    </LinearGradient>
                  </View>
                );
              })}

              {/* Add More Card - Last in horizontal scroll */}
              <View style={[styles.addMoreCard, { width: width - 32 }]}>
                <TouchableOpacity
                  style={styles.addMoreCardButton}
                  onPress={openAddModal}
                  activeOpacity={0.85}
                >
                  <View style={styles.addMoreCardGradient}>
                    <View style={styles.addMoreIconContainer}>
                      <Ionicons name="add" size={28} color="#64748B" />
                    </View>
                    <Text style={styles.addMoreCardTitle}>Add Another Vehicle</Text>
                    <Text style={styles.addMoreCardSubtitle}>
                      Tap to add a new vehicle{'\n'}to your fleet
                    </Text>
                  </View>
                </TouchableOpacity>
              </View>
            </ScrollView>
          </View>
        )}
      </Animated.View>

      {/* Add/Edit Vehicle Modal */}
      <Modal visible={showModal} animationType="slide" transparent onRequestClose={closeModal}>
        <View style={styles.modalOverlay}>
          <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            keyboardVerticalOffset={Platform.OS === 'ios' ? 0 : 20}
            style={{ flex: 1 }}
          >
            <View style={styles.modalContent}>
              <LinearGradient
                colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
                style={styles.modalGradient}
              >
                <View style={styles.modalHeader}>
                  <View>
                    <Text style={styles.modalTitle}>{editingVehicleId ? 'Edit Vehicle' : 'Add Vehicle'}</Text>
                    <Text style={styles.modalSubtitle}>
                      {editingVehicleId ? 'Update your vehicle details' : 'Add a new vehicle to your fleet'}
                    </Text>
                  </View>
                  <TouchableOpacity onPress={closeModal} style={styles.modalCloseButton}>
                    <Ionicons name="close" size={24} color="#F9FAFB" />
                  </TouchableOpacity>
                </View>

                {!editingVehicleId && (
                  <View style={styles.modeRow}>
                    <Pressable 
                      onPress={() => {
                        hapticFeedback('light');
                        setAddMode('reg');
                      }} 
                      style={[styles.modePill, addMode === 'reg' && styles.modePillActive]}
                    >
                      <Ionicons name="search" size={18} color={addMode === 'reg' ? BG : SKY} />
                      <Text style={[styles.modeText, addMode === 'reg' && styles.modeTextActive]}>
                        Auto Lookup
                      </Text>
                    </Pressable>

                    <Pressable 
                      onPress={() => {
                        hapticFeedback('light');
                        setAddMode('manual');
                      }} 
                      style={[styles.modePill, addMode === 'manual' && styles.modePillActive]}
                    >
                      <Ionicons name="create-outline" size={18} color={addMode === 'manual' ? BG : SKY} />
                      <Text style={[styles.modeText, addMode === 'manual' && styles.modeTextActive]}>
                        Manual Entry
                      </Text>
                    </Pressable>
                  </View>
                )}

                <ScrollView 
                  style={styles.modalBody} 
                  showsVerticalScrollIndicator={false}
                  keyboardShouldPersistTaps="handled"
                  contentContainerStyle={{ paddingBottom: 20 }}
                >
                  {/* Picture */}
                  <View style={styles.imageSection}>
                    <Text style={styles.sectionLabel}>Vehicle Photo</Text>
                    <View style={styles.imageRow}>
                      <View style={styles.imagePreviewWrap}>
                        {formData.image_url ? (
                          <Image source={{ uri: formData.image_url }} style={styles.imagePreview} />
                        ) : (
                          <LinearGradient
                            colors={[SKY + '20', SKY + '10']}
                            style={styles.imagePlaceholder}
                          >
                            <Ionicons name="image-outline" size={32} color={SKY} />
                            <Text style={styles.imagePlaceholderText}>No photo</Text>
                          </LinearGradient>
                        )}
                      </View>

                      <View style={styles.imageButtons}>
                        <TouchableOpacity
                          onPress={pickAndUploadImage}
                          disabled={uploadingImage}
                          activeOpacity={0.85}
                          style={[styles.imageBtn, uploadingImage && { opacity: 0.7 }]}
                        >
                          {uploadingImage ? (
                            <ActivityIndicator size="small" color={SKY} />
                          ) : (
                            <>
                              <Ionicons name="cloud-upload-outline" size={18} color={SKY} />
                              <Text style={styles.imageBtnText}>
                                {formData.image_url ? 'Change' : 'Upload'}
                              </Text>
                            </>
                          )}
                        </TouchableOpacity>

                        {!!formData.image_url && (
                          <TouchableOpacity 
                            onPress={removeImageFromForm} 
                            activeOpacity={0.85} 
                            style={styles.imageBtnDanger}
                          >
                            <Ionicons name="trash-outline" size={18} color="#EF4444" />
                            <Text style={styles.imageBtnDangerText}>Remove</Text>
                          </TouchableOpacity>
                        )}
                      </View>
                    </View>
                  </View>

                  {/* Registration */}
                  <View style={styles.inputGroup}>
                    <View style={styles.inputLabelRow}>
                      <Text style={styles.inputLabel}>Registration Number *</Text>
                      {dvlaLoading && (
                        <View style={styles.lookupIndicator}>
                          <ActivityIndicator size="small" color={SKY} />
                          <Text style={styles.lookupText}>Looking up…</Text>
                        </View>
                      )}
                    </View>

                    <TextInput
                      style={styles.input}
                      value={formData.registration}
                      onChangeText={handleRegistrationChange}
                      placeholder="Enter UK reg (e.g., AB12CDE)"
                      placeholderTextColor="rgba(249,250,251,0.45)"
                      autoCapitalize="characters"
                      editable={!dvlaLoading}
                    />

                    {addMode === 'reg' && !editingVehicleId ? (
                      <Text style={styles.inputHint}>
                        We'll automatically fetch Make, Model, Colour, MOT & TAX from DVLA
                      </Text>
                    ) : (
                      <Text style={styles.inputHint}>
                        You can refresh DVLA data using the button below
                      </Text>
                    )}
                  </View>

                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Make *</Text>
                    <TextInput
                      style={styles.input}
                      value={formData.make}
                      onChangeText={(text) => setFormData((p) => ({ ...p, make: text }))}
                      placeholder={addMode === 'reg' && !editingVehicleId ? 'Auto-filled from DVLA' : 'e.g. Ford'}
                      placeholderTextColor="rgba(249,250,251,0.45)"
                      editable={addMode === 'manual' || editingVehicleId ? true : !dvlaLoading}
                    />
                  </View>

                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Model *</Text>
                    <TextInput
                      style={styles.input}
                      value={formData.model}
                      onChangeText={(text) => setFormData((p) => ({ ...p, model: text }))}
                      placeholder={addMode === 'reg' && !editingVehicleId ? 'Auto-filled from DVLA' : 'e.g. Fiesta'}
                      placeholderTextColor="rgba(249,250,251,0.45)"
                      editable={addMode === 'manual' || editingVehicleId ? true : !dvlaLoading}
                    />
                  </View>

                  <View style={styles.inputGroup}>
                    <Text style={styles.inputLabel}>Colour</Text>
                    <TextInput
                      style={styles.input}
                      value={formData.color}
                      onChangeText={(text) => setFormData((p) => ({ ...p, color: text }))}
                      placeholder={addMode === 'reg' && !editingVehicleId ? 'Auto-filled from DVLA' : 'e.g. Blue'}
                      placeholderTextColor="rgba(249,250,251,0.45)"
                      editable={addMode === 'manual' || editingVehicleId ? true : !dvlaLoading}
                    />
                  </View>

                  {/* DVLA Info */}
                  <View style={styles.dvlaSection}>
                    <View style={styles.dvlaHeader}>
                      <View style={styles.dvlaBadge}>
                        <Ionicons name="shield-checkmark" size={16} color={SKY} />
                        <Text style={styles.dvlaBadgeText}>DVLA Information</Text>
                      </View>
                      <TouchableOpacity
                        onPress={async () => {
                          const reg = cleanReg(formData.registration);
                          if (!reg) {
                            Alert.alert('Missing reg', 'Enter a registration first.');
                            return;
                          }
                          await hapticFeedback('light');
                          await doDvlaLookup(reg);
                        }}
                        style={styles.refreshPill}
                        activeOpacity={0.85}
                        disabled={dvlaLoading}
                      >
                        {dvlaLoading ? (
                          <ActivityIndicator size="small" color={SKY} />
                        ) : (
                          <>
                            <Ionicons name="refresh" size={16} color={SKY} />
                            <Text style={styles.refreshText}>Refresh</Text>
                          </>
                        )}
                      </TouchableOpacity>
                    </View>

                    <View style={styles.dvlaInfo}>
                      <View style={styles.dvlaInfoItem}>
                        <Text style={styles.dvlaInfoLabel}>MOT Status</Text>
                        <Text style={styles.dvlaInfoValue}>
                          {formData.mot_status || '—'}
                          {formData.mot_expiry_date && ` • ${formatDatePretty(formData.mot_expiry_date)}`}
                        </Text>
                      </View>
                      <View style={styles.dvlaInfoItem}>
                        <Text style={styles.dvlaInfoLabel}>TAX Status</Text>
                        <Text style={styles.dvlaInfoValue}>
                          {formData.tax_status || '—'}
                          {formData.tax_due_date && ` • ${formatDatePretty(formData.tax_due_date)}`}
                        </Text>
                      </View>
                    </View>
                  </View>

                  <TouchableOpacity 
                    style={styles.saveButton} 
                    onPress={handleSaveVehicle} 
                    activeOpacity={0.9} 
                    disabled={uploadingImage}
                  >
                    <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.saveButtonGradient}>
                      <Text style={styles.saveButtonText}>
                        {editingVehicleId ? 'Save Changes' : 'Add Vehicle'}
                      </Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </ScrollView>
              </LinearGradient>
            </View>
          </KeyboardAvoidingView>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0F172A' },
  background: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: '#0F172A',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: '#E2E8F0',
    fontSize: 14,
    fontWeight: '600',
  },

  content: { flex: 1 },
  horizontalContainer: {
    flex: 1,
    paddingHorizontal: 16,
  },
  horizontalScrollView: {
    flex: 1,
    marginTop: 8,
  },
  horizontalScrollContent: {
    paddingRight: 16,
    alignItems: 'flex-start',
  },

  addButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
  },

  emptyContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 80,
    paddingHorizontal: 24,
  },
  emptyIconContainer: {
    marginBottom: 24,
  },
  emptyTitle: {
    color: '#E2E8F0',
    fontSize: isSmallScreen ? 24 : 28,
    fontWeight: '700',
    marginBottom: 12,
    textAlign: 'center',
  },
  emptySubtitle: {
    color: '#94A3B8',
    fontSize: 15,
    textAlign: 'center',
    marginBottom: 32,
    lineHeight: 22,
  },

  addButtonCard: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#334155',
  },
  addButtonCardGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 28,
    gap: 10,
  },
  addButtonCardText: {
    color: '#64748B',
    fontSize: 16,
    fontWeight: '600',
  },


  vehicleCard: {
    marginRight: 16,
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: '#1E293B',
    borderWidth: 1,
    borderColor: '#334155',
    maxHeight: 500,
  },
  vehicleCardGradient: {
    padding: 20,
    minHeight: 400,
    justifyContent: 'space-between',
  },
  vehicleImageContainer: {
    width: '100%',
    height: 180,
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 16,
    position: 'relative',
    backgroundColor: '#0F172A',
  },
  vehicleImage: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover',
  },
  vehicleImagePlaceholder: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#1E293B',
  },
  defaultBadgeOverlay: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: '#10B981',
    borderRadius: 12,
    padding: 4,
  },
  defaultBadgeGradient: {
    alignItems: 'center',
    justifyContent: 'center',
  },

  vehicleInfo: {
    gap: 12,
  },
  vehicleHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  vehicleTitleContainer: {
    flex: 1,
    marginRight: 12,
  },
  vehicleName: {
    color: '#E2E8F0',
    fontSize: isSmallScreen ? 20 : 22,
    fontWeight: '700',
    marginBottom: 4,
  },
  vehicleReg: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
    letterSpacing: 0.5,
  },
  vehicleActions: {
    flexDirection: 'row',
    gap: 8,
    zIndex: 10,
  },
  actionButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
  },
  actionButtonDisabled: {
    opacity: 0.5,
  },
  vehicleMetaRow: {
    marginBottom: 4,
  },
  vehicleMetaText: {
    color: '#64748B',
    fontSize: 13,
    fontWeight: '500',
  },

  statusBadgesContainer: {
    flexDirection: 'row',
    gap: 8,
    flexWrap: 'wrap',
  },
  statusBadge: {
    flex: 1,
    minWidth: 120,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 12,
    borderRadius: 12,
    backgroundColor: '#334155',
    borderWidth: 1,
    borderColor: '#475569',
  },
  statusBadgeGood: {
    backgroundColor: '#064E3B',
    borderColor: '#10B981',
  },
  statusBadgeBad: {
    backgroundColor: '#7F1D1D',
    borderColor: '#EF4444',
  },
  statusBadgeNeutral: {},
  statusBadgeUrgent: {
    backgroundColor: '#78350F',
    borderColor: '#F59E0B',
  },
  statusBadgeContent: {
    flex: 1,
  },
  statusBadgeLabel: {
    color: '#64748B',
    fontSize: 11,
    fontWeight: '600',
    marginBottom: 2,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  statusBadgeLabelGood: {
    color: '#10B981',
  },
  statusBadgeLabelBad: {
    color: '#EF4444',
  },
  statusBadgeLabelUrgent: {
    color: '#F59E0B',
  },
  statusBadgeValue: {
    color: '#E2E8F0',
    fontSize: 12,
    fontWeight: '500',
  },
  statusBadgeUrgentText: {
    color: '#F59E0B',
    fontWeight: '700',
  },

  dvlaInfoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 4,
  },
  dvlaInfoText: {
    color: '#64748B',
    fontSize: 11,
    fontWeight: '500',
  },

  addMoreCard: {
    marginRight: 16,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: '#334155',
    borderStyle: 'dashed',
    maxHeight: 500,
    backgroundColor: '#1E293B',
  },
  addMoreCardButton: {
    height: '100%',
  },
  addMoreCardGradient: {
    height: '100%',
    minHeight: 400,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  addMoreIconContainer: {
    marginBottom: 16,
  },
  addMoreCardTitle: {
    color: '#94A3B8',
    fontSize: 18,
    fontWeight: '600',
    marginBottom: 8,
    textAlign: 'center',
  },
  addMoreCardSubtitle: {
    color: '#64748B',
    fontSize: 14,
    fontWeight: '500',
    textAlign: 'center',
    lineHeight: 20,
  },

  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'flex-end'
  },
  modalContent: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    maxHeight: '92%',
    overflow: 'hidden',
    backgroundColor: '#1E293B',
  },
  modalGradient: {
    flex: 1,
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
  },
  modalTitle: {
    color: '#E2E8F0',
    fontSize: 22,
    fontWeight: '700',
    marginBottom: 4,
  },
  modalSubtitle: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
  },
  modalCloseButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: '#334155',
    justifyContent: 'center',
    alignItems: 'center',
  },

  modeRow: {
    flexDirection: 'row',
    gap: 12,
    paddingHorizontal: 20,
    paddingVertical: 16,
  },
  modePill: {
    flex: 1,
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#475569',
    backgroundColor: '#334155',
  },
  modePillActive: {
    backgroundColor: '#3B82F6',
    borderColor: '#3B82F6',
  },
  modeText: {
    color: '#94A3B8',
    fontWeight: '600',
    fontSize: 14,
  },
  modeTextActive: {
    color: '#FFFFFF',
  },

  modalBody: {
    paddingHorizontal: 20,
  },

  imageSection: {
    marginBottom: 24,
  },
  sectionLabel: {
    color: '#E2E8F0',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 12,
  },
  imageRow: {
    flexDirection: 'row',
    gap: 16,
    alignItems: 'center',
  },
  imagePreviewWrap: {
    width: 120,
    height: 90,
    borderRadius: 12,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: '#475569',
    backgroundColor: '#334155',
  },
  imagePreview: {
    width: '100%',
    height: '100%',
    resizeMode: 'cover'
  },
  imagePlaceholder: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 6,
  },
  imagePlaceholderText: {
    color: '#64748B',
    fontSize: 11,
    fontWeight: '600',
  },
  imageButtons: {
    flex: 1,
    gap: 10,
  },
  imageBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#475569',
    backgroundColor: '#334155',
  },
  imageBtnText: {
    color: '#94A3B8',
    fontWeight: '600',
    fontSize: 14,
  },
  imageBtnDanger: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#EF4444',
    backgroundColor: '#7F1D1D',
  },
  imageBtnDangerText: {
    color: '#FCA5A5',
    fontWeight: '600',
    fontSize: 14,
  },

  inputGroup: {
    marginBottom: 20,
  },
  inputLabel: {
    color: '#E2E8F0',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 10,
  },
  inputLabelRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  lookupIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  lookupText: {
    color: '#3B82F6',
    fontSize: 12,
    fontWeight: '600',
  },
  inputHint: {
    color: '#64748B',
    fontSize: 12,
    marginTop: 8,
    lineHeight: 18,
  },
  input: {
    backgroundColor: '#334155',
    borderRadius: 12,
    padding: 16,
    color: '#E2E8F0',
    fontSize: 16,
    borderWidth: 1,
    borderColor: '#475569',
    fontWeight: '500',
  },

  dvlaSection: {
    marginTop: 8,
    marginBottom: 24,
    padding: 16,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#475569',
    backgroundColor: '#334155',
  },
  dvlaHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  dvlaBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 10,
    backgroundColor: '#3B82F6',
  },
  dvlaBadgeText: {
    color: '#FFFFFF',
    fontWeight: '600',
    fontSize: 12,
  },
  refreshPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: '#475569',
    backgroundColor: '#334155',
  },
  refreshText: {
    color: '#94A3B8',
    fontWeight: '600',
    fontSize: 13,
  },
  dvlaInfo: {
    gap: 12,
  },
  dvlaInfoItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  dvlaInfoLabel: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
  },
  dvlaInfoValue: {
    color: '#E2E8F0',
    fontSize: 13,
    fontWeight: '500',
    flex: 1,
    textAlign: 'right',
  },

  saveButton: {
    borderRadius: 16,
    marginTop: 8,
    marginBottom: 20,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  saveButtonGradient: {
    backgroundColor: '#3B82F6',
    paddingVertical: 18,
    alignItems: 'center',
  },
  saveButtonText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
});
