import React, { useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Switch,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { useProfilePicture } from '../../../src/hooks/useProfilePicture';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

export default function PrivacySettings() {
  const { user } = useAuth();
  const [locationSharing, setLocationSharing] = useState(true);
  const [pushNotifications, setPushNotifications] = useState(true);
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [smsNotifications, setSmsNotifications] = useState(false);
  const [dataAnalytics, setDataAnalytics] = useState(true);
  const [marketingEmails, setMarketingEmails] = useState(false);
  const [isCabDriver, setIsCabDriver] = useState<boolean>(false); // UI-only state

  const settings = [
    {
      id: 'location',
      title: 'Location Sharing',
      subtitle: 'Allow app to access your location',
      value: locationSharing,
      onValueChange: setLocationSharing,
      icon: 'location',
    },
    {
      id: 'push',
      title: 'Push Notifications',
      subtitle: 'Receive notifications on your device',
      value: pushNotifications,
      onValueChange: setPushNotifications,
      icon: 'notifications',
    },
    {
      id: 'email',
      title: 'Email Notifications',
      subtitle: 'Receive updates via email',
      value: emailNotifications,
      onValueChange: setEmailNotifications,
      icon: 'mail',
    },
    {
      id: 'sms',
      title: 'SMS Notifications',
      subtitle: 'Receive text message updates',
      value: smsNotifications,
      onValueChange: setSmsNotifications,
      icon: 'chatbubble',
    },
    {
      id: 'analytics',
      title: 'Data Analytics',
      subtitle: 'Help improve our service',
      value: dataAnalytics,
      onValueChange: setDataAnalytics,
      icon: 'analytics',
    },
    {
      id: 'marketing',
      title: 'Marketing Emails',
      subtitle: 'Receive promotional content',
      value: marketingEmails,
      onValueChange: setMarketingEmails,
      icon: 'megaphone',
    },
    {
      id: 'cabDriver',
      title: 'I\'m a Cab Driver',
      subtitle: 'Enable for exclusive car wash discounts',
      value: isCabDriver,
      onValueChange: (value: boolean) => {
        setIsCabDriver(value);
        // UI-only toggle, no backend save
      },
      icon: 'car-sport',
    },
  ];

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader 
        title="Privacy Settings"
        profilePicture={useProfilePicture()}
        onProfilePress={() => router.push('/owner/owner-profile')}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
        showsVerticalScrollIndicator={false}
      >
        {settings.map((setting) => (
          <View key={setting.id} style={styles.settingCard}>
            <View style={styles.settingIconWrapper}>
              <Ionicons name={setting.icon as any} size={22} color={SKY} />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingTitle}>{setting.title}</Text>
              <Text style={styles.settingSubtitle}>{setting.subtitle}</Text>
            </View>
            <Switch
              value={setting.value}
              onValueChange={setting.onValueChange}
              trackColor={{ false: '#374151', true: SKY }}
              thumbColor={setting.value ? '#FFFFFF' : '#9CA3AF'}
            />
          </View>
        ))}

        <TouchableOpacity style={styles.linkCard} onPress={() => router.push('/privacy-policy')}>
          <Ionicons name="document-text" size={20} color={SKY} />
          <Text style={styles.linkText}>View Privacy Policy</Text>
          <Ionicons name="chevron-forward" size={20} color="#87CEEB" />
        </TouchableOpacity>

        <TouchableOpacity style={styles.linkCard} onPress={() => router.push('/cookie-policy')}>
          <Ionicons name="cookie-outline" size={20} color={SKY} />
          <Text style={styles.linkText}>View Cookie Policy</Text>
          <Ionicons name="chevron-forward" size={20} color="#87CEEB" />
        </TouchableOpacity>

        <TouchableOpacity style={styles.linkCard} onPress={() => router.push('/terms-of-service')}>
          <Ionicons name="document" size={20} color={SKY} />
          <Text style={styles.linkText}>View Terms of Service</Text>
          <Ionicons name="chevron-forward" size={20} color="#87CEEB" />
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? 12 : 20 },
  settingCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  settingIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  settingContent: {
    flex: 1,
  },
  settingTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 17,
    fontWeight: '700',
    marginBottom: 4,
  },
  settingSubtitle: {
    color: '#87CEEB',
    fontSize: 13,
    fontWeight: '600',
  },
  linkCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  linkText: {
    flex: 1,
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 17,
    fontWeight: '700',
    marginLeft: 12,
  },
});

