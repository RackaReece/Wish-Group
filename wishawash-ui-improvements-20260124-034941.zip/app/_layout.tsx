// app/_layout.tsx (RootLayout)
import React, { useEffect, useRef, useState } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { AuthProvider } from '../src/providers/enhanced-auth-context';
import { LogBox, Platform, View, StyleSheet } from 'react-native';
import * as SplashScreen from 'expo-splash-screen';
import NavigationTab from './components/NavigationTab';

// Conditionally import Stripe only on native platforms
let StripeProvider: any = ({ children }: { children: React.ReactNode }) => <>{children}</>;
if (Platform.OS !== 'web') {
  try {
    const stripe = require('@stripe/stripe-react-native');
    StripeProvider = stripe.StripeProvider;
  } catch (e) {
    // Stripe not available on this platform - handled gracefully
  }
}

// Make splash manual and guard errors
(async () => {
  try {
    await SplashScreen.preventAutoHideAsync();
  } catch (e) {
    // Splash screen error - non-critical, app will continue
  }
})();

LogBox.ignoreLogs([
  'Non-serializable values were found in the navigation state',
  'AsyncStorage has been extracted from react-native',
]);

export default function RootLayout() {
  const [appReady, setAppReady] = useState(false);
  const hideOnceRef = useRef(false);

  useEffect(() => {
    (async () => {
      try {
        const startTime = Date.now();

        // If you load fonts/assets, await them here.
        // await Font.loadAsync(...)
        await new Promise(requestAnimationFrame);

        // Ensure splash screen shows for at least 3 seconds
        const minDisplayTime = 3000;
        const elapsed = Date.now() - startTime;
        const remaining = Math.max(0, minDisplayTime - elapsed);

        if (remaining > 0) {
          await new Promise((resolve) => setTimeout(resolve, remaining));
        }

        setAppReady(true);
      } catch (e) {
        // Boot error - set app ready anyway to prevent blocking
        setAppReady(true);
      }
    })();
  }, []);

  useEffect(() => {
    const hide = async () => {
      if (appReady && !hideOnceRef.current) {
        hideOnceRef.current = true;
        try {
          await SplashScreen.hideAsync();
        } catch (e) {
          // Splash hide error - non-critical
        }
      }
    };
    hide();
  }, [appReady]);

  return (
    <StripeProvider
      publishableKey="pk_test_51S3OQLGYkpu3JDyWrHRRw6kvG9t4BNGpCiFVDAUeQCptnXAFJYnNEyWyv1HJG7XYsOd7Io4qYAn9T4deCcYUu2zC00O9yRUMdU"
      merchantIdentifier="merchant.com.wishawash"
      urlScheme="waw"
    >
      <AuthProvider>
        {/* IMPORTANT:
           - Keep layout transparent so screens can draw their own gradients to the very bottom.
           - Avoid painting a solid background behind every screen (kills the blur effect). */}
        <View style={styles.root}>
          <StatusBar style="light" backgroundColor="transparent" />

          <View style={styles.contentWrapper}>
            <Stack
              screenOptions={{
                headerShown: false,

                // ✅ key change: don't paint an opaque background behind all screens
                // If a screen doesn't provide its own background, it will fall back to root's transparent.
                contentStyle: { backgroundColor: 'transparent' },

                animation: Platform.OS === 'android' ? 'slide_from_right' : 'default',
                gestureEnabled: false,
              }}
            />
            <NavigationTab />
          </View>
        </View>
      </AuthProvider>
    </StripeProvider>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  contentWrapper: {
    flex: 1,
  },
});
