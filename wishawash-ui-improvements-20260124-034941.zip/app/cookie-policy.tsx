import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Dimensions,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import AppHeader, { HEADER_HEIGHT } from '../src/components/shared/AppHeader';
import GlassCard from '../src/components/booking/GlassCard';
import { useAuth } from '../src/providers/enhanced-auth-context';
import { getAccountTheme } from '../src/constants/accountThemes';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

export default function CookiePolicy() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  
  // Determine account type from user or route
  const accountType = user?.userType === 'valeter' ? 'valeter' 
    : user?.userType === 'organization' ? 'business' 
    : 'customer';
  const theme = getAccountTheme(accountType);
  
  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />

      <AppHeader 
        title="Cookie Policy" 
        accountType={accountType}
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[
          styles.scrollContent,
          { paddingTop: insets.top + HEADER_HEIGHT + 4 },
        ]}
        showsVerticalScrollIndicator={false}
      >
        <GlassCard style={styles.headerCard} accountType={accountType}>
          <View style={styles.headerIcon}>
            <Ionicons name="cookie-outline" size={32} color={theme.primary} />
          </View>
          <Text style={styles.lastUpdated}>Last updated: {new Date().toLocaleDateString('en-GB', { 
            day: 'numeric', 
            month: 'long', 
            year: 'numeric' 
          })}</Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="information-circle" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>1. What Are Cookies?</Text>
          </View>
          <Text style={styles.sectionText}>
            Cookies are small text files that are placed on your device when you visit our app. They help us provide you with a better experience by remembering your preferences and understanding how you use our services.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="list" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>2. Types of Cookies We Use</Text>
          </View>
          <Text style={styles.sectionText}>
            We use the following types of cookies:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• <Text style={styles.bulletBold}>Essential Cookies:</Text> Required for the app to function properly, including authentication and security features</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.bulletBold}>Functional Cookies:</Text> Remember your preferences and settings to enhance your experience</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.bulletBold}>Analytics Cookies:</Text> Help us understand how users interact with our app to improve performance</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.bulletBold}>Performance Cookies:</Text> Monitor app performance and identify technical issues</Text>
          </View>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="settings" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>3. How We Use Cookies</Text>
          </View>
          <Text style={styles.sectionText}>
            We use cookies to:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• Keep you signed in and maintain your session</Text>
            <Text style={styles.bulletPoint}>• Remember your location preferences and vehicle information</Text>
            <Text style={styles.bulletPoint}>• Store your booking history and preferences</Text>
            <Text style={styles.bulletPoint}>• Analyse app usage to improve our services</Text>
            <Text style={styles.bulletPoint}>• Ensure app security and prevent fraud</Text>
            <Text style={styles.bulletPoint}>• Personalise your experience based on your usage patterns</Text>
          </View>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="time-outline" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>4. Cookie Duration</Text>
          </View>
          <Text style={styles.sectionText}>
            Cookies may be either "session" cookies or "persistent" cookies:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• <Text style={styles.bulletBold}>Session Cookies:</Text> Temporary cookies that expire when you close the app</Text>
            <Text style={styles.bulletPoint}>• <Text style={styles.bulletBold}>Persistent Cookies:</Text> Remain on your device for a set period or until you delete them</Text>
          </View>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="shield-checkmark" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>5. Third-Party Cookies</Text>
          </View>
          <Text style={styles.sectionText}>
            We may use third-party services that set their own cookies, including:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• Payment processors (Stripe) for secure payment handling</Text>
            <Text style={styles.bulletPoint}>• Analytics services to understand app performance</Text>
            <Text style={styles.bulletPoint}>• Location services for accurate service delivery</Text>
          </View>
          <Text style={[styles.sectionText, { marginTop: 12 }]}>
            These third parties have their own privacy policies and cookie practices.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="options" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>6. Managing Cookies</Text>
          </View>
          <Text style={styles.sectionText}>
            You can control and manage cookies through:
          </Text>
          <View style={styles.bulletList}>
            <Text style={styles.bulletPoint}>• Your device settings to clear or block cookies</Text>
            <Text style={styles.bulletPoint}>• App settings within your account preferences</Text>
            <Text style={styles.bulletPoint}>• Browser settings if accessing via web</Text>
          </View>
          <Text style={[styles.sectionText, { marginTop: 12 }]}>
            Please note that disabling certain cookies may affect app functionality and your user experience.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="globe-outline" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>7. UK GDPR Compliance</Text>
          </View>
          <Text style={styles.sectionText}>
            We comply with UK GDPR and the Privacy and Electronic Communications Regulations (PECR). We only use cookies that are necessary for the app to function or where we have your consent for non-essential cookies.
          </Text>
        </GlassCard>

        <GlassCard style={styles.sectionCard} accountType={accountType}>
          <View style={styles.sectionHeader}>
            <Ionicons name="mail-outline" size={20} color={theme.primary} />
            <Text style={[styles.sectionTitle, { color: theme.primary }]}>8. Contact Us</Text>
          </View>
          <Text style={styles.sectionText}>
            If you have questions about our use of cookies, please contact us through the app's support section or email our data protection team.
          </Text>
        </GlassCard>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 40, paddingHorizontal: isSmallScreen ? 16 : 20, gap: 16 },
  headerCard: {
    padding: 20,
    alignItems: 'center',
    marginBottom: 8,
  },
  headerIcon: {
    marginBottom: 12,
  },
  lastUpdated: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '500',
    textAlign: 'center',
  },
  sectionCard: {
    padding: 20,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
  },
  sectionTitle: {
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '700',
  },
  sectionText: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    lineHeight: 22,
    fontWeight: '400',
  },
  bulletList: {
    marginTop: 12,
    gap: 8,
  },
  bulletPoint: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    lineHeight: 20,
    marginLeft: 4,
  },
  bulletBold: {
    fontWeight: '700',
    color: 'rgba(255,255,255,0.95)',
  },
});
