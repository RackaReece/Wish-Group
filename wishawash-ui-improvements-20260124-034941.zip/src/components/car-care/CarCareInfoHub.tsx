import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
  TextInput,
  ActivityIndicator,
  RefreshControl,
  Dimensions,
  Linking,
  Alert,
  Image,
  Modal,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '../../providers/enhanced-auth-context';
import { supabase } from '../../lib/supabase';
import useLiveLocation from '../../hooks/useLiveLocation';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../shared/AppHeader';
import GlassCard from '../booking/GlassCard';
import { colors } from '../../constants/colors';
import { getAccountTheme } from '../../constants/accountThemes';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

interface CarCareTip {
  id: string;
  title: string;
  content: string;
  category: 'valeter' | 'customer' | 'general';
  source?: string;
  date?: string;
}

interface ComingSoonFeature {
  id: string;
  title: string;
  description: string;
  icon: string;
  availableDate?: string;
}

interface TaxMOTReminder {
  id: string;
  type: 'tax' | 'mot';
  vehicleRegistration: string;
  expiryDate: Date;
  daysRemaining: number;
}

interface CarWashLocation {
  id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  status?: string | null;
  wait_time_minutes?: number | null;
  distance?: number;
  organization_id?: string | null;
  rating?: number | null;
  total_reviews?: number | null;
  profile_photo?: string | null;
}


export default function CarCareInfoHub({ userType, onClose }: { userType: 'customer' | 'valeter' | 'organization'; onClose?: () => void }) {
  const { user } = useAuth();
    const { coords } = useLiveLocation();
  const [activeTab, setActiveTab] = useState<'carwashes' | 'reminders'>('carwashes');
  const [selectedLocation, setSelectedLocation] = useState<CarWashLocation | null>(null);
  
  // Get theme based on user type
  const theme = userType === 'customer' 
    ? getAccountTheme('customer')
    : userType === 'valeter'
    ? getAccountTheme('valeter')
    : getAccountTheme('business');
  const [searchQuery, setSearchQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [locations, setLocations] = useState<CarWashLocation[]>([]);
  const [filterType, setFilterType] = useState<'all' | 'eco-friendly' | 'self-service' | 'full-service'>('all');
  const [reminders, setReminders] = useState<TaxMOTReminder[]>([]);
  const [tips, setTips] = useState<CarCareTip[]>([]);
  const scrollViewRef = useRef<ScrollView>(null);

  // Get day of year for daily tip rotation (1-365/366)
  const getDayOfYear = (): number => {
    const now = new Date();
    const start = new Date(now.getFullYear(), 0, 0);
    const diff = now.getTime() - start.getTime();
    return Math.floor(diff / (1000 * 60 * 60 * 24));
  };

  // Load tips based on user type with daily rotation
  const loadTips = async () => {
    setLoading(true);
    try {
      // Expanded tip library for daily rotation
      const allTips: CarCareTip[] = userType === 'valeter' ? [
        {
          id: '1',
          title: 'Best Practices for Two-Bucket Wash Method',
          content: 'Always use two buckets - one for soapy water and one for rinsing your mitt. This prevents dirt from being reintroduced to your wash mitt, reducing the risk of scratches.',
          category: 'valeter',
          source: 'Professional Detailing Guide',
        },
        {
          id: '2',
          title: 'Proper Drying Techniques',
          content: 'Use a high-quality microfiber towel and dry in straight lines, not circular motions. Start from the top and work your way down to avoid water spots.',
          category: 'valeter',
          source: 'Car Care Expert',
        },
        {
          id: '3',
          title: 'Tyre Dressing Application',
          content: 'Apply tyre dressing evenly using an applicator pad. Avoid over-application as excess product can sling onto the vehicle\'s paintwork.',
          category: 'valeter',
          source: 'Detailing Tips',
        },
        {
          id: '4',
          title: 'Wheel Cleaning Best Practices',
          content: 'Clean wheels first before washing the body. Use dedicated wheel brushes and pH-neutral cleaners to protect brake components and wheel finishes.',
          category: 'valeter',
          source: 'Professional Detailing Guide',
        },
        {
          id: '5',
          title: 'Clay Bar Technique',
          content: 'Use a clay bar after washing to remove embedded contaminants. Keep the surface and clay bar lubricated with detail spray to prevent marring.',
          category: 'valeter',
          source: 'Advanced Detailing',
        },
        {
          id: '6',
          title: 'Paint Correction Safety',
          content: 'Always test polishing compounds in an inconspicuous area first. Start with the least aggressive method and work up only if needed.',
          category: 'valeter',
          source: 'Paint Care Expert',
        },
        {
          id: '7',
          title: 'Interior Vacuuming Order',
          content: 'Vacuum from top to bottom - start with headliner, then seats, then floor. Use appropriate attachments for different surfaces.',
          category: 'valeter',
          source: 'Interior Detailing Guide',
        },
        {
          id: '8',
          title: 'Leather Conditioning',
          content: 'Clean leather with pH-balanced cleaner first, then apply conditioner in thin, even coats. Allow to absorb before buffing.',
          category: 'valeter',
          source: 'Leather Care Specialist',
        },
        {
          id: '9',
          title: 'Glass Cleaning Technique',
          content: 'Clean glass with a dedicated glass cleaner and microfiber cloth. Use horizontal strokes on inside, vertical on outside to identify streaks.',
          category: 'valeter',
          source: 'Window Care Tips',
        },
        {
          id: '10',
          title: 'Engine Bay Cleaning',
          content: 'Cover sensitive components before cleaning. Use degreaser and low-pressure water. Never use high-pressure washers on engine bays.',
          category: 'valeter',
          source: 'Engine Care Guide',
        },
        {
          id: '11',
          title: 'Water Spot Prevention',
          content: 'Dry vehicles in shade or garage. Use filtered water for final rinse if possible. Apply quick detailer as you dry to prevent spots.',
          category: 'valeter',
          source: 'Water Management Tips',
        },
        {
          id: '12',
          title: 'Microfiber Care',
          content: 'Wash microfiber towels separately from other laundry. Use no fabric softener. Air dry or use low heat to maintain effectiveness.',
          category: 'valeter',
          source: 'Tool Maintenance',
        },
      ] : [
        {
          id: '1',
          title: 'Regular Washing Schedule',
          content: 'Wash your vehicle every two weeks to maintain its appearance and protect the paintwork. More frequent washing may be needed in winter months due to road salt.',
          category: 'customer',
          source: 'Car Care Guide',
        },
        {
          id: '2',
          title: 'Protecting Your Paintwork',
          content: 'Park in shaded areas when possible to protect your paint from UV damage. Consider waxing or ceramic coating for additional protection.',
          category: 'customer',
          source: 'Vehicle Maintenance Tips',
        },
        {
          id: '3',
          title: 'Interior Care',
          content: 'Vacuum regularly and use appropriate cleaners for different materials. Leather requires conditioning, while fabric may need protection sprays.',
          category: 'customer',
          source: 'Interior Care Guide',
        },
        {
          id: '4',
          title: 'Winter Car Care',
          content: 'Wash your car more frequently in winter to remove road salt and grime. Consider applying a protective wax before winter sets in.',
          category: 'customer',
          source: 'Seasonal Maintenance',
        },
        {
          id: '5',
          title: 'Tyre Maintenance',
          content: 'Check tyre pressure monthly and rotate tyres every 6,000-8,000 miles. Proper inflation improves fuel economy and tyre life.',
          category: 'customer',
          source: 'Tyre Care Guide',
        },
        {
          id: '6',
          title: 'Headlight Restoration',
          content: 'Cloudy headlights reduce visibility. Use a headlight restoration kit or have them professionally restored for better night driving safety.',
          category: 'customer',
          source: 'Safety Tips',
        },
        {
          id: '7',
          title: 'Bird Dropping Removal',
          content: 'Remove bird droppings immediately as they can damage paint. Use a damp cloth and gentle pressure, or a dedicated cleaner if needed.',
          category: 'customer',
          source: 'Quick Care Tips',
        },
        {
          id: '8',
          title: 'Dashboard Protection',
          content: 'Use UV-protectant products on your dashboard to prevent cracking and fading. Avoid products that create a shiny, reflective surface.',
          category: 'customer',
          source: 'Interior Protection',
        },
        {
          id: '9',
          title: 'Windscreen Wiper Care',
          content: 'Replace wiper blades every 6-12 months or when they streak. Clean the windscreen regularly and check washer fluid levels.',
          category: 'customer',
          source: 'Visibility Safety',
        },
        {
          id: '10',
          title: 'Paint Protection Film',
          content: 'Consider paint protection film for high-impact areas like the front bumper and bonnet. It provides excellent protection against stone chips.',
          category: 'customer',
          source: 'Long-term Protection',
        },
        {
          id: '11',
          title: 'Regular Waxing Benefits',
          content: 'Wax your vehicle every 3-4 months to maintain paint protection and shine. Choose between carnauba wax or synthetic sealants based on your needs.',
          category: 'customer',
          source: 'Paint Care Basics',
        },
        {
          id: '12',
          title: 'Eco-Friendly Washing',
          content: 'Use biodegradable soaps and wash on permeable surfaces. Consider waterless wash products for quick touch-ups between full washes.',
          category: 'customer',
          source: 'Environmental Care',
        },
      ];

      // Select tips based on day of year for daily rotation
      const dayOfYear = getDayOfYear();
      const tipsPerDay = 3; // Show 3 tips per day
      const startIndex = (dayOfYear % allTips.length);
      
      const dailyTips: CarCareTip[] = [];
      for (let i = 0; i < tipsPerDay; i++) {
        const tipIndex = (startIndex + i) % allTips.length;
        dailyTips.push(allTips[tipIndex]);
      }

      setTips(dailyTips);
    } catch (error) {
      console.error('Error loading tips:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  // Calculate distance between two coordinates
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 3959; // Earth's radius in miles
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  // Load car wash locations
  const loadLocations = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude,status,wait_time_minutes,organization_id,rating,total_reviews')
        .order('created_at', { ascending: true });

      if (error) throw error;

      // Load profile photos for organizations
      const locationsWithPhotos = await Promise.all((data || []).map(async (loc) => {
        let profilePhoto: string | null = null;
        
        if (loc.organization_id) {
          try {
            // Try to get organization profile photo from storage
            const orgFolder = `organizations/${loc.organization_id}`;
            const { data: files } = await supabase.storage
              .from('uploads')
              .list(orgFolder, { limit: 10 });
            
            if (files && files.length > 0) {
              const photoFile = files.find((f: any) => 
                String(f?.name || '').toLowerCase().includes('profile') ||
                String(f?.name || '').toLowerCase().includes('logo') ||
                String(f?.name || '').toLowerCase().includes('image')
              ) || files[0];
              
              if (photoFile?.name) {
                const path = `${orgFolder}/${photoFile.name}`;
                const { data: publicData } = supabase.storage.from('uploads').getPublicUrl(path);
                if (publicData?.publicUrl) {
                  profilePhoto = publicData.publicUrl;
                }
              }
            }
          } catch (err) {
            console.warn('Error loading org photo:', err);
          }
        }
        
        let distance: number | undefined;
        if (coords && loc.latitude && loc.longitude) {
          distance = calculateDistance(
            coords.latitude,
            coords.longitude,
            loc.latitude,
            loc.longitude
          );
        }
        
        return { ...loc, distance, profile_photo: profilePhoto };
      }));

      let locationsWithDistance: CarWashLocation[] = locationsWithPhotos;

      // Sort by distance if available
      locationsWithDistance.sort((a, b) => {
        if (a.distance === undefined) return 1;
        if (b.distance === undefined) return -1;
        return a.distance - b.distance;
      });

      // Apply search filter
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        locationsWithDistance = locationsWithDistance.filter(
          (loc) =>
            loc.name?.toLowerCase().includes(query) ||
            loc.address?.toLowerCase().includes(query)
        );
      }

      // Apply type filter
      if (filterType !== 'all') {
        // Note: This assumes status field contains filter info
        // Adjust based on actual database schema
        locationsWithDistance = locationsWithDistance.filter((loc) => {
          if (filterType === 'eco-friendly') {
            return loc.status?.toLowerCase().includes('eco') || loc.name?.toLowerCase().includes('eco');
          }
          return true;
        });
      }

      setLocations(locationsWithDistance);
    } catch (error) {
      console.error('Error loading locations:', error);
      setLocations([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };



  useEffect(() => {
    if (activeTab === 'carwashes') {
      loadLocations();
    }
  }, [activeTab, userType, searchQuery, filterType, coords]);

  const onRefresh = () => {
    setRefreshing(true);
    if (activeTab === 'carwashes') {
      loadLocations();
    } else if (activeTab === 'reminders') {
      loadReminders();
    }
  };


  const renderCarWashes = () => (
    <View style={styles.contentSection}>
      <View style={styles.searchSection}>
        <View style={[styles.searchContainer, { borderColor: `${theme.primary}40` }]}>
          <View style={styles.searchIconContainer}>
            <Ionicons name="search" size={22} color={theme.primary} />
          </View>
          <TextInput
            style={styles.searchInput}
            placeholder="Search car wash locations..."
            placeholderTextColor={`${theme.primary}70`}
            value={searchQuery}
            onChangeText={setSearchQuery}
          />
          {searchQuery.length > 0 && (
            <TouchableOpacity 
              onPress={() => setSearchQuery('')}
              style={styles.clearButton}
              activeOpacity={0.7}
            >
              <Ionicons name="close-circle" size={22} color={theme.primary} />
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Filter Buttons */}
      <View style={styles.filterContainer}>
        <ScrollView 
          horizontal 
          showsHorizontalScrollIndicator={false} 
          contentContainerStyle={styles.filterScroll}
        >
          {(['all', 'eco-friendly', 'self-service', 'full-service'] as const).map((filter) => {
            const isActive = filterType === filter;
            return (
              <TouchableOpacity
                key={filter}
                onPress={() => setFilterType(filter)}
                style={[
                  styles.filterButton,
                  isActive && styles.filterButtonActive
                ]}
                activeOpacity={0.7}
              >
                {isActive && (
                  <LinearGradient
                    colors={[`${theme.primary}40`, `${theme.primary}30`]}
                    style={StyleSheet.absoluteFill}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                  />
                )}
                <Text style={[
                  styles.filterText,
                  isActive && styles.filterTextActive
                ]}>
                  {filter === 'all' ? 'All' : filter === 'eco-friendly' ? 'Eco-Friendly' : filter === 'self-service' ? 'Self-Service' : 'Full-Service'}
                </Text>
              </TouchableOpacity>
            );
          })}
        </ScrollView>
      </View>

      {loading && !refreshing ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={theme.primary} />
          <Text style={[styles.loadingText, { color: theme.primary }]}>Searching locations...</Text>
        </View>
      ) : locations.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Ionicons name="location-outline" size={64} color={theme.primary} style={{ opacity: 0.5 }} />
          <Text style={styles.emptyTitle}>No Locations Found</Text>
          <Text style={styles.emptySubtitle}>
            {searchQuery ? 'Try a different search term' : 'No car wash locations available in your area'}
          </Text>
        </View>
      ) : (
        <View style={styles.locationsList}>
          {locations.map((location) => (
            <TouchableOpacity
              key={location.id}
              onPress={() => setSelectedLocation(location)}
              activeOpacity={0.9}
            >
              <GlassCard
                style={styles.locationCard}
                accountType={userType === 'customer' ? 'customer' : userType === 'valeter' ? 'valeter' : 'business'}
              >
                <LinearGradient
                  colors={['transparent', 'transparent']}
                  style={StyleSheet.absoluteFill}
                />
                <View style={styles.locationHeader}>
                  {location.profile_photo ? (
                    <Image 
                      source={{ uri: location.profile_photo }} 
                      style={styles.locationPhoto}
                    />
                  ) : (
                    <View style={[styles.locationIconWrapper, { backgroundColor: `${theme.primary}20`, borderColor: `${theme.primary}40` }]}>
                      <Ionicons name="business" size={28} color={theme.primary} />
                    </View>
                  )}
                  <View style={styles.locationInfo}>
                    <View style={styles.locationNameRow}>
                      <Text style={styles.locationName}>{location.name}</Text>
                      {location.distance !== undefined && (
                        <View style={[styles.distanceBadge, { backgroundColor: `${theme.primary}25` }]}>
                          <Ionicons name="navigate" size={14} color={theme.primary} />
                          <Text style={[styles.distanceText, { color: theme.primary }]}>{location.distance.toFixed(1)} mi</Text>
                        </View>
                      )}
                    </View>
                    {location.address && (
                      <View style={styles.addressRow}>
                        <Ionicons name="location-outline" size={14} color="rgba(255,255,255,0.6)" />
                        <Text style={styles.locationAddress} numberOfLines={2}>
                          {location.address}
                        </Text>
                      </View>
                    )}
                  </View>
                </View>
                <View style={styles.locationMeta}>
                  {location.wait_time_minutes !== null && location.wait_time_minutes !== undefined && (
                    <View style={[styles.metaBadge, { backgroundColor: `${theme.primary}20` }]}>
                      <Ionicons name="time" size={14} color={theme.primary} />
                      <Text style={[styles.metaText, { color: theme.primary }]}>
                        {location.wait_time_minutes < 15 ? '< 15 min' : `${location.wait_time_minutes} min`}
                      </Text>
                    </View>
                  )}
                  {location.status && (
                    <View style={[styles.metaBadge, { backgroundColor: 'rgba(255,255,255,0.1)' }]}>
                      <Ionicons name="information-circle" size={14} color="rgba(255,255,255,0.8)" />
                      <Text style={styles.metaText}>{location.status}</Text>
                    </View>
                  )}
                </View>
              </GlassCard>
            </TouchableOpacity>
          ))}
        </View>
      )}
    </View>
  );


  // Load Tax & MOT reminders (from DVLA-backed fields on customer_vehicles)
  const loadReminders = async () => {
    if (!user?.id) {
      setReminders([]);
      return;
    }

    setLoading(true);
    try {
      // Pull the DVLA fields you’re now storing
      const { data: vehicles, error } = await supabase
        .from('customer_vehicles')
        .select('id,registration,tax_status,tax_due_date,mot_status,mot_expiry_date')
        .eq('user_id', user.id);

      if (error) throw error;

      const reminderList: TaxMOTReminder[] = [];
      const now = new Date();

      (vehicles || []).forEach((vehicle: any) => {
        const reg = vehicle.registration || 'Unknown';

        // TAX reminders (only if we have a due date + it's not obviously untaxed/SORN)
        if (vehicle.tax_due_date) {
          const taxExpiry = new Date(vehicle.tax_due_date);
          const daysRemaining = Math.ceil((taxExpiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

          const taxStatus = String(vehicle.tax_status || '').toLowerCase();
          const isClearlyNotTaxed = taxStatus.includes('sorn') || taxStatus.includes('not') || taxStatus.includes('no');

          if (!isClearlyNotTaxed && daysRemaining >= 0 && daysRemaining <= 60) {
            reminderList.push({
              id: `tax-${vehicle.id}`,
              type: 'tax',
              vehicleRegistration: reg,
              expiryDate: taxExpiry,
              daysRemaining,
            });
          }
        }

        // MOT reminders (only if we have an expiry date + it's not obviously no MOT)
        if (vehicle.mot_expiry_date) {
          const motExpiry = new Date(vehicle.mot_expiry_date);
          const daysRemaining = Math.ceil((motExpiry.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

          const motStatus = String(vehicle.mot_status || '').toLowerCase();
          const isClearlyNoMot = motStatus.includes('no') || motStatus.includes('not');

          if (!isClearlyNoMot && daysRemaining >= 0 && daysRemaining <= 60) {
            reminderList.push({
              id: `mot-${vehicle.id}`,
              type: 'mot',
              vehicleRegistration: reg,
              expiryDate: motExpiry,
              daysRemaining,
            });
          }
        }
      });

      // Sort by days remaining (most urgent first)
      reminderList.sort((a, b) => a.daysRemaining - b.daysRemaining);
      setReminders(reminderList);
    } catch (error) {
      console.error('Error loading reminders:', error);
      setReminders([]);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };


  useEffect(() => {
    if (activeTab === 'reminders') {
      loadReminders();
    }
  }, [activeTab, user?.id]);


  const renderReminders = () => {
    if (loading && !refreshing) {
      return (
        <View style={styles.contentSection}>
          <View style={styles.loadingContainer}>
            <ActivityIndicator size="large" color={theme.primary} />
            <Text style={[styles.loadingText, { color: theme.primary }]}>Loading reminders...</Text>
          </View>
        </View>
      );
    }

    if (reminders.length === 0) {
      return (
        <View style={styles.contentSection}>
          <View style={styles.emptyContainer}>
            <Ionicons name="calendar-outline" size={64} color={theme.primary} style={{ opacity: 0.5 }} />
            <Text style={styles.emptyTitle}>No Active Reminders</Text>
            <Text style={styles.emptySubtitle}>
              Add your vehicles and set tax/MOT expiry dates to receive automatic reminders
            </Text>
            <TouchableOpacity 
              style={[styles.addVehicleButton, { backgroundColor: theme.primary }]}
              onPress={() => router.push('/owner/settings/vehicle-management')}
            >
              <Text style={styles.addVehicleText}>Manage Vehicles</Text>
            </TouchableOpacity>
          </View>
        </View>
      );
    }

    return (
      <View style={styles.contentSection}>
        <Text style={styles.sectionDescription}>
          Active reminders for your vehicles
        </Text>
        {reminders.map((reminder) => {
          const isUrgent = reminder.daysRemaining < 7;
          const isWarning = reminder.daysRemaining >= 7 && reminder.daysRemaining < 30;
          const color = isUrgent ? '#EF4444' : isWarning ? '#F59E0B' : '#10B981';
          
          return (
            <GlassCard
              key={reminder.id}
              style={[styles.reminderCard, { borderColor: color + '50', borderWidth: 2 }]}
              accountType={userType === 'customer' ? 'customer' : userType === 'valeter' ? 'valeter' : 'business'}
            >
              <LinearGradient
                colors={[`${color}15`, `${color}08`]}
                style={StyleSheet.absoluteFill}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              />
              <View style={styles.reminderHeader}>
                <View style={[styles.reminderIconWrapper, { backgroundColor: color + '25', borderColor: color + '50' }]}>
                  <Ionicons 
                    name={reminder.type === 'tax' ? 'card' : 'shield-checkmark'} 
                    size={26} 
                    color={color} 
                  />
                </View>
                <View style={styles.reminderContent}>
                  <View style={styles.reminderTitleRow}>
                    <Text style={styles.reminderTitle}>
                      {reminder.type === 'tax' ? 'Vehicle Tax' : 'MOT'} Expiry
                    </Text>
                    <View style={[styles.daysBadge, { backgroundColor: color }]}>
                      <Text style={styles.daysText}>
                        {reminder.daysRemaining === 0 
                          ? 'Today' 
                          : reminder.daysRemaining === 1 
                          ? '1 day' 
                          : `${reminder.daysRemaining} days`}
                      </Text>
                    </View>
                  </View>
                  <Text style={styles.reminderRegistration}>
                    {reminder.vehicleRegistration}
                  </Text>
                </View>
              </View>
              <View style={styles.reminderFooter}>
                <View style={[styles.reminderDateBadge, { backgroundColor: color + '20' }]}>
                  <Ionicons name="calendar" size={16} color={color} />
                  <Text style={[styles.reminderDate, { color }]}>
                    {reminder.expiryDate.toLocaleDateString('en-GB', { 
                      day: 'numeric', 
                      month: 'short', 
                      year: 'numeric' 
                    })}
                  </Text>
                </View>
              </View>
            </GlassCard>
          );
        })}
        <TouchableOpacity 
          style={[styles.addVehicleButton, { backgroundColor: theme.primary }]}
          onPress={() => router.push('/owner/settings/vehicle-management')}
        >
          <Text style={styles.addVehicleText}>Manage Vehicles</Text>
        </TouchableOpacity>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={theme.background} style={StyleSheet.absoluteFill} />
      
      <AppHeader
        title="Car Care Info Hub"
        subtitle="Local Car Washes & More"
        accountType={userType === 'customer' ? 'customer' : userType === 'valeter' ? 'valeter' : 'business'}
        rightAction={
          onClose ? (
            <TouchableOpacity onPress={onClose} style={styles.closeButton}>
              <Ionicons name="close" size={24} color={theme.primary} />
            </TouchableOpacity>
          ) : undefined
        }
        showBack={false}
      />

      <View style={[styles.contentWrapper, { paddingTop: HEADER_CONTENT_OFFSET }]}>
        <View style={styles.tabsContainer}>
          <View style={styles.tabsRow}>
            <TouchableOpacity
              style={[
                styles.tabPill,
                activeTab === 'carwashes' && { backgroundColor: theme.primary }
              ]}
              onPress={() => setActiveTab('carwashes')}
              activeOpacity={0.8}
            >
              <Ionicons 
                name="business" 
                size={18} 
                color={activeTab === 'carwashes' ? '#FFFFFF' : theme.primary} 
              />
              <Text style={[
                styles.tabPillText,
                activeTab === 'carwashes' && styles.tabPillTextActive
              ]}>
                Car Washes
              </Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[
                styles.tabPill,
                activeTab === 'reminders' && { backgroundColor: theme.primary }
              ]}
              onPress={() => setActiveTab('reminders')}
              activeOpacity={0.8}
            >
              <Ionicons 
                name="calendar" 
                size={18} 
                color={activeTab === 'reminders' ? '#FFFFFF' : theme.primary} 
              />
              <Text style={[
                styles.tabPillText,
                activeTab === 'reminders' && styles.tabPillTextActive
              ]}>
                Tax & MOT
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        <ScrollView
          ref={scrollViewRef}
          style={styles.scrollView}
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
          refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />}
        >
          {activeTab === 'carwashes' && renderCarWashes()}
          {activeTab === 'reminders' && renderReminders()}
        </ScrollView>
      </View>

      {/* Enhanced Location Details Modal */}
      <Modal
        visible={selectedLocation !== null}
        transparent
        animationType="slide"
        onRequestClose={() => setSelectedLocation(null)}
      >
        <View style={styles.modalOverlay}>
          <TouchableOpacity 
            style={styles.modalBackdrop}
            activeOpacity={1}
            onPress={() => setSelectedLocation(null)}
          />
          <View style={styles.modalContent}>
            {selectedLocation && (
              <>
                <View style={styles.modalHeader}>
                  <View style={styles.modalHeaderContent}>
                    {selectedLocation.profile_photo ? (
                      <Image 
                        source={{ uri: selectedLocation.profile_photo }} 
                        style={styles.profilePhotoLarge}
                      />
                    ) : (
                      <View style={[styles.profilePhotoPlaceholder, { backgroundColor: `${theme.primary}25`, borderColor: `${theme.primary}50` }]}>
                        <Ionicons name="business" size={52} color={theme.primary} />
                      </View>
                    )}
                    <View style={styles.modalHeaderText}>
                      <Text style={styles.profileName}>{selectedLocation.name}</Text>
                    </View>
                  </View>
                  <TouchableOpacity
                    style={styles.closeModalButton}
                    onPress={() => setSelectedLocation(null)}
                    activeOpacity={0.7}
                  >
                    <View style={styles.closeModalButtonInner}>
                      <Ionicons name="close" size={22} color="#FFFFFF" />
                    </View>
                  </TouchableOpacity>
                </View>
                
                <ScrollView style={styles.profileScroll} showsVerticalScrollIndicator={false}>
                  <View style={styles.profileInfo}>
                    <View style={styles.profileDetailsSection}>
                      {selectedLocation.address && (
                        <View style={styles.profileDetailCard}>
                          <View style={[styles.profileDetailIcon, { backgroundColor: `${theme.primary}20` }]}>
                            <Ionicons name="location" size={20} color={theme.primary} />
                          </View>
                          <View style={styles.profileDetailContent}>
                            <Text style={styles.profileDetailLabel}>Address</Text>
                            <Text style={styles.profileDetailText}>{selectedLocation.address}</Text>
                          </View>
                        </View>
                      )}
                      
                      {selectedLocation.distance !== undefined && (
                        <View style={styles.profileDetailCard}>
                          <View style={[styles.profileDetailIcon, { backgroundColor: `${theme.primary}20` }]}>
                            <Ionicons name="navigate" size={20} color={theme.primary} />
                          </View>
                          <View style={styles.profileDetailContent}>
                            <Text style={styles.profileDetailLabel}>Distance</Text>
                            <Text style={styles.profileDetailText}>{selectedLocation.distance.toFixed(1)} miles away</Text>
                          </View>
                        </View>
                      )}

                      {selectedLocation.wait_time_minutes !== null && selectedLocation.wait_time_minutes !== undefined && (
                        <View style={styles.profileDetailCard}>
                          <View style={[styles.profileDetailIcon, { backgroundColor: `${theme.primary}20` }]}>
                            <Ionicons name="time" size={20} color={theme.primary} />
                          </View>
                          <View style={styles.profileDetailContent}>
                            <Text style={styles.profileDetailLabel}>Wait Time</Text>
                            <Text style={styles.profileDetailText}>
                              {selectedLocation.wait_time_minutes < 15 ? 'Under 15 minutes' : `${selectedLocation.wait_time_minutes} minutes`}
                            </Text>
                          </View>
                        </View>
                      )}

                      {selectedLocation.status && (
                        <View style={styles.profileDetailCard}>
                          <View style={[styles.profileDetailIcon, { backgroundColor: `${theme.primary}20` }]}>
                            <Ionicons name="information-circle" size={20} color={theme.primary} />
                          </View>
                          <View style={styles.profileDetailContent}>
                            <Text style={styles.profileDetailLabel}>Status</Text>
                            <Text style={styles.profileDetailText}>{selectedLocation.status}</Text>
                          </View>
                        </View>
                      )}

                    </View>
                  
                  {userType === 'customer' && (
                    <TouchableOpacity
                      style={[styles.bookButton, { backgroundColor: theme.primary }]}
                      onPress={() => {
                        setSelectedLocation(null);
                        router.push({
                          pathname: '/owner/booking/physical/location',
                          params: { preSelectedLocationId: selectedLocation.id },
                        });
                      }}
                      activeOpacity={0.8}
                    >
                      <LinearGradient
                        colors={[theme.primary, '#3B82F6']}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 0 }}
                        style={styles.bookButtonGradient}
                      >
                        <Text style={styles.bookButtonText}>Book at this location</Text>
                        <Ionicons name="arrow-forward" size={22} color="#FFFFFF" />
                      </LinearGradient>
                    </TouchableOpacity>
                  )}
                  </View>
                </ScrollView>
              </>
            )}
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: BG,
  },
  contentWrapper: {
    flex: 1,
  },
  closeButton: {
    padding: 8,
  },
  tabsContainer: {
    paddingHorizontal: 20,
    paddingVertical: 12,
  },
  tabsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  tabPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 22,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  tabPillText: {
    fontSize: 16,
    fontWeight: '700',
    color: SKY,
    includeFontPadding: false,
  },
  tabPillTextActive: {
    color: '#FFFFFF',
  },
  scrollView: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 100,
  },
  contentSection: {
    gap: 16,
  },
  sectionDescription: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
    marginBottom: 8,
    textAlign: 'center',
  },
  searchSection: {
    marginBottom: 20,
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 18,
    paddingHorizontal: 4,
    paddingVertical: 4,
    gap: 8,
    borderWidth: 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  searchIconContainer: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 4,
  },
  searchInput: {
    flex: 1,
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    paddingVertical: 12,
  },
  clearButton: {
    padding: 8,
    marginRight: 4,
  },
  loadingContainer: {
    paddingVertical: 60,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    fontSize: 14,
  },
  emptyContainer: {
    paddingVertical: 60,
    alignItems: 'center',
    gap: 16,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: 'bold',
  },
  emptySubtitle: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 14,
    textAlign: 'center',
    paddingHorizontal: 40,
  },
  tipCard: {
    marginBottom: 16,
    padding: 20,
  },
  tipHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  tipIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  tipContent: {
    flex: 1,
  },
  tipTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  tipSource: {
    color: 'rgba(255,255,255,0.5)',
    fontSize: 12,
  },
  tipText: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    lineHeight: 20,
  },
  featureCard: {
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
  },
  featureGradient: {
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
    position: 'relative',
  },
  featureHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
    marginBottom: 12,
  },
  featureIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(139,92,246,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  featureContent: {
    flex: 1,
  },
  featureTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 4,
  },
  featureDate: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
  },
  featureDescription: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 12,
  },
  comingSoonBadge: {
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(139,92,246,0.3)',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  comingSoonText: {
    color: '#8B5CF6',
    fontSize: 12,
    fontWeight: '600',
  },
  addVehicleButton: {
    marginTop: 20,
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 12,
  },
  addVehicleText: {
    color: '#0A1929',
    fontSize: 16,
    fontWeight: '600',
  },
  filterContainer: {
    marginBottom: 20,
  },
  filterScroll: {
    gap: 8,
    paddingRight: 20,
  },
  filterButton: {
    paddingHorizontal: 18,
    paddingVertical: 10,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.1)',
    marginRight: 10,
    overflow: 'hidden',
    position: 'relative',
  },
  filterButtonActive: {
    borderColor: SKY,
    borderWidth: 2,
  },
  filterText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  filterTextActive: {
    color: SKY,
    fontWeight: '800',
  },
  locationsList: {
    gap: 12,
  },
  locationCard: {
    marginBottom: 16,
    padding: 20,
    borderRadius: 20,
    borderWidth: 1.5,
    overflow: 'hidden',
    maxHeight: 220,
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 16,
    marginBottom: 16,
  },
  locationIconWrapper: {
    width: 64,
    height: 64,
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2.5,
  },
  locationPhoto: {
    width: 64,
    height: 64,
    borderRadius: 32,
    borderWidth: 3,
    borderColor: `${SKY}90`,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 4,
  },
  ratingStars: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ratingText: {
    color: '#FBBF24',
    fontSize: 14,
    fontWeight: '700',
  },
  reviewCount: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    fontWeight: '600',
  },
  locationInfo: {
    flex: 1,
  },
  locationNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
    gap: 8,
  },
  locationName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: 0.2,
    flex: 1,
  },
  addressRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 6,
    marginBottom: 8,
  },
  locationAddress: {
    color: 'rgba(255,255,255,0.75)',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '600',
    flex: 1,
  },
  distanceBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  distanceText: {
    fontSize: 12,
    fontWeight: '800',
  },
  locationMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flexWrap: 'wrap',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.08)',
  },
  metaBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  metaText: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 12,
    fontWeight: '700',
  },
  ecoBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: 'rgba(16,185,129,0.2)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  ecoBadgeText: {
    color: '#10B981',
    fontSize: 11,
    fontWeight: '600',
  },
  reminderCard: {
    marginBottom: 16,
    padding: 20,
    borderRadius: 20,
    overflow: 'hidden',
    maxHeight: 220,
  },
  reminderHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 16,
    marginBottom: 16,
  },
  reminderIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 28,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2.5,
  },
  reminderContent: {
    flex: 1,
  },
  reminderTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
    gap: 8,
  },
  reminderTitle: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.2,
    flex: 1,
  },
  reminderRegistration: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 15,
    fontWeight: '700',
  },
  daysBadge: {
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 14,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  daysText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  reminderFooter: {
    paddingTop: 12,
    borderTopWidth: 1.5,
    borderTopColor: 'rgba(255,255,255,0.12)',
  },
  reminderDateBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    alignSelf: 'flex-start',
  },
  reminderDate: {
    fontSize: 13,
    fontWeight: '700',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.75)',
    justifyContent: 'flex-end',
  },
  modalBackdrop: {
    ...StyleSheet.absoluteFillObject,
  },
  modalContent: {
    backgroundColor: BG,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    maxHeight: height * 0.9,
    paddingBottom: 100,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 10,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    padding: 24,
    paddingBottom: 20,
    borderBottomWidth: 1.5,
    borderBottomColor: 'rgba(135,206,235,0.2)',
  },
  modalHeaderContent: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 16,
    flex: 1,
  },
  modalHeaderText: {
    flex: 1,
    gap: 8,
  },
  modalRatingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  modalRatingText: {
    color: '#FBBF24',
    fontSize: 15,
    fontWeight: '700',
  },
  profilePhotoLarge: {
    width: 80,
    height: 80,
    borderRadius: 40,
    borderWidth: 3,
    borderColor: SKY,
  },
  profilePhotoPlaceholder: {
    width: 80,
    height: 80,
    borderRadius: 40,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 3,
  },
  closeModalButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(0,0,0,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  closeModalButtonInner: {
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileScroll: {
    flex: 1,
  },
  profileInfo: {
    padding: 20,
    gap: 20,
  },
  profileName: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    letterSpacing: 0.2,
    marginBottom: 4,
  },
  profileDetailsSection: {
    gap: 12,
  },
  profileDetailCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    padding: 16,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  profileDetailIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  profileDetailContent: {
    flex: 1,
    gap: 4,
  },
  profileDetailLabel: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  profileDetailText: {
    color: 'rgba(255,255,255,0.95)',
    fontSize: 15,
    fontWeight: '700',
    flex: 1,
  },
  profileDetailRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 8,
  },
  bookButton: {
    marginHorizontal: 20,
    marginTop: 24,
    borderRadius: 18,
    overflow: 'hidden',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 6,
  },
  bookButtonGradient: {
    paddingVertical: 18,
    paddingHorizontal: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
  },
  bookButtonText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
});

