import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Easing,
  Dimensions,
  ScrollView,
  Modal,
  ActivityIndicator,
  StatusBar,
  Alert,
  Image,
} from 'react-native';
import MapView, { Marker, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../providers/enhanced-auth-context';
import { supabase } from '../../lib/supabase';
import AsyncStorage from '@react-native-async-storage/async-storage';
import CarCareInfoHub from '../car-care/CarCareInfoHub';
import GradientNotificationBell from '../shared/GradientNotificationBell';
import AppHeader, { DASHBOARD_HEADER_CONTENT_OFFSET } from '../shared/AppHeader';
import BubbleBackground from '../shared/BubbleBackground';
import useLiveLocation from '../../hooks/useLiveLocation';
import { customerTheme } from '../../constants/customerTheme';
import { colors } from '../../constants/colors';
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;
import { getServiceDisplayName } from '../../utils/serviceNameMapper';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY;

interface NearbyValeter {
  id: string;
  name: string;
  organization: string;
  rating: number;
  distance: number | null;
  isOnline: boolean;
}

interface LoyaltyData {
  points: number;
  tier: 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  pointsToNextTier: number;
  nextReward?: string;
}

type DbBookingStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled';

type ActiveBooking = {
  id: string;
  status: DbBookingStatus;
  service_type: string;
  service_name: string | null;
  location_address: string | null;
  scheduled_at: string;
  price: number;
  valeter_name: string | null;
  valeter_id: string | null;
  latitude: number | null;
  longitude: number | null;
};

const ACTIVE_STATUSES: DbBookingStatus[] = ['scheduled', 'in_progress'];

export default function EnhancedCustomerDashboard() {
  const { user } = useAuth();

  const [nearbyValeters, setNearbyValeters] = useState<NearbyValeter[]>([]);
  const [carWashCount, setCarWashCount] = useState(0);
  const [detailingHubCount, setDetailingHubCount] = useState(0);
  const [showCarCareHub, setShowCarCareHub] = useState(false);
  const [loading, setLoading] = useState(true);
  const [profileName, setProfileName] = useState<string>('');
  const [profilePicture, setProfilePicture] = useState<string | null>(null);
  const [notificationCount, setNotificationCount] = useState(0);
  const [weeklyStats, setWeeklyStats] = useState({
    washesThisWeek: 0,
    totalWashes: 0,
  });

  const [activeBooking, setActiveBooking] = useState<ActiveBooking | null>(null);
  const [activeBookingLoading, setActiveBookingLoading] = useState(false);
  const [recentBookings, setRecentBookings] = useState<ActiveBooking[]>([]);
  const [recentBookingsLoading, setRecentBookingsLoading] = useState(false);
  const [valeterLocation, setValeterLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [eta, setEta] = useState<number | null>(null);
  const valeterPresenceChannelRef = useRef<any>(null);

  // Still used by header points + notifications logic
  const [loyaltyData] = useState<LoyaltyData | null>({
    points: 850,
    tier: 'Silver',
    pointsToNextTier: 150,
    nextReward: '50 points = 10% off next wash',
  });

  const { refresh } = useLiveLocation();

  const notificationStatuses = useMemo(
    () => [
      'pending',
      'pending_valeter_acceptance',
      'pending_payment',
      'confirmed',
      'valeter_assigned',
      'en_route',
      'arrived',
      'in_progress',
      'scheduled',
      'completed',
      'cancelled',
    ],
    []
  );

  const refreshRef = useRef(refresh);
  useEffect(() => {
    refreshRef.current = refresh;
  }, [refresh]);

  useEffect(() => {
    const interval = setInterval(() => {
      refreshRef.current?.();
    }, 60000);
    return () => clearInterval(interval);
  }, []);

  const scrollY = useRef(new Animated.Value(0)).current;

  // Animated bubbles for header background
  const bubbleData = useRef(
    Array.from({ length: 8 }, (_, index) => {
      const random = Math.random();
      return {
        translateY: new Animated.Value(0),
        opacity: new Animated.Value(0.2 + random * 0.2),
        scale: new Animated.Value(0.6 + random * 0.3),
        size: 20 + random * 30,
        leftPosition: width * 0.6 + random * width * 0.3,
        delay: index * 800,
        duration: 12000 + random * 8000,
        startY: 120 + random * 40,
        endY: -60,
        initialOpacity: 0.2 + random * 0.2,
      };
    })
  ).current;

  useEffect(() => {
    bubbleData.forEach((bubble) => {
      bubble.translateY.setValue(bubble.startY);
      bubble.opacity.setValue(bubble.initialOpacity);

      Animated.parallel([
        Animated.loop(
          Animated.sequence([
            Animated.delay(bubble.delay),
            Animated.timing(bubble.translateY, {
              toValue: bubble.endY,
              duration: bubble.duration,
              useNativeDriver: true,
            }),
            Animated.timing(bubble.translateY, {
              toValue: bubble.startY,
              duration: 0,
              useNativeDriver: true,
            }),
          ])
        ),
        Animated.loop(
          Animated.sequence([
            Animated.timing(bubble.opacity, {
              toValue: 0.35,
              duration: bubble.duration / 3,
              easing: Easing.inOut(Easing.ease),
              useNativeDriver: true,
            }),
            Animated.timing(bubble.opacity, {
              toValue: 0.15,
              duration: bubble.duration / 3,
              easing: Easing.inOut(Easing.ease),
              useNativeDriver: true,
            }),
            Animated.timing(bubble.opacity, {
              toValue: bubble.initialOpacity,
              duration: bubble.duration / 3,
              easing: Easing.inOut(Easing.ease),
              useNativeDriver: true,
            }),
          ])
        ),
      ]).start();
    });
  }, [bubbleData]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        console.warn('Location permission not granted');
        return;
      }

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };

      setUserLocation(coords);
      // Recalculate ETA if valeter location exists
      if (valeterLocation) {
        calculateETA(valeterLocation);
      }
      return coords;
    } catch (error) {
      console.warn('Error getting location:', error);
      return null;
    }
  };

  const loadValeterLocation = async (valeterId: string) => {
    try {
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', valeterId)
        .maybeSingle();

      if (error) {
        console.warn('Error loading valeter location:', error);
        return;
      }

      if (data?.last_lat && data?.last_lng) {
        const valeterCoords = {
          latitude: Number(data.last_lat),
          longitude: Number(data.last_lng),
        };
        setValeterLocation(valeterCoords);
        calculateETA(valeterCoords);
      } else {
        setValeterLocation(null);
        setEta(null);
      }
    } catch (error) {
      console.warn('Error loading valeter location:', error);
    }
  };

  const calculateETA = (valeterCoords: { latitude: number; longitude: number }) => {
    if (!userLocation) return;

    const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
      const R = 3959; // Earth radius in miles
      const dLat = ((lat2 - lat1) * Math.PI) / 180;
      const dLon = ((lon2 - lon1) * Math.PI) / 180;
      const a =
        Math.sin(dLat / 2) * Math.sin(dLat / 2) +
        Math.cos((lat1 * Math.PI) / 180) *
          Math.cos((lat2 * Math.PI) / 180) *
          Math.sin(dLon / 2) *
          Math.sin(dLon / 2);
      const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
      return R * c;
    };

    const distance = calculateDistance(
      userLocation.latitude,
      userLocation.longitude,
      valeterCoords.latitude,
      valeterCoords.longitude
    );

    // Average speed: 25 mph in city, estimate ETA in minutes
    const averageSpeed = 25; // mph
    const timeInHours = distance / averageSpeed;
    const timeInMinutes = Math.round(timeInHours * 60);
    
    setEta(timeInMinutes);
  };

  const subscribeToValeterPresence = (valeterId: string) => {
    // Remove existing subscription
    if (valeterPresenceChannelRef.current) {
      supabase.removeChannel(valeterPresenceChannelRef.current);
      valeterPresenceChannelRef.current = null;
    }

    const channel = supabase
      .channel(`valeter-presence-dashboard-${valeterId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${valeterId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          if (updated?.last_lat && updated?.last_lng) {
            const valeterCoords = {
              latitude: Number(updated.last_lat),
              longitude: Number(updated.last_lng),
            };
            setValeterLocation(valeterCoords);
            calculateETA(valeterCoords);
          }
        }
      )
      .subscribe();

    valeterPresenceChannelRef.current = channel;
  };

  const loadActiveBooking = async () => {
    if (!user?.id) return;

    try {
      setActiveBookingLoading(true);

      const { data, error } = await supabase
        .from('bookings')
        .select('id,status,service_type,service_name,location_address,scheduled_at,price,valeter_name,valeter_id')
        .eq('user_id', user.id)
        .in('status', ACTIVE_STATUSES as any)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        console.warn('[CustomerDashboard] loadActiveBooking error:', error);
        setActiveBooking(null);
        return;
      }

      if (!data) {
        setActiveBooking(null);
        setValeterLocation(null);
        setEta(null);
        return;
      }

      setActiveBooking({
        id: data.id,
        status: data.status as DbBookingStatus,
        service_type: data.service_type,
        service_name: data.service_name ?? null,
        location_address: data.location_address ?? null,
        scheduled_at: data.scheduled_at,
        price: Number(data.price ?? 0),
        valeter_name: data.valeter_name ?? null,
        valeter_id: data.valeter_id ?? null,
        latitude: null,
        longitude: null,
      });

      // Load valeter location if valeter_id exists
      if (data.valeter_id) {
        await loadValeterLocation(data.valeter_id);
        // Subscribe to valeter presence updates
        subscribeToValeterPresence(data.valeter_id);
      } else {
        // Unsubscribe if no valeter
        if (valeterPresenceChannelRef.current) {
          supabase.removeChannel(valeterPresenceChannelRef.current);
          valeterPresenceChannelRef.current = null;
        }
      }

      // Get user location for ETA calculation
      await getCurrentLocation();
    } catch (e) {
      console.warn('[CustomerDashboard] loadActiveBooking exception:', e);
      setActiveBooking(null);
    } finally {
      setActiveBookingLoading(false);
    }
  };

  const loadRecentBookings = async () => {
    if (!user?.id) return;

    try {
      setRecentBookingsLoading(true);

      const { data, error } = await supabase
        .from('bookings')
        .select('id,status,service_type,service_name,location_address,scheduled_at,price,valeter_name,valeter_id')
        .eq('user_id', user.id)
        .in('status', ['completed', 'cancelled'] as any)
        .order('created_at', { ascending: false })
        .limit(5);

      if (error) {
        console.warn('[CustomerDashboard] loadRecentBookings error:', error);
        setRecentBookings([]);
        return;
      }

      if (!data || data.length === 0) {
        setRecentBookings([]);
        return;
      }

      setRecentBookings(
        data.map((booking) => ({
          id: booking.id,
          status: booking.status as DbBookingStatus,
          service_type: booking.service_type,
          service_name: booking.service_name ?? null,
          location_address: booking.location_address ?? null,
          scheduled_at: booking.scheduled_at,
          price: Number(booking.price ?? 0),
          valeter_name: booking.valeter_name ?? null,
          valeter_id: booking.valeter_id ?? null,
          latitude: null,
          longitude: null,
        }))
      );
    } catch (e) {
      console.warn('[CustomerDashboard] loadRecentBookings exception:', e);
      setRecentBookings([]);
    } finally {
      setRecentBookingsLoading(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;

    loadActiveBooking();
    loadRecentBookings();

    const channel = supabase
      .channel(`customer-active-booking-${user.id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        () => {
          loadActiveBooking();
          loadRecentBookings();
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        (payload) => {
          const updated = payload.new as any;

          if (activeBooking?.id && updated?.id === activeBooking.id) {
            const newStatus = updated.status as DbBookingStatus;

            if (newStatus === 'completed' || newStatus === 'cancelled') {
              setActiveBooking(null);
              loadRecentBookings(); // Reload recent bookings when active booking completes
            } else {
              setActiveBooking((prev) =>
                prev
                  ? {
                      ...prev,
                      status: newStatus,
                      valeter_name: updated.valeter_name ?? prev.valeter_name,
                      price: Number(updated.price ?? prev.price),
                      service_name: updated.service_name ?? prev.service_name,
                      location_address: updated.location_address ?? prev.location_address,
                    }
                  : prev
              );
            }
            return;
          }

          loadActiveBooking();
          loadRecentBookings();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      if (valeterPresenceChannelRef.current) {
        supabase.removeChannel(valeterPresenceChannelRef.current);
        valeterPresenceChannelRef.current = null;
      }
    };
  }, [user?.id, activeBooking?.id]);

  // Notifications count (unchanged)
  useEffect(() => {
    if (!user?.id) return;
    let isMounted = true;
    const DISMISSED_STORAGE_KEY = 'wishawash:dismissed-notifications-v1';

    const fetchVehicleReminders = async (
      userId: string
    ): Promise<Array<{ id: string; type: 'vehicle_reminder' }>> => {
      try {
        const { data: vehicles, error } = await supabase
          .from('customer_vehicles')
          .select('id,make,model,registration,tax_expiry,mot_expiry')
          .eq('user_id', userId);

        if (error || !vehicles) return [];

        const reminders: Array<{ id: string; type: 'vehicle_reminder' }> = [];
        const now = new Date();
        const thirtyDaysFromNow = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);

        vehicles.forEach((vehicle) => {
          if (vehicle.tax_expiry) {
            const taxExpiry = new Date(vehicle.tax_expiry);
            if (taxExpiry <= thirtyDaysFromNow && taxExpiry >= now) {
              reminders.push({ id: `tax-reminder-${vehicle.id}`, type: 'vehicle_reminder' });
            }
          }
          if (vehicle.mot_expiry) {
            const motExpiry = new Date(vehicle.mot_expiry);
            if (motExpiry <= thirtyDaysFromNow && motExpiry >= now) {
              reminders.push({ id: `mot-reminder-${vehicle.id}`, type: 'vehicle_reminder' });
            }
          }
        });

        return reminders;
      } catch (error) {
        console.warn('[CustomerDashboard] Vehicle reminders error', error);
        return [];
      }
    };

    const fetchRewardNotifications = async (userId: string): Promise<Array<{ id: string; type: 'reward' }>> => {
      try {
        const { data: userData, error } = await supabase
          .from('users')
          .select('tier_points,tier')
          .eq('id', userId)
          .single();

        if (error || !userData) return [];

        const notifications: Array<{ id: string; type: 'reward' }> = [];
        const points = userData.tier_points || 0;
        const milestones = [500, 1000, 2000, 3000, 5000];
        const nextMilestone = milestones.find((m) => m > points);

        if (nextMilestone && points > 0) {
          const pointsNeeded = nextMilestone - points;
          if (pointsNeeded <= 100) {
            notifications.push({ id: `reward-milestone-${nextMilestone}`, type: 'reward' });
          }
        }

        return notifications;
      } catch (error) {
        console.warn('[CustomerDashboard] Reward notifications error', error);
        return [];
      }
    };

    const fetchNotificationCount = async () => {
      try {
        const [bookingsResult, vehicleReminders, rewardNotifications] = await Promise.all([
          supabase
            .from('bookings')
            .select(
              'id,status,service_name,service_type,price,created_at,updated_at,scheduled_at,time_slot,location_address,address,valeter_name'
            )
            .eq('user_id', user.id)
            .in('status', notificationStatuses as any)
            .order('created_at', { ascending: false })
            .limit(100),
          fetchVehicleReminders(user.id),
          fetchRewardNotifications(user.id),
        ]);

        if (!isMounted) return;

        const bookingNotifications: Array<{ id: string; type: 'booking' }> = [];
        if (!bookingsResult.error && bookingsResult.data) {
          bookingNotifications.push(
            ...bookingsResult.data.map((b) => ({
              id: `booking-${b.id}`,
              type: 'booking' as const,
            }))
          );
        }

        const allNotifications = [...bookingNotifications, ...vehicleReminders, ...rewardNotifications];

        try {
          const raw = await AsyncStorage.getItem(DISMISSED_STORAGE_KEY);
          const dismissedStore = raw ? JSON.parse(raw) : {};
          const dismissedIds = new Set(dismissedStore[user.id] || []);
          const visibleNotifications = allNotifications.filter((notif) => !dismissedIds.has(notif.id));
          setNotificationCount(visibleNotifications.length);
        } catch (storageError) {
          console.warn('[CustomerDashboard] Storage read error:', storageError);
          setNotificationCount(allNotifications.length);
        }
      } catch (error) {
        if (isMounted) {
          console.warn('[CustomerDashboard] Notification count exception:', error);
          setNotificationCount(0);
        }
      }
    };

    fetchNotificationCount();
    const interval = setInterval(fetchNotificationCount, 45000);
    return () => {
      isMounted = false;
      clearInterval(interval);
    };
  }, [user?.id, notificationStatuses]);

  // Load profile name
  useEffect(() => {
    if (!user?.id) return;
    const loadProfile = async () => {
      // Load profile name
      const { data: profileData } = await supabase
        .from('profiles')
        .select('full_name, profile_picture')
        .eq('id', user.id)
        .maybeSingle();
      
      if (profileData) {
        setProfileName(profileData.full_name || user.name || 'Customer');
        
        // Load profile picture
        if (profileData.profile_picture) {
          const cleanUrl = (url: string) => url?.trim().replace(/[?#].*$/, '') || '';
          const clean = cleanUrl(profileData.profile_picture);
          setProfilePicture(`${clean}?v=${Date.now()}`);
        } else {
          // Try to resolve from storage
          try {
            const folder = `users/${user.id}`;
            const { data: files } = await supabase.storage
              .from('uploads')
              .list(folder, { limit: 50 });
            
            if (files && files.length > 0) {
              const preferred = files.find((f: any) => 
                String(f?.name || '').toLowerCase().startsWith('profile_picture')
              ) || files[0];
              
              if (preferred?.name) {
                const path = `${folder}/${preferred.name}`;
                const { data: publicData } = supabase.storage.from('uploads').getPublicUrl(path);
                if (publicData?.publicUrl) {
                  setProfilePicture(`${publicData.publicUrl}?v=${Date.now()}`);
                }
              }
            }
          } catch (err) {
            console.warn('[Dashboard] Failed to load profile picture from storage:', err);
          }
        }
      } else {
        setProfileName(user.name || 'Customer');
      }
    };
    loadProfile();
  }, [user?.id]);

  const loadWeeklyStats = async () => {
    if (!user?.id) return;
    
    try {
      const now = new Date();
      const startOfWeek = new Date(now);
      startOfWeek.setDate(now.getDate() - now.getDay()); // Start of week (Sunday)
      startOfWeek.setHours(0, 0, 0, 0);
      
      // Get all completed bookings
      const { data: allBookings, error: allError } = await supabase
        .from('bookings')
        .select('id, status, completed_at, created_at')
        .eq('user_id', user.id)
        .eq('status', 'completed');
      
      if (allError) {
        console.warn('Error loading all bookings:', allError);
        return;
      }
      
      const totalWashes = allBookings?.length || 0;
      
      // Get bookings from this week
      const { data: weeklyBookings, error: weeklyError } = await supabase
        .from('bookings')
        .select('id, status, completed_at, created_at')
        .eq('user_id', user.id)
        .eq('status', 'completed')
        .gte('completed_at', startOfWeek.toISOString());
      
      if (weeklyError) {
        console.warn('Error loading weekly bookings:', weeklyError);
        return;
      }
      
      const washesThisWeek = weeklyBookings?.length || 0;
      
      setWeeklyStats({
        washesThisWeek,
        totalWashes,
      });
    } catch (error) {
      console.warn('Error loading weekly stats:', error);
    }
  };

  const loadNearbyValeters = async () => {
    if (!user?.id) return;
    try {
      const { data: presence, error: presErr } = await supabase.from('valeter_presence').select('user_id, is_online').eq('is_online', true);

      if (presErr) console.warn('[NearbyValeters] presence error:', presErr);
      if (!presence || presence.length === 0) {
        setNearbyValeters([]);
        return;
      }

      const ids = presence.map((p) => p.user_id);
      const { data: profiles } = await supabase.from('valeter_profiles').select('user_id, display_name, company_name').in('user_id', ids);

      const list: NearbyValeter[] = (presence || []).map((p) => {
        const profile = profiles?.find((pr) => pr.user_id === p.user_id);
        return {
          id: p.user_id,
          name: profile?.display_name || 'Valeter',
          organization: profile?.company_name || 'Independent',
          rating: 4.5,
          distance: null,
          isOnline: p.is_online,
        };
      });

      setNearbyValeters(list.slice(0, 8));
    } catch (e) {
      console.error('[NearbyValeters] load error:', e);
      setNearbyValeters([]);
    }
  };

  const loadCarWashCount = async () => {
    try {
      const { count, error } = await supabase
        .from('car_wash_locations')
        .select('*', { count: 'exact', head: true });

      if (error) {
        console.warn('[CarWashCount] error:', error);
        return;
      }

      setCarWashCount(count || 0);
    } catch (e) {
      console.error('[CarWashCount] load error:', e);
    }
  };

  const loadDetailingHubCount = async () => {
    try {
      // Check if there's a separate detailing_hubs table, or filter car_wash_locations by service_type
      const { count, error } = await supabase
        .from('car_wash_locations')
        .select('*', { count: 'exact', head: true })
        .or('service_types.cs.{detailing},service_type.eq.detailing');

      if (error) {
        // If that doesn't work, try a different approach - just count all for now
        const { count: allCount, error: allError } = await supabase
          .from('car_wash_locations')
          .select('*', { count: 'exact', head: true });
        
        if (allError) {
          console.warn('[DetailingHubCount] error:', allError);
          return;
        }
        
        // For now, estimate detailing hubs as a portion of total (you can refine this later)
        setDetailingHubCount(Math.floor((allCount || 0) * 0.3));
        return;
      }

      setDetailingHubCount(count || 0);
    } catch (e) {
      console.error('[DetailingHubCount] load error:', e);
    }
  };

  useEffect(() => {
    loadNearbyValeters();
    loadCarWashCount();
    loadDetailingHubCount();
    loadWeeklyStats();
    const interval = setInterval(() => {
      loadNearbyValeters();
      loadCarWashCount();
      loadDetailingHubCount();
      loadWeeklyStats();
    }, 30000);
    return () => clearInterval(interval);
  }, [user?.id]);

  useEffect(() => {
    if (user?.id) {
      const timer = setTimeout(() => setLoading(false), 500);
      return () => clearTimeout(timer);
    }
    return undefined;
  }, [user?.id]);

  const handleNotificationPress = () => {
    router.push('/owner/features/notifications');
  };

  const handleResumeTracking = () => {
    if (!activeBooking?.id) return;
    router.push({
      pathname: '/owner/booking/tracking',
      params: { bookingId: activeBooking.id },
    } as any);
  };

  const handleAttemptNewBooking = (route: string) => {
    if (!activeBooking?.id) {
      router.push(route as any);
      return;
    }

    Alert.alert(
      'Active booking in progress',
      'You already have an active booking. You can resume tracking it now.',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'View booking',
          onPress: handleResumeTracking,
        },
      ]
    );
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading...</Text>
        </View>
      </SafeAreaView>
    );
  }

  const onlineCount = nearbyValeters.filter((v) => v.isOnline).length;

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={customerTheme.backgroundColor} />
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="customer" />

      <AppHeader
        title={profileName || user?.name || 'Customer'}
        subtitle={
          new Date().getHours() < 12
            ? 'Good morning!'
            : new Date().getHours() < 17
              ? 'Good afternoon!'
              : 'Good evening!'
        }
        variant="dashboard"
        accountType="customer"
        showBack={false}
        scrollY={scrollY}
        enableScrollAnimation={true}
        rightAction={<GradientNotificationBell count={notificationCount} onPress={handleNotificationPress} />}
        profilePicture={profilePicture}
        onProfilePress={() => router.push('/owner/owner-profile')}
      />

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        contentContainerStyle={{
          paddingTop: DASHBOARD_HEADER_CONTENT_OFFSET,
          paddingBottom: 20,
        }}
        showsVerticalScrollIndicator={false}
      >
        {/* Booking Button with Quick Actions */}
        <View style={styles.bookingButtonsSection}>
          <TouchableOpacity
            style={[styles.bookingButton, styles.bookingButtonTall]}
            onPress={() => handleAttemptNewBooking('/owner/booking')}
            activeOpacity={0.9}
          >
            <LinearGradient colors={['rgba(135,206,235,0.55)', 'rgba(59,130,246,0.55)']} style={styles.bookingButtonGradientTall}>
              <View style={styles.bookingButtonIconWrap}>
                <Ionicons name="water" size={22} color={LIGHT_SKY} />
              </View>
              <View style={styles.bookingButtonTextWrap}>
                <Text style={styles.bookingButtonTitle}>Book a Wash</Text>
                <Text style={styles.bookingButtonSubtitle}>
                  {activeBooking ? 'Finish your active booking first' : 'Wash, valet & detailing services'}
                </Text>
              </View>
              <Ionicons name="chevron-forward" size={18} color="rgba(255,255,255,0.85)" />
            </LinearGradient>
          </TouchableOpacity>

          {/* Quick Actions - Horizontal Scroll */}
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.quickActionsScrollContent}
            style={styles.quickActionsScroll}
          >
            <TouchableOpacity
              style={styles.quickActionItem}
              onPress={() => router.push('/owner/settings/vehicle-management')}
              activeOpacity={0.85}
            >
              <View style={[styles.quickActionIconBox, { backgroundColor: '#3B82F6' }]}>
                <Ionicons name="car-sport" size={20} color="#FFFFFF" />
              </View>
              <Text style={styles.quickActionItemLabel}>Vehicles</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickActionItem}
              onPress={() => router.push('/owner/features/rewards')}
              activeOpacity={0.85}
            >
              <View style={[styles.quickActionIconBox, { backgroundColor: '#10B981' }]}>
                <Ionicons name="trophy" size={20} color="#FFFFFF" />
              </View>
              <Text style={styles.quickActionItemLabel}>Rewards</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickActionItem}
              onPress={() => router.push('/owner/features/referral-system')}
              activeOpacity={0.85}
            >
              <View style={[styles.quickActionIconBox, { backgroundColor: '#8B5CF6' }]}>
                <Ionicons name="people-circle" size={20} color="#FFFFFF" />
              </View>
              <Text style={styles.quickActionItemLabel}>Referrals</Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={styles.quickActionItem}
              onPress={() => setShowCarCareHub(true)}
              activeOpacity={0.85}
            >
              <View style={[styles.quickActionIconBox, { backgroundColor: '#F59E0B' }]}>
                <Ionicons name="information-circle" size={20} color="#FFFFFF" />
              </View>
              <Text style={styles.quickActionItemLabel}>Car Care</Text>
            </TouchableOpacity>
          </ScrollView>
        </View>

        {/* Weekly Stats */}
        <View style={styles.statsSection}>
          <View style={styles.statsCard}>
            <View style={styles.statItem}>
              <View style={styles.statIconWrapper}>
                <Ionicons name="water" size={20} color={SKY} />
              </View>
              <View style={styles.statContent}>
                <Text style={styles.statValue}>{weeklyStats.washesThisWeek}</Text>
                <Text style={styles.statLabel}>This Week</Text>
              </View>
            </View>
            <View style={styles.statDivider} />
            <View style={styles.statItem}>
              <View style={styles.statIconWrapper}>
                <Ionicons name="checkmark-circle" size={20} color={SKY} />
              </View>
              <View style={styles.statContent}>
                <Text style={styles.statValue}>{weeklyStats.totalWashes}</Text>
                <Text style={styles.statLabel}>Total Washes</Text>
              </View>
            </View>
          </View>
        </View>

        {/* Active Booking Card (bigger) */}
        {activeBookingLoading ? (
          <View style={styles.activeBookingSection}>
            <View style={styles.activeBookingSkeleton}>
              <ActivityIndicator size="small" color={SKY} />
              <Text style={styles.activeBookingLoadingText}>Checking active booking…</Text>
            </View>
          </View>
        ) : activeBooking ? (
          <View style={styles.activeBookingSection}>
            <TouchableOpacity activeOpacity={0.9} onPress={handleResumeTracking} style={styles.activeBookingCard}>
              <LinearGradient colors={['rgba(135,206,235,0.24)', 'rgba(30,58,138,0.3)']} style={styles.activeBookingGradient}>
                <View style={styles.activeBookingTopRow}>
                  <View style={styles.activeBookingIconWrap}>
                    <Ionicons name="radio" size={22} color={SKY} />
                  </View>

                  <View style={{ flex: 1 }}>
                    <Text style={styles.activeBookingTitle}>Active booking</Text>
                    <Text style={styles.activeBookingSubtitle} numberOfLines={1}>
                      {getServiceDisplayName(activeBooking.service_type, activeBooking.service_name)}
                    </Text>
                    {!!activeBooking.valeter_name && (
                      <Text style={styles.activeBookingValeter} numberOfLines={1}>
                        {activeBooking.service_type?.includes('detailing') ? 'Detailer' : 'Valeter'}: {activeBooking.valeter_name}
                      </Text>
                    )}
                  </View>

                  <View style={styles.activeBookingStatusPill}>
                    <Ionicons
                      name={activeBooking.status === 'in_progress' ? 'play' : 'time'}
                      size={12}
                      color="#0A1929"
                    />
                    <Text style={styles.activeBookingStatusText}>
                      {activeBooking.status === 'in_progress' ? 'In progress' : 'Scheduled'}
                    </Text>
                  </View>
                </View>

                {/* Map View */}
                {valeterLocation && userLocation && (
                  <View style={styles.activeBookingMapContainer}>
                    <MapView
                      style={styles.activeBookingMap}
                      region={{
                        latitude: (valeterLocation.latitude + userLocation.latitude) / 2,
                        longitude: (valeterLocation.longitude + userLocation.longitude) / 2,
                        latitudeDelta: Math.abs(valeterLocation.latitude - userLocation.latitude) * 2.5 || 0.01,
                        longitudeDelta: Math.abs(valeterLocation.longitude - userLocation.longitude) * 2.5 || 0.01,
                      }}
                      scrollEnabled={false}
                      zoomEnabled={false}
                      pitchEnabled={false}
                      rotateEnabled={false}
                    >
                      {/* User location marker */}
                      <Marker coordinate={userLocation}>
                        <View style={styles.mapMarkerContainer}>
                          <Image 
                            source={require('../../../assets/washing.png')} 
                            style={styles.mapMarkerImage}
                            resizeMode="contain"
                          />
                        </View>
                      </Marker>
                      
                      {/* Valeter location marker */}
                      <Marker coordinate={valeterLocation}>
                        <View style={styles.mapMarkerContainer}>
                          <Image 
                            source={
                              activeBooking.service_type?.includes('detailing')
                                ? require('../../../assets/detailing.png')
                                : require('../../../assets/cleaning.png')
                            } 
                            style={styles.mapMarkerImage}
                            resizeMode="contain"
                          />
                        </View>
                      </Marker>
                    </MapView>
                    
                    {/* ETA overlay */}
                    {eta !== null && (
                      <View style={styles.etaOverlay}>
                        <Ionicons name="time" size={14} color={SKY} />
                        <Text style={styles.etaText}>ETA: {eta} min</Text>
                      </View>
                    )}
                  </View>
                )}

                {!!activeBooking.location_address && (
                  <View style={styles.activeBookingMetaRow}>
                    <Ionicons name="location-outline" size={15} color={LIGHT_SKY} />
                    <Text style={styles.activeBookingMetaText} numberOfLines={1}>
                      {activeBooking.location_address}
                    </Text>
                  </View>
                )}

                <View style={styles.activeBookingBottomRow}>
                  <View style={styles.activeBookingPriceWrap}>
                    <Ionicons name="wallet-outline" size={15} color={LIGHT_SKY} />
                    <Text style={styles.activeBookingPrice}>£{Number(activeBooking.price || 0).toFixed(2)}</Text>
                  </View>

                  <View style={styles.activeBookingCta}>
                    <Text style={styles.activeBookingMetaCta}>Resume tracking</Text>
                    <Ionicons name="chevron-forward" size={18} color={SKY} />
                  </View>
                </View>
              </LinearGradient>
            </TouchableOpacity>
          </View>
        ) : null}

        {/* Recent Bookings Section */}
        {recentBookings.length > 0 && (
          <View style={styles.recentBookingsSection}>
            <View style={styles.recentBookingsHeader}>
              <View style={styles.recentBookingsHeaderLeft}>
                <View style={styles.recentBookingsIconWrapper}>
                  <Ionicons name="time-outline" size={18} color={SKY} />
                </View>
                <View>
                  <Text style={styles.recentBookingsTitle}>Recent Bookings</Text>
                  <Text style={styles.recentBookingsSubtitle}>
                    {recentBookings.length} booking{recentBookings.length !== 1 ? 's' : ''}
                  </Text>
                </View>
              </View>
              <TouchableOpacity
                onPress={() => router.push('/owner/wash-history')}
                activeOpacity={0.7}
              >
                <Text style={styles.recentBookingsViewAll}>View all</Text>
              </TouchableOpacity>
            </View>

            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.recentBookingsScrollContent}
            >
              {recentBookings.map((booking) => (
                <TouchableOpacity
                  key={booking.id}
                  style={styles.recentBookingCard}
                  activeOpacity={0.9}
                  onPress={() => router.push(`/owner/wash-history?highlightId=${booking.id}`)}
                >
                  <View style={styles.recentBookingCardContent}>
                    <View style={styles.recentBookingTopRow}>
                      <View style={styles.recentBookingIconWrap}>
                        <Ionicons
                          name={booking.status === 'completed' ? 'checkmark-circle' : 'close-circle'}
                          size={18}
                          color={booking.status === 'completed' ? '#10B981' : '#EF4444'}
                        />
                      </View>
                      <View style={styles.recentBookingInfo}>
                        <Text style={styles.recentBookingService} numberOfLines={1}>
                          {getServiceDisplayName(booking.service_type, booking.service_name)}
                        </Text>
                        <Text style={styles.recentBookingStatus} numberOfLines={1}>
                          {booking.status === 'completed' ? 'Completed' : 'Cancelled'}
                        </Text>
                      </View>
                    </View>
                    {booking.location_address && (
                      <View style={styles.recentBookingLocation}>
                        <Ionicons name="location-outline" size={12} color="rgba(255,255,255,0.6)" />
                        <Text style={styles.recentBookingLocationText} numberOfLines={1}>
                          {booking.location_address}
                        </Text>
                      </View>
                    )}
                    <View style={styles.recentBookingBottomRow}>
                      <Text style={styles.recentBookingPrice}>£{Number(booking.price || 0).toFixed(2)}</Text>
                      {booking.scheduled_at && (
                        <Text style={styles.recentBookingDate}>
                          {new Date(booking.scheduled_at).toLocaleDateString('en-GB', {
                            day: 'numeric',
                            month: 'short',
                          })}
                        </Text>
                      )}
                    </View>
                  </View>
                </TouchableOpacity>
              ))}
            </ScrollView>
          </View>
        )}

        {/* Live Availability - Redesigned & Positioned at Bottom */}
        <View style={styles.availabilitySectionBottom}>
          {/* Header */}
          <View style={styles.availabilityHeaderBottom}>
            <View style={styles.availabilityHeaderLeftBottom}>
              <View style={styles.availabilityIconWrapper}>
                <Ionicons name="location" size={20} color={SKY} />
              </View>
              <View>
                <Text style={styles.availabilityTitleBottom}>Pros Nearby</Text>
                <Text style={styles.availabilitySubtitleBottom}>
                  {nearbyValeters.length} valeter{nearbyValeters.length !== 1 ? 's' : ''} • {carWashCount} wash hub{carWashCount !== 1 ? 's' : ''}
                </Text>
              </View>
            </View>
          </View>

          {/* Pros Nearby - Horizontal Scroll */}
          {nearbyValeters.length > 0 ? (
            <View style={styles.prosNearbyContainer}>
              <ScrollView
                horizontal
                showsHorizontalScrollIndicator={false}
                contentContainerStyle={styles.prosNearbyScrollContent}
              >
                {nearbyValeters.map((valeter) => (
                  <View key={valeter.id} style={styles.proCard}>
                    <View style={styles.proCardHeader}>
                      <View style={styles.proAvatar}>
                        <Ionicons name="person" size={20} color={SKY} />
                      </View>
                      {valeter.isOnline && (
                        <View style={styles.proOnlineBadge}>
                          <View style={styles.proOnlineDot} />
                        </View>
                      )}
                    </View>
                    <Text style={styles.proName} numberOfLines={1}>
                      {valeter.name}
                    </Text>
                    <Text style={styles.proOrganization} numberOfLines={1}>
                      {valeter.organization}
                    </Text>
                    <View style={styles.proRating}>
                      <Ionicons name="star" size={12} color="#FBBF24" />
                      <Text style={styles.proRatingText}>{valeter.rating.toFixed(1)}</Text>
                    </View>
                  </View>
                ))}
              </ScrollView>
            </View>
          ) : (
            <View style={styles.prosEmptyState}>
              <Text style={styles.prosEmptyText}>No pros available nearby</Text>
            </View>
          )}

          {/* ETA for Active Booking */}
          {activeBooking && eta !== null && (
            <View style={styles.availabilityETARow}>
              <View style={styles.etaCard}>
                <Ionicons name="time" size={18} color={SKY} />
                <View style={styles.etaContent}>
                  <Text style={styles.etaLabel}>Estimated Arrival</Text>
                  <Text style={styles.etaValue}>{eta} min</Text>
                </View>
              </View>
            </View>
          )}
        </View>

        {/* Powered By */}

      </Animated.ScrollView>

      <Modal visible={showCarCareHub} animationType="slide" presentationStyle="fullScreen">
        <CarCareInfoHub userType="customer" onClose={() => setShowCarCareHub(false)} />
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  loadingContainer: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: customerTheme.backgroundColor },
  loadingText: { color: LIGHT_SKY, fontSize: 16 },
  scrollView: { flex: 1 },

  bookingButtonsSection: {
    flexDirection: 'column',
    gap: 12,
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginTop: -8,
    marginBottom: 14,
  },
  bookingButton: {
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
  },
  bookingButtonTall: {
    minHeight: 76,
  },
  bookingButtonGradientTall: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingVertical: 18,
    paddingHorizontal: 16,
    gap: 12,
  },
  bookingButtonIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.18)',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.25)',
  },
  bookingButtonTextWrap: {
    flex: 1,
    gap: 2,
  },
  bookingButtonTitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  bookingButtonSubtitle: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 12,
    fontWeight: '600',
  },
  quickActionsScroll: {
    marginTop: 12,
  },
  quickActionsScrollContent: {
    gap: 12,
    paddingRight: 4,
  },
  quickActionItem: {
    alignItems: 'center',
    gap: 8,
    minWidth: 70,
    opacity: 0.95,
  },
  quickActionIconBox: {
    width: 56,
    height: 56,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 4,
    opacity: 0.9,
  },
  quickActionItemLabel: {
    color: '#F9FAFB',
    fontSize: 12,
    fontWeight: '600',
    textAlign: 'center',
  },

  /* Active Booking (bigger + more prominent) */
  activeBookingSection: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 18,
  },
  activeBookingSkeleton: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.28)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    padding: 18,
    alignItems: 'center',
  },
  activeBookingCard: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1.8,
    borderColor: 'rgba(135,206,235,0.38)',
    backgroundColor: 'rgba(255,255,255,0.04)',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.28,
    shadowRadius: 10,
  },
  activeBookingGradient: {
    padding: 18,
  },
  activeBookingLoadingText: {
    color: LIGHT_SKY,
    fontSize: 13,
    fontWeight: '600',
    marginTop: 10,
    textAlign: 'center',
  },
  activeBookingTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  activeBookingIconWrap: {
    width: 50,
    height: 50,
    borderRadius: 16,
    backgroundColor: 'rgba(135,206,235,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.38)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  activeBookingTitle: {
    color: LIGHT_SKY,
    fontSize: 15,
    fontWeight: '900',
    letterSpacing: 0.2,
    marginBottom: 3,
  },
  activeBookingSubtitle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 13,
    fontWeight: '700',
  },
  activeBookingValeter: {
    color: 'rgba(255,255,255,0.78)',
    fontSize: 12,
    fontWeight: '600',
    marginTop: 4,
  },
  activeBookingStatusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 999,
    backgroundColor: SKY,
  },
  activeBookingStatusText: {
    color: '#0A1929',
    fontSize: 11,
    fontWeight: '900',
  },
  activeBookingMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginTop: 6,
  },
  activeBookingMetaText: {
    color: 'rgba(255,255,255,0.88)',
    fontSize: 12,
    fontWeight: '650',
    flex: 1,
  },
  activeBookingBottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: 14,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.18)',
  },
  activeBookingPriceWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  activeBookingPrice: {
    color: LIGHT_SKY,
    fontSize: 13,
    fontWeight: '900',
  },
  activeBookingCta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  activeBookingMetaCta: {
    color: SKY,
    fontSize: 13,
    fontWeight: '900',
  },
  activeBookingMapContainer: {
    height: 180,
    borderRadius: 12,
    overflow: 'hidden',
    marginTop: 12,
    marginBottom: 8,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    position: 'relative',
  },
  activeBookingMap: {
    width: '100%',
    height: '100%',
  },
  mapMarkerContainer: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapMarkerImage: {
    width: 36,
    height: 36,
  },
  etaOverlay: {
    position: 'absolute',
    top: 12,
    right: 12,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(0,0,0,0.7)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  etaText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '800',
  },

  /* Recent Bookings Section */
  recentBookingsSection: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 18,
  },
  recentBookingsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  recentBookingsHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  recentBookingsIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  recentBookingsTitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 16 : 18,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  recentBookingsSubtitle: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  recentBookingsViewAll: {
    color: SKY,
    fontSize: 13,
    fontWeight: '700',
  },
  recentBookingsScrollContent: {
    gap: 12,
    paddingRight: 4,
  },
  recentBookingCard: {
    width: 200,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(255,255,255,0.06)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 4,
  },
  recentBookingCardContent: {
    padding: 14,
    gap: 10,
  },
  recentBookingTopRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  recentBookingIconWrap: {
    marginTop: 2,
  },
  recentBookingInfo: {
    flex: 1,
    gap: 4,
  },
  recentBookingService: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
  },
  recentBookingStatus: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 11,
    fontWeight: '600',
  },
  recentBookingLocation: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  recentBookingLocationText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 11,
    fontWeight: '500',
    flex: 1,
  },
  recentBookingBottomRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingTop: 8,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.15)',
  },
  recentBookingPrice: {
    color: LIGHT_SKY,
    fontSize: 15,
    fontWeight: '800',
  },
  recentBookingDate: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 11,
    fontWeight: '600',
  },

  /* Car Care Hub - Bottom Positioned */
  carCareHubSection: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 24,
    marginTop: 8,
  },
  carCareHubCard: {
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.28,
    shadowRadius: 10,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.35)',
  },
  carCareHubGradient: {
    padding: 20,
  },
  carCareHubHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    marginBottom: 16,
  },
  carCareHubIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  carCareHubTextContainer: {
    flex: 1,
    gap: 4,
  },
  carCareHubTitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  carCareHubSubtitle: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 13,
    fontWeight: '600',
  },
  carCareHubFeatures: {
    flexDirection: 'row',
    gap: 12,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  carCareHubFeature: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  carCareHubFeatureText: {
    color: LIGHT_SKY,
    fontSize: 11,
    fontWeight: '700',
  },

  /* Availability - New Design */
  availabilitySection: { 
    marginBottom: 20,
    marginHorizontal: isSmallScreen ? 12 : 20,
  },
  availabilityHeaderRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
  },
  availabilityHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  availabilitySectionTitle: {
    color: LIGHT_SKY,
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  liveIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 5,
    borderRadius: 12,
    backgroundColor: 'rgba(239,68,68,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(239,68,68,0.3)',
  },
  liveDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#EF4444',
  },
  liveText: {
    color: '#EF4444',
    fontSize: 10,
    fontWeight: '900',
    letterSpacing: 0.5,
  },
  availabilityCardNew: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.25,
    shadowRadius: 8,
  },
  availabilityGradientNew: { 
    padding: 20,
  },
  availabilityMainDisplay: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 20,
    marginBottom: 16,
  },
  availabilityCountCircle: {
    width: 90,
    height: 90,
    borderRadius: 45,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1.5,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 2,
  },
  availabilityCountNumber: {
    color: LIGHT_SKY,
    fontSize: 32,
    fontWeight: '900',
    lineHeight: 36,
  },
  availabilityCountLabel: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 11,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  availabilityCountNumberSmall: {
    color: LIGHT_SKY,
    fontSize: 24,
    fontWeight: '900',
    lineHeight: 28,
    marginTop: 4,
  },
  availabilityCountLabelSmall: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 10,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  availabilityQuickInfo: {
    flex: 1,
    gap: 10,
  },
  quickInfoItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  quickInfoText: {
    color: LIGHT_SKY,
    fontSize: 13,
    fontWeight: '700',
  },
  availabilityStatusBar: {
    height: 6,
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderRadius: 3,
    overflow: 'hidden',
    marginBottom: 12,
  },
  statusBarFill: {
    height: '100%',
    borderRadius: 3,
  },
  qualityIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
  },
  qualityText: {
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.3,
  },

  poweredBySection: {
    alignItems: 'center',
    paddingVertical: 24,
    paddingHorizontal: isSmallScreen ? 12 : 20,
    marginTop: 8,
  },
  poweredByText: {
    color: LIGHT_SKY,
    fontSize: 12,
    opacity: 0.8,
    fontWeight: '600',
  },
  /* Live Availability - Bottom Redesigned */
  availabilitySectionBottom: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 24,
    marginTop: 8,
  },
  availabilityCardBottom: {
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    backgroundColor: 'rgba(255,255,255,0.05)',
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
  },
  availabilityGradientBottom: {
    padding: 24,
  },
  availabilityHeaderBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  availabilityHeaderLeftBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  availabilityIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  availabilityTitleBottom: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: 0.3,
    marginBottom: 2,
  },
  availabilitySubtitleBottom: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  liveIndicatorBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: 'rgba(239,68,68,0.2)',
    borderWidth: 1.5,
    borderColor: 'rgba(239,68,68,0.4)',
  },
  liveDotBottom: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#EF4444',
  },
  liveTextBottom: {
    color: '#EF4444',
    fontSize: 11,
    fontWeight: '900',
    letterSpacing: 0.8,
  },
  availabilityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    marginBottom: 12,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.15)',
  },
  availabilityRowIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  availabilityRowContent: {
    flex: 1,
  },
  availabilityRowLabel: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 4,
  },
  availabilityRowValue: {
    color: SKY,
    fontSize: 18,
    fontWeight: '800',
  },
  prosNearbyContainer: {
    marginTop: 12,
    marginBottom: 8,
  },
  prosNearbyScrollContent: {
    paddingHorizontal: 4,
    gap: 12,
  },
  proCard: {
    width: 140,
    padding: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    marginRight: 12,
  },
  proCardHeader: {
    position: 'relative',
    marginBottom: 10,
  },
  proAvatar: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 2,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },
  proOnlineBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#0A1929',
    borderWidth: 2,
    borderColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
  },
  proOnlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  proName: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 4,
  },
  proOrganization: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 11,
    marginBottom: 8,
  },
  proRating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  proRatingText: {
    color: '#FBBF24',
    fontSize: 12,
    fontWeight: '700',
  },
  prosEmptyState: {
    padding: 20,
    alignItems: 'center',
    marginTop: 12,
  },
  prosEmptyText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 13,
    fontWeight: '600',
  },
  statIconWrapper: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  statNumber: {
    color: LIGHT_SKY,
    fontSize: 32,
    fontWeight: '900',
    lineHeight: 38,
    marginBottom: 4,
  },
  statLabel: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 13,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 8,
  },
  statBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  statBadgeText: {
    color: '#10B981',
    fontSize: 11,
    fontWeight: '700',
  },
  availabilityStatDivider: {
    width: 1,
    height: 80,
    backgroundColor: 'rgba(135,206,235,0.2)',
  },
  availabilityQuickInfoBottom: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 20,
  },
  quickInfoCard: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 14,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.15)',
  },
  quickInfoContent: {
    flex: 1,
    gap: 2,
  },
  quickInfoLabel: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 11,
    fontWeight: '600',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  quickInfoValue: {
    color: LIGHT_SKY,
    fontSize: 15,
    fontWeight: '800',
  },
  availabilityQualityBar: {
    gap: 10,
  },
  qualityBarBackground: {
    height: 8,
    backgroundColor: 'rgba(0,0,0,0.25)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  qualityBarFill: {
    height: '100%',
    borderRadius: 4,
  },
  qualityIndicatorBottom: {
    alignItems: 'flex-start',
  },
  qualityBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
  },
  qualityDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  qualityTextBottom: {
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  /* Detailing Hub Count - Purple Styled */
  availabilityStatCardPurple: {
    alignItems: 'center',
    padding: 16,
    borderRadius: 18,
    backgroundColor: 'rgba(139,92,246,0.1)',
    borderWidth: 1.5,
    borderColor: 'rgba(139,92,246,0.3)',
    marginTop: 12,
  },
  statIconWrapperPurple: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(139,92,246,0.15)',
    borderWidth: 2,
    borderColor: PREMIUM_PURPLE,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  statNumberPurple: {
    color: PREMIUM_PURPLE,
    fontSize: 32,
    fontWeight: '900',
    lineHeight: 38,
    marginBottom: 4,
  },
  statLabelPurple: {
    color: 'rgba(255,255,255,0.85)',
    fontSize: 13,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 8,
  },
  statBadgePurple: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
    backgroundColor: 'rgba(139,92,246,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
  },
  statBadgeTextPurple: {
    color: PREMIUM_PURPLE,
    fontSize: 11,
    fontWeight: '700',
  },
  availabilityETARow: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  statsSection: {
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 18,
  },
  statsCard: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 16,
    padding: 16,
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 4,
  },
  statItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  statIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  statContent: {
    flex: 1,
  },
  statValue: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 2,
  },
  statLabel: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 12,
    fontWeight: '600',
  },
  statDivider: {
    width: 1,
    height: 40,
    backgroundColor: 'rgba(135,206,235,0.2)',
    marginHorizontal: 12,
  },
  etaCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    padding: 12,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  etaContent: {
    flex: 1,
  },
  etaLabel: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 2,
  },
  etaValue: {
    color: SKY,
    fontSize: 18,
    fontWeight: '800',
  },
});
