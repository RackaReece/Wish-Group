import React, { useEffect, useState, useRef } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

interface CountdownTimerProps {
  seconds: number;
  onComplete?: () => void;
  size?: 'small' | 'medium' | 'large';
  showIcon?: boolean;
}

export default function CountdownTimer({ 
  seconds, 
  onComplete, 
  size = 'medium',
  showIcon = true 
}: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState(seconds);
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    if (timeLeft <= 0) {
      onComplete?.();
      return;
    }

    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          onComplete?.();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    // Pulse animation on each second
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 1.1,
        duration: 200,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start();

    return () => clearInterval(timer);
  }, [timeLeft]);

  useEffect(() => {
    // Continuous pulse animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.05,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const fontSize = size === 'small' ? 24 : size === 'medium' ? 32 : 48;
  const iconSize = size === 'small' ? 16 : size === 'medium' ? 20 : 28;

  return (
    <Animated.View style={[styles.container, { transform: [{ scale: pulseAnim }] }]}>
      <BlurView intensity={60} tint="dark" style={styles.blurContainer}>
        <LinearGradient
          colors={['rgba(15, 23, 42, 0.75)', 'rgba(15, 23, 42, 0.85)']}
          style={StyleSheet.absoluteFill}
        />
        <View style={[styles.border, { borderColor: 'rgba(96,165,250,0.3)' }]} />
        <View style={styles.content}>
          {showIcon && (
            <Ionicons name="time-outline" size={iconSize} color="#60A5FA" style={styles.icon} />
          )}
          <Animated.Text 
            style={[
              styles.timeText, 
              { 
                fontSize,
                transform: [{ scale: scaleAnim }]
              }
            ]}
          >
            {formatTime(timeLeft)}
          </Animated.Text>
        </View>
      </BlurView>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  blurContainer: {
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    paddingHorizontal: 24,
    paddingVertical: 16,
    minWidth: 140,
    elevation: 8,
    shadowColor: '#60A5FA',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
  },
  border: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 24,
    borderWidth: 1,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  icon: {
    marginRight: 4,
  },
  timeText: {
    color: '#F9FAFB',
    fontWeight: 'bold',
    fontVariant: ['tabular-nums'],
  },
});

