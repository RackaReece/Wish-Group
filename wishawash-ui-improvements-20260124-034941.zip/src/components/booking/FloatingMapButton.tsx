import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../constants/colors';

const SKY = colors.SKY;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;

interface FloatingMapButtonProps {
  title: string;
  onPress: () => void;
  disabled?: boolean;
  icon?: keyof typeof Ionicons.glyphMap;
  variant?: 'primary' | 'secondary' | 'premium';
  style?: ViewStyle;
  textStyle?: TextStyle;
}

export default function FloatingMapButton({
  title,
  onPress,
  disabled = false,
  icon,
  variant = 'primary',
  style,
  textStyle,
}: FloatingMapButtonProps) {
  const insets = useSafeAreaInsets();

  const getVariantColors = () => {
    switch (variant) {
      case 'premium':
        return [PREMIUM_PURPLE, '#7C3AED'];
      case 'secondary':
        return [SKY + '80', SKY + '60'];
      default:
        return [SKY, '#0EA5E9'];
    }
  };

  return (
    <View
      style={[
        styles.container,
        {
          paddingBottom: Math.max(insets.bottom, 14) + 8,
        },
        style,
      ]}
      pointerEvents="box-none"
    >
      <TouchableOpacity
        onPress={onPress}
        disabled={disabled}
        activeOpacity={0.85}
        style={[styles.button, disabled && styles.buttonDisabled]}
      >
        <BlurView intensity={20} tint="dark" style={styles.blurContainer}>
          <LinearGradient
            colors={disabled ? ['rgba(255,255,255,0.1)', 'rgba(255,255,255,0.05)'] : getVariantColors()}
            style={styles.gradient}
          >
            {icon && (
              <Ionicons
                name={icon}
                size={20}
                color={disabled ? 'rgba(255,255,255,0.5)' : '#FFFFFF'}
                style={styles.icon}
              />
            )}
            <Text
              style={[
                styles.text,
                disabled && styles.textDisabled,
                textStyle,
              ]}
            >
              {title}
            </Text>
          </LinearGradient>
        </BlurView>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 20,
    alignItems: 'center',
    zIndex: 1000,
  },
  button: {
    width: '100%',
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 12,
  },
  buttonDisabled: {
    opacity: 0.5,
  },
  blurContainer: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  gradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 24,
    gap: 8,
  },
  icon: {
    marginRight: 4,
  },
  text: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  textDisabled: {
    opacity: 0.6,
  },
});
