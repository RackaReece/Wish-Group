import React from 'react';
import { View, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { AccountType, getAccountTheme } from '../../constants/accountThemes';
import { useAccountTheme } from '../shared/AccountThemeProvider';

interface GlassCardProps {
  children: React.ReactNode;
  onPress?: () => void;
  style?: ViewStyle;
  intensity?: number;
  tint?: 'light' | 'dark' | 'default';
  borderColor?: string;
  accountType?: AccountType;
}

export default function GlassCard({ 
  children, 
  onPress, 
  style, 
  intensity = 40,
  tint = 'dark',
  borderColor,
  accountType
}: GlassCardProps) {
  // Use account theme if provided, otherwise try to get from context, otherwise default to customer
  const contextTheme = useAccountTheme();
  const theme = accountType 
    ? getAccountTheme(accountType)
    : contextTheme.theme;
  
  const finalBorderColor = borderColor || theme.glassBorder;

  const content = (
    <BlurView intensity={intensity} tint={tint} style={[styles.blurContainer, style]}>
      <LinearGradient
        colors={['rgba(255,255,255,0.06)', 'rgba(255,255,255,0.03)', 'rgba(255,255,255,0.02)']}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
      />
      <View style={[styles.border, { borderColor: finalBorderColor }]} />
      {/* Subtle inner highlight */}
      <View style={styles.innerHighlight} />
      {children}
    </BlurView>
  );

  if (onPress) {
    return (
      <TouchableOpacity activeOpacity={0.8} onPress={onPress}>
        {content}
      </TouchableOpacity>
    );
  }

  return content;
}

const styles = StyleSheet.create({
  blurContainer: {
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
  },
  border: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 24,
    borderWidth: 1,
  },
  innerHighlight: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 24,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.08)',
    pointerEvents: 'none',
  },
});

