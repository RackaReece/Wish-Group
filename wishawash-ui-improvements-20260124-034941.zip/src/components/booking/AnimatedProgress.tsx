import React, { useEffect, useRef, useState } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../../constants/colors';

const SKY = colors.SKY;

interface AnimatedProgressProps {
  progress: number; // 0-100
  size?: number;
  strokeWidth?: number;
  showPercentage?: boolean;
  color?: string;
}

export default function AnimatedProgress({ 
  progress, 
  size = 120, 
  strokeWidth = 8,
  showPercentage = true,
  color = SKY
}: AnimatedProgressProps) {
  const animatedProgress = useRef(new Animated.Value(0)).current;
  const [displayProgress, setDisplayProgress] = useState(0);
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.spring(animatedProgress, {
        toValue: progress,
        useNativeDriver: false,
        tension: 50,
        friction: 7,
      }),
      Animated.sequence([
        Animated.timing(scaleAnim, {
          toValue: 1.05,
          duration: 300,
          useNativeDriver: true,
        }),
        Animated.timing(scaleAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]),
    ]).start();

    const listener = animatedProgress.addListener(({ value }) => {
      setDisplayProgress(Math.round(value));
    });
    
    return () => {
      animatedProgress.removeListener(listener);
    };
  }, [progress]);

  useEffect(() => {
    // Subtle pulse animation
    Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.02,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  const progressWidth = animatedProgress.interpolate({
    inputRange: [0, 100],
    outputRange: ['0%', '100%'],
  });

  return (
    <Animated.View
      style={[
        styles.container,
        {
          width: size,
          height: size,
          transform: [{ scale: pulseAnim }],
        },
      ]}
    >
      {/* Outer ring with gradient */}
      <LinearGradient
        colors={[color + '40', color + '20']}
        style={[
          styles.outerRing,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
            borderWidth: strokeWidth,
          },
        ]}
      />

      {/* Progress fill ring */}
      <View
        style={[
          styles.progressRing,
          {
            width: size,
            height: size,
            borderRadius: size / 2,
            borderWidth: strokeWidth,
            borderColor: 'rgba(135,206,235,0.2)',
          },
        ]}
      >
        <Animated.View
          style={[
            styles.progressFill,
            {
              width: progressWidth,
              height: '100%',
              backgroundColor: color,
              opacity: 0.6,
            },
          ]}
        />
      </View>

      {/* Center circle with content */}
      <Animated.View
        style={[
          styles.centerCircle,
          {
            width: size - strokeWidth * 4,
            height: size - strokeWidth * 4,
            borderRadius: (size - strokeWidth * 4) / 2,
            transform: [{ scale: scaleAnim }],
          },
        ]}
      >
        <LinearGradient
          colors={['rgba(10,25,41,0.95)', 'rgba(10,25,41,0.98)']}
          style={StyleSheet.absoluteFill}
        />
        {showPercentage && (
          <View style={styles.percentageContainer}>
            <Text style={styles.percentageText}>{displayProgress}</Text>
            <Text style={styles.percentSymbol}>%</Text>
          </View>
        )}
      </Animated.View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  outerRing: {
    position: 'absolute',
    borderColor: SKY,
  },
  progressRing: {
    position: 'absolute',
    overflow: 'hidden',
  },
  progressFill: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    borderRadius: 60,
  },
  centerCircle: {
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
    zIndex: 1,
  },
  percentageContainer: {
    flexDirection: 'row',
    alignItems: 'baseline',
  },
  percentageText: {
    color: '#F9FAFB',
    fontSize: 24,
    fontWeight: 'bold',
  },
  percentSymbol: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
    marginLeft: 2,
  },
});
