import React, { useEffect, useRef } from 'react';
import { View, Text, StyleSheet, Animated, Dimensions } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

const { width, height } = Dimensions.get('window');

interface SuccessOverlayProps {
  visible: boolean;
  type?: 'payment' | 'accepted' | 'completed';
  message?: string;
  onComplete?: () => void;
}

export default function SuccessOverlay({ 
  visible, 
  type = 'payment',
  message,
  onComplete 
}: SuccessOverlayProps) {
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const scaleAnim = useRef(new Animated.Value(0.8)).current;
  const confettiAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    if (visible) {
      // Main animation
      Animated.parallel([
        Animated.spring(scaleAnim, {
          toValue: 1,
          tension: 50,
          friction: 7,
          useNativeDriver: true,
        }),
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 300,
          useNativeDriver: true,
        }),
      ]).start();

      // Confetti animation for payment/completed
      if (type === 'payment' || type === 'completed') {
        Animated.timing(confettiAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }).start();
      }

      // Auto dismiss after 2 seconds
      const timer = setTimeout(() => {
        Animated.parallel([
          Animated.timing(fadeAnim, {
            toValue: 0,
            duration: 300,
            useNativeDriver: true,
          }),
          Animated.timing(scaleAnim, {
            toValue: 0.8,
            duration: 300,
            useNativeDriver: true,
          }),
        ]).start(() => {
          onComplete?.();
        });
      }, 2000);

      return () => clearTimeout(timer);
    }
  }, [visible]);

  if (!visible) return null;

  const getIcon = () => {
    switch (type) {
      case 'payment':
        return 'checkmark-circle';
      case 'accepted':
        return 'checkmark-done-circle';
      case 'completed':
        return 'checkmark-done-circle';
      default:
        return 'checkmark-circle';
    }
  };

  const getColor = () => {
    switch (type) {
      case 'payment':
        return '#10B981';
      case 'accepted':
        return '#10B981';
      case 'completed':
        return '#10B981';
      default:
        return '#10B981';
    }
  };

  const getDefaultMessage = () => {
    switch (type) {
      case 'payment':
        return 'Payment Successful!';
      case 'accepted':
        return 'Booking Accepted!';
      case 'completed':
        return 'Service Completed!';
      default:
        return 'Success!';
    }
  };

  return (
    <Animated.View 
      style={[
        styles.overlay,
        {
          opacity: fadeAnim,
        }
      ]}
      pointerEvents="none"
    >
      <BlurView intensity={80} tint="dark" style={StyleSheet.absoluteFill} />
      
      {/* Confetti effect for payment/completed */}
      {(type === 'payment' || type === 'completed') && (
        <Animated.View 
          style={[
            styles.confettiContainer,
            {
              opacity: confettiAnim,
            }
          ]}
        >
          {[...Array(20)].map((_, i) => (
            <Animated.View
              key={i}
              style={[
                styles.confetti,
                {
                  left: `${(i * 5) % 100}%`,
                  top: `${(i * 10) % 100}%`,
                  backgroundColor: ['#10B981', '#60A5FA', '#FBBF24', '#EF4444', '#A855F7'][i % 5],
                  transform: [
                    {
                      rotate: confettiAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: ['0deg', `${360 * (i % 2 === 0 ? 1 : -1)}deg`],
                      }),
                    },
                    {
                      translateY: confettiAnim.interpolate({
                        inputRange: [0, 1],
                        outputRange: [0, height],
                      }),
                    },
                  ],
                },
              ]}
            />
          ))}
        </Animated.View>
      )}

      {/* Success content */}
      <Animated.View
        style={[
          styles.content,
          {
            transform: [{ scale: scaleAnim }],
          },
        ]}
      >
        <View style={[styles.iconContainer, { backgroundColor: getColor() + '20' }]}>
          <Ionicons name={getIcon()} size={64} color={getColor()} />
        </View>
        <Text style={styles.message}>{message || getDefaultMessage()}</Text>
      </Animated.View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  overlay: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 9999,
    justifyContent: 'center',
    alignItems: 'center',
  },
  confettiContainer: {
    ...StyleSheet.absoluteFillObject,
  },
  confetti: {
    position: 'absolute',
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  content: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  iconContainer: {
    width: 120,
    height: 120,
    borderRadius: 60,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 24,
    borderWidth: 2,
    borderColor: '#10B981',
  },
  message: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: '800',
    textAlign: 'center',
  },
});
