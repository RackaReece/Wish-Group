import React, { useRef, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  PanResponder,
  Dimensions,
  TouchableOpacity,
  ScrollView,
  ViewStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';

const { height: SCREEN_HEIGHT } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;

export type BottomSheetState = 'collapsed' | 'half' | 'full';

interface UberBottomSheetProps {
  children: React.ReactNode;
  state?: BottomSheetState;
  onStateChange?: (state: BottomSheetState) => void;
  collapsedHeight?: number; // ~15% of screen
  halfHeight?: number; // ~40-50% of screen
  fullHeight?: number; // ~75-85% of screen
  showHandle?: boolean;
  enablePan?: boolean;
  previewContent?: React.ReactNode; // Shows at top when collapsed/half
  footerButton?: React.ReactNode; // Floating button inside sheet
  style?: ViewStyle;
}

const DEFAULT_COLLAPSED = SCREEN_HEIGHT * 0.15;
const DEFAULT_HALF = SCREEN_HEIGHT * 0.5;
const DEFAULT_FULL = SCREEN_HEIGHT * 0.8;

export default function UberBottomSheet({
  children,
  state: controlledState,
  onStateChange,
  collapsedHeight = DEFAULT_COLLAPSED,
  halfHeight = DEFAULT_HALF,
  fullHeight = DEFAULT_FULL,
  showHandle = true,
  enablePan = true,
  previewContent,
  footerButton,
  style,
}: UberBottomSheetProps) {
  const insets = useSafeAreaInsets();
  const [internalState, setInternalState] = useState<BottomSheetState>('half');
  const panY = useRef(new Animated.Value(halfHeight)).current;
  const lastPanY = useRef(halfHeight);

  const currentState = controlledState || internalState;

  const getHeightForState = (s: BottomSheetState): number => {
    switch (s) {
      case 'collapsed':
        return collapsedHeight;
      case 'half':
        return halfHeight;
      case 'full':
        return fullHeight;
    }
  };

  const setState = (newState: BottomSheetState) => {
    if (controlledState === undefined) {
      setInternalState(newState);
    }
    onStateChange?.(newState);
    
    const targetHeight = getHeightForState(newState);
    Animated.spring(panY, {
      toValue: targetHeight,
      useNativeDriver: false,
      tension: 50,
      friction: 8,
    }).start();
    lastPanY.current = targetHeight;
  };

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => enablePan,
      onMoveShouldSetPanResponder: () => enablePan,
      onPanResponderGrant: () => {
        panY.setOffset(lastPanY.current);
        panY.setValue(0);
      },
      onPanResponderMove: (_, gestureState) => {
        const newY = lastPanY.current + gestureState.dy;
        // Clamp between collapsed and full
        const clampedY = Math.max(
          collapsedHeight,
          Math.min(fullHeight, newY)
        );
        panY.setValue(clampedY - lastPanY.current);
      },
      onPanResponderRelease: (_, gestureState) => {
        panY.flattenOffset();
        const currentY = lastPanY.current + gestureState.dy;
        const velocity = gestureState.vy;

        // Determine target state based on position and velocity
        let targetState: BottomSheetState;
        
        if (Math.abs(velocity) > 0.5) {
          // Fast swipe - go to next/previous state
          if (velocity > 0) {
            // Swiping down
            if (currentState === 'full') {
              targetState = 'half';
            } else {
              targetState = 'collapsed';
            }
          } else {
            // Swiping up
            if (currentState === 'collapsed') {
              targetState = 'half';
            } else {
              targetState = 'full';
            }
          }
        } else {
          // Slow drag - snap to nearest state
          const midCollapsedHalf = (collapsedHeight + halfHeight) / 2;
          const midHalfFull = (halfHeight + fullHeight) / 2;

          if (currentY < midCollapsedHalf) {
            targetState = 'collapsed';
          } else if (currentY < midHalfFull) {
            targetState = 'half';
          } else {
            targetState = 'full';
          }
        }

        setState(targetState);
      },
    })
  ).current;

  useEffect(() => {
    if (controlledState !== undefined) {
      const targetHeight = getHeightForState(controlledState);
      Animated.spring(panY, {
        toValue: targetHeight,
        useNativeDriver: false,
        tension: 50,
        friction: 8,
      }).start();
      lastPanY.current = targetHeight;
    }
  }, [controlledState]);

  const handleToggle = () => {
    if (currentState === 'collapsed') {
      setState('half');
    } else if (currentState === 'half') {
      setState('full');
    } else {
      setState('half');
    }
  };

  const sheetHeight = panY.interpolate({
    inputRange: [collapsedHeight, fullHeight],
    outputRange: [collapsedHeight, fullHeight],
    extrapolate: 'clamp',
  });

  const isCollapsed = currentState === 'collapsed';
  const isHalf = currentState === 'half';
  const showPreview = (isCollapsed || isHalf) && previewContent;

  const translateY = Animated.subtract(SCREEN_HEIGHT, sheetHeight);

  return (
    <Animated.View
      style={[
        styles.container,
        {
          height: sheetHeight,
          transform: [{ translateY }],
        },
        style,
      ]}
      {...panResponder.panHandlers}
    >
      {/* Edge fade gradient at top */}
      <LinearGradient
        colors={['rgba(15, 23, 42, 0.95)', 'rgba(15, 23, 42, 0.85)', 'rgba(15, 23, 42, 0.7)', 'transparent']}
        style={styles.topGradient}
        pointerEvents="none"
      />

      {/* Blur background */}
      <BlurView intensity={20} tint="dark" style={StyleSheet.absoluteFill}>
        <LinearGradient
          colors={['rgba(15, 23, 42, 0.92)', 'rgba(15, 23, 42, 0.88)']}
          style={StyleSheet.absoluteFill}
        />
      </BlurView>

      {/* Content */}
      <View style={styles.content}>
        {/* Handle */}
        {showHandle && (
          <TouchableOpacity
            onPress={handleToggle}
            style={styles.handleContainer}
            activeOpacity={0.7}
          >
            <View style={styles.handle} />
          </TouchableOpacity>
        )}

        {/* Preview content (shown when collapsed/half) */}
        {showPreview && (
          <View style={styles.previewContainer}>
            {previewContent}
          </View>
        )}

        {/* Main content */}
        <ScrollView
          style={styles.scrollContent}
          contentContainerStyle={[
            styles.scrollContentInner,
            { paddingBottom: insets.bottom + (footerButton ? 80 : 20) },
          ]}
          showsVerticalScrollIndicator={false}
        >
          {children}
        </ScrollView>

        {/* Footer button */}
        {footerButton && (
          <View style={[styles.footerContainer, { paddingBottom: insets.bottom + 8 }]}>
            {footerButton}
          </View>
        )}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 16,
  },
  topGradient: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 40,
    zIndex: 1,
  },
  content: {
    flex: 1,
  },
  handleContainer: {
    alignItems: 'center',
    paddingVertical: 12,
    zIndex: 2,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  previewContainer: {
    paddingHorizontal: 20,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  scrollContent: {
    flex: 1,
  },
  scrollContentInner: {
    paddingHorizontal: 20,
    paddingTop: 8,
  },
  footerContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 20,
    paddingTop: 12,
    backgroundColor: 'rgba(15, 23, 42, 0.95)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
});
