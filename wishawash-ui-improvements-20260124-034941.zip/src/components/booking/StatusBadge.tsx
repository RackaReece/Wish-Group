import React, { useMemo } from 'react';
import { View, Text, StyleSheet, StyleProp, ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors as appColors } from '../../constants/colors'; // adjust path if needed

type StatusBadgeSize = 'small' | 'medium' | 'large';

type AnyStatus =
  // DB / schema statuses
  | 'scheduled'
  | 'in_progress'
  | 'completed'
  | 'cancelled'
  // older / UI statuses you’ve used in screens
  | 'pending_payment'
  | 'confirmed'
  | 'valeter_assigned'
  | 'en_route'
  | 'arrived'
  | 'rejected'
  | 'unknown'
  // allow unexpected values from DB without crashing
  | string;

type BadgeConfig = {
  label: string;
  colors: string[];
  borderColor: string;
  icon: keyof typeof Ionicons.glyphMap;
};

const SKY = appColors?.SKY ?? '#38BDF8';

const STATUS_CONFIG: Record<string, BadgeConfig> = {
  // ✅ DB schema aligned
  scheduled: {
    label: 'Scheduled',
    colors: ['rgba(56,189,248,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(56,189,248,0.45)',
    icon: 'calendar-outline',
  },
  in_progress: {
    label: 'In Progress',
    colors: ['rgba(245,158,11,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(245,158,11,0.55)',
    icon: 'construct-outline',
  },
  completed: {
    label: 'Completed',
    colors: ['rgba(16,185,129,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(16,185,129,0.55)',
    icon: 'checkmark-circle-outline',
  },
  cancelled: {
    label: 'Cancelled',
    colors: ['rgba(239,68,68,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(239,68,68,0.55)',
    icon: 'close-circle-outline',
  },

  // ✅ older flow statuses (keep for both apps)
  pending_payment: {
    label: 'Pending Payment',
    colors: ['rgba(56,189,248,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(56,189,248,0.45)',
    icon: 'card-outline',
  },
  confirmed: {
    label: 'Confirmed',
    colors: ['rgba(56,189,248,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(56,189,248,0.45)',
    icon: 'checkmark-outline',
  },
  valeter_assigned: {
    label: 'Valeter Assigned',
    colors: ['rgba(99,102,241,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(99,102,241,0.55)',
    icon: 'person-outline',
  },
  en_route: {
    label: 'En Route',
    colors: ['rgba(245,158,11,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(245,158,11,0.55)',
    icon: 'navigate-outline',
  },
  arrived: {
    label: 'Arrived',
    colors: ['rgba(34,197,94,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(34,197,94,0.55)',
    icon: 'pin-outline',
  },
  rejected: {
    label: 'Rejected',
    colors: ['rgba(239,68,68,0.35)', 'rgba(30,58,138,0.15)'],
    borderColor: 'rgba(239,68,68,0.55)',
    icon: 'alert-circle-outline',
  },
};

const FALLBACK_CONFIG: BadgeConfig = {
  label: 'Status',
  colors: ['rgba(56,189,248,0.25)', 'rgba(30,58,138,0.10)'],
  borderColor: 'rgba(56,189,248,0.35)',
  icon: 'information-circle-outline',
};

export default function StatusBadge({
  status,
  size = 'small',
  style,
}: {
  status: AnyStatus;
  size?: StatusBadgeSize;
  style?: StyleProp<ViewStyle>;
}) {
  const config = useMemo(() => {
    const key = String(status ?? '').toLowerCase();
    return STATUS_CONFIG[key] ?? {
      ...FALLBACK_CONFIG,
      label: key ? key.replace(/_/g, ' ') : FALLBACK_CONFIG.label,
    };
  }, [status]);

  const padding = size === 'large' ? 14 : size === 'medium' ? 10 : 8;
  const fontSize = size === 'large' ? 14 : size === 'medium' ? 13 : 12;
  const iconSize = size === 'large' ? 16 : size === 'medium' ? 15 : 14;

  return (
    <BlurView
      intensity={30}
      tint="dark"
      style={[
        styles.container,
        { paddingHorizontal: padding, paddingVertical: padding / 2 },
        style,
      ]}
    >
      <LinearGradient colors={config.colors} style={StyleSheet.absoluteFill} />
      <View style={[styles.border, { borderColor: config.borderColor }]} />

      <View style={styles.row}>
        <Ionicons name={config.icon} size={iconSize} color={SKY} />
        <Text style={[styles.text, { fontSize }]} numberOfLines={1}>
          {config.label}
        </Text>
      </View>
    </BlurView>
  );
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 999,
    overflow: 'hidden',
    alignSelf: 'flex-start',
  },
  border: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1,
    borderRadius: 999,
  },
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  text: {
    color: '#F9FAFB',
    fontWeight: '700',
    letterSpacing: 0.2,
  },
});
