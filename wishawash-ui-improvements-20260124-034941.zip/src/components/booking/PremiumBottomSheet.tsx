import React, { useRef, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  PanResponder,
  Dimensions,
  TouchableOpacity,
  ScrollView,
  ViewStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';

const { height: SCREEN_HEIGHT, width: SCREEN_WIDTH } = Dimensions.get('window');
const SKY = colors.SKY;

export type BottomSheetState = 'collapsed' | 'half' | 'full';

interface PremiumBottomSheetProps {
  children: React.ReactNode;
  state?: BottomSheetState;
  onStateChange?: (state: BottomSheetState) => void;
  collapsedHeight?: number;
  halfHeight?: number;
  fullHeight?: number;
  showHandle?: boolean;
  enablePan?: boolean;
  title?: string;
  subtitle?: string;
  footerButton?: React.ReactNode;
  showCloseButton?: boolean;
  onClose?: () => void;
  style?: ViewStyle;
  mapVisible?: boolean; // Whether map should stay 70% visible
}

const DEFAULT_COLLAPSED = SCREEN_HEIGHT * 0.15;
const DEFAULT_HALF = SCREEN_HEIGHT * 0.5;
const DEFAULT_FULL = SCREEN_HEIGHT * 0.8;

export default function PremiumBottomSheet({
  children,
  state: controlledState,
  onStateChange,
  collapsedHeight = DEFAULT_COLLAPSED,
  halfHeight = DEFAULT_HALF,
  fullHeight = DEFAULT_FULL,
  showHandle = true,
  enablePan = true,
  title,
  subtitle,
  footerButton,
  showCloseButton = false,
  onClose,
  style,
  mapVisible = true,
}: PremiumBottomSheetProps) {
  const insets = useSafeAreaInsets();
  const [internalState, setInternalState] = useState<BottomSheetState>('half');
  const panY = useRef(new Animated.Value(halfHeight)).current;
  const lastPanY = useRef(halfHeight);
  const opacityAnim = useRef(new Animated.Value(1)).current;

  const currentState = controlledState || internalState;

  const getHeightForState = (s: BottomSheetState): number => {
    switch (s) {
      case 'collapsed':
        return collapsedHeight;
      case 'half':
        return mapVisible ? SCREEN_HEIGHT * 0.3 : halfHeight;
      case 'full':
        return fullHeight;
    }
  };

  const setState = (newState: BottomSheetState) => {
    if (controlledState === undefined) {
      setInternalState(newState);
    }
    onStateChange?.(newState);
    
    const targetHeight = getHeightForState(newState);
    Animated.parallel([
      Animated.spring(panY, {
        toValue: targetHeight,
        useNativeDriver: false,
        tension: 50,
        friction: 8,
      }),
      Animated.timing(opacityAnim, {
        toValue: newState === 'full' ? 0.95 : 1,
        duration: 300,
        useNativeDriver: true,
      }),
    ]).start();
    lastPanY.current = targetHeight;
  };

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => enablePan,
      onMoveShouldSetPanResponder: () => enablePan,
      onPanResponderGrant: () => {
        panY.setOffset(lastPanY.current);
        panY.setValue(0);
      },
      onPanResponderMove: (_, gestureState) => {
        const newY = lastPanY.current + gestureState.dy;
        const clampedY = Math.max(
          collapsedHeight,
          Math.min(fullHeight, newY)
        );
        panY.setValue(clampedY - lastPanY.current);
      },
      onPanResponderRelease: (_, gestureState) => {
        panY.flattenOffset();
        const currentY = lastPanY.current + gestureState.dy;
        const velocity = gestureState.vy;

        let targetState: BottomSheetState;
        
        if (Math.abs(velocity) > 0.5) {
          if (velocity > 0) {
            if (currentState === 'full') {
              targetState = 'half';
            } else {
              targetState = 'collapsed';
            }
          } else {
            if (currentState === 'collapsed') {
              targetState = 'half';
            } else {
              targetState = 'full';
            }
          }
        } else {
          const midCollapsedHalf = (collapsedHeight + getHeightForState('half')) / 2;
          const midHalfFull = (getHeightForState('half') + fullHeight) / 2;

          if (currentY < midCollapsedHalf) {
            targetState = 'collapsed';
          } else if (currentY < midHalfFull) {
            targetState = 'half';
          } else {
            targetState = 'full';
          }
        }

        setState(targetState);
      },
    })
  ).current;

  useEffect(() => {
    if (controlledState !== undefined) {
      const targetHeight = getHeightForState(controlledState);
      Animated.spring(panY, {
        toValue: targetHeight,
        useNativeDriver: false,
        tension: 50,
        friction: 8,
      }).start();
      lastPanY.current = targetHeight;
    }
  }, [controlledState]);

  const sheetHeight = panY.interpolate({
    inputRange: [collapsedHeight, fullHeight],
    outputRange: [collapsedHeight, fullHeight],
    extrapolate: 'clamp',
  });

  const translateY = Animated.subtract(SCREEN_HEIGHT, sheetHeight);

  return (
    <Animated.View
      style={[
        styles.container,
        {
          height: sheetHeight,
          transform: [{ translateY }],
          opacity: opacityAnim,
        },
        style,
      ]}
      {...panResponder.panHandlers}
    >
      {/* Top gradient fade */}
      <LinearGradient
        colors={['rgba(15, 23, 42, 0.98)', 'rgba(15, 23, 42, 0.95)', 'rgba(15, 23, 42, 0.85)', 'transparent']}
        style={styles.topGradient}
        pointerEvents="none"
      />

      {/* Blur background */}
      <BlurView intensity={25} tint="dark" style={StyleSheet.absoluteFill}>
        <LinearGradient
          colors={['rgba(15, 23, 42, 0.95)', 'rgba(15, 23, 42, 0.92)']}
          style={StyleSheet.absoluteFill}
        />
      </BlurView>

      {/* Content */}
      <View style={styles.content}>
        {/* Handle */}
        {showHandle && (
          <TouchableOpacity
            onPress={() => {
              if (currentState === 'half') setState('full');
              else if (currentState === 'full') setState('half');
              else setState('half');
            }}
            style={styles.handleContainer}
            activeOpacity={0.7}
          >
            <View style={styles.handle} />
          </TouchableOpacity>
        )}

        {/* Header */}
        {(title || subtitle || showCloseButton) && (
          <View style={styles.header}>
            <View style={styles.headerText}>
              {title && <Text style={styles.title}>{title}</Text>}
              {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
            </View>
            {showCloseButton && onClose && (
              <TouchableOpacity onPress={onClose} style={styles.closeButton}>
                <Ionicons name="close" size={24} color="#F9FAFB" />
              </TouchableOpacity>
            )}
          </View>
        )}

        {/* Main content */}
        <ScrollView
          style={styles.scrollContent}
          contentContainerStyle={[
            styles.scrollContentInner,
            { paddingBottom: insets.bottom + (footerButton ? 90 : 24) },
          ]}
          showsVerticalScrollIndicator={false}
        >
          {children}
        </ScrollView>

        {/* Footer button */}
        {footerButton && (
          <View style={[styles.footerContainer, { paddingBottom: insets.bottom + 12 }]}>
            {footerButton}
          </View>
        )}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -6 },
    shadowOpacity: 0.4,
    shadowRadius: 20,
    elevation: 20,
  },
  topGradient: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 50,
    zIndex: 1,
  },
  content: {
    flex: 1,
  },
  handleContainer: {
    alignItems: 'center',
    paddingVertical: 12,
    zIndex: 2,
  },
  handle: {
    width: 48,
    height: 5,
    borderRadius: 3,
    backgroundColor: 'rgba(255, 255, 255, 0.4)',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  headerText: {
    flex: 1,
  },
  title: {
    fontSize: 24,
    fontWeight: '900',
    color: '#F9FAFB',
    letterSpacing: -0.5,
    marginBottom: 4,
  },
  subtitle: {
    fontSize: 15,
    fontWeight: '600',
    color: 'rgba(249, 250, 251, 0.7)',
  },
  closeButton: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  scrollContent: {
    flex: 1,
  },
  scrollContentInner: {
    paddingHorizontal: 20,
    paddingTop: 8,
  },
  footerContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 20,
    paddingTop: 16,
    backgroundColor: 'rgba(15, 23, 42, 0.98)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
});
