import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ViewStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import * as Haptics from 'expo-haptics';

const SKY = colors.SKY;

export type WashTier = 'Bronze' | 'Silver' | 'Gold';

interface WashTierCardProps {
  tier: WashTier;
  duration: string;
  price: string;
  perks: string[];
  selected?: boolean;
  onPress?: () => void;
  style?: ViewStyle;
}

const TIER_COLORS: Record<WashTier, { primary: string; secondary: string; icon: string }> = {
  Bronze: {
    primary: '#CD7F32',
    secondary: 'rgba(205, 127, 50, 0.2)',
    icon: 'medal',
  },
  Silver: {
    primary: '#C0C0C0',
    secondary: 'rgba(192, 192, 192, 0.2)',
    icon: 'star',
  },
  Gold: {
    primary: '#FFD700',
    secondary: 'rgba(255, 215, 0, 0.2)',
    icon: 'diamond',
  },
};

export default function WashTierCard({
  tier,
  duration,
  price,
  perks,
  selected = false,
  onPress,
  style,
}: WashTierCardProps) {
  const tierColors = TIER_COLORS[tier];

  const handlePress = () => {
    if (onPress) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      onPress();
    }
  };

  return (
    <TouchableOpacity
      onPress={handlePress}
      activeOpacity={0.8}
      style={[styles.container, selected && styles.selected, style]}
    >
      <BlurView intensity={selected ? 30 : 20} tint="dark" style={styles.blur}>
        <LinearGradient
          colors={
            selected
              ? ['rgba(255,255,255,0.12)', 'rgba(255,255,255,0.06)']
              : ['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']
          }
          style={StyleSheet.absoluteFill}
        />
        <View
          style={[
            styles.border,
            {
              borderColor: selected
                ? `${tierColors.primary}60`
                : 'rgba(255, 255, 255, 0.1)',
            },
          ]}
        />

        <View style={styles.header}>
          <View style={[styles.iconContainer, { backgroundColor: tierColors.secondary }]}>
            <Ionicons name={tierColors.icon as any} size={24} color={tierColors.primary} />
          </View>
          <View style={styles.headerText}>
            <Text style={styles.tierName}>{tier}</Text>
            <Text style={styles.duration}>{duration}</Text>
          </View>
          <View style={styles.priceContainer}>
            <Text style={styles.priceFrom}>from</Text>
            <Text style={[styles.price, { color: tierColors.primary }]}>{price}</Text>
          </View>
        </View>

        <View style={styles.perksContainer}>
          {perks.map((perk, index) => (
            <View key={index} style={styles.perk}>
              <Ionicons name="checkmark-circle" size={16} color={tierColors.primary} />
              <Text style={styles.perkText}>{perk}</Text>
            </View>
          ))}
        </View>

        {selected && (
          <View style={[styles.selectedBadge, { backgroundColor: tierColors.secondary }]}>
            <Ionicons name="checkmark" size={16} color={tierColors.primary} />
            <Text style={[styles.selectedText, { color: tierColors.primary }]}>Selected</Text>
          </View>
        )}
      </BlurView>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 12,
    borderRadius: 20,
    overflow: 'hidden',
  },
  selected: {
    transform: [{ scale: 1.02 }],
  },
  blur: {
    borderRadius: 20,
    overflow: 'hidden',
    padding: 16,
  },
  border: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1.5,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  iconContainer: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  headerText: {
    flex: 1,
  },
  tierName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
    marginBottom: 2,
  },
  duration: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
  },
  priceContainer: {
    alignItems: 'flex-end',
  },
  priceFrom: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '500',
    marginBottom: 2,
  },
  price: {
    fontSize: 20,
    fontWeight: '800',
  },
  perksContainer: {
    marginTop: 8,
  },
  perk: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
  },
  perkText: {
    color: '#E2E8F0',
    fontSize: 13,
    fontWeight: '500',
    marginLeft: 8,
  },
  selectedBadge: {
    position: 'absolute',
    top: 12,
    right: 12,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  selectedText: {
    fontSize: 11,
    fontWeight: '700',
    marginLeft: 4,
  },
});
