import React from 'react';
import {
  TouchableOpacity,
  Text,
  StyleSheet,
  ViewStyle,
  TextStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { colors } from '../../constants/colors';
import * as Haptics from 'expo-haptics';

const SKY = colors.SKY;

interface WWSecondaryButtonProps {
  title: string;
  onPress: () => void;
  disabled?: boolean;
  style?: ViewStyle;
  textStyle?: TextStyle;
  icon?: string;
}

export default function WWSecondaryButton({
  title,
  onPress,
  disabled = false,
  style,
  textStyle,
  icon,
}: WWSecondaryButtonProps) {
  const handlePress = () => {
    if (!disabled) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      onPress();
    }
  };

  return (
    <TouchableOpacity
      onPress={handlePress}
      disabled={disabled}
      activeOpacity={0.7}
      style={[styles.container, disabled && styles.disabled, style]}
    >
      <BlurView intensity={20} tint="dark" style={styles.blur}>
        <Text style={[styles.text, textStyle]}>
          {icon && `${icon} `}
          {title}
        </Text>
      </BlurView>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 56,
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1.5,
    borderColor: `${SKY}40`,
  },
  blur: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
  },
  text: {
    color: SKY,
    fontSize: 16,
    fontWeight: '600',
    letterSpacing: 0.3,
  },
  disabled: {
    opacity: 0.5,
  },
});
