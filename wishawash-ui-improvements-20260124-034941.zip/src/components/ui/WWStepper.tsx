import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ViewStyle,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';

const SKY = colors.SKY;

export type StepperStatus = 'completed' | 'active' | 'pending';

interface StepperStep {
  label: string;
  status: StepperStatus;
}

interface WWStepperProps {
  steps: StepperStep[];
  style?: ViewStyle;
}

export default function WWStepper({ steps, style }: WWStepperProps) {
  return (
    <View style={[styles.container, style]}>
      {steps.map((step, index) => {
        const isLast = index === steps.length - 1;
        const isCompleted = step.status === 'completed';
        const isActive = step.status === 'active';

        return (
          <View key={index} style={styles.stepContainer}>
            <View style={styles.stepContent}>
              {/* Step Circle */}
              <View
                style={[
                  styles.stepCircle,
                  isCompleted && styles.stepCircleCompleted,
                  isActive && styles.stepCircleActive,
                ]}
              >
                {isCompleted ? (
                  <Ionicons name="checkmark" size={16} color="#F9FAFB" />
                ) : isActive ? (
                  <View style={styles.activeDot} />
                ) : (
                  <View style={styles.pendingDot} />
                )}
              </View>

              {/* Step Label */}
              <Text
                style={[
                  styles.stepLabel,
                  isActive && styles.stepLabelActive,
                  isCompleted && styles.stepLabelCompleted,
                ]}
              >
                {step.label}
              </Text>
            </View>

            {/* Connector Line */}
            {!isLast && (
              <View
                style={[
                  styles.connector,
                  (isCompleted || isActive) && styles.connectorActive,
                ]}
              />
            )}
          </View>
        );
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingVertical: 16,
  },
  stepContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  stepContent: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  stepCircle: {
    width: 32,
    height: 32,
    borderRadius: 16,
    backgroundColor: 'rgba(148, 163, 184, 0.2)',
    borderWidth: 2,
    borderColor: '#94A3B8',
    alignItems: 'center',
    justifyContent: 'center',
  },
  stepCircleCompleted: {
    backgroundColor: SKY,
    borderColor: SKY,
  },
  stepCircleActive: {
    backgroundColor: `${SKY}20`,
    borderColor: SKY,
    borderWidth: 3,
  },
  activeDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: SKY,
  },
  pendingDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#94A3B8',
  },
  stepLabel: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '500',
    marginLeft: 12,
    flex: 1,
  },
  stepLabelActive: {
    color: '#F9FAFB',
    fontWeight: '600',
  },
  stepLabelCompleted: {
    color: '#E2E8F0',
  },
  connector: {
    position: 'absolute',
    left: 15,
    top: 32,
    width: 2,
    height: 24,
    backgroundColor: 'rgba(148, 163, 184, 0.3)',
  },
  connectorActive: {
    backgroundColor: SKY,
  },
});
