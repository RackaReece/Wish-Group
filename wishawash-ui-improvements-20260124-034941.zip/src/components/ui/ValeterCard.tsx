import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Image,
  ViewStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import WWChip from './WWChip';
import * as Haptics from 'expo-haptics';

const SKY = colors.SKY;

interface ValeterCardProps {
  name: string;
  rating: number;
  reviewCount: number;
  eta: string;
  distance: string;
  jobsCompleted: number;
  profileImage?: string;
  isCertified?: boolean;
  selected?: boolean;
  onPress?: () => void;
  style?: ViewStyle;
}

export default function ValeterCard({
  name,
  rating,
  reviewCount,
  eta,
  distance,
  jobsCompleted,
  profileImage,
  isCertified = false,
  selected = false,
  onPress,
  style,
}: ValeterCardProps) {
  const handlePress = () => {
    if (onPress) {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
      onPress();
    }
  };

  return (
    <TouchableOpacity
      onPress={handlePress}
      activeOpacity={0.8}
      style={[styles.container, selected && styles.selected, style]}
    >
      <BlurView intensity={selected ? 30 : 20} tint="dark" style={styles.blur}>
        <LinearGradient
          colors={
            selected
              ? ['rgba(135,206,235,0.15)', 'rgba(135,206,235,0.08)']
              : ['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']
          }
          style={StyleSheet.absoluteFill}
        />
        <View
          style={[
            styles.border,
            {
              borderColor: selected
                ? `${SKY}60`
                : 'rgba(255, 255, 255, 0.1)',
            },
          ]}
        />

        <View style={styles.content}>
          <View style={styles.profileSection}>
            {profileImage ? (
              <Image source={{ uri: profileImage }} style={styles.avatar} />
            ) : (
              <View style={styles.avatarPlaceholder}>
                <Ionicons name="person" size={24} color={SKY} />
              </View>
            )}
            {isCertified && (
              <View style={styles.certifiedBadge}>
                <Ionicons name="shield-checkmark" size={12} color="#8B5CF6" />
              </View>
            )}
          </View>

          <View style={styles.infoSection}>
            <View style={styles.nameRow}>
              <Text style={styles.name}>{name}</Text>
              {isCertified && (
                <WWChip label="Wish Certified" variant="certified" style={styles.chip} />
              )}
            </View>

            <View style={styles.ratingRow}>
              <Ionicons name="star" size={14} color="#FCD34D" />
              <Text style={styles.rating}>{rating.toFixed(1)}</Text>
              <Text style={styles.reviewCount}>({reviewCount})</Text>
              <Text style={styles.jobsCount}>• {jobsCompleted} jobs</Text>
            </View>
          </View>

          <View style={styles.etaSection}>
            <Text style={styles.etaValue}>{eta}</Text>
            <Text style={styles.etaLabel}>ETA</Text>
            <Text style={styles.distance}>{distance}</Text>
          </View>
        </View>

        {selected && (
          <View style={styles.selectedIndicator}>
            <Ionicons name="checkmark-circle" size={20} color={SKY} />
          </View>
        )}
      </BlurView>
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: {
    marginBottom: 12,
    borderRadius: 20,
    overflow: 'hidden',
  },
  selected: {
    transform: [{ scale: 1.02 }],
  },
  blur: {
    borderRadius: 20,
    overflow: 'hidden',
    padding: 16,
  },
  border: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1.5,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  profileSection: {
    marginRight: 12,
    position: 'relative',
  },
  avatar: {
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 2,
    borderColor: SKY,
  },
  avatarPlaceholder: {
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: `${SKY}20`,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: SKY,
  },
  certifiedBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#8B5CF6',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#0A1929',
  },
  infoSection: {
    flex: 1,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 6,
    flexWrap: 'wrap',
  },
  name: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginRight: 8,
  },
  chip: {
    marginTop: 2,
  },
  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  rating: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    marginLeft: 4,
  },
  reviewCount: {
    color: '#94A3B8',
    fontSize: 13,
    marginLeft: 4,
  },
  jobsCount: {
    color: '#94A3B8',
    fontSize: 13,
    marginLeft: 8,
  },
  etaSection: {
    alignItems: 'flex-end',
  },
  etaValue: {
    color: SKY,
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 2,
  },
  etaLabel: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '500',
    marginBottom: 4,
  },
  distance: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '500',
  },
  selectedIndicator: {
    position: 'absolute',
    top: 12,
    right: 12,
  },
});
