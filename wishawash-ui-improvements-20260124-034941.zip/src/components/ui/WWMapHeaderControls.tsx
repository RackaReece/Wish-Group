import React from 'react';
import {
  View,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import { BlurView } from 'expo-blur';

const SKY = colors.SKY;

interface WWMapHeaderControlsProps {
  onBack?: () => void;
  onLocate?: () => void;
  onClose?: () => void;
  showBack?: boolean;
  showLocate?: boolean;
  showClose?: boolean;
}

export default function WWMapHeaderControls({
  onBack,
  onLocate,
  onClose,
  showBack = true,
  showLocate = true,
  showClose = false,
}: WWMapHeaderControlsProps) {
  return (
    <View style={styles.container}>
      {showBack && onBack && (
        <TouchableOpacity
          onPress={onBack}
          style={styles.button}
          activeOpacity={0.7}
        >
          <BlurView intensity={20} tint="dark" style={styles.blur}>
            <Ionicons name="arrow-back" size={20} color="#F9FAFB" />
          </BlurView>
        </TouchableOpacity>
      )}

      {showLocate && onLocate && (
        <TouchableOpacity
          onPress={onLocate}
          style={styles.button}
          activeOpacity={0.7}
        >
          <BlurView intensity={20} tint="dark" style={styles.blur}>
            <Ionicons name="locate" size={20} color={SKY} />
          </BlurView>
        </TouchableOpacity>
      )}

      {showClose && onClose && (
        <TouchableOpacity
          onPress={onClose}
          style={styles.button}
          activeOpacity={0.7}
        >
          <BlurView intensity={20} tint="dark" style={styles.blur}>
            <Ionicons name="close" size={20} color="#F9FAFB" />
          </BlurView>
        </TouchableOpacity>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 50,
    left: 16,
    right: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    zIndex: 1000,
  },
  button: {
    width: 44,
    height: 44,
    borderRadius: 22,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  blur: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
});
