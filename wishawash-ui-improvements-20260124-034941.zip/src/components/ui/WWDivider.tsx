import React from 'react';
import {
  View,
  StyleSheet,
  ViewStyle,
} from 'react-native';

interface WWDividerProps {
  style?: ViewStyle;
  variant?: 'default' | 'subtle' | 'strong';
}

export default function WWDivider({
  style,
  variant = 'default',
}: WWDividerProps) {
  const getOpacity = () => {
    switch (variant) {
      case 'subtle':
        return 0.05;
      case 'strong':
        return 0.2;
      default:
        return 0.1;
    }
  };

  return (
    <View
      style={[
        styles.container,
        { backgroundColor: `rgba(255, 255, 255, ${getOpacity()})` },
        style,
      ]}
    />
  );
}

const styles = StyleSheet.create({
  container: {
    height: 1,
    width: '100%',
  },
});
