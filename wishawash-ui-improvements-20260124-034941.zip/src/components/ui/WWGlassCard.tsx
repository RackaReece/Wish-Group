import React from 'react';
import {
  View,
  StyleSheet,
  ViewStyle,
  TouchableOpacity,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../../constants/colors';

const SKY = colors.SKY;

interface WWGlassCardProps {
  children: React.ReactNode;
  style?: ViewStyle;
  onPress?: () => void;
  variant?: 'default' | 'elevated' | 'subtle';
}

export default function WWGlassCard({
  children,
  style,
  onPress,
  variant = 'default',
}: WWGlassCardProps) {
  const blurIntensity = variant === 'elevated' ? 30 : variant === 'subtle' ? 15 : 20;
  const borderOpacity = variant === 'elevated' ? 0.4 : 0.25;

  const content = (
    <BlurView intensity={blurIntensity} tint="dark" style={[styles.container, style]}>
      <LinearGradient
        colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
        style={StyleSheet.absoluteFill}
      />
      <View style={[styles.border, { borderColor: `${SKY}${Math.round(borderOpacity * 255).toString(16).padStart(2, '0')}` }]} />
      {children}
    </BlurView>
  );

  if (onPress) {
    return (
      <TouchableOpacity activeOpacity={0.8} onPress={onPress}>
        {content}
      </TouchableOpacity>
    );
  }

  return content;
}

const styles = StyleSheet.create({
  container: {
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
  },
  border: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
  },
});
