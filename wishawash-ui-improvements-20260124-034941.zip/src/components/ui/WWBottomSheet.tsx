import React, { useRef, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  PanResponder,
  Dimensions,
  TouchableOpacity,
  ScrollView,
  ViewStyle,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../constants/colors';
import * as Haptics from 'expo-haptics';

const { height: SCREEN_HEIGHT } = Dimensions.get('window');
const SKY = colors.SKY;

export type BottomSheetState = 'collapsed' | 'half' | 'full';

interface WWBottomSheetProps {
  children: React.ReactNode;
  state?: BottomSheetState;
  onStateChange?: (state: BottomSheetState) => void;
  collapsedHeight?: number; // ~15% of screen
  halfHeight?: number; // ~45-55% of screen
  fullHeight?: number; // ~80-90% of screen
  showHandle?: boolean;
  enablePan?: boolean;
  previewContent?: React.ReactNode;
  footerButton?: React.ReactNode;
  style?: ViewStyle;
  snapPoints?: number[]; // Custom snap points
}

const DEFAULT_COLLAPSED = SCREEN_HEIGHT * 0.15;
const DEFAULT_HALF = SCREEN_HEIGHT * 0.5;
const DEFAULT_FULL = SCREEN_HEIGHT * 0.85;

export default function WWBottomSheet({
  children,
  state: controlledState,
  onStateChange,
  collapsedHeight = DEFAULT_COLLAPSED,
  halfHeight = DEFAULT_HALF,
  fullHeight = DEFAULT_FULL,
  showHandle = true,
  enablePan = true,
  previewContent,
  footerButton,
  style,
  snapPoints,
}: WWBottomSheetProps) {
  const insets = useSafeAreaInsets();
  const [internalState, setInternalState] = useState<BottomSheetState>('half');
  const panY = useRef(new Animated.Value(halfHeight)).current;
  const lastPanY = useRef(halfHeight);

  const currentState = controlledState || internalState;
  const points = snapPoints || [collapsedHeight, halfHeight, fullHeight];

  const getHeightForState = (s: BottomSheetState): number => {
    switch (s) {
      case 'collapsed':
        return collapsedHeight;
      case 'half':
        return halfHeight;
      case 'full':
        return fullHeight;
    }
  };

  const findNearestSnapPoint = (y: number): number => {
    return points.reduce((prev, curr) => 
      Math.abs(curr - y) < Math.abs(prev - y) ? curr : prev
    );
  };

  const setState = (newState: BottomSheetState) => {
    if (controlledState === undefined) {
      setInternalState(newState);
    }
    onStateChange?.(newState);
    
    const targetHeight = getHeightForState(newState);
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    
    Animated.spring(panY, {
      toValue: targetHeight,
      useNativeDriver: false,
      tension: 50,
      friction: 8,
    }).start();
    lastPanY.current = targetHeight;
  };

  const panResponder = useRef(
    PanResponder.create({
      onStartShouldSetPanResponder: () => enablePan,
      onMoveShouldSetPanResponder: () => enablePan,
      onPanResponderGrant: () => {
        panY.setOffset(lastPanY.current);
        panY.setValue(0);
      },
      onPanResponderMove: (_, gestureState) => {
        const newY = lastPanY.current + gestureState.dy;
        const clampedY = Math.max(
          Math.min(...points),
          Math.min(Math.max(...points), newY)
        );
        panY.setValue(clampedY - lastPanY.current);
      },
      onPanResponderRelease: (_, gestureState) => {
        panY.flattenOffset();
        const currentY = lastPanY.current + gestureState.dy;
        const velocity = gestureState.vy;

        let targetState: BottomSheetState;
        
        if (Math.abs(velocity) > 0.5) {
          // Fast swipe
          if (velocity > 0) {
            if (currentState === 'full') {
              targetState = 'half';
            } else {
              targetState = 'collapsed';
            }
          } else {
            if (currentState === 'collapsed') {
              targetState = 'half';
            } else {
              targetState = 'full';
            }
          }
        } else {
          // Slow drag - snap to nearest
          const nearest = findNearestSnapPoint(currentY);
          if (nearest === collapsedHeight) {
            targetState = 'collapsed';
          } else if (nearest === fullHeight) {
            targetState = 'full';
          } else {
            targetState = 'half';
          }
        }

        setState(targetState);
      },
    })
  ).current;

  useEffect(() => {
    if (controlledState !== undefined) {
      const targetHeight = getHeightForState(controlledState);
      Animated.spring(panY, {
        toValue: targetHeight,
        useNativeDriver: false,
        tension: 50,
        friction: 8,
      }).start();
      lastPanY.current = targetHeight;
    }
  }, [controlledState]);

  const handleToggle = () => {
    if (currentState === 'collapsed') {
      setState('half');
    } else if (currentState === 'half') {
      setState('full');
    } else {
      setState('half');
    }
  };

  const sheetHeight = panY.interpolate({
    inputRange: [Math.min(...points), Math.max(...points)],
    outputRange: [Math.min(...points), Math.max(...points)],
    extrapolate: 'clamp',
  });

  const isCollapsed = currentState === 'collapsed';
  const isHalf = currentState === 'half';
  const showPreview = (isCollapsed || isHalf) && previewContent;

  const translateY = Animated.subtract(SCREEN_HEIGHT, sheetHeight);

  return (
    <Animated.View
      style={[
        styles.container,
        {
          height: sheetHeight,
          transform: [{ translateY }],
        },
        style,
      ]}
      {...panResponder.panHandlers}
    >
      <LinearGradient
        colors={['rgba(15, 23, 42, 0.95)', 'rgba(15, 23, 42, 0.85)', 'rgba(15, 23, 42, 0.7)', 'transparent']}
        style={styles.topGradient}
        pointerEvents="none"
      />

      <BlurView intensity={20} tint="dark" style={StyleSheet.absoluteFill}>
        <LinearGradient
          colors={['rgba(15, 23, 42, 0.92)', 'rgba(15, 23, 42, 0.88)']}
          style={StyleSheet.absoluteFill}
        />
      </BlurView>

      <View style={styles.content}>
        {showHandle && (
          <TouchableOpacity
            onPress={handleToggle}
            style={styles.handleContainer}
            activeOpacity={0.7}
          >
            <View style={styles.handle} />
          </TouchableOpacity>
        )}

        {showPreview && (
          <View style={styles.previewContainer}>
            {previewContent}
          </View>
        )}

        <ScrollView
          style={styles.scrollContent}
          contentContainerStyle={[
            styles.scrollContentInner,
            { paddingBottom: insets.bottom + (footerButton ? 80 : 20) },
          ]}
          showsVerticalScrollIndicator={false}
        >
          {children}
        </ScrollView>

        {footerButton && (
          <View style={[styles.footerContainer, { paddingBottom: insets.bottom + 8 }]}>
            {footerButton}
          </View>
        )}
      </View>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
    elevation: 16,
  },
  topGradient: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 40,
    zIndex: 1,
  },
  content: {
    flex: 1,
  },
  handleContainer: {
    alignItems: 'center',
    paddingVertical: 12,
    zIndex: 2,
  },
  handle: {
    width: 40,
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255, 255, 255, 0.3)',
  },
  previewContainer: {
    paddingHorizontal: 20,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.1)',
  },
  scrollContent: {
    flex: 1,
  },
  scrollContentInner: {
    paddingHorizontal: 20,
    paddingTop: 8,
  },
  footerContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 20,
    paddingTop: 12,
    backgroundColor: 'rgba(15, 23, 42, 0.95)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255, 255, 255, 0.1)',
  },
});
