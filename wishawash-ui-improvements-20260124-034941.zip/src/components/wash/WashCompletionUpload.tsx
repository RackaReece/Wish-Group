import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Alert,
  Image,
  Dimensions,
  ActivityIndicator,
  Modal,
  Animated,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import * as ImagePicker from 'expo-image-picker';
import { WashCompletion } from '../../services/WashCompletionService';
import { useAuth } from '../../providers/enhanced-auth-context';
import { CurrentJob } from '../../services/CurrentJobService';

const { width, height } = Dimensions.get('window');

interface WashCompletionUploadProps {
  bookingId?: string;
  customerId?: string;
  onComplete?: (washCompletion: WashCompletion) => void;
  onClose?: () => void;
}

export default function WashCompletionUpload({ 
  onComplete, 
  onClose 
}: WashCompletionUploadProps) {
  const { user } = useAuth();
  const [photos, setPhotos] = useState<string[]>([]);
  const [notes, setNotes] = useState('');
  const [isUploading, setIsUploading] = useState(false);
  const [currentJob, setCurrentJob] = useState<CurrentJob | null>(null);
  const [loadingJob, setLoadingJob] = useState(true);
  const [showRatingModal, setShowRatingModal] = useState(false);
  const [washCompletionId, setWashCompletionId] = useState<string>('');
  
  // Rating state
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [tipAmount, setTipAmount] = useState(0);
  const [isSubmittingRating, setIsSubmittingRating] = useState(false);
  
  // AI Car Image Scanning state
  const [carScanPhoto, setCarScanPhoto] = useState<string | null>(null);
  const [dirtinessLevel, setDirtinessLevel] = useState<'low' | 'medium' | 'high' | 'very_high' | null>(null);
  const [showDirtinessAssessment, setShowDirtinessAssessment] = useState(false);

  // Star animations
  const starAnimations = [
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
    useRef(new Animated.Value(0)).current,
  ];

  useEffect(() => {
    loadCurrentJob();
  }, []);

  const loadCurrentJob = async () => {
    if (!user) return;
    
    try {
      setLoadingJob(true);
      
      // Load actual job from booking service
      // TODO: Implement actual job loading from BookingService
      setCurrentJob(null);
    } catch (error) {
      console.error('Error loading current job:', error);
      Alert.alert('Error', 'Failed to load current job information');
    } finally {
      setLoadingJob(false);
    }
  };

  const requestCameraPermission = async () => {
    const { status } = await ImagePicker.requestCameraPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission Required', 'Camera permission is required to take photos');
      return false;
    }
    return true;
  };

  const handleTakePhoto = async () => {
    const hasPermission = await requestCameraPermission();
    if (!hasPermission) return;

    try {
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        setPhotos(prev => [...prev, result.assets[0].uri]);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to take photo');
    }
  };

  const handlePickFromGallery = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
        allowsMultipleSelection: true,
      });

      if (!result.canceled && result.assets) {
        const newPhotos = result.assets.map(asset => asset.uri);
        setPhotos(prev => [...prev, ...newPhotos]);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to pick photos from gallery');
    }
  };

  const handleRemovePhoto = (index: number) => {
    setPhotos(prev => prev.filter((_, i) => i !== index));
  };

  const handleScanCarPhoto = async () => {
    const hasPermission = await requestCameraPermission();
    if (!hasPermission) return;

    try {
      const result = await ImagePicker.launchCameraAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        setCarScanPhoto(result.assets[0].uri);
        // Simulate AI analysis - in UI only, randomly assign dirtiness level
        const levels: Array<'low' | 'medium' | 'high' | 'very_high'> = ['low', 'medium', 'high', 'very_high'];
        const randomLevel = levels[Math.floor(Math.random() * levels.length)];
        setDirtinessLevel(randomLevel);
        setShowDirtinessAssessment(true);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to scan car photo');
    }
  };

  const handlePickCarPhotoFromGallery = async () => {
    try {
      const result = await ImagePicker.launchImageLibraryAsync({
        mediaTypes: ImagePicker.MediaTypeOptions.Images,
        allowsEditing: true,
        aspect: [4, 3],
        quality: 0.8,
      });

      if (!result.canceled && result.assets[0]) {
        setCarScanPhoto(result.assets[0].uri);
        // Simulate AI analysis - in UI only, randomly assign dirtiness level
        const levels: Array<'low' | 'medium' | 'high' | 'very_high'> = ['low', 'medium', 'high', 'very_high'];
        const randomLevel = levels[Math.floor(Math.random() * levels.length)];
        setDirtinessLevel(randomLevel);
        setShowDirtinessAssessment(true);
      }
    } catch (error) {
      Alert.alert('Error', 'Failed to pick photo from gallery');
    }
  };

  const handleSubmit = async () => {
    if (photos.length === 0) {
      Alert.alert('Photos Required', 'Please take at least one photo of the completed wash');
      return;
    }

    setIsUploading(true);
    try {
      // Simulate wash completion upload
      const washCompletion: WashCompletion = {
        id: `completion_${Date.now()}`,
        bookingId: currentJob?.bookingId || '',
        customerId: currentJob?.customerId || '',
        valeterId: user?.id || '',
        photos,
        notes,
        status: 'completed',
        completedAt: new Date(),
        rating: 0,
        tipAmount: 0,
      };

      // Set the completion ID for the rating modal
      setWashCompletionId(washCompletion.id);
      
      // Show success message and rating option
      Alert.alert(
        'Wash Completed! 🎉',
        'Your wash has been successfully completed and uploaded. Would you like to rate the service?',
        [
          {
            text: 'Skip Rating',
            style: 'cancel',
            onPress: () => {
              onComplete?.(washCompletion);
              onClose?.();
            }
          },
          {
            text: 'Rate Service',
            onPress: () => {
              setShowRatingModal(true);
            }
          }
        ]
      );

    } catch (error) {
      Alert.alert('Error', 'Failed to complete wash. Please try again.');
    } finally {
      setIsUploading(false);
    }
  };

  const animateStars = (selectedRating: number) => {
    starAnimations.forEach((anim, index) => {
      Animated.spring(anim, {
        toValue: index < selectedRating ? 1 : 0,
        useNativeDriver: true,
        tension: 100,
        friction: 8,
      }).start();
    });
  };

  const handleStarPress = (starIndex: number) => {
    const newRating = starIndex + 1;
    setRating(newRating);
    animateStars(newRating);
  };

  const handleTipSelect = (amount: number) => {
    setTipAmount(amount);
  };

  const handleRatingSubmit = async () => {
    if (rating === 0) {
      Alert.alert('Rating Required', 'Please select a star rating');
      return;
    }

    if (review.trim().length === 0) {
      Alert.alert('Review Required', 'Please write a review');
      return;
    }

    setIsSubmittingRating(true);
    try {
      // Simulate rating submission
      await new Promise(resolve => setTimeout(resolve, 1000));

      Alert.alert(
        'Thank You! ⭐',
        'Your rating and tip have been submitted successfully.',
        [
          {
            text: 'OK',
            onPress: () => {
              setShowRatingModal(false);
              onComplete?.({
                id: washCompletionId,
                bookingId: currentJob?.bookingId || '',
                customerId: currentJob?.customerId || '',
                valeterId: user?.id || '',
                photos,
                notes,
                status: 'completed',
                completedAt: new Date(),
                        rating,
        tipAmount,
              });
              onClose?.();
            }
          }
        ]
      );
    } catch (error) {
      Alert.alert('Submission Failed', 'Please try again');
    } finally {
      setIsSubmittingRating(false);
    }
  };

  const handleRatingClose = () => {
    setShowRatingModal(false);
    setRating(0);
    setReview('');
    setTipAmount(0);
    onComplete?.({
      id: washCompletionId,
      bookingId: currentJob?.bookingId || '',
      customerId: currentJob?.customerId || '',
      valeterId: user?.id || '',
      photos,
      notes,
      status: 'completed',
      completedAt: new Date(),
      rating: 0,
      tipAmount: 0,
    });
    onClose?.();
  };

  if (loadingJob) {
    return (
      <View style={styles.container}>
        <LinearGradient
          colors={['#0A1929', '#1E3A8A']}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color="#FFFFFF" />
          <Text style={styles.loadingText}>Loading current job...</Text>
        </View>
      </View>
    );
  }

  if (!currentJob) {
    return (
      <View style={styles.container}>
        <LinearGradient
          colors={['#0A1929', '#1E3A8A']}
          style={StyleSheet.absoluteFill}
        />
        <View style={styles.noJobContainer}>
          <Text style={styles.noJobTitle}>No Active Job</Text>
          <Text style={styles.noJobText}>
            You don't have any active jobs to complete at the moment.
          </Text>
          <TouchableOpacity style={styles.backToDashboardButton} onPress={onClose}>
            <Text style={styles.backToDashboardText}>Back to Dashboard</Text>
          </TouchableOpacity>
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#0A1929', '#1E3A8A']}
        style={StyleSheet.absoluteFill}
      />
      
      <View style={styles.header}>
        <TouchableOpacity onPress={onClose} style={styles.backButton}>
          <Text style={styles.backButtonText}>← Back</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Complete Wash</Text>
        <View style={styles.placeholder} />
      </View>

      <ScrollView style={styles.content} showsVerticalScrollIndicator={false}>
        {/* Current Job Information */}
        <View style={styles.jobInfoSection}>
          <Text style={styles.sectionTitle}>📋 Current Job</Text>
          <View style={styles.jobCard}>
            <View style={styles.jobHeader}>
              <Text style={styles.jobService}>{currentJob.serviceName}</Text>
              <Text style={styles.jobPrice}>£{currentJob.price}</Text>
            </View>
            <Text style={styles.jobLocation}>{currentJob.location.address}</Text>
            <Text style={styles.jobVehicle}>
              {currentJob.vehicleType} {currentJob.vehicleInfo ? `- ${currentJob.vehicleInfo}` : ''}
            </Text>
            {currentJob.specialInstructions && (
              <Text style={styles.jobInstructions}>
                Special Instructions: {currentJob.specialInstructions}
              </Text>
            )}
          </View>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📸 Upload Photos</Text>
          <Text style={styles.sectionSubtitle}>
            Take photos of the completed wash to show the customer
          </Text>

          <View style={styles.photoButtonsContainer}>
            <TouchableOpacity style={styles.takePhotoButton} onPress={handleTakePhoto}>
              <Text style={styles.takePhotoIcon}>📷</Text>
              <Text style={styles.takePhotoText}>Take Photo</Text>
            </TouchableOpacity>

            <TouchableOpacity style={styles.galleryButton} onPress={handlePickFromGallery}>
              <Text style={styles.galleryIcon}>🖼️</Text>
              <Text style={styles.galleryText}>From Gallery</Text>
            </TouchableOpacity>
          </View>

          {photos.length > 0 && (
            <View style={styles.photosContainer}>
              <Text style={styles.photosTitle}>Photos ({photos.length})</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false}>
                {photos.map((photo, index) => (
                  <View key={index} style={styles.photoContainer}>
                    <Image source={{ uri: photo }} style={styles.photoImage} />
                    <TouchableOpacity
                      style={styles.removePhotoButton}
                      onPress={() => handleRemovePhoto(index)}
                    >
                      <Text style={styles.removePhotoText}>×</Text>
                    </TouchableOpacity>
                  </View>
                ))}
              </ScrollView>
            </View>
          )}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>📝 Notes (Optional)</Text>
          <Text style={styles.sectionSubtitle}>
            Add any notes about the wash service provided
          </Text>

          <TextInput
            style={styles.notesInput}
            placeholder="e.g., Exterior wash completed, interior vacuumed and wiped down, wheels cleaned..."
            placeholderTextColor="#87CEEB"
            value={notes}
            onChangeText={setNotes}
            multiline
            numberOfLines={4}
          />
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>✅ Completion Checklist</Text>
          <View style={styles.checklist}>
            <View style={styles.checklistItem}>
              <Text style={styles.checklistIcon}>✓</Text>
              <Text style={styles.checklistText}>Exterior wash completed</Text>
            </View>
            <View style={styles.checklistItem}>
              <Text style={styles.checklistIcon}>✓</Text>
              <Text style={styles.checklistText}>Interior cleaned and vacuumed</Text>
            </View>
            <View style={styles.checklistItem}>
              <Text style={styles.checklistIcon}>✓</Text>
              <Text style={styles.checklistText}>Windows cleaned</Text>
            </View>
            <View style={styles.checklistItem}>
              <Text style={styles.checklistIcon}>✓</Text>
              <Text style={styles.checklistText}>Wheels and tyres cleaned</Text>
            </View>
            <View style={styles.checklistItem}>
              <Text style={styles.checklistIcon}>✓</Text>
              <Text style={styles.checklistText}>Quality check completed</Text>
            </View>
          </View>
        </View>

        <TouchableOpacity
          style={[styles.submitButton, isUploading && styles.submitButtonDisabled]}
          onPress={handleSubmit}
          disabled={isUploading}
        >
          {isUploading ? (
            <ActivityIndicator color="#0A1929" />
          ) : (
            <>
              <Text style={styles.submitButtonIcon}>✅</Text>
              <Text style={styles.submitButtonText}>Complete Wash</Text>
            </>
          )}
        </TouchableOpacity>
      </ScrollView>

      {/* Rating Modal */}
      <Modal
        visible={showRatingModal}
        animationType="slide"
        presentationStyle="fullScreen"
      >
        <View style={styles.ratingModalContainer}>
          <LinearGradient
            colors={['#0A1929', '#1E3A8A']}
            style={StyleSheet.absoluteFill}
          />
          
          <View style={styles.ratingHeader}>
            <TouchableOpacity onPress={handleRatingClose} style={styles.ratingBackButton}>
              <Text style={styles.ratingBackButtonText}>← Back</Text>
            </TouchableOpacity>
            <Text style={styles.ratingHeaderTitle}>Rate Your Wash</Text>
            <View style={styles.ratingPlaceholder} />
          </View>

          <ScrollView style={styles.ratingContent} showsVerticalScrollIndicator={false}>
            <View style={styles.ratingSection}>
              <Text style={styles.ratingSectionTitle}>✨ Rate Your Experience</Text>
              <Text style={styles.ratingSectionSubtitle}>
                How was your car wash service today?
              </Text>

              <View style={styles.starsContainer}>
                {[0, 1, 2, 3, 4].map((starIndex) => (
                  <TouchableOpacity
                    key={starIndex}
                    style={styles.starButton}
                    onPress={() => handleStarPress(starIndex)}
                  >
                    <Animated.Text
                      style={[
                        styles.starIcon,
                        {
                          transform: [
                            {
                              scale: starAnimations[starIndex].interpolate({
                                inputRange: [0, 1],
                                outputRange: [1, 1.2],
                              }),
                            },
                          ],
                          color: starIndex < rating ? '#FFD700' : '#6B7280',
                        },
                      ]}
                    >
                      ⭐
                    </Animated.Text>
                  </TouchableOpacity>
                ))}
              </View>

              <Text style={styles.ratingText}>
                {rating === 0 && 'Tap the stars to rate'}
                {rating === 1 && 'Poor'}
                {rating === 2 && 'Fair'}
                {rating === 3 && 'Good'}
                {rating === 4 && 'Very Good'}
                {rating === 5 && 'Excellent!'}
              </Text>
            </View>

            <View style={styles.ratingSection}>
              <Text style={styles.ratingSectionTitle}>📝 Write a Review</Text>
              <Text style={styles.ratingSectionSubtitle}>
                Share your experience with the valeter
              </Text>

              <TextInput
                style={styles.reviewInput}
                placeholder="Tell us about your experience... (e.g., Great service, car looks amazing, very professional)"
                placeholderTextColor="#87CEEB"
                value={review}
                onChangeText={setReview}
                multiline
                numberOfLines={4}
              />
            </View>

            {/* AI Car Image Scanning Section */}
            <View style={styles.ratingSection}>
              <Text style={styles.ratingSectionTitle}>🤖 AI Car Image Scanning</Text>
              <Text style={styles.ratingSectionSubtitle}>
                Scan your car to get personalised wash recommendations
              </Text>

              {!carScanPhoto ? (
                <View style={styles.scanButtonsContainer}>
                  <TouchableOpacity style={styles.scanPhotoButton} onPress={handleScanCarPhoto}>
                    <Ionicons name="camera" size={20} color="#FFFFFF" />
                    <Text style={styles.scanPhotoText}>Scan Car</Text>
                  </TouchableOpacity>

                  <TouchableOpacity style={styles.pickScanPhotoButton} onPress={handlePickCarPhotoFromGallery}>
                    <Ionicons name="image" size={20} color="#10B981" />
                    <Text style={styles.pickScanPhotoText}>From Gallery</Text>
                  </TouchableOpacity>
                </View>
              ) : (
                <View style={styles.scannedPhotoContainer}>
                  <Image source={{ uri: carScanPhoto }} style={styles.scannedPhotoImage} />
                  <TouchableOpacity
                    style={styles.removeScannedPhotoButton}
                    onPress={() => {
                      setCarScanPhoto(null);
                      setDirtinessLevel(null);
                      setShowDirtinessAssessment(false);
                    }}
                  >
                    <Text style={styles.removeScannedPhotoText}>×</Text>
                  </TouchableOpacity>
                </View>
              )}

              {showDirtinessAssessment && dirtinessLevel && (
                <View style={styles.dirtinessAssessmentCard}>
                  <Text style={styles.dirtinessTitle}>Dirtiness Assessment</Text>
                  <View style={styles.dirtinessLevelContainer}>
                    <View style={[styles.dirtinessLevelBadge, styles[`dirtinessLevel${dirtinessLevel.charAt(0).toUpperCase() + dirtinessLevel.slice(1).replace('_', '')}Badge`]]}>
                      <Text style={styles.dirtinessLevelText}>
                        {dirtinessLevel === 'low' ? 'Low' : 
                         dirtinessLevel === 'medium' ? 'Medium' : 
                         dirtinessLevel === 'high' ? 'High' : 'Very High'}
                      </Text>
                    </View>
                    <View style={styles.dirtinessBarContainer}>
                      <View style={[styles.dirtinessBar, { 
                        width: dirtinessLevel === 'low' ? '25%' : 
                               dirtinessLevel === 'medium' ? '50%' : 
                               dirtinessLevel === 'high' ? '75%' : '100%',
                        backgroundColor: dirtinessLevel === 'low' ? '#10B981' : 
                                        dirtinessLevel === 'medium' ? '#F59E0B' : 
                                        dirtinessLevel === 'high' ? '#F97316' : '#EF4444'
                      }]} />
                    </View>
                  </View>
                  
                  <Text style={styles.recommendationTitle}>Recommended Wash Type:</Text>
                  {dirtinessLevel === 'low' && (
                    <View style={styles.recommendationCard}>
                      <Text style={styles.recommendationServiceName}>Bronze Wash</Text>
                      <Text style={styles.recommendationPrice}>£15</Text>
                      <Text style={styles.recommendationDescription}>Perfect for lightly soiled vehicles</Text>
                    </View>
                  )}
                  {dirtinessLevel === 'medium' && (
                    <View style={styles.recommendationCard}>
                      <Text style={styles.recommendationServiceName}>Silver Wash</Text>
                      <Text style={styles.recommendationPrice}>£25</Text>
                      <Text style={styles.recommendationDescription}>Ideal for moderate dirt build-up</Text>
                    </View>
                  )}
                  {dirtinessLevel === 'high' && (
                    <View style={styles.recommendationCard}>
                      <Text style={styles.recommendationServiceName}>Gold Wash</Text>
                      <Text style={styles.recommendationPrice}>£45</Text>
                      <Text style={styles.recommendationDescription}>Recommended for heavily soiled vehicles</Text>
                    </View>
                  )}
                  {dirtinessLevel === 'very_high' && (
                    <View style={styles.recommendationCard}>
                      <Text style={styles.recommendationServiceName}>Platinum Wash</Text>
                      <Text style={styles.recommendationPrice}>£85</Text>
                      <Text style={styles.recommendationDescription}>Complete deep clean for very dirty vehicles</Text>
                    </View>
                  )}
                </View>
              )}
            </View>

            <View style={styles.ratingSection}>
              <Text style={styles.ratingSectionTitle}>💰 Leave a Tip (Optional)</Text>
              <Text style={styles.ratingSectionSubtitle}>
                Show appreciation for excellent service
              </Text>

              <View style={styles.tipOptions}>
                {[0, 2, 5, 10, 15, 20].map((amount) => (
                  <TouchableOpacity
                    key={amount}
                    style={[
                      styles.tipOption,
                      tipAmount === amount && styles.tipOptionSelected
                    ]}
                    onPress={() => handleTipSelect(amount)}
                  >
                    <Text style={[
                      styles.tipAmount,
                      tipAmount === amount && styles.tipAmountSelected
                    ]}>
                      £{amount}
                    </Text>
                    {amount === 0 && (
                      <Text style={[
                        styles.tipLabel,
                        tipAmount === amount && styles.tipLabelSelected
                      ]}>
                        No Tip
                      </Text>
                    )}
                  </TouchableOpacity>
                ))}
              </View>

              {tipAmount > 0 && (
                <View style={styles.tipMessage}>
                  <Text style={styles.tipMessageText}>
                    💝 Thank you for your generosity! Your tip will be sent directly to the valeter.
                  </Text>
                  {dirtinessLevel && (
                    <Text style={styles.tipRecommendationText}>
                      💡 Based on your car's condition, consider booking a {
                        dirtinessLevel === 'low' ? 'Bronze Wash' : 
                        dirtinessLevel === 'medium' ? 'Silver Wash' : 
                        dirtinessLevel === 'high' ? 'Gold Wash' : 'Platinum Wash'
                      } for your next service.
                    </Text>
                  )}
                </View>
              )}
            </View>

            <TouchableOpacity
              style={[styles.ratingSubmitButton, isSubmittingRating && styles.ratingSubmitButtonDisabled]}
              onPress={handleRatingSubmit}
              disabled={isSubmittingRating}
            >
              {isSubmittingRating ? (
                <ActivityIndicator color="#0A1929" />
              ) : (
                <>
                  <Text style={styles.ratingSubmitButtonIcon}>⭐</Text>
                  <Text style={styles.ratingSubmitButtonText}>
                    Submit Rating & Tip
                  </Text>
                </>
              )}
            </TouchableOpacity>
          </ScrollView>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    color: '#FFFFFF',
    fontSize: 16,
    marginTop: 16,
  },
  noJobContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
  },
  noJobTitle: {
    color: '#FFFFFF',
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  noJobText: {
    color: '#87CEEB',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 32,
  },
  backToDashboardButton: {
    backgroundColor: '#10B981',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
  },
  backToDashboardText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderBottomColor: 'rgba(255, 255, 255, 0.2)',
    borderBottomWidth: 1,
  },
  backButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  headerTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  placeholder: {
    width: 60,
  },
  content: {
    flex: 1,
    paddingHorizontal: 20,
  },
  jobInfoSection: {
    marginVertical: 20,
  },
  jobCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    marginTop: 12,
  },
  jobHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  jobService: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  jobPrice: {
    color: '#10B981',
    fontSize: 18,
    fontWeight: 'bold',
  },
  jobLocation: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 4,
  },
  jobVehicle: {
    color: '#FFFFFF',
    fontSize: 14,
    marginBottom: 4,
  },
  jobInstructions: {
    color: '#F59E0B',
    fontSize: 14,
    fontStyle: 'italic',
  },
  section: {
    marginVertical: 20,
  },
  sectionTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  sectionSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 16,
  },
  photoButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  takePhotoButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderWidth: 2,
    borderColor: '#FFFFFF',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 20,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    flex: 1,
    marginRight: 8,
  },
  takePhotoIcon: {
    fontSize: 24,
    marginRight: 8,
  },
  takePhotoText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  galleryButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.15)',
    borderWidth: 2,
    borderColor: '#87CEEB',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 20,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    flex: 1,
    marginLeft: 8,
  },
  galleryIcon: {
    fontSize: 24,
    marginRight: 8,
  },
  galleryText: {
    color: '#87CEEB',
    fontSize: 16,
    fontWeight: '600',
  },
  photosContainer: {
    marginTop: 20,
  },
  photosTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 12,
  },
  photoContainer: {
    marginRight: 12,
    position: 'relative',
  },
  photoImage: {
    width: 100,
    height: 100,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
  },
  removePhotoButton: {
    position: 'absolute',
    top: -8,
    right: -8,
    backgroundColor: '#EF4444',
    borderRadius: 12,
    width: 24,
    height: 24,
    alignItems: 'center',
    justifyContent: 'center',
  },
  removePhotoText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  notesInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    color: '#FFFFFF',
    fontSize: 16,
    textAlignVertical: 'top',
    minHeight: 100,
  },
  checklist: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
  },
  checklistItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  checklistIcon: {
    color: '#4CAF50',
    fontSize: 18,
    fontWeight: 'bold',
    marginRight: 12,
  },
  checklistText: {
    color: '#FFFFFF',
    fontSize: 16,
  },
  submitButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    marginVertical: 20,
  },
  submitButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  submitButtonIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  submitButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  ratingModalContainer: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  ratingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 60,
    paddingBottom: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderBottomColor: 'rgba(255, 255, 255, 0.2)',
    borderBottomWidth: 1,
  },
  ratingBackButton: {
    paddingVertical: 8,
    paddingHorizontal: 12,
  },
  ratingBackButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '600',
  },
  ratingHeaderTitle: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  ratingPlaceholder: {
    width: 60,
  },
  ratingContent: {
    flex: 1,
    paddingHorizontal: 20,
  },
  ratingSection: {
    marginVertical: 20,
  },
  ratingSectionTitle: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  ratingSectionSubtitle: {
    color: '#87CEEB',
    fontSize: 14,
    marginBottom: 16,
  },
  starsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginBottom: 16,
  },
  starButton: {
    padding: 10,
  },
  starIcon: {
    fontSize: 30,
  },
  ratingText: {
    color: '#87CEEB',
    fontSize: 16,
    textAlign: 'center',
    marginBottom: 16,
  },
  reviewInput: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 12,
    color: '#FFFFFF',
    fontSize: 16,
    textAlignVertical: 'top',
    minHeight: 100,
  },
  tipOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    marginBottom: 16,
  },
  tipOption: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.2)',
    borderRadius: 20,
    paddingVertical: 10,
    paddingHorizontal: 20,
    alignItems: 'center',
    marginVertical: 8,
    minWidth: '45%', // Adjust as needed for spacing
  },
  tipOptionSelected: {
    backgroundColor: '#10B981',
    borderColor: '#10B981',
  },
  tipAmount: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  tipAmountSelected: {
    color: '#FFFFFF',
  },
  tipLabel: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: 4,
  },
  tipLabelSelected: {
    color: '#FFFFFF',
  },
  tipMessage: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
  },
  tipMessageText: {
    color: '#10B981',
    fontSize: 16,
    textAlign: 'center',
  },
  ratingSubmitButton: {
    backgroundColor: '#4CAF50',
    borderRadius: 12,
    paddingVertical: 16,
    paddingHorizontal: 24,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
  },
  ratingSubmitButtonDisabled: {
    backgroundColor: '#6B7280',
  },
  ratingSubmitButtonIcon: {
    fontSize: 20,
    marginRight: 8,
  },
  ratingSubmitButtonText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  scanButtonsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
    gap: 12,
  },
  scanPhotoButton: {
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 2,
    borderColor: '#87CEEB',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    flex: 1,
    gap: 8,
  },
  scanPhotoText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '600',
  },
  pickScanPhotoButton: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderWidth: 2,
    borderColor: '#10B981',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    alignItems: 'center',
    flexDirection: 'row',
    justifyContent: 'center',
    flex: 1,
    gap: 8,
  },
  pickScanPhotoText: {
    color: '#10B981',
    fontSize: 14,
    fontWeight: '600',
  },
  scannedPhotoContainer: {
    position: 'relative',
    marginBottom: 16,
    alignItems: 'center',
  },
  scannedPhotoImage: {
    width: 200,
    height: 150,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  removeScannedPhotoButton: {
    position: 'absolute',
    top: -8,
    right: '30%',
    backgroundColor: '#EF4444',
    borderRadius: 15,
    width: 30,
    height: 30,
    alignItems: 'center',
    justifyContent: 'center',
  },
  removeScannedPhotoText: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  dirtinessAssessmentCard: {
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 12,
    padding: 16,
    marginTop: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  dirtinessTitle: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 12,
  },
  dirtinessLevelContainer: {
    marginBottom: 16,
  },
  dirtinessLevelBadge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    alignSelf: 'flex-start',
    marginBottom: 8,
  },
  dirtinessLevelLowBadge: {
    backgroundColor: 'rgba(16,185,129,0.3)',
    borderWidth: 1,
    borderColor: '#10B981',
  },
  dirtinessLevelMediumBadge: {
    backgroundColor: 'rgba(245,158,11,0.3)',
    borderWidth: 1,
    borderColor: '#F59E0B',
  },
  dirtinessLevelHighBadge: {
    backgroundColor: 'rgba(249,115,22,0.3)',
    borderWidth: 1,
    borderColor: '#F97316',
  },
  dirtinessLevelVeryHighBadge: {
    backgroundColor: 'rgba(239,68,68,0.3)',
    borderWidth: 1,
    borderColor: '#EF4444',
  },
  dirtinessLevelText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontWeight: '700',
  },
  dirtinessBarContainer: {
    height: 8,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderRadius: 4,
    overflow: 'hidden',
  },
  dirtinessBar: {
    height: '100%',
    borderRadius: 4,
    transition: 'width 0.3s ease',
  },
  recommendationTitle: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 8,
  },
  recommendationCard: {
    backgroundColor: 'rgba(16,185,129,0.15)',
    borderRadius: 10,
    padding: 12,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  recommendationServiceName: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 4,
  },
  recommendationPrice: {
    color: '#10B981',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
  },
  recommendationDescription: {
    color: 'rgba(255,255,255,0.8)',
    fontSize: 12,
  },
  tipRecommendationText: {
    color: '#87CEEB',
    fontSize: 13,
    marginTop: 8,
    fontStyle: 'italic',
  },
});
