import React, { useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  StatusBar,
  Animated,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import { AccountType, getAccountTheme } from '../../constants/accountThemes';
import { useAccountTheme } from './AccountThemeProvider';
// Header content heights (not including safe area or padding)
export const HEADER_CONTENT_HEIGHT = 44;
export const DASHBOARD_HEADER_CONTENT_HEIGHT = 48;
// Total header heights including padding (for calculating page padding)
export const HEADER_HEIGHT = HEADER_CONTENT_HEIGHT + 16;
export const DASHBOARD_HEADER_HEIGHT = DASHBOARD_HEADER_CONTENT_HEIGHT + 16;

// Standard spacing to position content directly beneath the header.
// These offsets already include the safe-area padding applied inside the header.
export const HEADER_CONTENT_OFFSET = HEADER_HEIGHT + 8;
export const DASHBOARD_HEADER_CONTENT_OFFSET = DASHBOARD_HEADER_HEIGHT + 8;

interface AppHeaderProps {
  title: string;
  subtitle?: string;
  onBack?: () => void;
  rightAction?: React.ReactNode;
  variant?: 'default' | 'dashboard';
  scrollY?: Animated.Value;
  enableScrollAnimation?: boolean;
  accountType?: AccountType;
  showBack?: boolean;
  points?: number;
  businessName?: string;
  businessAddress?: string;
  businessRating?: number;
  profilePicture?: string | null;
  onProfilePress?: () => void;
  primaryColor?: string; // Override theme primary color
}

export default function AppHeader({
  title,
  subtitle,
  onBack,
  rightAction,
  variant = 'default',
  scrollY,
  enableScrollAnimation = false,
  accountType,
  showBack = true,
  points,
  businessName,
  businessAddress,
  businessRating,
  profilePicture,
  onProfilePress,
  primaryColor,
}: AppHeaderProps) {
  const insets = useSafeAreaInsets();
  const defaultScrollY = useRef(new Animated.Value(0)).current;
  const scrollPosition = scrollY || defaultScrollY;
  
  const contextTheme = useAccountTheme();
  const theme = accountType 
    ? getAccountTheme(accountType)
    : contextTheme.theme;
  
  // Use custom primary color if provided, otherwise use theme primary
  const effectivePrimaryColor = primaryColor || theme.primary;

  const headerOpacity = enableScrollAnimation
    ? scrollPosition.interpolate({
        inputRange: [0, 50, 100],
        outputRange: [1, 0.98, 0.96],
        extrapolate: 'clamp',
      })
    : 1;

  const handleBack = async () => {
    await hapticFeedback('light');
    if (onBack) {
      onBack();
    } else {
      router.back();
    }
  };

  const isDashboard = variant === 'dashboard';
  const headerContentHeight = isDashboard ? DASHBOARD_HEADER_CONTENT_HEIGHT : HEADER_CONTENT_HEIGHT;

  return (
    <>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <Animated.View
        style={[
          styles.container,
          { 
            opacity: headerOpacity,
            paddingTop: insets.top + 12,
          },
        ]}
        pointerEvents="box-none"
      >
        <View style={styles.floatingRow}>
          {/* Left side - Back button or Title */}
          <View style={styles.leftFloating}>
            {showBack ? (
              <TouchableOpacity
                onPress={handleBack}
                style={styles.floatingButton}
                activeOpacity={0.7}
              >
                <Ionicons name="chevron-back" size={20} color="#FFFFFF" />
              </TouchableOpacity>
            ) : (
              <View style={[styles.floatingTitle, { backgroundColor: effectivePrimaryColor }]}>
                <Text 
                  style={styles.floatingTitleText} 
                  numberOfLines={1} 
                  ellipsizeMode="tail"
                >
                  {isDashboard && businessName ? businessName : (title || ' ')}
                </Text>
              </View>
            )}
          </View>

          {/* Right side - Actions */}
          <View style={styles.rightFloating}>
            {rightAction && (
              <View style={styles.floatingAction}>
                {rightAction}
              </View>
            )}
            {isDashboard && points !== undefined && (
              <View style={[styles.floatingPoints, { backgroundColor: effectivePrimaryColor }]}>
                <Ionicons name="trophy-outline" size={16} color="#FFFFFF" />
                <Text style={styles.floatingPointsText}>{points}</Text>
              </View>
            )}
            {profilePicture && (
              <TouchableOpacity
                onPress={onProfilePress}
                style={styles.floatingProfile}
                activeOpacity={0.8}
              >
                <Image
                  source={{ uri: profilePicture }}
                  style={styles.profileImage}
                />
              </TouchableOpacity>
            )}
            {!profilePicture && onProfilePress && (
              <TouchableOpacity
                onPress={onProfilePress}
                style={[styles.floatingProfile, styles.floatingProfilePlaceholder]}
                activeOpacity={0.8}
              >
                <Ionicons name="person" size={20} color="#FFFFFF" />
              </TouchableOpacity>
            )}
          </View>
        </View>
      </Animated.View>
    </>
  );
}

const styles = StyleSheet.create({
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    elevation: 0,
  },
  floatingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingBottom: 12,
  },
  leftFloating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  rightFloating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  floatingButton: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 4,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  floatingTitle: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 14,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 6,
    maxWidth: 200,
  },
  floatingTitleText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
    includeFontPadding: false,
  },
  floatingAction: {
    // Container for right action (like notification bell)
  },
  floatingPoints: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 12,
  },
  floatingPointsText: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '700',
  },
  floatingProfile: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 4,
    elevation: 4,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  floatingProfilePlaceholder: {
    // Same as floatingProfile, just for when no image
  },
  profileImage: {
    width: 44,
    height: 44,
    borderRadius: 22,
  },
});

