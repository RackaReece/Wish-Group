import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { colors } from '../../constants/colors';

interface StandardFooterProps {
  showPoweredBy?: boolean;
  customContent?: React.ReactNode;
}

export default function StandardFooter({
  showPoweredBy = true,
  customContent,
}: StandardFooterProps) {
  const insets = useSafeAreaInsets();

  return (
    <View style={[styles.container, { paddingBottom: insets.bottom }]}>
      <LinearGradient
        colors={[colors.headerBg, colors.headerBgSecondary]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={StyleSheet.absoluteFill}
        opacity={0.8}
      />
      
      <View style={styles.content}>
        {customContent || (
          showPoweredBy && (
            <View style={styles.poweredByContainer}>
              <Text style={styles.poweredByText}>Powered by</Text>
              <Text style={styles.brandText}>Wish a Wash ⚡</Text>
            </View>
          )
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    borderTopWidth: 1,
    borderTopColor: colors.headerBorder,
    backgroundColor: colors.headerBg,
  },
  content: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    alignItems: 'center',
    justifyContent: 'center',
  },
  poweredByContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  poweredByText: {
    fontSize: 11,
    color: colors.greyMedium,
    fontWeight: '500',
  },
  brandText: {
    fontSize: 11,
    color: colors.accentMedium,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
});

