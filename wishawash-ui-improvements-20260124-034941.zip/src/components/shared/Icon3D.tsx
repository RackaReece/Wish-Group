import React from 'react';
import { View, StyleSheet, ViewStyle } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

interface Icon3DProps {
  name: keyof typeof Ionicons.glyphMap;
  size?: number;
  color?: string;
  style?: ViewStyle;
  variant?: 'default' | 'earnings' | 'gold' | 'blue' | 'purple';
  shadowIntensity?: 'light' | 'medium' | 'strong';
}

/**
 * 3D Icon Component with enhanced shadows, gradients, and depth effects
 */
export default function Icon3D({
  name,
  size = 24,
  color,
  style,
  variant = 'default',
  shadowIntensity = 'medium',
}: Icon3DProps) {
  // Color variants
  const getVariantColors = () => {
    switch (variant) {
      case 'earnings':
      case 'gold':
        return {
          primary: '#F59E0B',
          secondary: '#FCD34D',
          gradient: ['#F59E0B', '#FCD34D', '#FBBF24'],
          shadow: '#F59E0B',
        };
      case 'blue':
        return {
          primary: '#3B82F6',
          secondary: '#60A5FA',
          gradient: ['#3B82F6', '#60A5FA', '#93C5FD'],
          shadow: '#3B82F6',
        };
      case 'purple':
        return {
          primary: '#8B5CF6',
          secondary: '#A78BFA',
          gradient: ['#8B5CF6', '#A78BFA', '#C4B5FD'],
          shadow: '#8B5CF6',
        };
      default:
        return {
          primary: color || '#87CEEB',
          secondary: color || '#B0E0E6',
          gradient: [color || '#87CEEB', color || '#B0E0E6'],
          shadow: color || '#87CEEB',
        };
    }
  };

  const variantColors = getVariantColors();
  // Use white icon color for better contrast on gradient backgrounds, unless custom color is provided
  const iconColor = color || '#FFFFFF';

  // Shadow intensity settings
  const getShadowConfig = () => {
    switch (shadowIntensity) {
      case 'light':
        return {
          shadowOpacity: 0.25,
          shadowRadius: 4,
          elevation: 6,
          innerShadowOpacity: 0.15,
        };
      case 'strong':
        return {
          shadowOpacity: 0.5,
          shadowRadius: 12,
          elevation: 16,
          innerShadowOpacity: 0.3,
        };
      default: // medium
        return {
          shadowOpacity: 0.35,
          shadowRadius: 8,
          elevation: 10,
          innerShadowOpacity: 0.2,
        };
    }
  };

  const shadowConfig = getShadowConfig();

  // Icon container size (slightly larger to accommodate shadows)
  const containerSize = size + (shadowIntensity === 'strong' ? 12 : shadowIntensity === 'medium' ? 8 : 6);

  return (
    <View
      style={[
        styles.container,
        {
          width: containerSize,
          height: containerSize,
        },
        style,
      ]}
    >
      {/* Outer glow layer */}
      <View
        style={[
          styles.glowLayer,
          {
            width: containerSize,
            height: containerSize,
            borderRadius: containerSize / 2,
            backgroundColor: `${variantColors.shadow}20`,
            shadowColor: variantColors.shadow,
            shadowOffset: { width: 0, height: 0 },
            shadowOpacity: shadowConfig.shadowOpacity * 0.6,
            shadowRadius: shadowConfig.shadowRadius * 1.5,
            elevation: shadowConfig.elevation * 0.8,
          },
        ]}
      />

      {/* Main icon container with gradient background */}
      <View
        style={[
          styles.iconContainer,
          {
            width: size + 8,
            height: size + 8,
            borderRadius: (size + 8) / 2,
            backgroundColor: `${variantColors.primary}15`,
            shadowColor: variantColors.shadow,
            shadowOffset: { width: 0, height: 4 },
            shadowOpacity: shadowConfig.shadowOpacity,
            shadowRadius: shadowConfig.shadowRadius,
            elevation: shadowConfig.elevation,
            borderWidth: 1.5,
            borderColor: `${variantColors.primary}40`,
          },
        ]}
      >
        {/* Gradient overlay for 3D effect */}
        <LinearGradient
          colors={[`${variantColors.primary}25`, `${variantColors.secondary}15`]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={[
            StyleSheet.absoluteFill,
            {
              borderRadius: (size + 8) / 2,
            },
          ]}
        />

        {/* Inner highlight for 3D depth */}
        <View
          style={[
            styles.innerHighlight,
            {
              width: size + 4,
              height: size + 4,
              borderRadius: (size + 4) / 2,
              backgroundColor: 'rgba(255,255,255,0.15)',
            },
          ]}
        />

        {/* Icon */}
        <Ionicons name={name} size={size} color={iconColor} style={styles.icon} />

        {/* Top highlight for 3D effect */}
        <LinearGradient
          colors={['rgba(255,255,255,0.25)', 'transparent']}
          start={{ x: 0.5, y: 0 }}
          end={{ x: 0.5, y: 0.6 }}
          style={[
            styles.topHighlight,
            {
              width: size + 8,
              height: (size + 8) / 2,
              borderRadius: (size + 8) / 2,
            },
          ]}
        />
      </View>

      {/* Bottom shadow for depth */}
      <View
        style={[
          styles.bottomShadow,
          {
            width: size + 6,
            height: size / 3,
            borderRadius: (size + 6) / 2,
            backgroundColor: `${variantColors.shadow}40`,
            shadowColor: variantColors.shadow,
            shadowOffset: { width: 0, height: 2 },
            shadowOpacity: shadowConfig.innerShadowOpacity,
            shadowRadius: shadowConfig.shadowRadius * 0.5,
            elevation: shadowConfig.elevation * 0.5,
            transform: [{ translateX: -(size + 6) / 2 }],
          },
        ]}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
  },
  glowLayer: {
    position: 'absolute',
    top: 0,
    left: 0,
  },
  iconContainer: {
    justifyContent: 'center',
    alignItems: 'center',
    position: 'relative',
    overflow: 'hidden',
  },
  innerHighlight: {
    position: 'absolute',
    top: 2,
    left: 2,
  },
  icon: {
    zIndex: 2,
  },
  topHighlight: {
    position: 'absolute',
    top: 0,
    left: 0,
    zIndex: 1,
  },
  bottomShadow: {
    position: 'absolute',
    bottom: -2,
    left: '50%',
    transform: [{ translateX: -25 }],
    zIndex: 0,
  },
});
