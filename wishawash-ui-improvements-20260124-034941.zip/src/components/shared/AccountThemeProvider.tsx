import React, { createContext, useContext, ReactNode } from 'react';
import { AccountType, getAccountTheme, AccountTheme } from '../../constants/accountThemes';

interface AccountThemeContextValue {
  accountType: AccountType;
  theme: AccountTheme;
}

const AccountThemeContext = createContext<AccountThemeContextValue | undefined>(undefined);

interface AccountThemeProviderProps {
  accountType: AccountType;
  children: ReactNode;
}

export function AccountThemeProvider({ accountType, children }: AccountThemeProviderProps) {
  const theme = getAccountTheme(accountType);

  return (
    <AccountThemeContext.Provider value={{ accountType, theme }}>
      {children}
    </AccountThemeContext.Provider>
  );
}

export function useAccountTheme(): AccountThemeContextValue {
  const context = useContext(AccountThemeContext);
  if (!context) {
    // Default to customer theme if no provider
    return {
      accountType: 'customer',
      theme: getAccountTheme('customer'),
    };
  }
  return context;
}

