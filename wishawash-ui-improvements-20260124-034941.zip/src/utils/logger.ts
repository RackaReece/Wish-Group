/**
 * Centralised logging utility
 * Replaces console.log/warn/error with a proper logging service
 * In production, this can be connected to analytics/error tracking services
 */

import { errorHandlingService } from '../services/ErrorHandlingService';

type LogLevel = 'debug' | 'info' | 'warn' | 'error';

class Logger {
  private isDevelopment = __DEV__;

  private log(level: LogLevel, message: string, ...args: any[]): void {
    if (!this.isDevelopment && level === 'debug') {
      return; // Don't log debug messages in production
    }

    const timestamp = new Date().toISOString();
    const prefix = `[${timestamp}] [${level.toUpperCase()}]`;

    switch (level) {
      case 'debug':
      case 'info':
        if (this.isDevelopment) {
          console.log(prefix, message, ...args);
        }
        break;
      case 'warn':
        if (this.isDevelopment) {
          console.warn(prefix, message, ...args);
        }
        break;
      case 'error':
        // Always log errors, even in production (but don't expose sensitive data)
        if (this.isDevelopment) {
          console.error(prefix, message, ...args);
        }
        // In production, send to error tracking service
        break;
    }
  }

  debug(message: string, ...args: any[]): void {
    this.log('debug', message, ...args);
  }

  info(message: string, ...args: any[]): void {
    this.log('info', message, ...args);
  }

  warn(message: string, ...args: any[]): void {
    this.log('warn', message, ...args);
  }

  error(message: string, error?: Error, context?: any): void {
    this.log('error', message, error, context);
    
    // Create error in error handling service
    if (error) {
      errorHandlingService.handleSystemError(error);
    }
  }

  // Specialised error logging methods
  networkError(operation: string, error: any): void {
    this.error(`Network error in ${operation}`, error);
    errorHandlingService.handleNetworkError(error, operation);
  }

  bookingError(bookingType: string, error: any): void {
    this.error(`Booking error for ${bookingType}`, error);
    errorHandlingService.handleBookingError(error, bookingType);
  }

  validationError(field: string, value: any, rule: string): void {
    this.warn(`Validation error: ${field} failed ${rule}`, { field, value });
    errorHandlingService.handleValidationError(field, value, rule);
  }
}

export const logger = new Logger();
