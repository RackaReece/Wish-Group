// Shared types for booking-related components

export type Hub = {
  id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
  status?: string | null;
  wait_time_minutes?: number | null;
  organization_id?: string | null;
};

