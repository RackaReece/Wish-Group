import * as ImagePicker from 'expo-image-picker';

export interface UploadedDocument {
  id: string;
  name: string;
  type: 'photo' | 'document' | 'pdf';
  uri: string;
  size: number;
  mimeType: string;
  uploadDate: Date;
  status: 'pending' | 'uploading' | 'completed' | 'failed';
  progress: number;
  verificationStatus: 'pending' | 'approved' | 'rejected';
  rejectionReason?: string;
}

export interface UploadProgress {
  documentId: string;
  progress: number;
  status: 'uploading' | 'completed' | 'failed';
  error?: string;
}

export class SimpleDocumentUploadService {
  private static instance: SimpleDocumentUploadService;
  private documents: Map<string, UploadedDocument> = new Map();
  private progressListeners: Map<string, (progress: UploadProgress) => void> = new Map();

  static getInstance(): SimpleDocumentUploadService {
    if (!SimpleDocumentUploadService.instance) {
      SimpleDocumentUploadService.instance = new SimpleDocumentUploadService();
    }
    return SimpleDocumentUploadService.instance;
  }

  private createDocFromPickerResult(
    documentType: string,
    result: ImagePicker.ImagePickerResult
  ): UploadedDocument | null {
    if (result.canceled) return null;

    const asset = result.assets?.[0];
    if (!asset?.uri) return null;

    const documentId = `doc_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;

    const extension =
      asset.fileName?.split('.').pop()?.toLowerCase() ||
      (asset.mimeType === 'image/png' ? 'png' : 'jpg');

    const fileName =
      asset.fileName ??
      `${documentType.replace(/[^\w.\-]+/g, '_')}_${Date.now()}.${extension}`;

    const mimeType =
      asset.mimeType ??
      (fileName.toLowerCase().endsWith('.png') ? 'image/png' : 'image/jpeg');

    const size = typeof asset.fileSize === 'number' ? asset.fileSize : 0;

    const document: UploadedDocument = {
      id: documentId,
      name: fileName,
      type: 'photo',
      uri: asset.uri,
      size,
      mimeType,
      uploadDate: new Date(),
      status: 'pending',
      progress: 0,
      verificationStatus: 'pending',
    };

    this.documents.set(documentId, document);
    return document;
  }

  /**
   * ✅ Cross-version mediaTypes helper:
   * Some Expo Go / expo-image-picker versions don't have ImagePicker.MediaType.
   * Using string array is the most compatible.
   */
  private imagesOnlyMediaTypes(): any {
    // Prefer legacy enum if present (older versions)
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const anyPicker: any = ImagePicker as any;

    if (anyPicker?.MediaTypeOptions?.Images) return anyPicker.MediaTypeOptions.Images;

    // Newer style supported by recent versions
    // Use as any to avoid type mismatch across versions
    return ['images'] as any;
  }

  // ✅ REAL camera
  async takePhoto(documentType: string): Promise<UploadedDocument | null> {
    const perm = await ImagePicker.requestCameraPermissionsAsync();
    if (!perm.granted) {
      throw new Error('Camera permission is required to take a photo.');
    }

    const result = await ImagePicker.launchCameraAsync({
      mediaTypes: this.imagesOnlyMediaTypes(),
      quality: 0.85,
      allowsEditing: false,
      exif: false,
      // ✅ ensures file:// uri (helps later with uploading)
      copyToCacheDirectory: true,
    } as any);

    return this.createDocFromPickerResult(documentType, result);
  }

  // ✅ REAL photo library picker
  async pickPhoto(documentType: string): Promise<UploadedDocument | null> {
    const perm = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (!perm.granted) {
      throw new Error('Photo library permission is required to choose a photo.');
    }

    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: this.imagesOnlyMediaTypes(),
      quality: 0.85,
      allowsEditing: false,
      exif: false,
      selectionLimit: 1,
      copyToCacheDirectory: true,
    } as any);

    return this.createDocFromPickerResult(documentType, result);
  }

  async pickDocument(documentType: string): Promise<UploadedDocument | null> {
    return this.pickPhoto(documentType);
  }

  async uploadDocument(documentId: string): Promise<boolean> {
    const document = this.documents.get(documentId);
    if (!document) throw new Error('Document not found');

    try {
      document.status = 'uploading';
      document.progress = 0;
      this.documents.set(documentId, document);

      const uploadSteps = 10;
      for (let i = 0; i <= uploadSteps; i++) {
        await new Promise((resolve) => setTimeout(resolve, 120));
        document.progress = (i / uploadSteps) * 100;
        this.documents.set(documentId, document);

        this.notifyProgressListeners(documentId, {
          documentId,
          progress: document.progress,
          status: 'uploading',
        });
      }

      document.status = 'completed';
      document.progress = 100;
      document.verificationStatus = 'pending';
      this.documents.set(documentId, document);

      this.notifyProgressListeners(documentId, {
        documentId,
        progress: 100,
        status: 'completed',
      });

      return true;
    } catch (error) {
      document.status = 'failed';
      document.progress = 0;
      this.documents.set(documentId, document);

      this.notifyProgressListeners(documentId, {
        documentId,
        progress: 0,
        status: 'failed',
        error: error instanceof Error ? error.message : 'Upload failed',
      });

      throw error;
    }
  }

  getUserDocuments(userId: string): UploadedDocument[] {
    return Array.from(this.documents.values())
      .filter((doc) => doc.id.startsWith(userId))
      .sort((a, b) => b.uploadDate.getTime() - a.uploadDate.getTime());
  }

  getDocument(documentId: string): UploadedDocument | undefined {
    return this.documents.get(documentId);
  }

  getUploadProgress(documentId: string): number {
    return this.documents.get(documentId)?.progress ?? 0;
  }

  async deleteDocument(documentId: string): Promise<boolean> {
    if (!this.documents.has(documentId)) return false;
    this.documents.delete(documentId);
    return true;
  }

  updateDocumentStatus(
    documentId: string,
    status: 'pending' | 'approved' | 'rejected',
    rejectionReason?: string
  ): boolean {
    const document = this.documents.get(documentId);
    if (!document) return false;

    document.verificationStatus = status;
    if (rejectionReason) document.rejectionReason = rejectionReason;
    this.documents.set(documentId, document);
    return true;
  }

  addProgressListener(documentId: string, listener: (progress: UploadProgress) => void): void {
    this.progressListeners.set(documentId, listener);
  }

  removeProgressListener(documentId: string): void {
    this.progressListeners.delete(documentId);
  }

  formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  }

  clearAll(): void {
    this.documents.clear();
    this.progressListeners.clear();
  }

  private notifyProgressListeners(documentId: string, progress: UploadProgress): void {
    const listener = this.progressListeners.get(documentId);
    if (listener) listener(progress);
  }
}

export const simpleDocumentUploadService = SimpleDocumentUploadService.getInstance();
