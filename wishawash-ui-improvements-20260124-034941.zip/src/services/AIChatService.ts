// AI Chat Service for Wish a Wash
export interface ChatMessage {
  id: string;
  text: string;
  sender: 'user' | 'ai';
  timestamp: Date;
  type: 'text' | 'quick_reply' | 'booking_suggestion';
}

export interface QuickReply {
  id: string;
  text: string;
  action?: string;
}

class AIChatService {
  private static instance: AIChatService;
  private conversationHistory: Map<string, ChatMessage[]> = new Map();

  static getInstance(): AIChatService {
    if (!AIChatService.instance) {
      AIChatService.instance = new AIChatService();
    }
    return AIChatService.instance;
  }

  // Wish a Wash knowledge base
  private wishAWashKnowledge = {
    services: {
      instant_wash: {
        name: "Instant Wash",
        description: "Quick 15-minute exterior wash service",
        price: "£15-25",
        features: ["Exterior wash", "Tire cleaning", "Window cleaning", "Quick service"]
      },
      priority_wash: {
        name: "Local Priority Wash",
        description: "Premium service with priority booking",
        price: "£25-40",
        features: ["Full exterior wash", "Interior cleaning", "Priority booking", "Premium finish"]
      },
      full_valet: {
        name: "Full Valet",
        description: "Complete interior and exterior cleaning",
        price: "£40-80",
        features: ["Full exterior wash", "Interior vacuum", "Dashboard cleaning", "Window cleaning", "Tire dressing"]
      }
    },
    valeter_info: {
      requirements: ["Valid driving license", "Insurance", "DBS check", "Vehicle registration"],
      earnings: "£15-30 per hour depending on experience and location",
      benefits: ["Flexible hours", "Own vehicle", "Commission bonuses", "Training provided"]
    },
    booking_process: {
      steps: ["Select service", "Choose location", "Pick date/time", "Confirm booking", "Track valeter"],
      payment: "Secure payment via card or mobile payment",
      cancellation: "Free cancellation up to 2 hours before service"
    },
    locations: "Available across London and major UK cities",
    contact: "Support available 24/7 via chat or phone"
  };

  async sendMessage(userId: string, message: string, userType: 'customer' | 'valeter'): Promise<ChatMessage[]> {
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text: message,
      sender: 'user',
      timestamp: new Date(),
      type: 'text'
    };

    // Add user message to history
    this.addMessageToHistory(userId, userMessage);

    // Generate AI response
    const aiResponse = await this.generateAIResponse(message, userType);
    
    // Add AI response to history
    this.addMessageToHistory(userId, aiResponse);

    return this.getConversationHistory(userId);
  }

  private async generateAIResponse(message: string, userType: 'customer' | 'valeter'): Promise<ChatMessage> {
    const lowerMessage = message.toLowerCase();
    
    // Customer-specific responses
    if (userType === 'customer') {
      if (lowerMessage.includes('book') || lowerMessage.includes('booking') || lowerMessage.includes('schedule')) {
        return {
          id: Date.now().toString(),
          text: "I'd be happy to help you book a service! 🚗\n\nWe offer:\n• Instant Wash (£15-25) - 15 min exterior wash\n• Priority Wash (£25-40) - Premium service with priority\n• Full Valet (£40-80) - Complete interior & exterior\n\nWould you like me to guide you through the booking process?",
          sender: 'ai',
          timestamp: new Date(),
          type: 'booking_suggestion'
        };
      }

      if (lowerMessage.includes('price') || lowerMessage.includes('cost') || lowerMessage.includes('how much')) {
        return {
          id: Date.now().toString(),
          text: "Here are our current prices: 💰\n\n• Instant Wash: £15-25\n• Priority Wash: £25-40\n• Full Valet: £40-80\n\nPrices vary based on vehicle size and location. Would you like a specific quote?",
          sender: 'ai',
          timestamp: new Date(),
          type: 'text'
        };
      }

      if (lowerMessage.includes('service') || lowerMessage.includes('wash') || lowerMessage.includes('valet')) {
        return {
          id: Date.now().toString(),
          text: "Our services include:\n\n• Instant Wash: Quick exterior cleaning\n• Priority Wash: Premium service with priority booking\n• Full Valet: Complete interior and exterior cleaning\n\nAll services are mobile and come to your location!",
          sender: 'ai',
          timestamp: new Date(),
          type: 'text'
        };
      }

      if (lowerMessage.includes('track') || lowerMessage.includes('where') || lowerMessage.includes('location')) {
        return {
          id: Date.now().toString(),
          text: "You can track your valeter in real-time! 📍\n\nOnce your booking is confirmed, you'll receive a tracking link to see exactly where your valeter is and when they'll arrive. The app also sends notifications when they're on their way.",
          sender: 'ai',
          timestamp: new Date(),
          type: 'text'
        };
      }

      if (lowerMessage.includes('cancel') || lowerMessage.includes('refund')) {
        return {
          id: Date.now().toString(),
          text: "Cancellation Policy: 📋\n\n• Free cancellation up to 2 hours before your service\n• Late cancellations may incur a small fee\n• Refunds are processed within 3-5 business days\n\nNeed help cancelling a booking?",
          sender: 'ai',
          timestamp: new Date(),
          type: 'text'
        };
      }
    }

    // Valeter-specific responses
    if (userType === 'valeter') {
      if (lowerMessage.includes('earn') || lowerMessage.includes('money') || lowerMessage.includes('pay')) {
        return {
          id: Date.now().toString(),
          text: "Earnings Information: 💰\n\n• Base rate: £15-30 per hour\n• Commission bonuses for high ratings\n• Weekly performance bonuses\n• Tips from satisfied customers\n\nYour earnings depend on experience, location, and customer ratings!",
          sender: 'ai',
          timestamp: new Date(),
          type: 'text'
        };
      }

      if (lowerMessage.includes('job') || lowerMessage.includes('work') || lowerMessage.includes('available')) {
        return {
          id: Date.now().toString(),
          text: "Job Availability: 🚗\n\n• Jobs are available 24/7\n• Peak times: Weekends and evenings\n• Set your own working hours\n• Choose jobs within your radius\n\nMake sure you're online to receive job notifications!",
          sender: 'ai',
          timestamp: new Date(),
          type: 'text'
        };
      }

      if (lowerMessage.includes('requirement') || lowerMessage.includes('document') || lowerMessage.includes('license')) {
        return {
          id: Date.now().toString(),
          text: "Requirements to become a valeter: 📋\n\n• Valid UK driving license\n• Vehicle insurance\n• DBS background check\n• Vehicle registration\n• Profile photo\n\nOnce verified, you can start accepting jobs!",
          sender: 'ai',
          timestamp: new Date(),
          type: 'text'
        };
      }

      if (lowerMessage.includes('rating') || lowerMessage.includes('review') || lowerMessage.includes('feedback')) {
        return {
          id: Date.now().toString(),
          text: "Rating System: ⭐\n\n• Customers rate you after each service\n• Higher ratings = more job opportunities\n• 4.5+ stars get priority job access\n• Regular feedback helps you improve\n\nFocus on quality service to maintain high ratings!",
          sender: 'ai',
          timestamp: new Date(),
          type: 'text'
        };
      }
    }

    // General responses
    if (lowerMessage.includes('hello') || lowerMessage.includes('hi') || lowerMessage.includes('hey')) {
      return {
        id: Date.now().toString(),
        text: `Hello! I'm your Wish a Wash assistant. I can help you with:\n\n${userType === 'customer' ? 
          '• Booking services\n• Checking prices\n• Tracking your valeter\n• Cancellation policies' : 
          '• Job opportunities\n• Earnings information\n• Requirements\n• Rating system'}\n\nHow can I help you today?`,
        sender: 'ai',
        timestamp: new Date(),
        type: 'text'
      };
    }

    if (lowerMessage.includes('help') || lowerMessage.includes('support')) {
      return {
        id: Date.now().toString(),
        text: "I'm here to help! 🤝\n\nYou can ask me about:\n• Services and pricing\n• Booking process\n• Account issues\n• General questions\n\nOr type 'menu' to see all options.",
        sender: 'ai',
        timestamp: new Date(),
        type: 'text'
      };
    }

    if (lowerMessage.includes('contact') || lowerMessage.includes('phone') || lowerMessage.includes('email')) {
      return {
        id: Date.now().toString(),
        text: "Contact Information: 📞\n\n• 24/7 Support: +44 800 123 4567\n• Email: support@wishawash.com\n• Live Chat: Available in app\n• Emergency: +44 800 999 9999\n\nWe're here to help anytime!",
        sender: 'ai',
        timestamp: new Date(),
        type: 'text'
      };
    }

    // Default response
    return {
      id: Date.now().toString(),
      text: "I understand you're asking about that! 🤔\n\nCould you please be more specific? I can help with:\n• Service information\n• Booking assistance\n• Account support\n• General questions\n\nWhat would you like to know?",
      sender: 'ai',
      timestamp: new Date(),
      type: 'text'
    };
  }

  addMessageToHistory(userId: string, message: ChatMessage): void {
    if (!this.conversationHistory.has(userId)) {
      this.conversationHistory.set(userId, []);
    }
    this.conversationHistory.get(userId)!.push(message);
  }

  getConversationHistory(userId: string): ChatMessage[] {
    return this.conversationHistory.get(userId) || [];
  }

  clearConversation(userId: string): void {
    this.conversationHistory.delete(userId);
  }

  getQuickReplies(userType: 'customer' | 'valeter'): QuickReply[] {
    if (userType === 'customer') {
      return [
        { id: '1', text: 'Book a service', action: 'book' },
        { id: '2', text: 'Check prices', action: 'prices' },
        { id: '3', text: 'Track my valeter', action: 'track' },
        { id: '4', text: 'Cancel booking', action: 'cancel' },
        { id: '5', text: 'Contact support', action: 'contact' }
      ];
    } else {
      return [
        { id: '1', text: 'Job opportunities', action: 'jobs' },
        { id: '2', text: 'Earnings info', action: 'earnings' },
        { id: '3', text: 'Requirements', action: 'requirements' },
        { id: '4', text: 'Rating system', action: 'ratings' },
        { id: '5', text: 'Contact support', action: 'contact' }
      ];
    }
  }
}

export const aiChatService = AIChatService.getInstance();

