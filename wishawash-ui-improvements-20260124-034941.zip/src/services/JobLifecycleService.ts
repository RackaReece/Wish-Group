export interface JobStatus {
  id: string;
  status: 'pending' | 'accepted' | 'in_progress' | 'nearly_done' | 'completed' | 'cancelled';
  timestamp: Date;
  message: string;
}

export interface JobRating {
  id: string;
  jobId: string;
  customerId: string;
  valeterId: string;
  rating: number; // 1-5 stars
  review: string;
  tip: number; // Amount in pence
  createdAt: Date;
}

export interface JobDetails {
  id: string;
  customerId: string;
  valeterId?: string;
  serviceType: string;
  vehicleCategory: string;
  washMethod: string;
  location: {
    lat: number;
    lng: number;
    address: string;
  };
  price: number;
  status: JobStatus[];
  rating?: JobRating;
  createdAt: Date;
  startedAt?: Date;
  completedAt?: Date;
  estimatedDuration: string;
  actualDuration?: string;
  specialInstructions?: string;
  addons: string[];
}

export class JobLifecycleService {
  private static instance: JobLifecycleService;
  private jobs: Map<string, JobDetails> = new Map();
  private ratings: Map<string, JobRating> = new Map();

  static getInstance(): JobLifecycleService {
    if (!JobLifecycleService.instance) {
      JobLifecycleService.instance = new JobLifecycleService();
    }
    return JobLifecycleService.instance;
  }

  // Create a new job
  createJob(
    customerId: string,
    serviceType: string,
    vehicleCategory: string,
    washMethod: string,
    location: { lat: number; lng: number; address: string },
    price: number,
    addons: string[] = [],
    specialInstructions?: string
  ): string {
    const jobId = `job_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const job: JobDetails = {
      id: jobId,
      customerId,
      serviceType,
      vehicleCategory,
      washMethod,
      location,
      price,
      addons,
      specialInstructions,
      status: [
        {
          id: `status_${Date.now()}`,
          status: 'pending',
          timestamp: new Date(),
          message: 'Job created and waiting for valeter to accept'
        }
      ],
      createdAt: new Date(),
      estimatedDuration: this.getEstimatedDuration(washMethod, vehicleCategory)
    };

    this.jobs.set(jobId, job);
    return jobId;
  }

  // Get job by ID
  getJob(jobId: string): JobDetails | undefined {
    return this.jobs.get(jobId);
  }

  // Get all jobs for a user (customer or valeter)
  getUserJobs(userId: string, userType: 'customer' | 'valeter'): JobDetails[] {
    const jobs = Array.from(this.jobs.values());
    if (userType === 'customer') {
      return jobs.filter(job => job.customerId === userId);
    } else {
      return jobs.filter(job => job.valeterId === userId);
    }
  }

  // Get available jobs for valeters
  getAvailableJobs(): JobDetails[] {
    return Array.from(this.jobs.values()).filter(job => 
      job.status[job.status.length - 1].status === 'pending'
    );
  }

  // Accept job by valeter
  acceptJob(jobId: string, valeterId: string): boolean {
    const job = this.jobs.get(jobId);
    if (!job || job.status[job.status.length - 1].status !== 'pending') {
      return false;
    }

    job.valeterId = valeterId;
    job.status.push({
      id: `status_${Date.now()}`,
      status: 'accepted',
      timestamp: new Date(),
      message: 'Valeter accepted the job and is on the way'
    });

    this.jobs.set(jobId, job);
    return true;
  }

  // Start job
  startJob(jobId: string): boolean {
    const job = this.jobs.get(jobId);
    if (!job || job.status[job.status.length - 1].status !== 'accepted') {
      return false;
    }

    job.startedAt = new Date();
    job.status.push({
      id: `status_${Date.now()}`,
      status: 'in_progress',
      timestamp: new Date(),
      message: 'Valeter has started the car wash service'
    });

    this.jobs.set(jobId, job);
    return true;
  }

  // Update job to nearly done
  updateJobNearlyDone(jobId: string): boolean {
    const job = this.jobs.get(jobId);
    if (!job || job.status[job.status.length - 1].status !== 'in_progress') {
      return false;
    }

    job.status.push({
      id: `status_${Date.now()}`,
      status: 'nearly_done',
      timestamp: new Date(),
      message: 'Car wash is nearly complete'
    });

    this.jobs.set(jobId, job);
    return true;
  }

  // Complete job
  completeJob(jobId: string): boolean {
    const job = this.jobs.get(jobId);
    if (!job || job.status[job.status.length - 1].status !== 'nearly_done') {
      return false;
    }

    job.completedAt = new Date();
    if (job.startedAt) {
      const duration = Math.round((job.completedAt.getTime() - job.startedAt.getTime()) / 60000);
      job.actualDuration = `${duration} minutes`;
    }

    job.status.push({
      id: `status_${Date.now()}`,
      status: 'completed',
      timestamp: new Date(),
      message: 'Car wash completed successfully!'
    });

    this.jobs.set(jobId, job);
    return true;
  }

  // Cancel job
  cancelJob(jobId: string, reason: string): boolean {
    const job = this.jobs.get(jobId);
    if (!job) return false;

    job.status.push({
      id: `status_${Date.now()}`,
      status: 'cancelled',
      timestamp: new Date(),
      message: `Job cancelled: ${reason}`
    });

    this.jobs.set(jobId, job);
    return true;
  }

  // Add rating and tip
  addRating(
    jobId: string,
    customerId: string,
    valeterId: string,
    rating: number,
    review: string,
    tip: number
  ): boolean {
    const job = this.jobs.get(jobId);
    if (!job || job.customerId !== customerId) {
      return false;
    }

    const ratingId = `rating_${Date.now()}`;
    const jobRating: JobRating = {
      id: ratingId,
      jobId,
      customerId,
      valeterId,
      rating,
      review,
      tip,
      createdAt: new Date()
    };

    this.ratings.set(ratingId, jobRating);
    job.rating = jobRating;
    this.jobs.set(jobId, job);

    return true;
  }

  // Get job rating
  getJobRating(jobId: string): JobRating | undefined {
    const job = this.jobs.get(jobId);
    return job?.rating;
  }

  // Get valeter average rating
  getValeterAverageRating(valeterId: string): { average: number; total: number } {
    const valeterRatings = Array.from(this.ratings.values())
      .filter(rating => rating.valeterId === valeterId);

    if (valeterRatings.length === 0) {
      return { average: 0, total: 0 };
    }

    const totalRating = valeterRatings.reduce((sum, rating) => sum + rating.rating, 0);
    const average = totalRating / valeterRatings.length;

    return { average: Math.round(average * 10) / 10, total: valeterRatings.length };
  }

  // Get current job status
  getCurrentStatus(jobId: string): JobStatus | undefined {
    const job = this.jobs.get(jobId);
    if (!job || job.status.length === 0) return undefined;
    return job.status[job.status.length - 1];
  }

  // Get job progress percentage
  getJobProgress(jobId: string): number {
    const job = this.jobs.get(jobId);
    if (!job) return 0;

    const currentStatus = this.getCurrentStatus(jobId);
    if (!currentStatus) return 0;

    switch (currentStatus.status) {
      case 'pending': return 10;
      case 'accepted': return 30;
      case 'in_progress': return 60;
      case 'nearly_done': return 90;
      case 'completed': return 100;
      case 'cancelled': return 0;
      default: return 0;
    }
  }

  // Get estimated duration based on wash method and vehicle
  private getEstimatedDuration(washMethod: string, vehicleCategory: string): string {
    const baseDurations: { [key: string]: number } = {
      'exterior_only': 15,
      'standard_wash': 30,
      'luxury_exterior': 45,
      'luxury_full': 90
    };

    const vehicleMultipliers: { [key: string]: number } = {
      'small': 0.8,
      'medium': 1.0,
      'large': 1.3,
      'luxury': 1.2
    };

    const baseDuration = baseDurations[washMethod] || 30;
    const multiplier = vehicleMultipliers[vehicleCategory] || 1.0;
    const estimatedMinutes = Math.round(baseDuration * multiplier);

    return `${estimatedMinutes} minutes`;
  }

  // Get job statistics
  getJobStats(userId: string, userType: 'customer' | 'valeter'): {
    total: number;
    completed: number;
    cancelled: number;
    averageRating: number;
    totalEarnings: number;
  } {
    const userJobs = this.getUserJobs(userId, userType);
    
    const completed = userJobs.filter(job => 
      job.status[job.status.length - 1].status === 'completed'
    ).length;

    const cancelled = userJobs.filter(job => 
      job.status[job.status.length - 1].status === 'cancelled'
    ).length;

    const totalEarnings = userJobs
      .filter(job => job.status[job.status.length - 1].status === 'completed')
      .reduce((sum, job) => sum + job.price, 0);

    let averageRating = 0;
    if (userType === 'valeter') {
      const { average } = this.getValeterAverageRating(userId);
      averageRating = average;
    }

    return {
      total: userJobs.length,
      completed,
      cancelled,
      averageRating,
      totalEarnings
    };
  }

  // Simulate job updates (for demo purposes)
  simulateJobUpdates(jobId: string): void {
    const job = this.jobs.get(jobId);
    if (!job) return;

    // Simulate automatic status updates
    setTimeout(() => {
      if (this.getCurrentStatus(jobId)?.status === 'accepted') {
        this.startJob(jobId);
      }
    }, 5000);

    setTimeout(() => {
      if (this.getCurrentStatus(jobId)?.status === 'in_progress') {
        this.updateJobNearlyDone(jobId);
      }
    }, 15000);

    setTimeout(() => {
      if (this.getCurrentStatus(jobId)?.status === 'nearly_done') {
        this.completeJob(jobId);
      }
    }, 20000);
  }
}

export const jobLifecycleService = JobLifecycleService.getInstance();
