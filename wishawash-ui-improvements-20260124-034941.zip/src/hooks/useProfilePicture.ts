import { useState, useEffect } from 'react';
import { useAuth } from '../providers/enhanced-auth-context';
import { supabase } from '../lib/supabase';

export function useProfilePicture() {
  const { user } = useAuth();
  const [profilePicture, setProfilePicture] = useState<string | null>(null);

  useEffect(() => {
    if (!user?.id) return;

    const loadProfilePicture = async () => {
      try {
        // Load from profiles table first
        const { data: profileData } = await supabase
          .from('profiles')
          .select('profile_picture')
          .eq('id', user.id)
          .maybeSingle();

        if (profileData?.profile_picture) {
          const cleanUrl = (url: string) => url?.trim().replace(/[?#].*$/, '') || '';
          const clean = cleanUrl(profileData.profile_picture);
          setProfilePicture(`${clean}?v=${Date.now()}`);
          return;
        }

        // Try to resolve from storage
        const folder = `users/${user.id}`;
        const { data: files } = await supabase.storage
          .from('uploads')
          .list(folder, { limit: 50 });

        if (files && files.length > 0) {
          const preferred = files.find((f: any) =>
            String(f?.name || '').toLowerCase().startsWith('profile_picture')
          ) || files[0];

          if (preferred?.name) {
            const path = `${folder}/${preferred.name}`;
            const { data: publicData } = supabase.storage.from('uploads').getPublicUrl(path);
            if (publicData?.publicUrl) {
              setProfilePicture(`${publicData.publicUrl}?v=${Date.now()}`);
            }
          }
        }
      } catch (err) {
        console.warn('[useProfilePicture] Failed to load:', err);
      }
    };

    loadProfilePicture();
  }, [user?.id]);

  return profilePicture;
}
