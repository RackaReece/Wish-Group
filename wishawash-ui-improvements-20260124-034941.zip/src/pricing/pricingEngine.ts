/**
 * Frontend-Only Pricing Engine
 * 
 * This module provides a centralized pricing calculation system for mobile wash services.
 * All pricing logic is frontend-only and used for UI display. The backend continues to
 * accept price values as-is without any changes.
 * 
 * To adjust prices in the future:
 * - Update basePriceSmallGBP in WASH_DEFINITIONS array
 * - Modify getVehicleSizeAdjustmentGBP() for size adjustments
 * 
 * To change surge rules:
 * - Modify getSurgeInfo() function (weekday peak hours, weekend multipliers)
 * 
 * To tweak distance logic:
 * - Modify getDistanceSurchargeGBP() (included miles, per-mile rate)
 */

export type VehicleSize = 'SMALL' | 'MEDIUM' | 'LARGE' | 'XL';

export type WashTier = 'BRONZE' | 'SILVER' | 'GOLD' | 'PLATINUM';

export interface WashDefinition {
  id: string;
  label: string;
  description: string;
  tier: WashTier;
  isEco: boolean;
  isMobile: boolean;
  isPhysicalLocation: boolean;
  basePriceSmallGBP: number; // base price for SMALL vehicle, mobile valet
}

export interface SurgeInfo {
  multiplier: number;   // 1.0 = no surge, 1.10 = 10% extra
  label?: string;
}

export interface FrontendPricingInput {
  washId: string;
  vehicleSize: VehicleSize;
  isMobile: boolean;
  isPhysicalLocation: boolean;
  distanceMiles?: number;
  scheduledDateTime: Date;
}

export interface FrontendPricingBreakdown {
  basePriceGBP: number;
  vehicleSizeAdjustmentGBP: number;
  distanceSurchargeGBP: number;
  surgeMultiplier: number;
  surgeLabel?: string;
  finalDisplayPriceGBP: number;
}

/**
 * Single source of truth for all wash service definitions
 * Base prices are for SMALL vehicles in mobile valet service
 */
export const WASH_DEFINITIONS: WashDefinition[] = [
  {
    id: 'MOBILE_BRONZE',
    label: 'Bronze Wash',
    description: 'Exterior OR interior only. Quick clean.',
    tier: 'BRONZE',
    isEco: false,
    isMobile: true,
    isPhysicalLocation: false,
    basePriceSmallGBP: 12,
  },
  {
    id: 'MOBILE_SILVER',
    label: 'Silver Wash',
    description: 'Exterior + interior. Standard full wash.',
    tier: 'SILVER',
    isEco: false,
    isMobile: true,
    isPhysicalLocation: false,
    basePriceSmallGBP: 20,
  },
  {
    id: 'MOBILE_GOLD',
    label: 'Gold Wash',
    description: 'Deep clean, wheels, trims, interior wipe-down.',
    tier: 'GOLD',
    isEco: false,
    isMobile: true,
    isPhysicalLocation: false,
    basePriceSmallGBP: 32,
  },
  {
    id: 'MOBILE_PLATINUM',
    label: 'Platinum Wash',
    description: 'Premium valet-style wash.',
    tier: 'PLATINUM',
    isEco: false,
    isMobile: true,
    isPhysicalLocation: false,
    basePriceSmallGBP: 55,
  },
  {
    id: 'MOBILE_ECO_BRONZE',
    label: 'Eco Bronze Wash',
    description: 'Eco products, exterior OR interior.',
    tier: 'BRONZE',
    isEco: true,
    isMobile: true,
    isPhysicalLocation: false,
    basePriceSmallGBP: 15,
  },
  {
    id: 'MOBILE_ECO_SILVER',
    label: 'Eco Silver Wash',
    description: 'Eco products, exterior + interior.',
    tier: 'SILVER',
    isEco: true,
    isMobile: true,
    isPhysicalLocation: false,
    basePriceSmallGBP: 23,
  },
  {
    id: 'MOBILE_ECO_GOLD',
    label: 'Eco Gold Wash',
    description: 'Eco deep clean, wheels, trims, interior.',
    tier: 'GOLD',
    isEco: true,
    isMobile: true,
    isPhysicalLocation: false,
    basePriceSmallGBP: 36,
  },
  {
    id: 'MOBILE_ECO_PLATINUM',
    label: 'Eco Platinum Wash',
    description: 'Eco premium valet-style wash.',
    tier: 'PLATINUM',
    isEco: true,
    isMobile: true,
    isPhysicalLocation: false,
    basePriceSmallGBP: 60,
  },
];

/**
 * Vehicle size adjustment pricing
 * Adjustments are added to base price
 */
export function getVehicleSizeAdjustmentGBP(size: VehicleSize): number {
  switch (size) {
    case 'SMALL':
      return 0;
    case 'MEDIUM':
      return 2;
    case 'LARGE':
      return 4;
    case 'XL':
      return 7;
  }
}

/**
 * Surge pricing calculation
 * Weekday peak (Mon-Fri, 16:00-19:00): +10%
 * Weekends (Sat/Sun): +15%
 */
export function getSurgeInfo(dateTime: Date): SurgeInfo {
  const day = dateTime.getDay(); // 0 = Sun, 6 = Sat
  const hour = dateTime.getHours();

  const isWeekend = day === 0 || day === 6;
  if (isWeekend) {
    return { multiplier: 1.15, label: 'Weekend demand' };
  }

  const isPeakWeekday = hour >= 16 && hour < 19;
  if (isPeakWeekday) {
    return { multiplier: 1.1, label: 'Peak time pricing' };
  }

  return { multiplier: 1, label: undefined };
}

/**
 * Distance surcharge calculation
 * First 4 miles included, then £0.50 per additional mile
 */
export function getDistanceSurchargeGBP(distanceMiles: number | undefined): number {
  if (!distanceMiles) return 0;
  const includedMiles = 4;
  if (distanceMiles <= includedMiles) return 0;
  const extraMiles = Math.max(0, distanceMiles - includedMiles);
  return extraMiles * 0.5;
}

/**
 * Infer vehicle size from DVLA make/model data
 * Uses heuristics based on common vehicle makes/models
 */
export function inferVehicleSizeFromDVLA(make: string, model: string): VehicleSize {
  const makeLower = make.toLowerCase();
  const modelLower = model.toLowerCase();

  // XL vehicles (large vans, trucks)
  if (
    modelLower.includes('transit') ||
    modelLower.includes('sprinter') ||
    modelLower.includes('vivaro') ||
    modelLower.includes('master') ||
    modelLower.includes('crafter') ||
    makeLower.includes('ldv') ||
    modelLower.includes('boxer')
  ) {
    return 'XL';
  }

  // LARGE vehicles (SUVs, large cars)
  if (
    modelLower.includes('range rover') ||
    modelLower.includes('discovery') ||
    modelLower.includes('x5') ||
    modelLower.includes('x7') ||
    modelLower.includes('q7') ||
    modelLower.includes('q8') ||
    modelLower.includes('gle') ||
    modelLower.includes('gls') ||
    modelLower.includes('cayenne') ||
    modelLower.includes('macan') ||
    modelLower.includes('touareg') ||
    modelLower.includes('suv') ||
    makeLower.includes('land rover')
  ) {
    return 'LARGE';
  }

  // MEDIUM vehicles (mid-size sedans, estates)
  if (
    modelLower.includes('5 series') ||
    modelLower.includes('e-class') ||
    modelLower.includes('a6') ||
    modelLower.includes('a4') ||
    modelLower.includes('passat') ||
    modelLower.includes('mondeo') ||
    modelLower.includes('insignia') ||
    modelLower.includes('octavia') ||
    modelLower.includes('superb')
  ) {
    return 'MEDIUM';
  }

  // Default to SMALL (hatchbacks, small cars)
  return 'SMALL';
}

/**
 * Infer vehicle size from vehicle type string (fallback)
 */
export function inferVehicleSizeFromType(vehicleType: string): VehicleSize {
  const typeLower = vehicleType.toLowerCase();

  if (typeLower.includes('van') || typeLower.includes('truck') || typeLower.includes('lorry')) {
    return 'XL';
  }

  if (typeLower.includes('suv') || typeLower.includes('4x4')) {
    return 'LARGE';
  }

  if (typeLower.includes('estate') || typeLower.includes('saloon') || typeLower.includes('sedan')) {
    return 'MEDIUM';
  }

  // Default to SMALL for cars, motorcycles, etc.
  return 'SMALL';
}

/**
 * Get vehicle size from vehicle data
 * Prefers DVLA make/model, falls back to vehicle type
 */
export function getVehicleSize(vehicle: { make?: string; model?: string; type?: string }): VehicleSize {
  if (vehicle.make && vehicle.model) {
    return inferVehicleSizeFromDVLA(vehicle.make, vehicle.model);
  }
  
  if (vehicle.type) {
    return inferVehicleSizeFromType(vehicle.type);
  }

  // Default fallback
  return 'SMALL';
}

/**
 * Main pricing calculator
 * Calculates final display price with all adjustments
 */
export function calculateDisplayPrice(input: FrontendPricingInput): FrontendPricingBreakdown {
  const wash = WASH_DEFINITIONS.find(w => w.id === input.washId);
  if (!wash) {
    // Fallback – no wash found, return zeros
    return {
      basePriceGBP: 0,
      vehicleSizeAdjustmentGBP: 0,
      distanceSurchargeGBP: 0,
      surgeMultiplier: 1,
      finalDisplayPriceGBP: 0,
    };
  }

  // Start with base price (SMALL car baseline)
  let price = wash.basePriceSmallGBP;
  const vehicleSizeAdjustmentGBP = getVehicleSizeAdjustmentGBP(input.vehicleSize);
  price += vehicleSizeAdjustmentGBP;

  let distanceSurchargeGBP = 0;
  if (wash.isMobile && input.isMobile) {
    distanceSurchargeGBP = getDistanceSurchargeGBP(input.distanceMiles);
    price += distanceSurchargeGBP;
  }

  let surgeMultiplier = 1;
  let surgeLabel: string | undefined = undefined;
  if (wash.isMobile && input.isMobile) {
    const surge = getSurgeInfo(input.scheduledDateTime);
    surgeMultiplier = surge.multiplier;
    surgeLabel = surge.label;
    price *= surgeMultiplier;
  }

  const finalDisplayPriceGBP = Number(price.toFixed(2));

  return {
    basePriceGBP: wash.basePriceSmallGBP,
    vehicleSizeAdjustmentGBP,
    distanceSurchargeGBP,
    surgeMultiplier,
    surgeLabel,
    finalDisplayPriceGBP,
  };
}

/**
 * Map service ID to wash definition ID
 * Maps existing service IDs to new WASH_DEFINITIONS IDs
 */
export function mapServiceIdToWashId(serviceId: string): string | null {
  const mapping: Record<string, string> = {
    'bronze-wash': 'MOBILE_BRONZE',
    'silver-wash': 'MOBILE_SILVER',
    'gold-wash': 'MOBILE_GOLD',
    'platinum-wash': 'MOBILE_PLATINUM',
    'eco-bronze-wash': 'MOBILE_ECO_BRONZE',
    'eco-silver-wash': 'MOBILE_ECO_SILVER',
    'eco-gold-wash': 'MOBILE_ECO_GOLD',
    'eco-platinum-wash': 'MOBILE_ECO_PLATINUM',
  };

  return mapping[serviceId] || null;
}


