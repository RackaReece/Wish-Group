// Shared customer theme with softer, more subtle blue tones
// Used across all customer-related pages for consistent styling

export const customerTheme = {
  // Background gradient: softer blue to darker navy (reduced intensity)
  backgroundGradient: ['#5B8FA8', '#1A2F4A'] as [string, string],
  
  // Fallback solid background color
  backgroundColor: '#0A1929',
  
  // Header background to match nav tabs (more subtle)
  headerBg: 'rgba(26,47,74,0.25)',
  
  // Primary colors (softer, less intense blues)
  skyBlue: '#5B8FA8', // Softer than #87CEEB
  navyBlue: '#1A2F4A', // Softer than #1E3A8A
  darkNavy: '#0A1929',
  
  // Primary color for header and nav
  primary: '#3B82F6', // Modern blue for Uber-style design
};

