import { customerTheme } from './customerTheme';
import { colors } from './colors';

export type AccountType = 'customer' | 'valeter' | 'business';

export interface AccountTheme {
  primary: string;
  primaryAlt: string;
  background: [string, string];
  headerBackground?: [string, string]; // Optional header-specific background to match nav tabs
  glassBorder: string;
  glassBorderAlt?: string;
  accent: string;
  accentAlt: string;
}

export const accountThemes: Record<AccountType, AccountTheme> = {
  customer: {
    primary: '#3B82F6', // Modern blue for Uber-style design
    primaryAlt: '#2563EB',
    background: customerTheme.backgroundGradient, // Sky blue to navy blue
    headerBackground: ['rgba(59,130,246,0.35)', 'rgba(59,130,246,0.25)'], // Match nav tab colors
    glassBorder: 'rgba(59,130,246,0.3)',
    accent: '#3B82F6',
    accentAlt: '#2563EB',
  },
  valeter: {
    primary: '#10B981', // Vibrant Green
    primaryAlt: '#F59E0B', // Vibrant Yellow
    background: ['#0A1929', '#1E3A8A'],
    glassBorder: 'rgba(16,185,129,0.3)',
    glassBorderAlt: 'rgba(245,158,11,0.3)',
    accent: '#10B981',
    accentAlt: '#F59E0B',
  },
  business: {
    primary: '#84CC16', // Lime Green
    primaryAlt: '#10B981', // Emerald
    background: ['#0A1929', '#065F46'], // Dark green gradient
    glassBorder: 'rgba(132,204,22,0.3)',
    glassBorderAlt: 'rgba(16,185,129,0.3)',
    accent: '#84CC16',
    accentAlt: '#10B981',
  },
};

export const getAccountTheme = (accountType: AccountType): AccountTheme => {
  return accountThemes[accountType];
};

