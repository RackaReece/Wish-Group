# Asset Usage

Reference for all assets in `/assets` and where they are used across the Wish a Wash app.

---

## Images

| Asset | Usage | Locations |
|-------|-------|-----------|
| **car.png** | User/customer marker on maps; vehicle icon in booking flows | `app/owner/booking/index.tsx`, `payment.tsx`, `create.tsx`, `valeter-selection.tsx`, `waiting-acceptance.tsx`, `current-trip.tsx`, `tracking.tsx`, `track.tsx`, `physical/location.tsx`, `physical/service.tsx`, `physical/vehicle.tsx`, `physical/schedule.tsx`, `physical/confirm.tsx`, `detailing/create.tsx`, `detailing/vehicle.tsx`, `detailing/valeter-selection.tsx`, `detailing/schedule.tsx`, `detailing/physical.tsx`, `eco/vehicle.tsx` |
| **cleaning.png** | Wash hub / standard wash service imagery | `app/owner/booking/physical/location.tsx`, `physical/service.tsx`, `physical/schedule.tsx`, `physical/confirm.tsx`, `valeter-selection.tsx`, `waiting-acceptance.tsx`, `tracking.tsx`, `track.tsx` |
| **detailing.png** | Premium detailing service imagery | `app/owner/booking/detailing/valeter-selection.tsx`, `detailing/physical.tsx`, `tracking.tsx`, `track.tsx` |
| **icon-auth.png** | Auth screen logo/branding | `app/auth/login.tsx`, `app/auth/signup.tsx` |
| **icon.png** | App icon, splash screen, adaptive icon; loading screen fallback | `app.config.ts` (icon, splash.image, adaptiveIcon.foregroundImage), `src/components/LoadingScreen.tsx` |
| **icon2.png** | — | *Unused* |
| **washing.png** | — | *Unused* |

---

## Video

| Asset | Usage | Locations |
|-------|-------|-----------|
| **auth.mp4** | Signup screen background video | `app/auth/signup.tsx` |
| **login.mp4** | Login screen background video | `app/auth/login.tsx` |
| **business.mp4** | — | *Unused* |
| **car-cleaning.mp4** | — | *Unused* |
| **water-rain.mp4** | — | *Unused* |

---

## App config (app.config.ts)

| Asset | Purpose |
|-------|---------|
| `./assets/icon.png` | App icon, splash image, Android adaptive icon foreground |
| `./assets/favicon.png` | Web favicon (must exist in `/assets`) |

---

## Summary

- **Used:** `car.png`, `cleaning.png`, `detailing.png`, `icon-auth.png`, `icon.png`, `auth.mp4`, `login.mp4`
- **Unused:** `icon2.png`, `washing.png`, `business.mp4`, `car-cleaning.mp4`, `water-rain.mp4`
- **Config-only:** `favicon.png` (referenced for web; ensure it exists)

---

## Naming conventions

| Prefix / name | Context |
|---------------|---------|
| `car.png` | User location marker, generic vehicle representation |
| `cleaning.png` | Standard wash / Wash Hub |
| `detailing.png` | Premium detailing / Detail Hub |
| `icon*.png` | Branding, app identity |
| `*.mp4` | Auth screen background videos |

---

*Generated from codebase scan. Update this doc when adding or removing assets.*
                                                                                '''''''''KL