import { createClient } from '@supabase/supabase-js';
import AsyncStorage from '@react-native-async-storage/async-storage';

// Supabase credentials
const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL || 'https://rmhlnfqgjipeawaddwor.supabase.co';
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJtaGxuZnFnamlwZWF3YWRkd29yIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTU5NTY4NDcsImV4cCI6MjA3MTUzMjg0N30.zhriJZhHMwwO4Q3iTsbIXN4EHeu89Vn8xo-yte9X-y4';

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    storage: AsyncStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

// Database types - matching UpdatedZip 3 code usage
export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string;
          email: string;
          name: string;
          phone?: string;
          user_type: 'customer' | 'valeter' | 'business' | 'super_admin';
          is_verified: boolean;
          verification_type: string;
          total_washes: number;
          tier: string;
          tier_points: number;
          join_date: string;
          created_at: string;
          updated_at: string;
          // Valeter specific fields
          is_individual_valeter?: boolean;
          organization_id?: string;
          individual_license_verified?: boolean;
          individual_insurance_verified?: boolean;
          individual_documents_uploaded?: boolean;
          background_check_passed?: boolean;
          // Organization specific fields
          organization_type?: 'independent' | 'registered';
          organization_name?: string;
          organization_license_verified?: boolean;
          organization_insurance_verified?: boolean;
          organization_documents_uploaded?: boolean;
        };
        Insert: {
          id?: string;
          email: string;
          name: string;
          phone?: string;
          user_type: 'customer' | 'valeter' | 'business' | 'super_admin';
          is_verified?: boolean;
          verification_type?: string;
          total_washes?: number;
          tier?: string;
          tier_points?: number;
          join_date?: string;
          created_at?: string;
          updated_at?: string;
          is_individual_valeter?: boolean;
          organization_id?: string;
          individual_license_verified?: boolean;
          individual_insurance_verified?: boolean;
          individual_documents_uploaded?: boolean;
          background_check_passed?: boolean;
          organization_type?: 'independent' | 'registered';
          organization_name?: string;
          organization_license_verified?: boolean;
          organization_insurance_verified?: boolean;
          organization_documents_uploaded?: boolean;
        };
        Update: {
          id?: string;
          email?: string;
          name?: string;
          phone?: string;
          user_type?: 'customer' | 'valeter' | 'business' | 'super_admin';
          is_verified?: boolean;
          verification_type?: string;
          total_washes?: number;
          tier?: string;
          tier_points?: number;
          join_date?: string;
          created_at?: string;
          updated_at?: string;
          is_individual_valeter?: boolean;
          organization_id?: string;
          individual_license_verified?: boolean;
          individual_insurance_verified?: boolean;
          individual_documents_uploaded?: boolean;
          background_check_passed?: boolean;
          organization_type?: 'independent' | 'registered';
          organization_name?: string;
          organization_license_verified?: boolean;
          organization_insurance_verified?: boolean;
          organization_documents_uploaded?: boolean;
        };
      };
      bookings: {
        Row: {
          id: string;
          user_id: string;
          valeter_id?: string;
          service_type: string;
          service_name?: string;
          price: number;
          status: 'pending' | 'pending_valeter_acceptance' | 'pending_payment' | 'confirmed' | 'valeter_assigned' | 'en_route' | 'arrived' | 'in_progress' | 'completed' | 'cancelled' | 'valeter_timeout' | 'scheduled';
          location_address?: string;
          location_lat?: number;
          location_lng?: number;
          location?: {
            latitude: number;
            longitude: number;
            address: string;
          };
          vehicle_type?: string;
          vehicle_info?: string;
          special_instructions?: string;
          customer_offers_water?: boolean;
          customer_offers_electricity?: boolean;
          discount_amount?: number;
          wash_type?: 'exterior' | 'interior' | 'both';
          scheduled_at?: string;
          time_slot?: string;
          request_sent_at?: string;
          payment_completed_at?: string;
          cancelled_by?: string;
          cancellation_reason?: string;
          completed_at?: string;
          rating?: number;
          review?: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          valeter_id?: string;
          service_type: string;
          service_name?: string;
          price: number;
          status?: 'pending' | 'pending_valeter_acceptance' | 'pending_payment' | 'confirmed' | 'valeter_assigned' | 'en_route' | 'arrived' | 'in_progress' | 'completed' | 'cancelled' | 'valeter_timeout' | 'scheduled';
          location_address?: string;
          location_lat?: number;
          location_lng?: number;
          location?: {
            latitude: number;
            longitude: number;
            address: string;
          };
          vehicle_type?: string;
          vehicle_info?: string;
          special_instructions?: string;
          customer_offers_water?: boolean;
          customer_offers_electricity?: boolean;
          discount_amount?: number;
          wash_type?: 'exterior' | 'interior' | 'both';
          scheduled_at?: string;
          time_slot?: string;
          request_sent_at?: string;
          payment_completed_at?: string;
          cancelled_by?: string;
          cancellation_reason?: string;
          completed_at?: string;
          rating?: number;
          review?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          valeter_id?: string;
          service_type?: string;
          service_name?: string;
          price?: number;
          status?: 'pending' | 'pending_valeter_acceptance' | 'pending_payment' | 'confirmed' | 'valeter_assigned' | 'en_route' | 'arrived' | 'in_progress' | 'completed' | 'cancelled' | 'valeter_timeout' | 'scheduled';
          location_address?: string;
          location_lat?: number;
          location_lng?: number;
          location?: {
            latitude: number;
            longitude: number;
            address: string;
          };
          vehicle_type?: string;
          vehicle_info?: string;
          special_instructions?: string;
          customer_offers_water?: boolean;
          customer_offers_electricity?: boolean;
          discount_amount?: number;
          wash_type?: 'exterior' | 'interior' | 'both';
          scheduled_at?: string;
          time_slot?: string;
          request_sent_at?: string;
          payment_completed_at?: string;
          cancelled_by?: string;
          cancellation_reason?: string;
          completed_at?: string;
          rating?: number;
          review?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      valeter_profiles: {
        Row: {
          id: string;
          user_id: string;
          working_radius: number;
          is_online: boolean;
          is_self_sufficient?: boolean;
          current_location?: {
            latitude: number;
            longitude: number;
          };
          specializations: string[];
          documents: {
            license?: string;
            insurance?: string;
            background_check?: string;
            profile_picture?: string;
          };
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          working_radius?: number;
          is_online?: boolean;
          is_self_sufficient?: boolean;
          current_location?: {
            latitude: number;
            longitude: number;
          };
          specializations?: string[];
          documents?: {
            license?: string;
            insurance?: string;
            background_check?: string;
            profile_picture?: string;
          };
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          working_radius?: number;
          is_online?: boolean;
          is_self_sufficient?: boolean;
          current_location?: {
            latitude: number;
            longitude: number;
          };
          specializations?: string[];
          documents?: {
            license?: string;
            insurance?: string;
            background_check?: string;
            profile_picture?: string;
          };
          created_at?: string;
          updated_at?: string;
        };
      };
      organizations: {
        Row: {
          id: string;
          name: string;
          email: string;
          phone: string;
          address: string;
          license_number: string;
          insurance_number: string;
          is_verified: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          email: string;
          phone: string;
          address: string;
          license_number: string;
          insurance_number: string;
          is_verified?: boolean;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          email?: string;
          phone?: string;
          address?: string;
          license_number?: string;
          insurance_number?: string;
          is_verified?: boolean;
          created_at?: string;
          updated_at?: string;
        };
      };
      customer_vehicles: {
        Row: {
          id: string;
          user_id: string;
          type: string;
          make?: string;
          model?: string;
          color?: string;
          registration?: string;
          is_default: boolean;
          photo?: string;
          tax_expiry?: string;
          mot_expiry?: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          type: string;
          make?: string;
          model?: string;
          color?: string;
          registration?: string;
          is_default?: boolean;
          photo?: string;
          tax_expiry?: string;
          mot_expiry?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          type?: string;
          make?: string;
          model?: string;
          color?: string;
          registration?: string;
          is_default?: boolean;
          photo?: string;
          tax_expiry?: string;
          mot_expiry?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      car_wash_locations: {
        Row: {
          id: string;
          name: string;
          address: string;
          latitude: number;
          longitude: number;
          phone?: string;
          email?: string;
          rating?: number;
          total_reviews?: number;
          base_price?: number;
          priority_price?: number;
          status?: string;
          operating_hours?: any;
          services_offered?: string[];
          is_active: boolean;
          organization_id?: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          name: string;
          address: string;
          latitude: number;
          longitude: number;
          phone?: string;
          email?: string;
          rating?: number;
          total_reviews?: number;
          base_price?: number;
          priority_price?: number;
          status?: string;
          operating_hours?: any;
          services_offered?: string[];
          is_active?: boolean;
          organization_id?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          name?: string;
          address?: string;
          latitude?: number;
          longitude?: number;
          phone?: string;
          email?: string;
          rating?: number;
          total_reviews?: number;
          base_price?: number;
          priority_price?: number;
          status?: string;
          operating_hours?: any;
          services_offered?: string[];
          is_active?: boolean;
          organization_id?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
      admin_access_logs: {
        Row: {
          id: string;
          user_id: string;
          access_code: string;
          success: boolean;
          device_id: string;
          ip_address?: string;
          user_agent?: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          user_id: string;
          access_code: string;
          success: boolean;
          device_id: string;
          ip_address?: string;
          user_agent?: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          user_id?: string;
          access_code?: string;
          success?: boolean;
          device_id?: string;
          ip_address?: string;
          user_agent?: string;
          created_at?: string;
        };
      };
    };
    Views: {
      [_ in never]: never;
    };
    Functions: {
      [_ in never]: never;
    };
    Enums: {
      [_ in never]: never;
    };
  };
}

export type User = Database['public']['Tables']['users']['Row'];
export type Booking = Database['public']['Tables']['bookings']['Row'];
export type ValeterProfile = Database['public']['Tables']['valeter_profiles']['Row'];
export type Organization = Database['public']['Tables']['organizations']['Row'];
export type CustomerVehicle = Database['public']['Tables']['customer_vehicles']['Row'];
export type CarWashLocation = Database['public']['Tables']['car_wash_locations']['Row'];
export type AdminAccessLog = Database['public']['Tables']['admin_access_logs']['Row'];
