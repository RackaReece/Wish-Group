import { supabase } from '../lib/supabase';

export interface WashHubStats {
  totalJobs: number;
  averageRating: number;
}

export class WashHubStatsService {
  static async getHubStats(locationId: string): Promise<WashHubStats> {
    try {
      const { data: jobs, error } = await supabase
        .from('bookings')
        .select('rating')
        .eq('location_id', locationId)
        .eq('status', 'completed');

      if (error) throw error;

      const completed = jobs || [];
      const totalJobs = completed.length;
      const withRatings = completed.filter((j) => j.rating != null);
      const averageRating =
        withRatings.length > 0
          ? withRatings.reduce((sum, j) => sum + (Number(j.rating) || 0), 0) / withRatings.length
          : 0;

      return {
        totalJobs,
        averageRating: Math.round(averageRating * 10) / 10,
      };
    } catch (e) {
      console.error('[WashHubStatsService]', e);
      return { totalJobs: 0, averageRating: 0 };
    }
  }
}
