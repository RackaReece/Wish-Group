// app/valeter/PowerfulDriverDashboard.tsx
import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Animated,
  Dimensions,
  SafeAreaView,
  StatusBar,
  ScrollView,
  Modal,
  Alert,
  ActivityIndicator,
  RefreshControl,
  Platform,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../providers/enhanced-auth-context';
import CarCareInfoHub from '../car-care/CarCareInfoHub';
import { hapticFeedback } from '../../services/HapticFeedbackService';
import * as Location from 'expo-location';
import { supabase } from '../../lib/supabase';
import GradientNotificationBell from '../shared/GradientNotificationBell';
import BubbleBackground from '../shared/BubbleBackground';
import useLiveLocation from '../../hooks/useLiveLocation';
import { colors } from '../../constants/colors';
import { ValeterStatsService, ValeterPerformanceStats } from '../../services/Valeterstatsservice';
import GlassCard from '../booking/GlassCard';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

interface JobRequest {
  id: string;
  serviceName: string;
  distance: number;
  price: number;
  customerName: string;
  address: string;
  timeRemaining: number;
}

interface TodayStats {
  hoursOnline: string;
  jobsCompleted: number;
  earnings: number;
}

/** Animated count-up text for stats */
const CountUpNumber = ({
  value,
  prefix = '',
  suffix = '',
  decimals = 0,
  duration = 650,
  style,
}: {
  value: number;
  prefix?: string;
  suffix?: string;
  decimals?: number;
  duration?: number;
  style?: any;
}) => {
  const anim = useRef(new Animated.Value(0)).current;
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    anim.stopAnimation();
    anim.setValue(0);
    const listenerId = anim.addListener(({ value: v }) => setDisplay(v));
    Animated.timing(anim, { toValue: value, duration, useNativeDriver: false }).start(() => {
      anim.removeListener(listenerId);
      setDisplay(value);
    });
    return () => anim.removeListener(listenerId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  const shown = useMemo(() => Number(display).toFixed(decimals), [display, decimals]);
  return <Text style={style}>{`${prefix}${shown}${suffix}`}</Text>;
};

export default function PowerfulDriverDashboard() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();

  const [showChat, setShowChat] = useState(false);
  const [isOnline, setIsOnline] = useState(false);
  const [loadingPresence, setLoadingPresence] = useState(true);
  const [toggling, setToggling] = useState(false);
  const [refreshing, setRefreshing] = useState(false);

  const [jobRequests, setJobRequests] = useState<JobRequest[]>([]);
  const [todayStats, setTodayStats] = useState<TodayStats>({
    hoursOnline: '0h 0m',
    jobsCompleted: 0,
    earnings: 0,
  });

  const [valeterStats, setValeterStats] = useState<ValeterPerformanceStats | null>(null);
  const [loadingStats, setLoadingStats] = useState(true);

  const [profileName, setProfileName] = useState<string>('Valeter');
  const [workingRadius, setWorkingRadius] = useState<number>(10);

  const { coords, cityLabel, addressLine, loading: locationLoading, refresh } = useLiveLocation();

  const scrollY = useRef(new Animated.Value(0)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;

  const headerHeight = scrollY.interpolate({
    inputRange: [0, 160],
    outputRange: [insets.top + 120, insets.top + 100],
    extrapolate: 'clamp',
  });
  const headerOpacity = scrollY.interpolate({
    inputRange: [0, 80, 160],
    outputRange: [1, 0.95, 0.9],
    extrapolate: 'clamp',
  });

  // Pulsing animation for online indicator
  useEffect(() => {
    if (isOnline) {
      Animated.loop(
        Animated.sequence([
          Animated.timing(pulseAnim, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
          Animated.timing(pulseAnim, { toValue: 1, duration: 1000, useNativeDriver: true }),
        ])
      ).start();
    } else {
      pulseAnim.setValue(1);
    }
  }, [isOnline, pulseAnim]);

  const loadValeterName = async (userId: string) => {
    // 1) profiles.full_name (most common)
    try {
      const { data: p } = await supabase
        .from('profiles')
        .select('full_name')
        .eq('id', userId)
        .maybeSingle();

      const name = (p?.full_name || '').trim();
      if (name) return name;
    } catch {}

    // 2) valeter_profiles fallback (some setups store it here)
    try {
      const { data: vp } = await supabase
        .from('valeter_profiles')
        .select('full_name, display_name')
        .eq('user_id', userId)
        .maybeSingle();

      const n1 = (vp?.display_name || '').trim();
      if (n1) return n1;

      const n2 = (vp?.full_name || '').trim();
      if (n2) return n2;
    } catch {}

    // 3) auth context / fallback
    const maybe = (user?.name || '').trim();
    if (maybe) return maybe;

    return 'Valeter';
  };

  const loadWorkingRadius = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('valeter_profiles')
        .select('working_radius')
        .eq('user_id', userId)
        .maybeSingle();

      if (error) {
        console.warn('[valeter_profiles] working_radius read error', error);
        return;
      }

      const r = Number(data?.working_radius);
      if (Number.isFinite(r) && r > 0) setWorkingRadius(r);
      else setWorkingRadius(10);
    } catch (e) {
      console.warn('[valeter_profiles] working_radius read crash', e);
      setWorkingRadius(10);
    }
  };

  // Load initial online status + subscribe to realtime
  useEffect(() => {
    if (!user?.id) return;
    let mounted = true;

    (async () => {
      setLoadingPresence(true);

      // ✅ Name at top should be the valeter's name
      const name = await loadValeterName(user.id);
      if (mounted) setProfileName(name);

      // ✅ Working radius from DB
      await loadWorkingRadius(user.id);

      // presence
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('is_online')
        .eq('user_id', user.id)
        .maybeSingle();

      if (!mounted) return;
      if (error) console.warn('[presence] read error', error);

      setIsOnline(!!data?.is_online);
      setLoadingPresence(false);
    })();

    const channel = supabase
      .channel('presence-self')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${user.id}`,
        },
        (payload) => {
          const row: any = payload.new ?? payload.old;
          if (row && typeof row.is_online === 'boolean') setIsOnline(row.is_online);
        }
      )
      .subscribe();

    return () => {
      mounted = false;
      supabase.removeChannel(channel);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  // Subscribe to job requests for this valeter
  useEffect(() => {
    if (!user?.id || !isOnline) return;

    const channel = supabase
      .channel('job-requests')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${user.id}`,
        },
        (payload) => {
          const booking: any = payload.new;
          if (booking.status === 'pending_valeter_acceptance') {
            const newRequest: JobRequest = {
              id: booking.id,
              serviceName: booking.service_name || 'Car Wash',
              distance: 0,
              price: Number(booking.price),
              customerName: 'Customer',
              address: booking.location_address || '',
              timeRemaining: 300,
            };
            setJobRequests((prev) => [...prev, newRequest]);
          }
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `valeter_id=eq.${user.id}`,
        },
        (payload) => {
          const booking: any = payload.new;
          if (booking.status !== 'pending_valeter_acceptance') {
            setJobRequests((prev) => prev.filter((r) => r.id !== booking.id));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, isOnline]);

  // Countdown timer for job requests
  useEffect(() => {
    if (jobRequests.length === 0) return;

    const interval = setInterval(() => {
      setJobRequests((prev) =>
        prev
          .map((req) => {
            if (req.timeRemaining <= 1) {
              handleJobTimeout(req.id);
              return { ...req, timeRemaining: 0 };
            }
            return { ...req, timeRemaining: req.timeRemaining - 1 };
          })
          .filter((req) => req.timeRemaining > 0)
      );
    }, 1000);

    return () => clearInterval(interval);
  }, [jobRequests]);

  const goOnlineWithLocation = async () => {
    const { status } = await Location.requestForegroundPermissionsAsync();
    if (status !== 'granted') {
      Alert.alert('Permission needed', 'Location permission is required to go online so customers can find you.');
      throw new Error('location-permission-denied');
    }
    const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
    const lat = Number(loc.coords.latitude.toFixed(6));
    const lng = Number(loc.coords.longitude.toFixed(6));

    const { error } = await supabase.rpc('update_my_presence', {
      p_is_online: true,
      p_last_lat: lat,
      p_last_lng: lng,
    });
    if (error) throw error;
  };

  const goOffline = async () => {
    const { error } = await supabase.rpc('set_online', { p_is_online: false });
    if (error) throw error;
  };

  const toggleOnline = async () => {
    try {
      if (!user?.id) return;
      setToggling(true);
      await hapticFeedback('medium');

      if (!isOnline) await goOnlineWithLocation();
      else await goOffline();

      setIsOnline(!isOnline);
    } catch (e) {
      console.error('[presence] toggle error', e);
      Alert.alert('Error', 'Could not update your online status. Try again.');
    } finally {
      setToggling(false);
    }
  };

  const handleAcceptJob = async (jobId: string) => {
    try {
      await hapticFeedback('medium');
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'confirmed',
          valeter_response_at: new Date().toISOString(),
        })
        .eq('id', jobId);

      if (error) throw error;

      Alert.alert("Job Accepted", "Customer will complete payment. You'll be notified when ready.");
      setJobRequests((prev) => prev.filter((r) => r.id !== jobId));
      router.push('/valeter/valeter-search');
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to accept job');
    }
  };

  const handleDeclineJob = async (jobId: string) => {
    try {
      await hapticFeedback('light');
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'valeter_declined',
          valeter_response_at: new Date().toISOString(),
        })
        .eq('id', jobId);

      if (error) throw error;
      setJobRequests((prev) => prev.filter((r) => r.id !== jobId));
    } catch (e: any) {
      Alert.alert('Error', e.message || 'Failed to decline job');
    }
  };

  const handleJobTimeout = async (jobId: string) => {
    try {
      await supabase.from('bookings').update({ status: 'valeter_timeout' }).eq('id', jobId);
    } catch (e) {
      console.error('Timeout update failed:', e);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  // Load valeter stats
  useEffect(() => {
    if (!user?.id) return;

    const loadStats = async () => {
      try {
        setLoadingStats(true);
        const stats = await ValeterStatsService.getValeterStats(user.id);
        setValeterStats(stats);
      } catch (error) {
        console.error('Error loading valeter stats:', error);
      } finally {
        setLoadingStats(false);
      }
    };

    loadStats();
  }, [user?.id]);

  const onRefresh = async () => {
    setRefreshing(true);
    try {
      if (user?.id) {
        const stats = await ValeterStatsService.getValeterStats(user.id);
        setValeterStats(stats);
        await loadWorkingRadius(user.id); // keep dashboard in sync
        const name = await loadValeterName(user.id);
        setProfileName(name);
      }
      await new Promise((resolve) => setTimeout(resolve, 700));
    } finally {
      setRefreshing(false);
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="#0A1929" />
      <LinearGradient colors={['#0A1929', '#1E3A8A']} style={StyleSheet.absoluteFill} />
      <BubbleBackground accountType="valeter" />

      {/* Animated Header */}
      <Animated.View
        style={[
          styles.header,
          {
            height: headerHeight,
            opacity: headerOpacity,
            paddingTop: insets.top,
          },
        ]}
      >
        <BlurView intensity={Platform.OS === 'ios' ? 25 : 20} tint="dark" style={StyleSheet.absoluteFill}>
          <View style={styles.glassOverlay}>
            <LinearGradient
              colors={[colors.headerGlassBg, colors.headerGlassOverlay]}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
              opacity={0.9}
            />
          </View>
        </BlurView>

        <View style={styles.glassBorder} />

        <View style={styles.headerContent}>
          <View style={styles.headerTop}>
            <View style={styles.headerLeft}>
              <Text style={styles.greeting}>
                {new Date().getHours() < 12
                  ? 'Good morning!'
                  : new Date().getHours() < 17
                    ? 'Good afternoon!'
                    : 'Good evening!'}
              </Text>

              {/* ✅ THIS is now real valeter name */}
              <Text style={styles.userName} numberOfLines={1}>
                {profileName || 'Valeter'}
              </Text>

              <Text style={styles.locationLine} numberOfLines={1}>
                {locationLoading ? 'Getting location…' : (addressLine || cityLabel || '—')}
              </Text>

              <Text style={styles.subtitle}>Welcome to Wish a Wash</Text>
            </View>

            <View style={styles.headerActions}>
              <View style={styles.statusBadge}>
                <Animated.View
                  style={[
                    styles.statusDot,
                    {
                      backgroundColor: isOnline ? '#10B981' : '#EF4444',
                      transform: [{ scale: pulseAnim }],
                    },
                  ]}
                />
                <Text style={styles.statusText}>
                  {loadingPresence || toggling ? '...' : isOnline ? 'ONLINE' : 'OFFLINE'}
                </Text>
              </View>

              <GradientNotificationBell
                count={jobRequests.length}
                onPress={() => router.push('/valeter/notifications')}
              />
            </View>
          </View>
        </View>
      </Animated.View>

      <Animated.ScrollView
        style={styles.scrollView}
        onScroll={Animated.event([{ nativeEvent: { contentOffset: { y: scrollY } } }], { useNativeDriver: false })}
        scrollEventThrottle={16}
        contentContainerStyle={{
          paddingTop: insets.top + 96,
          paddingBottom: 20,
        }}
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl tintColor="#87CEEB" refreshing={refreshing} onRefresh={onRefresh} />}
      >
        {/* Online Toggle Card */}
        <View style={styles.toggleSection}>
          <LinearGradient
            colors={isOnline ? ['#10B981', '#059669'] : ['#374151', '#1F2937']}
            style={styles.toggleCard}
          >
            <View style={styles.toggleContent}>
              <View style={styles.toggleLeft}>
                <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                  <Ionicons name={isOnline ? 'checkmark-circle' : 'pause-circle'} size={20} color="#FFFFFF" />
                  <Text style={styles.toggleTitle}>{isOnline ? "You're Online" : "You're Offline"}</Text>
                </View>
                <Text style={styles.toggleSubtitle}>{isOnline ? 'Accepting job requests' : 'Tap to start accepting jobs'}</Text>
              </View>

              <TouchableOpacity
                style={styles.toggleButton}
                onPress={toggleOnline}
                disabled={loadingPresence || toggling}
                activeOpacity={0.8}
              >
                <View style={[styles.toggleTrack, { backgroundColor: isOnline ? '#fff' : 'rgba(255,255,255,0.3)' }]}>
                  <Animated.View
                    style={[
                      styles.toggleThumb,
                      {
                        backgroundColor: isOnline ? '#10B981' : '#EF4444',
                        transform: [{ translateX: isOnline ? 30 : 0 }],
                      },
                    ]}
                  />
                </View>
              </TouchableOpacity>
            </View>
          </LinearGradient>
        </View>

        {/* Stats Section */}
        {!loadingStats && valeterStats && (
          <View style={styles.statsSection}>
            <View style={styles.statsGrid}>
              <View style={styles.statCard}>
                <View style={styles.statCardContent}>
                  <View style={styles.statIconWrapper}>
                    <Ionicons name="briefcase" size={22} color={colors.SKY} />
                  </View>
                  <View style={styles.statTextContainer}>
                    <Text style={styles.statNumber}>{valeterStats.totalJobs}</Text>
                    <Text style={styles.statLabel}>Total Jobs</Text>
                  </View>
                </View>
              </View>

              <View style={styles.statCard}>
                <View style={styles.statCardContent}>
                  <View style={[styles.statIconWrapper, styles.statIconWrapperGold]}>
                    <Ionicons name="wallet" size={22} color="#F59E0B" />
                  </View>
                  <View style={styles.statTextContainer}>
                    <Text style={styles.statNumber}>£{valeterStats.totalEarnings}</Text>
                    <Text style={styles.statLabel}>Total Earnings</Text>
                  </View>
                </View>
              </View>

              <View style={styles.statCard}>
                <View style={styles.statCardContent}>
                  <View style={[styles.statIconWrapper, styles.statIconWrapperGold]}>
                    <Ionicons name="star" size={22} color="#F59E0B" />
                  </View>
                  <View style={styles.statTextContainer}>
                    <Text style={styles.statNumber}>
                      {valeterStats.averageRating > 0 ? valeterStats.averageRating.toFixed(1) : 'N/A'}
                    </Text>
                    <Text style={styles.statLabel}>Avg Rating</Text>
                  </View>
                </View>
              </View>

              <View style={styles.statCard}>
                <View style={styles.statCardContent}>
                  <View style={styles.statIconWrapper}>
                    <Ionicons name="calendar" size={22} color={colors.SKY} />
                  </View>
                  <View style={styles.statTextContainer}>
                    <Text style={styles.statNumber}>{valeterStats.jobsThisMonth}</Text>
                    <Text style={styles.statLabel}>This Month</Text>
                  </View>
                </View>
              </View>
            </View>
          </View>
        )}

        {/* Incoming Job Requests */}
        {jobRequests.length > 0 && (
          <View style={styles.jobQueueSection}>
            <View style={styles.jobQueueHeader}>
              <View style={styles.notificationBadge}>
                <Text style={styles.notificationBadgeText}>{jobRequests.length}</Text>
              </View>
              <Text style={styles.jobQueueTitle}>Job Queue</Text>
            </View>

            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.jobQueueContainer}
              snapToInterval={width - 40}
              decelerationRate="fast"
              pagingEnabled={false}
            >
              {jobRequests.map((request) => (
                <GlassCard 
                  key={request.id} 
                  style={[styles.jobRequestCard, styles.jobRequestGlassCard]} 
                  borderColor="rgba(59,130,246,0.4)"
                >
                  <LinearGradient
                    colors={['rgba(59,130,246,0.25)', 'rgba(29,78,216,0.3)']}
                    style={StyleSheet.absoluteFill}
                  />
                  
                  {/* Header with timer */}
                  <View style={styles.jobRequestHeader}>
                    <View style={styles.jobRequestInfo}>
                      <View style={styles.jobRequestTitleRow}>
                        <View style={styles.jobRequestIconWrapper}>
                          <Ionicons name="car" size={20} color="#3B82F6" />
                        </View>
                        <Text style={styles.jobRequestService}>{request.serviceName}</Text>
                      </View>
                      
                      <View style={styles.jobRequestMetaRow}>
                        <View style={styles.jobRequestMetaItem}>
                          <Ionicons name="location" size={14} color="#87CEEB" />
                          <Text style={styles.jobRequestDetails}>{request.distance.toFixed(1)} mi</Text>
                        </View>
                        <View style={styles.jobRequestMetaItem}>
                          <Ionicons name="wallet" size={14} color="#10B981" />
                          <Text style={styles.jobRequestPrice}>£{request.price}</Text>
                        </View>
                      </View>
                      
                      <View style={styles.jobRequestAddressRow}>
                        <Ionicons name="map-outline" size={12} color="rgba(255,255,255,0.6)" />
                        <Text style={styles.jobRequestAddress} numberOfLines={2}>
                          {request.address}
                        </Text>
                      </View>
                    </View>

                    <View style={styles.jobRequestTimerContainer}>
                      <View style={styles.jobRequestTimer}>
                        <Ionicons name="time-outline" size={16} color="#FFFFFF" />
                        <Text style={styles.jobRequestTimerText}>{formatTime(request.timeRemaining)}</Text>
                      </View>
                    </View>
                  </View>

                  {/* Action Buttons */}
                  <View style={styles.jobRequestActions}>
                    <TouchableOpacity
                      style={[styles.jobRequestButton, styles.acceptButton]}
                      onPress={() => handleAcceptJob(request.id)}
                      activeOpacity={0.8}
                    >
                      <LinearGradient
                        colors={['#10B981', '#059669']}
                        style={styles.jobRequestButtonGradient}
                      >
                        <Ionicons name="checkmark-circle" size={18} color="#FFFFFF" />
                        <Text style={styles.jobRequestButtonText}>Accept</Text>
                      </LinearGradient>
                    </TouchableOpacity>

                    <TouchableOpacity
                      style={[styles.jobRequestButton, styles.declineButton]}
                      onPress={() => handleDeclineJob(request.id)}
                      activeOpacity={0.8}
                    >
                      <View style={styles.declineButtonContent}>
                        <Ionicons name="close-circle" size={18} color="rgba(255,255,255,0.9)" />
                        <Text style={styles.declineButtonText}>Decline</Text>
                      </View>
                    </TouchableOpacity>
                  </View>
                </GlassCard>
              ))}
            </ScrollView>
          </View>
        )}

        {/* Quick Actions (fixed sizing + text wrap) */}
        <View style={styles.quickActionsSection}>
          <Text style={styles.quickActionsTitle}>Quick Actions</Text>

          <View style={styles.quickActionsGrid}>
            <TouchableOpacity
              style={[styles.quickActionCardFixed, styles.quickActionCardBlue]}
              onPress={() => router.push('/valeter/valeter-wash-history')}
              activeOpacity={0.85}
            >
              <View style={styles.quickActionGradientFixed}>
                <View style={styles.quickActionRow}>
                  <View style={[styles.quickIcon, styles.quickIconBlue]}>
                    <Ionicons name="wallet" size={22} color="#FFFFFF" />
                  </View>

                  <View style={styles.quickTextWrap}>
                    <Text style={styles.quickTitle} numberOfLines={1}>
                      Earnings
                    </Text>
                    <Text style={styles.quickSubtitle} numberOfLines={2}>
                      View your history
                    </Text>
                  </View>

                  <Ionicons name="chevron-forward" size={18} color="#FFFFFF" style={{ opacity: 0.8 }} />
                </View>
              </View>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.quickActionCardFixed, styles.quickActionCardPurple]}
              onPress={() => router.push('/valeter/profile/valeter-profile')}
              activeOpacity={0.85}
            >
              <View style={styles.quickActionGradientFixed}>
                <View style={styles.quickActionRow}>
                  <View style={[styles.quickIcon, styles.quickIconPurple]}>
                    <Ionicons name="id-card" size={22} color="#FFFFFF" />
                  </View>

                  <View style={styles.quickTextWrap}>
                    <Text style={styles.quickTitle} numberOfLines={1}>
                      Profile
                    </Text>
                    <Text style={styles.quickSubtitle} numberOfLines={2}>
                      Edit your details
                    </Text>
                  </View>

                  <Ionicons name="chevron-forward" size={18} color="#FFFFFF" style={{ opacity: 0.8 }} />
                </View>
              </View>
            </TouchableOpacity>
          </View>
        </View>

        {/* Car Care Info Hub */}
        <View style={styles.assistantSection}>
          <TouchableOpacity style={styles.assistantCard} onPress={() => setShowChat(true)} activeOpacity={0.8}>
            <LinearGradient colors={['rgba(135,206,235,0.2)', 'rgba(30,58,138,0.25)']} style={styles.assistantGradient}>
              <View style={styles.assistantContent}>
                <View style={styles.assistantIconWrapper}>
                  <Ionicons name="information-circle" size={28} color="#87CEEB" />
                </View>
                <View style={styles.assistantTextContainer}>
                  <Text style={styles.assistantTitle}>Car Care Info Hub</Text>
                  <Text style={styles.assistantSubtitle} numberOfLines={2}>
                    Tips, locations, Tax & MOT reminders & more
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#87CEEB" />
              </View>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Working Radius (DB-backed) */}
        <View style={styles.assistantSection}>
          <TouchableOpacity style={styles.assistantCard} onPress={() => router.push('/valeter/settings/distance-covering')} activeOpacity={0.8}>
            <LinearGradient colors={['rgba(59,130,246,0.2)', 'rgba(37,99,235,0.25)']} style={styles.assistantGradient}>
              <View style={styles.assistantContent}>
                <View style={styles.assistantIconWrapper}>
                  <Ionicons name="location" size={28} color="#3B82F6" />
                </View>
                <View style={styles.assistantTextContainer}>
                  <Text style={styles.assistantTitle}>Working Radius</Text>
                  <Text style={styles.assistantSubtitle} numberOfLines={2}>
                    {workingRadius} miles from your location
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#3B82F6" />
              </View>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        {/* Documents */}
        <View style={styles.assistantSection}>
          <TouchableOpacity style={styles.assistantCard} onPress={() => router.push('/valeter/profile/valeter-documents')} activeOpacity={0.8}>
            <LinearGradient colors={['rgba(139,92,246,0.2)', 'rgba(124,58,237,0.25)']} style={styles.assistantGradient}>
              <View style={styles.assistantContent}>
                <View style={styles.assistantIconWrapper}>
                  <Ionicons name="document-text" size={28} color="#8B5CF6" />
                </View>
                <View style={styles.assistantTextContainer}>
                  <Text style={styles.assistantTitle}>Documents</Text>
                  <Text style={styles.assistantSubtitle} numberOfLines={2}>
                    Manage your verification documents
                  </Text>
                </View>
                <Ionicons name="chevron-forward" size={20} color="#8B5CF6" />
              </View>
            </LinearGradient>
          </TouchableOpacity>
        </View>

        <View style={{ height: 40 }} />
      </Animated.ScrollView>

      <Modal visible={showChat} animationType="slide" presentationStyle="fullScreen">
        <CarCareInfoHub userType="valeter" onClose={() => setShowChat(false)} />
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#0A1929' },

  /* Header */
  header: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 1000,
    backgroundColor: 'transparent',
    overflow: 'hidden',
    shadowColor: colors.headerGlassShadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 10,
  },
  glassOverlay: { ...StyleSheet.absoluteFillObject, backgroundColor: 'transparent' },
  glassBorder: {
    position: 'absolute',
    bottom: -1,
    left: 0,
    right: 0,
    height: 1,
    backgroundColor: colors.headerGlassBorder,
    shadowColor: colors.headerGlassBorder,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.5,
    shadowRadius: 4,
    zIndex: 1,
  },
  headerContent: {
    flex: 1,
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingBottom: 12,
    justifyContent: 'flex-start',
    zIndex: 1,
  },
  headerTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginTop: 8,
  },
  headerLeft: { flex: 1 },
  greeting: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 14 : 16,
    marginBottom: 4,
    opacity: 0.9,
  },
  userName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 22 : 26,
    fontWeight: '800',
    marginBottom: 2,
  },
  locationLine: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 11 : 12,
    opacity: 0.9,
    marginBottom: 2,
  },
  subtitle: {
    color: '#87CEEB',
    fontSize: isSmallScreen ? 12 : 14,
  },
  headerActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginLeft: 12,
  },
  statusBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.16)',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 20,
  },
  statusDot: { width: 10, height: 10, borderRadius: 5, marginRight: 6 },
  statusText: {
    color: '#F9FAFB',
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 0.5,
  },

  scrollView: { flex: 1 },

  /* Toggle Section */
  toggleSection: { marginHorizontal: isSmallScreen ? 12 : 20, marginBottom: 20 },
  toggleCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  toggleContent: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', padding: 20 },
  toggleLeft: { flex: 1 },
  toggleTitle: { color: '#FFFFFF', fontSize: 18, fontWeight: 'bold', marginBottom: 4 },
  toggleSubtitle: { color: '#FFFFFF', fontSize: 14, opacity: 0.9 },
  toggleButton: { marginLeft: 12 },
  toggleTrack: { width: 70, height: 40, borderRadius: 20, padding: 4, justifyContent: 'center' },
  toggleThumb: { width: 32, height: 32, borderRadius: 16 },

  /* Job Queue */
  jobQueueSection: { marginBottom: 24 },
  jobQueueHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: isSmallScreen ? 12 : 20,
    marginBottom: 12,
    gap: 8,
  },
  jobQueueTitle: { color: '#F9FAFB', fontSize: isSmallScreen ? 18 : 20, fontWeight: 'bold' },
  jobQueueContainer: { paddingHorizontal: isSmallScreen ? 12 : 20, gap: 12 },
  notificationBadge: { backgroundColor: '#EF4444', paddingHorizontal: 8, paddingVertical: 4, borderRadius: 12 },
  notificationBadgeText: { color: '#fff', fontSize: 12, fontWeight: '900' },

  jobRequestCard: {
    width: width - 40,
    marginRight: 16,
  },
  jobRequestGlassCard: {
    padding: 18,
    minHeight: 200,
  },
  jobRequestHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 18,
    gap: 12,
  },
  jobRequestInfo: {
    flex: 1,
    gap: 10,
  },
  jobRequestTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 4,
  },
  jobRequestIconWrapper: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(59,130,246,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.4)',
  },
  jobRequestService: {
    fontSize: 18,
    fontWeight: '900',
    color: '#F9FAFB',
    flex: 1,
    letterSpacing: 0.3,
  },
  jobRequestMetaRow: {
    flexDirection: 'row',
    gap: 16,
    alignItems: 'center',
    marginBottom: 6,
  },
  jobRequestMetaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  jobRequestDetails: {
    fontSize: 14,
    color: '#87CEEB',
    fontWeight: '700',
  },
  jobRequestPrice: {
    fontSize: 16,
    color: '#10B981',
    fontWeight: '800',
  },
  jobRequestAddressRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 6,
    marginTop: 4,
  },
  jobRequestAddress: {
    fontSize: 12,
    color: 'rgba(255,255,255,0.75)',
    flex: 1,
    lineHeight: 16,
    fontWeight: '500',
  },
  jobRequestTimerContainer: {
    alignItems: 'flex-end',
  },
  jobRequestTimer: {
    backgroundColor: 'rgba(239, 68, 68, 0.9)',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 14,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.5)',
    shadowColor: '#EF4444',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 4,
    elevation: 4,
  },
  jobRequestTimerText: {
    fontSize: 15,
    fontWeight: '900',
    color: '#FFFFFF',
    letterSpacing: 0.5,
  },
  jobRequestActions: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 4,
  },
  jobRequestButton: {
    flex: 1,
    borderRadius: 14,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
  },
  jobRequestButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    gap: 8,
  },
  acceptButton: {
    shadowColor: '#10B981',
  },
  declineButton: {
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.25)',
  },
  declineButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    gap: 8,
  },
  jobRequestButtonText: {
    fontSize: 15,
    fontWeight: '900',
    color: '#FFFFFF',
    letterSpacing: 0.3,
  },
  declineButtonText: {
    fontSize: 15,
    fontWeight: '900',
    color: 'rgba(255,255,255,0.9)',
    letterSpacing: 0.3,
  },

  /* Stats */
  statsSection: { marginBottom: 24 },
  statsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    gap: 12,
    paddingHorizontal: isSmallScreen ? 12 : 20,
  },
  statCard: {
    width: (width - (isSmallScreen ? 36 : 40)) / 2 - 6,
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.1)',
    backgroundColor: 'rgba(255,255,255,0.05)',
  },
  statCardContent: { flexDirection: 'row', alignItems: 'center', padding: 14, gap: 12 },
  statIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  statIconWrapperGold: { backgroundColor: 'rgba(245,158,11,0.12)', borderColor: 'rgba(245,158,11,0.25)' },
  statTextContainer: { flex: 1 },
  statNumber: { fontSize: isSmallScreen ? 18 : 20, fontWeight: '800', color: '#F9FAFB', marginBottom: 2 },
  statLabel: { fontSize: 12, color: '#87CEEB', fontWeight: '600' },

  /* Quick Actions */
  quickActionsSection: { marginBottom: 24 },
  quickActionsTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
    marginHorizontal: isSmallScreen ? 12 : 20,
  },
  quickActionsGrid: {
    flexDirection: 'row',
    gap: 12,
    paddingHorizontal: isSmallScreen ? 12 : 20,
  },

  // ✅ fixed cards
  quickActionCardFixed: {
    flex: 1,
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 4,
    minHeight: 88,
  },
  quickActionCardBlue: {
    backgroundColor: '#3B82F6',
  },
  quickActionCardPurple: {
    backgroundColor: '#8B5CF6',
  },
  quickActionGradientFixed: {
    padding: 14,
  },
  quickActionRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    minHeight: 60,
  },
  quickIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
  },
  quickIconBlue: {
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  quickIconPurple: {
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  quickTextWrap: {
    flex: 1,
    justifyContent: 'center',
    paddingRight: 2,
  },
  quickTitle: {
    color: '#FFFFFF',
    fontSize: isSmallScreen ? 15 : 16,
    fontWeight: '800',
    marginBottom: 2,
  },
  quickSubtitle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 12,
    lineHeight: 16,
    fontWeight: '600',
  },

  /* Assistant Section */
  assistantSection: { marginHorizontal: isSmallScreen ? 12 : 20, marginBottom: 20 },
  assistantCard: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  assistantGradient: { padding: 16 },
  assistantContent: { flexDirection: 'row', alignItems: 'center', gap: 12 },
  assistantIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  assistantTextContainer: { flex: 1, gap: 4 },
  assistantTitle: { color: '#F9FAFB', fontSize: isSmallScreen ? 16 : 18, fontWeight: '700', letterSpacing: 0.2 },
  assistantSubtitle: { color: '#87CEEB', fontSize: isSmallScreen ? 12 : 13, opacity: 0.9, fontWeight: '500' },
});
