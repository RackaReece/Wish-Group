export interface ServiceOption {
  id: string;
  name: string;
  desc: string;
  dur: string;
  icon: string;
  colors: [string, string];
  price: number;
  minPrice?: number;
  maxPrice?: number;
  bulletPoints?: string[];
}

/* =======================
   STANDARD VALET SERVICES
======================= */

export const serviceOptions: ServiceOption[] = [
  {
    id: 'bronze-wash',
    name: 'Bronze Wash',
    desc: 'Mini valet – quick and efficient basic clean',
    dur: '15–20 min',
    icon: 'water-outline',
    colors: ['#CD7F32', '#A0522D'],
    price: 15,
    bulletPoints: [
      'Exterior hand wash and dry',
      'Wheels and tyres cleaned',
      'OR interior vacuum and wipe down',
    ],
  },
  {
    id: 'silver-wash',
    name: 'Silver Wash',
    desc: 'Standard valet – interior and exterior clean',
    dur: '25–30 min',
    icon: 'sparkles-outline',
    colors: ['#C0C0C0', '#A8A8A8'],
    price: 25,
    bulletPoints: [
      'Exterior hand wash and dry',
      'Interior vacuum',
      'Dashboard and trims wiped',
      'Interior and exterior windows cleaned',
    ],
  },
  {
    id: 'gold-wash',
    name: 'Gold Wash',
    desc: 'Full valet – deeper interior and exterior clean',
    dur: '45–60 min',
    icon: 'diamond-outline',
    colors: ['#FFD700', '#FFA500'],
    price: 45,
    bulletPoints: [
      'Everything in Silver Wash',
      'Seats and interior surfaces cleaned',
      'Door shuts and sills cleaned',
      'Windows polished',
      'Interior deodorised',
    ],
  },
  {
    id: 'platinum-wash',
    name: 'Platinum Wash',
    desc: 'Ultimate valet – premium deep clean',
    dur: '2–3 hours',
    icon: 'star-outline',
    colors: ['#E5E4E2', '#BCC6CC'],
    price: 85,
    bulletPoints: [
      'Everything in Gold Wash',
      'Deep interior clean',
      'Carpets and upholstery shampooed',
      'Paint decontamination',
      'Protective wax applied',
    ],
  },
];

/* =======================
   ECO VALET SERVICES
======================= */

export const ecoServiceOptions: ServiceOption[] = [
  {
    id: 'eco-bronze-wash',
    name: 'Eco Bronze Wash',
    desc: 'Eco-friendly basic clean using biodegradable products',
    dur: '15–20 min',
    icon: 'leaf-outline',
    colors: ['#10B981', '#059669'],
    price: 18,
    minPrice: 15,
    maxPrice: 22,
    bulletPoints: [
      'Eco exterior wash or interior clean',
      'Biodegradable products',
      'Low-water cleaning method',
    ],
  },
  {
    id: 'eco-silver-wash',
    name: 'Eco Silver Wash',
    desc: 'Eco-friendly interior and exterior clean',
    dur: '25–30 min',
    icon: 'leaf',
    colors: ['#34D399', '#10B981'],
    price: 28,
    minPrice: 25,
    maxPrice: 32,
    bulletPoints: [
      'Eco exterior wash',
      'Interior vacuum',
      'Dashboard and trims cleaned',
      'Eco-friendly window clean',
    ],
  },
  {
    id: 'eco-gold-wash',
    name: 'Eco Gold Wash',
    desc: 'Complete eco valet with reduced water usage',
    dur: '45–60 min',
    icon: 'reload-outline',
    colors: ['#059669', '#047857'],
    price: 48,
    minPrice: 45,
    maxPrice: 55,
    bulletPoints: [
      'Everything in Eco Silver',
      'Interior fabric refresh',
      'Eco leather and trim care',
      'Natural deodoriser applied',
    ],
  },
  {
    id: 'eco-platinum-wash',
    name: 'Eco Platinum Wash',
    desc: 'Premium eco detailing service',
    dur: '2–3 hours',
    icon: 'earth-outline',
    colors: ['#047857', '#065F46'],
    price: 90,
    minPrice: 85,
    maxPrice: 100,
    bulletPoints: [
      'Deep eco interior clean',
      'Eco paint decontamination',
      'Eco wax protection',
      'Low-impact detailing process',
    ],
  },
];

/* =======================
   DETAILING SERVICES
   (DIRECT FROM YOUR TEXT)
======================= */

export const detailingServiceOptions: ServiceOption[] = [
  {
    id: 'interior-detail',
    name: 'Interior Detail',
    desc: 'Deep interior clean and protection',
    dur: '1–2 hours',
    icon: 'home-outline',
    colors: ['#8B5CF6', '#7C3AED'],
    price: 60,
    bulletPoints: [
      'Vacuuming throughout',
      'Seats cleaned',
      'Trims detailed',
      'Interior glass cleaned',
      'Interior deodorised',
    ],
  },
  {
    id: 'exterior-detail',
    name: 'Exterior Detail',
    desc: 'Complete exterior wash and protection',
    dur: '2–3 hours',
    icon: 'car-sport-outline',
    colors: ['#3B82F6', '#2563EB'],
    price: 80,
    bulletPoints: [
      'Complete exterior wash',
      'Paint decontamination',
      'Light polish',
      'Wheels cleaned',
      'Protective wax applied',
    ],
  },
  {
    id: 'full-detail',
    name: 'Full Detail',
    desc: 'Complete interior and exterior detailing',
    dur: '4–5 hours',
    icon: 'diamond',
    colors: ['#F59E0B', '#D97706'],
    price: 130,
    bulletPoints: [
      'Deep clean inside and out',
      'Interior and exterior detailed',
      'Enhanced gloss',
      'Long-lasting protection',
    ],
  },
  {
    id: 'paint-correction',
    name: 'Paint Correction',
    desc: 'Professional paint restoration and polishing',
    dur: '5–6 hours',
    icon: 'color-filter-outline',
    colors: ['#EF4444', '#DC2626'],
    price: 200,
    bulletPoints: [
      'Removes swirl marks',
      'Reduces light scratches',
      'Restores gloss',
      'Improves paint clarity',
    ],
  },
  {
    id: 'ceramic-coating',
    name: 'Ceramic Coating',
    desc: 'Long-lasting ceramic paint protection',
    dur: '6–8 hours',
    icon: 'shield-checkmark-outline',
    colors: ['#6366F1', '#4F46E5'],
    price: 350,
    bulletPoints: [
      'High-gloss ceramic finish',
      'Hydrophobic protection',
      'Protection from dirt, UV, and chemicals',
    ],
  },
  {
    id: 'ppf',
    name: 'PPF (Paint Protection Film)',
    desc: 'Premium physical paint protection',
    dur: 'Varies',
    icon: 'layers-outline',
    colors: ['#10B981', '#059669'],
    price: 500,
    minPrice: 400,
    maxPrice: 600,
    bulletPoints: [
      'Protection against stone chips',
      'Guards against scratches and road damage',
      'Self-healing paint protection film',
    ],
  },
];
