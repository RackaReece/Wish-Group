import { Dimensions } from 'react-native';
import { colors } from './colors';

const { width } = Dimensions.get('window');

export const BOOKING_CARD = {
  CARD_WIDTH: width - 48,
  SNAP_INTERVAL: width - 48 + 12,
  PADDING_H: 16,
  PADDING_TOP: 10,
  BORDER_RADIUS: 20,
  INTENSITY: 35,
  SKY: colors.SKY,
  GRADIENT: [colors.SKY, '#60A5FA', '#3B82F6'] as const,
  GRADIENT_CTA: [colors.SKY, '#60A5FA'] as const,
  ICON_SIZE: 52,
  ICON_RADIUS: 16,
};
