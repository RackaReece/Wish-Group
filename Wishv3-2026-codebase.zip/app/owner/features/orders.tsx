import React, { useState, useEffect, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
  RefreshControl,
  Alert,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { useAuth } from '@/providers/enhanced-auth-context';
import { supabase } from '@/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '@/components/shared/AppHeader';
import { customerTheme } from '@/constants/customerTheme';
import { colors } from '@/constants/colors';
import { getServiceDisplayName } from '@/utils/serviceNameMapper';

const SKY = colors.SKY;

type CompletedBooking = {
  id: string;
  service_name: string | null;
  service_type: string | null;
  price: number;
  completed_at: string | null;
  created_at: string;
  valeter_name: string | null;
  location_address: string | null;
  tip_amount: number | null;
  rating: number | null;
};

function buildReceiptHTML(booking: CompletedBooking, index: number): string {
  const date = booking.completed_at || booking.created_at;
  const formattedDate = new Date(date).toLocaleDateString('en-GB', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit',
  });
  const serviceName = getServiceDisplayName(booking.service_type, booking.service_name);
  const subtotal = Number(booking.price) || 0;
  const tip = Number(booking.tip_amount) || 0;
  const total = subtotal + tip;

  return `
    <div style="font-family: system-ui, sans-serif; padding: 24px; max-width: 400px;">
      <h1 style="color: #0ea5e9; font-size: 24px; margin-bottom: 4px;">Wish a Wash</h1>
      <p style="color: #64748b; font-size: 12px; margin-bottom: 24px;">Receipt</p>
      <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 16px 0;" />
      <p style="font-size: 14px; margin: 8px 0;"><strong>Order #</strong> ${String(booking.id).slice(0, 8).toUpperCase()}</p>
      <p style="font-size: 14px; margin: 8px 0;"><strong>Date</strong> ${formattedDate}</p>
      <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 16px 0;" />
      <p style="font-size: 16px; margin: 12px 0;"><strong>${serviceName}</strong></p>
      ${booking.valeter_name ? `<p style="font-size: 14px; color: #64748b; margin: 4px 0;">Valeter: ${booking.valeter_name}</p>` : ''}
      ${booking.location_address ? `<p style="font-size: 12px; color: #94a3b8; margin: 4px 0;">${booking.location_address}</p>` : ''}
      <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 16px 0;" />
      <div style="display: flex; justify-content: space-between; margin: 8px 0;">
        <span>Service</span>
        <span>£${subtotal.toFixed(2)}</span>
      </div>
      ${tip > 0 ? `
      <div style="display: flex; justify-content: space-between; margin: 8px 0;">
        <span>Tip</span>
        <span>£${tip.toFixed(2)}</span>
      </div>
      ` : ''}
      <div style="display: flex; justify-content: space-between; font-size: 18px; font-weight: bold; margin-top: 16px; padding-top: 12px; border-top: 2px solid #0ea5e9;">
        <span>Total</span>
        <span>£${total.toFixed(2)}</span>
      </div>
      <p style="color: #94a3b8; font-size: 11px; margin-top: 24px; text-align: center;">Thank you for choosing Wish a Wash</p>
    </div>
  `;
}

export default function OrdersScreen() {
  const { user } = useAuth();
  const [orders, setOrders] = useState<CompletedBooking[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [generatingId, setGeneratingId] = useState<string | null>(null);

  const loadOrders = useCallback(async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('id, service_name, service_type, price, completed_at, created_at, valeter_name, location_address, tip_amount, rating')
        .eq('user_id', user.id)
        .eq('status', 'completed')
        .order('completed_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      setOrders((data || []).map((r) => ({
        id: r.id,
        service_name: r.service_name,
        service_type: r.service_type,
        price: Number(r.price) || 0,
        completed_at: r.completed_at,
        created_at: r.created_at,
        valeter_name: r.valeter_name,
        location_address: r.location_address,
        tip_amount: r.tip_amount != null ? Number(r.tip_amount) : null,
        rating: r.rating != null ? Number(r.rating) : null,
      })));
    } catch (e) {
      console.error('[Orders] load error:', e);
      Alert.alert('Error', 'Failed to load orders');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [user?.id]);

  useEffect(() => {
    loadOrders();
  }, [loadOrders]);

  const onRefresh = useCallback(() => {
    setRefreshing(true);
    loadOrders();
  }, [loadOrders]);

  const handleGeneratePDF = async (booking: CompletedBooking) => {
    if (Platform.OS === 'web') {
      Alert.alert('PDF', 'PDF receipts are not available on web. Try the mobile app.');
      return;
    }
    setGeneratingId(booking.id);
    try {
      const PrintMod = await import('expo-print');
      const Print = PrintMod?.default;
      const SharingMod = await import('expo-sharing');
      const Sharing = SharingMod?.default;

      const printFn = Print?.printToFileAsync;
      if (typeof printFn !== 'function') {
        Alert.alert('Error', 'PDF generation is not available on this device.');
        setGeneratingId(null);
        return;
      }

      const html = `
        <!DOCTYPE html>
        <html>
          <head><meta charset="utf-8"><title>Receipt</title></head>
          <body>${buildReceiptHTML(booking, 0)}</body>
        </html>
      `;

      const { uri } = await printFn({
        html,
        base64: false,
      });

      const canShare = Sharing ? await Sharing.isAvailableAsync() : false;
      if (canShare) {
        await Sharing.shareAsync(uri, {
          mimeType: 'application/pdf',
          dialogTitle: `Receipt - ${getServiceDisplayName(booking.service_type, booking.service_name)}`,
        });
      } else {
        Alert.alert('Receipt saved', `PDF saved to: ${uri}`);
      }
    } catch (e: any) {
      console.error('[Orders] PDF error:', e);
      Alert.alert('Error', e?.message || 'Failed to generate receipt');
    } finally {
      setGeneratingId(null);
    }
  };

  const formatDate = (d: string | null) => {
    if (!d) return '—';
    return new Date(d).toLocaleDateString('en-GB', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Orders"
        subtitle={loading ? 'Loading…' : `${orders.length} completed job${orders.length !== 1 ? 's' : ''}`}
        showBack
      />

      {loading ? (
        <View style={styles.centerContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading orders…</Text>
        </View>
      ) : orders.length === 0 ? (
        <View style={styles.centerContainer}>
          <View style={styles.emptyIcon}>
            <Ionicons name="receipt-outline" size={48} color={SKY} />
          </View>
          <Text style={styles.emptyTitle}>No orders yet</Text>
          <Text style={styles.emptySubtitle}>Completed washes will appear here</Text>
          <TouchableOpacity style={styles.bookButton} onPress={() => router.push('/owner/booking')} activeOpacity={0.9}>
            <LinearGradient colors={[SKY, '#60A5FA']} style={styles.bookGradient}>
              <Ionicons name="water" size={20} color="#FFFFFF" />
              <Text style={styles.bookText}>Book a Wash</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView
          style={styles.scrollView}
          contentContainerStyle={[styles.scrollContent, { paddingTop: HEADER_CONTENT_OFFSET }]}
          showsVerticalScrollIndicator={false}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={SKY} />
          }
        >
          {orders.map((order) => (
            <View key={order.id} style={styles.orderCard}>
              <View style={styles.orderHeader}>
                <View style={styles.orderIconWrap}>
                  <Ionicons name="car-outline" size={22} color={SKY} />
                </View>
                <View style={styles.orderInfo}>
                  <Text style={styles.orderService}>{getServiceDisplayName(order.service_type, order.service_name)}</Text>
                  <Text style={styles.orderDate}>{formatDate(order.completed_at || order.created_at)}</Text>
                  {order.valeter_name && (
                    <Text style={styles.orderValeter}>{order.valeter_name}</Text>
                  )}
                </View>
                <Text style={styles.orderPrice}>£{(order.price + (order.tip_amount || 0)).toFixed(2)}</Text>
              </View>
              <TouchableOpacity
                style={styles.receiptButton}
                onPress={() => handleGeneratePDF(order)}
                disabled={!!generatingId}
                activeOpacity={0.8}
              >
                {generatingId === order.id ? (
                  <ActivityIndicator size="small" color={SKY} />
                ) : (
                  <>
                    <Ionicons name="document-text-outline" size={18} color={SKY} />
                    <Text style={styles.receiptText}>Receipt</Text>
                  </>
                )}
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  centerContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    marginTop: 12,
  },
  emptyIcon: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 8,
  },
  emptySubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    marginBottom: 24,
  },
  bookButton: {
    borderRadius: 14,
    overflow: 'hidden',
  },
  bookGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingVertical: 12,
    paddingHorizontal: 24,
  },
  bookText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
  scrollView: { flex: 1 },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  orderCard: {
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  orderHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  orderIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  orderInfo: {
    flex: 1,
    minWidth: 0,
  },
  orderService: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 2,
  },
  orderDate: {
    color: '#94A3B8',
    fontSize: 13,
    marginBottom: 2,
  },
  orderValeter: {
    color: '#94A3B8',
    fontSize: 12,
  },
  orderPrice: {
    color: SKY,
    fontSize: 18,
    fontWeight: '800',
  },
  receiptButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  receiptText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
  },
});
