import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../../src/lib/supabase';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import AppHeader from '../../../../src/components/shared/AppHeader';
import UberBottomSheet, { BottomSheetState } from '../../../../src/components/booking/UberBottomSheet';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;

type Vehicle = {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
};

export default function DetailingVehicleSelection() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [sheetState, setSheetState] = useState<BottomSheetState>('half');
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();

    // Get user location
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status === 'granted') {
          const location = await Location.getCurrentPositionAsync({
            accuracy: Location.Accuracy.Balanced,
          });
          const coords = {
            latitude: location.coords.latitude,
            longitude: location.coords.longitude,
          };
          setUserLocation(coords);
          setRegion({
            latitude: coords.latitude,
            longitude: coords.longitude,
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          });
        }
      } catch (error) {
        console.warn('Error getting location:', error);
      }
    })();
  }, []);

  useEffect(() => {
    loadVehicles();
  }, [user?.id]);

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      setVehicles(data || []);
      if (data && data.length > 0) {
        const defaultVehicle = data.find(v => v.is_default) || data[0];
        setSelectedVehicle(defaultVehicle.id);
      }
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleContinue = async () => {
    if (!selectedVehicle) return;
    await hapticFeedback('medium');
    router.push({
      pathname: '/owner/booking/detailing/location',
      params: { vehicleId: selectedVehicle },
    });
  };

  const selectedVehicleData = vehicles.find(v => v.id === selectedVehicle);
  const previewText = selectedVehicleData
    ? `${selectedVehicleData.make} ${selectedVehicleData.model} • ${selectedVehicleData.registration}`
    : 'Select a vehicle';

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {/* Fullscreen map - always visible */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
<View style={styles.userMarkerContainer}>
                <Image
                  source={require('../../../../assets/car.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Header floating over the map */}
      <AppHeader 
        title="Select Vehicle"
        subtitle="Choose your vehicle for detailing"
        showBack={true}
        onBack={() => router.back()}
      />

      {/* Uber-style bottom sheet */}
      <UberBottomSheet
        state={sheetState}
        onStateChange={setSheetState}
        previewContent={
          <View style={styles.previewContent}>
            <View style={styles.previewRow}>
              <Ionicons name="diamond" size={18} color={PREMIUM_PURPLE} />
              <Text style={styles.previewText} numberOfLines={1}>
                {previewText}
              </Text>
            </View>
            {selectedVehicleData && (
              <Text style={styles.previewDetails}>
                {selectedVehicleData.color} • {selectedVehicleData.type}
              </Text>
            )}
          </View>
        }
        footerButton={
          selectedVehicle ? (
            <TouchableOpacity
              onPress={handleContinue}
              style={styles.continueButton}
              activeOpacity={0.85}
            >
              <LinearGradient
                colors={[PREMIUM_PURPLE, '#7C3AED']}
                style={styles.continueGradient}
              >
                <Text style={styles.continueText}>Continue</Text>
                <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
              </LinearGradient>
            </TouchableOpacity>
          ) : null
        }
      >
        {loading ? (
              <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color={PREMIUM_PURPLE} />
                <Text style={styles.loadingText}>Loading vehicles...</Text>
              </View>
            ) : vehicles.length === 0 ? (
              <View style={styles.emptyContainer}>
                <View style={styles.emptyIconWrapper}>
                  <Ionicons name="diamond-outline" size={64} color={PREMIUM_PURPLE} style={{ opacity: 0.6 }} />
                </View>
                <Text style={styles.emptyTitle}>No vehicles found</Text>
                <Text style={styles.emptySubtext}>Add a vehicle to continue booking</Text>
                <TouchableOpacity
                  onPress={() => router.push('/owner/settings/vehicle-management')}
                  style={styles.addVehicleButton}
                  activeOpacity={0.85}
                >
                  <LinearGradient
                    colors={[PREMIUM_PURPLE, '#7C3AED']}
                    style={styles.addVehicleGradient}
                  >
                    <Ionicons name="add-circle" size={20} color="#FFFFFF" />
                    <Text style={styles.addVehicleText}>Add Vehicle</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            ) : (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Your Vehicles</Text>
                <Text style={styles.sectionSubtitle}>Swipe to see all options</Text>
                <ScrollView
                  horizontal
                  showsHorizontalScrollIndicator={false}
                  contentContainerStyle={styles.cardsScrollContent}
                  snapToInterval={width - 40}
                  decelerationRate="fast"
                  pagingEnabled
                  snapToAlignment="start"
                >
                  {vehicles.map((vehicle) => {
                    const isSelected = selectedVehicle === vehicle.id;
                    return (
                      <View key={vehicle.id} style={[styles.cardWrapper, { width: width - 40 }]}>
                        <GlassCard
                          onPress={() => {
                            hapticFeedback('light');
                            setSelectedVehicle(vehicle.id);
                          }}
                          style={[styles.vehicleCard, isSelected && styles.vehicleCardSelected]}
                          borderColor={isSelected ? PREMIUM_PURPLE : 'rgba(139,92,246,0.25)'}
                        >
                          <LinearGradient
                            colors={isSelected ? [PREMIUM_PURPLE + '20', PREMIUM_PURPLE + '10'] : ['transparent', 'transparent']}
                            style={StyleSheet.absoluteFill}
                          />
                          
                          <View style={styles.vehicleHeader}>
                            <View style={[styles.vehicleIconWrapper, isSelected && styles.vehicleIconWrapperSelected]}>
                              <Ionicons name="diamond" size={28} color={isSelected ? PREMIUM_PURPLE : 'rgba(139,92,246,0.8)'} />
                            </View>
                            <View style={styles.vehicleInfo}>
                              <View style={styles.vehicleNameRow}>
                                <View style={styles.vehicleNameContainer}>
                                  <Text style={styles.vehicleName} numberOfLines={1}>
                                    {vehicle.make} {vehicle.model}
                                  </Text>
                                  {vehicle.is_default && (
                                    <View style={styles.defaultBadge}>
                                      <Ionicons name="star" size={10} color="#10B981" />
                                      <Text style={styles.defaultBadgeText}>Default</Text>
                                    </View>
                                  )}
                                </View>
                                {isSelected && (
                                  <View style={styles.selectedCheck}>
                                    <Ionicons name="checkmark-circle" size={24} color={PREMIUM_PURPLE} />
                                  </View>
                                )}
                              </View>
                              <View style={styles.vehicleDetailsRow}>
                                <View style={styles.detailItem}>
                                  <Ionicons name="color-palette-outline" size={14} color={PREMIUM_PURPLE} />
                                  <Text style={styles.detailText}>{vehicle.color}</Text>
                                </View>
                                <View style={styles.detailDivider} />
                                <View style={styles.detailItem}>
                                  <Ionicons name="document-text-outline" size={14} color={PREMIUM_PURPLE} />
                                  <Text style={styles.detailText}>{vehicle.registration}</Text>
                                </View>
                              </View>
                              <View style={styles.vehicleTypeRow}>
                                <Ionicons name="information-circle-outline" size={12} color="rgba(249,250,251,0.6)" />
                                <Text style={styles.vehicleTypeText}>{vehicle.type}</Text>
                              </View>
                            </View>
                          </View>
                        </GlassCard>
                      </View>
                    );
                  })}
                </ScrollView>
              </View>
            )}
      </UberBottomSheet>
    </SafeAreaView>
  );
}