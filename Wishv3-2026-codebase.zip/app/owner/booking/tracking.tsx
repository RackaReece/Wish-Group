import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  ActivityIndicator,
  Image,
  Modal,
  Pressable,
  Platform,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Region } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams, useFocusEffect } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import GlassCard from '../../../src/components/booking/GlassCard';
import AnimatedProgress from '../../../src/components/booking/AnimatedProgress';
import SuccessOverlay from '../../../src/components/booking/SuccessOverlay';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import AppHeader from '../../../src/components/shared/AppHeader';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { colors } from '../../../src/constants/colors';
import { BOOKING_CARD } from '../../../src/constants/bookingCardTheme';
import { customerTheme } from '../../../src/constants/customerTheme';

const SKY = colors.SKY ?? '#38BDF8';
const { width } = Dimensions.get('window');
const CARD_WIDTH = width - 48;

type BookingStatus =
  | 'pending_valeter_acceptance'
  | 'pending_payment'
  | 'confirmed'
  | 'valeter_assigned'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled';

type BookingRow = {
  id: string;
  status: BookingStatus;
  service_type: string;
  service_name?: string | null;
  price: number | string | null;
  location_address?: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
  valeter_id?: string | null;
  location_id?: string | null;
};

type WashHub = {
  id: string;
  name: string;
  address: string | null;
  latitude: number | null;
  longitude: number | null;
};

export default function BookingTracking() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const insets = useSafeAreaInsets();

  const bookingId = typeof params.bookingId === 'string' ? params.bookingId : undefined;

  const [booking, setBooking] = useState<BookingRow | null>(null);
  const [valeterName, setValeterName] = useState<string>('Valeter');
  const [status, setStatus] = useState<BookingStatus>('pending_payment');
  const [valeterLocation, setValeterLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [washHub, setWashHub] = useState<WashHub | null>(null);
  const [cancelling, setCancelling] = useState(false);
  const [markingArrived, setMarkingArrived] = useState(false);
  const [infoModalVisible, setInfoModalVisible] = useState(false);
  const [showCompletedConfetti, setShowCompletedConfetti] = useState(false);

  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const bookingChannelRef = useRef<any>(null);
  const presenceChannelRef = useRef<any>(null);
  const presenceValeterIdRef = useRef<string | null>(null);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(markerPulse, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    if (!bookingId) return;

    const start = async () => {
      await loadBooking();
      subscribeToBooking();
    };

    start();

    return () => {
      if (bookingChannelRef.current) supabase.removeChannel(bookingChannelRef.current);
      if (presenceChannelRef.current) supabase.removeChannel(presenceChannelRef.current);
      bookingChannelRef.current = null;
      presenceChannelRef.current = null;
      presenceValeterIdRef.current = null;
    };
  }, [bookingId]);

  // Poll for updates every 4s - ensures tracking updates even if Realtime is delayed
  useEffect(() => {
    if (!bookingId || !booking) return;
    if (status === 'completed' || status === 'cancelled') return;

    const interval = setInterval(() => loadBooking(), 4000);
    return () => clearInterval(interval);
  }, [bookingId, booking?.id, status]);

  // Refetch immediately when screen gains focus (e.g. returning from payment)
  useFocusEffect(
    React.useCallback(() => {
      if (bookingId) loadBooking();
    }, [bookingId])
  );

  const loadBooking = async () => {
    if (!bookingId) return;
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', bookingId)
        .single();

      if (error) throw error;

      const row = data as BookingRow;
      setBooking(row);
      setStatus(row.status);

      if (row.valeter_id) {
        const profile = await fetchProfileById(row.valeter_id);
        setValeterName(profile?.full_name || 'Valeter');
        ensurePresenceSubscription(row.valeter_id);
        await loadValeterPresenceOnce(row.valeter_id);
      } else {
        setValeterName('Valeter');
      }

      if (row.location_id) {
        await loadWashHub(row.location_id);
      }

      updateMapRegion(row);
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const subscribeToBooking = () => {
    if (!bookingId || bookingChannelRef.current) return;

    const channel = supabase
      .channel(`booking-${bookingId}`)
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'bookings',
          filter: `id=eq.${bookingId}`,
        },
        async (payload) => {
          const updated = payload.new as BookingRow;
          setBooking(updated);
          setStatus(updated.status);

          if (updated.valeter_id) {
            const profile = await fetchProfileById(updated.valeter_id);
            setValeterName(profile?.full_name || 'Valeter');
            ensurePresenceSubscription(updated.valeter_id);
            await loadValeterPresenceOnce(updated.valeter_id);
          }

          if (updated.location_id && !washHub) {
            await loadWashHub(updated.location_id);
          }

          if (updated.status === 'completed') {
            setShowCompletedConfetti(true);
          }

          if (updated.status === 'cancelled') {
            setTimeout(() => router.replace('/owner/owner-dashboard'), 700);
          }

          updateMapRegion(updated);
        }
      )
      .subscribe();

    bookingChannelRef.current = channel;
  };

  const ensurePresenceSubscription = (valeterId: string) => {
    if (presenceValeterIdRef.current === valeterId && presenceChannelRef.current) return;
    if (presenceChannelRef.current) {
      supabase.removeChannel(presenceChannelRef.current);
      presenceChannelRef.current = null;
    }
    presenceValeterIdRef.current = valeterId;

    const channel = supabase
      .channel(`valeter-presence-${valeterId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'valeter_presence',
          filter: `user_id=eq.${valeterId}`,
        },
        (payload) => {
          const updated = payload.new as any;
          if (updated?.last_lat && updated?.last_lng) {
            setValeterLocation({ latitude: updated.last_lat, longitude: updated.last_lng });
          }
        }
      )
      .subscribe();

    presenceChannelRef.current = channel;
  };

  const loadValeterPresenceOnce = async (valeterId: string) => {
    try {
      const { data, error } = await supabase
        .from('valeter_presence')
        .select('last_lat, last_lng')
        .eq('user_id', valeterId)
        .maybeSingle();

      if (error) return;
      if (data?.last_lat && data?.last_lng) {
        setValeterLocation({ latitude: data.last_lat, longitude: data.last_lng });
      }
    } catch {}
  };

  const loadWashHub = async (locationId: string) => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, latitude, longitude')
        .eq('id', locationId)
        .maybeSingle();

      if (error) throw error;
      if (data && data.latitude && data.longitude) {
        setWashHub({
          id: data.id,
          name: data.name || 'Wash Hub',
          address: data.address,
          latitude: data.latitude,
          longitude: data.longitude,
        });
      }
    } catch (error) {
      console.error('Error loading wash hub:', error);
    }
  };

  const updateMapRegion = (bookingData: BookingRow) => {
    const points: Array<{ latitude: number; longitude: number }> = [];

    if (bookingData.location_lat && bookingData.location_lng) {
      points.push({ latitude: bookingData.location_lat, longitude: bookingData.location_lng });
    }
    if (valeterLocation) {
      points.push(valeterLocation);
    }
    if (washHub?.latitude && washHub?.longitude) {
      points.push({ latitude: washHub.latitude, longitude: washHub.longitude });
    }

    if (points.length === 0 && bookingData.location_lat && bookingData.location_lng) {
      setRegion({
        latitude: bookingData.location_lat,
        longitude: bookingData.location_lng,
        latitudeDelta: 0.05,
        longitudeDelta: 0.05,
      });
      return;
    }

    if (points.length > 0) {
      const lats = points.map((p) => p.latitude);
      const lngs = points.map((p) => p.longitude);
      const minLat = Math.min(...lats);
      const maxLat = Math.max(...lats);
      const minLng = Math.min(...lngs);
      const maxLng = Math.max(...lngs);
      const latPadding = (maxLat - minLat) * 0.3;
      const lngPadding = (maxLng - minLng) * 0.3;

      setRegion({
        latitude: (minLat + maxLat) / 2,
        longitude: (minLng + maxLng) / 2,
        latitudeDelta: Math.max(0.01, maxLat - minLat + latPadding * 2),
        longitudeDelta: Math.max(0.01, maxLng - minLng + lngPadding * 2),
      });
    }
  };

  useEffect(() => {
    if (booking) updateMapRegion(booking);
  }, [booking, valeterLocation, washHub]);

  const canCancel = status !== 'completed' && status !== 'cancelled' && status !== 'pending_payment';

  const cancelBooking = async () => {
    if (!bookingId || !user?.id || !canCancel) return;
    try {
      setCancelling(true);
      const { error } = await supabase
        .from('bookings')
        .update({
          status: 'cancelled',
          cancelled_at: new Date().toISOString(),
          cancelled_by: 'customer',
          cancellation_reason: 'Cancelled by customer',
        })
        .eq('id', bookingId);

      if (error) throw error;
      setStatus('cancelled');
    } catch (e) {
      console.warn('[BookingTracking] cancelBooking error', e);
      Alert.alert('Could not cancel', 'Please try again in a moment.');
    } finally {
      setCancelling(false);
    }
  };

  const handleMarkArrived = async () => {
    if (!bookingId || !washHub) return;
    try {
      setMarkingArrived(true);
      const { error } = await supabase
        .from('bookings')
        .update({ status: 'arrived' })
        .eq('id', bookingId);
      if (error) throw error;
      setStatus('arrived');
      hapticFeedback('medium');
    } catch (e) {
      console.warn('[BookingTracking] handleMarkArrived error', e);
      Alert.alert('Could not update', 'Please try again.');
    } finally {
      setMarkingArrived(false);
    }
  };

  const showArrivedButton =
    washHub &&
    ['confirmed', 'valeter_assigned', 'en_route', 'scheduled'].includes(status);

  const onPressCancel = () => {
    Alert.alert(
      'Cancel booking?',
      'This will cancel your booking. If a valeter is already on the way, you may still be charged depending on your policy.',
      [
        { text: 'Keep booking', style: 'cancel' },
        { text: 'Cancel booking', style: 'destructive', onPress: cancelBooking },
      ]
    );
  };

  const getStatusProgress = (): number => {
    switch (status) {
      case 'pending_valeter_acceptance':
      case 'pending_payment':
        return 20;
      case 'confirmed':
        return 40;
      case 'en_route':
        return 60;
      case 'arrived':
        return 80;
      case 'in_progress':
        return 90;
      case 'completed':
        return 100;
      case 'cancelled':
        return 100;
      default:
        return 0;
    }
  };

  const getStages = (): { label: string; done: boolean; current: boolean }[] => {
    const s = status;
    return [
      { label: 'Accepted', done: !['pending_valeter_acceptance', 'pending_payment'].includes(s), current: ['confirmed', 'valeter_assigned'].includes(s) },
      { label: 'En route', done: ['arrived', 'in_progress', 'completed'].includes(s), current: s === 'en_route' },
      { label: 'Arrived', done: ['in_progress', 'completed'].includes(s), current: s === 'arrived' },
      { label: 'Washing', done: s === 'completed', current: s === 'in_progress' },
      { label: 'Done', done: s === 'completed', current: s === 'completed' },
    ];
  };

  const getStageProgressPercent = (): number => {
    const stages = getStages();
    const doneCount = stages.filter(s => s.done).length;
    const currentIndex = stages.findIndex(s => s.current);
    if (currentIndex >= 0) return (currentIndex + 0.5) * 25;
    return doneCount * 25;
  };

  const getStatusMessage = (): string => {
    switch (status) {
      case 'pending_valeter_acceptance':
        return 'Waiting for valeter to accept';
      case 'pending_payment':
        return 'Waiting for payment';
      case 'confirmed':
        return 'Valeter assigned – Ready to start';
      case 'en_route':
        return washHub ? 'Heading to wash hub' : 'Valeter on the way to you';
      case 'arrived':
        return washHub ? 'At wash hub' : 'Valeter has arrived';
      case 'in_progress':
        return washHub ? 'Vehicle being washed' : 'Service in progress';
      case 'completed':
        return 'Service completed';
      case 'cancelled':
        return 'Booking cancelled';
      default:
        return 'Tracking your booking';
    }
  };

  const defaultRegion: Region = {
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  };

  const mapRegion = booking ? region : defaultRegion;
  const isLoading = !booking && !!bookingId;

  const locationDisplay = washHub ? washHub.name : (booking?.location_address || '—');

  return (
    <SafeAreaView style={styles.container} edges={[] as any}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
      <MapView
        style={StyleSheet.absoluteFill}
        region={mapRegion}
        showsUserLocation={true}
        mapType={Platform.OS === 'ios' ? 'mutedStandard' : 'standard'}
        mapPadding={{ top: 0, bottom: 0, left: 0, right: 0 }}
      >
          {/* Customer / job location marker */}
          {booking?.location_lat && booking?.location_lng && (
            <Marker
              coordinate={{
                latitude: booking.location_lat,
                longitude: booking.location_lng,
              }}
              title="Your Location"
            >
              <View style={styles.markerContainer}>
                <View style={styles.marker}>
                  <Image
                    source={require('../../../assets/car.png')}
                    style={styles.carMarkerImage}
                    resizeMode="contain"
                  />
                </View>
              </View>
            </Marker>
          )}

          {/* Valeter location marker */}
          {valeterLocation && (
            <Marker coordinate={valeterLocation} title={valeterName}>
              <Animated.View
                style={[styles.markerContainer, { transform: [{ scale: markerPulse }] }]}
              >
                <View style={styles.valeterMarker}>
                  <Image
                    source={
                      booking?.service_type?.includes('detailing')
                        ? require('../../../assets/detailing.png')
                        : require('../../../assets/cleaning.png')
                    }
                    style={styles.valeterMarkerImage}
                    resizeMode="contain"
                  />
                </View>
                <View style={styles.markerPulse} />
              </Animated.View>
            </Marker>
          )}

          {/* Wash hub marker */}
          {washHub?.latitude && washHub?.longitude && (
            <Marker
              coordinate={{ latitude: washHub.latitude, longitude: washHub.longitude }}
              title={washHub.name}
            >
              <View style={styles.markerContainer}>
                <View style={styles.hubMarker}>
                  <Image
                    source={
                      booking?.service_type?.includes('detailing')
                        ? require('../../../assets/detailing.png')
                        : require('../../../assets/cleaning.png')
                    }
                    style={styles.hubMarkerImage}
                    resizeMode="contain"
                  />
                </View>
              </View>
            </Marker>
          )}
      </MapView>

      <View style={styles.headerOverlay}>
        <AppHeader
          title="Tracking"
          showBack={false}
          rightAction={
            <TouchableOpacity
              onPress={() => router.replace('/owner/owner-dashboard')}
              style={styles.headerExitButton}
              activeOpacity={0.7}
            >
              <Ionicons name="close" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          }
        />
      </View>

      {isLoading ? (
        <View style={styles.loadingOverlay}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading booking...</Text>
        </View>
      ) : !booking ? (
        <View style={styles.emptyOverlay}>
          <GlassCard style={styles.emptyCard} accountType="customer">
            <View style={styles.emptyContent}>
              <Ionicons name="navigate-outline" size={64} color={SKY} style={{ opacity: 0.5 }} />
              <Text style={styles.emptyTitle}>No Active Booking</Text>
              <Text style={styles.emptyText}>
                We couldn't find an active booking to track. Head to the home screen to book a wash.
              </Text>
              <TouchableOpacity
                style={styles.backButton}
                onPress={() => router.replace('/owner/owner-dashboard')}
                activeOpacity={0.8}
              >
                <LinearGradient colors={[SKY, '#60A5FA']} style={styles.backButtonGradient}>
                  <Text style={styles.backButtonText}>Go to Dashboard</Text>
                  <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </GlassCard>
        </View>
      ) : (
        <Animated.View
          style={[
            styles.cardContainer,
            {
              opacity: fadeAnim,
              bottom: TAB_BAR_TOTAL_HEIGHT + insets.bottom + 20,
            },
          ]}
        >
          <View style={styles.cardWrapper}>
            <GlassCard
              style={styles.trackingCard}
              borderRadius={BOOKING_CARD.BORDER_RADIUS}
              intensity={BOOKING_CARD.INTENSITY}
              borderColor={SKY}
              accountType="customer"
            >
              <LinearGradient
                colors={[colors.SKY + '10', colors.SKY + '05', 'transparent']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
              {/* Top row: service, status, info */}
              <View style={styles.cardTopRow}>
                <View style={styles.cardHeader}>
                  <View style={styles.trackingIconWrap}>
                    <Image
                      source={
                        booking.service_type?.includes('detailing')
                          ? require('../../../assets/detailing.png')
                          : require('../../../assets/cleaning.png')
                      }
                      style={styles.trackingIcon}
                      resizeMode="contain"
                    />
                  </View>
                  <View style={styles.cardHeaderText}>
                    <Text style={styles.trackingServiceName} numberOfLines={1}>
                      {getServiceDisplayName(booking.service_type, booking.service_name)}
                    </Text>
                    <Text style={styles.trackingStatusMessage}>{getStatusMessage()}</Text>
                  </View>
                </View>
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    setInfoModalVisible(true);
                  }}
                  style={styles.infoBox}
                  activeOpacity={0.8}
                >
                  <View style={styles.infoBoxInner}>
                    <Ionicons name="information-circle" size={26} color={SKY} />
                  </View>
                </TouchableOpacity>
              </View>

              {/* Status ring with chat (left) and cancel (right) buttons */}
              <View style={styles.ringRow}>
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    if (bookingId) {
                      router.push({ pathname: '/owner/booking/chat', params: { bookingId } } as any);
                    }
                  }}
                  style={styles.ringSideButton}
                  activeOpacity={0.8}
                >
                  <View style={styles.ringSideButtonInner}>
                    <Ionicons name="chatbubble-ellipses-outline" size={22} color={SKY} />
                  </View>
                </TouchableOpacity>

                <View style={styles.ringCenter}>
                  <AnimatedProgress progress={getStatusProgress()} size={88} />
                  {/* Horizontal stepper */}
                  <View style={styles.stepper}>
                    <View style={styles.stepperTrack}>
                      <View
                        style={[
                          styles.stepperFill,
                          { width: `${getStageProgressPercent()}%` },
                        ]}
                      />
                    </View>
                    <View style={styles.stepperSteps}>
                      {getStages().map((stage, i) => (
                        <View key={i} style={styles.stepperStep}>
                          <View
                            style={[
                              styles.stepperDot,
                              stage.done && styles.stepperDotDone,
                              stage.current && styles.stepperDotCurrent,
                            ]}
                          >
                            {stage.done ? (
                              <Ionicons name="checkmark" size={10} color="#FFFFFF" />
                            ) : null}
                          </View>
                          <Text
                            style={[
                              styles.stepperLabel,
                              stage.done && styles.stepperLabelDone,
                              stage.current && styles.stepperLabelCurrent,
                            ]}
                            numberOfLines={1}
                          >
                            {stage.label}
                          </Text>
                        </View>
                      ))}
                    </View>
                  </View>
                </View>

                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    if (canCancel) onPressCancel();
                  }}
                  disabled={!canCancel || cancelling}
                  style={[styles.ringSideButton, !canCancel && styles.ringSideButtonDisabled]}
                  activeOpacity={0.8}
                >
                  <View style={[styles.ringSideButtonInner, !canCancel && styles.ringSideButtonInnerDisabled]}>
                    {cancelling ? (
                      <ActivityIndicator size="small" color="#EF4444" />
                    ) : (
                      <Ionicons name="close-circle-outline" size={22} color={canCancel ? '#EF4444' : '#64748B'} />
                    )}
                  </View>
                </TouchableOpacity>
              </View>

              {/* Payment button when pending */}
              {status === 'pending_payment' && (
                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('medium');
                    if (bookingId) {
                      router.push({ pathname: '/owner/booking/payment', params: { bookingId } } as any);
                    }
                  }}
                  style={styles.payButton}
                  activeOpacity={0.9}
                >
                  <LinearGradient
                    colors={[SKY, '#0EA5E9']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={styles.payButtonGradient}
                  >
                    <Ionicons name="wallet" size={20} color="#FFFFFF" />
                    <Text style={styles.payButtonText}>Pay £{Number(booking.price ?? 0).toFixed(2)}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              )}

              {/* Wash hub: "I've arrived" button */}
              {showArrivedButton && (
                <TouchableOpacity
                  onPress={handleMarkArrived}
                  disabled={markingArrived}
                  style={styles.arrivedButton}
                  activeOpacity={0.9}
                >
                  <LinearGradient
                    colors={['#10B981', '#059669']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 0 }}
                    style={styles.arrivedButtonGradient}
                  >
                    {markingArrived ? (
                      <ActivityIndicator size="small" color="#FFFFFF" />
                    ) : (
                      <>
                        <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                        <Text style={styles.arrivedButtonText}>I've arrived</Text>
                      </>
                    )}
                  </LinearGradient>
                </TouchableOpacity>
              )}

              {canCancel && status !== 'pending_payment' && (
                <TouchableOpacity
                  onPress={onPressCancel}
                  disabled={cancelling}
                  style={styles.cancelButton}
                  activeOpacity={0.8}
                >
                  {cancelling ? (
                    <ActivityIndicator size="small" color="#FFFFFF" />
                  ) : (
                    <>
                      <Ionicons name="close-circle-outline" size={18} color="#FFFFFF" />
                      <Text style={styles.cancelButtonText}>Cancel booking</Text>
                    </>
                  )}
                </TouchableOpacity>
              )}
            </GlassCard>
          </View>
        </Animated.View>
      )}

      {booking && (
        <>
          <SuccessOverlay
            visible={showCompletedConfetti}
            type="completed"
            message="Boom! Your super clean now"
            onComplete={() => {
              setShowCompletedConfetti(false);
              router.replace({
                pathname: '/owner/booking/completion',
                params: { bookingId, celebrated: '1' },
              } as any);
            }}
          />
          <Modal
              visible={infoModalVisible}
              transparent
              animationType="fade"
              onRequestClose={() => setInfoModalVisible(false)}
            >
              <Pressable style={styles.modalOverlay} onPress={() => setInfoModalVisible(false)}>
                <Pressable style={styles.infoModalContent} onPress={(e) => e.stopPropagation()}>
                  <View style={styles.infoModalHeader}>
                    <Text style={styles.infoModalTitle}>Booking Details</Text>
                    <TouchableOpacity
                      onPress={() => setInfoModalVisible(false)}
                      hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                    >
                      <Ionicons name="close" size={24} color="#94A3B8" />
                    </TouchableOpacity>
                  </View>
                  <View style={styles.infoModalBody}>
                    <View style={styles.infoRow}>
                      <Ionicons name="water-outline" size={18} color={SKY} />
                      <Text style={styles.infoText}>
                        {getServiceDisplayName(booking.service_type, booking.service_name)}
                      </Text>
                    </View>
                    {booking.valeter_id && (
                      <View style={styles.infoRow}>
                        <Ionicons name="person-outline" size={18} color={SKY} />
                        <Text style={styles.infoText}>{valeterName}</Text>
                      </View>
                    )}
                    <View style={styles.infoRow}>
                      <Ionicons name={washHub ? 'business-outline' : 'location-outline'} size={18} color={SKY} />
                      <Text style={styles.infoText}>{locationDisplay}</Text>
                    </View>
                    <View style={styles.infoRow}>
                      <Ionicons name="cash-outline" size={18} color={SKY} />
                      <Text style={styles.infoText}>£{Number(booking.price ?? 0).toFixed(2)}</Text>
                    </View>
                    <View style={styles.infoModalProgress}>
                      <Text style={styles.infoModalProgressLabel}>Progress</Text>
                      <AnimatedProgress progress={getStatusProgress()} size={80} />
                    </View>
                  </View>
                  {status === 'pending_payment' && (
                    <TouchableOpacity
                      onPress={() => {
                        setInfoModalVisible(false);
                        if (bookingId) {
                          router.push({ pathname: '/owner/booking/payment', params: { bookingId } } as any);
                        }
                      }}
                      style={styles.infoModalPayButton}
                      activeOpacity={0.9}
                    >
                      <LinearGradient
                        colors={[SKY, '#0EA5E9']}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 0 }}
                        style={styles.infoModalPayGradient}
                      >
                        <Ionicons name="wallet" size={20} color="#FFFFFF" />
                        <Text style={styles.infoModalPayText}>Pay £{Number(booking.price ?? 0).toFixed(2)}</Text>
                      </LinearGradient>
                    </TouchableOpacity>
                  )}
                  <TouchableOpacity
                    onPress={() => setInfoModalVisible(false)}
                    style={[styles.infoModalDone, status === 'pending_payment' && { marginTop: 8 }]}
                    activeOpacity={0.9}
                  >
                    <Text style={styles.infoModalDoneText}>Close</Text>
                  </TouchableOpacity>
                </Pressable>
              </Pressable>
            </Modal>
        </>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
  },
  headerExitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.15)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.3)',
  },
  loadingOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(10, 25, 41, 0.7)',
  },
  loadingText: {
    color: SKY,
    fontSize: 16,
    marginTop: 12,
    textAlign: 'center',
  },
  emptyOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    justifyContent: 'center',
    padding: 20,
  },
  emptyCard: {
    padding: 40,
    maxWidth: 400,
    alignSelf: 'center',
  },
  emptyContent: {
    alignItems: 'center',
  },
  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 8,
  },
  emptyText: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
    lineHeight: 20,
  },
  backButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    marginTop: 8,
  },
  backButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 28,
    gap: 8,
  },
  backButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  marker: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#EF4444',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  valeterMarker: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  hubMarker: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: '#10B981',
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  markerPulse: {
    position: 'absolute',
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: SKY,
    opacity: 0.3,
  },
  carMarkerImage: {
    width: 28,
    height: 28,
  },
  valeterMarkerImage: {
    width: 24,
    height: 24,
  },
  hubMarkerImage: {
    width: 24,
    height: 24,
  },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  cardWrapper: {
    width: '100%',
    maxWidth: CARD_WIDTH,
  },
  trackingCard: {
    padding: 20,
    overflow: 'hidden',
  },
  cardTopRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 16,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    flex: 1,
    minWidth: 0,
  },
  cardHeaderText: {
    flex: 1,
    minWidth: 0,
  },
  ringRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
    marginBottom: 12,
  },
  ringCenter: {
    flex: 1,
    alignItems: 'center',
    minWidth: 0,
  },
  stepper: {
    marginTop: 14,
    width: '100%',
    maxWidth: 220,
    alignSelf: 'center',
    paddingHorizontal: 4,
  },
  stepperTrack: {
    height: 3,
    backgroundColor: 'rgba(148,163,184,0.25)',
    borderRadius: 2,
    overflow: 'hidden',
    marginBottom: 10,
  },
  stepperFill: {
    height: '100%',
    backgroundColor: SKY,
    borderRadius: 2,
  },
  stepperSteps: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  stepperStep: {
    flex: 1,
    alignItems: 'center',
    minWidth: 0,
  },
  stepperDot: {
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: 'rgba(148,163,184,0.35)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 4,
  },
  stepperDotDone: {
    backgroundColor: '#10B981',
  },
  stepperDotCurrent: {
    backgroundColor: SKY,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.6)',
  },
  stepperLabel: {
    fontSize: 10,
    fontWeight: '600',
    color: '#64748B',
    textAlign: 'center',
  },
  stepperLabelDone: {
    color: '#10B981',
  },
  stepperLabelCurrent: {
    color: SKY,
    fontWeight: '800',
  },
  ringSideButton: {
    width: 44,
    height: 44,
  },
  ringSideButtonDisabled: {
    opacity: 0.5,
  },
  ringSideButtonInner: {
    width: '100%',
    height: '100%',
    borderRadius: 22,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  ringSideButtonInnerDisabled: {
    backgroundColor: 'rgba(100,116,139,0.2)',
    borderColor: 'rgba(100,116,139,0.3)',
  },
  payButton: {
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 8,
  },
  payButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 10,
  },
  payButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  arrivedButton: {
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 8,
  },
  arrivedButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 10,
  },
  arrivedButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  trackingIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  trackingIcon: {
    width: 24,
    height: 24,
  },
  trackingServiceName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 4,
  },
  trackingStatusMessage: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '500',
  },
  infoBox: {
    width: 44,
    height: 44,
  },
  infoBoxInner: {
    width: '100%',
    height: '100%',
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  infoModalContent: {
    width: '100%',
    maxWidth: 340,
    backgroundColor: '#1E293B',
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  infoModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  infoModalTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },
  infoModalBody: {
    gap: 12,
    marginBottom: 20,
  },
  infoModalProgress: {
    alignItems: 'center',
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  infoModalProgressLabel: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 8,
  },
  infoModalPayButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginBottom: 8,
  },
  infoModalPayGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 20,
    gap: 8,
  },
  infoModalPayText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  infoModalDone: {
    backgroundColor: SKY,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  infoModalDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoText: {
    color: '#E5E7EB',
    fontSize: 14,
    flex: 1,
  },
  cancelButton: {
    borderRadius: 12,
    backgroundColor: 'rgba(239,68,68,0.9)',
    borderWidth: 1.5,
    borderColor: 'rgba(239,68,68,0.5)',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 20,
    gap: 8,
    marginTop: 12,
  },
  cancelButtonText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: 'bold',
  },
});
