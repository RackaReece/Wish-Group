import React, { useEffect, useState, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  ActivityIndicator,
  Alert,
  Image,
  Animated,
  StatusBar,
  Dimensions,
  Modal,
  Pressable,
  ScrollView,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { supabase } from '../../../../src/lib/supabase';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { serviceOptions } from '../../../../src/constants/serviceOptions';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { colors } from '../../../../src/constants/colors';
import { Hub } from '../../../../src/types/booking';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
const SKY = colors.SKY;
const BG = colors.BG;
const { width } = Dimensions.get('window');
const CARD_WIDTH = width - 48;

export default function PhysicalConfirm() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();

  const params = useLocalSearchParams<{
    locationId?: string;
    serviceId?: string;
    vehicleId?: string;
    washType?: string;
    scheduledAt?: string;
    price?: string;
  }>();

  const { locationId, serviceId, vehicleId, washType, scheduledAt, price: priceParam } = params;

  const [hub, setHub] = useState<Hub | null>(null);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [infoModalVisible, setInfoModalVisible] = useState(false);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const { coords } = useLiveLocation();
  
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  const service = serviceOptions.find((opt) => opt.id === serviceId);
  const displayPrice = priceParam && !isNaN(Number(priceParam)) ? Number(priceParam) : (service?.price ?? 0);

  /* ------------------ Load location ------------------ */
  useEffect(() => {
    if (!locationId) return;

    const fetchHub = async () => {
      setLoading(true);

      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude')
        .eq('id', locationId)
        .maybeSingle();

      if (!error && data) {
        const hubData = data as Hub;
        setHub(hubData);
        
        // Update map region if hub has coordinates
        if (hubData.latitude && hubData.longitude) {
          setRegion({
            latitude: Number(hubData.latitude),
            longitude: Number(hubData.longitude),
            latitudeDelta: 0.01,
            longitudeDelta: 0.01,
          });
        }
      } else {
        setHub(null);
      }

      setLoading(false);
    };

    fetchHub();
    getCurrentLocation();
  }, [locationId]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    if (coords) {
      setUserLocation(coords);
    }
  }, [coords]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };
      setUserLocation(coords);
    } catch {}
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (hub?.latitude && hub?.longitude) {
      setRegion({
        latitude: Number(hub.latitude),
        longitude: Number(hub.longitude),
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    } else if (coords) {
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    }
  };

  /* ------------------ Confirm booking ------------------ */
  const handleConfirm = async () => {
    if (!user?.id || !service || !hub || !scheduledAt || !vehicleId) return;

    try {
      setSubmitting(true);
      await hapticFeedback('medium');

      // ✅ IMPORTANT:
      // Your DB does NOT have `customer_id`. Most schemas use `user_id` for the customer.
      // If yours is different (eg `owner_id`), change THIS ONE KEY.
      const BOOKING_CUSTOMER_COL = 'user_id';

      const insertPayload: any = {
        [BOOKING_CUSTOMER_COL]: user.id,
        vehicle_id: vehicleId,
        location_id: hub.id,
        service_type: service.id,
        service_name: service.name,
        price: displayPrice,
        wash_type: washType || null,
        status: 'pending_payment',
        scheduled_at: scheduledAt,
        location_address: hub.address,
        location_lat: hub.latitude,
        location_lng: hub.longitude,
        // created_at: new Date().toISOString(), // usually handled by DB default
      };

      const { data, error } = await supabase
        .from('bookings')
        .insert(insertPayload)
        .select('id')
        .single();

      if (error) throw error;

      router.replace({
        pathname: '/owner/booking/payment',
        params: { bookingId: data.id },
      });
    } catch (err: any) {
      console.error('[physical-confirm] booking error', err);
      Alert.alert('Error', err?.message || 'Unable to create booking');
    } finally {
      setSubmitting(false);
    }
  };

  /* ------------------ Guard ------------------ */
  if (!service || !scheduledAt || !locationId || !vehicleId) {
    return (
      <SafeAreaView style={[styles.container, styles.center]} edges={[]}>
        <Text style={{ color: '#fff' }}>Missing booking information.</Text>
      </SafeAreaView>
    );
  }

  const formattedDate = new Date(scheduledAt).toLocaleDateString('en-GB', {
    weekday: 'short',
    day: 'numeric',
    month: 'short',
  });
  const formattedTime = new Date(scheduledAt).toLocaleTimeString('en-GB', {
    hour: '2-digit',
    minute: '2-digit',
  });

  /* ------------------ UI ------------------ */
  // Custom map style to blur/hide labels for privacy
  const mapStyle = [
    {
      featureType: 'all',
      elementType: 'labels',
      stylers: [{ visibility: 'off' }],
    },
    {
      featureType: 'poi',
      elementType: 'labels',
      stylers: [{ visibility: 'off' }],
    },
    {
      featureType: 'road',
      elementType: 'labels',
      stylers: [{ visibility: 'off' }],
    },
    {
      featureType: 'transit',
      elementType: 'labels',
      stylers: [{ visibility: 'off' }],
    },
  ];

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <StatusBar hidden={true} />
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={mapStyle}
        >
          {/* User location marker */}
          {userLocation && (
            <Marker coordinate={userLocation}>
<View style={styles.userMarkerContainer}>
                <Image
                  source={require('../../../../assets/car.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {/* Hub location marker */}
          {hub?.latitude && hub?.longitude && (
            <Marker coordinate={{ latitude: Number(hub.latitude), longitude: Number(hub.longitude) }}>
              <View style={styles.hubMarkerContainer}>
                <Image 
                  source={require('../../../../assets/cleaning.png')} 
                  style={styles.hubMarkerImage}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Back button only */}
      <View style={[styles.headerContainer, { top: insets.top + 16 }]}>
        <TouchableOpacity 
          onPress={() => router.back()}
          style={styles.backButton}
          activeOpacity={0.7}
        >
          <Ionicons name="arrow-back" size={22} color={SKY} />
        </TouchableOpacity>
      </View>

      {/* Booking summary card - same size as prior cards */}
      <Animated.View
        style={[
          styles.summaryContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            bottom: 96 + Math.max(insets.bottom, 14),
          },
        ]}
      >
        {loading ? (
          <GlassCard style={styles.loadingCard} accountType="customer">
            <ActivityIndicator size="large" color={SKY} />
            <Text style={styles.loadingText}>Loading booking details...</Text>
          </GlassCard>
        ) : (
          <View style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
            <GlassCard style={styles.summaryCard} borderRadius={20} borderColor={SKY} intensity={35} accountType="customer">
              <View style={styles.cardContentRow}>
                <View style={styles.cardMain}>
                  <View style={styles.cardHeader}>
                    <View style={styles.summaryIconWrap}>
                      <Ionicons name="calendar-outline" size={28} color={SKY} />
                    </View>
                    <TouchableOpacity
                      onPress={() => {
                        hapticFeedback('light');
                        setInfoModalVisible(true);
                      }}
                      hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                      style={styles.infoIconBtn}
                    >
                      <Ionicons name="information-circle-outline" size={22} color={SKY} />
                    </TouchableOpacity>
                  </View>
                  <Text style={styles.summaryWash}>{service?.name || 'Service'}</Text>
                  <View style={styles.summaryMetaRow}>
                    <Ionicons name="calendar" size={12} color="#94A3B8" />
                    <Text style={styles.summaryMetaText}>{formattedDate}</Text>
                  </View>
                  <View style={styles.summaryMetaRow}>
                    <Ionicons name="time-outline" size={12} color="#94A3B8" />
                    <Text style={styles.summaryMetaText}>{formattedTime}</Text>
                  </View>
                  {hub?.address && (
                    <View style={styles.summaryMetaRow}>
                      <Ionicons name="location-outline" size={12} color="#94A3B8" />
                      <Text style={styles.summaryMetaText} numberOfLines={2}>{hub.address}</Text>
                    </View>
                  )}
                </View>
                <View style={styles.summaryInfoBox}>
                  <TouchableOpacity
                    onPress={() => {
                      hapticFeedback('light');
                      setInfoModalVisible(true);
                    }}
                    activeOpacity={0.9}
                    style={styles.summaryInfoTouch}
                  >
                    <Ionicons name="document-text-outline" size={32} color={SKY} />
                    <View style={styles.summaryInfoHint}>
                      <Ionicons name="information-circle" size={18} color="#fff" />
                    </View>
                  </TouchableOpacity>
                </View>
              </View>
            </GlassCard>
          </View>
        )}
      </Animated.View>

      {/* Info modal - full booking summary */}
      <Modal
        visible={infoModalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setInfoModalVisible(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setInfoModalVisible(false)}>
          <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Booking Summary</Text>
              <TouchableOpacity onPress={() => setInfoModalVisible(false)} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}>
                <Ionicons name="close" size={24} color="#94A3B8" />
              </TouchableOpacity>
            </View>
            <ScrollView style={styles.modalScroll} showsVerticalScrollIndicator={false}>
              <View style={styles.modalSection}>
                <Text style={styles.modalLabel}>Service</Text>
                <Text style={styles.modalValue}>
                  {service?.name || 'Service'}
                  {washType && washType !== 'both' ? ` (${washType.charAt(0).toUpperCase() + washType.slice(1)})` : ''}
                </Text>
                <Text style={styles.modalDesc}>{service?.desc || ''}</Text>
                <View style={styles.modalRow}>
                  <View style={styles.modalMeta}>
                    <Ionicons name="time-outline" size={14} color="#94A3B8" />
                    <Text style={styles.modalMetaText}>{service?.dur || ''}</Text>
                  </View>
                  <Text style={styles.modalPrice}>£{displayPrice}</Text>
                </View>
              </View>
              {hub && (
                <View style={styles.modalSection}>
                  <Text style={styles.modalLabel}>Location</Text>
                  <Text style={styles.modalValue}>{hub.name}</Text>
                  <Text style={styles.modalDesc}>{hub.address}</Text>
                </View>
              )}
              <View style={[styles.modalSection, { marginBottom: 0, paddingBottom: 0, borderBottomWidth: 0 }]}>
                <Text style={styles.modalLabel}>Time Slot</Text>
                <Text style={styles.modalValue}>{formattedDate} • {formattedTime}</Text>
                <Text style={styles.modalDesc}>Arrive 5 minutes early to keep your slot.</Text>
              </View>
            </ScrollView>
            <TouchableOpacity onPress={() => setInfoModalVisible(false)} style={styles.modalDone} activeOpacity={0.9}>
              <Text style={styles.modalDoneText}>Close</Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Payment CTA - same design as Continue on other screens */}
      <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12 }]}>
        <TouchableOpacity
          onPress={handleConfirm}
          disabled={submitting || loading || !hub}
          activeOpacity={0.9}
        >
          <LinearGradient
            colors={!loading && hub ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
            style={[styles.ctaButton, submitting && { opacity: 0.7 }]}
          >
            {submitting ? (
              <ActivityIndicator color="#FFFFFF" />
            ) : (
              <>
                <Text style={styles.ctaText}>Pay £{displayPrice}</Text>
                <Ionicons name="wallet" size={20} color="#FFFFFF" />
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

/* ------------------ Styles ------------------ */
const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center' },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  hubMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  hubMarkerImage: {
    width: 48,
    height: 48,
  },
  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  summaryContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 16,
  },
  cardWrapper: {
    width: CARD_WIDTH,
  },
  loadingCard: {
    padding: 20,
    alignItems: 'center',
    gap: 12,
  },
  loadingText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  summaryCard: {
    width: '100%',
    padding: 20,
    borderRadius: 20,
  },
  cardContentRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  cardMain: {
    flex: 1,
    minWidth: 0,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  summaryIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoIconBtn: { padding: 4 },
  summaryWash: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 8,
  },
  summaryMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 6,
  },
  summaryMetaText: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
    flex: 1,
  },
  summaryInfoBox: {
    width: 64,
    height: 64,
    marginLeft: 12,
  },
  summaryInfoTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  summaryInfoHint: {
    position: 'absolute',
    bottom: 4,
    right: 4,
    width: 22,
    height: 22,
    borderRadius: 11,
    backgroundColor: 'rgba(0,0,0,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  // Modal
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalContent: {
    width: '100%',
    maxWidth: 340,
    maxHeight: '80%',
    backgroundColor: '#1E293B',
    borderRadius: 20,
    padding: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
  },
  modalScroll: { maxHeight: 360, marginBottom: 16 },
  modalSection: {
    marginBottom: 20,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(135,206,235,0.18)',
  },
  modalLabel: {
    color: 'rgba(135,206,235,0.85)',
    fontSize: 11,
    letterSpacing: 1.2,
    textTransform: 'uppercase',
    marginBottom: 8,
    fontWeight: '800',
  },
  modalValue: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 6,
  },
  modalDesc: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 14,
    lineHeight: 20,
  },
  modalRow: {
    marginTop: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  modalMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  modalMetaText: {
    color: 'rgba(249,250,251,0.7)',
    fontSize: 13,
    fontWeight: '600',
  },
  modalPrice: {
    color: SKY,
    fontSize: 18,
    fontWeight: '800',
  },
  modalDone: {
    backgroundColor: SKY,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  modalDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
  },
  ctaButton: {
    borderRadius: 18,
    paddingVertical: 18,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
  headerContainer: {
    position: 'absolute',
    left: 16,
    zIndex: 1000,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
});
