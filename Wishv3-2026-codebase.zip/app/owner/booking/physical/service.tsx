import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Alert,
  Image,
  Modal,
  Pressable,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Location from 'expo-location';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { supabase } from '../../../../src/lib/supabase';
import { serviceOptions } from '../../../../src/constants/serviceOptions';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../components/NavigationTab';

const { width, height } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;
const CARD_WIDTH = width - 48;

// Uber-style dark map theme
const uberDarkMapStyle = [
  {
    elementType: 'geometry',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.fill',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'administrative.locality',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'geometry',
    stylers: [{ color: '#263c3f' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#6b9a76' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry',
    stylers: [{ color: '#38414e' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#212a37' }],
  },
  {
    featureType: 'road',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#9ca5b3' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#1f2835' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#f3d19c' }],
  },
  {
    featureType: 'transit',
    elementType: 'geometry',
    stylers: [{ color: '#2f3948' }],
  },
  {
    featureType: 'transit.station',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [{ color: '#17263c' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#515c6d' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#17263c' }],
  },
];

type TierId = 'bronze-wash' | 'silver-wash' | 'gold-wash' | 'platinum-wash';

const TIER_COLORS = {
  'bronze-wash': { main: '#CD7F32', light: 'rgba(205,127,50,0.25)', border: 'rgba(205,127,50,0.5)' },
  'silver-wash': { main: '#A8A8A8', light: 'rgba(168,168,168,0.2)', border: 'rgba(168,168,168,0.5)' },
  'gold-wash': { main: '#FFD700', light: 'rgba(255,215,0,0.2)', border: 'rgba(255,215,0,0.5)' },
  'platinum-wash': { main: '#E5E4E2', light: 'rgba(229,228,226,0.2)', border: 'rgba(229,228,226,0.5)' },
} as const;

type ServiceUI = {
  id: TierId;
  name: string;
  desc: string;
  dur: string;
  minutes: number;
  price: number;
  is_enabled: boolean;
  badge?: 'Quick & Affordable' | 'Best Value' | 'Most Popular' | 'Premium Detail';
  bulletPoints?: string[];
};

const TIERS: Array<{
  id: TierId;
  service_name: 'Bronze Wash' | 'Silver Wash' | 'Gold Wash' | 'Platinum Wash';
  defaultDesc: string;
  defaultMinutes: number;
  badge?: 'Quick & Affordable' | 'Best Value' | 'Most Popular' | 'Premium Detail';
}> = [
  {
    id: 'bronze-wash',
    service_name: 'Bronze Wash',
    defaultDesc:
      'Choose interior or exterior. Exterior includes pre-rinse, snow foam, hand wash, wheels cleaned and microfiber dry. Interior includes full vacuum, dashboard, centre console, door cards and interior windows cleaned.',
    defaultMinutes: 30,
    badge: 'Quick & Affordable',
  },
  {
    id: 'silver-wash',
    service_name: 'Silver Wash',
    defaultDesc:
      'Interior and exterior clean. Exterior wash with wheels, tyres and arches cleaned. Interior vacuum, dashboard, centre console, door cards, pedals and all windows cleaned.',
    defaultMinutes: 45,
    badge: 'Best Value',
  },
  {
    id: 'gold-wash',
    service_name: 'Gold Wash',
    defaultDesc:
      'Complete valet with added protection. Deep exterior clean with tyre dressing, door shuts and spray wax. Interior deep vacuum, seats and carpets shampooed, trims dressed and interior glass polished.',
    defaultMinutes: 60,
    badge: 'Most Popular',
  },
  {
    id: 'platinum-wash',
    service_name: 'Platinum Wash',
    defaultDesc:
      'Luxury detailing service. Includes machine polish, wax or ceramic sealant, trim restoration and full steam-cleaned interior with leather conditioning, odour neutralisation and interior protection.',
    defaultMinutes: 90,
    badge: 'Premium Detail',
  },
];

function money(n: any) {
  const v = typeof n === 'string' ? Number(n) : typeof n === 'number' ? n : 0;
  if (!Number.isFinite(v)) return 0;
  return v;
}

export default function PhysicalServiceSelection() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams();
  const locationId = params.locationId as string;
  const vehicleId = params.vehicleId as string;

  const [selectedService, setSelectedService] = useState<TierId | null>(null);
  const [washType, setWashType] = useState<'exterior' | 'interior' | 'both' | null>(null);
  const [infoModalService, setInfoModalService] = useState<ServiceUI | null>(null);
  const [washTypeModalVisible, setWashTypeModalVisible] = useState(false);
  const scrollViewRef = useRef<ScrollView>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  const [loading, setLoading] = useState(true);
  const [services, setServices] = useState<ServiceUI[]>([]);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [hubLocation, setHubLocation] = useState<{ latitude: number; longitude: number; name: string; address: string } | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    getCurrentLocation();
    if (!locationId) {
      setLoading(false);
      setLoadError('Missing location.');
      return;
    }
    loadHubLocation();
    loadTierPrices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locationId]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };
      setUserLocation(coords);
    } catch {}
  };

  const loadHubLocation = async () => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, latitude, longitude')
        .eq('id', locationId)
        .single();

      if (error) throw error;
      if (data && data.latitude && data.longitude) {
        const hub = {
          latitude: Number(data.latitude),
          longitude: Number(data.longitude),
          name: data.name || 'Wash Hub',
          address: data.address || '',
        };
        setHubLocation(hub);
        setRegion({
          latitude: hub.latitude,
          longitude: hub.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });
      }
    } catch (err) {
      console.error('Error loading hub location:', err);
    }
  };

  const loadTierPrices = async () => {
    try {
      setLoading(true);
      setLoadError(null);

      const { data, error } = await supabase
        .from('location_services')
        .select('service_name, price, duration_minutes, is_enabled')
        .eq('location_id', locationId);

      if (error) throw error;

      const rows = (data || []) as Array<{
        service_name: string | null;
        price: number | null;
        duration_minutes: number | null;
        is_enabled: boolean | null;
      }>;

      const map = new Map<string, { price: number; minutes: number; enabled: boolean }>();
      rows.forEach((r) => {
        const name = (r.service_name || '').trim();
        if (!name) return;
        map.set(name, {
          price: money(r.price),
          minutes: typeof r.duration_minutes === 'number' && r.duration_minutes > 0 ? r.duration_minutes : 0,
          enabled: r.is_enabled === null || r.is_enabled === undefined ? true : !!r.is_enabled,
        });
      });

      const built: ServiceUI[] = TIERS.map((t) => {
        const hit = map.get(t.service_name);
        const minutes = hit?.minutes ? hit.minutes : t.defaultMinutes;
        const durText = `${minutes} min`;
        const serviceOption = serviceOptions.find(so => so.id === t.id);
        
        return {
          id: t.id,
          name: t.service_name,
          desc: t.defaultDesc,
          minutes,
          dur: durText,
          price: hit?.price ?? 0,
          is_enabled: hit?.enabled ?? false,
          badge: t.badge,
          bulletPoints: serviceOption?.bulletPoints || [],
        };
      }).filter((s) => s.is_enabled);

      setServices(built);

      setSelectedService((prev) => {
        if (!prev) return prev;
        const stillThere = built.some((b) => b.id === prev);
        return stillThere ? prev : null;
      });
    } catch (e: any) {
      console.error('[PhysicalServiceSelection] loadTierPrices error:', e);
      setLoadError(e?.message || 'Failed to load pricing.');
      setServices([]);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceSelect = async (serviceId: TierId) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
    if (serviceId !== 'bronze-wash') {
      setWashType('both');
    } else {
      setWashType(null);
      setWashTypeModalVisible(true);
    }
  };

  const handleWashTypeSelect = async (type: 'exterior' | 'interior' | 'both') => {
    await hapticFeedback('light');
    setWashType(type);
    setWashTypeModalVisible(false);
  };

  const selectedServiceData = useMemo(
    () => services.find((s) => s.id === selectedService) || null,
    [services, selectedService]
  );

  // Calculate pricing tiers (small/medium/large)
  const getPriceTiers = (basePrice: number) => {
    return {
      small: basePrice,
      medium: Math.round(basePrice * 1.2 * 100) / 100,
      large: Math.round(basePrice * 1.4 * 100) / 100,
    };
  };

  const bronzeExteriorPrice = selectedServiceData?.price ?? 0;
  const bronzeInteriorPrice = selectedServiceData?.price ?? 0;

  const canContinue =
    !!selectedService &&
    !!locationId &&
    !!vehicleId &&
    (selectedService !== 'bronze-wash' || !!washType);

  const handleContinue = async () => {
    if (!canContinue) return;

    if (!selectedServiceData || !Number.isFinite(selectedServiceData.price) || selectedServiceData.price <= 0) {
      Alert.alert('Unavailable', 'This service does not have a price set yet. Please pick another option.');
      return;
    }

    await hapticFeedback('medium');

    let finalPrice = selectedServiceData.price;
    if (selectedService === 'bronze-wash') {
      if (washType === 'interior') finalPrice = bronzeInteriorPrice;
      else finalPrice = bronzeExteriorPrice; // Default to exterior if not specified
    }

    router.push({
      pathname: '/owner/booking/physical/schedule',
      params: {
        serviceId: selectedService,
        vehicleId,
        locationId,
        washType: washType || '',
        price: String(finalPrice),
      },
    });
  };

  const handleExitBooking = async () => {
    await hapticFeedback('light');
    router.replace('/owner/owner-dashboard' as any);
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (hubLocation) {
      setRegion({
        latitude: hubLocation.latitude,
        longitude: hubLocation.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    } else if (userLocation) {
      setRegion({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    }
  };


  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader 
          title="Select Service" 
          showBack={true}
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading prices...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (loadError) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader 
          title="Select Service" 
          showBack={true}
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <Ionicons name="alert-circle-outline" size={44} color={SKY} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>{loadError}</Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              loadTierPrices();
            }}
            style={styles.retryBtn}
            activeOpacity={0.85}
          >
            <LinearGradient colors={[SKY, '#60A5FA']} style={styles.retryGrad}>
              <Ionicons name="refresh" size={18} color="#fff" />
              <Text style={styles.retryText}>Retry</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (!services.length) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader 
          title="Select Service" 
          showBack={true}
          onBack={() => router.back()}
        />
        <View style={styles.loadingWrap}>
          <Ionicons name="pricetag-outline" size={44} color={SKY} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This location hasn't enabled any services yet.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={uberDarkMapStyle}
        >
          {/* User location marker */}
          {userLocation && (
            <Marker coordinate={userLocation}>
<View style={styles.userMarkerContainer}>
                <Image
                  source={require('../../../../assets/car.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {/* Hub location marker */}
          {hubLocation && (
            <Marker coordinate={{ latitude: hubLocation.latitude, longitude: hubLocation.longitude }}>
              <View style={styles.hubMarkerContainer}>
                <Image 
                  source={require('../../../../assets/cleaning.png')} 
                  style={styles.hubMarkerImage}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Header floating over the map */}
      <AppHeader 
        title="Select Service" 
        subtitle={hubLocation?.name || 'Choose your wash service'}
        showBack={true}
        onBack={() => router.back()}
        rightAction={
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            <TouchableOpacity 
              onPress={handleRecenter} 
              style={styles.recenterButton}
              activeOpacity={0.7}
            >
              <Ionicons name="locate" size={22} color={SKY} />
            </TouchableOpacity>
            <TouchableOpacity 
              onPress={handleExitBooking} 
              style={styles.exitButton}
              activeOpacity={0.7}
            >
              <Ionicons name="close" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        }
      />

      {/* Service cards - floating at bottom */}
      <Animated.View
        style={[
          styles.cardContainer,
          {
            opacity: fadeAnim,
            bottom: 96 + Math.max(insets.bottom, 14),
          },
        ]}
      >
        <ScrollView
          ref={scrollViewRef}
          horizontal
          showsHorizontalScrollIndicator={false}
          snapToInterval={CARD_WIDTH + 12}
          decelerationRate="fast"
          contentContainerStyle={styles.cardsScrollContent}
          onMomentumScrollEnd={(e) => {
            const index = Math.round(e.nativeEvent.contentOffset.x / (CARD_WIDTH + 12));
            if (services[index]) {
              handleServiceSelect(services[index].id);
            }
          }}
        >
          {services.map((service) => {
            const isSelected = selectedService === service.id;
            const tierColor = TIER_COLORS[service.id];
            const getServiceIcon = () => {
              if (service.id === 'bronze-wash') return 'car-wash';
              if (service.id === 'silver-wash') return 'spray';
              if (service.id === 'gold-wash') return 'diamond';
              if (service.id === 'platinum-wash') return 'diamond-stone';
              return 'car-wash';
            };
            const getBadgeIcon = () => {
              if (service.badge === 'Quick & Affordable') return 'flash';
              if (service.badge === 'Best Value') return 'trending-up';
              if (service.badge === 'Most Popular') return 'star';
              if (service.badge === 'Premium Detail') return 'ribbon';
              return 'checkmark';
            };

            return (
              <View key={service.id} style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
                <GlassCard
                  onPress={() => handleServiceSelect(service.id)}
                  style={[
                    styles.serviceCard,
                    isSelected && styles.serviceCardSelected,
                    isSelected && {
                      borderColor: tierColor.main,
                      borderWidth: 2,
                      shadowColor: tierColor.main,
                      shadowOpacity: 0.35,
                    },
                  ]}
                  borderColor={isSelected ? tierColor.main : undefined}
                  borderRadius={20}
                  intensity={35}
                >
                  {/* Badge ribbon at top */}
                  {service.badge ? (
                    <View style={[styles.badgeRibbon, { backgroundColor: tierColor.main }]}>
                      <Ionicons name={getBadgeIcon() as any} size={12} color="#0F172A" />
                      <Text style={styles.badgeRibbonText}>{service.badge}</Text>
                    </View>
                  ) : null}
                  <View style={styles.cardInner}>
                    <View style={styles.cardContentRow}>
                      <View style={styles.cardMain}>
                        <View style={styles.cardHeader}>
                          <View style={[styles.serviceIconWrap, { backgroundColor: tierColor.light, borderColor: tierColor.border }]}>
                            <MaterialCommunityIcons name={getServiceIcon() as any} size={28} color={tierColor.main} />
                          </View>
                          {isSelected && (
                            <View style={[styles.selectedCheck, { backgroundColor: tierColor.main }]}>
                              <Ionicons name="checkmark" size={14} color="#0F172A" />
                            </View>
                          )}
                        </View>
                        <Text style={styles.serviceName} numberOfLines={1}>{service.name}</Text>
                        <View style={styles.statsRow}>
                          <View style={styles.statPill}>
                            <Ionicons name="time-outline" size={13} color="#94A3B8" />
                            <Text style={styles.statText}>{service.dur}</Text>
                          </View>
                          <Text style={[styles.servicePrice, { color: tierColor.main }]}>£{service.price.toFixed(0)}</Text>
                        </View>
                        {isSelected && selectedService === 'bronze-wash' && washType && (
                          <TouchableOpacity
                            onPress={() => setWashTypeModalVisible(true)}
                            style={[styles.washTypeChip, { backgroundColor: tierColor.light, borderColor: tierColor.border }]}
                            activeOpacity={0.8}
                          >
                            <Ionicons
                              name={washType === 'exterior' ? 'car-sport-outline' : 'home-outline'}
                              size={18}
                              color={tierColor.main}
                            />
                            <Text style={[styles.washTypeChipText, { color: tierColor.main }]}>
                              {washType === 'exterior' ? 'Exterior' : 'Interior'}
                            </Text>
                            <Ionicons name="chevron-forward" size={16} color={tierColor.main} />
                          </TouchableOpacity>
                        )}
                      </View>
                      <View style={styles.tierBadgeBox}>
                        <TouchableOpacity
                          onPress={(e) => {
                            e.stopPropagation();
                            hapticFeedback('light');
                            setInfoModalService(service);
                          }}
                          activeOpacity={0.9}
                          style={[styles.tierBadgeTouch, { backgroundColor: tierColor.light, borderColor: tierColor.border }]}
                        >
                          <Ionicons name="information-circle" size={32} color={tierColor.main} />
                        </TouchableOpacity>
                      </View>
                    </View>
                  </View>
                </GlassCard>
              </View>
            );
          })}
        </ScrollView>

        {/* Info popup overlay */}
        <Modal
          visible={!!infoModalService}
          transparent
          animationType="fade"
          onRequestClose={() => setInfoModalService(null)}
        >
          <Pressable
            style={styles.modalOverlay}
            onPress={() => setInfoModalService(null)}
          >
            <Pressable
              style={[
                styles.modalContent,
                infoModalService && { borderColor: TIER_COLORS[infoModalService.id].border },
              ]}
              onPress={(e) => e.stopPropagation()}
            >
              {infoModalService && (() => {
                const tc = TIER_COLORS[infoModalService.id];
                return (
                  <>
                    <View style={[styles.modalHeader, { borderBottomColor: tc.light }]}>
                      <View style={styles.modalHeaderLeft}>
                        <Text style={styles.modalTitle}>{infoModalService.name}</Text>
                        {infoModalService.badge && (
                          <View style={[styles.modalBadge, { backgroundColor: tc.light, borderColor: tc.border }]}>
                            <Text style={[styles.modalBadgeText, { color: tc.main }]}>{infoModalService.badge}</Text>
                          </View>
                        )}
                      </View>
                      <TouchableOpacity
                        onPress={() => setInfoModalService(null)}
                        hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                      >
                        <Ionicons name="close" size={24} color="#94A3B8" />
                      </TouchableOpacity>
                    </View>
                    <ScrollView style={styles.modalScroll} showsVerticalScrollIndicator={false}>
                      <View style={styles.modalPriceRow}>
                        <Text style={[styles.modalPrice, { color: tc.main }]}>£{infoModalService.price.toFixed(0)}</Text>
                        <View style={styles.modalDuration}>
                          <Ionicons name="time-outline" size={14} color="#94A3B8" />
                          <Text style={styles.modalDurationText}>{infoModalService.dur}</Text>
                        </View>
                      </View>
                      <Text style={styles.modalDesc}>{infoModalService.desc}</Text>
                      {infoModalService.bulletPoints && infoModalService.bulletPoints.length > 0 && (
                        <View style={styles.modalFeatures}>
                          <Text style={styles.modalSectionTitle}>Includes</Text>
                          {infoModalService.bulletPoints.map((f, idx) => (
                            <View key={idx} style={styles.modalFeatureRow}>
                              <Ionicons name="checkmark-circle" size={16} color={tc.main} />
                              <Text style={styles.modalFeatureText}>{f}</Text>
                            </View>
                          ))}
                        </View>
                      )}
                      <View style={[styles.modalPricing, { borderTopColor: tc.light }]}>
                        <Text style={styles.modalSectionTitle}>Vehicle size pricing</Text>
                        <View style={styles.modalPriceTiers}>
                          <View style={styles.modalTierItem}>
                            <Text style={styles.modalTierLabel}>Small</Text>
                            <Text style={[styles.modalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).small.toFixed(0)}</Text>
                          </View>
                          <View style={styles.modalTierItem}>
                            <Text style={styles.modalTierLabel}>Medium</Text>
                            <Text style={[styles.modalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).medium.toFixed(0)}</Text>
                          </View>
                          <View style={styles.modalTierItem}>
                            <Text style={styles.modalTierLabel}>Large</Text>
                            <Text style={[styles.modalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).large.toFixed(0)}</Text>
                          </View>
                        </View>
                      </View>
                    </ScrollView>
                    <TouchableOpacity
                      onPress={() => setInfoModalService(null)}
                      style={[styles.modalDone, { backgroundColor: tc.main }]}
                      activeOpacity={0.9}
                    >
                      <Text style={styles.modalDoneText}>Close</Text>
                    </TouchableOpacity>
                  </>
                );
              })()}
            </Pressable>
          </Pressable>
        </Modal>

        {/* Bronze wash type selection overlay */}
        <Modal
          visible={washTypeModalVisible}
          transparent
          animationType="fade"
          onRequestClose={() => setWashTypeModalVisible(false)}
        >
          <Pressable
            style={styles.modalOverlay}
            onPress={() => setWashTypeModalVisible(false)}
          >
            <Pressable style={styles.washTypeModalContent} onPress={(e) => e.stopPropagation()}>
              <View style={styles.washTypeModalHeader}>
                <View style={styles.washTypeModalHeaderTop}>
                  <View style={[styles.washTypeModalBadge, { backgroundColor: TIER_COLORS['bronze-wash'].main }]}>
                    <MaterialCommunityIcons name="car-wash" size={18} color="#0F172A" />
                    <Text style={styles.washTypeModalBadgeText}>Bronze Wash</Text>
                  </View>
                  <TouchableOpacity
                    onPress={() => setWashTypeModalVisible(false)}
                    style={styles.washTypeModalClose}
                    hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                  >
                    <Ionicons name="close" size={22} color="#94A3B8" />
                  </TouchableOpacity>
                </View>
                <Text style={styles.washTypeModalTitle}>Choose your wash type</Text>
                <Text style={styles.washTypeModalSubtitle}>Select exterior or interior — both include our quick & affordable bronze treatment</Text>
              </View>
              <View style={styles.washTypeModalOptions}>
                <TouchableOpacity
                  onPress={() => handleWashTypeSelect('exterior')}
                  style={[styles.washTypeModalOption, { borderColor: TIER_COLORS['bronze-wash'].border }]}
                  activeOpacity={0.85}
                >
                  <View style={[styles.washTypeModalOptionIcon, { backgroundColor: TIER_COLORS['bronze-wash'].light }]}>
                    <Ionicons name="car-sport-outline" size={32} color={TIER_COLORS['bronze-wash'].main} />
                  </View>
                  <View style={styles.washTypeModalOptionBody}>
                    <Text style={styles.washTypeModalOptionLabel}>Exterior</Text>
                    <Text style={styles.washTypeModalOptionDesc}>Pre-rinse, snow foam, hand wash, wheels & microfiber dry</Text>
                  </View>
                  <Text style={[styles.washTypeModalOptionPrice, { color: TIER_COLORS['bronze-wash'].main }]}>
                    £{(bronzeExteriorPrice || 0).toFixed(0)}
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => handleWashTypeSelect('interior')}
                  style={[styles.washTypeModalOption, { borderColor: TIER_COLORS['bronze-wash'].border }]}
                  activeOpacity={0.85}
                >
                  <View style={[styles.washTypeModalOptionIcon, { backgroundColor: TIER_COLORS['bronze-wash'].light }]}>
                    <Ionicons name="layers-outline" size={32} color={TIER_COLORS['bronze-wash'].main} />
                  </View>
                  <View style={styles.washTypeModalOptionBody}>
                    <Text style={styles.washTypeModalOptionLabel}>Interior</Text>
                    <Text style={styles.washTypeModalOptionDesc}>Full vacuum, dashboard, centre console, door cards & windows</Text>
                  </View>
                  <Text style={[styles.washTypeModalOptionPrice, { color: TIER_COLORS['bronze-wash'].main }]}>
                    £{(bronzeInteriorPrice || 0).toFixed(0)}
                  </Text>
                </TouchableOpacity>
              </View>
            </Pressable>
          </Pressable>
        </Modal>
      </Animated.View>

      {/* Continue Button - separate from cards */}
      <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12 }]}>
        <TouchableOpacity
          onPress={handleContinue}
          disabled={!canContinue}
          activeOpacity={0.9}
        >
          <LinearGradient
            colors={canContinue ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
            style={styles.ctaButton}
          >
            <Text style={styles.ctaText}>
              {canContinue
                ? (selectedService === 'bronze-wash' && !washType
                  ? 'Select wash type'
                  : `Choose ${selectedServiceData?.name || 'service'}`)
                : 'Select a service'}
            </Text>
            <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
    backgroundColor: 'transparent',
    zIndex: 100,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  hubMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  hubMarkerImage: {
    width: 48,
    height: 48,
  },
  content: { flex: 1 },
  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: 24 },
  loadingText: { color: SKY, fontSize: 14 },
  retryBtn: { marginTop: 10, borderRadius: 16, overflow: 'hidden' },
  retryGrad: { flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', paddingVertical: 12, paddingHorizontal: 18 },
  retryText: { color: '#fff', fontWeight: '800' },

  cardWrapper: {
    marginRight: 12,
  },
  serviceCard: {
    padding: 0,
    borderRadius: 20,
    overflow: 'hidden',
    elevation: 6,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 12,
  },
  serviceCardSelected: {
    elevation: 8,
    shadowRadius: 16,
  },
  badgeRibbon: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 6,
    paddingHorizontal: 12,
  },
  badgeRibbonText: {
    color: '#0F172A',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  cardInner: {
    padding: 18,
    paddingTop: 14,
  },
  cardContentRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  cardMain: {
    flex: 1,
    minWidth: 0,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  serviceIconWrap: {
    width: 56,
    height: 56,
    borderRadius: 18,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: 'rgba(0,0,0,0.3)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
    elevation: 6,
  },
  selectedCheck: {
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 8,
    letterSpacing: -0.2,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  statPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(148,163,184,0.15)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  statText: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  servicePrice: {
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  tierBadgeBox: {
    width: 72,
    height: 72,
    marginLeft: 14,
  },
  tierBadgeTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 16,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },

  washTypeChip: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    gap: 8,
  },
  washTypeChipText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    flex: 1,
  },
  washTypeModalContent: {
    width: '100%',
    maxWidth: 360,
    marginHorizontal: 24,
    backgroundColor: '#1E293B',
    borderRadius: 24,
    borderWidth: 1,
    borderColor: 'rgba(205,127,50,0.4)',
    overflow: 'hidden',
  },
  washTypeModalHeader: {
    padding: 24,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(205,127,50,0.2)',
  },
  washTypeModalHeaderTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  washTypeModalBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  washTypeModalBadgeText: {
    color: '#0F172A',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  washTypeModalClose: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(148,163,184,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  washTypeModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 6,
  },
  washTypeModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 20,
  },
  washTypeModalOptions: {
    padding: 20,
    gap: 12,
  },
  washTypeModalOption: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1.5,
    backgroundColor: 'rgba(205,127,50,0.06)',
  },
  washTypeModalOptionIcon: {
    width: 56,
    height: 56,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  washTypeModalOptionBody: {
    flex: 1,
    minWidth: 0,
  },
  washTypeModalOptionLabel: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 4,
  },
  washTypeModalOptionDesc: {
    color: '#94A3B8',
    fontSize: 13,
    lineHeight: 18,
  },
  washTypeModalOptionPrice: {
    fontSize: 18,
    fontWeight: '800',
    marginLeft: 12,
  },
  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
  },
  ctaButton: {
    borderRadius: 18,
    paddingVertical: 18,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
  // Info modal
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalContent: {
    width: '100%',
    maxWidth: 340,
    maxHeight: '80%',
    backgroundColor: '#1E293B',
    borderRadius: 20,
    padding: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
    paddingBottom: 16,
    borderBottomWidth: 1,
  },
  modalHeaderLeft: {
    flex: 1,
  },
  modalBadge: {
    alignSelf: 'flex-start',
    marginTop: 6,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
  },
  modalBadgeText: {
    fontSize: 11,
    fontWeight: '700',
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
  },
  modalScroll: {
    maxHeight: 360,
    marginBottom: 16,
  },
  modalPriceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  modalPrice: {
    color: SKY,
    fontSize: 24,
    fontWeight: '800',
  },
  modalDuration: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  modalDurationText: {
    color: '#94A3B8',
    fontSize: 14,
  },
  modalDesc: {
    color: 'rgba(229,231,235,0.9)',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 16,
  },
  modalSectionTitle: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 10,
  },
  modalFeatures: {
    marginBottom: 16,
  },
  modalFeatureRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
    marginBottom: 8,
  },
  modalFeatureText: {
    color: 'rgba(229,231,235,0.9)',
    fontSize: 13,
    flex: 1,
  },
  modalPricing: {
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  modalPriceTiers: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    marginTop: 8,
  },
  modalTierItem: {
    alignItems: 'center',
  },
  modalTierLabel: {
    color: '#94A3B8',
    fontSize: 11,
    marginBottom: 4,
  },
  modalTierValue: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '700',
  },
  modalDone: {
    backgroundColor: SKY,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  modalDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },

  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
});
