import React, { useEffect, useState, useRef, useMemo, useCallback } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Image,
  ScrollView,
  Modal,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import Slider from '@react-native-community/slider';

import { supabase } from '../../../../src/lib/supabase';
import useLiveLocation from '../../../../src/hooks/useLiveLocation';
import AppHeader from '../../../../src/components/shared/AppHeader';
import GlassCard from '../../../../src/components/booking/GlassCard';
import { customerTheme } from '../../../../src/constants/customerTheme';
import { colors } from '../../../../src/constants/colors';
import { Hub } from '../../../../src/types/booking';
import { TAB_BAR_TOTAL_HEIGHT } from '../../../components/NavigationTab';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const CARD_WIDTH = width - 48;

type LatLng = { latitude: number; longitude: number };

type HubRow = Hub & {
  eco_washing?: boolean | null;
  detailing_offered?: boolean | null;
  created_at?: string | null;
  rating?: number | null;
};

const safeBool = (v: any) => v === true;

export default function PhysicalLocationSelect() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams<{ vehicleId?: string }>();
  const { coords } = useLiveLocation();
  const vehicleId = params.vehicleId;

  const [loading, setLoading] = useState(true);
  const [hubs, setHubs] = useState<HubRow[]>([]);
  const [selectedHub, setSelectedHub] = useState<HubRow | null>(null);
  const [radiusMiles, setRadiusMiles] = useState(10);
  const [radiusModalVisible, setRadiusModalVisible] = useState(false);
  const [infoModalHub, setInfoModalHub] = useState<HubRow | null>(null);
  const [hubStats, setHubStats] = useState<{ completed: number; active: number } | null>(null);

  const [region, setRegion] = useState<Region>({
    latitude: coords?.latitude || 51.5074,
    longitude: coords?.longitude || -0.1278,
    latitudeDelta: 0.05,
    longitudeDelta: 0.05,
  });

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 50, friction: 8, useNativeDriver: true }),
    ]).start();

    loadHubs();
  }, []);

  const normalizeHubs = (rows: any[]): HubRow[] =>
    (rows || [])
      .map((h) => ({
        ...h,
        latitude: Number(h.latitude),
        longitude: Number(h.longitude),
        eco_washing: safeBool(h.eco_washing),
        detailing_offered: safeBool(h.detailing_offered),
      }))
      .filter((h) => Number.isFinite(h.latitude) && Number.isFinite(h.longitude));

  const loadHubs = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id,name,address,latitude,longitude,status,eco_washing,detailing_offered,created_at,rating');

      if (error) throw error;
      setHubs(normalizeHubs(data || []));
    } catch (err: any) {
      Alert.alert('Hubs Error', err?.message || 'Failed to load hubs');
      setHubs([]);
    } finally {
      setLoading(false);
    }
  };

  const calculateDistance = useCallback(
    (hub: HubRow) => {
      if (!coords || !hub.latitude || !hub.longitude) return null;
      const toRad = (v: number) => (v * Math.PI) / 180;
      const R = 3959;
      const dLat = toRad(hub.latitude - coords.latitude);
      const dLon = toRad(hub.longitude - coords.longitude);
      const a =
        Math.sin(dLat / 2) ** 2 +
        Math.cos(toRad(coords.latitude)) *
          Math.cos(toRad(hub.latitude)) *
          Math.sin(dLon / 2) ** 2;
      return (R * (2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a)))).toFixed(1);
    },
    [coords]
  );

  const filteredHubs = useMemo(() => {
    if (!coords) return hubs;
    return hubs
      .map((hub) => ({ hub, distance: calculateDistance(hub) }))
      .filter(({ distance }) => distance && Number(distance) <= radiusMiles)
      .sort((a, b) => Number(a.distance) - Number(b.distance))
      .map(({ hub }) => hub);
  }, [hubs, coords, radiusMiles, calculateDistance]);

  const handleHubSelect = (hub: HubRow) => {
    setSelectedHub(hub);
    setRegion({
      latitude: hub.latitude,
      longitude: hub.longitude,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    });
  };

  const handleContinue = async () => {
    if (!selectedHub || !vehicleId) return;
    await hapticFeedback('medium');
    router.push({
      pathname: '/owner/booking/physical/service',
      params: { locationId: selectedHub.id, vehicleId },
    });
  };

  const openRadiusModal = async () => {
    await hapticFeedback('light');
    setRadiusModalVisible(true);
  };

  const openHubInfo = async (hub: HubRow) => {
    hapticFeedback('light');
    setInfoModalHub(hub);
    setHubStats(null);
    try {
      const [completedRes, activeRes] = await Promise.all([
        supabase.from('bookings').select('id', { count: 'exact', head: true }).eq('location_id', hub.id).eq('status', 'completed'),
        supabase.from('bookings').select('id', { count: 'exact', head: true }).eq('location_id', hub.id).in('status', ['scheduled', 'in_progress', 'valeter_assigned', 'en_route', 'arrived']),
      ]);
      setHubStats({
        completed: (completedRes as { count?: number })?.count ?? 0,
        active: (activeRes as { count?: number })?.count ?? 0,
      });
    } catch {
      setHubStats({ completed: 0, active: 0 });
    }
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <MapView style={StyleSheet.absoluteFill} region={region} showsUserLocation>
        {hubs.map((hub) => {
          const distance = calculateDistance(hub);
          const outOfRange = distance && Number(distance) > radiusMiles;
          return (
            <Marker
              key={hub.id}
              coordinate={{ latitude: hub.latitude, longitude: hub.longitude }}
              onPress={() => handleHubSelect(hub)}
            >
              <Image
                source={require('../../../../assets/cleaning.png')}
                style={[styles.marker, outOfRange && { opacity: 0.4 }]}
              />
            </Marker>
          );
        })}
      </MapView>

      <AppHeader
        title="Nearby Wash Hubs"
        subtitle="Select a wash hub"
        showBack
        onBack={() => router.back()}
        rightAction={
          <TouchableOpacity onPress={openRadiusModal} style={styles.radiusButton} activeOpacity={0.8}>
            <Ionicons name="radio-button-on" size={18} color={SKY} />
            <Text style={styles.radiusButtonText}>{radiusMiles} mi</Text>
          </TouchableOpacity>
        }
      />

      <Animated.View
        style={[
          styles.cardsContainer,
          { opacity: fadeAnim, transform: [{ translateY: slideAnim }], bottom: 96 + Math.max(insets.bottom, 14) },
        ]}
      >
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.cardsScrollContent}
          snapToInterval={CARD_WIDTH + 12}
          decelerationRate="fast"
        >
          {filteredHubs.map((hub) => {
            const isSelected = selectedHub?.id === hub.id;
            const distance = calculateDistance(hub);
            return (
              <View key={hub.id} style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
                <GlassCard
                  onPress={() => handleHubSelect(hub)}
                  style={[styles.hubCard, isSelected && styles.hubCardSelected]}
                  borderColor={isSelected ? SKY : undefined}
                  borderRadius={20}
                  intensity={35}
                >
                  <View style={styles.cardContentRow}>
                    <View style={styles.cardMain}>
                      <View style={styles.cardHeader}>
                        <View style={styles.hubIconWrap}>
                          <Image
                            source={require('../../../../assets/cleaning.png')}
                            style={styles.hubIcon}
                            resizeMode="contain"
                          />
                        </View>
                        {isSelected && (
                          <Ionicons name="checkmark-circle" size={22} color={SKY} />
                        )}
                      </View>
                      <Text style={styles.hubName} numberOfLines={2}>{hub.name}</Text>
                      <Text style={styles.hubAddress} numberOfLines={2}>{hub.address}</Text>
                      {distance != null && (
                        <View style={styles.distanceRow}>
                          <Ionicons name="navigate" size={12} color={SKY} />
                          <Text style={styles.distanceText}>{distance} miles</Text>
                        </View>
                      )}
                    </View>
                    <View style={styles.hubProfileBox}>
                      <TouchableOpacity
                        onPress={(e) => {
                          e.stopPropagation();
                          openHubInfo(hub);
                        }}
                        activeOpacity={0.9}
                        style={styles.hubProfileTouch}
                      >
                        <Image
                          source={require('../../../../assets/cleaning.png')}
                          style={styles.hubProfilePlaceholder}
                          resizeMode="contain"
                        />
                        <View style={styles.hubProfileInfoIcon}>
                          <Ionicons name="information-circle" size={20} color="#fff" />
                        </View>
                      </TouchableOpacity>
                    </View>
                  </View>
                </GlassCard>
              </View>
            );
          })}
        </ScrollView>
      </Animated.View>

      {/* Continue Button - separate from cards */}
      <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12 }]}>
        <TouchableOpacity
          onPress={handleContinue}
          disabled={!selectedHub}
          activeOpacity={0.9}
        >
          <LinearGradient
            colors={selectedHub ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
            style={styles.ctaButton}
          >
            <Text style={styles.ctaText}>
              {selectedHub ? 'Continue' : 'Select a wash hub'}
            </Text>
            <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      </View>

      {/* Hub info popup */}
      <Modal
        visible={!!infoModalHub}
        transparent
        animationType="fade"
        onRequestClose={() => setInfoModalHub(null)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setInfoModalHub(null)}>
          <Pressable style={styles.hubInfoModalContent} onPress={(e) => e.stopPropagation()}>
            {infoModalHub && (
              <ScrollView showsVerticalScrollIndicator={false}>
                <View style={styles.hubInfoCoverWrap}>
                  <View style={styles.hubInfoCoverPlaceholder}>
                    <Image source={require('../../../../assets/cleaning.png')} style={styles.hubInfoCoverImg} resizeMode="contain" />
                  </View>
                  <View style={styles.hubInfoCoverOverlay} />
                  <TouchableOpacity
                    onPress={() => setInfoModalHub(null)}
                    style={styles.hubInfoClose}
                    hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                  >
                    <Ionicons name="close-circle" size={32} color="#fff" />
                  </TouchableOpacity>
                </View>
                <View style={styles.hubInfoBody}>
                  <Text style={styles.hubInfoTitle}>{infoModalHub.name}</Text>
                  <Text style={styles.hubInfoAddress}>{infoModalHub.address}</Text>
                  {infoModalHub.rating != null && (
                    <View style={styles.hubInfoRating}>
                      <Ionicons name="star" size={16} color="#FCD34D" />
                      <Text style={styles.hubInfoRatingText}>{infoModalHub.rating.toFixed(1)}</Text>
                    </View>
                  )}
                  <View style={styles.hubInfoStats}>
                    {infoModalHub.created_at && (
                      <View style={styles.hubInfoStat}>
                        <Ionicons name="calendar-outline" size={16} color={SKY} />
                        <Text style={styles.hubInfoStatText}>
                          Joined {new Date(infoModalHub.created_at).toLocaleDateString('en-GB', { month: 'short', year: 'numeric' })}
                        </Text>
                      </View>
                    )}
                    {hubStats && (
                      <>
                        <View style={styles.hubInfoStat}>
                          <Ionicons name="checkmark-done" size={16} color="#10B981" />
                          <Text style={styles.hubInfoStatText}>{hubStats.completed} washes completed</Text>
                        </View>
                        <View style={styles.hubInfoStat}>
                          <Ionicons name="time" size={16} color={SKY} />
                          <Text style={styles.hubInfoStatText}>{hubStats.active} active bookings</Text>
                        </View>
                      </>
                    )}
                  </View>
                  {(infoModalHub.eco_washing || infoModalHub.detailing_offered) && (
                    <View style={styles.hubInfoTags}>
                      {infoModalHub.eco_washing && (
                        <View style={styles.hubInfoTag}>
                          <Ionicons name="leaf" size={12} color="#10B981" />
                          <Text style={styles.hubInfoTagText}>Eco</Text>
                        </View>
                      )}
                      {infoModalHub.detailing_offered && (
                        <View style={styles.hubInfoTag}>
                          <Ionicons name="sparkles" size={12} color={SKY} />
                          <Text style={styles.hubInfoTagText}>Detailing</Text>
                        </View>
                      )}
                    </View>
                  )}
                </View>
                <TouchableOpacity onPress={() => setInfoModalHub(null)} style={styles.hubInfoDone} activeOpacity={0.9}>
                  <Text style={styles.hubInfoDoneText}>Close</Text>
                </TouchableOpacity>
              </ScrollView>
            )}
          </Pressable>
        </Pressable>
      </Modal>

      {/* Radius popup overlay */}
      <Modal
        visible={radiusModalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setRadiusModalVisible(false)}
      >
        <Pressable
          style={styles.modalOverlay}
          onPress={() => setRadiusModalVisible(false)}
        >
          <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
            <View style={styles.modalHeader}>
              <Text style={styles.modalTitle}>Search Radius</Text>
              <TouchableOpacity
                onPress={() => setRadiusModalVisible(false)}
                hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
              >
                <Ionicons name="close" size={24} color="#94A3B8" />
              </TouchableOpacity>
            </View>
            <Text style={styles.modalValue}>{radiusMiles} miles</Text>
            <Slider
              minimumValue={5}
              maximumValue={30}
              step={1}
              value={radiusMiles}
              onValueChange={setRadiusMiles}
              minimumTrackTintColor={SKY}
              maximumTrackTintColor="#334155"
              thumbTintColor={SKY}
              style={styles.slider}
            />
            <TouchableOpacity
              onPress={() => {
                setRadiusModalVisible(false);
                hapticFeedback('light');
              }}
              style={styles.modalDone}
              activeOpacity={0.9}
            >
              <Text style={styles.modalDoneText}>Done</Text>
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  marker: { width: 40, height: 40 },
  radiusButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 20,
    backgroundColor: 'rgba(91, 143, 168, 0.2)',
    borderWidth: 1,
    borderColor: 'rgba(91, 143, 168, 0.4)',
  },
  radiusButtonText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 16,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  cardWrapper: {
    width: CARD_WIDTH,
    marginRight: 12,
  },
  hubCard: {
    padding: 20,
    borderRadius: 20,
  },
  hubCardSelected: {
    borderColor: SKY,
    borderWidth: 2,
  },
  cardContentRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  cardMain: {
    flex: 1,
    minWidth: 0,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  hubIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  hubIcon: {
    width: 28,
    height: 28,
  },
  hubProfileBox: {
    width: 64,
    height: 64,
    marginLeft: 12,
  },
  hubProfileTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  hubProfileImage: {
    width: '100%',
    height: '100%',
  },
  hubProfilePlaceholder: {
    width: '100%',
    height: '100%',
    opacity: 0.9,
  },
  hubProfileInfoIcon: {
    position: 'absolute',
    bottom: 4,
    right: 4,
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  hubName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
  },
  hubAddress: {
    color: '#94A3B8',
    fontSize: 12,
    marginTop: 4,
    lineHeight: 16,
  },
  distanceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 8,
  },
  distanceText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '700',
  },
  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
  },
  ctaButton: {
    borderRadius: 18,
    paddingVertical: 18,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
  // Modal
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalContent: {
    width: '100%',
    maxWidth: 320,
    backgroundColor: '#1E293B',
    borderRadius: 20,
    padding: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 16,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '700',
  },
  modalValue: {
    color: SKY,
    fontSize: 28,
    fontWeight: '800',
    marginBottom: 16,
    textAlign: 'center',
  },
  slider: {
    width: '100%',
    height: 40,
    marginBottom: 20,
  },
  modalDone: {
    backgroundColor: SKY,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  modalDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  hubInfoModalContent: {
    width: '100%',
    maxWidth: 360,
    maxHeight: '85%',
    backgroundColor: '#1E293B',
    borderRadius: 20,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  hubInfoCoverWrap: {
    height: 140,
    backgroundColor: 'rgba(0,0,0,0.3)',
  },
  hubInfoCover: {
    width: '100%',
    height: '100%',
  },
  hubInfoCoverPlaceholder: {
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  hubInfoCoverImg: {
    width: 64,
    height: 64,
    opacity: 0.8,
  },
  hubInfoCoverOverlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  hubInfoClose: {
    position: 'absolute',
    top: 12,
    right: 12,
  },
  hubInfoBody: {
    padding: 20,
  },
  hubInfoTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 6,
  },
  hubInfoAddress: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 16,
  },
  hubInfoRating: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 16,
  },
  hubInfoRatingText: {
    color: '#FCD34D',
    fontSize: 15,
    fontWeight: '700',
  },
  hubInfoStats: {
    gap: 10,
  },
  hubInfoStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  hubInfoStatText: {
    color: 'rgba(229,231,235,0.9)',
    fontSize: 14,
  },
  hubInfoTags: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 16,
  },
  hubInfoTag: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
  },
  hubInfoTagText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '600',
  },
  hubInfoDone: {
    margin: 20,
    marginTop: 0,
    backgroundColor: SKY,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  hubInfoDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
});
