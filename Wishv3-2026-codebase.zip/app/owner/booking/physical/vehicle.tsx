import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Image,
  Modal,
  Pressable,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import * as Location from 'expo-location';
import { useAuth } from '../../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../../src/lib/supabase';
import { hapticFeedback } from '../../../../src/services/HapticFeedbackService';
import GlassCard from '../../../../src/components/booking/GlassCard';
import AppHeader from '../../../../src/components/shared/AppHeader';
import { colors } from '../../../../src/constants/colors';

const { width } = Dimensions.get('window');
const CARD_WIDTH = width - 48;
const SKY = colors.SKY;

type VehicleSize = 'small' | 'medium' | 'large';

type Vehicle = {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
  image_url?: string | null;
  created_at?: string | null;
  photo?: string | null;
  size?: VehicleSize | string | null;
};

function formatVehicleSize(size: VehicleSize | string | null | undefined): string {
  if (!size) return '';
  const s = String(size).toLowerCase();
  if (s === 'small') return 'Small';
  if (s === 'medium') return 'Medium';
  if (s === 'large') return 'Large';
  return s.charAt(0).toUpperCase() + s.slice(1);
}

export default function PhysicalVehicleSelection() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();

  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [expandedImageUri, setExpandedImageUri] = useState<string | null>(null);
  const [infoModalVehicle, setInfoModalVehicle] = useState<Vehicle | null>(null);
  const [vehicleWashCount, setVehicleWashCount] = useState<number>(0);

  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });

  const fadeAnim = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 500,
      useNativeDriver: true,
    }).start();

    getCurrentLocation();
    loadVehicles();
  }, [user?.id]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;

      const location = await Location.getCurrentPositionAsync({
        accuracy: Location.Accuracy.Balanced,
      });

      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };

      setUserLocation(coords);
      setRegion({ ...coords, latitudeDelta: 0.01, longitudeDelta: 0.01 });
    } catch {}
  };

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;

      const rows = (data || []).map((r: any) => ({
        ...r,
        image_url: r.image_url ?? r.photo ?? null,
        created_at: r.created_at ?? null,
      }));
      setVehicles(rows);
      if (rows.length > 0) {
        setSelectedVehicle(rows.find((v: Vehicle) => v.is_default)?.id ?? rows[0].id);
      }
    } catch (e) {
      console.error('Failed to load vehicles', e);
    } finally {
      setLoading(false);
    }
  };

  const openVehicleInfo = async (vehicle: Vehicle) => {
    hapticFeedback('light');
    setInfoModalVehicle(vehicle);
    setVehicleWashCount(0);
    try {
      const res = await supabase
        .from('bookings')
        .select('id', { count: 'exact', head: true })
        .eq('vehicle_id', vehicle.id)
        .eq('status', 'completed');
      setVehicleWashCount((res as { count?: number }).count ?? 0);
    } catch {
      setVehicleWashCount(0);
    }
  };

  const handleSelect = async (vehicleId: string) => {
    await hapticFeedback('light');
    setSelectedVehicle(vehicleId);
  };

  const handleContinue = async () => {
    if (!selectedVehicle) return;
    await hapticFeedback('medium');
    router.push({
      pathname: '/owner/booking/physical/location',
      params: { vehicleId: selectedVehicle },
    });
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {/* Map */}
      <MapView style={StyleSheet.absoluteFill} region={region}>
        {userLocation && (
          <Marker coordinate={userLocation}>
            <Image
              source={require('../../../../assets/car.png')}
              style={{ width: 48, height: 48 }}
            />
          </Marker>
        )}
      </MapView>

      {/* Header */}
      <AppHeader
        title="Select Vehicle"
        subtitle="Swipe and choose a vehicle"
        showBack
        onBack={() => router.back()}
      />

      {/* Vehicle Cards */}
      <Animated.View
        style={[
          styles.cardsWrapper,
          {
            opacity: fadeAnim,
            bottom: 96 + insets.bottom,
          },
        ]}
      >
        {loading ? (
          <ActivityIndicator size="large" color={SKY} />
        ) : vehicles.length === 0 ? (
          <GlassCard style={styles.emptyCard}>
            <Ionicons name="car-outline" size={48} color={SKY} />
            <Text style={styles.emptyTitle}>No vehicles yet</Text>
            <TouchableOpacity
              onPress={() => router.push('/owner/settings/vehicle-management')}
            >
              <Text style={styles.addVehicleLink}>Add a vehicle</Text>
            </TouchableOpacity>
          </GlassCard>
        ) : (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            snapToInterval={CARD_WIDTH + 12}
            decelerationRate="fast"
            contentContainerStyle={styles.cardsScrollContent}
          >
            {vehicles.map(vehicle => {
              const selected = selectedVehicle === vehicle.id;
              return (
                <View key={vehicle.id} style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
                  <GlassCard
                    onPress={() => handleSelect(vehicle.id)}
                    style={[
                      styles.vehicleCard,
                      selected && styles.vehicleCardSelected,
                    ]}
                    borderRadius={20}
                    borderColor={selected ? SKY : undefined}
                  >
                    <View style={styles.cardContentRow}>
                      <View style={styles.cardMain}>
                        <View style={styles.cardHeader}>
                          <Ionicons
                            name="car-sport"
                            size={28}
                            color={selected ? SKY : '#94A3B8'}
                          />
                          <View style={styles.cardHeaderRight}>
                            <TouchableOpacity
                              onPress={(e) => {
                                e.stopPropagation();
                                openVehicleInfo(vehicle);
                              }}
                              hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                              style={styles.infoIconBtn}
                            >
                              <Ionicons name="information-circle-outline" size={22} color={SKY} />
                            </TouchableOpacity>
                            {selected && (
                              <Ionicons name="checkmark-circle" size={22} color={SKY} />
                            )}
                          </View>
                        </View>

                        <Text style={styles.vehicleName}>
                          {vehicle.make} {vehicle.model}
                        </Text>
<Text style={styles.vehicleMeta}>
                        {vehicle.color} • {vehicle.registration}
                        {vehicle.size && ` • ${formatVehicleSize(vehicle.size)}`}
                      </Text>

                      {vehicle.is_default && (
                          <View style={styles.defaultBadge}>
                            <Ionicons name="star" size={10} color="#10B981" />
                            <Text style={styles.defaultText}>Default</Text>
                          </View>
                        )}
                      </View>

                      <View style={styles.carPhotoBox}>
                        {vehicle.image_url ? (
                          <TouchableOpacity
                            onPress={(e) => {
                              e.stopPropagation();
                              hapticFeedback('light');
                              setExpandedImageUri(vehicle.image_url || null);
                            }}
                            activeOpacity={0.9}
                            style={styles.carPhotoTouch}
                          >
                            <Image
                              source={{ uri: vehicle.image_url }}
                              style={styles.carPhotoSmall}
                              resizeMode="cover"
                            />
                            <View style={styles.carPhotoExpandHint}>
                              <Ionicons name="expand" size={12} color="#fff" />
                            </View>
                          </TouchableOpacity>
                        ) : (
                          <View style={styles.carPhotoPlaceholder}>
                            <Ionicons name="car-sport-outline" size={24} color={SKY} style={{ opacity: 0.5 }} />
                          </View>
                        )}
                      </View>
                    </View>
                  </GlassCard>
                </View>
              );
            })}
          </ScrollView>
        )}
      </Animated.View>

      {/* Vehicle info modal */}
      <Modal
        visible={!!infoModalVehicle}
        transparent
        animationType="fade"
        onRequestClose={() => setInfoModalVehicle(null)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setInfoModalVehicle(null)}>
          <Pressable style={styles.infoModalContent} onPress={(e) => e.stopPropagation()}>
            {infoModalVehicle && (
              <>
                <View style={styles.infoModalHeader}>
                  <Text style={styles.infoModalTitle}>{infoModalVehicle.make} {infoModalVehicle.model}</Text>
                  <TouchableOpacity
                    onPress={() => setInfoModalVehicle(null)}
                    hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                  >
                    <Ionicons name="close" size={24} color="#94A3B8" />
                  </TouchableOpacity>
                </View>
                <View style={styles.infoModalBody}>
                  <View style={styles.infoModalRow}>
                    <Ionicons name="car-sport-outline" size={18} color={SKY} />
                    <Text style={styles.infoModalText}>{infoModalVehicle.color} • {infoModalVehicle.registration}</Text>
                  </View>
                  {infoModalVehicle.size && (
                    <View style={styles.infoModalRow}>
                      <Ionicons name="resize-outline" size={18} color={SKY} />
                      <Text style={styles.infoModalText}>{formatVehicleSize(infoModalVehicle.size)} vehicle</Text>
                    </View>
                  )}
                  {infoModalVehicle.created_at && (
                    <View style={styles.infoModalRow}>
                      <Ionicons name="calendar-outline" size={18} color={SKY} />
                      <Text style={styles.infoModalText}>
                        Added {new Date(infoModalVehicle.created_at).toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' })}
                      </Text>
                    </View>
                  )}
                  <View style={styles.infoModalRow}>
                    <Ionicons name="checkmark-done" size={18} color="#10B981" />
                    <Text style={styles.infoModalText}>{vehicleWashCount} washes completed</Text>
                  </View>
                  {infoModalVehicle.is_default && (
                    <View style={styles.infoModalBadge}>
                      <Ionicons name="star" size={14} color="#10B981" />
                      <Text style={styles.infoModalBadgeText}>Default vehicle</Text>
                    </View>
                  )}
                </View>
                <TouchableOpacity
                  onPress={() => setInfoModalVehicle(null)}
                  style={styles.infoModalDone}
                  activeOpacity={0.9}
                >
                  <Text style={styles.infoModalDoneText}>Close</Text>
                </TouchableOpacity>
              </>
            )}
          </Pressable>
        </Pressable>
      </Modal>

      {/* Expanded car photo modal */}
      <Modal
        visible={!!expandedImageUri}
        transparent
        animationType="fade"
        onRequestClose={() => setExpandedImageUri(null)}
      >
        <Pressable
          style={styles.imageModalOverlay}
          onPress={() => setExpandedImageUri(null)}
        >
          <Pressable onPress={(e) => e.stopPropagation()} style={styles.imageModalContent}>
            {expandedImageUri && (
              <Image
                source={{ uri: expandedImageUri }}
                style={styles.imageModalImage}
                resizeMode="contain"
              />
            )}
            <TouchableOpacity
              onPress={() => setExpandedImageUri(null)}
              style={styles.imageModalClose}
              hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
            >
              <Ionicons name="close-circle" size={36} color="#fff" />
            </TouchableOpacity>
          </Pressable>
        </Pressable>
      </Modal>

      {/* Continue Button */}
      <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12 }]}>
        <TouchableOpacity
          onPress={handleContinue}
          disabled={!selectedVehicle}
          activeOpacity={0.9}
        >
          <LinearGradient
            colors={
              selectedVehicle
                ? [SKY, '#0EA5E9']
                : ['#475569', '#334155']
            }
            style={styles.ctaButton}
          >
            <Text style={styles.ctaText}>
              {selectedVehicle ? 'Continue' : 'Select a vehicle'}
            </Text>
            <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },

  cardsWrapper: {
    position: 'absolute',
    width: '100%',
  },
  cardsScrollContent: {
    paddingHorizontal: 16,
    paddingRight: 28,
  },
  cardWrapper: {
    width: CARD_WIDTH,
    marginRight: 12,
  },
  vehicleCard: {
    width: '100%',
    padding: 20,
    borderRadius: 20,
  },

  cardContentRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },

  cardMain: {
    flex: 1,
    minWidth: 0,
  },

  carPhotoBox: {
    width: 64,
    height: 64,
    marginLeft: 12,
  },

  carPhotoTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },

  carPhotoSmall: {
    width: '100%',
    height: '100%',
  },

  carPhotoExpandHint: {
    position: 'absolute',
    bottom: 4,
    right: 4,
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  carPhotoPlaceholder: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  imageModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.85)',
    justifyContent: 'center',
    alignItems: 'center',
  },

  imageModalContent: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },

  imageModalImage: {
    width: '100%',
    height: '80%',
  },

  imageModalClose: {
    position: 'absolute',
    top: 60,
    right: 24,
  },

  vehicleCardSelected: {
    shadowColor: SKY,
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 10,
  },

  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  cardHeaderRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  infoIconBtn: {
    padding: 4,
  },

  vehicleName: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '900',
  },

  vehicleMeta: {
    color: '#94A3B8',
    marginTop: 4,
    fontWeight: '600',
  },

  defaultBadge: {
    marginTop: 10,
    flexDirection: 'row',
    gap: 6,
    alignItems: 'center',
  },

  defaultText: {
    color: '#10B981',
    fontSize: 12,
    fontWeight: '800',
  },

  emptyCard: {
    marginHorizontal: 24,
    padding: 32,
    alignItems: 'center',
    gap: 12,
  },

  emptyTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
  },

  addVehicleLink: {
    color: SKY,
    fontWeight: '800',
    marginTop: 8,
  },

  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
  },

  ctaButton: {
    borderRadius: 18,
    paddingVertical: 18,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },

  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },

  // Vehicle info modal
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  infoModalContent: {
    width: '100%',
    maxWidth: 340,
    backgroundColor: '#1E293B',
    borderRadius: 20,
    padding: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  infoModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  infoModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    flex: 1,
  },
  infoModalBody: {
    gap: 12,
    marginBottom: 20,
  },
  infoModalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  infoModalText: {
    color: 'rgba(229,231,235,0.9)',
    fontSize: 15,
  },
  infoModalBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
    backgroundColor: 'rgba(16,185,129,0.15)',
    alignSelf: 'flex-start',
  },
  infoModalBadgeText: {
    color: '#10B981',
    fontSize: 13,
    fontWeight: '700',
  },
  infoModalDone: {
    backgroundColor: SKY,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  infoModalDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
});
