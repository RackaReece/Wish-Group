import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Image,
  ActivityIndicator,
  Modal,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import MapView, { Region, Marker, MapPressEvent } from 'react-native-maps';
import * as Location from 'expo-location';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '../../../src/components/booking/GlassCard';
import FloatingMapButton from '../../../src/components/booking/FloatingMapButton';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { serviceOptions } from '../../../src/constants/serviceOptions';
import AppHeader from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import {
  calculateDisplayPrice,
  getVehicleSize,
  mapServiceIdToWashId,
  FrontendPricingInput
} from '../../../src/pricing/pricingEngine';


import { BOOKING_CARD } from '../../../src/constants/bookingCardTheme';

const { width } = Dimensions.get('window');
const CARD_WIDTH = BOOKING_CARD.CARD_WIDTH;
const SKY = colors.SKY;
const CARD_GRADIENT = BOOKING_CARD.GRADIENT;
const BG = colors.BG;

// Uber-style dark map theme
const uberDarkMapStyle = [
  {
    elementType: 'geometry',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.fill',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'administrative.locality',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'geometry',
    stylers: [{ color: '#263c3f' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#6b9a76' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry',
    stylers: [{ color: '#38414e' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#212a37' }],
  },
  {
    featureType: 'road',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#9ca5b3' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#1f2835' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#f3d19c' }],
  },
  {
    featureType: 'transit',
    elementType: 'geometry',
    stylers: [{ color: '#2f3948' }],
  },
  {
    featureType: 'transit.station',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [{ color: '#17263c' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#515c6d' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#17263c' }],
  },
];

type Vehicle = {
  id: string;
  type: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
};

type BookingStep = 'location' | 'vehicle' | 'service';

export default function BookingCreate() {
  const [infoService, setInfoService] = useState<any | null>(null);
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState<BookingStep>('location');
  const [selectedLocation, setSelectedLocation] = useState<{ latitude: number; longitude: number; address: string } | null>(null);
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [washType, setWashType] = useState<'exterior' | 'interior' | null>(null);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const [valeterCount, setValeterCount] = useState<number>(0);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [mapLocation, setMapLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [address, setAddress] = useState('');

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const stepSlideAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    loadVehicles();
  }, [user?.id]);

  useEffect(() => {
    stepSlideAnim.setValue(24);
    Animated.timing(stepSlideAnim, {
      toValue: 0,
      duration: 320,
      useNativeDriver: true,
    }).start();
  }, [currentStep]);

  // Get user location and load nearby valeters
  useEffect(() => {
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') {
          console.warn('Location permission not granted');
          return;
        }

        const location = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Balanced,
        });

        const coords = {
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        };

        setUserLocation(coords);
        setMapLocation(coords);
        setRegion({
          latitude: coords.latitude,
          longitude: coords.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });

        // Reverse geocode to get address
        try {
          const [result] = await Location.reverseGeocodeAsync(coords);
          if (result) {
            const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current Location';
            setAddress(addr);
            setSelectedLocation({ ...coords, address: addr });
          }
        } catch (e) {
          console.warn('Reverse geocode error:', e);
        }

        // Load nearby valeters count
        await loadNearbyValetersCount(coords.latitude, coords.longitude);
      } catch (error) {
        console.warn('Error getting location:', error);
      }
    })();
  }, []);

  const handleMapPress = async (event: MapPressEvent) => {
    const coords = event.nativeEvent.coordinate;
    setMapLocation(coords);
    setRegion({
      latitude: coords.latitude,
      longitude: coords.longitude,
      latitudeDelta: 0.01,
      longitudeDelta: 0.01,
    });

    try {
      const [result] = await Location.reverseGeocodeAsync(coords);
      if (result) {
        const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Selected Location';
        setAddress(addr);
        setSelectedLocation({ ...coords, address: addr });
        await hapticFeedback('light');
      }
    } catch (e) {
      console.warn('Reverse geocode error:', e);
    }
  };

  const handleUseCurrentLocation = async () => {
    await hapticFeedback('medium');
    if (userLocation) {
      setMapLocation(userLocation);
      setRegion({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
      try {
        const [result] = await Location.reverseGeocodeAsync(userLocation);
        if (result) {
          const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current Location';
          setAddress(addr);
          setSelectedLocation({ ...userLocation, address: addr });
        }
      } catch (e) {
        console.warn('Reverse geocode error:', e);
      }
    }
  };

  const loadNearbyValetersCount = async (latitude: number, longitude: number) => {
    try {
      const { data: presenceData, error } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng')
        .eq('is_online', true);

      if (error) {
        console.warn('Error loading valeters:', error);
        return;
      }

      if (!presenceData || presenceData.length === 0) {
        setValeterCount(0);
        return;
      }

      const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
        const R = 3959;
        const dLat = ((lat2 - lat1) * Math.PI) / 180;
        const dLon = ((lon2 - lon1) * Math.PI) / 180;
        const a =
          Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos((lat1 * Math.PI) / 180) *
            Math.cos((lat2 * Math.PI) / 180) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
      };

      const nearbyValeters = presenceData.filter((presence) => {
        if (!presence.last_lat || !presence.last_lng) return false;
        const distance = calculateDistance(latitude, longitude, presence.last_lat, presence.last_lng);
        return distance <= 10;
      });

      setValeterCount(nearbyValeters.length);
    } catch (error) {
      console.warn('Error counting valeters:', error);
    }
  };

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      setVehicles(data || []);
      if (data && data.length > 0) {
        const defaultVehicle = data.find(v => v.is_default) || data[0];
        setSelectedVehicle(defaultVehicle.id);
      }
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLocationContinue = async () => {
    if (!selectedLocation) {
      Alert.alert('Location Required', 'Please select a location on the map or use your current location.');
      return;
    }
    await hapticFeedback('medium');
    setCurrentStep('vehicle');
  };

  const handleVehicleContinue = async () => {
    if (!selectedVehicle) {
      Alert.alert('Vehicle Required', 'Please select a vehicle.');
      return;
    }
    await hapticFeedback('medium');
    setCurrentStep('service');
  };

  const handleServiceSelect = async (serviceId: string) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
    if (serviceId !== 'bronze-wash') {
      setWashType(null);
    }
  };

  const handleWashTypeSelect = async (type: 'exterior' | 'interior') => {
    await hapticFeedback('light');
    setWashType(type);
  };

  const handleServiceContinue = async () => {
    if (!selectedService || !selectedVehicle || !selectedLocation) {
      return;
    }
    if (selectedService === 'bronze-wash' && !washType) {
      return;
    }
    await hapticFeedback('medium');
    router.push({
      pathname: '/owner/booking/valeter-selection',
      params: {
        serviceId: selectedService,
        vehicleId: selectedVehicle,
        latitude: selectedLocation.latitude.toString(),
        longitude: selectedLocation.longitude.toString(),
        address: selectedLocation.address,
        washType: washType || '',
      },
    });
  };

  const selectedServiceData = serviceOptions.find(s => s.id === selectedService);
  const selectedVehicleData = vehicles.find(v => v.id === selectedVehicle);

  const pricingBreakdown = selectedService && selectedVehicleData ? (() => {
    const washId = mapServiceIdToWashId(selectedService);
    if (!washId) return null;
    const vehicleSize = getVehicleSize(selectedVehicleData);
    const input: FrontendPricingInput = {
      washId,
      vehicleSize,
      isMobile: true,
      isPhysicalLocation: false,
      scheduledDateTime: new Date(),
    };
    return calculateDisplayPrice(input);
  })() : null;


  return (
    <SafeAreaView style={styles.container} edges={[]}>
      {/* Fullscreen map - always visible */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          onPress={currentStep === 'location' ? handleMapPress : undefined}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={uberDarkMapStyle}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image
                  source={require('../../../assets/car.png')}
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
          {mapLocation && currentStep === 'location' && (
            <Marker coordinate={mapLocation}>
              <Animated.View style={[styles.selectedLocationMarker, { transform: [{ scale: markerPulse }] }]}>
                <View style={styles.selectedLocationMarkerInner}>
                  <Ionicons name="location" size={20} color="#FFFFFF" />
                </View>
              </Animated.View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Header floating over the map */}
      <AppHeader
        title={
          currentStep === 'location' ? 'Select Location' :
          currentStep === 'vehicle' ? 'Select Vehicle' :
          'Select Service'
        }
        subtitle={
          currentStep === 'location' ? 'Tap on map to choose location' :
          currentStep === 'vehicle' ? 'Swipe to see all vehicles' :
          'Swipe to see all services'
        }
        showBack={currentStep !== 'location'}
        onBack={
          currentStep === 'service'
            ? () => {
                setCurrentStep('vehicle');
              }
            : currentStep === 'vehicle'
            ? () => {
                setCurrentStep('location');
              }
            : undefined
        }
        rightAction={
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            {currentStep === 'location' && (
              <TouchableOpacity onPress={handleUseCurrentLocation} style={styles.currentLocationButton}>
                <Ionicons name="locate" size={20} color={SKY} />
              </TouchableOpacity>
            )}
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                router.replace('/owner/owner-dashboard' as any);
              }}
              style={styles.exitButton}
              activeOpacity={0.7}
            >
              <Ionicons name="close" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        }
      />

      {/* Valeter count badge */}
      <Animated.View
        style={[
          styles.valeterCountBadge,
          {
            opacity: fadeAnim,
            top: insets.top + 92,
          },
        ]}
      >
        <View style={styles.valeterCountContent}>
          <Ionicons name="people-outline" size={18} color={SKY} />
          <Text style={styles.valeterCountText}>{valeterCount}</Text>
        </View>
      </Animated.View>

      {/* Step progress dots */}
      <Animated.View style={[styles.stepDots, { top: insets.top + 88 }]}>
        {(['location', 'vehicle', 'service'] as const).map((step, i) => {
          const idx = ['location', 'vehicle', 'service'].indexOf(currentStep);
          const done = i < idx;
          const active = i === idx;
          return (
            <View
              key={step}
              style={[
                styles.stepDot,
                done && styles.stepDotDone,
                active && styles.stepDotActive,
              ]}
            />
          );
        })}
      </Animated.View>

      {/* Floating cards container - matches Book Your Wash */}
      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            paddingBottom: Math.max(insets.bottom, 14) + 14 + TAB_BAR_TOTAL_HEIGHT + 12,
          },
        ]}
      >
        <Animated.View style={[styles.cardsInner, { transform: [{ translateX: stepSlideAnim }] }]}>
        {/* Step 1: Location Selection */}
        {currentStep === 'location' && (
          <View style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
            <GlassCard
              style={[styles.modernCard, !selectedLocation && styles.modernCardEmpty]}
              borderRadius={BOOKING_CARD.BORDER_RADIUS}
              accountType="customer"
              intensity={BOOKING_CARD.INTENSITY}
            >
              <LinearGradient
                colors={[SKY + '15', SKY + '08', 'transparent']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
              {!selectedLocation ? (
                <View style={styles.emptyContent}>
                  <View style={[styles.iconWrap, { backgroundColor: SKY + '20', borderColor: SKY + '40' }]}>
                    <Ionicons name="location-outline" size={28} color={SKY} />
                  </View>
                  <Text style={styles.emptyText}>Tap on the map</Text>
                  <Text style={styles.emptySubtext}>Select your wash location</Text>
                </View>
              ) : (
                <>
                  <View style={styles.cardTop}>
                    <View style={[styles.iconWrap, { backgroundColor: SKY + '25', borderColor: SKY + '40' }]}>
                      <LinearGradient colors={CARD_GRADIENT} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.iconGradient}>
                        <Ionicons name="location" size={26} color="#FFFFFF" />
                      </LinearGradient>
                    </View>
                    <View style={styles.cardContent}>
                      <View style={styles.titleRow}>
                        <Text style={styles.cardTitle} numberOfLines={1}>Location</Text>
                        <View style={[styles.badgeSmall, { backgroundColor: '#10B98120', borderColor: '#10B98140' }]}>
                          <Ionicons name="checkmark" size={10} color="#10B981" />
                        </View>
                      </View>
                      <Text style={styles.cardSubtitle} numberOfLines={2}>{selectedLocation.address}</Text>
                    </View>
                  </View>
                  <View style={[styles.ctaDivider, { backgroundColor: SKY + '25' }]} />
                  <TouchableOpacity onPress={handleLocationContinue} style={styles.ctaButton} activeOpacity={0.9}>
                    <LinearGradient colors={[SKY, '#60A5FA']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.ctaGradient}>
                      <Text style={styles.ctaText}>Continue</Text>
                      <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
                    </LinearGradient>
                  </TouchableOpacity>
                </>
              )}
            </GlassCard>
          </View>
        )}

        {/* Step 2: Vehicle Selection */}
        {currentStep === 'vehicle' && (
          loading ? (
            <View style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
              <GlassCard style={styles.modernCard} borderRadius={BOOKING_CARD.BORDER_RADIUS} accountType="customer" intensity={BOOKING_CARD.INTENSITY}>
                <View style={styles.loadingContainer}>
                  <ActivityIndicator size="large" color={SKY} />
                  <Text style={styles.loadingText}>Loading vehicles…</Text>
                </View>
              </GlassCard>
            </View>
          ) : vehicles.length === 0 ? (
            <View style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
              <GlassCard style={styles.modernCard} borderRadius={BOOKING_CARD.BORDER_RADIUS} accountType="customer" intensity={BOOKING_CARD.INTENSITY}>
                <LinearGradient colors={[SKY + '12', 'transparent']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
                <View style={styles.emptyContent}>
                  <View style={[styles.iconWrap, { backgroundColor: SKY + '20', borderColor: SKY + '40' }]}>
                    <Ionicons name="car-outline" size={28} color={SKY} />
                  </View>
                  <Text style={styles.emptyText}>No vehicles found</Text>
                  <Text style={styles.emptySubtext}>Add a vehicle to continue</Text>
                  <TouchableOpacity onPress={() => router.push('/owner/settings/vehicle-management')} style={styles.addButton} activeOpacity={0.85}>
                    <LinearGradient colors={[SKY, '#60A5FA']} style={styles.addButtonGradient}>
                      <Ionicons name="add-circle" size={20} color="#FFFFFF" />
                      <Text style={styles.addButtonText}>Add Vehicle</Text>
                    </LinearGradient>
                  </TouchableOpacity>
                </View>
              </GlassCard>
            </View>
          ) : (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.cardsScrollContent}
              snapToInterval={BOOKING_CARD.SNAP_INTERVAL}
              decelerationRate="fast"
              snapToAlignment="start"
            >
              {vehicles.map((vehicle) => {
                const isSelected = selectedVehicle === vehicle.id;
                return (
                  <View key={vehicle.id} style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
                    <GlassCard
                      onPress={() => { hapticFeedback('light'); setSelectedVehicle(vehicle.id); }}
                      style={[styles.modernCard, isSelected && styles.modernCardSelected]}
                      borderColor={isSelected ? SKY : undefined}
                      borderRadius={BOOKING_CARD.BORDER_RADIUS}
                      accountType="customer"
                      intensity={BOOKING_CARD.INTENSITY}
                    >
                      <LinearGradient colors={isSelected ? [SKY + '15', SKY + '08', 'transparent'] : ['transparent', 'transparent']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
                      <View style={styles.cardTop}>
                        <View style={[styles.iconWrap, { backgroundColor: (isSelected ? SKY : '#94A3B8') + '25', borderColor: (isSelected ? SKY : '#94A3B8') + '40' }]}>
                          <Ionicons name="car-sport" size={26} color={isSelected ? SKY : '#94A3B8'} />
                        </View>
                        <View style={styles.cardContent}>
                          <View style={styles.titleRow}>
                            <Text style={styles.cardTitle} numberOfLines={1}>{vehicle.make} {vehicle.model}</Text>
                            {isSelected && <View style={[styles.badgeSmall, { backgroundColor: '#10B98120', borderColor: '#10B98140' }]}><Ionicons name="checkmark" size={10} color="#10B981" /></View>}
                          </View>
                          <Text style={styles.cardSubtitle}>{vehicle.color} • {vehicle.registration}</Text>
                          {vehicle.is_default && (
                            <View style={styles.cardMetaRow}>
                              <View style={[styles.quickHint, { backgroundColor: '#10B98115' }]}>
                                <Ionicons name="star" size={11} color="#10B981" />
                                <Text style={[styles.quickHintText, { color: '#10B981' }]}>Default</Text>
                              </View>
                            </View>
                          )}
                        </View>
                        <View style={styles.carPhotoBox}>
                          {vehicle.image_url ? (
                            <Image source={{ uri: vehicle.image_url }} style={styles.carPhotoSmall} resizeMode="cover" />
                          ) : (
                            <View style={styles.carPhotoPlaceholder}>
                              <Ionicons name="car-sport-outline" size={22} color={SKY} style={{ opacity: 0.5 }} />
                            </View>
                          )}
                        </View>
                      </View>
                      <View style={[styles.ctaDivider, { backgroundColor: SKY + '25' }]} />
                      <TouchableOpacity onPress={handleVehicleContinue} style={styles.ctaButton} activeOpacity={0.9}>
                        <LinearGradient colors={[SKY, '#60A5FA']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.ctaGradient}>
                          <Text style={styles.ctaText}>Continue</Text>
                          <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
                        </LinearGradient>
                      </TouchableOpacity>
                    </GlassCard>
                  </View>
                );
              })}
            </ScrollView>
          )
        )}

        {/* Step 3: Service Selection */}
        {currentStep === 'service' && (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.cardsScrollContent}
            snapToInterval={BOOKING_CARD.SNAP_INTERVAL}
            decelerationRate="fast"
            snapToAlignment="start"
          >
            {serviceOptions.map((service) => {
              const isSelected = selectedService === service.id;
              const showWashTypeSelection = isSelected && service.id === 'bronze-wash';
              const serviceColor = service.colors[0];

              return (
                <View key={service.id} style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
                  <GlassCard
                    onPress={() => handleServiceSelect(service.id)}
                    style={[styles.modernCard, isSelected && styles.modernCardSelected, isSelected && { borderColor: serviceColor }]}
                    borderColor={isSelected ? serviceColor : 'rgba(148,163,184,0.25)'}
                    borderRadius={BOOKING_CARD.BORDER_RADIUS}
                    accountType="customer"
                    intensity={BOOKING_CARD.INTENSITY}
                  >
                    <LinearGradient colors={isSelected ? [serviceColor + '15', serviceColor + '08', 'transparent'] : ['transparent', 'transparent']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
                    <View style={styles.cardTop}>
                      <View style={[styles.iconWrap, { backgroundColor: serviceColor + '25', borderColor: serviceColor + '40' }]}>
                        <Ionicons name={service.icon as any} size={26} color={serviceColor} />
                      </View>
                      <View style={styles.cardContent}>
                        <View style={styles.titleRow}>
                          <Text style={styles.cardTitle} numberOfLines={1}>{service.name}</Text>
                          <TouchableOpacity onPress={(e) => { e.stopPropagation(); hapticFeedback('light'); setInfoService(service); }} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }} style={[styles.infoIconBtn, { backgroundColor: serviceColor + '15' }]}>
                            <Ionicons name="information-circle-outline" size={20} color={serviceColor} />
                          </TouchableOpacity>
                        </View>
                        <Text style={styles.cardSubtitle}>{service.dur}</Text>
                        <View style={styles.cardMetaRow}>
                          <View style={[styles.quickHint, { backgroundColor: serviceColor + '15' }]}>
                            <Text style={[styles.quickHintText, { color: serviceColor }]}>£{service.price}</Text>
                          </View>
                        </View>
                        {showWashTypeSelection && (
                          <View style={styles.washTypeRow}>
                            <TouchableOpacity onPress={(e) => { e.stopPropagation(); handleWashTypeSelect('exterior'); }} style={[styles.washTypePillClean, washType === 'exterior' && { backgroundColor: serviceColor + '30', borderColor: serviceColor }]}>
                              <Text style={[styles.washTypePillTextClean, washType === 'exterior' && { color: serviceColor, fontWeight: '700' }]}>Exterior</Text>
                            </TouchableOpacity>
                            <TouchableOpacity onPress={(e) => { e.stopPropagation(); handleWashTypeSelect('interior'); }} style={[styles.washTypePillClean, washType === 'interior' && { backgroundColor: serviceColor + '30', borderColor: serviceColor }]}>
                              <Text style={[styles.washTypePillTextClean, washType === 'interior' && { color: serviceColor, fontWeight: '700' }]}>Interior</Text>
                            </TouchableOpacity>
                          </View>
                        )}
                      </View>
                    </View>
                    {isSelected && selectedVehicle && (selectedService !== 'bronze-wash' || washType) && (
                      <>
                        <View style={[styles.ctaDivider, { backgroundColor: serviceColor + '25' }]} />
                        <TouchableOpacity onPress={handleServiceContinue} style={styles.ctaButton} activeOpacity={0.9}>
                          <LinearGradient colors={[SKY, '#60A5FA']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.ctaGradient}>
                            <Text style={styles.ctaText}>Continue</Text>
                            <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
                          </LinearGradient>
                        </TouchableOpacity>
                      </>
                    )}
                  </GlassCard>
                </View>
              );
            })}
          </ScrollView>
        )}
        </Animated.View>

        {/* Service Info Modal */}
        <Modal visible={!!infoService} transparent animationType="fade" onRequestClose={() => setInfoService(null)}>
          <TouchableOpacity
            style={styles.modalOverlay}
            activeOpacity={1}
            onPress={() => setInfoService(null)}
          >
            <TouchableOpacity activeOpacity={1} onPress={(e) => e.stopPropagation()}>
              <View style={styles.modalContent}>
                <View style={styles.modalHeader}>
                  <View style={[styles.modalIconWrapper, infoService && { backgroundColor: infoService.colors[0] + '20' }]}>
                    <Ionicons name={infoService?.icon as any} size={28} color={infoService?.colors[0]} />
                  </View>
                  <View style={styles.modalTitleContainer}>
                    <Text style={styles.modalTitle}>{infoService?.name}</Text>
                    <Text style={styles.modalPrice}>£{infoService?.price}</Text>
                  </View>
                </View>

                <Text style={styles.modalDescription}>{infoService?.desc}</Text>

                {infoService?.bulletPoints && infoService.bulletPoints.length > 0 && (
                  <View style={styles.bulletPointsContainer}>
                    {infoService.bulletPoints.map((point: string, index: number) => (
                      <View key={index} style={styles.bulletPoint}>
                        <Ionicons name="checkmark-circle" size={18} color={SKY} />
                        <Text style={styles.bulletPointText}>{point}</Text>
                      </View>
                    ))}
                  </View>
                )}

                <TouchableOpacity
                  onPress={async () => {
                    await hapticFeedback('light');
                    setInfoService(null);
                  }}
                  style={styles.modalCloseButton}
                >
                  <LinearGradient
                    colors={[SKY, '#60A5FA']}
                    style={styles.modalCloseButtonGradient}
                  >
                    <Text style={styles.modalCloseButtonText}>Close</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </TouchableOpacity>
          </TouchableOpacity>
        </Modal>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: 'transparent',
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  selectedLocationMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedLocationMarkerInner: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
  },
  valeterCountBadge: {
    position: 'absolute',
    right: 16,
    zIndex: 1000,
  },
  valeterCountContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 24,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  valeterCountText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  currentLocationButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 8,
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  cardsInner: {},
  stepDots: {
    position: 'absolute',
    left: 16,
    flexDirection: 'row',
    gap: 8,
    zIndex: 100,
  },
  stepDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(148,163,184,0.4)',
  },
  stepDotDone: {
    backgroundColor: SKY,
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  stepDotActive: {
    backgroundColor: SKY,
    width: 12,
    height: 8,
    borderRadius: 4,
  },
  modernCard: {
    padding: 20,
    overflow: 'hidden',
  },
  modernCardEmpty: {
    alignItems: 'center',
  },
  modernCardSelected: {
    borderWidth: 2,
    shadowColor: SKY,
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 8,
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 52,
    height: 52,
    borderRadius: 16,
    marginRight: 14,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconGradient: {
    width: '100%',
    height: '100%',
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    flex: 1,
    minWidth: 0,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    flex: 1,
  },
  cardSubtitle: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
  },
  badgeSmall: {
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
  },
  cardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 8,
  },
  quickHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  quickHintText: {
    fontSize: 11,
    fontWeight: '600',
  },
  infoIconBtn: {
    padding: 6,
    borderRadius: 10,
  },
  ctaDivider: {
    height: 1,
    marginTop: 14,
    marginBottom: 12,
    borderRadius: 1,
  },
  ctaButton: {
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 20,
    gap: 8,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  cardWrapper: {
    marginRight: 12,
  },
  emptyContent: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginTop: 14,
    marginBottom: 4,
  },
  emptySubtext: {
    color: '#94A3B8',
    fontSize: 13,
    textAlign: 'center',
    marginBottom: 16,
  },
  loadingContainer: {
    paddingVertical: 40,
    paddingHorizontal: 20,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  addButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginTop: 16,
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
    gap: 8,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  carPhotoBox: {
    width: 56,
    height: 56,
    borderRadius: 14,
    overflow: 'hidden',
    marginLeft: 10,
  },
  carPhotoTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  carPhotoSmall: {
    width: 56,
    height: 56,
  },
  carPhotoPlaceholder: {
    width: 56,
    height: 56,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  washTypeRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 12,
  },
  washTypePillClean: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.3)',
  },
  washTypePillTextClean: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  serviceCardRight: {
    alignItems: 'flex-end',
    gap: 6,
  },
  servicePriceClean: {
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  serviceIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedCheck: {
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoIconBtn: {
    padding: 4,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 8,
    letterSpacing: -0.2,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  statPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(148,163,184,0.15)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  statText: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  servicePrice: {
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  serviceBadgeBox: {
    width: 64,
    height: 64,
    marginLeft: 12,
  },
  serviceBadgeTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  washTypeSection: {
    marginTop: 4,
    gap: 12,
  },
  washTypeTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  washTypeOptions: {
    flexDirection: 'row',
    gap: 12,
  },
  washTypePill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  washTypePillSelected: {
    borderColor: SKY,
    backgroundColor: SKY + '20',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  washTypePillText: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 15,
    fontWeight: '700',
  },
  continueBtn: {
    height: 54,
    borderRadius: 16,
    overflow: 'hidden',
    marginTop: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 12,
    width: '100%',
  },
  continueBtnGradient: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingHorizontal: 20,
  },
  continueBtnText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.75)',
    justifyContent: 'center',
    padding: 24,
  },
  modalContent: {
    backgroundColor: '#0F172A',
    borderRadius: 24,
    padding: 24,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 20,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
    marginBottom: 16,
  },
  modalIconWrapper: {
    width: 60,
    height: 60,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  modalTitleContainer: {
    flex: 1,
  },
  modalTitle: {
    color: '#F9FAFB',
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 4,
    letterSpacing: -0.3,
  },
  modalPrice: {
    color: SKY,
    fontSize: 18,
    fontWeight: '700',
  },
  modalDescription: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 15,
    lineHeight: 22,
    marginBottom: 16,
  },
  bulletPointsContainer: {
    gap: 12,
    marginBottom: 20,
  },
  bulletPoint: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
  },
  bulletPointText: {
    color: '#F9FAFB',
    fontSize: 14,
    lineHeight: 20,
    flex: 1,
  },
  modalCloseButton: {
    borderRadius: 16,
    overflow: 'hidden',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    elevation: 8,
  },
  modalCloseButtonGradient: {
    padding: 16,
    alignItems: 'center',
  },
  modalCloseButtonText: {
    color: '#FFFFFF',
    fontWeight: '800',
    fontSize: 16,
    letterSpacing: 0.3,
  },
});