import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import AppHeader from '../../../src/components/shared/AppHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';

const SKY = colors.SKY;

export default function BookingChat() {
  const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
      <AppHeader
        title="Chat"
        subtitle="Message your valeter"
        showBack
        onBack={() => router.back()}
      />
      <View style={styles.content}>
        <GlassCard style={styles.placeholderCard} accountType="customer">
          <Ionicons name="chatbubbles-outline" size={64} color={SKY} style={{ opacity: 0.6 }} />
          <Text style={styles.placeholderTitle}>Chat coming soon</Text>
          <Text style={styles.placeholderText}>
            Message your valeter about your booking. This feature is being built.
          </Text>
          <TouchableOpacity
            onPress={() => router.back()}
            style={styles.backBtn}
            activeOpacity={0.8}
          >
            <LinearGradient
              colors={[SKY, '#0EA5E9']}
              style={styles.backBtnGradient}
            >
              <Ionicons name="arrow-back" size={18} color="#FFFFFF" />
              <Text style={styles.backBtnText}>Back to tracking</Text>
            </LinearGradient>
          </TouchableOpacity>
        </GlassCard>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1, padding: 20, justifyContent: 'center' },
  placeholderCard: {
    padding: 32,
    alignItems: 'center',
  },
  placeholderTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginTop: 16,
    marginBottom: 8,
  },
  placeholderText: {
    color: '#94A3B8',
    fontSize: 14,
    textAlign: 'center',
    marginBottom: 24,
  },
  backBtn: {
    borderRadius: 14,
    overflow: 'hidden',
  },
  backBtnGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 8,
  },
  backBtnText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },
});
