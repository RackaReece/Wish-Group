import React, { useRef, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  Dimensions,
  Animated,
  Alert,
  ScrollView,
  Image,
  TouchableOpacity,
  Modal,
  Pressable,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import AppHeader from '../../../src/components/shared/AppHeader';
import GlassCard from '../../../src/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const PREMIUM_PURPLE = colors.PREMIUM_PURPLE;
const CARD_WIDTH = width - 48;

type DbBookingStatus = 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
const ACTIVE_STATUSES: DbBookingStatus[] = ['scheduled', 'in_progress'];

const washTypes = [
  {
    id: 'valeter',
    title: 'On-Demand Valeter',
    subtitle: 'Valeter comes to you',
    description: 'A vetted professional valeter will come to your location with live tracking and real-time updates.',
    eta: '10–25 mins',
    trustLine: 'Vetted professionals',
    icon: 'car-sport',
    gradient: [SKY, '#60A5FA', '#3B82F6'],
    borderColor: 'rgba(135,206,235,0.4)',
    iconColor: SKY,
    route: '/owner/booking/create',
    features: ['Live GPS tracking', 'Pay after acceptance', 'Home or office', 'Real-time updates'],
    badge: 'FASTEST',
  },
  {
    id: 'physical',
    title: 'Wash Hub',
    subtitle: 'Book a time slot',
    description: 'Visit a verified car wash location near you. Book your preferred date and time slot in advance.',
    nextSlot: 'Available today',
    trustLine: 'Verified locations',
    icon: 'business',
    gradient: ['#60A5FA', '#3B82F6', '#2563EB'],
    borderColor: 'rgba(59,130,246,0.4)',
    iconColor: '#60A5FA',
    route: '/owner/booking/physical/vehicle',
    features: ['Certified locations', 'Flexible scheduling', 'Nearby errands', 'Time slots'],
    badge: 'FLEXIBLE',
  },
] as const;

const detailingTypes = [
  {
    id: 'valeter',
    title: 'On-Demand Detailer',
    subtitle: 'Premium detailer to you',
    description: 'A premium detailer will come to your location with professional-grade equipment and live tracking.',
    eta: '15–30 mins',
    trustLine: 'Premium professionals',
    icon: 'diamond',
    gradient: [PREMIUM_PURPLE, '#7C3AED', '#6D28D9'],
    borderColor: 'rgba(139,92,246,0.4)',
    iconColor: PREMIUM_PURPLE,
    route: '/owner/booking/detailing/create',
    features: ['Live GPS tracking', 'Premium equipment', 'Home or office', 'Real-time updates'],
    badge: 'PREMIUM',
  },
  {
    id: 'physical',
    title: 'Detail Hub',
    subtitle: 'Book a time slot',
    description: 'Visit a premium detailing facility near you. Book your preferred date and time slot in advance.',
    nextSlot: 'Available today',
    trustLine: 'Premium facilities',
    icon: 'business',
    gradient: [PREMIUM_PURPLE, '#7C3AED', '#6D28D9'],
    borderColor: 'rgba(139,92,246,0.4)',
    iconColor: PREMIUM_PURPLE,
    route: '/owner/booking/detailing/physical',
    features: ['Premium facilities', 'Flexible scheduling', 'Professional setup', 'Time slots'],
    badge: 'PREMIUM',
  },
] as const;

type ActiveBooking = { id: string; status: DbBookingStatus };

export default function WashTypeSelection() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams();

  const [serviceType, setServiceType] = useState<'wash' | 'detailing'>(
    (params.serviceType as 'wash' | 'detailing') || 'wash'
  );

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;
  const cardScaleAnim = useRef(new Animated.Value(1)).current;

  const [activeBooking, setActiveBooking] = useState<ActiveBooking | null>(null);
  const [checkingActive, setCheckingActive] = useState(false);
  const [valeterCount, setValeterCount] = useState<number>(0);
  const [nextSlotText, setNextSlotText] = useState<string>('Available today');
  const [infoModalOption, setInfoModalOption] = useState<typeof washTypes[number] | typeof detailingTypes[number] | null>(null);

  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);

  const calculateNextSlot = () => {
    const now = new Date();
    const currentHour = now.getHours();
    if (currentHour < 17) {
      setNextSlotText('Available today');
    } else {
      setNextSlotText('Available tomorrow');
    }
  };

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, friction: 8, tension: 60, useNativeDriver: true }),
    ]).start();
    calculateNextSlot();
  }, []);

  useEffect(() => {
    if (params.serviceType === 'detailing' || params.serviceType === 'wash') {
      setServiceType(params.serviceType as 'wash' | 'detailing');
    }
  }, [params.serviceType]);

  useEffect(() => {
    (async () => {
      try {
        const { status } = await Location.requestForegroundPermissionsAsync();
        if (status !== 'granted') return;

        const location = await Location.getCurrentPositionAsync({
          accuracy: Location.Accuracy.Balanced,
        });

        const coords = {
          latitude: location.coords.latitude,
          longitude: location.coords.longitude,
        };

        setUserLocation(coords);
        setRegion({
          latitude: coords.latitude,
          longitude: coords.longitude,
          latitudeDelta: 0.01,
          longitudeDelta: 0.01,
        });

        await loadNearbyValetersCount(coords.latitude, coords.longitude);
      } catch (error) {
        console.warn('Error getting location:', error);
      }
    })();
  }, []);

  const loadNearbyValetersCount = async (latitude: number, longitude: number) => {
    try {
      const { data: presenceData, error } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng')
        .eq('is_online', true);

      if (error) {
        console.warn('Error loading valeters:', error);
        return;
      }

      if (!presenceData || presenceData.length === 0) {
        setValeterCount(0);
        return;
      }

      const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
        const R = 3959;
        const dLat = ((lat2 - lat1) * Math.PI) / 180;
        const dLon = ((lon2 - lon1) * Math.PI) / 180;
        const a =
          Math.sin(dLat / 2) * Math.sin(dLat / 2) +
          Math.cos((lat1 * Math.PI) / 180) *
            Math.cos((lat2 * Math.PI) / 180) *
            Math.sin(dLon / 2) *
            Math.sin(dLon / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
      };

      const nearbyValeters = presenceData.filter((presence) => {
        if (!presence.last_lat || !presence.last_lng) return false;
        const distance = calculateDistance(latitude, longitude, presence.last_lat, presence.last_lng);
        return distance <= 10;
      });

      setValeterCount(nearbyValeters.length);
    } catch (error) {
      console.warn('Error counting valeters:', error);
    }
  };

  const loadActiveBooking = async () => {
    if (!user?.id) return;
    try {
      setCheckingActive(true);
      const { data, error } = await supabase
        .from('bookings')
        .select('id,status')
        .eq('user_id', user.id)
        .in('status', ACTIVE_STATUSES as any)
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        console.warn('[WashTypeSelection] loadActiveBooking error:', error);
        setActiveBooking(null);
        return;
      }

      if (!data) {
        setActiveBooking(null);
        return;
      }

      setActiveBooking({ id: data.id, status: data.status as DbBookingStatus });
    } catch (e) {
      console.warn('[WashTypeSelection] loadActiveBooking exception:', e);
      setActiveBooking(null);
    } finally {
      setCheckingActive(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;
    loadActiveBooking();

    const channel = supabase
      .channel(`wash-type-active-booking-${user.id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        () => loadActiveBooking()
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        (payload) => {
          const updated = payload.new as any;
          const status = updated?.status as DbBookingStatus | undefined;
          if (!updated?.id || !status) {
            loadActiveBooking();
            return;
          }
          if (ACTIVE_STATUSES.includes(status)) {
            setActiveBooking({ id: updated.id, status });
          } else if (activeBooking?.id === updated.id) {
            setActiveBooking(null);
          } else {
            loadActiveBooking();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, activeBooking?.id]);

  const goToActiveBooking = () => {
    if (!activeBooking?.id) return;
    router.push({
      pathname: '/owner/booking/tracking',
      params: { bookingId: activeBooking.id },
    } as any);
  };

  const handleSelect = async (option: (typeof washTypes)[number] | (typeof detailingTypes)[number]) => {
    if (checkingActive) return;

    if (activeBooking?.id) {
      Alert.alert(
        'Active booking in progress',
        'You already have an active booking. Want to go back to tracking it?',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'View booking', onPress: goToActiveBooking },
        ]
      );
      return;
    }

    await hapticFeedback('medium');
    
    // Animate card press
    Animated.sequence([
      Animated.timing(cardScaleAnim, { toValue: 0.95, duration: 100, useNativeDriver: true }),
      Animated.timing(cardScaleAnim, { toValue: 1, duration: 100, useNativeDriver: true }),
    ]).start();

    router.push(option.route as any);
  };

  const currentTypes = serviceType === 'wash' ? washTypes : detailingTypes;
  const primaryColor = serviceType === 'detailing' ? PREMIUM_PURPLE : SKY;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation={false}
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={[
            { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
            { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
            { elementType: 'water', stylers: [{ color: '#17263c' }] },
          ]}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
<View style={styles.userMarkerContainer}>
                <Image
                  source={require('../../../assets/car.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Header */}
      <AppHeader 
        title="Book a Service" 
        subtitle={serviceType === 'wash' ? "Choose your wash type" : "Choose your detailing service"} 
        showBack={false}
        primaryColor={primaryColor}
        rightAction={
          <View style={[styles.segmentedControl, { borderColor: primaryColor + '50' }]}>
            <TouchableOpacity
              style={[styles.segmentedOption, serviceType === 'wash' && { backgroundColor: primaryColor }]}
              onPress={async () => {
                if (serviceType === 'detailing') {
                  await hapticFeedback('light');
                  setServiceType('wash');
                }
              }}
              activeOpacity={0.8}
            >
              <Ionicons name="water" size={16} color={serviceType === 'wash' ? '#FFFFFF' : primaryColor} />
              <Text style={[styles.segmentedLabel, { color: serviceType === 'wash' ? '#FFFFFF' : primaryColor }]}>Wash</Text>
            </TouchableOpacity>
            <TouchableOpacity
              style={[styles.segmentedOption, serviceType === 'detailing' && { backgroundColor: primaryColor }]}
              onPress={async () => {
                if (serviceType === 'wash') {
                  await hapticFeedback('light');
                  setServiceType('detailing');
                }
              }}
              activeOpacity={0.8}
            >
              <Ionicons name="diamond" size={16} color={serviceType === 'detailing' ? '#FFFFFF' : primaryColor} />
              <Text style={[styles.segmentedLabel, { color: serviceType === 'detailing' ? '#FFFFFF' : primaryColor }]}>Detail</Text>
            </TouchableOpacity>
          </View>
        }
      />

      {/* Valeter count badge */}
      <Animated.View
        style={[
          styles.valeterCountBadge,
          {
            opacity: fadeAnim,
            top: insets.top + 92,
          },
        ]}
      >
        <View style={[styles.valeterBadgeCard, { backgroundColor: primaryColor + '18', borderColor: primaryColor + '35' }]}>
          <View style={[styles.valeterBadgeIcon, { backgroundColor: primaryColor + '30' }]}>
            <Ionicons name="car-sport" size={16} color={primaryColor} />
          </View>
          <View style={styles.valeterCountContent}>
            <Text style={[styles.valeterCountNum, { color: primaryColor }]}>{valeterCount}</Text>
            <Text style={styles.valeterCountLabel}>nearby</Text>
          </View>
        </View>
      </Animated.View>

      {/* Modern floating cards */}
      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            paddingBottom: Math.max(insets.bottom, 14) + 14 + TAB_BAR_TOTAL_HEIGHT + 12,
          },
        ]}
      >
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.cardsScrollContent}
          snapToInterval={CARD_WIDTH + 12}
          decelerationRate="fast"
          snapToAlignment="start"
        >
          {currentTypes.map((option) => {
            const isValeter = option.id === 'valeter';

            return (
              <Animated.View
                key={option.id}
                style={[
                  styles.cardWrapper,
                  { width: CARD_WIDTH },
                  { transform: [{ scale: cardScaleAnim }] },
                ]}
              >
                <TouchableOpacity
                  onPress={() => handleSelect(option)}
                  activeOpacity={0.95}
                  disabled={checkingActive}
                >
                  <GlassCard
                    style={styles.modernCard}
                    borderRadius={20}
                    accountType="customer"
                    intensity={35}
                  >
                    {/* Subtle gradient overlay */}
                    <LinearGradient
                      colors={[...option.gradient.map((c) => c + '12'), 'transparent']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 1 }}
                      style={StyleSheet.absoluteFill}
                      pointerEvents="none"
                    />
                    <View style={styles.cardInner}>
                      <View style={styles.cardTop}>
                        <View style={[styles.iconWrap, { backgroundColor: primaryColor + '25', borderColor: primaryColor + '40' }]}>
                          <LinearGradient
                            colors={option.gradient}
                            start={{ x: 0, y: 0 }}
                            end={{ x: 1, y: 1 }}
                            style={styles.iconGradient}
                          >
                            <Ionicons name={option.icon as any} size={30} color="#FFFFFF" />
                          </LinearGradient>
                        </View>
                        <View style={styles.cardContent}>
                          <View style={styles.titleRow}>
                            <Text style={styles.cardTitle} numberOfLines={1}>{option.title}</Text>
                            <TouchableOpacity
                              onPress={() => {
                                hapticFeedback('light');
                                setInfoModalOption(option);
                              }}
                              hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                              style={[styles.infoIconBtn, { backgroundColor: primaryColor + '15' }]}
                            >
                              <Ionicons name="information-circle-outline" size={20} color={primaryColor} />
                            </TouchableOpacity>
                          </View>
                          <Text style={styles.cardSubtitle} numberOfLines={1}>{option.subtitle}</Text>
                          <View style={styles.cardMetaRow}>
                            <View style={[styles.badgeSmall, { backgroundColor: primaryColor + '25', borderColor: primaryColor + '40' }]}>
                              <Text style={[styles.badgeSmallText, { color: primaryColor }]}>{option.badge}</Text>
                            </View>
                            {isValeter && option.eta && (
                              <View style={[styles.quickHint, { backgroundColor: primaryColor + '15' }]}>
                                <Ionicons name="time-outline" size={11} color={primaryColor} />
                                <Text style={[styles.quickHintText, { color: primaryColor }]}>{option.eta}</Text>
                              </View>
                            )}
                            {!isValeter && (
                              <View style={[styles.quickHint, { backgroundColor: primaryColor + '15' }]}>
                                <Ionicons name="calendar-outline" size={11} color={primaryColor} />
                                <Text style={[styles.quickHintText, { color: primaryColor }]}>{nextSlotText}</Text>
                              </View>
                            )}
                          </View>
                        </View>
                      </View>
                      <View style={[styles.ctaDivider, { backgroundColor: primaryColor + '20' }]} />
                      <TouchableOpacity
                        onPress={() => handleSelect(option)}
                        activeOpacity={0.9}
                        style={styles.ctaButton}
                        disabled={checkingActive}
                      >
                        <LinearGradient
                          colors={option.gradient}
                          start={{ x: 0, y: 0 }}
                          end={{ x: 1, y: 0 }}
                          style={styles.ctaGradient}
                        >
                          <Text style={styles.ctaText}>Choose {option.title}</Text>
                          <Ionicons name="arrow-forward" size={18} color="#FFFFFF" />
                        </LinearGradient>
                      </TouchableOpacity>
                    </View>
                  </GlassCard>
                </TouchableOpacity>
              </Animated.View>
            );
          })}
        </ScrollView>

        {/* Info popup overlay */}
        <Modal
          visible={!!infoModalOption}
          transparent
          animationType="fade"
          onRequestClose={() => setInfoModalOption(null)}
        >
          <Pressable
            style={styles.modalOverlay}
            onPress={() => setInfoModalOption(null)}
          >
            <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
              {infoModalOption && (
                <>
                  <View style={styles.modalHeader}>
                    <Text style={[styles.modalTitle, { color: primaryColor }]}>{infoModalOption.title}</Text>
                    <TouchableOpacity
                      onPress={() => setInfoModalOption(null)}
                      hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                    >
                      <Ionicons name="close" size={24} color="#94A3B8" />
                    </TouchableOpacity>
                  </View>
                  <Text style={styles.modalSubtitle}>{infoModalOption.subtitle}</Text>
                  <Text style={styles.modalDesc}>{infoModalOption.description}</Text>
                  <View style={styles.modalStatusRow}>
                    {infoModalOption.id === 'valeter' && infoModalOption.eta && (
                      <View style={[styles.modalBadge, { backgroundColor: primaryColor + '20' }]}>
                        <Ionicons name="time" size={14} color={primaryColor} />
                        <Text style={[styles.modalBadgeText, { color: primaryColor }]}>{infoModalOption.eta}</Text>
                      </View>
                    )}
                    {infoModalOption.id !== 'valeter' && (
                      <View style={[styles.modalBadge, { backgroundColor: primaryColor + '20' }]}>
                        <Ionicons name="calendar" size={14} color={primaryColor} />
                        <Text style={[styles.modalBadgeText, { color: primaryColor }]}>{nextSlotText}</Text>
                      </View>
                    )}
                    <View style={[styles.modalTrustBadge, { backgroundColor: '#10B98120' }]}>
                      <Ionicons name="shield-checkmark" size={12} color="#10B981" />
                      <Text style={styles.modalTrustText}>{infoModalOption.trustLine}</Text>
                    </View>
                  </View>
                  <View style={styles.modalFeatures}>
                    <Text style={styles.modalSectionTitle}>Includes</Text>
                    {infoModalOption.features.map((f, idx) => (
                      <View key={idx} style={styles.modalFeatureRow}>
                        <View style={[styles.modalFeatureDot, { backgroundColor: primaryColor }]} />
                        <Text style={styles.modalFeatureText}>{f}</Text>
                      </View>
                    ))}
                  </View>
                  <TouchableOpacity
                    onPress={() => setInfoModalOption(null)}
                    style={[styles.modalDone, { backgroundColor: primaryColor }]}
                    activeOpacity={0.9}
                  >
                    <Text style={styles.modalDoneText}>Close</Text>
                  </TouchableOpacity>
                </>
              )}
            </Pressable>
          </Pressable>
        </Modal>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  valeterCountBadge: {
    position: 'absolute',
    right: 16,
    zIndex: 1000,
  },
  valeterBadgeCard: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 14,
    borderWidth: 1,
  },
  valeterBadgeIcon: {
    width: 32,
    height: 32,
    borderRadius: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  valeterCountContent: {
    alignItems: 'flex-start',
  },
  valeterCountNum: {
    fontSize: 18,
    fontWeight: '800',
    lineHeight: 20,
  },
  valeterCountLabel: {
    fontSize: 11,
    color: '#94A3B8',
    fontWeight: '600',
  },
  segmentedControl: {
    flexDirection: 'row',
    borderRadius: 12,
    borderWidth: 1,
    padding: 3,
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  segmentedOption: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 10,
    minWidth: 72,
    justifyContent: 'center',
  },
  segmentedLabel: {
    fontSize: 13,
    fontWeight: '700',
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  cardWrapper: {
    marginRight: 12,
  },
  modernCard: {
    padding: 20,
    backgroundColor: 'transparent',
    borderRadius: 20,
    overflow: 'hidden',
  },
  cardInner: {},
  cardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 52,
    height: 52,
    borderRadius: 16,
    overflow: 'hidden',
    marginRight: 14,
    borderWidth: 1,
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
  },
  iconGradient: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    flex: 1,
    minWidth: 0,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    flex: 1,
  },
  infoIconBtn: {
    padding: 6,
    borderRadius: 10,
  },
  cardSubtitle: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
    marginBottom: 10,
  },
  cardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
  },
  badgeSmall: {
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
  },
  badgeSmallText: {
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  quickHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 8,
  },
  quickHintText: {
    fontSize: 11,
    fontWeight: '600',
  },
  ctaDivider: {
    height: 1,
    marginTop: 14,
    marginBottom: 12,
    borderRadius: 1,
  },
  ctaButton: {
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 20,
    gap: 8,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
  },
  // Info modal
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalContent: {
    width: '100%',
    maxWidth: 340,
    maxHeight: '85%',
    backgroundColor: '#1E293B',
    borderRadius: 20,
    padding: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  modalTitle: {
    fontSize: 20,
    fontWeight: '800',
  },
  modalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    marginBottom: 12,
  },
  modalDesc: {
    color: 'rgba(229,231,235,0.9)',
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 16,
  },
  modalStatusRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 16,
  },
  modalBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  modalBadgeText: {
    fontSize: 12,
    fontWeight: '700',
  },
  modalTrustBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  modalTrustText: {
    color: '#10B981',
    fontSize: 12,
    fontWeight: '700',
  },
  modalSectionTitle: {
    color: '#F9FAFB',
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 10,
  },
  modalFeatures: {
    marginBottom: 20,
  },
  modalFeatureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 8,
  },
  modalFeatureDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  modalFeatureText: {
    color: 'rgba(229,231,235,0.9)',
    fontSize: 13,
    flex: 1,
  },
  modalDone: {
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  modalDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
});
