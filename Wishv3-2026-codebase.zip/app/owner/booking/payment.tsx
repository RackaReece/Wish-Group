import React, { useState, useEffect, useRef, useMemo } from "react";
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Platform,
  Image,
  StatusBar,
} from "react-native";
import { LinearGradient } from "expo-linear-gradient";
import { Ionicons } from "@expo/vector-icons";
import { router, useLocalSearchParams } from "expo-router";
import { useAuth } from "../../../src/providers/enhanced-auth-context";
import { supabase } from "../../../src/lib/supabase";
import { hapticFeedback } from "../../../src/services/HapticFeedbackService";
import GlassCard from "../../../src/components/booking/GlassCard";
import CountdownTimer from "../../../src/components/booking/CountdownTimer";
import { getServiceDisplayName } from "../../../src/utils/serviceNameMapper";
import { customerTheme } from "../../../src/constants/customerTheme";
import { colors } from "../../../src/constants/colors";
import LoadingScreen from "../../../src/components/LoadingScreen";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import MapView, { Region, Marker } from "react-native-maps";
import AppHeader, { HEADER_CONTENT_OFFSET } from "../../../src/components/shared/AppHeader";
import * as Location from "expo-location";
import useLiveLocation from "../../../src/hooks/useLiveLocation";
import SuccessOverlay from "../../../src/components/booking/SuccessOverlay";

// Stripe (native only)
let useStripe: any = null;
if (Platform.OS !== "web") {
  try {
    const stripe = require("@stripe/stripe-react-native");
    useStripe = stripe.useStripe;
  } catch (e) {
    console.warn("Stripe not available:", e);
    useStripe = null;
  }
}

import { BOOKING_CARD } from "../../../src/constants/bookingCardTheme";

const { width } = Dimensions.get("window");
const SKY = colors.SKY;
const CARD_WIDTH = BOOKING_CARD.CARD_WIDTH;

type PrepState = "idle" | "preparing" | "ready" | "error";

function asStringParam(v: unknown): string | null {
  if (!v) return null;
  if (Array.isArray(v)) return typeof v[0] === "string" ? v[0] : null;
  return typeof v === "string" ? v : null;
}

function moneyGBP(value: any) {
  const n = Number(value);
  if (!Number.isFinite(n)) return "0.00";
  return n.toFixed(2);
}

export default function BookingPayment() {
  const { user } = useAuth();
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams();

  // ✅ handles string | string[] | undefined
  const bookingId = useMemo(() => asStringParam((params as any)?.bookingId), [params]);

  const stripeHook = useStripe ? useStripe() : null;
  const initPaymentSheet = stripeHook?.initPaymentSheet;
  const presentPaymentSheet = stripeHook?.presentPaymentSheet;

  const [booking, setBooking] = useState<any | null>(null);
  const [loadingBooking, setLoadingBooking] = useState(false);

  const [processing, setProcessing] = useState(false);
  const [countdown] = useState(600);
  const [showSuccessOverlay, setShowSuccessOverlay] = useState(false);

  const [clientSecret, setClientSecret] = useState<string | null>(null);
  const [prepState, setPrepState] = useState<PrepState>("idle");
  const [lastError, setLastError] = useState<string | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.01,
    longitudeDelta: 0.01,
  });

  const { coords } = useLiveLocation();
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const cardAnim = useRef(new Animated.Value(0)).current;

  const sheetReady = prepState === "ready";

  useEffect(() => {
    if (coords) {
      setUserLocation(coords);
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    } else {
      getCurrentLocation();
    }
  }, [coords]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== "granted") return;
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };
      setUserLocation(coords);
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.01,
        longitudeDelta: 0.01,
      });
    } catch {}
  };

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(cardAnim, { toValue: 1, tension: 50, friction: 8, useNativeDriver: true }),
    ]).start();
  }, []);

  useEffect(() => {
    if (!bookingId) return;
    loadBooking();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [bookingId]);

  useEffect(() => {
    // Auto-prepare once booking is loaded
    if (booking?.id && user?.id && Platform.OS !== "web") {
      preparePaymentSheet();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [booking?.id, user?.id]);

  const loadBooking = async () => {
    if (!bookingId) return;

    try {
      setLoadingBooking(true);
      setLastError(null);

      const { data, error } = await supabase
        .from("bookings")
        .select("*")
        .eq("id", bookingId)
        .single();

      if (error) throw error;
      setBooking(data);
    } catch (e: any) {
      console.error("Error loading booking:", e);
      setBooking(null);
      setPrepState("error");
      setLastError(
        e?.message ||
          "Couldn’t load booking. If this is your booking, check RLS policies allow the customer to select it."
      );
    } finally {
      setLoadingBooking(false);
    }
  };

  const extractClientSecret = (data: any): string | null => {
    return (
      data?.clientSecret ??
      data?.client_secret ??
      data?.paymentIntentClientSecret ??
      data?.payment_intent_client_secret ??
      data?.paymentIntent?.clientSecret ??
      data?.paymentIntent?.client_secret ??
      data?.payment_intent?.client_secret ??
      null
    );
  };

  const preparePaymentSheet = async () => {
    if (Platform.OS === "web") return;
    if (!booking || !user?.id || !bookingId) return;

    if (!initPaymentSheet || !presentPaymentSheet) {
      const msg =
        "Stripe not initialised. Check StripeProvider is mounted at the app root, and that @stripe/stripe-react-native is installed correctly.";
      console.error("[Payment] Stripe hook missing:", { initPaymentSheet, presentPaymentSheet });
      setLastError(msg);
      setPrepState("error");
      return;
    }

    setPrepState("preparing");
    setLastError(null);
    setClientSecret(null);

    const priceNumber = Number(booking.price);
    const amountPence = Math.round((Number.isFinite(priceNumber) ? priceNumber : 0) * 100);

    console.log("[Payment] preparing", {
      bookingId,
      price: booking.price,
      amountPence,
      platform: Platform.OS,
    });

    if (!amountPence || Number.isNaN(amountPence) || amountPence < 50) {
      const msg = `Invalid amount: ${amountPence}. Check booking.price is a number in pounds (e.g. 12.99).`;
      console.error("[Payment]", msg, booking?.price);
      setLastError(msg);
      setPrepState("error");
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke("hyper-endpoint", {
        body: {
          bookingId,
          amount: amountPence,
          currency: "gbp",
          customerId: user.id,
          description: `Wish a Wash booking ${bookingId}`,
        },
      });

      console.log("[Payment] edge response", { data, error });

      if (error) {
        const msg = error?.message || "Edge function failed creating payment intent.";
        console.error("[Payment] Edge function error:", error);
        setLastError(msg);
        setPrepState("error");
        return;
      }

      const cs = extractClientSecret(data);
      if (!cs) {
        const msg =
          "No client secret returned. Your edge function response shape likely differs. Check logs for data keys.";
        console.error("[Payment] Missing client secret. Data:", data);
        setLastError(msg);
        setPrepState("error");
        return;
      }

      setClientSecret(cs);

      const { error: sheetError } = await initPaymentSheet({
        paymentIntentClientSecret: cs,
        merchantDisplayName: "Wish a Wash",
        returnURL: "waw://stripe-redirect",
        style: "automatic",
      });

      console.log("[Payment] initPaymentSheet result", sheetError);

      if (sheetError) {
        const msg = sheetError.message || "initPaymentSheet failed.";
        console.error("[Payment] initPaymentSheet error:", sheetError);
        setLastError(msg);
        setPrepState("error");
        return;
      }

      setPrepState("ready");
    } catch (e: any) {
      const msg = e?.message || "Unexpected error preparing payment.";
      console.error("[Payment] preparePaymentSheet exception:", e);
      setLastError(msg);
      setPrepState("error");
    }
  };

  const markBookingPaid = async () => {
    if (!bookingId) return;

    const { error } = await supabase
      .from("bookings")
      .update({
        status: "confirmed",
        payment_completed_at: new Date().toISOString(),
      })
      .eq("id", bookingId);

    if (error) throw error;
  };

  const handlePayment = async () => {
    if (!bookingId) {
      Alert.alert("Missing booking", "No bookingId was passed to payment screen.");
      return;
    }
    if (!booking || !user?.id) return;
    if (processing) return;

    if (Platform.OS === "web") {
      Alert.alert("Not supported", "This payment flow is native-only.");
      return;
    }

    if (!presentPaymentSheet) {
      Alert.alert("Stripe not ready", "Stripe is not initialised in the app.");
      return;
    }

    if (!sheetReady || !clientSecret) {
      const msg =
        lastError ||
        (prepState === "preparing" ? "Payment is still preparing…" : "Payment isn’t ready. Tap Retry.");
      Alert.alert("Hold up", msg);
      return;
    }

    setProcessing(true);
    await hapticFeedback("medium");

    try {
      console.log("[Payment] presenting sheet…");
      const { error } = await presentPaymentSheet();
      console.log("[Payment] presentPaymentSheet result:", error);

      if (error) {
        if (error.code === "Canceled") {
          setProcessing(false);
          return;
        }
        throw error;
      }

      await markBookingPaid();

      // Show success overlay with confetti
      setShowSuccessOverlay(true);
      
      setTimeout(() => {
        router.replace({
          pathname: "/owner/booking/tracking",
          params: { bookingId },
        });
      }, 2500);
    } catch (e: any) {
      console.error("[Payment] failed:", e);
      Alert.alert("Payment Failed", e?.message || "Please try again.");
    } finally {
      setProcessing(false);
    }
  };

  const handleCountdownComplete = () => {
    Alert.alert("Payment Timeout", "The payment window has expired. Please try again.", [
      { text: "OK", onPress: () => router.back() },
    ]);
  };

  // ✅ explicit missing bookingId UI (this is the real “missing booking info” case)
  if (!bookingId) {
    return (
      <SafeAreaView style={[styles.container, { justifyContent: "center", alignItems: "center", padding: 20 }]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <Text style={{ color: "#fff", fontWeight: "800", fontSize: 16, textAlign: "center" }}>
          Missing bookingId
        </Text>
        <Text style={{ color: "rgba(255,255,255,0.75)", marginTop: 8, textAlign: "center" }}>
          Payment screen was opened without a booking reference.
        </Text>
        <TouchableOpacity
          onPress={() => router.back()}
          style={{ marginTop: 14, paddingVertical: 10, paddingHorizontal: 14, borderRadius: 10, borderWidth: 1, borderColor: "rgba(135,206,235,0.35)" }}
        >
          <Text style={{ color: SKY, fontWeight: "800" }}>Go back</Text>
        </TouchableOpacity>
      </SafeAreaView>
    );
  }

  if (loadingBooking && !booking) return <LoadingScreen />;

  // ✅ booking failed to load UI
  if (!booking) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader title="Payment" />
        <View style={{ padding: 20, paddingTop: HEADER_CONTENT_OFFSET + 20 }}>
          <GlassCard style={{ padding: 18 }} accountType="customer">
            <Text style={{ color: "#F9FAFB", fontSize: 16, fontWeight: "900" }}>Couldn’t load booking</Text>
            <Text style={{ color: "rgba(249,250,251,0.8)", marginTop: 8, lineHeight: 18 }}>
              {lastError || "Unknown error."}
            </Text>

            <View style={{ flexDirection: "row", gap: 10, marginTop: 14 }}>
              <TouchableOpacity
                onPress={loadBooking}
                style={{ flex: 1, paddingVertical: 12, borderRadius: 12, borderWidth: 1, borderColor: "rgba(135,206,235,0.35)", alignItems: "center" }}
              >
                <Text style={{ color: SKY, fontWeight: "900" }}>Retry</Text>
              </TouchableOpacity>

              <TouchableOpacity
                onPress={() => router.back()}
                style={{ flex: 1, paddingVertical: 12, borderRadius: 12, borderWidth: 1, borderColor: "rgba(255,255,255,0.12)", alignItems: "center" }}
              >
                <Text style={{ color: "#F9FAFB", fontWeight: "900" }}>Back</Text>
              </TouchableOpacity>
            </View>
          </GlassCard>
        </View>
      </SafeAreaView>
    );
  }

  const statusText =
    prepState === "ready"
      ? "Payment ready"
      : prepState === "preparing"
      ? "Preparing payment…"
      : prepState === "error"
      ? "Payment setup failed"
      : "Tap Retry to prepare";

  const totalDisplay = moneyGBP(booking.price);

  // Custom map style to blur/hide labels for privacy
  const mapStyle = [
    {
      featureType: "all",
      elementType: "labels",
      stylers: [{ visibility: "off" }],
    },
    {
      featureType: "poi",
      elementType: "labels",
      stylers: [{ visibility: "off" }],
    },
    {
      featureType: "road",
      elementType: "labels",
      stylers: [{ visibility: "off" }],
    },
    {
      featureType: "transit",
      elementType: "labels",
      stylers: [{ visibility: "off" }],
    },
  ];

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <StatusBar hidden={true} />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={mapStyle}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image
                  source={require("../../../assets/car.png")}
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Back button */}
      <View style={[styles.headerContainer, { top: insets.top + 16 }]}>
        <TouchableOpacity
          onPress={() => router.back()}
          style={styles.backButton}
          activeOpacity={0.7}
        >
          <Ionicons name="arrow-back" size={22} color={SKY} />
        </TouchableOpacity>
      </View>

      {/* Payment card - matches Book Your Wash design */}
      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            transform: [{ scale: cardAnim }],
            bottom: 96 + Math.max(insets.bottom, 14),
          },
        ]}
      >
        <View style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
          <GlassCard
            style={styles.paymentCard}
            borderRadius={BOOKING_CARD.BORDER_RADIUS}
            borderColor={sheetReady ? SKY : undefined}
            intensity={BOOKING_CARD.INTENSITY}
            accountType="customer"
          >
            <LinearGradient
              colors={sheetReady ? [SKY + '12', SKY + '06', 'transparent'] : ['transparent', 'transparent']}
              start={{ x: 0, y: 0 }}
              end={{ x: 1, y: 1 }}
              style={StyleSheet.absoluteFill}
              pointerEvents="none"
            />
            <View style={styles.cardContentRow}>
              <View style={styles.cardMain}>
                <View style={styles.cardHeader}>
                  <View style={styles.paymentIconWrap}>
                    <Ionicons name="wallet-outline" size={28} color={SKY} />
                  </View>
                  <View style={styles.statusBadge}>
                    <View
                      style={[styles.dot, { backgroundColor: sheetReady ? "#10B981" : prepState === "error" ? "#EF4444" : SKY, opacity: sheetReady ? 1 : 0.6 }]}
                    />
                    <Text style={styles.statusText}>{statusText}</Text>
                  </View>
                </View>
                <Text style={styles.serviceName}>
                  {getServiceDisplayName(booking.service_type, booking.service_name)}
                </Text>
                <View style={styles.metaRow}>
                  <Ionicons name="location-outline" size={12} color="#94A3B8" />
                  <Text style={styles.metaText} numberOfLines={2}>
                    {booking.location_address || "—"}
                  </Text>
                </View>
                <View style={styles.totalRow}>
                  <Text style={styles.totalLabel}>Total</Text>
                  <Text style={styles.totalValue}>£{totalDisplay}</Text>
                </View>
                {(prepState === "error" || prepState === "idle") && (
                  <TouchableOpacity onPress={preparePaymentSheet} style={styles.retryBtn} activeOpacity={0.85}>
                    <Text style={styles.retryText}>Retry</Text>
                  </TouchableOpacity>
                )}
                {!!lastError && (
                  <Text style={styles.errorText} numberOfLines={2}>{lastError}</Text>
                )}
                <View style={styles.timerRow}>
                  <CountdownTimer seconds={countdown} onComplete={handleCountdownComplete} size="small" variant="integrated" />
                </View>
              </View>
              <View style={styles.paymentInfoBox}>
                <View style={styles.paymentInfoTouch}>
                  <Ionicons name="lock-closed" size={32} color={SKY} />
                  <Text style={styles.secureLabel}>Secure</Text>
                </View>
              </View>
            </View>
          </GlassCard>
        </View>
      </Animated.View>

      <SuccessOverlay
        visible={showSuccessOverlay}
        type="payment"
        message="Payment Successful!"
        onComplete={() => setShowSuccessOverlay(false)}
      />

      {/* CTA - same design as Continue on other screens */}
      <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12 }]}>
        <TouchableOpacity
          onPress={handlePayment}
          disabled={!sheetReady || processing}
          activeOpacity={0.9}
        >
          <LinearGradient
            colors={sheetReady && !processing ? [SKY, "#0EA5E9"] : ["#475569", "#334155"]}
            style={[styles.ctaButton, processing && { opacity: 0.7 }]}
          >
            {processing ? (
              <Text style={styles.ctaText}>Processing…</Text>
            ) : (
              <>
                <Text style={styles.ctaText}>Pay £{totalDisplay}</Text>
                <Ionicons name="lock-closed" size={20} color="#FFFFFF" />
              </>
            )}
          </LinearGradient>
        </TouchableOpacity>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: "transparent" },
  headerContainer: {
    position: "absolute",
    left: 16,
    zIndex: 1000,
  },
  backButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: "rgba(15, 23, 42, 0.6)",
    borderWidth: 1.5,
    borderColor: "rgba(135,206,235,0.3)",
    justifyContent: "center",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  userMarkerContainer: {
    alignItems: "center",
    justifyContent: "center",
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  cardsContainer: {
    position: "absolute",
    left: 0,
    right: 0,
    paddingHorizontal: 16,
  },
  cardWrapper: { width: CARD_WIDTH },
  paymentCard: {
    width: "100%",
    padding: 20,
    borderRadius: 20,
  },
  cardContentRow: {
    flexDirection: "row",
    alignItems: "flex-end",
    justifyContent: "space-between",
  },
  cardMain: { flex: 1, minWidth: 0 },
  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
  },
  paymentIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: "rgba(135,206,235,0.15)",
    justifyContent: "center",
    alignItems: "center",
  },
  statusBadge: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
  },
  dot: { width: 8, height: 8, borderRadius: 4 },
  statusText: { color: "#94A3B8", fontSize: 12, fontWeight: "600" },
  serviceName: {
    color: "#F9FAFB",
    fontSize: 16,
    fontWeight: "800",
    marginBottom: 6,
  },
  metaRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 6,
    marginBottom: 6,
  },
  metaText: {
    color: "#94A3B8",
    fontSize: 13,
    fontWeight: "500",
    flex: 1,
  },
  totalRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: "rgba(135,206,235,0.2)",
  },
  totalLabel: { color: "#F9FAFB", fontSize: 15, fontWeight: "700" },
  totalValue: { color: SKY, fontSize: 20, fontWeight: "800" },
  retryBtn: {
    alignSelf: "flex-start",
    marginTop: 10,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "rgba(135,206,235,0.4)",
  },
  retryText: { color: SKY, fontWeight: "700", fontSize: 14 },
  errorText: {
    color: "#FCA5A5",
    fontSize: 12,
    marginTop: 8,
    lineHeight: 16,
  },
  paymentInfoBox: {
    width: 64,
    height: 64,
    marginLeft: 12,
  },
  paymentInfoTouch: {
    width: "100%",
    height: "100%",
    borderRadius: 12,
    backgroundColor: "rgba(135,206,235,0.1)",
    borderWidth: 1,
    borderColor: "rgba(135,206,235,0.3)",
    justifyContent: "center",
    alignItems: "center",
  },
  secureLabel: {
    color: SKY,
    fontSize: 10,
    fontWeight: "700",
    marginTop: 4,
  },
  timerRow: {
    marginTop: 12,
    marginBottom: 0,
  },
  ctaWrapper: {
    position: "absolute",
    left: 16,
    right: 16,
    bottom: 0,
  },
  ctaButton: {
    borderRadius: 18,
    paddingVertical: 18,
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 10,
  },
  ctaText: {
    color: "#FFFFFF",
    fontSize: 17,
    fontWeight: "900",
  },
});
