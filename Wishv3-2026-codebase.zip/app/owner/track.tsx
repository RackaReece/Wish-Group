import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  ActivityIndicator,
  RefreshControl,
  Modal,
  Pressable,
  Image,
  Platform,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Marker, Region } from 'react-native-maps';
import * as Location from 'expo-location';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { supabase } from '../../src/lib/supabase';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../src/components/shared/AppHeader';
import { useProfilePicture } from '../../src/hooks/useProfilePicture';
import { customerTheme } from '../../src/constants/customerTheme';
import { colors } from '../../src/constants/colors';
import { getServiceDisplayName } from '../../src/utils/serviceNameMapper';
import { TAB_BAR_TOTAL_HEIGHT } from '../components/NavigationTab';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';

const { width, height } = Dimensions.get('window');
const SKY = colors.SKY;
const LIGHT_SKY = colors.LIGHT_SKY;
const CARD_WIDTH = width - 48; // Same as book your wash cards

const ACTIVE_STATUSES = [
  'pending',
  'pending_valeter_acceptance',
  'pending_payment',
  'confirmed',
  'valeter_assigned',
  'en_route',
  'arrived',
  'in_progress',
  'scheduled',
];

type ActiveBooking = {
  id: string;
  status: string;
  service_type: string;
  service_name?: string | null;
  price: number | null;
  location_address?: string | null;
  location_lat?: number | null;
  location_lng?: number | null;
  valeter_id?: string | null;
  location_id?: string | null;
  scheduled_at?: string | null;
  valeter_name?: string | null;
  created_at?: string | null;
};

type ValeterLoc = { [valeterId: string]: { latitude: number; longitude: number } };
type HubLoc = { [locationId: string]: { latitude: number; longitude: number } };

const getStatusColor = (status: string): string => {
  switch (status) {
    case 'en_route':
    case 'arrived':
      return '#10B981';
    case 'in_progress':
      return '#60A5FA';
    case 'valeter_assigned':
    case 'confirmed':
      return '#8B5CF6';
    case 'pending_valeter_acceptance':
    case 'pending':
    case 'pending_payment':
      return '#F59E0B';
    default:
      return SKY;
  }
};

const getStatusLabel = (status: string): string => {
  switch (status) {
    case 'en_route':
      return 'En route';
    case 'arrived':
      return 'Arrived';
    case 'in_progress':
      return 'In progress';
    case 'valeter_assigned':
      return 'Assigned';
    case 'confirmed':
      return 'Confirmed';
    case 'pending_valeter_acceptance':
      return 'Waiting';
    case 'pending':
      return 'Pending';
    case 'pending_payment':
      return 'Pay now';
    case 'scheduled':
      return 'Scheduled';
    default:
      return status.replace(/_/g, ' ').replace(/\b\w/g, (l) => l.toUpperCase());
  }
};

const getCTAText = (status: string): string => {
  switch (status) {
    case 'pending_valeter_acceptance':
    case 'pending':
      return 'View status';
    case 'pending_payment':
      return 'Pay now';
    case 'en_route':
      return 'Track';
    default:
      return 'View trip';
  }
};

const LONDON: Region = {
  latitude: 51.5074,
  longitude: -0.1278,
  latitudeDelta: 0.05,
  longitudeDelta: 0.05,
};

export default function CustomerTrackPage() {
  const { user } = useAuth();
  const profilePicture = useProfilePicture();
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [activeBookings, setActiveBookings] = useState<ActiveBooking[]>([]);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [valeterLocations, setValeterLocations] = useState<ValeterLoc>({});
  const [hubLocations, setHubLocations] = useState<HubLoc>({});
  const [etaMap, setEtaMap] = useState<Record<string, number>>({});
  const [infoModalBooking, setInfoModalBooking] = useState<ActiveBooking | null>(null);
  const [mapRegion, setMapRegion] = useState<Region>(LONDON);
  const presenceChannels = useRef<Record<string, any>>({});

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return null;
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
      setUserLocation(coords);
      return coords;
    } catch {
      return null;
    }
  };

  const calcEta = (
    valeterCoords: { latitude: number; longitude: number },
    userCoords?: { latitude: number; longitude: number } | null
  ) => {
    const u = userCoords ?? userLocation;
    if (!u) return null;
    const R = 3959;
    const dLat = ((valeterCoords.latitude - u.latitude) * Math.PI) / 180;
    const dLon = ((valeterCoords.longitude - u.longitude) * Math.PI) / 180;
    const a =
      Math.sin(dLat / 2) ** 2 +
      Math.cos((u.latitude * Math.PI) / 180) *
        Math.cos((valeterCoords.latitude * Math.PI) / 180) *
        Math.sin(dLon / 2) ** 2;
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    const dist = R * c;
    return Math.round((dist / 25) * 60);
  };

  const loadActiveBookings = async () => {
    if (!user?.id) {
      setLoading(false);
      return;
    }
    try {
      const coords = await getCurrentLocation();
      const { data, error } = await supabase
        .from('bookings')
        .select(
          `id, status, service_type, service_name, price, location_address, location_lat, location_lng, valeter_id, location_id, scheduled_at, valeter_name, created_at`
        )
        .eq('user_id', user.id)
        .in('status', ACTIVE_STATUSES as any)
        .order('created_at', { ascending: false });

      if (error) throw error;
      const bookings = (data || []) as ActiveBooking[];
      setActiveBookings(bookings);

      const vlMap: ValeterLoc = {};
      const hlMap: HubLoc = {};
      const eta: Record<string, number> = {};
      for (const b of bookings) {
        if (b.valeter_id) {
          const vd = (
            await supabase
              .from('valeter_presence')
              .select('last_lat, last_lng')
              .eq('user_id', b.valeter_id)
              .maybeSingle()
          ).data;
          if (vd?.last_lat != null && vd?.last_lng != null) {
            const vc = { latitude: vd.last_lat, longitude: vd.last_lng };
            vlMap[b.valeter_id] = vc;
            if (coords) {
              const e = calcEta(vc, coords);
              if (e != null) eta[b.id] = e;
            }
          }
        }
        if (b.location_id) {
          const hd = (
            await supabase
              .from('car_wash_locations')
              .select('latitude, longitude')
              .eq('id', b.location_id)
              .maybeSingle()
          ).data;
          if (hd?.latitude != null && hd?.longitude != null) {
            hlMap[b.location_id] = { latitude: hd.latitude, longitude: hd.longitude };
          }
        }
      }
      setValeterLocations((prev) => ({ ...prev, ...vlMap }));
      setHubLocations((prev) => ({ ...prev, ...hlMap }));
      setEtaMap((prev) => ({ ...prev, ...eta }));

      if (bookings.length > 0 && coords) {
        const first = bookings[0];
        let other: { latitude: number; longitude: number } | null = null;
        if (first.valeter_id && vlMap[first.valeter_id]) other = vlMap[first.valeter_id];
        else if (first.location_id && hlMap[first.location_id]) other = hlMap[first.location_id];
        else if (first.location_lat != null && first.location_lng != null)
          other = { latitude: first.location_lat, longitude: first.location_lng };
        if (other) {
          setMapRegion({
            latitude: (coords.latitude + other.latitude) / 2,
            longitude: (coords.longitude + other.longitude) / 2,
            latitudeDelta: Math.max(0.02, Math.abs(other.latitude - coords.latitude) * 2.5 || 0.02),
            longitudeDelta: Math.max(0.02, Math.abs(other.longitude - coords.longitude) * 2.5 || 0.02),
          });
        } else {
          setMapRegion({
            ...coords,
            latitudeDelta: 0.03,
            longitudeDelta: 0.03,
          });
        }
      }
    } catch (e) {
      console.error('Error loading active bookings:', e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    loadActiveBookings();
    const channel = supabase
      .channel('customer-track-bookings')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'bookings', filter: `user_id=eq.${user?.id}` },
        () => loadActiveBookings()
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
      Object.values(presenceChannels.current).forEach((ch) => ch && supabase.removeChannel(ch));
    };
  }, [user?.id]);

  useEffect(() => {
    for (const b of activeBookings) {
      if (b.valeter_id && !presenceChannels.current[b.valeter_id]) {
        const ch = supabase
          .channel(`valeter-presence-track-${b.valeter_id}`)
          .on(
            'postgres_changes',
            {
              event: '*',
              schema: 'public',
              table: 'valeter_presence',
              filter: `user_id=eq.${b.valeter_id}`,
            },
            (payload) => {
              const n = payload.new as any;
              if (n?.last_lat != null && n?.last_lng != null) {
                const vc = { latitude: n.last_lat, longitude: n.last_lng };
                setValeterLocations((prev) => ({ ...prev, [b.valeter_id!]: vc }));
                if (userLocation) {
                  const e = calcEta(vc, userLocation);
                  if (e != null) setEtaMap((prev) => ({ ...prev, [b.id]: e }));
                }
              }
            }
          )
          .subscribe();
        presenceChannels.current[b.valeter_id] = ch;
      }
    }
  }, [activeBookings.map((x) => x.valeter_id).join(',')]);

  const handleRefresh = async () => {
    setRefreshing(true);
    await hapticFeedback('light');
    await loadActiveBookings();
  };

  const handleCardPress = async (bookingId: string) => {
    await hapticFeedback('medium');
    router.push(`/owner/booking/tracking?bookingId=${bookingId}` as any);
  };

  const formatCurrency = (n?: number | null) =>
    typeof n === 'number' ? `£${n.toFixed(2).replace(/\.00$/, '')}` : '—';
  const formatDate = (d?: string | null) =>
    d
      ? new Date(d).toLocaleDateString('en-GB', {
          day: 'numeric',
          month: 'short',
          hour: '2-digit',
          minute: '2-digit',
        })
      : '—';

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader
          title="Active Bookings"
          subtitle="Your trips"
          accountType="customer"
          profilePicture={profilePicture}
          onProfilePress={() => router.push('/owner/owner-profile')}
        />
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading your trips…</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Map - full screen */}
      <View style={styles.mapWrapper}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={mapRegion}
          showsUserLocation={false}
          mapType={Platform.OS === 'ios' ? 'mutedStandard' : 'standard'}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.markerWrap}>
                <Image source={require('../../assets/car.png')} style={styles.markerImg} resizeMode="contain" />
              </View>
            </Marker>
          )}
          {activeBookings.map((b) => {
            const vl = b.valeter_id ? valeterLocations[b.valeter_id] : null;
            const hl = b.location_id ? hubLocations[b.location_id] : null;
            const coord =
              vl ||
              hl ||
              (b.location_lat != null && b.location_lng != null
                ? { latitude: b.location_lat, longitude: b.location_lng }
                : null);
            if (!coord) return null;
            return (
              <Marker key={b.id} coordinate={coord}>
                <View style={styles.bookingMarkerWrap}>
                  <Image
                    source={
                      b.service_type?.includes('detailing')
                        ? require('../../assets/detailing.png')
                        : require('../../assets/cleaning.png')
                    }
                    style={styles.bookingMarkerImg}
                    resizeMode="contain"
                  />
                </View>
              </Marker>
            );
          })}
        </MapView>
      </View>

      {/* Header */}
      <View style={styles.headerOverlay}>
        <AppHeader
          title="Active Bookings"
          subtitle={activeBookings.length > 0 ? `${activeBookings.length} trip${activeBookings.length !== 1 ? 's' : ''}` : 'Your trips'}
          accountType="customer"
          profilePicture={profilePicture}
          onProfilePress={() => router.push('/owner/owner-profile')}
        />
      </View>

      {/* Booking count icon - right side of map */}
      <TouchableOpacity
        style={styles.bookingCountBadge}
        onPress={handleRefresh}
        activeOpacity={0.8}
      >
        <BlurView intensity={60} tint="dark" style={styles.bookingCountBlur}>
          <Ionicons name="calendar" size={22} color={SKY} />
          <View style={styles.bookingCountPill}>
            <Text style={styles.bookingCountText}>{activeBookings.length}</Text>
          </View>
        </BlurView>
      </TouchableOpacity>

      {/* Horizontal scrolling cards - above tab bar */}
      <View style={[styles.horizontalCardsWrapper, { bottom: TAB_BAR_TOTAL_HEIGHT + 100 }]}>
        {activeBookings.length === 0 ? (
          <BlurView intensity={70} tint="dark" style={styles.emptyCard}>
            <View style={styles.emptyContent}>
              <Ionicons name="car-outline" size={32} color={SKY} />
              <Text style={styles.emptyTitle}>No active trips</Text>
              <TouchableOpacity
                style={styles.bookBtn}
                onPress={async () => {
                  await hapticFeedback('medium');
                  router.push('/owner/booking');
                }}
                activeOpacity={0.85}
              >
                <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.bookBtnGrad}>
                  <Text style={styles.bookBtnText}>Book a service</Text>
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </BlurView>
        ) : (
          <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.horizontalScroll}
            snapToInterval={CARD_WIDTH + 12}
            decelerationRate="fast"
            snapToAlignment="start"
          >
            {activeBookings.map((booking) => {
              const statusColor = getStatusColor(booking.status);
              const eta = etaMap[booking.id];
              const isDetailing = booking.service_type?.includes('detailing');

              return (
                <TouchableOpacity
                  key={booking.id}
                  activeOpacity={0.85}
                  onPress={() => handleCardPress(booking.id)}
                  style={[styles.horizontalCard, { borderColor: statusColor + '40', width: CARD_WIDTH }]}
                >
                  <BlurView intensity={50} tint="dark" style={StyleSheet.absoluteFill} />
                  <LinearGradient
                    colors={[statusColor + '15', 'transparent']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={StyleSheet.absoluteFill}
                    pointerEvents="none"
                  />
                  <View style={styles.cardTop}>
                    <View style={[styles.serviceIconWrap, { backgroundColor: statusColor + '25' }]}>
                      <Image
                        source={
                          isDetailing ? require('../../assets/detailing.png') : require('../../assets/cleaning.png')
                        }
                        style={styles.serviceIcon}
                        resizeMode="contain"
                      />
                    </View>
                    <View style={styles.cardMain}>
                      <Text style={styles.cardService} numberOfLines={1}>
                        {getServiceDisplayName(booking.service_type, booking.service_name)}
                      </Text>
                      {booking.valeter_name && (
                        <Text style={styles.cardValeter} numberOfLines={1}>{booking.valeter_name}</Text>
                      )}
                      <View style={[styles.statusPill, { backgroundColor: statusColor + '30' }]}>
                        <View style={[styles.statusDot, { backgroundColor: statusColor }]} />
                        <Text style={[styles.statusPillText, { color: statusColor }]}>{getStatusLabel(booking.status)}</Text>
                      </View>
                    </View>
                  </View>
                  <View style={styles.cardBottom}>
                    <Text style={styles.cardPriceValue}>£{Number(booking.price || 0).toFixed(2)}</Text>
                    {eta != null && (
                      <View style={styles.etaWrap}>
                        <Ionicons name="time-outline" size={12} color={SKY} />
                        <Text style={styles.etaText}>{eta} min</Text>
                      </View>
                    )}
                    <TouchableOpacity
                      onPress={(e) => {
                        e.stopPropagation();
                        hapticFeedback('light');
                        setInfoModalBooking(booking);
                      }}
                      hitSlop={12}
                      style={styles.infoBtn}
                    >
                      <Ionicons name="information-circle-outline" size={20} color={SKY} />
                    </TouchableOpacity>
                    <Text style={styles.ctaText}>{getCTAText(booking.status)}</Text>
                  </View>
                </TouchableOpacity>
              );
            })}
          </ScrollView>
        )}
      </View>

      {/* Info Modal */}
      <Modal
        visible={!!infoModalBooking}
        transparent
        animationType="fade"
        onRequestClose={() => setInfoModalBooking(null)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setInfoModalBooking(null)}>
          <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
            {infoModalBooking && (
              <>
                <View style={styles.modalHeader}>
                  <Text style={styles.modalTitle}>Booking details</Text>
                  <TouchableOpacity onPress={() => setInfoModalBooking(null)} hitSlop={12}>
                    <Ionicons name="close" size={24} color="#94A3B8" />
                  </TouchableOpacity>
                </View>
                <Text style={styles.modalService}>
                  {getServiceDisplayName(infoModalBooking.service_type, infoModalBooking.service_name)}
                </Text>
                <View style={styles.modalRows}>
                  {infoModalBooking.location_address && (
                    <View style={styles.modalRow}>
                      <Ionicons name="location-outline" size={18} color={SKY} />
                      <Text style={styles.modalRowText}>{infoModalBooking.location_address}</Text>
                    </View>
                  )}
                  <View style={styles.modalRow}>
                    <Ionicons name="time-outline" size={18} color={SKY} />
                    <Text style={styles.modalRowText}>{formatDate(infoModalBooking.scheduled_at || infoModalBooking.created_at)}</Text>
                  </View>
                  <View style={styles.modalRow}>
                    <Ionicons name="wallet-outline" size={18} color={SKY} />
                    <Text style={styles.modalRowText}>{formatCurrency(infoModalBooking.price)}</Text>
                  </View>
                  {infoModalBooking.valeter_name && (
                    <View style={styles.modalRow}>
                      <Ionicons name="person-outline" size={18} color={SKY} />
                      <Text style={styles.modalRowText}>{infoModalBooking.valeter_name}</Text>
                    </View>
                  )}
                </View>
                <TouchableOpacity
                  onPress={() => {
                    const id = infoModalBooking.id;
                    setInfoModalBooking(null);
                    handleCardPress(id);
                  }}
                  style={styles.modalCta}
                  activeOpacity={0.9}
                >
                  <LinearGradient colors={[SKY, '#0EA5E9']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.modalCtaGrad}>
                    <Ionicons name="navigate" size={18} color="#FFFFFF" />
                    <Text style={styles.modalCtaText}>{getCTAText(infoModalBooking.status)}</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </>
            )}
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  mapWrapper: {
    ...StyleSheet.absoluteFillObject,
  },
  headerOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 10,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingTop: HEADER_CONTENT_OFFSET,
  },
  loadingText: {
    color: SKY,
    fontSize: 15,
    marginTop: 12,
  },
  markerWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderWidth: 2,
    borderColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  markerImg: { width: 28, height: 28 },
  bookingCountBadge: {
    position: 'absolute',
    top: HEADER_CONTENT_OFFSET + 12,
    right: 16,
    zIndex: 11,
  },
  bookingCountBlur: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 14,
    paddingVertical: 10,
    borderRadius: 16,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
  },
  bookingCountPill: {
    minWidth: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: SKY + '35',
    justifyContent: 'center',
    alignItems: 'center',
  },
  bookingCountText: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '800',
  },
  horizontalCardsWrapper: {
    position: 'absolute',
    left: 0,
    right: 0,
    zIndex: 10,
    paddingHorizontal: 16,
  },
  horizontalScroll: {
    flexDirection: 'row',
    gap: 12,
    paddingRight: 20,
  },
  emptyCard: {
    borderRadius: 20,
    overflow: 'hidden',
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  bookingMarkerWrap: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(30,58,138,0.9)',
    borderWidth: 2,
    borderColor: LIGHT_SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bookingMarkerImg: { width: 24, height: 24 },
  emptyContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  emptyTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '800', flex: 1 },
  bookBtn: { borderRadius: 12, overflow: 'hidden' },
  bookBtnGrad: {
    paddingVertical: 10,
    paddingHorizontal: 18,
  },
  bookBtnText: { color: '#FFFFFF', fontSize: 14, fontWeight: '700' },
  horizontalCard: {
    padding: 20,
    overflow: 'hidden',
    borderRadius: 20,
    borderWidth: 1,
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    marginBottom: 12,
  },
  serviceIconWrap: {
    width: 52,
    height: 52,
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
  },
  serviceIcon: { width: 28, height: 28 },
  cardMain: { flex: 1, minWidth: 0 },
  cardService: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 4,
  },
  cardValeter: {
    color: '#94A3B8',
    fontSize: 12,
    marginBottom: 6,
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 999,
    alignSelf: 'flex-start',
  },
  statusDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  statusPillText: { fontSize: 12, fontWeight: '700' },
  cardBottom: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingTop: 12,
    marginTop: 2,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.15)',
  },
  cardPriceValue: { color: '#F9FAFB', fontSize: 15, fontWeight: '800', flex: 1 },
  etaWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  etaText: { color: SKY, fontSize: 13, fontWeight: '700' },
  infoBtn: { padding: 4 },
  ctaWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  ctaText: { color: SKY, fontSize: 12, fontWeight: '800' },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalContent: {
    width: '100%',
    maxWidth: 340,
    backgroundColor: '#1E293B',
    borderRadius: 20,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  modalTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '800' },
  modalService: { color: SKY, fontSize: 16, fontWeight: '700', marginBottom: 16 },
  modalRows: { gap: 12, marginBottom: 20 },
  modalRow: { flexDirection: 'row', alignItems: 'center', gap: 10 },
  modalRowText: { color: '#E5E7EB', fontSize: 14, flex: 1 },
  modalCta: { borderRadius: 14, overflow: 'hidden' },
  modalCtaGrad: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 8,
  },
  modalCtaText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
});
