/**
 * Stub file to prevent Metro symbolication ENOENT.
 * Hermes stack traces reference InternalBytecode.js (engine internals);
 * Metro tries to read it for code frames - this file satisfies that.
 * See: React Native Hermes parseHermesStack.js
 */
// (empty - Hermes internal bytecode placeholder)
