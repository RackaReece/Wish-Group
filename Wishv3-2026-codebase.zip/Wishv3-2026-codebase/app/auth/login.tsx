import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  TextInput,
  Alert,
  Dimensions,
  Animated,
  Platform,
  ScrollView,
  StatusBar,
  KeyboardAvoidingView,
  Image,
} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { Video, ResizeMode, AVPlaybackStatus } from 'expo-av';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { useAuth } from '../../src/providers/enhanced-auth-context';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { colors } from '../../src/constants/colors';
import { WWPrimaryButton } from '../../src/components/ui';
import * as AppleAuthentication from 'expo-apple-authentication';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;

export default function LoginScreen() {
  const { login, /* @ts-ignore */ loginWithApple } = useAuth();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isAppleAvailable, setIsAppleAvailable] = useState(false);
  const [isEmailFormOpen, setIsEmailFormOpen] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const videoRef = useRef<Video>(null);

  useEffect(() => {
    (async () => {
      try {
        const available =
          Platform.OS === 'ios' && (await AppleAuthentication.isAvailableAsync());
        setIsAppleAvailable(Boolean(available));
      } catch {
        setIsAppleAvailable(false);
      }
    })();
  }, []);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 800,
        useNativeDriver: true,
      }),
      Animated.timing(slideAnim, {
        toValue: 0,
        duration: 800,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  const handlePlaybackStatusUpdate = (status: AVPlaybackStatus) => {
    if (!status.isLoaded || !videoRef.current) return;
    // Restart when video finishes (ensures continuous loop even if isLooping fails)
    if (status.didJustFinish) {
      videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      return;
    }
    if (status.durationMillis != null && status.positionMillis != null) {
      const remaining = status.durationMillis - status.positionMillis;
      if (remaining < 500 && remaining > 0) {
        videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
      }
    }
  };

  const finishRouting = () => {
    router.replace('owner/owner-dashboard');
  };

  const handleResetOnboarding = async () => {
    await hapticFeedback('light');
    try {
      await AsyncStorage.multiRemove(['onboarding_seen', 'customer_onboarding_seen']);
      Alert.alert('Done', 'Onboarding has been reset. You’ll see the onboarding flow again when you next open the app or after sign in.');
    } catch {
      Alert.alert('Error', 'Could not reset onboarding.');
    }
  };

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert('Error', 'Please enter both email and password');
      return;
    }

    await hapticFeedback('medium');
    setIsLoading(true);

    try {
      const adminTriggerEmails = [
        'reeceyrackz@gmail.com',
        'founder@wishawash.com',
        'admin@wishawash.com',
        'ceo@wishawash.com',
        'director@wishawash.com',
      ];
      const adminTriggerPasswords = [
        'WishWash2026!',
        'Admin2026!',
        'Founder2026!',
        'CEO2026!',
      ];

      if (
        adminTriggerEmails.includes(email.toLowerCase()) &&
        adminTriggerPasswords.includes(password)
      ) {
        router.push('/super-admin-auth' as any);
        return;
      }

      const ok = await login(email.trim(), password);
      if (!ok) {
        Alert.alert('Login Failed', 'Invalid email or password.');
        return;
      }

      finishRouting();
    } catch {
      Alert.alert('Login Failed', 'Something went wrong. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleAppleLogin = async () => {
    try {
      await hapticFeedback('light');

      const credential = await AppleAuthentication.signInAsync({
        requestedScopes: [
          AppleAuthentication.AppleAuthenticationScope.FULL_NAME,
          AppleAuthentication.AppleAuthenticationScope.EMAIL,
        ],
      });

      if (typeof loginWithApple === 'function') {
        const ok = await loginWithApple(credential);
        if (!ok) return;
      } else if (credential?.identityToken) {
        await AsyncStorage.setItem(
          'appleIdentityToken',
          credential.identityToken
        );
      }

      finishRouting();
    } catch (error: any) {
      if (error?.code !== 'ERR_CANCELED') {
        Alert.alert('Apple Sign In Failed', 'Please try again.');
      }
    }
  };

  return (
    <View style={styles.root}>
      <StatusBar translucent backgroundColor="transparent" barStyle="light-content" />

      {/* TOP RIGHT SIGN UP */}
      <TouchableOpacity
        style={styles.signUpTopRight}
        onPress={() => router.push('/auth/signup' as any)}
        disabled={isLoading}
        activeOpacity={0.8}
      >
        <Text style={styles.signUpTopRightText}>Sign up</Text>
      </TouchableOpacity>

      <Video
        ref={videoRef}
        source={require('../../assets/index.js').authVideo}
        style={styles.videoBackground}
        resizeMode={ResizeMode.COVER}
        shouldPlay
        isLooping={true}
        isMuted
        progressUpdateIntervalMillis={30}
        onPlaybackStatusUpdate={handlePlaybackStatusUpdate}
      />

      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        style={styles.keyboardView}
      >
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
          showsVerticalScrollIndicator={false}
        >
          <Animated.View
            style={[
              styles.contentContainer,
              { opacity: fadeAnim, transform: [{ translateY: slideAnim }] },
            ]}
          >
            {/* CENTERED LOGO - 3D rounded card */}
            <View style={styles.logoContainer}>
              <View style={styles.logoImageWrapper}>
                <Image
                  source={require('../../assets/icon.png')}
                  style={styles.logoImage}
                  resizeMode="contain"
                />
              </View>
            </View>

            {/* EMAIL TOGGLE */}
            <TouchableOpacity
              style={styles.toggleButton}
              onPress={() => setIsEmailFormOpen(!isEmailFormOpen)}
              activeOpacity={0.8}
            >
              <View style={styles.toggleButtonContent}>
                <Ionicons name="mail-outline" size={20} color="rgba(255,255,255,0.9)" />
                <Text style={styles.toggleButtonText}>Sign in with Email</Text>
                <Ionicons
                  name={isEmailFormOpen ? 'chevron-up' : 'chevron-down'}
                  size={20}
                  color="rgba(255,255,255,0.9)"
                />
              </View>
            </TouchableOpacity>

            {isEmailFormOpen && (
              <View style={styles.formCard}>
                <View style={styles.inputWrapper}>
                  <View style={styles.inputIconContainer}>
                    <Ionicons name="mail-outline" size={20} color="rgba(255,255,255,0.7)" />
                  </View>
                  <TextInput
                    style={styles.input}
                    placeholder="Email address"
                    placeholderTextColor={colors.inputPlaceholder}
                    value={email}
                    onChangeText={setEmail}
                    autoCapitalize="none"
                    keyboardType="email-address"
                    autoComplete="email"
                    accessibilityLabel="Email address"
                  />
                </View>

                <View style={styles.inputWrapper}>
                  <View style={styles.inputIconContainer}>
                    <Ionicons name="lock-closed-outline" size={20} color="rgba(255,255,255,0.7)" />
                  </View>
                  <TextInput
                    style={styles.input}
                    placeholder="Password"
                    placeholderTextColor={colors.inputPlaceholder}
                    value={password}
                    onChangeText={setPassword}
                    secureTextEntry
                    autoComplete="password"
                    accessibilityLabel="Password"
                  />
                </View>

                <TouchableOpacity style={styles.forgotPasswordLink}>
                  <Text style={styles.forgotPasswordText}>Forgot password?</Text>
                </TouchableOpacity>

                <WWPrimaryButton
                  title={isLoading ? 'Signing in…' : 'Sign in'}
                  onPress={handleLogin}
                  disabled={isLoading}
                  loading={isLoading}
                  style={styles.loginButton}
                />
              </View>
            )}

            {isAppleAvailable && (
              <>
                <View style={styles.dividerContainer}>
                  <View style={styles.dividerLine} />
                  <Text style={styles.dividerText}>or continue with</Text>
                  <View style={styles.dividerLine} />
                </View>

                <AppleAuthentication.AppleAuthenticationButton
                  buttonType={AppleAuthentication.AppleAuthenticationButtonType.SIGN_IN}
                  buttonStyle={AppleAuthentication.AppleAuthenticationButtonStyle.WHITE}
                  cornerRadius={12}
                  style={styles.appleButton}
                  onPress={handleAppleLogin}
                />
              </>
            )}

            <View style={styles.utilityRow}>
              <TouchableOpacity
                style={styles.utilityButton}
                onPress={() => router.push('/site-map' as any)}
                activeOpacity={0.7}
                disabled={isLoading}
              >
                <Ionicons name="map-outline" size={16} color="rgba(255,255,255,0.7)" />
                <Text style={styles.utilityButtonText}>Sitemap</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.utilityButton}
                onPress={handleResetOnboarding}
                activeOpacity={0.7}
                disabled={isLoading}
              >
                <Ionicons name="refresh-outline" size={16} color="rgba(255,255,255,0.6)" />
                <Text style={styles.resetOnboardingText}>Reset onboarding</Text>
              </TouchableOpacity>
            </View>

            <View style={styles.footer}>
              <Text style={styles.footerText}>Wish a Wash v1.0.0 • © 2025</Text>
            </View>
          </Animated.View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  keyboardView: { flex: 1 },

  scrollContent: {
    flexGrow: 1,
    paddingTop: Platform.OS === 'ios' ? 100 : 24,
    paddingBottom: 28,
    paddingHorizontal: isSmallScreen ? 16 : 20,
  },
  contentContainer: { flex: 1 },

  /* Top-right sign up */
  signUpTopRight: {
    position: 'absolute',
    top: Platform.OS === 'ios' ? 50 : 24,
    right: 20,
    zIndex: 20,
    paddingVertical: 6,
    paddingHorizontal: 10,
  },
  signUpTopRightText: {
    color: '#87CEEB',
    fontWeight: '600',
    fontSize: 15,
  },

  videoBackground: { ...StyleSheet.absoluteFillObject },

  logoContainer: {
    alignItems: 'center',
    marginBottom: 20,
  },
  logoImageWrapper: {
    width: 160,
    height: 160,
    borderRadius: 32,
    backgroundColor: 'rgba(255,255,255,0.06)',
    overflow: 'hidden',
    // 3D depth
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.45,
    shadowRadius: 16,
    elevation: 16,
    // 3D bevel border (light top/left, dark bottom/right)
    borderWidth: 3,
    borderTopColor: 'rgba(255,255,255,0.45)',
    borderLeftColor: 'rgba(255,255,255,0.35)',
    borderRightColor: 'rgba(0,0,0,0.35)',
    borderBottomColor: 'rgba(0,0,0,0.45)',
  },
  logoImage: {
    width: 160,
    height: 160,
    borderRadius: 32,
    overflow: 'hidden',
  },

  toggleButton: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    padding: 12,
    marginBottom: 12,
  },
  toggleButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  toggleButtonText: {
    flex: 1,
    fontSize: 15,
    fontWeight: '600',
    color: 'rgba(255,255,255,0.9)',
  },

  formCard: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 14,
    padding: 18,
    marginBottom: 16,
  },
  inputWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderRadius: 12,
    marginBottom: 12,
  },
  inputIconContainer: {
    width: 44,
    height: 48,
    alignItems: 'center',
    justifyContent: 'center',
  },
  input: {
    flex: 1,
    color: colors.inputText,
    fontSize: 15,
    paddingRight: 12,
  },

  forgotPasswordLink: {
    alignSelf: 'flex-end',
    marginBottom: 14,
  },
  forgotPasswordText: {
    color: '#87CEEB',
    fontWeight: '600',
  },

  loginButton: { marginTop: 4 },

  dividerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 14,
  },
  dividerLine: {
    flex: 1,
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.2)',
  },
  dividerText: {
    marginHorizontal: 12,
    color: 'rgba(255,255,255,0.6)',
    fontSize: 12,
    fontWeight: '600',
  },

  appleButton: { width: '100%', height: 44 },

  utilityRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    flexWrap: 'wrap',
    gap: 16,
    marginBottom: 12,
  },
  utilityButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 10,
    paddingHorizontal: 14,
  },
  utilityButtonText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 14,
    fontWeight: '500',
  },
  resetOnboardingText: {
    color: 'rgba(255,255,255,0.6)',
    fontSize: 14,
    fontWeight: '500',
  },
  footer: {
    marginTop: 18,
    alignItems: 'center',
  },
  footerText: {
    fontSize: 11,
    color: 'rgba(255,255,255,0.4)',
  },
});
