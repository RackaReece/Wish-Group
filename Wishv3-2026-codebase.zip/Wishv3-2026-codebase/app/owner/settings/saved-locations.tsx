import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Alert,
  TextInput,
  KeyboardAvoidingView,
  Platform,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import MapView, { MapPressEvent } from 'react-native-maps';
import * as Location from 'expo-location';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader from '../../../src/components/shared/AppHeader';
import EmptyState from '../../../src/components/shared/EmptyState';
import LoadingScreen from '../../../src/components/LoadingScreen';
import GlassCard from '@/components/booking/GlassCard';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';
import { getScrollContentPadding } from '../../../src/constants/layoutConstants';
import { CONTENT_PADDING_H } from '../../../src/constants/pageStyles';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';

const SKY = colors.SKY;
const BG = colors.BG;

const STORAGE_KEY = 'customer_saved_locations';

type LocationLabelId = 'home' | 'work' | 'gym' | 'other';

type SavedLocation = {
  id: string;
  label: LocationLabelId;
  customLabel?: string;
  address: string;
  latitude: number;
  longitude: number;
};

const LABELS: { id: LocationLabelId; icon: string; title: string }[] = [
  { id: 'home', icon: 'home', title: 'Home' },
  { id: 'work', icon: 'briefcase', title: 'Work' },
  { id: 'gym', icon: 'barbell', title: 'Gym' },
  { id: 'other', icon: 'location', title: 'Other' },
];

async function loadSaved(userId: string): Promise<SavedLocation[]> {
  try {
    const raw = await AsyncStorage.getItem(`${STORAGE_KEY}_${userId}`);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

async function saveLocations(userId: string, locations: SavedLocation[]) {
  await AsyncStorage.setItem(`${STORAGE_KEY}_${userId}`, JSON.stringify(locations));
}

export default function SavedLocations() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [locations, setLocations] = useState<SavedLocation[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<SavedLocation | null>(null);
  const [editLabel, setEditLabel] = useState<LocationLabelId>('home');
  const [editAddress, setEditAddress] = useState('');
  const [editLat, setEditLat] = useState<number>(51.5074);
  const [editLng, setEditLng] = useState<number>(-0.1278);
  const userEditedAddressRef = useRef(false);

  useEffect(() => {
    if (!user?.id) return;
    loadSaved(user.id).then((list) => {
      setLocations(list);
      setLoading(false);
    });
  }, [user?.id]);

  const openAdd = async (label: LocationLabelId) => {
    await hapticFeedback('light');
    userEditedAddressRef.current = false;
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Location permission is required.');
        return;
      }
      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const [result] = await Location.reverseGeocodeAsync(loc.coords);
      const addr = result
        ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current location'
        : 'Current location';

      setEditLabel(label);
      setEditAddress(addr);
      setEditLat(loc.coords.latitude);
      setEditLng(loc.coords.longitude);
      setEditing({
        id: `new-${Date.now()}`,
        label,
        address: addr,
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
      });
    } catch {
      Alert.alert('Error', 'Could not get location.');
    }
  };

  const openEdit = (loc: SavedLocation) => {
    hapticFeedback('light');
    userEditedAddressRef.current = false;
    setEditing(loc);
    setEditLabel(loc.label);
    setEditAddress(loc.address);
    setEditLat(loc.latitude);
    setEditLng(loc.longitude);
  };

  const handleMapPress = async (e: MapPressEvent) => {
    const { latitude, longitude } = e.nativeEvent.coordinate;
    setEditLat(latitude);
    setEditLng(longitude);
    if (userEditedAddressRef.current) return;
    try {
      const [result] = await Location.reverseGeocodeAsync({ latitude, longitude });
      const addr = result
        ? `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Selected location'
        : 'Selected location';
      setEditAddress(addr);
    } catch {}
  };

  const handleAddressChange = (text: string) => {
    userEditedAddressRef.current = true;
    setEditAddress(text);
  };

  const saveLocation = async () => {
    if (!user?.id || !editAddress.trim()) return;
    await hapticFeedback('medium');

    const updated: SavedLocation = {
      id: editing!.id,
      label: editLabel,
      address: editAddress.trim(),
      latitude: editLat,
      longitude: editLng,
    };

    const isNew = editing!.id.startsWith('new-');
    let next: SavedLocation[];

    if (isNew) {
      if (editLabel !== 'other' && locations.some((l) => l.label === editLabel)) {
        Alert.alert('Already saved', `You already have a ${editLabel} location. Edit it instead.`);
        return;
      }
      next = [...locations, { ...updated, id: `loc-${Date.now()}` }];
    } else {
      next = locations.map((l) => (l.id === editing!.id ? updated : l));
    }

    setLocations(next);
    await saveLocations(user.id, next);
    setEditing(null);
  };

  const performRemoveLocation = async (id: string) => {
    if (!user?.id) return;
    const next = locations.filter((l) => l.id !== id);
    setLocations(next);
    await saveLocations(user.id, next);
    if (editing?.id === id) setEditing(null);
  };

  const deleteLocation = (id: string) => {
    Alert.alert('Remove location?', 'This cannot be undone.', [
      { text: 'Cancel', style: 'cancel' },
      {
        text: 'Remove',
        style: 'destructive',
        onPress: () => { void performRemoveLocation(id); },
      },
    ]);
  };

  const displayLabel = (l: SavedLocation) => LABELS.find((x) => x.id === l.label)?.title || l.label;

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LoadingScreen />
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
      <AppHeader title="Saved Locations" variant="dashboard" accountType="customer" showBack onBack={() => router.back()} />

      <ScrollView
        style={styles.scroll}
        contentContainerStyle={[styles.scrollContent, { paddingHorizontal: CONTENT_PADDING_H, ...getScrollContentPadding(insets, true) }]}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled"
      >
        <Text style={styles.subtitle}>Save Home, Work, Gym and more. Use these when booking.</Text>

        {locations.length === 0 && (
          <EmptyState
            icon="location-outline"
            title="No saved locations"
            subtitle="Add Home, Work, Gym or Other below for quicker booking."
            iconColor={SKY}
            style={styles.emptyState}
          />
        )}

        {locations.map((loc) => (
          <GlassCard key={loc.id} style={styles.card} borderRadius={16} accountType="customer">
            <View style={styles.cardRow}>
              <View style={styles.cardIcon}>
                <Ionicons
                  name={(LABELS.find((x) => x.id === loc.label)?.icon || 'location') as any}
                  size={22}
                  color={SKY}
                />
              </View>
              <View style={styles.cardText}>
                <Text style={styles.cardTitle}>{displayLabel(loc)}</Text>
                <Text style={styles.cardAddress} numberOfLines={2}>{loc.address}</Text>
              </View>
              <TouchableOpacity onPress={() => openEdit(loc)} style={styles.iconBtn} hitSlop={12} activeOpacity={0.7}>
                <Ionicons name="pencil" size={18} color={SKY} />
              </TouchableOpacity>
              <TouchableOpacity onPress={() => deleteLocation(loc.id)} style={styles.deleteIconBtn} hitSlop={12} activeOpacity={0.7}>
                <Ionicons name="trash-outline" size={20} color="#EF4444" />
              </TouchableOpacity>
            </View>
          </GlassCard>
        ))}

        <Text style={styles.sectionTitle}>Add location</Text>
        <View style={styles.addGrid}>
          {LABELS.map((l) => {
            const canAdd = l.id === 'other' || !locations.some((x) => x.label === l.id);
            return (
              <TouchableOpacity
                key={l.id}
                style={[styles.addBtn, !canAdd && styles.addBtnDisabled]}
                onPress={() => canAdd && openAdd(l.id)}
                disabled={!canAdd}
                activeOpacity={0.8}
                hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              >
                <View style={[styles.addIcon, !canAdd && styles.addIconDisabled]}>
                  <Ionicons name={l.icon as any} size={24} color={canAdd ? SKY : '#64748B'} />
                </View>
                <Text style={[styles.addLabel, !canAdd && styles.addLabelDisabled]}>{l.title}</Text>
                {!canAdd && <Text style={styles.addHint}>Saved</Text>}
              </TouchableOpacity>
            );
          })}
        </View>
      </ScrollView>

      {editing && (
        <Pressable style={styles.modal} onPress={() => setEditing(null)}>
          <KeyboardAvoidingView
            behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
            style={styles.modalInner}
          >
            <Pressable style={styles.modalContent} onPress={(e) => e.stopPropagation()}>
              <Text style={styles.modalTitle}>{editing.id.startsWith('new-') ? 'Add' : 'Edit'} {displayLabel(editing)}</Text>
              <MapView
                style={styles.map}
                region={{
                  latitude: editLat,
                  longitude: editLng,
                  latitudeDelta: 0.002,
                  longitudeDelta: 0.002,
                }}
                onPress={handleMapPress}
              />
              <TextInput
                style={styles.input}
                value={editAddress}
                onChangeText={handleAddressChange}
                placeholder="Address"
                placeholderTextColor={colors.inputPlaceholderMuted}
              />
              <View style={styles.modalBtns}>
                <TouchableOpacity style={styles.cancelBtn} onPress={() => setEditing(null)} hitSlop={12}>
                  <Text style={styles.cancelText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.saveBtn} onPress={saveLocation} disabled={!editAddress.trim()} hitSlop={12} activeOpacity={0.85}>
                  <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.saveGrad}>
                    <Text style={styles.saveText}>Save</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </Pressable>
          </KeyboardAvoidingView>
        </Pressable>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  scroll: { flex: 1 },
  scrollContent: {},
  subtitle: { color: '#94A3B8', fontSize: 14, marginBottom: 20 },
  emptyState: { minHeight: 200, marginBottom: 16 },
  card: { padding: 16, marginBottom: 12 },
  cardRow: { flexDirection: 'row', alignItems: 'center' },
  cardIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: SKY + '20',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  cardText: { flex: 1, minWidth: 0 },
  cardTitle: { color: '#F9FAFB', fontSize: 16, fontWeight: '700', marginBottom: 4 },
  cardAddress: { color: '#94A3B8', fontSize: 13 },
  iconBtn: { padding: 8 },
  deleteIconBtn: {
    padding: 8,
    borderRadius: 10,
    backgroundColor: 'rgba(239,68,68,0.1)',
  },
  sectionTitle: { color: colors.textOnDarkPrimary, fontSize: 18, fontWeight: '800', marginTop: 24, marginBottom: 12 },
  addGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12 },
  addBtn: {
    width: '47%',
    padding: 16,
    borderRadius: 16,
    backgroundColor: 'rgba(255,255,255,0.05)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  addBtnDisabled: { opacity: 0.6 },
  addIcon: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: SKY + '20',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  addIconDisabled: { backgroundColor: 'rgba(100,116,139,0.2)' },
  addLabel: { color: '#F9FAFB', fontSize: 15, fontWeight: '700' },
  addLabelDisabled: { color: '#64748B' },
  addHint: { color: '#64748B', fontSize: 11, marginTop: 4 },
  modal: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(0,0,0,0.7)', justifyContent: 'center', padding: 20 },
  modalInner: { width: '100%', maxHeight: '85%' },
  modalContent: { backgroundColor: '#1E293B', borderRadius: 20, padding: 20 },
  modalTitle: { color: '#F9FAFB', fontSize: 18, fontWeight: '800', marginBottom: 12 },
  map: { height: 180, borderRadius: 12, marginBottom: 12 },
  input: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    padding: 14,
    color: '#F9FAFB',
    fontSize: 15,
    marginBottom: 16,
  },
  modalBtns: { flexDirection: 'row', gap: 12 },
  cancelBtn: {
    flex: 1,
    padding: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(100,116,139,0.3)',
    alignItems: 'center',
  },
  cancelText: { color: '#F9FAFB', fontSize: 16, fontWeight: '600' },
  saveBtn: { flex: 1, borderRadius: 12, overflow: 'hidden' },
  saveGrad: { padding: 14, alignItems: 'center' },
  saveText: { color: '#FFF', fontSize: 16, fontWeight: '700' },
});
