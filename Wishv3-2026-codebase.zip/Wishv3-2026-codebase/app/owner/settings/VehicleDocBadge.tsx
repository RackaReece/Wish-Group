import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import { colors } from '../../../src/constants/colors';

const SKY = colors.SKY;

type BadgeTone = 'good' | 'bad' | 'neutral';

function formatDatePretty(dateOnly: string | null | undefined) {
  if (!dateOnly) return '—';
  const d = new Date(`${dateOnly}T00:00:00`);
  if (Number.isNaN(d.getTime())) return '—';
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

function getDaysUntilExpiry(dateOnly: string | null | undefined): number | null {
  if (!dateOnly) return null;
  const d = new Date(`${dateOnly}T00:00:00`);
  if (Number.isNaN(d.getTime())) return null;
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  d.setHours(0, 0, 0, 0);
  const diff = d.getTime() - now.getTime();
  return Math.ceil(diff / (1000 * 60 * 60 * 24));
}

function badgeToneFromStatus(status?: string | null): BadgeTone {
  const s = String(status || '').toLowerCase();
  if (!s) return 'neutral';
  if (s.includes('valid') || s.includes('taxed') || s.includes('in force') || s.includes('yes')) return 'good';
  if (s.includes('no') || s.includes('expired') || s.includes('sorn') || s.includes('not')) return 'bad';
  return 'neutral';
}

function getBadgeToneStyle(tone: BadgeTone) {
  if (tone === 'good') return styles.statusBadgeGood;
  if (tone === 'bad') return styles.statusBadgeBad;
  return styles.statusBadgeNeutral;
}

function getBadgeColor(tone: BadgeTone, isUrgent: boolean) {
  if (tone === 'good') return '#10B981';
  if (tone === 'bad') return '#EF4444';
  return isUrgent ? '#F59E0B' : SKY;
}

export type VehicleDocBadgeProps = Readonly<{
  label: string;
  status?: string | null;
  expiryDate?: string | null;
  icon: string;
}>;

export default function VehicleDocBadge({ label, status, expiryDate, icon }: VehicleDocBadgeProps) {
  const tone = badgeToneFromStatus(status);
  const daysUntil = getDaysUntilExpiry(expiryDate);
  const isUrgent = daysUntil !== null && daysUntil <= 30 && daysUntil >= 0;
  const badgeToneStyle = getBadgeToneStyle(tone);
  const badgeColor = getBadgeColor(tone, isUrgent);
  const labelToneStyle = [
    styles.statusBadgeLabel,
    tone === 'good' && styles.statusBadgeLabelGood,
    tone === 'bad' && styles.statusBadgeLabelBad,
    isUrgent && styles.statusBadgeLabelUrgent,
  ];

  return (
    <View style={[styles.statusBadge, badgeToneStyle, isUrgent && styles.statusBadgeUrgent]}>
      <Ionicons name={icon as never} size={14} color={badgeColor} />
      <View style={styles.statusBadgeContent}>
        <Text style={labelToneStyle}>{label}</Text>
        <Text style={styles.statusBadgeValue}>
          {status || '—'}
          {expiryDate ? ` • ${formatDatePretty(expiryDate)}` : ''}
          {isUrgent && daysUntil !== null && (
            <Text style={styles.statusBadgeUrgentText}> ({daysUntil} days)</Text>
          )}
        </Text>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  statusBadge: {
    flex: 1,
    minWidth: 120,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    padding: 12,
    borderRadius: 12,
    backgroundColor: '#334155',
    borderWidth: 1,
    borderColor: '#475569',
  },
  statusBadgeGood: {
    backgroundColor: '#064E3B',
    borderColor: '#10B981',
  },
  statusBadgeBad: {
    backgroundColor: '#7F1D1D',
    borderColor: '#EF4444',
  },
  statusBadgeNeutral: {},
  statusBadgeUrgent: {
    backgroundColor: '#78350F',
    borderColor: '#F59E0B',
  },
  statusBadgeContent: {
    flex: 1,
  },
  statusBadgeLabel: {
    color: '#64748B',
    fontSize: 11,
    fontWeight: '600',
    marginBottom: 2,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  statusBadgeLabelGood: {
    color: '#10B981',
  },
  statusBadgeLabelBad: {
    color: '#EF4444',
  },
  statusBadgeLabelUrgent: {
    color: '#F59E0B',
  },
  statusBadgeValue: {
    color: '#E2E8F0',
    fontSize: 12,
    fontWeight: '500',
  },
  statusBadgeUrgentText: {
    color: '#F59E0B',
    fontWeight: '700',
  },
});
