import React, { useState, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Share,
  Alert,
} from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import AppHeader from '../../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { getScrollContentPadding } from '../../../src/constants/layoutConstants';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;
const REWARD_PER_REFERRAL = 5;

// Referral tiers: Rookie → Rising Star → Champion → Ambassador → Legend
const REFERRAL_TIERS = [
  { name: 'Rookie', min: 0, icon: 'leaf', color: '#94A3B8' },
  { name: 'Rising Star', min: 1, icon: 'star', color: '#FCD34D' },
  { name: 'Champion', min: 3, icon: 'trophy', color: '#F59E0B' },
  { name: 'Ambassador', min: 7, icon: 'ribbon', color: '#8B5CF6' },
  { name: 'Legend', min: 10, icon: 'diamond', color: '#06B6D4' },
];

// Achievement milestones
const MILESTONES = [
  { id: 'first', count: 1, label: 'First Friend', icon: 'heart' },
  { id: 'squad', count: 3, label: 'Squad Builder', icon: 'people' },
  { id: 'influencer', count: 5, label: 'Influencer', icon: 'megaphone' },
  { id: 'ambassador', count: 7, label: 'Ambassador', icon: 'ribbon' },
  { id: 'legend', count: 10, label: 'Legend', icon: 'diamond' },
];

export default function ReferralSystem() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();

  const generateShortCode = (userId: string | undefined): string => {
    if (!userId) return 'WAW000';
    const shortId = userId.replaceAll('-', '').substring(0, 6).toUpperCase();
    return shortId || 'WAW000';
  };

  const [referralCode] = useState(generateShortCode(user?.id));
  const [referrals] = useState<Array<{ id: string; name: string; date: string; reward: string }>>([]);

  const referralCount = referrals.length;
  const creditsEarned = referralCount * REWARD_PER_REFERRAL;

  const { currentTier, nextTier, progressToNext, isMaxTier } = useMemo(() => {
    const tiers = [...REFERRAL_TIERS].reverse();
    const current = tiers.find((t) => referralCount >= t.min) ?? REFERRAL_TIERS[0];
    const next = REFERRAL_TIERS[REFERRAL_TIERS.indexOf(current) + 1];
    const isMax = !next;
    let progress: number;
    if (isMax) progress = 100;
    else if (next) progress = Math.min(100, ((referralCount - current.min) / (next.min - current.min)) * 100);
    else progress = 0;
    return {
      currentTier: current,
      nextTier: next ?? null,
      progressToNext: progress,
      isMaxTier: isMax,
    };
  }, [referralCount]);

  const nextMilestone = useMemo(
    () => MILESTONES.find((m) => referralCount < m.count),
    [referralCount]
  );
  const referralsToNext = nextMilestone ? nextMilestone.count - referralCount : 0;

  const handleShare = async () => {
    try {
      await Share.share({
        message: `Join me on Wish a Wash! Use my referral code: ${referralCode} and get £5 off your first booking!`,
      });
    } catch (err) {
      console.warn('[Referral] Share failed:', err);
      Alert.alert('Error', 'Unable to share referral code');
    }
  };

  const handleCopy = () => {
    Alert.alert('Copied!', 'Referral code copied to clipboard');
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Referrals"
        variant="dashboard"
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
        accountType="customer"
      />

      <ScrollView
        style={styles.scrollView}
        contentContainerStyle={[styles.scrollContent, getScrollContentPadding(insets, true)]}
        showsVerticalScrollIndicator={false}
      >
        {/* Level & Stats Card */}
        <View style={styles.levelCard}>
          <BlurView intensity={35} tint="dark" style={styles.levelBlur}>
            <LinearGradient
              colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.levelBorder} />
            <View style={styles.levelContent}>
              <View style={styles.levelHeader}>
                <View style={[styles.tierBadge, { backgroundColor: `${currentTier.color}25` }]}>
                  <Ionicons name={currentTier.icon as any} size={20} color={currentTier.color} />
                  <Text style={[styles.tierText, { color: currentTier.color }]}>{currentTier.name}</Text>
                </View>
                <View style={styles.statsRow}>
                  <View style={styles.statPill}>
                    <Ionicons name="people" size={16} color={SKY} />
                    <Text style={styles.statValue}>{referralCount}</Text>
                    <Text style={styles.statLabel}>Friends</Text>
                  </View>
                  <View style={styles.statPill}>
                    <Ionicons name="wallet" size={16} color="#10B981" />
                    <Text style={[styles.statValue, { color: '#10B981' }]}>£{creditsEarned}</Text>
                    <Text style={styles.statLabel}>Earned</Text>
                  </View>
                </View>
              </View>
              {!isMaxTier && nextTier && (
                <View style={styles.progressContainer}>
                  <View style={styles.progressBarBg}>
                    <LinearGradient
                      colors={[currentTier.color, nextTier.color]}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 1, y: 0 }}
                      style={[styles.progressBarFill, { width: `${progressToNext}%` }]}
                    />
                  </View>
                  <Text style={styles.progressLabel}>
                    {referralCount} / {nextTier.min} → {nextTier.name}
                  </Text>
                </View>
              )}
              {isMaxTier && (
                <View style={styles.maxTierBadge}>
                  <Ionicons name="ribbon" size={14} color={currentTier.color} />
                  <Text style={[styles.maxTierText, { color: currentTier.color }]}>Max tier unlocked!</Text>
                </View>
              )}
            </View>
          </BlurView>
        </View>

        {/* Referral Code Card */}
        <View style={styles.codeCard}>
          <BlurView intensity={35} tint="dark" style={styles.codeBlur}>
            <LinearGradient
              colors={['rgba(255,255,255,0.08)', 'rgba(255,255,255,0.03)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.codeBorder} />
            <View style={styles.codeGradient}>
              <View style={[styles.codeIconWrapper, { backgroundColor: `${currentTier.color}25` }]}>
                <Ionicons name="gift" size={32} color={currentTier.color} />
              </View>
              <Text style={styles.codeLabel}>Your Referral Code</Text>
              <View style={styles.codeContainer}>
                <Text style={styles.codeText}>{referralCode}</Text>
              </View>
              <View style={styles.codeActions}>
                <TouchableOpacity style={styles.codeButton} onPress={handleCopy}>
                  <Ionicons name="copy" size={18} color={SKY} />
                  <Text style={styles.codeButtonText}>Copy</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[styles.codeButton, styles.shareButton]} onPress={handleShare}>
                  <Ionicons name="share-social" size={18} color="#fff" />
                  <Text style={[styles.codeButtonText, { color: '#fff' }]}>Share & Earn</Text>
                </TouchableOpacity>
              </View>
            </View>
          </BlurView>
        </View>

        {/* Next Milestone Callout */}
        {nextMilestone && (
          <View style={styles.milestoneCard}>
            <BlurView intensity={25} tint="dark" style={styles.milestoneBlur}>
              <LinearGradient
                colors={['rgba(139,92,246,0.15)', 'rgba(6,182,212,0.08)']}
                style={StyleSheet.absoluteFill}
              />
              <View style={styles.milestoneContent}>
                <View style={styles.milestoneIconWrapper}>
                  <Ionicons name={nextMilestone.icon as any} size={24} color="#8B5CF6" />
                </View>
                <View style={styles.milestoneTextWrapper}>
                  <Text style={styles.milestoneTitle}>Next unlock: {nextMilestone.label}</Text>
                  <Text style={styles.milestoneSubtext}>
                    {referralsToNext} more referral{referralsToNext === 1 ? '' : 's'} to unlock this badge!
                  </Text>
                </View>
              </View>
            </BlurView>
          </View>
        )}

        {/* Achievement Badges */}
        <View style={styles.achievementsSection}>
          <Text style={styles.sectionTitle}>Achievements</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.achievementsRow}>
            {MILESTONES.map((m) => {
              const unlocked = referralCount >= m.count;
              return (
                <View
                  key={m.id}
                  style={[
                    styles.achievementBadge,
                    unlocked ? styles.achievementUnlocked : styles.achievementLocked,
                  ]}
                >
                  <View
                    style={[
                      styles.achievementIcon,
                      unlocked ? { backgroundColor: `${SKY}25`, borderColor: `${SKY}50` } : { backgroundColor: 'rgba(107,114,128,0.08)', borderColor: 'rgba(107,114,128,0.25)' },
                    ]}
                  >
                    <Ionicons
                      name={unlocked ? (m.icon as any) : 'lock-closed'}
                      size={22}
                      color={unlocked ? SKY : '#6B7280'}
                    />
                  </View>
                  <Text style={[styles.achievementLabel, !unlocked && styles.achievementLabelLocked]}>
                    {m.label}
                  </Text>
                  <Text style={styles.achievementCount}>{m.count}</Text>
                </View>
              );
            })}
          </ScrollView>
        </View>

        {/* How it Works */}
        <View style={styles.infoCard}>
          <BlurView intensity={30} tint="dark" style={styles.infoBlur}>
            <LinearGradient
              colors={['rgba(255,255,255,0.06)', 'rgba(255,255,255,0.02)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.infoBorder} />
            <View style={styles.infoContentWrapper}>
              <View style={styles.infoIconWrapper}>
                <Ionicons name="sparkles" size={24} color={SKY} />
              </View>
              <View style={styles.infoContent}>
                <Text style={styles.infoTitle}>How it Works</Text>
                <Text style={styles.infoText}>
                  Share your code with friends. When they sign up and complete their first booking, you both get £5 credit! Level up through tiers and unlock achievement badges as you refer more friends.
                </Text>
              </View>
            </View>
          </BlurView>
        </View>

        {/* Referrals List */}
        <View style={styles.referralsSection}>
          <Text style={styles.sectionTitle}>Your Squad ({referrals.length})</Text>
          {referrals.length === 0 ? (
            <View style={styles.emptyContainer}>
              <View style={styles.emptyIconRing}>
                <Ionicons name="rocket" size={40} color={SKY} />
              </View>
              <Text style={styles.emptyText}>Your first referral = £5!</Text>
              <Text style={styles.emptySubtext}>
                Share your code to level up from Rookie and unlock the First Friend badge
              </Text>
              <TouchableOpacity style={styles.emptyCta} onPress={handleShare}>
                <Ionicons name="share-social" size={18} color="#fff" />
                <Text style={styles.emptyCtaText}>Share Now</Text>
              </TouchableOpacity>
            </View>
          ) : (
            referrals.map((referral) => (
              <View key={referral.id} style={styles.referralCard}>
                <BlurView intensity={30} tint="dark" style={styles.referralBlur}>
                  <LinearGradient
                    colors={['rgba(255,255,255,0.06)', 'rgba(255,255,255,0.02)']}
                    style={StyleSheet.absoluteFill}
                  />
                  <View style={styles.referralBorder} />
                  <View style={styles.referralContentWrapper}>
                    <View style={styles.referralIconWrapper}>
                      <Ionicons name="person" size={20} color={SKY} />
                    </View>
                    <View style={styles.referralContent}>
                      <Text style={styles.referralName}>{referral.name}</Text>
                      <Text style={styles.referralDate}>{referral.date}</Text>
                    </View>
                    <View style={styles.rewardBadge}>
                      <Text style={styles.rewardText}>{referral.reward}</Text>
                    </View>
                  </View>
                </BlurView>
              </View>
            ))
          )}
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  scrollView: { flex: 1 },
  scrollContent: { paddingBottom: 120, paddingHorizontal: isSmallScreen ? 12 : 20 },
  // Level & tier card
  levelCard: {
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  levelBlur: { borderRadius: 20, overflow: 'hidden' },
  levelBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  levelContent: { padding: 20 },
  levelHeader: { marginBottom: 12 },
  tierBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 14,
    marginBottom: 14,
  },
  tierText: { fontSize: 14, fontWeight: '800', marginLeft: 6, textTransform: 'uppercase', letterSpacing: 0.5 },
  statsRow: { flexDirection: 'row', gap: 16 },
  statPill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    gap: 8,
  },
  statValue: { color: '#F9FAFB', fontSize: 18, fontWeight: '800' },
  statLabel: { color: '#94A3B8', fontSize: 11, fontWeight: '600' },
  progressContainer: { marginTop: 4 },
  progressBarBg: {
    height: 8,
    backgroundColor: 'rgba(107,114,128,0.2)',
    borderRadius: 4,
    overflow: 'hidden',
    marginBottom: 6,
  },
  progressBarFill: { height: '100%', borderRadius: 4 },
  progressLabel: { color: '#87CEEB', fontSize: 11, fontWeight: '600', opacity: 0.9 },
  maxTierBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    marginTop: 8,
    gap: 6,
  },
  maxTierText: { fontSize: 12, fontWeight: '700' },
  // Milestone callout
  milestoneCard: {
    borderRadius: 14,
    overflow: 'hidden',
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(139,92,246,0.3)',
  },
  milestoneBlur: { borderRadius: 14, overflow: 'hidden' },
  milestoneContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  milestoneIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 14,
    backgroundColor: 'rgba(139,92,246,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 14,
  },
  milestoneTextWrapper: { flex: 1 },
  milestoneTitle: { color: '#F9FAFB', fontSize: 15, fontWeight: '700', marginBottom: 4 },
  milestoneSubtext: { color: '#A78BFA', fontSize: 12, fontWeight: '500' },
  // Achievements
  achievementsSection: { marginBottom: 20 },
  achievementsRow: {
    flexDirection: 'row',
    gap: 12,
    paddingVertical: 4,
  },
  achievementBadge: {
    alignItems: 'center',
    minWidth: 80,
  },
  achievementUnlocked: {},
  achievementLocked: { opacity: 0.5 },
  achievementIcon: {
    width: 48,
    height: 48,
    borderRadius: 14,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  achievementLabel: {
    color: '#F9FAFB',
    fontSize: 11,
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 2,
  },
  achievementLabelLocked: { color: '#6B7280' },
  achievementCount: {
    color: '#87CEEB',
    fontSize: 10,
    fontWeight: '700',
  },
  codeCard: {
    borderRadius: 20,
    overflow: 'hidden',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  codeBlur: {
    borderRadius: 20,
    overflow: 'hidden',
  },
  codeBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  codeGradient: {
    padding: 24,
    alignItems: 'center',
  },
  codeIconWrapper: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 12,
  },
  codeLabel: {
    color: '#87CEEB',
    fontSize: 14,
    fontWeight: '600',
    marginBottom: 12,
  },
  codeContainer: {
    backgroundColor: 'rgba(255,255,255,0.08)',
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 20,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  codeText: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 20 : 24,
    fontWeight: '800',
    letterSpacing: 2,
  },
  codeActions: {
    flexDirection: 'row',
    gap: 12,
  },
  codeButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(135,206,235,0.25)',
    paddingVertical: 10,
    paddingHorizontal: 20,
    borderRadius: 12,
    gap: 6,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  codeButtonText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
  },
  shareButton: {
    backgroundColor: SKY,
    borderColor: SKY,
  },
  infoCard: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 24,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  infoBlur: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  infoBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  infoContentWrapper: {
    flexDirection: 'row',
    padding: 16,
  },
  infoIconWrapper: {
    width: 48,
    height: 48,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  infoContent: {
    flex: 1,
  },
  infoTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 16 : 17,
    fontWeight: '700',
    marginBottom: 6,
  },
  infoText: {
    color: '#87CEEB',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '500',
  },
  referralsSection: {
    marginBottom: 24,
  },
  sectionTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 18 : 20,
    fontWeight: 'bold',
    marginBottom: 16,
  },
  emptyContainer: {
    alignItems: 'center',
    paddingVertical: 36,
  },
  emptyIconRing: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.35)',
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 8,
    textAlign: 'center',
  },
  emptySubtext: {
    color: '#87CEEB',
    fontSize: 14,
    textAlign: 'center',
    paddingHorizontal: 24,
    lineHeight: 20,
    marginBottom: 20,
  },
  emptyCta: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: SKY,
    paddingVertical: 14,
    paddingHorizontal: 28,
    borderRadius: 14,
    gap: 10,
  },
  emptyCtaText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  referralCard: {
    borderRadius: 16,
    overflow: 'hidden',
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
  },
  referralBlur: {
    borderRadius: 16,
    overflow: 'hidden',
  },
  referralBorder: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  referralContentWrapper: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  referralIconWrapper: {
    width: 40,
    height: 40,
    borderRadius: 10,
    backgroundColor: 'rgba(135,206,235,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  referralContent: {
    flex: 1,
  },
  referralName: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 15 : 16,
    fontWeight: '700',
    marginBottom: 4,
  },
  referralDate: {
    color: '#87CEEB',
    fontSize: 12,
    fontWeight: '600',
  },
  rewardBadge: {
    backgroundColor: 'rgba(16,185,129,0.2)',
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 8,
  },
  rewardText: {
    color: '#10B981',
    fontSize: 12,
    fontWeight: '700',
  },
});

