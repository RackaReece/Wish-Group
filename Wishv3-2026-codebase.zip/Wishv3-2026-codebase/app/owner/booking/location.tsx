import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Modal,
  Pressable,
  TextInput,
  ActivityIndicator,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import MapView, { Marker, Region, MapPressEvent } from 'react-native-maps';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import * as Location from 'expo-location';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import GlassCard from '@/components/booking/GlassCard';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { serviceOptions } from '../../../src/constants/serviceOptions';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import { BOOKING_CARD } from '../../../src/constants/bookingCardTheme';
import { DEFAULT_MAP_REGION } from '../../../src/constants/mapConstants';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { 
  calculateDisplayPrice, 
  getVehicleSize, 
  mapServiceIdToWashId,
  FrontendPricingInput 
} from '../../../src/pricing/pricingEngine';

const { width, height } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;
const DETAILING_YELLOW = colors.DETAILING_YELLOW;
const LOCATION_CARD_GREEN = colors.ECO_GREEN;

export default function BookingLocation() {
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const serviceId = params.serviceId as string;
  const vehicleId = params.vehicleId as string;
  const washType = params.washType as 'exterior' | 'interior' | 'both' | undefined;

  const { coords: liveCoords } = useLiveLocation();
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [address, setAddress] = useState('');
  const [region, setRegion] = useState<Region | null>(null);
  const [selectedLocation, setSelectedLocation] = useState<{ latitude: number; longitude: number; address: string } | null>(null);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [offersWater, setOffersWater] = useState(false);
  const [offersElectricity, setOffersElectricity] = useState(false);
  const [vehicle, setVehicle] = useState<{ make?: string; model?: string; type?: string } | null>(null);
  const [showAddressOverlay, setShowAddressOverlay] = useState(false);
  const [addressSearchInput, setAddressSearchInput] = useState('');
  const [addressSearching, setAddressSearching] = useState(false);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const mapAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;
  const panelSlideAnim = useRef(new Animated.Value(height)).current; // Start off-screen

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(mapAnim, {
        toValue: 1,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();

    // Pulse animation for marker
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, {
          toValue: 1.2,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(markerPulse, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    ).start();

    if (liveCoords) {
      const coords = { latitude: liveCoords.latitude, longitude: liveCoords.longitude };
      setLocation(coords);
      setRegion({ ...coords, latitudeDelta: 0.002, longitudeDelta: 0.002 });
    }
    getCurrentLocation();
    loadVehicle();
  }, [vehicleId, user?.id, liveCoords]);

  const loadVehicle = async () => {
    if (!vehicleId || !user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('make, model, type')
        .eq('id', vehicleId)
        .eq('user_id', user.id)
        .single();
      
      if (error) throw error;
      setVehicle(data || null);
    } catch (error) {
      console.error('Error loading vehicle:', error);
    }
  };

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission needed', 'Location permission is required to find nearby valeters.');
        setLoading(false);
        return;
      }

      const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: loc.coords.latitude,
        longitude: loc.coords.longitude,
      };
      
      setLocation(coords);
      setRegion({ ...coords, latitudeDelta: 0.002, longitudeDelta: 0.002 });

      // Reverse geocode
      const [result] = await Location.reverseGeocodeAsync(coords);
      if (result) {
        const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim();
        setAddress(addr);
        const newLocation = { ...coords, address: addr };
        setSelectedLocation(newLocation);
        
        // Slide panel up when location is loaded
        setTimeout(() => {
          Animated.spring(panelSlideAnim, {
            toValue: 0,
            tension: 50,
            friction: 8,
            useNativeDriver: true,
          }).start();
        }, 300);
      }
    } catch (error) {
      console.error('Error getting location:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleMapPress = async (event: MapPressEvent) => {
    const coordinate = event?.nativeEvent?.coordinate;
    if (!coordinate) {
      return;
    }
    await hapticFeedback('light');
    const coords = {
      latitude: coordinate.latitude,
      longitude: coordinate.longitude,
    };
    setLocation(coords);
    setRegion({
      ...coords,
      latitudeDelta: 0.002,
      longitudeDelta: 0.002,
    });

    try {
      const [result] = await Location.reverseGeocodeAsync(coords);
      if (result) {
        const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim();
        setAddress(addr);
        const newLocation = { ...coords, address: addr };
        setSelectedLocation(newLocation);
        
        // Slide panel up when location is selected
        Animated.spring(panelSlideAnim, {
          toValue: 0,
          tension: 50,
          friction: 8,
          useNativeDriver: true,
        }).start();
      }
    } catch (error) {
      console.error('Error reverse geocoding:', error);
    }
  };

  const handleUseCurrentLocation = async () => {
    await hapticFeedback('medium');
    await getCurrentLocation();
    
    // If we get a location, trigger panel slide
    setTimeout(() => {
      if (selectedLocation || location) {
        Animated.spring(panelSlideAnim, {
          toValue: 0,
          tension: 50,
          friction: 8,
          useNativeDriver: true,
        }).start();
      }
    }, 300);
  };

  const handleContinue = async () => {
    if (!selectedLocation) {
      Alert.alert('Location Required', 'Please select a location on the map.');
      return;
    }
    await hapticFeedback('medium');
    
    const serviceOption = serviceOptions.find(s => s.id === serviceId);
    const basePrice = serviceOption?.price || 0;
    const discountAmount = (offersWater || offersElectricity) ? basePrice * 0.25 : 0;
    
    router.push({
      pathname: '/owner/booking/valeter-selection',
      params: {
        serviceId,
        vehicleId,
        latitude: selectedLocation.latitude.toString(),
        longitude: selectedLocation.longitude.toString(),
        address: selectedLocation.address,
        customerOffersWater: offersWater.toString(),
        customerOffersElectricity: offersElectricity.toString(),
        discountAmount: discountAmount.toString(),
        washType: washType || '',
      },
    });
  };

  // Calculate price using pricing engine
  const pricingBreakdown = serviceId && vehicle ? (() => {
    const washId = mapServiceIdToWashId(serviceId);
    if (!washId) return null;
    
    const vehicleSize = getVehicleSize(vehicle);
    const input: FrontendPricingInput = {
      washId,
      vehicleSize,
      isMobile: true,
      isPhysicalLocation: false,
      scheduledDateTime: new Date(), // Will be recalculated when time is selected
    };
    
    return calculateDisplayPrice(input);
  })() : null;
  
  const basePrice = pricingBreakdown?.finalDisplayPriceGBP || serviceOptions.find(s => s.id === serviceId)?.price || 0;
  const discountAmount = (offersWater || offersElectricity) ? basePrice * 0.25 : 0;
  const finalPrice = basePrice - discountAmount;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Select Location"
        subtitle="Where should we come?"
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
        rightAction={
          <TouchableOpacity onPress={handleUseCurrentLocation} style={styles.currentLocationButton}>
            <Ionicons name="locate" size={20} color={SKY} />
          </TouchableOpacity>
        }
      />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
            transform: [{ scale: mapAnim }],
          },
        ]}
      >
        {/* Map – real map with default region until location loads */}
        <View style={styles.mapContainer}>
          <MapView
            style={styles.map}
            region={region ?? DEFAULT_MAP_REGION}
            onPress={handleMapPress}
            showsUserLocation={true}
            showsMyLocationButton={false}
          >
            {location && (
              <Marker coordinate={location}>
                <Animated.View
                  style={[
                    styles.markerContainer,
                    { transform: [{ scale: markerPulse }] },
                  ]}
                >
                  <View style={styles.markerPin}>
                    <Ionicons name="location" size={24} color="#EF4444" />
                  </View>
                  <View style={styles.markerPulse} />
                </Animated.View>
              </Marker>
            )}
          </MapView>
        </View>

        {/* Location Card - Slides up from bottom when location is selected */}
        <Animated.View
          style={[
            styles.cardContainer,
            {
              transform: [{ translateY: panelSlideAnim }],
            },
          ]}
        >
          <ScrollView showsVerticalScrollIndicator={false} style={styles.scrollContainer}>
            <View style={[styles.cardStripWrapper, { borderLeftColor: LOCATION_CARD_GREEN }]}>
            <GlassCard style={styles.locationCard} borderRadius={BOOKING_CARD.BORDER_RADIUS}>
              <View style={styles.locationHeader}>
                <Ionicons name="location" size={24} color={SKY} />
                <Text style={styles.locationTitle}>Selected Location</Text>
                {selectedLocation && (
                  <TouchableOpacity
                    onPress={() => { hapticFeedback('light'); setAddressSearchInput(selectedLocation?.address ?? ''); setShowAddressOverlay(true); }}
                    style={styles.locationChangeBtn}
                    activeOpacity={0.8}
                  >
                    <Ionicons name="pencil" size={14} color={SKY} />
                    <Text style={styles.locationChangeBtnText}>Change</Text>
                  </TouchableOpacity>
                )}
              </View>
              {selectedLocation ? (
                <View style={styles.locationInfo}>
                  <Text style={styles.locationAddress}>{selectedLocation.address}</Text>
                  <View style={styles.locationCoords}>
                    <Ionicons name="map-outline" size={12} color={SKY} />
                    <Text style={styles.coordsText}>
                      {selectedLocation.latitude.toFixed(4)}, {selectedLocation.longitude.toFixed(4)}
                    </Text>
                  </View>
                </View>
              ) : (
                <Text style={styles.locationPlaceholder}>Tap on the map to select location</Text>
              )}
            </GlassCard>
            </View>

            {/* Water/Electricity Offers – same format as Wash/Detail on book service page */}
            {selectedLocation && (
              <View style={[styles.cardStripWrapper, { borderLeftColor: SKY }]}>
              <GlassCard style={styles.offersCard}>
                <View style={styles.offersHeader}>
                  <Ionicons name="gift-outline" size={20} color={SKY} />
                  <Text style={styles.offersTitle}>Offer Resources</Text>
                </View>
                <Text style={styles.offersSubtitle}>
                  Help valeters at your location
                </Text>

                <View style={styles.serviceModeToggle}>
                  <TouchableOpacity
                    onPress={() => { hapticFeedback('light'); setOffersWater((v) => !v); }}
                    activeOpacity={0.8}
                    style={styles.serviceModePill}
                  >
                    <Ionicons name="water-outline" size={18} color={offersWater ? SKY : 'rgba(135,206,235,0.5)'} />
                    <Text style={[styles.serviceModeLabel, offersWater && styles.serviceModeLabelHighlight]}>Water</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    onPress={() => { hapticFeedback('light'); setOffersElectricity((v) => !v); }}
                    activeOpacity={0.8}
                    style={styles.serviceModePill}
                  >
                    <Ionicons name="flash-outline" size={18} color={offersElectricity ? DETAILING_YELLOW : 'rgba(135,206,235,0.5)'} />
                    <Text style={[styles.serviceModeLabel, offersElectricity && styles.serviceModeLabelHighlightYellow]}>Electricity</Text>
                  </TouchableOpacity>
                </View>

                <View style={styles.priceSummary}>
                  <Text style={styles.priceLabel}>Service Price</Text>
                  <View style={styles.priceRow}>
                    <Text style={styles.originalPrice}>£{basePrice.toFixed(2)}</Text>
                  </View>
                  {pricingBreakdown && (
                    <View style={styles.priceBreakdown}>
                      {pricingBreakdown.vehicleSizeAdjustmentGBP > 0 && (
                        <Text style={styles.breakdownText}>
                          +£{pricingBreakdown.vehicleSizeAdjustmentGBP.toFixed(2)} vehicle size
                        </Text>
                      )}
                      {pricingBreakdown.surgeMultiplier > 1 && (
                        <View style={styles.surgeBadge}>
                          <Ionicons name="flash" size={12} color="#F59E0B" />
                          <Text style={styles.surgeBadgeText}>{pricingBreakdown.surgeLabel}</Text>
                        </View>
                      )}
                    </View>
                  )}
                </View>
              </GlassCard>
              </View>
            )}
          </ScrollView>

          {/* Continue Button */}
          {selectedLocation && (
            <Animated.View
              style={{
                opacity: fadeAnim,
                transform: [{ scale: fadeAnim }],
              }}
            >
              <TouchableOpacity
                onPress={handleContinue}
                style={styles.continueButton}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={[SKY, '#60A5FA']}
                  style={styles.continueGradient}
                >
                  <Text style={styles.continueText}>Continue</Text>
                  <Ionicons name="arrow-forward" size={20} color={colors.LIGHT_SKY} />
                </LinearGradient>
              </TouchableOpacity>
            </Animated.View>
          )}
        </Animated.View>
      </Animated.View>

      {/* Address search overlay */}
      <Modal visible={showAddressOverlay} transparent animationType="fade" onRequestClose={() => setShowAddressOverlay(false)}>
        <Pressable style={styles.addressOverlay} onPress={() => setShowAddressOverlay(false)}>
          <Pressable style={styles.addressOverlayContent} onPress={(e) => e.stopPropagation()}>
            <Text style={styles.addressOverlayTitle}>Change location</Text>
            <Text style={styles.addressOverlaySubtitle}>Search for an address to find it on the map</Text>
            <TextInput
              style={styles.addressOverlayInput}
              placeholder="Enter address..."
              placeholderTextColor="#64748B"
              value={addressSearchInput}
              onChangeText={setAddressSearchInput}
              onSubmitEditing={handleAddressSearch}
              returnKeyType="search"
              autoCapitalize="none"
            />
            <View style={styles.addressOverlayButtons}>
              <TouchableOpacity style={styles.addressOverlayCancel} onPress={() => setShowAddressOverlay(false)} activeOpacity={0.8}>
                <Text style={styles.addressOverlayCancelText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={[styles.addressOverlaySearchWrap, addressSearching && { opacity: 0.7 }]}
                onPress={handleAddressSearch}
                disabled={addressSearching}
                activeOpacity={0.85}
              >
                <LinearGradient colors={[SKY, '#60A5FA']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} style={styles.addressOverlaySearch}>
                  {addressSearching ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <>
                      <Ionicons name="search" size={18} color="#fff" />
                      <Text style={styles.addressOverlaySearchText}>Search</Text>
                    </>
                  )}
                </LinearGradient>
              </TouchableOpacity>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  currentLocationButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(135,206,235,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  content: {
    flex: 1,
    paddingTop: HEADER_CONTENT_OFFSET,
  },
  mapContainer: {
    position: 'absolute',
    top: 0,
    bottom: 0,
    left: 0,
    right: 0,
    zIndex: 0,
  },
  map: {
    flex: 1,
  },
  markerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  markerPin: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: colors.LIGHT_SKY,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
  },
  markerPulse: {
    position: 'absolute',
    width: 60,
    height: 60,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: '#EF4444',
    opacity: 0.3,
  },
  cardContainer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    maxHeight: height * 0.65,
    backgroundColor: customerTheme.backgroundColor,
    borderTopLeftRadius: BOOKING_CARD.BORDER_RADIUS,
    borderTopRightRadius: BOOKING_CARD.BORDER_RADIUS,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: -4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
    elevation: 16,
    zIndex: 100,
  },
  scrollContainer: {
    padding: 16,
    paddingBottom: 100,
  },
  cardStripWrapper: {
    borderLeftWidth: 4,
    marginBottom: 12,
  },
  locationCard: {
    padding: 16,
    marginBottom: 12,
  },
  locationHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 8,
  },
  locationChangeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: SKY + '18',
    borderWidth: 1.5,
    borderColor: SKY + '45',
    minHeight: 36,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 2,
  },
  locationChangeBtnText: {
    color: SKY,
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 0.2,
  },
  locationTitle: {
    color: colors.LIGHT_SKY,
    fontSize: 16,
    fontWeight: 'bold',
  },
  locationInfo: {
    gap: 8,
  },
  locationAddress: {
    color: colors.LIGHT_SKY,
    fontSize: 14,
    fontWeight: '600',
  },
  locationCoords: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  coordsText: {
    color: SKY,
    fontSize: 12,
  },
  locationPlaceholder: {
    color: '#9CA3AF',
    fontSize: 14,
    fontStyle: 'italic',
  },
  continueButton: {
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
    marginTop: 8,
    marginHorizontal: 16,
    marginBottom: 16,
  },
  continueGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 32,
    gap: 8,
  },
  continueText: {
    color: colors.LIGHT_SKY,
    fontSize: 18,
    fontWeight: 'bold',
  },
  offersCard: {
    padding: 16,
    marginTop: 8,
  },
  offersHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 2,
  },
  offersTitle: {
    color: colors.LIGHT_SKY,
    fontSize: 16,
    fontWeight: 'bold',
  },
  offersSubtitle: {
    color: SKY,
    fontSize: 11,
    marginBottom: 12,
    marginTop: 2,
  },
  serviceModeToggle: {
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 4,
    marginBottom: 12,
  },
  serviceModePill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  serviceModeLabel: {
    color: 'rgba(135,206,235,0.6)',
    fontSize: 15,
    fontWeight: '700',
  },
  serviceModeLabelHighlight: {
    color: SKY,
  },
  serviceModeLabelHighlightYellow: {
    color: DETAILING_YELLOW,
  },
  discountBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: 'rgba(16,185,129,0.15)',
    padding: 12,
    borderRadius: 8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(16,185,129,0.3)',
  },
  discountText: {
    color: '#10B981',
    fontSize: 14,
    fontWeight: '600',
  },
  priceSummary: {
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  priceLabel: {
    color: '#9CA3AF',
    fontSize: 12,
    marginBottom: 8,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  originalPrice: {
    color: '#9CA3AF',
    fontSize: 20,
    fontWeight: 'bold',
  },
  discountPrice: {
    color: '#10B981',
    fontSize: 20,
    fontWeight: 'bold',
  },
  discountTag: {
    backgroundColor: '#10B981',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  discountTagText: {
    color: colors.LIGHT_SKY,
    fontSize: 12,
    fontWeight: 'bold',
  },
  priceBreakdown: {
    marginTop: 8,
    gap: 4,
  },
  breakdownText: {
    color: '#9CA3AF',
    fontSize: 11,
  },
  surgeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    alignSelf: 'flex-start',
    backgroundColor: 'rgba(245,158,11,0.15)',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
    borderWidth: 1,
    borderColor: 'rgba(245,158,11,0.3)',
  },
  surgeBadgeText: {
    color: '#F59E0B',
    fontSize: 10,
    fontWeight: '600',
  },
  addressOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  addressOverlayContent: {
    width: '100%',
    maxWidth: 360,
    backgroundColor: '#1E293B',
    borderRadius: 18,
    padding: 24,
    borderWidth: 1.5,
    borderColor: SKY + '35',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 24,
    overflow: 'hidden',
  },
  addressOverlayTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 4,
    letterSpacing: 0.2,
  },
  addressOverlaySubtitle: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 14,
    marginBottom: 20,
    lineHeight: 20,
  },
  addressOverlayInput: {
    backgroundColor: '#0F172A',
    borderRadius: 14,
    paddingHorizontal: 18,
    paddingVertical: 16,
    color: '#F9FAFB',
    fontSize: 16,
    borderWidth: 1.5,
    borderColor: SKY + '30',
  },
  addressOverlayButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 24,
  },
  addressOverlayCancel: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 14,
    backgroundColor: 'rgba(148,163,184,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.3)',
    alignItems: 'center',
  },
  addressOverlayCancelText: {
    color: '#94A3B8',
    fontSize: 16,
    fontWeight: '700',
  },
  addressOverlaySearchWrap: {
    flex: 1,
    borderRadius: 14,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
  },
  addressOverlaySearch: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  addressOverlaySearchText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
});

