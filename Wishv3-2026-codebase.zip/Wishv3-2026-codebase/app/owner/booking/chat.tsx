import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  TextInput,
  Image,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
  Modal,
  Pressable,
} from 'react-native';
import { router, useLocalSearchParams } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import GlassCard from '@/components/booking/GlassCard';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import { supabase } from '../../../src/lib/supabase';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import { ValeterStatsService } from '../../../src/services/Valeterstatsservice';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { HEADER_CONTENT_OFFSET } from '../../../src/constants/layoutConstants';
import AppHeader from '../../../src/components/shared/AppHeader';

const SKY = colors.SKY;

type BookingRow = {
  id: string;
  service_type: string;
  service_name?: string | null;
  valeter_id?: string | null;
  location_id?: string | null;
  vehicle_type?: string | null;
  vehicle_info?: string | null;
  location_address?: string | null;
};

type Message = {
  id: string;
  sender: 'customer' | 'pro';
  text: string;
  time: string;
};

export default function BookingChat() {
  const params = useLocalSearchParams<{ bookingId: string }>();
  const bookingId = params.bookingId;
  const insets = useSafeAreaInsets();

  const [booking, setBooking] = useState<BookingRow | null>(null);
  const [proName, setProName] = useState<string>('Valeter');
  const [proPhoto, setProPhoto] = useState<string | null>(null);
  const [rating, setRating] = useState<number>(0);
  const [jobsCompleted, setJobsCompleted] = useState<number>(0);
  const [reviewCount, setReviewCount] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputText, setInputText] = useState('');
  const [profileModalVisible, setProfileModalVisible] = useState(false);
  const [optionsExpanded, setOptionsExpanded] = useState(false);
  const [valeterVehicle, setValeterVehicle] = useState<string | null>(null);
  const [valeterBio, setValeterBio] = useState<string | null>(null);
  const scrollRef = useRef<ScrollView>(null);

  useEffect(() => {
    if (!bookingId) {
      setLoading(false);
      return;
    }
    const load = async () => {
      try {
        const { data: bookingData, error: bookingError } = await supabase
          .from('bookings')
          .select('id, service_type, service_name, valeter_id, location_id, vehicle_type, vehicle_info, location_address')
          .eq('id', bookingId)
          .single();

        if (bookingError || !bookingData) {
          setBooking(null);
          setLoading(false);
          return;
        }

        const row = bookingData as BookingRow;
        setBooking(row);

        if (row.valeter_id) {
          const [profile, stats] = await Promise.all([
            fetchProfileById(row.valeter_id),
            ValeterStatsService.getValeterStats(row.valeter_id),
          ]);
          setProName(profile?.full_name || 'Valeter');
          setRating(stats.averageRating);
          setJobsCompleted(stats.totalJobs);
          setReviewCount(stats.customerReviews);

          const { data: vp } = await supabase
            .from('valeter_profiles')
            .select('profile_photo_url')
            .eq('user_id', row.valeter_id)
            .maybeSingle();
          if ((vp as any)?.profile_photo_url) setProPhoto((vp as any).profile_photo_url);
          else {
            const { data: prof } = await supabase.from('profiles').select('profile_picture').eq('id', row.valeter_id).maybeSingle();
            if ((prof as any)?.profile_picture) setProPhoto((prof as any).profile_picture);
          }
        } else if (row.location_id) {
          const { data: hub } = await supabase
            .from('car_wash_locations')
            .select('name')
            .eq('id', row.location_id)
            .maybeSingle();
          setProName((hub as any)?.name || 'Wash Hub');
        } else {
          setProName('Valeter');
        }

        setValeterBio(
          [getServiceDisplayName(row.service_type, row.service_name), row.location_address].filter(Boolean).join(' · ') || null
        );
        // Placeholder messages – replace with real chat when backend is ready
        setMessages([
          { id: '1', sender: 'pro', text: `Hi! I'm on my way for your ${getServiceDisplayName(row.service_type, row.service_name)}. See you soon.`, time: '10:32' },
          { id: '2', sender: 'customer', text: 'Thanks! I’ll be at the address.', time: '10:34' },
          { id: '3', sender: 'pro', text: 'Perfect. ETA about 8 minutes.', time: '10:35' },
        ]);
      } catch (e) {
        console.error('Chat load error', e);
        setBooking(null);
      } finally {
        setLoading(false);
      }
    };
    load();
  }, [bookingId]);

  const sendMessage = async () => {
    const trimmed = inputText.trim();
    if (!trimmed) return;
    await hapticFeedback('light');
    const newMsg: Message = {
      id: Date.now().toString(),
      sender: 'customer',
      text: trimmed,
      time: new Date().toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages((prev) => [...prev, newMsg]);
    setInputText('');
    setTimeout(() => scrollRef.current?.scrollToEnd({ animated: true }), 100);
  };

  const vehicleDisplay = booking?.vehicle_type || booking?.vehicle_info
    ? [booking.vehicle_type, booking.vehicle_info].filter(Boolean).join(' • ')
    : '—';

  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader title="Chat" subtitle="Loading…" showBack onBack={() => { hapticFeedback('light'); router.back(); }} />
        <View style={[styles.headerProfileWrap, { paddingTop: 12, paddingBottom: 12, paddingHorizontal: 16 }]}>
          <GlassCard style={styles.proCardAsHeader} accountType="customer">
            <BlurView intensity={40} tint="dark" style={StyleSheet.absoluteFill} />
            <LinearGradient colors={[SKY + '18', SKY + '08', 'transparent']} style={StyleSheet.absoluteFill} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} />
            <View style={styles.proCardInner}>
              <View style={styles.proAvatarPlaceholder}><Ionicons name="person" size={28} color={SKY} /></View>
              <View style={styles.proInfo}>
                <Text style={styles.proName}>Chat</Text>
                <Text style={styles.proSubtitle}>Loading…</Text>
              </View>
            </View>
          </GlassCard>
        </View>
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="large" color={SKY} />
          <Text style={styles.loadingText}>Loading chat…</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (!booking) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader title="Chat" subtitle="Booking not found" showBack onBack={() => { hapticFeedback('light'); router.back(); }} />
        <View style={[styles.headerProfileWrap, { paddingTop: 12, paddingBottom: 12, paddingHorizontal: 16 }]}>
          <GlassCard style={styles.proCardAsHeader} accountType="customer">
            <BlurView intensity={40} tint="dark" style={StyleSheet.absoluteFill} />
            <LinearGradient colors={[SKY + '18', SKY + '08', 'transparent']} style={StyleSheet.absoluteFill} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} />
            <View style={styles.proCardInner}>
              <View style={styles.proAvatarPlaceholder}><Ionicons name="person" size={28} color={SKY} /></View>
              <View style={styles.proInfo}>
                <Text style={styles.proName}>Chat</Text>
                <Text style={styles.proSubtitle}>Booking not found</Text>
              </View>
            </View>
          </GlassCard>
        </View>
        <View style={styles.emptyWrap}>
          <Text style={styles.emptyText}>Booking not found.</Text>
          <TouchableOpacity onPress={() => router.back()} style={styles.backBtn} activeOpacity={0.8}>
            <LinearGradient colors={[SKY, '#0EA5E9']} style={styles.backBtnGradient}>
              <Text style={styles.backBtnText}>Back</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  const serviceSubtitle = [
    getServiceDisplayName(booking.service_type, booking.service_name),
    rating > 0 ? `${rating.toFixed(1)}` : null,
  ].filter(Boolean).join(' · ');

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Dashboard-style header (matches AppHeader): tappable opens valeter profile */}
      <View style={[styles.dashboardHeaderWrap, { marginTop: insets?.top ?? 0 }]}>
        <BlurView intensity={Platform.OS === 'ios' ? 25 : 20} tint="dark" style={StyleSheet.absoluteFill} />
        <LinearGradient
          colors={['rgba(135,206,235,0.35)', 'rgba(30,58,138,0.25)']}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
        <View style={StyleSheet.absoluteFill} pointerEvents="none">
          <LinearGradient
            colors={['rgba(125,211,252,0.12)', 'transparent']}
            start={{ x: 0, y: 0 }}
            end={{ x: 0, y: 1 }}
            style={StyleSheet.absoluteFill}
          />
        </View>
        <View style={[styles.dashboardHeaderStroke, { borderColor: 'rgba(135,206,235,0.4)' }]} />
        <View style={[styles.dashboardHeaderGlow, { backgroundColor: 'rgba(135,206,235,0.6)' }]} />
        <View style={styles.dashboardHeaderContent}>
          <TouchableOpacity
            onPress={() => { hapticFeedback('light'); router.back(); }}
            style={styles.dashboardHeaderBack}
            hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
          >
            <Ionicons name="chevron-back" size={22} color="#FFFFFF" />
          </TouchableOpacity>
          <Pressable
            style={styles.dashboardHeaderCenter}
            onPress={() => { hapticFeedback('light'); setProfileModalVisible(true); }}
          >
            <Text style={styles.dashboardHeaderTitle} numberOfLines={1}>{proName}</Text>
            {serviceSubtitle ? (
              <Text style={styles.dashboardHeaderSubtitle} numberOfLines={1}>{serviceSubtitle}</Text>
            ) : null}
          </Pressable>
          <View style={styles.dashboardHeaderRight} />
        </View>
      </View>

      <KeyboardAvoidingView
        style={styles.keyboardView}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
        keyboardVerticalOffset={Platform.OS === 'ios' ? (insets?.top ?? 0) + 72 : 0}
      >
        <ScrollView
          ref={scrollRef}
          style={styles.scroll}
          contentContainerStyle={[styles.scrollContent, { paddingBottom: 120 + (insets?.bottom ?? 0) }]}
          showsVerticalScrollIndicator={false}
          onContentSizeChange={() => scrollRef.current?.scrollToEnd({ animated: false })}
        >
          <View style={styles.messagesBlock}>
            {messages.map((msg) => (
              <View
                key={msg.id}
                style={[styles.messageRow, msg.sender === 'customer' ? styles.messageRowCustomer : styles.messageRowPro]}
              >
                {msg.sender === 'pro' ? (
                  <>
                    {proPhoto ? (
                      <Image source={{ uri: proPhoto }} style={styles.msgAvatar} />
                    ) : (
                      <View style={styles.msgAvatarPlaceholder}>
                        <Ionicons name="person" size={14} color={SKY} />
                      </View>
                    )}
                    <View style={[styles.bubble, styles.bubblePro]}>
                      <Text style={styles.bubbleText}>{msg.text}</Text>
                      <Text style={styles.bubbleTime}>{msg.time}</Text>
                    </View>
                  </>
                ) : (
                  <>
                    <View style={[styles.bubble, styles.bubbleCustomer]}>
                      <Text style={styles.bubbleText}>{msg.text}</Text>
                      <Text style={styles.bubbleTime}>{msg.time}</Text>
                    </View>
                    <View style={styles.customerAvatarWrap}>
                      <Image source={require('../../../assets/car.png')} style={styles.customerAvatar} resizeMode="contain" />
                    </View>
                  </>
                )}
              </View>
            ))}
          </View>
        </ScrollView>

        {/* Floating input + options (no dark wrapper; background extends) */}
        <View style={[styles.inputWrapFloating, { paddingBottom: Math.max(insets?.bottom ?? 0, 16) + 16 }]}>
          {/* Expanded options: Photo, Voice, Call as floating icons */}
          {optionsExpanded && (
            <View style={styles.floatingOptionsRow}>
              <TouchableOpacity
                onPress={() => hapticFeedback('light')}
                style={styles.floatingIconBtn}
                activeOpacity={0.8}
              >
                <Ionicons name="image-outline" size={24} color={SKY} />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => hapticFeedback('light')}
                style={styles.floatingIconBtn}
                activeOpacity={0.8}
              >
                <Ionicons name="mic-outline" size={24} color={SKY} />
              </TouchableOpacity>
              <TouchableOpacity
                onPress={() => hapticFeedback('light')}
                style={styles.floatingIconBtn}
                activeOpacity={0.8}
              >
                <Ionicons name="call-outline" size={24} color={SKY} />
              </TouchableOpacity>
            </View>
          )}
          {/* Main row: attach, input pill, options toggle, send */}
          <View style={styles.floatingInputRow}>
            <TouchableOpacity
              onPress={() => hapticFeedback('light')}
              style={styles.floatingIconBtn}
              activeOpacity={0.8}
            >
              <Ionicons name="camera-outline" size={24} color={SKY} />
            </TouchableOpacity>
            <TextInput
              style={styles.floatingInput}
              placeholder="Type a message…"
              placeholderTextColor="#64748B"
              value={inputText}
              onChangeText={setInputText}
              multiline
              maxLength={500}
              editable
            />
            <TouchableOpacity
              onPress={() => { hapticFeedback('light'); setOptionsExpanded((v) => !v); }}
              style={[styles.floatingIconBtn, optionsExpanded && styles.floatingIconBtnActive]}
              activeOpacity={0.8}
            >
              <Ionicons name="ellipsis-horizontal" size={24} color={SKY} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={sendMessage}
              style={[styles.floatingSendBtn, !inputText.trim() && styles.floatingSendBtnDisabled]}
              activeOpacity={0.85}
              disabled={!inputText.trim()}
            >
              <Ionicons name="send" size={20} color={inputText.trim() ? '#FFFFFF' : '#64748B'} />
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>

      {/* Valeter full profile modal */}
      <Modal
        visible={profileModalVisible}
        animationType="slide"
        transparent
        onRequestClose={() => setProfileModalVisible(false)}
      >
        <Pressable style={styles.modalOverlay} onPress={() => setProfileModalVisible(false)}>
          <Pressable style={styles.modalCard} onPress={(e) => e.stopPropagation()}>
            <BlurView intensity={40} tint="dark" style={StyleSheet.absoluteFill} />
            <LinearGradient colors={[SKY + '15', 'rgba(15,23,42,0.95)']} style={StyleSheet.absoluteFill} />
            <View style={[styles.modalStroke, { borderColor: SKY + '35' }]} />
            <View style={styles.modalCloseRow}>
              <Text style={styles.modalTitle}>Valeter profile</Text>
              <TouchableOpacity
                onPress={() => { hapticFeedback('light'); setProfileModalVisible(false); }}
                style={styles.modalCloseBtn}
                hitSlop={12}
              >
                <Ionicons name="close" size={24} color="#F1F5F9" />
              </TouchableOpacity>
            </View>
            <View style={styles.modalAvatarSection}>
              {proPhoto ? (
                <Image source={{ uri: proPhoto }} style={styles.modalAvatar} />
              ) : (
                <View style={styles.modalAvatarPlaceholder}>
                  <Ionicons name="person" size={48} color={SKY} />
                </View>
              )}
              <Text style={styles.modalName}>{proName}</Text>
              <View style={styles.modalRatingRow}>
                <Ionicons name="star" size={16} color="#FBBF24" />
                <Text style={styles.modalRatingText}>{rating > 0 ? rating.toFixed(1) : '—'}</Text>
                <Text style={styles.modalMetaText}> · {jobsCompleted} jobs</Text>
                <Text style={styles.modalMetaText}> · {reviewCount} reviews</Text>
              </View>
            </View>
            {valeterBio ? (
              <View style={styles.modalSection}>
                <Text style={styles.modalSectionTitle}>This wash</Text>
                <Text style={styles.modalSectionBody}>{valeterBio}</Text>
              </View>
            ) : null}
            <View style={styles.modalSection}>
              <Text style={styles.modalSectionTitle}>Valeter vehicle</Text>
              <Text style={styles.modalSectionBody}>{valeterVehicle || '—'}</Text>
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  loadingWrap: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    gap: 12,
  },
  loadingText: { color: SKY, fontSize: 15 },
  emptyWrap: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  emptyText: { color: '#94A3B8', fontSize: 16, marginBottom: 20 },
  keyboardView: { flex: 1 },
  scroll: { flex: 1 },
  scrollContent: {
    paddingHorizontal: 20,
    paddingTop: 16,
  },
  dashboardHeaderWrap: {
    marginHorizontal: 0,
    borderRadius: 28,
    overflow: 'hidden',
    backgroundColor: 'transparent',
    position: 'relative',
    minHeight: 72,
  },
  dashboardHeaderStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
    borderRadius: 28,
  },
  dashboardHeaderGlow: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: 2,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.6,
    shadowRadius: 6,
    borderRadius: 28,
  },
  dashboardHeaderContent: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 12,
    paddingBottom: 16,
    minHeight: 44,
  },
  dashboardHeaderBack: {
    width: 40,
    height: 40,
    borderRadius: 20,
    justifyContent: 'center',
    alignItems: 'center',
  },
  dashboardHeaderCenter: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    minWidth: 0,
    paddingHorizontal: 8,
  },
  dashboardHeaderTitle: {
    color: '#F8FAFC',
    fontSize: 17,
    fontWeight: '700',
  },
  dashboardHeaderSubtitle: {
    color: 'rgba(248,250,252,0.9)',
    fontSize: 13,
    marginTop: 2,
  },
  dashboardHeaderRight: { width: 40 },
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalCard: {
    width: '100%',
    maxWidth: 380,
    borderRadius: 18,
    overflow: 'hidden',
    position: 'relative',
  },
  modalStroke: {
    ...StyleSheet.absoluteFillObject,
    borderWidth: 1.5,
    borderRadius: 18,
  },
  modalCloseRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 20,
    paddingBottom: 8,
  },
  modalTitle: { color: '#F1F5F9', fontSize: 18, fontWeight: '700' },
  modalCloseBtn: { padding: 4 },
  modalAvatarSection: {
    alignItems: 'center',
    paddingVertical: 20,
    paddingHorizontal: 20,
  },
  modalAvatar: { width: 88, height: 88, borderRadius: 44, borderWidth: 2, borderColor: SKY + '50' },
  modalAvatarPlaceholder: {
    width: 88,
    height: 88,
    borderRadius: 44,
    backgroundColor: SKY + '20',
    borderWidth: 2,
    borderColor: SKY + '40',
    justifyContent: 'center',
    alignItems: 'center',
  },
  modalName: { color: '#F9FAFB', fontSize: 22, fontWeight: '700', marginTop: 12 },
  modalRatingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
    gap: 4,
  },
  modalRatingText: { color: '#FBBF24', fontSize: 15, fontWeight: '700' },
  modalMetaText: { color: '#94A3B8', fontSize: 13 },
  modalSection: {
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  modalSectionTitle: {
    color: SKY,
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 6,
    textTransform: 'uppercase',
  },
  modalSectionBody: {
    color: '#E2E8F0',
    fontSize: 15,
    lineHeight: 22,
  },
  headerProfileWrap: { paddingHorizontal: 16 },
  proCardAsHeader: { padding: 14, borderRadius: 14 },
  proCardInner: { flexDirection: 'row', alignItems: 'center' },
  proAvatarWrap: { marginRight: 12 },
  proAvatar: { width: 48, height: 48, borderRadius: 24 },
  proAvatarPlaceholder: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: SKY + '20',
    justifyContent: 'center',
    alignItems: 'center',
  },
  proInfo: { flex: 1, minWidth: 0 },
  proName: { color: '#F9FAFB', fontSize: 16, fontWeight: '700' },
  proStatsRow: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap', gap: 6 },
  proStat: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  proStatText: { color: '#94A3B8', fontSize: 12 },
  proStatDot: { color: '#64748B', fontSize: 12 },
  vehicleRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  vehicleIcon: { width: 18, height: 18 },
  vehicleText: { color: '#94A3B8', fontSize: 12, flex: 1 },
  addressRow: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  addressText: { color: '#94A3B8', fontSize: 12, flex: 1 },
  chatHeaderOuter: {
    paddingHorizontal: 16,
    paddingBottom: 8,
  },
  chatHeaderBar: {
    flexDirection: 'row',
    borderRadius: 14,
    overflow: 'hidden',
    backgroundColor: 'rgba(30,41,59,0.6)',
    borderWidth: 1,
    borderColor: SKY + '20',
    minHeight: 72,
    position: 'relative',
  },
  chatHeaderBack: {
    width: 44,
    justifyContent: 'center',
    alignItems: 'center',
  },
  chatHeaderStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 4,
    borderTopLeftRadius: 14,
    borderBottomLeftRadius: 14,
  },
  chatHeaderInner: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 14,
    paddingLeft: 18,
    flex: 1,
  },
  chatHeaderAvatarWrap: { marginRight: 12 },
  chatHeaderAvatar: {
    width: 44,
    height: 44,
    borderRadius: 18,
    borderWidth: 1.5,
    borderColor: SKY + '40',
  },
  chatHeaderAvatarPlaceholder: {
    width: 44,
    height: 44,
    borderRadius: 18,
    backgroundColor: SKY + '18',
    borderWidth: 1.5,
    borderColor: SKY + '35',
    justifyContent: 'center',
    alignItems: 'center',
  },
  chatHeaderInfo: { flex: 1, minWidth: 0 },
  chatHeaderName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
    marginBottom: 2,
  },
  chatHeaderService: {
    color: SKY,
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 2,
  },
  chatHeaderMeta: { gap: 2 },
  chatHeaderMetaText: {
    color: '#94A3B8',
    fontSize: 11,
    fontWeight: '500',
  },
  messagesBlock: { gap: 16 },
  messageRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
  },
  messageRowPro: { justifyContent: 'flex-start' },
  messageRowCustomer: { justifyContent: 'flex-end' },
  msgAvatar: { width: 28, height: 28, borderRadius: 14 },
  msgAvatarPlaceholder: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: SKY + '25',
    justifyContent: 'center',
    alignItems: 'center',
  },
  bubble: {
    maxWidth: '80%',
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 20,
  },
  bubblePro: {
    backgroundColor: 'rgba(30,41,59,0.85)',
    borderBottomLeftRadius: 6,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.2)',
  },
  bubbleCustomer: {
    backgroundColor: SKY + '30',
    borderBottomRightRadius: 6,
    borderWidth: 1,
    borderColor: SKY + '45',
  },
  bubbleText: {
    color: '#F1F5F9',
    fontSize: 15,
    lineHeight: 22,
    fontWeight: '500',
  },
  bubbleTime: {
    color: 'rgba(148,163,184,0.85)',
    fontSize: 11,
    marginTop: 6,
    fontWeight: '500',
  },
  customerAvatarWrap: {
    width: 28,
    height: 28,
    borderRadius: 14,
    backgroundColor: SKY + '20',
    borderWidth: 1,
    borderColor: SKY + '40',
    justifyContent: 'center',
    alignItems: 'center',
  },
  customerAvatar: { width: 16, height: 16 },
  inputWrap: {
    paddingHorizontal: 16,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.12)',
    overflow: 'hidden',
    position: 'relative',
  },
  inputWrapFixed: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
  },
  inputWrapFloating: {
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 16,
    backgroundColor: 'transparent',
  },
  floatingOptionsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    gap: 10,
    marginBottom: 10,
  },
  floatingIconBtn: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: 'rgba(30,41,59,0.5)',
    borderWidth: 1,
    borderColor: SKY + '25',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  floatingIconBtnActive: {
    backgroundColor: SKY + '30',
    borderColor: SKY + '50',
  },
  floatingInputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
  },
  floatingInput: {
    flex: 1,
    minHeight: 48,
    maxHeight: 120,
    backgroundColor: 'rgba(30,41,59,0.5)',
    borderRadius: 18,
    paddingHorizontal: 20,
    paddingVertical: 14,
    paddingTop: 14,
    color: '#F1F5F9',
    fontSize: 15,
    borderWidth: 1,
    borderColor: SKY + '25',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 4,
  },
  floatingSendBtn: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 6,
    elevation: 4,
  },
  floatingSendBtnDisabled: {
    backgroundColor: 'rgba(100,116,139,0.5)',
    shadowOpacity: 0,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    gap: 10,
  },
  input: {
    flex: 1,
    minHeight: 48,
    maxHeight: 120,
    backgroundColor: 'rgba(30,41,59,0.85)',
    borderRadius: 18,
    paddingHorizontal: 20,
    paddingVertical: 14,
    paddingTop: 14,
    color: '#F1F5F9',
    fontSize: 15,
    borderWidth: 1,
    borderColor: SKY + '22',
  },
  sendBtn: {
    width: 48,
    height: 48,
    borderRadius: 18,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
  },
  sendBtnDisabled: {
    backgroundColor: 'rgba(100,116,139,0.4)',
  },
  backBtn: { borderRadius: 14, overflow: 'hidden' },
  backBtnGradient: {
    paddingVertical: 14,
    paddingHorizontal: 24,
    alignItems: 'center',
  },
  backBtnText: { color: '#FFFFFF', fontSize: 16, fontWeight: '700' },
});
