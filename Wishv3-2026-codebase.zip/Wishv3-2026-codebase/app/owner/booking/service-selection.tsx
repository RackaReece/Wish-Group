import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { customerTheme } from '../../../src/constants/customerTheme';
import { BOOKING_CARD } from '../../../src/constants/bookingCardTheme';
import { colors } from '../../../src/constants/colors';
import { DEFAULT_MAP_REGION } from '../../../src/constants/mapConstants';
import { serviceOptions, ServiceOption } from '../../../src/constants/serviceOptions';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import AppHeader from '../../../src/components/shared/AppHeader';
import {
  WWBottomSheet,
  WWPrimaryButton,
  WashTierCard,
  WWSectionHeader,
} from '../../../src/components/ui';
import type { BottomSheetState, WashTier } from '../../../src/components/ui';

const { height } = Dimensions.get('window');
const SKY = '#5B8FA8';

// Dark map style
const darkMapStyle = [
  { elementType: 'geometry', stylers: [{ color: '#242f3e' }] },
  { elementType: 'labels.text.fill', stylers: [{ color: '#746855' }] },
  { featureType: 'water', stylers: [{ color: '#17263c' }] },
];

export default function ServiceSelection() {
  useAuth();
  const params = useLocalSearchParams();
  const vehicleId = params.vehicleId as string;
  const locationLat = params.locationLat ? Number.parseFloat(params.locationLat as string) : null;
  const locationLng = params.locationLng ? Number.parseFloat(params.locationLng as string) : null;

  const [selectedTier, setSelectedTier] = useState<WashTier | null>(null);
  const [infoService, setInfoService] = useState<ServiceOption | null>(null);
  const [sheetState, setSheetState] = useState<BottomSheetState>('half');

  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);

  useEffect(() => {
    const lat = locationLat != null && locationLng != null ? locationLat : liveCoords?.latitude;
    const lng = locationLat != null && locationLng != null ? locationLng : liveCoords?.longitude;
    if (lat != null && lng != null) {
      setUserLocation({ latitude: lat, longitude: lng });
      setRegion({ latitude: lat, longitude: lng, latitudeDelta: 0.002, longitudeDelta: 0.002 });
    } else {
      Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced })
        .then((loc) => {
          const c = { latitude: loc.coords.latitude, longitude: loc.coords.longitude };
          setUserLocation(c);
          setRegion({ ...c, latitudeDelta: 0.002, longitudeDelta: 0.002 });
        })
        .catch((err) => console.warn('Error getting location:', err));
    }
  }, [locationLat, locationLng, liveCoords]);

  const handleTierSelect = (tier: WashTier) => {
    setSelectedTier(tier);
    setSheetState('half');
  };

  const handleContinue = () => {
    if (!selectedTier || !vehicleId) return;

    const serviceMap: Record<WashTier, string> = {
      Bronze: 'bronze-wash',
      Silver: 'silver-wash',
      Gold: 'gold-wash',
    };

    router.push({
      pathname: '/owner/booking/valeter-selection',
      params: {
        serviceId: serviceMap[selectedTier],
        vehicleId,
        locationLat: locationLat?.toString() || userLocation?.latitude.toString(),
        locationLng: locationLng?.toString() || userLocation?.longitude.toString(),
      },
    } as any);
  };

  const handleBack = () => router.back();

  const handleLocate = async () => {
    try {
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const c = { latitude: location.coords.latitude, longitude: location.coords.longitude };
      setUserLocation(c);
      setRegion({ ...c, latitudeDelta: 0.002, longitudeDelta: 0.002 });
    } catch (err) {
      console.warn('Error locating:', err);
    }
  };

  const bronzeService = serviceOptions.find(s => s.id === 'bronze-wash');
  const silverService = serviceOptions.find(s => s.id === 'silver-wash');
  const goldService = serviceOptions.find(s => s.id === 'gold-wash');

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Map – real map with default region until location loads */}
      <MapView
        style={StyleSheet.absoluteFill}
        region={region ?? DEFAULT_MAP_REGION}
        customMapStyle={darkMapStyle}
        showsUserLocation
        showsMyLocationButton={false}
        toolbarEnabled={false}
      >
        {userLocation && (
          <Marker coordinate={userLocation}>
            <View style={styles.userMarker}>
              <View style={styles.markerPulse} />
              <View style={styles.markerInner}>
                <Ionicons name="person" size={16} color={SKY} />
              </View>
            </View>
          </Marker>
        )}
      </MapView>

      <AppHeader
        title="Choose a wash"
        subtitle="Select your preferred service tier"
        showBack
        onBack={handleBack}
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              handleLocate();
            }}
            style={{ padding: 8 }}
            activeOpacity={0.7}
          >
            <Ionicons name="locate" size={22} color={SKY} />
          </TouchableOpacity>
        }
      />

      <WWBottomSheet
        state={sheetState}
        onStateChange={setSheetState}
        collapsedHeight={height * 0.15}
        halfHeight={height * 0.55}
        fullHeight={height * 0.85}
      >
        <WWSectionHeader
          title="Choose a wash"
          subtitle="Select your preferred service tier"
        />

        <View style={styles.servicesContainer}>
          {bronzeService && (
            <WashTierCard
              tier="Bronze"
              duration={bronzeService.dur}
              price={`£${bronzeService.price}`}
              perks={bronzeService.bulletPoints ?? []}
              selected={selectedTier === 'Bronze'}
              onPress={() => handleTierSelect('Bronze')}
              onInfoPress={() => setInfoService(bronzeService)}
            />
          )}

          {silverService && (
            <WashTierCard
              tier="Silver"
              duration={silverService.dur}
              price={`£${silverService.price}`}
              perks={silverService.bulletPoints ?? []}
              selected={selectedTier === 'Silver'}
              onPress={() => handleTierSelect('Silver')}
              onInfoPress={() => setInfoService(silverService)}
            />
          )}

          {goldService && (
            <WashTierCard
              tier="Gold"
              duration={goldService.dur}
              price={`£${goldService.price}`}
              perks={goldService.bulletPoints ?? []}
              selected={selectedTier === 'Gold'}
              onPress={() => handleTierSelect('Gold')}
              onInfoPress={() => setInfoService(goldService)}
            />
          )}
        </View>
      </WWBottomSheet>

      {selectedTier && (
        <View style={styles.footer}>
          <WWPrimaryButton title="Continue" onPress={handleContinue} />
        </View>
      )}

      {/* INFO MODAL */}
      {infoService && (
        <View style={styles.infoOverlay}>
          <View style={styles.infoCard}>
            <View style={styles.infoCardHeader}>
              <Text style={styles.infoTitle}>{infoService.name}</Text>
              <TouchableOpacity onPress={() => setInfoService(null)} hitSlop={12}>
                <Ionicons name="close" size={24} color={customerTheme.primary} />
              </TouchableOpacity>
            </View>
            <Text style={styles.infoDesc}>{infoService.desc}</Text>

            {infoService.bulletPoints?.map((point) => (
              <Text key={point} style={styles.infoBullet}>• {point}</Text>
            ))}
          </View>
        </View>
      )}
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },

  userMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  markerPulse: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: `${SKY}30`,
  },
  markerInner: {
    width: 32,
    height: 32,
    borderRadius: 18,
    backgroundColor: '#0A1929',
    borderWidth: 2,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
  },

  servicesContainer: {
    paddingTop: 8,
  },

  footer: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    paddingHorizontal: 20,
    paddingBottom: 20,
    paddingTop: 12,
    backgroundColor: 'rgba(15, 23, 42, 0.95)',
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.1)',
  },

  infoOverlay: {
    position: 'absolute',
    inset: 0,
    backgroundColor: 'rgba(10,25,41,0.78)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },

  infoCard: {
    width: '100%',
    maxWidth: 420,
    backgroundColor: customerTheme.backgroundColor,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(126,184,212,0.35)',
  },

  infoCardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
    paddingBottom: 10,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(126,184,212,0.2)',
  },

  infoTitle: {
    fontSize: 18,
    fontWeight: '800',
    color: customerTheme.primary,
    flex: 1,
  },

  infoDesc: {
    color: colors.headerSubtext,
    fontSize: 13,
    lineHeight: 20,
    marginBottom: 12,
    opacity: 0.95,
  },

  infoBullet: {
    color: colors.headerText,
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 6,
    opacity: 0.92,
  },
});
