import React from 'react';
import DetailingPhysicalVehicleSelection from './_physical';

export default function DetailingVehicleScreen() {
  return <DetailingPhysicalVehicleSelection />;
}
