import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Alert,
  Image,
  Modal,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { hapticFeedback } from '../../../../../src/services/HapticFeedbackService';
import GlassCard from '@/components/booking/GlassCard';
import { BOOKING_CARD } from '../../../../../src/constants/bookingCardTheme';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../../../src/components/shared/AppHeader';
import { colors } from '../../../../../src/constants/colors';
import { RECENTER_BUTTON_RIGHT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '../../../../../src/constants/mapConstants';
import { customerTheme } from '../../../../../src/constants/customerTheme';
import { supabase } from '../../../../../src/lib/supabase';
import { detailingServiceOptions } from '../../../../../src/constants/serviceOptions';
const { width, height } = Dimensions.get('window');
const SKY = colors.SKY;
const BG = colors.BG;
const DETAILING_YELLOW = colors.DETAILING_YELLOW;
const CARD_WIDTH = BOOKING_CARD.CARD_WIDTH;

// Uber-style dark map theme
const uberDarkMapStyle = [
  {
    elementType: 'geometry',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#242f3e' }],
  },
  {
    elementType: 'labels.text.fill',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'administrative.locality',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'geometry',
    stylers: [{ color: '#263c3f' }],
  },
  {
    featureType: 'poi.park',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#6b9a76' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry',
    stylers: [{ color: '#38414e' }],
  },
  {
    featureType: 'road',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#212a37' }],
  },
  {
    featureType: 'road',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#9ca5b3' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry',
    stylers: [{ color: '#746855' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'geometry.stroke',
    stylers: [{ color: '#1f2835' }],
  },
  {
    featureType: 'road.highway',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#f3d19c' }],
  },
  {
    featureType: 'transit',
    elementType: 'geometry',
    stylers: [{ color: '#2f3948' }],
  },
  {
    featureType: 'transit.station',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#d59563' }],
  },
  {
    featureType: 'water',
    elementType: 'geometry',
    stylers: [{ color: '#17263c' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.fill',
    stylers: [{ color: '#515c6d' }],
  },
  {
    featureType: 'water',
    elementType: 'labels.text.stroke',
    stylers: [{ color: '#17263c' }],
  },
];

// Derive UI colors from option hex (e.g. #EAB308 -> main, light, border)
function detailColors(hex: string): { main: string; light: string; border: string } {
  const main = hex;
  const light = hex + '40';
  const border = hex + '80';
  return { main, light, border };
}

type ServiceUI = {
  id: string;
  name: string;
  desc: string;
  dur: string;
  minutes: number;
  price: number;
  is_enabled: boolean;
  badge?: string;
  bulletPoints?: string[];
  icon: string;
  main: string;
  light: string;
  border: string;
};

function money(n: any) {
  let v = 0;
  if (typeof n === 'string') v = Number(n);
  else if (typeof n === 'number') v = n;
  if (!Number.isFinite(v)) return 0;
  return v;
}

export default function PhysicalServiceSelection() {
  const insets = useSafeAreaInsets();
  const params = useLocalSearchParams();
  const locationId = params.locationId as string;
  const vehicleId = params.vehicleId as string;
  const scheduledAt = params.scheduledAt as string | undefined;

  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [infoModalService, setInfoModalService] = useState<ServiceUI | null>(null);
  const scrollViewRef = useRef<ScrollView>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  const [loading, setLoading] = useState(true);
  const [services, setServices] = useState<ServiceUI[]>([]);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [hubLocation, setHubLocation] = useState<{ latitude: number; longitude: number; name: string; address: string } | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [region, setRegion] = useState<Region>({
    latitude: 51.5074,
    longitude: -0.1278,
    latitudeDelta: 0.002,
    longitudeDelta: 0.002,
  });

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    getCurrentLocation();
    if (!locationId) {
      setLoading(false);
      setLoadError('Missing location.');
      return;
    }
    loadHubLocation();
    loadServicePrices();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [locationId]);

  const getCurrentLocation = async () => {
    try {
      const { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') return;
      const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
      const coords = {
        latitude: location.coords.latitude,
        longitude: location.coords.longitude,
      };
      setUserLocation(coords);
    } catch {}
  };

  const loadHubLocation = async () => {
    try {
      const { data, error } = await supabase
        .from('car_wash_locations')
        .select('id, name, address, latitude, longitude')
        .eq('id', locationId)
        .single();

      if (error) throw error;
      if (data?.latitude != null && data?.longitude != null) {
        const hub = {
          latitude: Number(data.latitude),
          longitude: Number(data.longitude),
          name: data.name || 'Detail Hub',
          address: data.address || '',
        };
        setHubLocation(hub);
        setRegion({
          latitude: hub.latitude,
          longitude: hub.longitude,
          latitudeDelta: 0.002,
          longitudeDelta: 0.002,
        });
      }
    } catch (err) {
      console.error('Error loading hub location:', err);
    }
  };

  const parseMinutesFromDur = (dur: string): number => {
    const rangeRegex = /(\d+)\s*[–-]\s*(\d+)\s*hours?/i;
    const singleRegex = /(\d+)\s*hours?/i;
    const m = rangeRegex.exec(dur) ?? singleRegex.exec(dur);
    if (m) {
      const a = Number(m[1]);
      const b = m[2] ? Number(m[2]) : a;
      return Math.round(((a + b) / 2) * 60);
    }
    const minRegex = /(\d+)\s*min/i;
    const mins = minRegex.exec(dur);
    return mins ? Number(mins[1]) : 60;
  };

  const loadServicePrices = async () => {
    try {
      setLoading(true);
      setLoadError(null);

      const { data, error } = await supabase
        .from('location_services')
        .select('service_name, price, duration_minutes, is_enabled')
        .eq('location_id', locationId);

      if (error) throw error;

      const rows = (data || []) as Array<{
        service_name: string | null;
        price: number | null;
        duration_minutes: number | null;
        is_enabled: boolean | null;
      }>;

      const map = new Map<string, { price: number; minutes: number; enabled: boolean }>();
      rows.forEach((r) => {
        const name = (r.service_name || '').trim();
        if (!name) return;
        map.set(name, {
          price: money(r.price),
          minutes: typeof r.duration_minutes === 'number' && r.duration_minutes > 0 ? r.duration_minutes : 0,
          enabled: r.is_enabled === null || r.is_enabled === undefined ? true : !!r.is_enabled,
        });
      });

      const built: ServiceUI[] = detailingServiceOptions.map((opt) => {
        const hit = map.get(opt.name);
        const defaultMinutes = parseMinutesFromDur(opt.dur);
        const minutes = hit?.minutes ? hit.minutes : defaultMinutes;
        const durText = minutes >= 60 ? `${Math.round(minutes / 60)}h` : `${minutes} min`;
        const { main, light, border } = detailColors(opt.colors[0]);
        return {
          id: opt.id,
          name: opt.name,
          desc: opt.desc,
          minutes,
          dur: durText,
          price: hit?.price ?? opt.price,
          is_enabled: hit?.enabled ?? true,
          bulletPoints: opt.bulletPoints || [],
          icon: opt.icon,
          main,
          light,
          border,
        };
      }).filter((s) => s.is_enabled);

      setServices(built);

      setSelectedService((prev) => {
        if (!prev) return prev;
        const stillThere = built.some((b) => b.id === prev);
        return stillThere ? prev : null;
      });
    } catch (e: any) {
      console.error('[PhysicalServiceSelection] loadServicePrices error:', e);
      setLoadError(e?.message || 'Failed to load pricing.');
      setServices([]);
    } finally {
      setLoading(false);
    }
  };

  const handleServiceSelect = async (serviceId: string) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
  };

  const selectedServiceData = useMemo(
    () => services.find((s) => s.id === selectedService) || null,
    [services, selectedService]
  );

  // Calculate pricing tiers (small/medium/large)
  const getPriceTiers = (basePrice: number) => {
    return {
      small: basePrice,
      medium: Math.round(basePrice * 1.2 * 100) / 100,
      large: Math.round(basePrice * 1.4 * 100) / 100,
    };
  };

  const canContinue =
    !!selectedService &&
    !!locationId &&
    !!vehicleId;

  const handleContinue = async () => {
    if (!canContinue) return;

    if (!selectedServiceData || !Number.isFinite(selectedServiceData.price) || selectedServiceData.price <= 0) {
      Alert.alert('Unavailable', 'This service does not have a price set yet. Please pick another option.');
      return;
    }

    await hapticFeedback('medium');

    const baseParams = {
      serviceId: selectedService,
      vehicleId,
      locationId,
      washType: '',
      price: String(selectedServiceData.price),
    };

    if (scheduledAt) {
      router.push({
        pathname: '/owner/booking/detailing/physical/confirm',
        params: { ...baseParams, scheduledAt },
      });
    } else {
      router.push({
        pathname: '/owner/booking/detailing/physical/schedule',
        params: baseParams,
      });
    }
  };

  const handleExitBooking = async () => {
    await hapticFeedback('light');
    router.replace('/owner/owner-dashboard' as any);
  };

  const handleRecenter = async () => {
    await hapticFeedback('light');
    if (hubLocation) {
      setRegion({
        latitude: hubLocation.latitude,
        longitude: hubLocation.longitude,
        latitudeDelta: 0.002,
        longitudeDelta: 0.002,
      });
    } else if (userLocation) {
      setRegion({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.002,
        longitudeDelta: 0.002,
      });
    }
  };


  if (loading) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader 
          title="Select Service" 
          showBack={true}
          onBack={() => router.back()}
          primaryColor={DETAILING_YELLOW}
        />
        <View style={styles.loadingWrap}>
          <ActivityIndicator size="large" color={DETAILING_YELLOW} />
          <Text style={styles.loadingText}>Loading prices...</Text>
        </View>
      </SafeAreaView>
    );
  }

  if (loadError) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader 
          title="Select Service" 
          showBack={true}
          onBack={() => router.back()}
          primaryColor={DETAILING_YELLOW}
        />
        <View style={styles.loadingWrap}>
          <Ionicons name="alert-circle-outline" size={44} color={DETAILING_YELLOW} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>{loadError}</Text>
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              loadServicePrices();
            }}
            style={styles.retryBtn}
            activeOpacity={0.85}
          >
            <LinearGradient colors={[DETAILING_YELLOW, colors.DETAILING_YELLOW_DARK]} style={styles.retryGrad}>
              <Ionicons name="refresh" size={18} color="#fff" />
              <Text style={styles.retryText}>Retry</Text>
            </LinearGradient>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  if (!services.length) {
    return (
      <SafeAreaView style={styles.container} edges={[]}>
        <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
        <AppHeader 
          title="Select Service" 
          showBack={true}
          onBack={() => router.back()}
          primaryColor={DETAILING_YELLOW}
        />
        <View style={styles.loadingWrap}>
          <Ionicons name="pricetag-outline" size={44} color={DETAILING_YELLOW} style={{ opacity: 0.9 }} />
          <Text style={[styles.loadingText, { textAlign: 'center', maxWidth: 320 }]}>
            This location hasn't enabled any services yet.
          </Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Fullscreen map */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={uberDarkMapStyle}
        >
          {/* User location marker */}
          {userLocation && (
            <Marker coordinate={userLocation}>
<View style={styles.userMarkerContainer}>
                <Image
                  source={require('../../../../../assets/car.png')} 
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {/* Hub location marker */}
          {hubLocation && (
            <Marker coordinate={{ latitude: hubLocation.latitude, longitude: hubLocation.longitude }}>
              <View style={styles.hubMarkerContainer}>
                <Image 
                  source={require('../../../../../assets/cleaning.png')} 
                  style={styles.hubMarkerImage}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      <TouchableOpacity
        onPress={handleRecenter}
        style={[styles.recenterButtonFloating, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS, right: RECENTER_BUTTON_RIGHT }]}
        activeOpacity={0.7}
      >
        <Ionicons name="locate" size={22} color={DETAILING_YELLOW} />
      </TouchableOpacity>

      <AppHeader 
        title="Select Service" 
        subtitle={hubLocation?.name || 'Choose your wash service'}
        showBack={true}
        onBack={() => router.back()}
        primaryColor={DETAILING_YELLOW}
        rightAction={
          <TouchableOpacity 
            onPress={handleExitBooking} 
            style={styles.exitButton}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={22} color="#FFFFFF" />
          </TouchableOpacity>
        }
      />

      {/* Service cards - floating at bottom */}
      <Animated.View
        style={[
          styles.cardContainer,
          {
            opacity: fadeAnim,
            bottom: 96 + Math.max(insets.bottom, 14),
          },
        ]}
      >
        <ScrollView
          ref={scrollViewRef}
          horizontal
          showsHorizontalScrollIndicator={false}
          snapToInterval={BOOKING_CARD.SNAP_INTERVAL}
          decelerationRate="fast"
          contentContainerStyle={styles.cardsScrollContent}
          onMomentumScrollEnd={(e) => {
            const index = Math.round(e.nativeEvent.contentOffset.x / BOOKING_CARD.SNAP_INTERVAL);
            if (services[index]) {
              handleServiceSelect(services[index].id);
            }
          }}
        >
          {services.map((service) => {
            const isSelected = selectedService === service.id;
            const tierColor = { main: service.main, light: service.light, border: service.border };

            return (
              <View
                key={service.id}
                style={[
                  styles.cardWrapper,
                  styles.cardStrip,
                  { width: CARD_WIDTH, borderLeftColor: DETAILING_YELLOW },
                ]}
              >
                <GlassCard
                  onPress={() => handleServiceSelect(service.id)}
                  style={[
                    styles.serviceCard,
                    isSelected && styles.serviceCardSelected,
                    isSelected && {
                      borderWidth: 0,
                      borderColor: 'transparent',
                      shadowColor: tierColor.main,
                      shadowOpacity: 0.35,
                    },
                  ]}
                  borderColor={undefined}
                  borderRadius={BOOKING_CARD.BORDER_RADIUS}
                  intensity={52}
                  accountType="customer"
                >
                  <TouchableOpacity
                    style={styles.serviceCardInfoBtn}
                    onPress={(e) => { e.stopPropagation(); hapticFeedback('light'); setInfoModalService(service); }}
                    hitSlop={8}
                  >
                    <Ionicons name="information-circle-outline" size={20} color={DETAILING_YELLOW} />
                  </TouchableOpacity>
                  {service.badge ? (
                    <View style={[styles.badgePill, { backgroundColor: tierColor.main }]} pointerEvents="none">
                      <Text style={styles.badgePillText} numberOfLines={1}>{service.badge}</Text>
                    </View>
                  ) : null}
                  <View style={styles.cardInner}>
                    <View style={styles.cardContentRow}>
                      <View style={styles.cardMain}>
                        <View style={styles.cardHeader}>
                          <View style={[styles.serviceIconWrap, { backgroundColor: tierColor.light, borderColor: tierColor.border }]}>
                            <Ionicons name={service.icon as any} size={28} color={tierColor.main} />
                          </View>
                          {isSelected && (
                            <View style={[styles.selectedCheck, { backgroundColor: tierColor.main }]}>
                              <Ionicons name="checkmark" size={14} color="#0F172A" />
                            </View>
                          )}
                        </View>
                        <Text style={styles.serviceName} numberOfLines={1}>{service.name}</Text>
                        <View style={styles.statsRow}>
                          <View style={styles.statPill}>
                            <Ionicons name="time-outline" size={13} color="#94A3B8" />
                            <Text style={styles.statText}>{service.dur}</Text>
                          </View>
                          <Text style={[styles.servicePrice, { color: tierColor.main }]}>£{service.price.toFixed(0)}</Text>
                        </View>
                      </View>
                    </View>
                  </View>
                </GlassCard>
              </View>
            );
          })}
        </ScrollView>
      </Animated.View>

      {/* Continue Button - separate from cards */}
      <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12 }]}>
        {canContinue ? (
          <Text style={styles.conditionMicrocopy}>
            Detailing is condition-based. Results vary by vehicle condition.
          </Text>
        ) : null}
        <TouchableOpacity
          onPress={handleContinue}
          disabled={!canContinue}
          activeOpacity={0.9}
        >
          <LinearGradient
            colors={canContinue ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
            style={styles.ctaButton}
          >
            <Text style={styles.ctaText}>
              {canContinue
                ? `Choose ${selectedServiceData?.name || 'service'}`
                : 'Select a detailing service'}
            </Text>
            <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
          </LinearGradient>
        </TouchableOpacity>
      </View>

      {/* Service info popup – updated UI for PPF, tints, headlight restoration, etc. */}
      <Modal
        visible={!!infoModalService}
        transparent
        animationType="fade"
        statusBarTranslucent
        onRequestClose={() => setInfoModalService(null)}
      >
        <View style={styles.infoModalOverlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => setInfoModalService(null)} />
          <View
            style={[
              styles.infoModalCard,
              infoModalService && { borderColor: infoModalService.border, shadowColor: infoModalService.main },
            ]}
            pointerEvents="box-none"
          >
            {infoModalService && (() => {
              const tc = { main: infoModalService.main, light: infoModalService.light, border: infoModalService.border };
              return (
                <>
                  <View style={[styles.infoModalHeader, { backgroundColor: tc.light + '18', borderBottomColor: tc.light + '40' }]}>
                    <View style={[styles.infoModalAccent, { backgroundColor: tc.main }]} />
                    <View style={styles.infoModalHeaderContent}>
                      <Text style={[styles.infoModalTitle, { color: colors.headerText }]}>{infoModalService.name}</Text>
                      {infoModalService.badge && (
                        <View style={[styles.infoModalBadge, { backgroundColor: tc.light, borderColor: tc.border }]}>
                          <Text style={[styles.infoModalBadgeText, { color: tc.main }]}>{infoModalService.badge}</Text>
                        </View>
                      )}
                    </View>
                    <TouchableOpacity
                      onPress={() => setInfoModalService(null)}
                      style={styles.infoModalCloseBtn}
                      hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                    >
                      <Ionicons name="close" size={22} color="#94A3B8" />
                    </TouchableOpacity>
                  </View>
                  <ScrollView style={styles.infoModalScroll} showsVerticalScrollIndicator={false}>
                    <View style={[styles.infoModalPriceRow, { borderLeftColor: tc.main }]}>
                      <Text style={[styles.infoModalPrice, { color: tc.main }]}>£{infoModalService.price.toFixed(0)}</Text>
                      <View style={styles.infoModalDuration}>
                        <Ionicons name="time-outline" size={14} color="#64748B" />
                        <Text style={styles.infoModalDurationText}>{infoModalService.dur}</Text>
                      </View>
                    </View>
                    <Text style={styles.infoModalDesc}>{infoModalService.desc}</Text>
                    {infoModalService.bulletPoints && infoModalService.bulletPoints.length > 0 && (
                      <View style={styles.infoModalSection}>
                        <View style={styles.infoModalSectionTitleRow}>
                          <Ionicons name="checkmark-done-circle" size={16} color={tc.main} />
                          <Text style={[styles.infoModalSectionTitle, { color: tc.main }]}>Includes</Text>
                        </View>
                        {infoModalService.bulletPoints.map((f) => (
                          <View key={f} style={styles.infoModalFeatureRow}>
                            <Ionicons name="checkmark-circle" size={18} color={tc.main} />
                            <Text style={styles.infoModalFeatureText}>{f}</Text>
                          </View>
                        ))}
                      </View>
                    )}
                    <View style={[styles.infoModalSection, { borderTopColor: tc.light + '50' }]}>
                      <View style={styles.infoModalSectionTitleRow}>
                        <Ionicons name="car-sport-outline" size={16} color={tc.main} />
                        <Text style={[styles.infoModalSectionTitle, { color: tc.main }]}>Vehicle size pricing</Text>
                      </View>
                      <View style={styles.infoModalTiers}>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>Small</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).small.toFixed(0)}</Text>
                        </View>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>Medium</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).medium.toFixed(0)}</Text>
                        </View>
                        <View style={[styles.infoModalTierItem, { backgroundColor: tc.light + '15', borderColor: tc.light + '35' }]}>
                          <Text style={styles.infoModalTierLabel}>Large</Text>
                          <Text style={[styles.infoModalTierValue, { color: tc.main }]}>£{getPriceTiers(infoModalService.price).large.toFixed(0)}</Text>
                        </View>
                      </View>
                    </View>
                  </ScrollView>
                  <TouchableOpacity
                    onPress={() => setInfoModalService(null)}
                    style={[styles.infoModalDoneBtn, { backgroundColor: tc.main }]}
                    activeOpacity={0.9}
                  >
                    <Text style={styles.infoModalDoneText}>Close</Text>
                  </TouchableOpacity>
                </>
              );
            })()}
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: 'transparent' },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
    backgroundColor: 'transparent',
    zIndex: 100,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  hubMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  hubMarkerImage: {
    width: 48,
    height: 48,
  },
  content: { flex: 1 },
  loadingWrap: { flex: 1, alignItems: 'center', justifyContent: 'center', gap: 12, paddingHorizontal: 24 },
  loadingText: { color: SKY, fontSize: 14 },
  retryBtn: { marginTop: 10, borderRadius: 18, overflow: 'hidden' },
  retryGrad: { flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center', paddingVertical: 12, paddingHorizontal: 18 },
  retryText: { color: '#fff', fontWeight: '800' },

  cardWrapper: {
    marginRight: 12,
  },
  cardStrip: {
    borderLeftWidth: 4,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
  },
  serviceCard: {
    padding: 0,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    position: 'relative',
    elevation: 2,
    shadowColor: 'rgba(0,0,0,0.15)',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.12,
    shadowRadius: 8,
    ...BOOKING_CARD.CURVED,
  },
  serviceCardSelected: {
    elevation: 4,
    shadowOpacity: 0.18,
    shadowRadius: 10,
  },
  badgePill: {
    alignSelf: 'center',
    marginBottom: 4,
    zIndex: 2,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 6,
    paddingHorizontal: 12,
    borderRadius: 14,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.5)',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.18,
    shadowRadius: 4,
    elevation: 3,
  },
  badgePillIconWrap: {
    width: 18,
    height: 18,
    borderRadius: 9,
    backgroundColor: 'rgba(15,23,42,0.12)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  badgePillText: {
    color: '#0F172A',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.3,
    maxWidth: 100,
  },
  cardInner: {
    padding: 16,
    paddingTop: 14,
  },
  cardContentRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'space-between',
  },
  cardMain: {
    flex: 1,
    minWidth: 0,
    paddingRight: 44,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  serviceIconWrap: {
    width: 52,
    height: 52,
    borderRadius: 18,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedCheck: {
    width: 22,
    height: 22,
    borderRadius: 11,
    justifyContent: 'center',
    alignItems: 'center',
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    marginBottom: 6,
    letterSpacing: -0.2,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  statPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(148,163,184,0.12)',
    paddingHorizontal: 8,
    paddingVertical: 5,
    borderRadius: 8,
  },
  statText: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
  },
  servicePrice: {
    fontSize: 18,
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  serviceCardInfoBtn: {
    position: 'absolute',
    top: 12,
    right: 12,
    zIndex: 10,
  },
  tierBadgeBox: {
    width: 72,
    height: 72,
    marginLeft: 14,
  },
  tierBadgeTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 18,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },

  washTypeChip: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 12,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
    gap: 8,
  },
  washTypeChipText: {
    color: SKY,
    fontSize: 14,
    fontWeight: '700',
    flex: 1,
  },
  washTypeModalContent: {
    width: '100%',
    maxWidth: 360,
    marginHorizontal: 24,
    backgroundColor: '#1E293B',
    borderRadius: 18,
    borderWidth: 1,
    borderColor: 'rgba(205,127,50,0.4)',
    overflow: 'hidden',
  },
  washTypeModalHeader: {
    padding: 24,
    paddingBottom: 20,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(205,127,50,0.2)',
  },
  washTypeModalHeaderTop: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 12,
  },
  washTypeModalBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  washTypeModalBadgeText: {
    color: '#0F172A',
    fontSize: 13,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  washTypeModalClose: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(148,163,184,0.15)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  washTypeModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 6,
  },
  washTypeModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 20,
  },
  washTypeModalOptions: {
    padding: 20,
    gap: 12,
  },
  washTypeModalOption: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 18,
    padding: 16,
    borderWidth: 1.5,
    backgroundColor: 'rgba(205,127,50,0.06)',
  },
  washTypeModalOptionIcon: {
    width: 56,
    height: 56,
    borderRadius: 18,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 16,
  },
  washTypeModalOptionBody: {
    flex: 1,
    minWidth: 0,
  },
  washTypeModalOptionLabel: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 4,
  },
  washTypeModalOptionDesc: {
    color: '#94A3B8',
    fontSize: 13,
    lineHeight: 18,
  },
  washTypeModalOptionPrice: {
    fontSize: 18,
    fontWeight: '800',
    marginLeft: 12,
  },
  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
  },
  conditionMicrocopy: {
    color: '#94A3B8',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 10,
    fontStyle: 'italic',
    textAlign: 'center',
  },
  ctaButton: {
    borderRadius: 18,
    paddingVertical: 18,
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
  // Info modal
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  infoModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10,25,41,0.82)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  infoModalCard: {
    width: '100%',
    maxWidth: 360,
    maxHeight: '85%',
    backgroundColor: customerTheme.backgroundColor,
    borderRadius: 20,
    borderWidth: 1,
    overflow: 'hidden',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.25,
    shadowRadius: 16,
    elevation: 8,
  },
  infoModalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 16,
    paddingHorizontal: 16,
    paddingLeft: 20,
    borderBottomWidth: 1,
  },
  infoModalAccent: {
    width: 4,
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    borderRadius: 2,
  },
  infoModalHeaderContent: { flex: 1, marginLeft: 8 },
  infoModalTitle: {
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 4,
  },
  infoModalBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
  },
  infoModalBadgeText: { fontSize: 12, fontWeight: '700' },
  infoModalCloseBtn: {
    width: 36,
    height: 36,
    borderRadius: 18,
    backgroundColor: 'rgba(148,163,184,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoModalScroll: {
    maxHeight: 380,
    paddingHorizontal: 20,
    paddingTop: 16,
    paddingBottom: 12,
  },
  infoModalPriceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 14,
    paddingLeft: 12,
    borderLeftWidth: 3,
  },
  infoModalPrice: { fontSize: 24, fontWeight: '800' },
  infoModalDuration: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  infoModalDurationText: { color: '#64748B', fontSize: 14, fontWeight: '600' },
  infoModalDesc: {
    color: colors.headerSubtext,
    fontSize: 14,
    lineHeight: 22,
    marginBottom: 18,
    opacity: 0.95,
  },
  infoModalSection: {
    marginBottom: 18,
    paddingTop: 14,
    borderTopWidth: 1,
  },
  infoModalSectionTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 10,
  },
  infoModalSectionTitle: {
    fontSize: 12,
    fontWeight: '700',
    letterSpacing: 0.5,
    textTransform: 'uppercase',
  },
  infoModalFeatureRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 10,
    marginBottom: 10,
  },
  infoModalFeatureText: {
    color: colors.headerText,
    fontSize: 14,
    flex: 1,
    lineHeight: 20,
    opacity: 0.95,
  },
  infoModalTiers: {
    flexDirection: 'row',
    gap: 10,
    marginTop: 4,
  },
  infoModalTierItem: {
    flex: 1,
    alignItems: 'center',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderRadius: 12,
    borderWidth: 1,
  },
  infoModalTierLabel: {
    color: '#64748B',
    fontSize: 11,
    fontWeight: '600',
    marginBottom: 4,
    textTransform: 'uppercase',
  },
  infoModalTierValue: { fontSize: 15, fontWeight: '800' },
  infoModalDoneBtn: {
    marginHorizontal: 20,
    marginBottom: 20,
    paddingVertical: 14,
    borderRadius: 14,
    alignItems: 'center',
  },
  infoModalDoneText: { color: '#fff', fontSize: 16, fontWeight: '800' },

  recenterButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15, 23, 42, 0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 4,
    elevation: 3,
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 100,
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
});
