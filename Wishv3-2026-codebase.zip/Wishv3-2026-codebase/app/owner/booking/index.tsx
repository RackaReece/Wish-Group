import React, { useRef, useEffect, useState } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  Animated,
  Alert,
  ScrollView,
  Image,
  TouchableOpacity,
  Modal,
  Pressable,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import InfoIconButton from '../../../src/components/shared/InfoIconButton';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { BOOKING_CARD, CURVED_BOOKING_CARD, BOOKING_INDEX_CARDS_BOTTOM_PADDING } from '../../../src/constants/bookingCardTheme';
import { DEFAULT_MAP_REGION, BOOKING_MAP_STYLE, RECENTER_BUTTON_LEFT, RECENTER_BUTTON_RIGHT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '../../../src/constants/mapConstants';
import { ACTIVE_CUSTOMER_BOOKING_STATUSES } from '../../../src/utils/activeBookingGuard';
import { useBookingFlowTheme } from '../../../src/contexts/BookingFlowThemeContext';

const { width } = Dimensions.get('window');
const SKY = colors.SKY;
const DETAILING_YELLOW = colors.DETAILING_YELLOW;
const DETAILING_YELLOW_DARK = colors.DETAILING_YELLOW_DARK;
const CARD_WIDTH = BOOKING_CARD.CARD_WIDTH;


const washTypes = [
  {
    id: 'valeter',
    title: 'Mobile Valeter',
    subtitle: 'Valeter comes to you',
    description: 'A vetted professional valeter will come to your location with live tracking and real-time updates.',
    eta: '10–25 mins',
    trustLine: 'Vetted professionals',
    icon: 'car-sport',
    gradient: [SKY, '#60A5FA', '#3B82F6'],
    borderColor: 'rgba(135,206,235,0.4)',
    iconColor: SKY,
    route: '/owner/booking/create',
    params: {} as Record<string, string>,
    features: ['Pay after acceptance', 'Live GPS tracking', 'Real-time updates', 'Home or office'],
    badge: 'FASTEST',
  },
  {
    id: 'physical',
    title: 'Wash Hub',
    subtitle: 'Book a time slot',
    description: 'Visit a verified car wash location near you. Book your preferred date and time slot in advance.',
    nextSlot: 'Available today',
    trustLine: 'Verified locations',
    icon: 'business',
    gradient: ['#60A5FA', '#3B82F6', '#2563EB'],
    borderColor: 'rgba(59,130,246,0.4)',
    iconColor: '#60A5FA',
    route: '/owner/booking/physical/location',
    params: {} as Record<string, string>,
    features: ['Certified locations', 'Flexible scheduling', 'Nearby errands', 'Time slots'],
    badge: 'FLEXIBLE',
  },
] as const;

const detailingTypes = [
  {
    id: 'valeter',
    title: 'Mobile Detailer',
    subtitle: 'Premium detailer to you',
    description: 'A premium detailer will come to your location with professional-grade equipment and live tracking.',
    eta: '15–30 mins',
    trustLine: 'Premium professionals',
    icon: 'diamond',
    gradient: [DETAILING_YELLOW, DETAILING_YELLOW_DARK, '#B45309'],
    borderColor: 'rgba(234,179,8,0.4)',
    iconColor: DETAILING_YELLOW,
    route: '/owner/booking/create',
    params: { serviceMode: 'detailing' },
    features: ['Pay after acceptance', 'Live GPS tracking', 'Real-time updates', 'Home or office'],
    badge: 'PREMIUM',
  },
  {
    id: 'physical',
    title: 'Detail Hub',
    subtitle: 'Book a time slot',
    description: 'Visit a premium detailing facility near you. Book your preferred date and time slot in advance.',
    nextSlot: 'Available today',
    trustLine: 'Premium facilities',
    icon: 'business',
    gradient: [DETAILING_YELLOW, DETAILING_YELLOW_DARK, '#B45309'],
    borderColor: 'rgba(234,179,8,0.4)',
    iconColor: DETAILING_YELLOW,
    route: '/owner/booking/detailing/physical',
    params: {} as Record<string, string>,
    features: ['Premium facilities', 'Flexible scheduling', 'Professional setup', 'Time slots'],
    badge: 'PREMIUM',
  },
] as const;

type ActiveBooking = { id: string; status: string };

export default function WashTypeSelection() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const { setTheme } = useBookingFlowTheme();

  const [serviceType, setServiceType] = useState<'wash' | 'detailing'>(
    (params.serviceType as 'wash' | 'detailing') || 'wash'
  );

  // Sync booking flow theme for header/nav tab colour (detail = yellow, wash = default)
  useEffect(() => {
    setTheme(serviceType);
  }, [serviceType, setTheme]);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(30)).current;
  const cardScaleAnim = useRef(new Animated.Value(1)).current;

  const [activeBooking, setActiveBooking] = useState<ActiveBooking | null>(null);
  const [checkingActive, setCheckingActive] = useState(false);
  const [nextSlotText, setNextSlotText] = useState<string>('Available today');
  const [infoModalOption, setInfoModalOption] = useState<typeof washTypes[number] | typeof detailingTypes[number] | null>(null);

  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);

  const calculateNextSlot = () => {
    const now = new Date();
    const currentHour = now.getHours();
    if (currentHour < 17) {
      setNextSlotText('Available today');
    } else {
      setNextSlotText('Available tomorrow');
    }
  };

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, friction: 8, tension: 60, useNativeDriver: true }),
    ]).start();
    calculateNextSlot();
  }, []);

  useEffect(() => {
    if (params.serviceType === 'detailing' || params.serviceType === 'wash') {
      setServiceType(params.serviceType);
    }
  }, [params.serviceType]);

  useEffect(() => {
    if (liveCoords) {
      const coords = { latitude: liveCoords.latitude, longitude: liveCoords.longitude };
      setUserLocation(coords);
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.002,
        longitudeDelta: 0.002,
      });
    } else {
      (async () => {
        try {
          const { status } = await Location.requestForegroundPermissionsAsync();
          if (status !== 'granted') return;
          const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
          const coords = { latitude: location.coords.latitude, longitude: location.coords.longitude };
          setUserLocation(coords);
          setRegion({ ...coords, latitudeDelta: 0.002, longitudeDelta: 0.002 });
        } catch (error) {
          console.warn('Error getting location:', error);
        }
      })();
    }
  }, [liveCoords]);

  const loadActiveBooking = async () => {
    if (!user?.id) return;
    try {
      setCheckingActive(true);
      const { data, error } = await supabase
        .from('bookings')
        .select('id,status')
        .eq('user_id', user.id)
        .in('status', [...ACTIVE_CUSTOMER_BOOKING_STATUSES])
        .order('created_at', { ascending: false })
        .limit(1)
        .maybeSingle();

      if (error) {
        console.warn('[WashTypeSelection] loadActiveBooking error:', error);
        setActiveBooking(null);
        return;
      }

      if (!data) {
        setActiveBooking(null);
        return;
      }

      setActiveBooking({ id: data.id, status: data.status });
    } catch (e) {
      console.warn('[WashTypeSelection] loadActiveBooking exception:', e);
      setActiveBooking(null);
    } finally {
      setCheckingActive(false);
    }
  };

  useEffect(() => {
    if (!user?.id) return;
    loadActiveBooking();

    const channel = supabase
      .channel(`wash-type-active-booking-${user.id}`)
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        () => loadActiveBooking()
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'bookings', filter: `user_id=eq.${user.id}` },
        (payload) => {
          const updated = payload.new as any;
          const status = updated?.status as string | undefined;
          if (!updated?.id || !status) {
            loadActiveBooking();
            return;
          }
          if (ACTIVE_CUSTOMER_BOOKING_STATUSES.includes(status as any)) {
            setActiveBooking({ id: updated.id, status });
          } else if (activeBooking?.id === updated.id) {
            setActiveBooking(null);
          } else {
            loadActiveBooking();
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [user?.id, activeBooking?.id]);

  const goToActiveBooking = () => {
    if (!activeBooking?.id) return;
    router.push({
      pathname: '/owner/booking/tracking',
      params: { bookingId: activeBooking.id },
    } as any);
  };

  const handleSelect = async (option: (typeof washTypes)[number] | (typeof detailingTypes)[number]) => {
    if (checkingActive) return;

    if (activeBooking?.id) {
      Alert.alert(
        'One booking at a time',
        'You already have an active booking. Please complete or cancel it before starting a new one.',
        [
          { text: 'Cancel', style: 'cancel' },
          { text: 'View my booking', onPress: goToActiveBooking },
        ]
      );
      return;
    }

    await hapticFeedback('medium');
    
    // Animate card press
    Animated.sequence([
      Animated.timing(cardScaleAnim, { toValue: 0.95, duration: 100, useNativeDriver: true }),
      Animated.timing(cardScaleAnim, { toValue: 1, duration: 100, useNativeDriver: true }),
    ]).start();

    if (option.params && Object.keys(option.params).length > 0) {
      router.push({ pathname: option.route as any, params: option.params });
    } else {
      router.push(option.route as any);
    }
  };

  const currentTypes = serviceType === 'wash' ? washTypes : detailingTypes;
  const primaryColor = serviceType === 'detailing' ? DETAILING_YELLOW : SKY;

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      {/* Map background for both wash and detailing */}
      <View style={[StyleSheet.absoluteFill, styles.mapContainer]}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region ?? DEFAULT_MAP_REGION}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={BOOKING_MAP_STYLE}
        >
          {userLocation && (
            <Marker coordinate={userLocation} anchor={{ x: 0.5, y: 0.5 }}>
              <View style={styles.userMarkerContainer}>
                <View style={styles.userMarkerPulse} />
                <Image
                  source={require('../../../assets/car.png')}
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
        </MapView>
      </View>

      {/* Overlay: header, badge, cards - above map */}
      <View style={[StyleSheet.absoluteFill, styles.overlay]} pointerEvents="box-none" collapsable={false}>
      {/* Wash / Detail toggle - same place as wash hub map view */}
      <View style={[styles.serviceModeToggle, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + 12, position: 'absolute', left: 16, right: 16, zIndex: 1001, elevation: 24 }]}>
        <TouchableOpacity
          onPress={() => { hapticFeedback('light'); setServiceType('wash'); }}
          style={[styles.serviceModePill, serviceType === 'wash' && styles.serviceModePillActive]}
          activeOpacity={0.8}
        >
          <Ionicons name="water-outline" size={18} color={serviceType === 'wash' ? '#FFFFFF' : SKY} />
          <Text style={[styles.serviceModeLabel, serviceType === 'wash' && styles.serviceModeLabelActive]}>Wash</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => { hapticFeedback('light'); setServiceType('detailing'); }}
          style={[styles.serviceModePill, serviceType === 'detailing' && styles.serviceModePillActiveDetail]}
          activeOpacity={0.8}
        >
          <Ionicons name="diamond-outline" size={18} color={serviceType === 'detailing' ? '#FFFFFF' : DETAILING_YELLOW} />
          <Text style={[styles.serviceModeLabel, serviceType === 'detailing' && styles.serviceModeLabelActiveDetail]}>Detail</Text>
        </TouchableOpacity>
      </View>

      {/* Header – info hub only in header */}
      <AppHeader 
        title="Book a Service" 
        subtitle={serviceType === 'wash' ? "We've found wash types" : "We've found detailing services"} 
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
        primaryColor={primaryColor}
        rightAction={
          <TouchableOpacity
            onPress={() => {
              hapticFeedback('light');
              router.push('/owner/wash-vs-detail-info');
            }}
            style={styles.headerIconButton}
            activeOpacity={0.7}
          >
            <Ionicons name="information-circle" size={22} color={serviceType === 'wash' ? SKY : DETAILING_YELLOW} />
          </TouchableOpacity>
        }
      />

      {/* Scheduling icon – map + time slot booking (not on-demand) */}
      <TouchableOpacity
        onPress={() => {
          hapticFeedback('light');
          router.push('/owner/booking/schedule-booking' as any);
        }}
        style={[
          styles.recenterButton,
          {
            top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS,
            left: RECENTER_BUTTON_LEFT,
          },
        ]}
        activeOpacity={0.7}
        accessibilityLabel="Schedule a booking: pick location on map and time slot"
      >
        <Ionicons name="calendar-outline" size={22} color={serviceType === 'wash' ? SKY : DETAILING_YELLOW} />
      </TouchableOpacity>

      {/* Recentre button – right side below header */}
      <TouchableOpacity
        onPress={() => {
          hapticFeedback('light');
          if (userLocation) setRegion({ ...userLocation, latitudeDelta: 0.002, longitudeDelta: 0.002 });
        }}
        style={[
          styles.recenterButton,
          {
            top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS,
            right: RECENTER_BUTTON_RIGHT,
          },
        ]}
        activeOpacity={0.7}
      >
        <Ionicons name="locate" size={22} color={SKY} />
      </TouchableOpacity>

      {/* Modern floating cards */}
      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            bottom: TAB_BAR_TOTAL_HEIGHT + Math.max(insets.bottom, 14) + BOOKING_INDEX_CARDS_BOTTOM_PADDING,
          },
        ]}
      >
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.cardsScrollContent}
          snapToInterval={BOOKING_CARD.SNAP_INTERVAL}
          decelerationRate="fast"
          snapToAlignment="start"
        >
          {currentTypes.map((option) => {
            const isValeter = option.id === 'valeter';
            const serviceColor = primaryColor;
            let badgeIconName: 'flash' | 'ribbon' | 'calendar';
            let badgeText: string;
            if (isValeter && option.eta) {
              badgeIconName = 'flash';
              badgeText = option.eta;
            } else if (isValeter) {
              badgeIconName = 'ribbon';
              badgeText = option.badge;
            } else {
              badgeIconName = 'calendar';
              badgeText = nextSlotText;
            }

            return (
              <Animated.View
                key={option.id}
                style={[
                  styles.cardWrapper,
                  { width: CARD_WIDTH },
                  { transform: [{ scale: cardScaleAnim }] },
                ]}
              >
                <View style={styles.cardBorderWrap}>
                  <LinearGradient
                    colors={[SKY + '99', SKY + '66', '#1E3A5F']}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}
                    style={StyleSheet.absoluteFill}
                  />
                  <TouchableOpacity
                    onPress={() => handleSelect(option)}
                    activeOpacity={0.9}
                    style={styles.bookServiceCard}
                  >
                    <View style={[styles.cardYellowStrip, { backgroundColor: SKY }]} />
                    <LinearGradient
                      colors={[SKY + '28', 'rgba(30,58,95,0.4)']}
                      start={{ x: 0, y: 0 }}
                      end={{ x: 0, y: 1 }}
                      style={StyleSheet.absoluteFill}
                      pointerEvents="none"
                    />
                    <View style={styles.cardCoverWrap}>
                      <BlurView intensity={14} tint="light" style={styles.cardCoverBlur} />
                      <View style={styles.cardCoverTitleWrap}>
                        <Text style={styles.cardCoverTitleWhite} numberOfLines={1}>{option.title}</Text>
                        <Text style={styles.cardCoverSubtitleWhite} numberOfLines={1}>{option.subtitle}</Text>
                      </View>
                      <View style={styles.cardCoverInfoBtn}>
                        <InfoIconButton
                          onPress={() => { hapticFeedback('light'); setInfoModalOption(option); }}
                          accentColor={SKY}
                        />
                      </View>
                    </View>
                    <View style={styles.modernCard}>
                      <View style={styles.cardTop}>
                        <View style={[styles.iconWrap, { backgroundColor: serviceColor + '28', borderColor: serviceColor + '50' }]}>
                          <Ionicons name={option.icon as any} size={26} color={serviceColor} />
                        </View>
                        <View style={styles.cardContent}>
                          <View style={styles.cardMetaRow}>
                            <View style={[styles.badgePill, { borderColor: serviceColor + '50', backgroundColor: serviceColor + '18' }]}>
                              <Ionicons name={badgeIconName} size={12} color={serviceColor} style={styles.badgePillIcon} />
                              <Text style={[styles.badgePillText, { color: serviceColor }]} numberOfLines={1}>
                                {badgeText}
                              </Text>
                            </View>
                          </View>
                        </View>
                      </View>
                    </View>
                  </TouchableOpacity>
                </View>
              </Animated.View>
            );
          })}
        </ScrollView>

        {/* Info popup overlay – customer design, UI colours */}
        <Modal
          visible={!!infoModalOption}
          transparent
          animationType="fade"
          onRequestClose={() => setInfoModalOption(null)}
        >
          <Pressable
            style={styles.modalOverlay}
            onPress={() => setInfoModalOption(null)}
          >
            <Pressable style={styles.modalContentWrap} onPress={(e) => e.stopPropagation()}>
              <BlurView intensity={32} tint="dark" style={StyleSheet.absoluteFill} />
              <View style={styles.modalContent}>
                {infoModalOption && (() => {
                  let modalTitleText: string;
                  if (infoModalOption.id === 'valeter') {
                    modalTitleText = serviceType === 'wash' ? 'A washer is on the way to you' : 'A detailer is on the way to you';
                  } else {
                    modalTitleText = infoModalOption.title;
                  }
                  let modalDescText: string;
                  if (infoModalOption.id === 'valeter') {
                    modalDescText = serviceType === 'wash'
                      ? 'A vetted professional washer will come directly to your location with live tracking and updates.'
                      : 'A vetted professional detailer will come directly to your location with live tracking and updates.';
                  } else {
                    modalDescText = infoModalOption.description;
                  }
                  return (
                  <>
                    <View style={styles.modalHeader}>
                      <Text style={[styles.modalTitle, { color: customerTheme.primary }]}>
                        {modalTitleText}
                      </Text>
                      <TouchableOpacity
                        onPress={() => setInfoModalOption(null)}
                        hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
                      >
                        <Ionicons name="close" size={24} color={customerTheme.primary} />
                      </TouchableOpacity>
                    </View>
                    <Text style={styles.modalSubtitle}>{infoModalOption.subtitle}</Text>
                    <Text style={styles.modalDesc}>
                      {modalDescText}
                    </Text>
                    <View style={styles.modalStatusRow}>
                      {infoModalOption.id === 'valeter' && infoModalOption.eta && (
                        <>
                          <View style={[styles.modalBadge, { backgroundColor: customerTheme.primary + '22' }]}>
                            <Ionicons name="time" size={14} color={customerTheme.primary} />
                            <Text style={[styles.modalBadgeText, { color: customerTheme.primary }]}>{infoModalOption.eta}</Text>
                          </View>
                          <View style={[styles.modalTrustBadge, { backgroundColor: colors.ecoGreen + '22' }]}>
                            <Ionicons name="shield-checkmark" size={12} color={colors.ecoGreen} />
                            <Text style={styles.modalTrustText}>{infoModalOption.trustLine}</Text>
                          </View>
                          <View style={[styles.modalTrustBadge, { backgroundColor: customerTheme.primary + '22' }]}>
                            <Ionicons name="star" size={12} color={customerTheme.primary} />
                            <Text style={[styles.modalTrustText, { color: customerTheme.primary }]}>Rated by customers near you</Text>
                          </View>
                        </>
                      )}
                      {infoModalOption.id !== 'valeter' && (
                        <>
                          <View style={[styles.modalBadge, { backgroundColor: customerTheme.primary + '22' }]}>
                            <Ionicons name="calendar" size={14} color={customerTheme.primary} />
                            <Text style={[styles.modalBadgeText, { color: customerTheme.primary }]}>{nextSlotText}</Text>
                          </View>
                          <View style={[styles.modalTrustBadge, { backgroundColor: colors.ecoGreen + '22' }]}>
                            <Ionicons name="shield-checkmark" size={12} color={colors.ecoGreen} />
                            <Text style={styles.modalTrustText}>{infoModalOption.trustLine}</Text>
                          </View>
                        </>
                      )}
                    </View>
                    <View style={styles.modalFeatures}>
                      <Text style={styles.modalSectionTitle}>Includes</Text>
                      {infoModalOption.features.map((f) => (
                        <View key={f} style={styles.modalFeatureRow}>
                          <View style={[styles.modalFeatureDot, { backgroundColor: customerTheme.primary }]} />
                          <Text style={styles.modalFeatureText}>{f}</Text>
                        </View>
                      ))}
                    </View>
                  </>
                  );
                })()}
              </View>
            </Pressable>
          </Pressable>
        </Modal>
      </Animated.View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  userMarkerPulse: {
    position: 'absolute',
    width: 56,
    height: 56,
    borderRadius: 28,
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderWidth: 2,
    borderColor: 'rgba(135,206,235,0.4)',
  },
  userMarker: {
    width: 48,
    height: 48,
    zIndex: 1,
  },
  serviceModeToggle: {
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 4,
  },
  serviceModePill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  serviceModePillActive: {
    backgroundColor: SKY,
    borderColor: SKY,
  },
  serviceModePillActiveDetail: {
    backgroundColor: DETAILING_YELLOW,
    borderColor: DETAILING_YELLOW,
  },
  serviceModeLabel: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  serviceModeLabelActive: {
    color: '#FFFFFF',
  },
  serviceModeLabelActiveDetail: {
    color: '#FFFFFF',
  },
  // Resources toggles – I offer Water / Electricity
  offersToggleContainer: {
    flexDirection: 'row',
  },
  offersToggleCard: {
    flex: 1,
    flexDirection: 'column',
    backgroundColor: 'rgba(15,23,42,0.75)',
    borderRadius: 16,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.35)',
    paddingVertical: 12,
    paddingHorizontal: 14,
    overflow: 'hidden',
  },
  offersToggleTitle: {
    color: SKY,
    fontSize: 12,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.6,
    marginBottom: 10,
  },
  offersToggleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 12,
  },
  offersToggleItem: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  offersToggleLabel: {
    color: '#F9FAFB',
    fontSize: 14,
    fontWeight: '600',
    flex: 1,
  },
  recenterButton: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 100,
  },
  headerRightActions: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  headerIconButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  headerLocateButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  mapContainer: {
    zIndex: 0,
    elevation: 0,
  },
  overlay: {
    zIndex: 1,
    elevation: 1,
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
    zIndex: 10,
    elevation: 8,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  cardWrapper: {
    marginRight: 12,
  },
  cardBorderWrap: {
    borderRadius: 20,
    padding: 0,
    overflow: 'hidden',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 4,
  },
  bookServiceCard: {
    ...CURVED_BOOKING_CARD,
    overflow: 'hidden',
    borderRadius: 18,
    borderWidth: 0,
    borderColor: 'transparent',
  },
  cardYellowStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 3,
    backgroundColor: SKY,
    borderTopLeftRadius: 18,
    borderBottomLeftRadius: 18,
    zIndex: 1,
    opacity: 0.9,
  },
  cardCoverWrap: {
    height: 84,
    width: '100%',
    position: 'relative',
    overflow: 'hidden',
    borderTopLeftRadius: 18,
    borderTopRightRadius: 18,
  },
  cardCoverBlur: {
    ...StyleSheet.absoluteFillObject,
    borderTopLeftRadius: 18,
    borderTopRightRadius: 18,
  },
  cardCoverTitleWrap: {
    position: 'absolute',
    left: 16,
    right: 56,
    top: 20,
    justifyContent: 'center',
  },
  cardCoverTitle: {
    color: customerTheme.primary,
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  cardCoverTitleWhite: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  cardCoverSubtitle: {
    color: customerTheme.primary,
    fontSize: 13,
    fontWeight: '500',
    marginTop: 2,
    opacity: 0.9,
  },
  cardCoverSubtitleWhite: {
    color: '#FFFFFF',
    fontSize: 13,
    fontWeight: '500',
    marginTop: 2,
    opacity: 0.92,
  },
  cardCoverInfoBtn: {
    position: 'absolute',
    top: 12,
    right: 12,
    padding: 6,
    borderRadius: 10,
  },
  modernCard: {
    padding: 20,
    overflow: 'hidden',
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 52,
    height: 52,
    borderRadius: 16,
    marginRight: 14,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    flex: 1,
    minWidth: 0,
  },
  badgePill: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingVertical: 6,
    paddingHorizontal: 10,
    borderRadius: 10,
    borderWidth: 1,
    gap: 5,
  },
  badgePillIcon: {
    opacity: 0.95,
  },
  badgePillText: {
    fontSize: 12,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    flex: 1,
  },
  infoIconBtn: {
    padding: 6,
    borderRadius: 10,
  },
  cardSubtitle: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
  },
  cardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 8,
  },
  quickHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  quickHintText: {
    fontSize: 11,
    fontWeight: '600',
  },
  ctaDivider: {
    height: 1,
    marginTop: 14,
    marginBottom: 12,
    borderRadius: 1,
  },
  ctaButton: {
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
  // Info modal – clean, matches app
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10,25,41,0.78)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  modalContentWrap: {
    width: '100%',
    maxWidth: 340,
    maxHeight: '85%',
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: customerTheme.primary + '35',
  },
  modalContent: {
    padding: 20,
    backgroundColor: 'transparent',
  },
  modalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
    paddingBottom: 12,
    borderBottomWidth: 1,
    borderBottomColor: customerTheme.primary + '20',
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: '800',
  },
  modalSubtitle: {
    color: colors.headerSubtext,
    fontSize: 13,
    marginBottom: 10,
  },
  modalDesc: {
    color: colors.headerText,
    fontSize: 13,
    lineHeight: 20,
    marginBottom: 14,
    opacity: 0.92,
  },
  modalStatusRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
    marginBottom: 14,
  },
  modalBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  modalBadgeText: {
    fontSize: 12,
    fontWeight: '700',
  },
  modalTrustBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  modalTrustText: {
    color: colors.ecoGreen,
    fontSize: 12,
    fontWeight: '700',
  },
  modalSectionTitle: {
    color: customerTheme.primary,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 8,
  },
  modalFeatures: {
    marginBottom: 18,
  },
  modalFeatureRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 8,
  },
  modalFeatureDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
  },
  modalFeatureText: {
    color: colors.headerText,
    fontSize: 13,
    flex: 1,
    opacity: 0.92,
  },
  modalDone: {
    backgroundColor: customerTheme.primary,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  modalDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
});
