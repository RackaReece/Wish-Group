import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  ActivityIndicator,
  Image,
  Alert,
  Modal,
  Pressable,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Region, Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { serviceOptions } from '../../../src/constants/serviceOptions';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { ValeterStatsService } from '../../../src/services/Valeterstatsservice';
import { BOOKING_CARD } from '../../../src/constants/bookingCardTheme';
import { getActiveBookingForCustomer } from '../../../src/utils/activeBookingGuard';
import UnifiedBookingCard from '../../../src/components/booking/UnifiedBookingCard';
import { DEFAULT_MAP_REGION, BOOKING_MAP_STYLE, RECENTER_BUTTON_RIGHT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '../../../src/constants/mapConstants';

const { width, height: windowHeight } = Dimensions.get('window');
const CARD_WIDTH = BOOKING_CARD.CARD_WIDTH;
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

interface Valeter {
  id: string;
  name: string;
  rating: number;
  totalJobs: number;
  distance: number;
  isOnline: boolean;
  profilePicture?: string;
  lastLat?: number;
  lastLng?: number;
  isVerified?: boolean;
  responseTime?: number;
  eta?: number;
  vehicleRegistration?: string;
  vehicleType?: string;
}

export default function ValeterSelection() {
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const params = useLocalSearchParams();
  const serviceId = params.serviceId as string;
  const paramLat = Number.parseFloat(params.latitude as string);
  const paramLng = Number.parseFloat(params.longitude as string);
  const address = params.address as string;
  const customerOffersWater = params.customerOffersWater === 'true';
  const customerOffersElectricity = params.customerOffersElectricity === 'true';
  const discountAmount = Number.parseFloat(params.discountAmount as string) || 0;
  const washType = params.washType as 'exterior' | 'interior' | 'both' | undefined;
  const addOnIds = (params.addOnIds as string) || '';
  const addOnsTotal = Number.parseFloat((params.addOnsTotal as string) || '0') || 0;

  const [valeters, setValeters] = useState<Valeter[]>([]);
  const [selectedValeter, setSelectedValeter] = useState<string | null>(null);
  const [showConfirmValeterModal, setShowConfirmValeterModal] = useState(false);
  const [sendingRequest, setSendingRequest] = useState(false);
  const [loading, setLoading] = useState(true);
  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [center, setCenter] = useState<{ lat: number; lng: number } | null>(null);

  const latitude = center?.lat ?? paramLat ?? liveCoords?.latitude ?? 0;
  const longitude = center?.lng ?? paramLng ?? liveCoords?.longitude ?? 0;

  const mapRef = useRef<MapView>(null);
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;

  useEffect(() => {
    const lat = Number.isFinite(paramLat) && Number.isFinite(paramLng) ? paramLat : liveCoords?.latitude;
    const lng = Number.isFinite(paramLat) && Number.isFinite(paramLng) ? paramLng : liveCoords?.longitude;
    if (lat != null && lng != null) {
      setCenter({ lat, lng });
      setRegion({ latitude: lat, longitude: lng, latitudeDelta: 0.002, longitudeDelta: 0.002 });
    } else if (liveCoords) {
      setCenter({ lat: liveCoords.latitude, lng: liveCoords.longitude });
      setRegion({ latitude: liveCoords.latitude, longitude: liveCoords.longitude, latitudeDelta: 0.002, longitudeDelta: 0.002 });
    } else {
      Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced })
        .then((loc) => {
          setCenter({ lat: loc.coords.latitude, lng: loc.coords.longitude });
          setRegion({ latitude: loc.coords.latitude, longitude: loc.coords.longitude, latitudeDelta: 0.002, longitudeDelta: 0.002 });
        })
        .catch(() => {});
    }
  }, [paramLat, paramLng, liveCoords]);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.spring(slideAnim, { toValue: 0, tension: 50, friction: 8, useNativeDriver: true }),
    ]).start();
  }, []);

  useEffect(() => {
    if (center) loadNearbyValeters();
  }, [center]);

  // Fit map so user and all valeter locations are always visible
  useEffect(() => {
    if (!center || valeters.length === 0) return;
    const coords = [{ latitude: center.lat, longitude: center.lng }];
    valeters.forEach((v) => {
      if (v.lastLat != null && v.lastLng != null) coords.push({ latitude: v.lastLat, longitude: v.lastLng });
    });
    if (coords.length < 2) return;
    const t = setTimeout(() => {
      mapRef.current?.fitToCoordinates(coords, {
        edgePadding: { top: 100, right: 48, bottom: 320, left: 48 },
        animated: true,
      });
    }, 400);
    return () => clearTimeout(t);
  }, [center, valeters.map((v) => `${v.lastLat}-${v.lastLng}`).join(',')]);

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 3959;
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const loadNearbyValeters = async () => {
    try {
      const { data: presenceData, error: presenceError } = await supabase
        .from('valeter_presence')
        .select('user_id, is_online, last_lat, last_lng')
        .eq('is_online', true);

      if (presenceError) throw presenceError;

      if (!presenceData || presenceData.length === 0) {
        setValeters([]);
        setLoading(false);
        return;
      }

      const userIds = presenceData.map(p => p.user_id);
      const { data: profilesData, error: profilesError } = await supabase
        .from('valeter_profiles')
        .select('user_id, full_name, profile_photo_url, verification_status')
        .in('user_id', userIds);

      if (profilesError) throw profilesError;

      const { data: vehiclesData } = await supabase
        .from('customer_vehicles')
        .select('user_id, registration, type')
        .in('user_id', userIds)
        .eq('is_default', true);

      const statsPromises = userIds.map(userId =>
        ValeterStatsService.getValeterStats(userId).catch(() => null)
      );
      const statsResults = await Promise.all(statsPromises);
      const statsMap = new Map(
        userIds.map((userId, index) => [userId, statsResults[index]])
      );

      const valetersList: Valeter[] = await Promise.all(
        presenceData.map(async (presence) => {
          const profile = profilesData?.find(p => p.user_id === presence.user_id);
          const distance = presence.last_lat && presence.last_lng
            ? calculateDistance(latitude, longitude, presence.last_lat, presence.last_lng)
            : 999;

          const stats = statsMap.get(presence.user_id);
          const displayName = profile?.full_name || 'Valeter';
          const isVerified = profile?.verification_status === 'verified';
          const vehicle = vehiclesData?.find(v => v.user_id === presence.user_id);
          const estimatedETA = Math.round(distance * 2);

          return {
            id: presence.user_id,
            name: displayName,
            rating: stats?.averageRating || 0,
            totalJobs: stats?.totalJobs || 0,
            distance: Math.round(distance * 10) / 10,
            isOnline: presence.is_online,
            profilePicture: profile?.profile_photo_url,
            lastLat: presence.last_lat,
            lastLng: presence.last_lng,
            isVerified: isVerified,
            responseTime: 5,
            eta: estimatedETA,
            vehicleRegistration: vehicle?.registration,
            vehicleType: vehicle?.type,
          };
        })
      );

      const filteredValeters = valetersList
        .filter(v => v.distance <= 10)
        .sort((a, b) => a.distance - b.distance);

      setValeters(filteredValeters);
    } catch (error) {
      const errorService = await import('../../../src/services/ErrorHandlingService').then(m => m.errorHandlingService);
      errorService.handleBookingError(error as Error, 'valeter_selection');
    } finally {
      setLoading(false);
    }
  };

  const handleValeterSelect = async (valeterId: string) => {
    await hapticFeedback('light');
    setSelectedValeter(valeterId);
  };

  const selectedServiceOption = serviceOptions.find((option) => option.id === serviceId);

  const handleContinue = async () => {
    if (!selectedValeter || !selectedServiceOption) return;
    await hapticFeedback('medium');

    if (!user?.id) return;

    const active = await getActiveBookingForCustomer(user.id);
    if (active) {
      Alert.alert(
        'One booking at a time',
        'You already have an active booking. Please complete or cancel it before starting a new one.',
        [
          { text: 'OK', style: 'cancel' },
          { text: 'View my booking', onPress: () => router.push({ pathname: '/owner/booking/tracking', params: { bookingId: active.id } } as any) },
        ]
      );
      return;
    }

    try {
      const scheduledAt = new Date().toISOString();
      const basePrice = selectedServiceOption.price || 25;
      const serviceTotal = basePrice - discountAmount;
      const finalPrice = serviceTotal + addOnsTotal;

      const insertRow: Record<string, unknown> = {
        user_id: user.id,
        valeter_id: selectedValeter,
        service_type: serviceId,
        service_name: selectedServiceOption.name || serviceId,
        status: 'pending_valeter_acceptance',
        price: finalPrice,
        location_address: address,
        location_lat: latitude,
        location_lng: longitude,
        customer_offers_water: customerOffersWater,
        customer_offers_electricity: customerOffersElectricity,
        discount_amount: discountAmount,
        wash_type: washType,
        request_sent_at: new Date().toISOString(),
        scheduled_at: scheduledAt,
      };
      if (addOnIds) insertRow.add_on_ids = addOnIds;
      if (addOnsTotal > 0) insertRow.add_ons_total = addOnsTotal;

      let result = await supabase.from('bookings').insert(insertRow).select().single();
      if (result.error && (result.error.message?.includes('add_on') || result.error.message?.includes('add_ons'))) {
        delete insertRow.add_on_ids;
        delete insertRow.add_ons_total;
        result = await supabase.from('bookings').insert(insertRow).select().single();
      }
      const { data, error } = result;

      if (error) throw error;

      router.push({
        pathname: '/owner/booking/waiting-acceptance',
        params: { bookingId: data.id },
      });
    } catch (error: any) {
      console.error('Error creating booking:', error);
      setSendingRequest(false);
      Alert.alert('Error', error?.message || 'Failed to create booking');
    }
  };

  const handleConfirmValeterPress = () => {
    if (!selectedValeter) return;
    setShowConfirmValeterModal(true);
  };

  const handleSendRequest = () => {
    if (sendingRequest) return;
    setSendingRequest(true);
    setShowConfirmValeterModal(false);
    handleContinue();
  };

  const renderValeterStats = (valeter: Valeter) => {
    const ratingText = valeter.rating > 0 ? `${valeter.rating.toFixed(1)}` : 'New';
    const jobsText = `${valeter.totalJobs} ${valeter.totalJobs === 1 ? 'job' : 'jobs'} completed`;
    const distanceText = `${valeter.distance.toFixed(1)} mi`;
    const etaText = valeter.eta && valeter.eta > 0 ? `${valeter.eta} min` : null;

    return (
      <View style={styles.uberValeterStats}>
        <View style={styles.uberStatItem}>
          <Ionicons name="star" size={14} color="#FBBF24" />
          <Text style={styles.uberStatText}>{ratingText}</Text>
        </View>
        <View style={styles.uberStatItem}>
          <Ionicons name="checkmark-done-outline" size={14} color="rgba(255,255,255,0.7)" />
          <Text style={styles.uberStatText}>{jobsText}</Text>
        </View>
        <View style={styles.uberStatItem}>
          <Ionicons name="location" size={14} color="rgba(255,255,255,0.7)" />
          <Text style={styles.uberStatText}>{distanceText}</Text>
        </View>
        {etaText && (
          <View style={styles.uberStatItem}>
            <Ionicons name="time" size={14} color="#60A5FA" />
            <Text style={[styles.uberStatText, { color: '#60A5FA' }]}>{etaText}</Text>
          </View>
        )}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <View style={StyleSheet.absoluteFill}>
        <MapView
          ref={mapRef}
          style={StyleSheet.absoluteFill}
          region={region ?? DEFAULT_MAP_REGION}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={BOOKING_MAP_STYLE}
        >
          {center && (
            <Marker coordinate={{ latitude: center.lat, longitude: center.lng }}>
              <View style={styles.userMarkerContainer}>
                <Image
                  source={require('../../../assets/car.png')}
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}

          {valeters.map((valeter) => {
            if (!valeter.lastLat || !valeter.lastLng) return null;
            const isSelected = selectedValeter === valeter.id;
            return (
              <Marker
                key={valeter.id}
                coordinate={{ latitude: valeter.lastLat, longitude: valeter.lastLng }}
                onPress={() => handleValeterSelect(valeter.id)}
              >
                <View style={styles.valeterMarkerContainer}>
                  <Image
                    source={require('../../../assets/cleaning.png')}
                    style={[
                      styles.valeterMarker,
                      isSelected && styles.valeterMarkerSelected
                    ]}
                    resizeMode="contain"
                  />
                  {valeter.isOnline && (
                    <View style={styles.valeterOnlineBadge}>
                      <View style={styles.valeterOnlineDot} />
                    </View>
                  )}
                </View>
              </Marker>
            );
          })}
        </MapView>
      </View>

      <TouchableOpacity
        onPress={async () => {
          hapticFeedback('light');
          const lat = liveCoords?.latitude ?? latitude;
          const lng = liveCoords?.longitude ?? longitude;
          if (lat != null && lng != null && Number.isFinite(lat) && Number.isFinite(lng)) {
            setRegion({ latitude: lat, longitude: lng, latitudeDelta: 0.002, longitudeDelta: 0.002 });
          } else {
            try {
              const loc = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
              setRegion({ latitude: loc.coords.latitude, longitude: loc.coords.longitude, latitudeDelta: 0.002, longitudeDelta: 0.002 });
            } catch {}
          }
        }}
        style={[styles.recenterButtonFloating, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS, right: RECENTER_BUTTON_RIGHT }]}
        activeOpacity={0.7}
      >
        <Ionicons name="locate" size={22} color={SKY} />
      </TouchableOpacity>

      <AppHeader
        title="Confirm your valeter"
        subtitle="We've found nearby valeters"
        showBack={true}
        onBack={() => router.back()}
        rightAction={
          <TouchableOpacity
            onPress={async () => {
              await hapticFeedback('light');
              router.replace('/owner/owner-dashboard' as any);
            }}
            style={styles.exitButton}
            activeOpacity={0.7}
          >
            <Ionicons name="close" size={22} color="#FFFFFF" />
          </TouchableOpacity>
        }
      />

      <Animated.View
        style={[
          styles.cardContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            top: windowHeight * 0.64,
            paddingBottom: 56 + Math.max(insets.bottom, 14) + 12 + TAB_BAR_TOTAL_HEIGHT,
          },
        ]}
      >
        {(() => {
          if (loading) {
            return (
              <View style={[styles.curvedCard, { borderColor: 'transparent' }]}>
                <View style={styles.valeterCard}>
                  <View style={styles.loadingContainer}>
                    <ActivityIndicator size="large" color={SKY} />
                    <Text style={styles.loadingText}>Finding nearby valeters…</Text>
                  </View>
                </View>
              </View>
            );
          }
          if (valeters.length === 0) {
            return (
              <View style={[styles.curvedCard, { borderColor: 'transparent' }]}>
                <View style={styles.valeterCard}>
                  <View style={styles.emptyContent}>
                    <View style={styles.valeterEmptyIcon}>
                      <Ionicons name="person-outline" size={32} color={SKY} />
                    </View>
                    <Text style={styles.emptyText}>No valeters available</Text>
                    <Text style={styles.emptySubtext}>Try again later or adjust your location</Text>
                  </View>
                </View>
              </View>
            );
          }
          return (
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.cardsScrollContent}
              snapToInterval={BOOKING_CARD.SNAP_INTERVAL}
              decelerationRate="fast"
              pagingEnabled
            >
              {valeters.map((valeter, index) => {
                const isSelected = selectedValeter === valeter.id;
                const isBestMatch = index === 0;
                const arrivalMins = valeter.eta && valeter.eta > 0 ? valeter.eta : Math.max(2, Math.round(valeter.distance * 2));
                return (
                  <View key={valeter.id} style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
                    <UnifiedBookingCard
                      stripColor={SKY}
                      intensity={18}
                      onPress={() => handleValeterSelect(valeter.id)}
                    >
                    {isBestMatch && (
                      <View style={styles.bestMatchBadge}>
                        <Ionicons name="star" size={12} color="#FBBF24" />
                        <Text style={styles.bestMatchText}>Best match for you</Text>
                      </View>
                    )}
                    {isSelected && (
                      <LinearGradient
                        colors={[SKY + '15', SKY + '08', 'transparent']}
                        start={{ x: 0, y: 0 }}
                        end={{ x: 1, y: 1 }}
                        style={StyleSheet.absoluteFill}
                        pointerEvents="none"
                      />
                    )}
                    <View style={[styles.valeterCard, isSelected && styles.valeterCardSelected]}>
                      <View style={styles.valeterCardTop}>
                        <View style={styles.valeterAvatarWrap}>
                          {valeter.profilePicture ? (
                            <Image source={{ uri: valeter.profilePicture }} style={styles.valeterAvatar} />
                          ) : (
                            <View style={styles.valeterAvatarPlaceholder}>
                              <Ionicons name="person" size={24} color={SKY} />
                            </View>
                          )}
                          {valeter.isOnline && (
                            <View style={styles.valeterOnlineBadgeSmall}>
                              <View style={styles.valeterOnlineDotSmall} />
                            </View>
                          )}
                        </View>
                        <View style={styles.valeterCardContent}>
                          <View style={styles.valeterTitleRow}>
                            <Text style={styles.valeterName} numberOfLines={1}>{valeter.name}</Text>
                          </View>
                          {(valeter.vehicleType || valeter.vehicleRegistration) && (
                            <View style={styles.valeterVehicleRow}>
                              <Ionicons name="car-sport-outline" size={12} color={SKY} />
                              <Text style={styles.valeterVehicleText} numberOfLines={1}>
                                {[valeter.vehicleType, valeter.vehicleRegistration].filter(Boolean).join(' • ')}
                              </Text>
                            </View>
                          )}
                          {renderValeterStats(valeter)}
                          <View style={styles.arrivalRow}>
                            <Ionicons name="time-outline" size={14} color="#60A5FA" />
                            <Text style={styles.arrivalText}>Arrives in ~{arrivalMins} mins</Text>
                          </View>
                        </View>
                      </View>
                    </View>
                    </UnifiedBookingCard>
                  </View>
                );
              })}
            </ScrollView>
          );
        })()}
      </Animated.View>

      {/* Floating Continue button - opens confirmation modal */}
      {(() => {
        const selectedValeterData = selectedValeter ? valeters.find(v => v.id === selectedValeter) : null;
        let ratingDisplay = '';
        if (selectedValeterData) {
          ratingDisplay = selectedValeterData.rating > 0 ? selectedValeterData.rating.toFixed(1) : '5.0';
        }
        let ctaLabel: string;
        if (selectedValeterData) {
          ctaLabel = `Confirm ${selectedValeterData.name.split(' ')[0]} (${ratingDisplay})`;
        } else {
          ctaLabel = "We've found valeters – pick one";
        }
        return (
          <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12 }]}>
            <TouchableOpacity
              onPress={handleConfirmValeterPress}
              disabled={!selectedValeter}
              style={styles.ctaButton}
              activeOpacity={0.9}
            >
              <LinearGradient
                colors={selectedValeter ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.ctaGradient}
              >
                <Text style={styles.ctaText} numberOfLines={1}>
                  {ctaLabel}
                </Text>
                {selectedValeterData ? (
                  <Ionicons name="star" size={16} color="#FBBF24" style={{ marginLeft: 4, marginRight: 6 }} />
                ) : null}
                <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
              </LinearGradient>
            </TouchableOpacity>
          </View>
        );
      })()}

      {/* Confirm valeter choice modal - confirm before sending request */}
      <Modal
        visible={showConfirmValeterModal}
        transparent
        animationType="fade"
        onRequestClose={() => !sendingRequest && setShowConfirmValeterModal(false)}
      >
        <Pressable
          style={styles.confirmModalOverlay}
          onPress={() => !sendingRequest && setShowConfirmValeterModal(false)}
        >
          <Pressable style={styles.confirmModalContent} onPress={(e) => e.stopPropagation()}>
            <BlurView intensity={36} tint="dark" style={StyleSheet.absoluteFill} />
            <LinearGradient
              colors={['rgba(15,23,42,0.97)', 'rgba(30,41,59,0.95)']}
              style={StyleSheet.absoluteFill}
            />
            <View style={styles.confirmModalInner}>
              {(() => {
                const v = selectedValeter ? valeters.find(x => x.id === selectedValeter) : null;
                if (!v) return null;
                const arrivalMins = v.eta && v.eta > 0 ? v.eta : Math.max(2, Math.round(v.distance * 2));
                const ratingText = v.rating > 0 ? v.rating.toFixed(1) : '5.0';
                const firstName = v.name.split(' ')[0];
                const serviceName = selectedServiceOption?.name ?? 'Wash';
                const basePrice = selectedServiceOption?.price ?? 25;
                const serviceTotal = basePrice - discountAmount;
                const finalPrice = serviceTotal + addOnsTotal;
                return (
                  <>
                    <View style={styles.confirmModalHeader}>
                      <View style={styles.confirmModalTitleRow}>
                        <View style={styles.confirmModalIconWrap}>
                          <Ionicons name="person-circle-outline" size={28} color={SKY} />
                        </View>
                        <Text style={styles.confirmModalTitle}>Send request to {firstName}?</Text>
                      </View>
                      <TouchableOpacity
                        onPress={() => !sendingRequest && setShowConfirmValeterModal(false)}
                        hitSlop={12}
                        disabled={sendingRequest}
                        style={styles.confirmModalCloseBtn}
                      >
                        <Ionicons name="close" size={24} color="#94A3B8" />
                      </TouchableOpacity>
                    </View>
                    <Text style={styles.confirmModalSubtitle}>
                      {firstName} will have a few minutes to accept. You can cancel the request anytime before they accept.
                    </Text>

                    <View style={styles.confirmValeterSummary}>
                      <View style={styles.confirmValeterAvatarWrap}>
                        {v.profilePicture ? (
                          <Image source={{ uri: v.profilePicture }} style={styles.confirmValeterAvatar} />
                        ) : (
                          <View style={styles.confirmValeterAvatarPlaceholder}>
                            <Ionicons name="person" size={32} color={SKY} />
                          </View>
                        )}
                        {v.isOnline && (
                          <View style={styles.confirmValeterOnlineBadge}>
                            <View style={styles.confirmValeterOnlineDot} />
                          </View>
                        )}
                      </View>
                      <View style={styles.confirmValeterDetails}>
                        <Text style={styles.confirmValeterName}>{v.name}</Text>
                        <View style={styles.confirmValeterMeta}>
                          <Ionicons name="star" size={14} color="#FBBF24" />
                          <Text style={styles.confirmValeterMetaText}>{ratingText}</Text>
                          <Text style={styles.confirmValeterMetaDot}>·</Text>
                          <Ionicons name="time-outline" size={12} color="#94A3B8" />
                          <Text style={styles.confirmValeterMetaText}>~{arrivalMins} min</Text>
                        </View>
                      </View>
                    </View>

                    <View style={styles.confirmServiceRow}>
                      <Ionicons name="car-wash-outline" size={18} color={SKY} />
                      <Text style={styles.confirmServiceLabel}>{serviceName}</Text>
                      <Text style={styles.confirmServicePrice}>£{finalPrice.toFixed(2)}</Text>
                    </View>

                    <Text style={styles.confirmModalHint}>No charge until the valeter accepts.</Text>

                    <View style={styles.confirmModalActions}>
                      <TouchableOpacity
                        style={styles.confirmModalCancel}
                        onPress={() => !sendingRequest && setShowConfirmValeterModal(false)}
                        disabled={sendingRequest}
                        activeOpacity={0.8}
                      >
                        <Text style={styles.confirmModalCancelText}>Go back</Text>
                      </TouchableOpacity>
                      <TouchableOpacity
                        style={[styles.confirmModalSend, sendingRequest && styles.confirmModalSendDisabled]}
                        onPress={handleSendRequest}
                        disabled={sendingRequest}
                        activeOpacity={0.9}
                      >
                        <LinearGradient
                          colors={[SKY, '#0EA5E9']}
                          start={{ x: 0, y: 0 }}
                          end={{ x: 1, y: 0 }}
                          style={styles.confirmModalSendGradient}
                        >
                          {sendingRequest ? (
                            <>
                              <ActivityIndicator size="small" color="#FFFFFF" />
                              <Text style={styles.confirmModalSendText}>Sending…</Text>
                            </>
                          ) : (
                            <>
                              <Ionicons name="rocket" size={18} color="#FFFFFF" />
                              <Text style={styles.confirmModalSendText}>GO!</Text>
                            </>
                          )}
                        </LinearGradient>
                      </TouchableOpacity>
                    </View>
                  </>
                );
              })()}
            </View>
          </Pressable>
        </Pressable>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  recenterButton: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 100,
  },
  valeterMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },
  valeterMarker: {
    width: 48,
    height: 48,
  },
  valeterMarkerSelected: {
    width: 48,
    height: 48,
  },
  valeterOnlineBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#0A1929',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  valeterOnlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  cardContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    paddingHorizontal: 12,
    paddingTop: 10,
  },
  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
  },
  ctaButton: {
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.15,
    shadowRadius: 6,
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
  },
  confirmModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.65)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  confirmModalContent: {
    width: '100%',
    maxWidth: 360,
    borderRadius: 24,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: SKY + '25',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 12 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 12,
  },
  confirmModalInner: {
    padding: 24,
  },
  confirmModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 10,
  },
  confirmModalTitleRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingRight: 8,
  },
  confirmModalIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: SKY + '22',
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    flex: 1,
    letterSpacing: -0.3,
  },
  confirmModalCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    lineHeight: 21,
    marginBottom: 18,
    paddingRight: 4,
  },
  confirmValeterSummary: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderRadius: 16,
    padding: 14,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.18)',
  },
  confirmValeterAvatarWrap: {
    marginRight: 14,
    position: 'relative',
  },
  confirmValeterAvatar: {
    width: 52,
    height: 52,
    borderRadius: 16,
  },
  confirmValeterAvatarPlaceholder: {
    width: 52,
    height: 52,
    borderRadius: 16,
    backgroundColor: SKY + '22',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: SKY + '35',
  },
  confirmValeterOnlineBadge: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    width: 14,
    height: 14,
    borderRadius: 7,
    backgroundColor: '#0F172A',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.9)',
  },
  confirmValeterOnlineDot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  confirmValeterDetails: {
    flex: 1,
    minWidth: 0,
  },
  confirmValeterName: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 4,
    letterSpacing: -0.2,
  },
  confirmValeterMeta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  confirmValeterMetaText: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  confirmValeterMetaDot: {
    color: '#64748B',
    fontSize: 13,
  },
  confirmServiceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 12,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(135,206,235,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.2)',
    marginBottom: 10,
  },
  confirmServiceLabel: {
    flex: 1,
    color: '#E2E8F0',
    fontSize: 15,
    fontWeight: '700',
  },
  confirmServicePrice: {
    color: SKY,
    fontSize: 16,
    fontWeight: '800',
  },
  confirmModalHint: {
    color: '#64748B',
    fontSize: 12,
    marginBottom: 20,
    textAlign: 'center',
  },
  confirmModalActions: {
    flexDirection: 'row',
    gap: 12,
  },
  confirmModalCancel: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: 14,
    backgroundColor: 'rgba(148,163,184,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.25)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  confirmModalCancelText: {
    color: '#E2E8F0',
    fontSize: 16,
    fontWeight: '700',
  },
  confirmModalSend: {
    flex: 1,
    borderRadius: 14,
    overflow: 'hidden',
  },
  confirmModalSendDisabled: {
    opacity: 0.85,
  },
  confirmModalSendGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 20,
    gap: 8,
  },
  confirmModalSendText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  cardWrapper: {
    marginRight: 12,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  valeterCardStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 4,
    borderTopLeftRadius: 14,
    borderBottomLeftRadius: 14,
    zIndex: 1,
  },
  bestMatchBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    position: 'absolute',
    top: 8,
    right: 8,
    zIndex: 5,
    backgroundColor: 'rgba(251, 191, 36, 0.18)',
    paddingHorizontal: 6,
    paddingVertical: 3,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(251, 191, 36, 0.4)',
  },
  bestMatchText: {
    fontSize: 10,
    fontWeight: '700',
    color: '#FBBF24',
  },
  arrivalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 6,
  },
  arrivalText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#60A5FA',
  },
  stickySummary: {
    position: 'absolute',
    left: 16,
    right: 16,
    paddingVertical: 10,
    paddingHorizontal: 14,
    borderRadius: 12,
    backgroundColor: 'rgba(15,23,42,0.9)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    zIndex: 50,
  },
  stickySummaryText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#E2E8F0',
    textAlign: 'center',
  },
  valeterCard: {
    padding: 18,
    overflow: 'hidden',
    minHeight: 160,
  },
  valeterVehicleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 6,
    marginBottom: 2,
  },
  valeterVehicleText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '600',
    flex: 1,
  },
  valeterCardSelected: {
    borderWidth: 0,
    borderColor: 'transparent',
    shadowColor: SKY,
    shadowOpacity: 0.12,
    shadowRadius: 6,
    elevation: 3,
  },
  valeterCardTop: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  valeterAvatarWrap: {
    width: 52,
    height: 52,
    borderRadius: 18,
    marginRight: 14,
    overflow: 'hidden',
    position: 'relative',
  },
  valeterAvatar: {
    width: '100%',
    height: '100%',
  },
  valeterAvatarPlaceholder: {
    width: '100%',
    height: '100%',
    backgroundColor: SKY + '20',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: SKY + '40',
  },
  valeterOnlineBadgeSmall: {
    position: 'absolute',
    bottom: 2,
    right: 2,
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#0A1929',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1.5,
    borderColor: '#FFFFFF',
  },
  valeterOnlineDotSmall: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: '#10B981',
  },
  valeterCardContent: {
    flex: 1,
    minWidth: 0,
  },
  valeterTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  valeterName: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    flex: 1,
  },
  valeterSelectedBadge: {
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 10,
    backgroundColor: '#10B98120',
    borderWidth: 1,
    borderColor: '#10B98140',
  },
  valeterCtaDivider: {
    height: 1,
    marginTop: 14,
    marginBottom: 12,
    borderRadius: 1,
  },
  valeterCtaButton: {
    borderRadius: 12,
    overflow: 'hidden',
    elevation: 4,
  },
  valeterCtaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 12,
    paddingHorizontal: 20,
    gap: 8,
  },
  valeterCtaText: {
    color: '#FFFFFF',
    fontSize: 15,
    fontWeight: '800',
  },
  valeterEmptyIcon: {
    width: 52,
    height: 52,
    borderRadius: 18,
    backgroundColor: SKY + '15',
    borderWidth: 1,
    borderColor: SKY + '30',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 14,
  },
  uberValeterCard: {
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderRadius: 18,
    padding: 16,
    marginBottom: 12,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.15)',
  },
  uberValeterCardSelected: {
    borderColor: '#60A5FA',
    shadowColor: '#60A5FA',
    shadowOpacity: 0.3,
  },
  uberValeterCardContent: {
    width: '100%',
  },
  uberValeterHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 12,
  },
  uberValeterLeft: {
    position: 'relative',
  },
  uberProfileImage: {
    width: 56,
    height: 56,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 2,
    borderColor: '#60A5FA',
  },
  uberOnlineBadge: {
    position: 'absolute',
    bottom: -2,
    right: -2,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: '#FFFFFF',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  uberOnlineDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: '#10B981',
  },
  uberValeterInfo: {
    flex: 1,
  },
  uberValeterNameRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  uberValeterName: {
    color: '#FFFFFF',
    fontSize: 20,
    fontWeight: '800',
    flex: 1,
    letterSpacing: 0.2,
  },
  uberSelectedBadge: {
    marginLeft: 8,
  },
  uberValeterActionRow: {
    marginTop: 16,
    paddingTop: 16,
    borderTopWidth: 1,
    borderTopColor: 'rgba(255,255,255,0.15)',
  },
  uberValeterButton: {
    backgroundColor: '#60A5FA',
    borderRadius: 12,
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
  },
  uberValeterButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
    letterSpacing: 0.3,
  },
  loadingContainer: {
    padding: 40,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: '#FFFFFF',
    fontSize: 14,
  },
  emptyContent: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
    marginBottom: 8,
  },
  emptySubtext: {
    color: '#9CA3AF',
    fontSize: 14,
    textAlign: 'center',
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 100,
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  headerLocateButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(0, 0, 0, 0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  uberValeterStats: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flexWrap: 'wrap',
  },
  uberStatItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  uberStatText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 13,
    fontWeight: '500',
  },
});