import { colors } from '../../../src/constants/colors';

const SKY = colors.SKY ?? '#38BDF8';

export type BookingStatus =
  | 'pending_valeter_acceptance'
  | 'pending_payment'
  | 'confirmed'
  | 'valeter_assigned'
  | 'en_route'
  | 'arrived'
  | 'in_progress'
  | 'completed'
  | 'cancelled'
  | 'valeter_declined'
  | 'valeter_timeout';

export type StepCardConfig = {
  stepTitle: string;
  stepSubtitle: string;
  stepIcon: 'time-outline' | 'wallet-outline' | 'checkmark-circle' | 'car' | 'location' | 'water' | 'sparkles';
  stepAccent: string;
};

export function getStatusProgress(status: BookingStatus): number {
  switch (status) {
    case 'pending_valeter_acceptance':
    case 'pending_payment':
      return 20;
    case 'confirmed':
      return 40;
    case 'en_route':
      return 60;
    case 'arrived':
      return 80;
    case 'in_progress':
      return 90;
    case 'completed':
    case 'cancelled':
      return 100;
    default:
      return 0;
  }
}

export function getStages(status: BookingStatus): { label: string; done: boolean; current: boolean; icon: 'checkmark-circle' | 'car' | 'location' | 'water' | 'sparkles' }[] {
  const s = status;
  return [
    { label: 'Accepted', done: !['pending_valeter_acceptance', 'pending_payment'].includes(s), current: ['confirmed', 'valeter_assigned'].includes(s), icon: 'checkmark-circle' },
    { label: 'En route', done: ['arrived', 'in_progress', 'completed'].includes(s), current: s === 'en_route', icon: 'car' },
    { label: 'Arrived', done: ['in_progress', 'completed'].includes(s), current: s === 'arrived', icon: 'location' },
    { label: 'Washing', done: s === 'completed', current: s === 'in_progress', icon: 'water' },
    { label: 'Done', done: s === 'completed', current: s === 'completed', icon: 'sparkles' },
  ];
}

export function getStatusMessage(status: BookingStatus, washHub: { name: string } | null): string {
  switch (status) {
    case 'pending_valeter_acceptance':
      return 'Connecting to your pro';
    case 'pending_payment':
      return 'Waiting for payment';
    case 'confirmed':
      return 'Valeter assigned – Ready to start';
    case 'en_route':
      return washHub ? 'Heading to wash hub' : 'Valeter on the way to you';
    case 'arrived':
      return washHub ? 'At wash hub' : 'Valeter has arrived';
    case 'in_progress':
      return washHub ? 'Vehicle being washed' : 'Service in progress';
    case 'completed':
      return 'Service completed';
    case 'cancelled':
    case 'valeter_declined':
    case 'valeter_timeout':
      return 'Booking cancelled';
    default:
      return 'Tracking your booking';
  }
}

export function getStepCardConfig(
  status: BookingStatus,
  valeterName: string,
  washHub: { name: string } | null
): StepCardConfig {
  switch (status) {
    case 'pending_valeter_acceptance':
      return { stepTitle: 'Connecting to your pro', stepSubtitle: "We're connecting you with your pro", stepIcon: 'time-outline', stepAccent: '#F59E0B' };
    case 'pending_payment':
      return { stepTitle: 'Pay to confirm', stepSubtitle: 'Complete payment to lock in your booking', stepIcon: 'wallet-outline', stepAccent: '#F59E0B' };
    case 'confirmed':
    case 'valeter_assigned':
      return { stepTitle: 'Accepted', stepSubtitle: `${valeterName} is assigned – getting ready to head your way`, stepIcon: 'checkmark-circle', stepAccent: '#8B5CF6' };
    case 'en_route':
      return { stepTitle: 'On the way', stepSubtitle: washHub ? 'Heading to the wash hub' : `${valeterName} is on the way to you`, stepIcon: 'car', stepAccent: SKY };
    case 'arrived':
      return { stepTitle: 'Arrived', stepSubtitle: washHub ? "At the wash hub – tap \"I've arrived\" when you're there" : `${valeterName} has arrived at your location`, stepIcon: 'location', stepAccent: '#10B981' };
    case 'in_progress':
      return { stepTitle: 'Washing', stepSubtitle: 'Your vehicle is being cleaned right now', stepIcon: 'water', stepAccent: '#0EA5E9' };
    case 'completed':
      return { stepTitle: 'All done', stepSubtitle: 'Service completed – rate your experience', stepIcon: 'sparkles', stepAccent: '#10B981' };
    case 'cancelled':
    case 'valeter_declined':
    case 'valeter_timeout':
      return { stepTitle: 'Cancelled', stepSubtitle: 'This booking was cancelled', stepIcon: 'checkmark-circle', stepAccent: '#64748B' };
    default:
      return {
        stepTitle: 'Tracking',
        stepSubtitle: getStatusMessage(status, washHub),
        stepIcon: 'car',
        stepAccent: SKY,
      };
  }
}

export function getRingColorForStep(status: BookingStatus): string {
  switch (status) {
    case 'pending_valeter_acceptance':
    case 'pending_payment':
      return '#F59E0B';
    case 'confirmed':
    case 'valeter_assigned':
      return '#8B5CF6';
    case 'en_route':
      return SKY;
    case 'arrived':
      return '#10B981';
    case 'in_progress':
      return '#0EA5E9';
    case 'completed':
      return '#10B981';
    case 'cancelled':
    case 'valeter_declined':
    case 'valeter_timeout':
      return '#64748B';
    default:
      return SKY;
  }
}

export function getStageProgressPercent(status: BookingStatus): number {
  const stages = getStages(status);
  const doneCount = stages.filter((s) => s.done).length;
  const currentIndex = stages.findIndex((s) => s.current);
  if (currentIndex >= 0) return (currentIndex + 0.5) * 25;
  return doneCount * 25;
}
