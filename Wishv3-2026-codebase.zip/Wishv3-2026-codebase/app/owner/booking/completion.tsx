import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  SafeAreaView,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Image,
  Alert,
  Platform,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import MapView, { Marker } from 'react-native-maps';
import { router, useLocalSearchParams } from 'expo-router';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { BOOKING_MAP_STYLE } from '../../../src/constants/mapConstants';

let useStripe: any = null;
if (Platform.OS !== 'web') {
  try {
    const stripe = require('@stripe/stripe-react-native');
    useStripe = stripe.useStripe;
  } catch {}
}
import GlassCard from '@/components/booking/GlassCard';
import { getServiceDisplayName } from '../../../src/utils/serviceNameMapper';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { customerTheme } from '../../../src/constants/customerTheme';
import { colors } from '../../../src/constants/colors';
import SuccessOverlay from '../../../src/components/booking/SuccessOverlay';
import { fetchProfileById } from '../../../src/utils/customerProfiles';
import { ValeterStatsService } from '../../../src/services/Valeterstatsservice';
import { WashHubStatsService } from '../../../src/services/WashHubStatsService';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const BG = colors.BG;

const TIP_OPTIONS = [0, 2, 5, 10];

export default function BookingCompletion() {
  const { user } = useAuth();
    const params = useLocalSearchParams();
  const bookingId = params.bookingId as string;
  const alreadyCelebrated = params.celebrated === '1';

  const [booking, setBooking] = useState<any | null>(null);
  const [rating, setRating] = useState(0);
  const [review, setReview] = useState('');
  const [tipAmount, setTipAmount] = useState(0);
  const [tipPaid, setTipPaid] = useState(false);
  const [tipPaying, setTipPaying] = useState(false);
  const [valeterName, setValeterName] = useState<string>('');
  const [valeterPhoto, setValeterPhoto] = useState<string | null>(null);
  const [valeterStats, setValeterStats] = useState<{ totalJobs: number; averageRating: number } | null>(null);
  const [hubName, setHubName] = useState<string>('');
  const [hubAddress, setHubAddress] = useState<string>('');
  const [hubStats, setHubStats] = useState<{ totalJobs: number; averageRating: number } | null>(null);

  const stripeHook = useStripe ? useStripe() : null;
  const fadeAnim = useRef(new Animated.Value(0)).current;
  const [showSuccessOverlay, setShowSuccessOverlay] = useState(!alreadyCelebrated);

  useEffect(() => {
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();

    loadBooking();
  }, [bookingId]);

  const loadBooking = async () => {
    try {
      const { data, error } = await supabase
        .from('bookings')
        .select('*')
        .eq('id', bookingId)
        .single();

      if (error) throw error;
      setBooking(data);

      if (data?.valeter_id) {
        const [profile, stats] = await Promise.all([
          fetchProfileById(data.valeter_id),
          ValeterStatsService.getValeterStats(data.valeter_id),
        ]);
        setValeterName(profile?.full_name || 'Valeter');
        setValeterStats({ totalJobs: stats.totalJobs, averageRating: stats.averageRating });

        try {
          const { data: vp } = await supabase
            .from('valeter_profiles')
            .select('profile_photo_url')
            .eq('user_id', data.valeter_id)
            .maybeSingle();
          if (vp?.profile_photo_url) setValeterPhoto(vp.profile_photo_url);
        } catch {}
      }

      if (data?.location_id) {
        try {
          const { data: hub } = await supabase
            .from('car_wash_locations')
            .select('name, address')
            .eq('id', data.location_id)
            .single();
          if (hub) {
            setHubName(hub.name || 'Wash Hub');
            setHubAddress(hub.address || '');
          }
          const stats = await WashHubStatsService.getHubStats(data.location_id);
          setHubStats(stats);
        } catch (e) {
          console.warn('Error loading wash hub:', e);
        }
      }
    } catch (error) {
      console.error('Error loading booking:', error);
    }
  };

  const handleRatingSelect = async (value: number) => {
    await hapticFeedback('light');
    setRating(value);
  };

  const handlePayTip = async () => {
    if (!bookingId || !user?.id || tipAmount <= 0 || tipPaid || Platform.OS === 'web') return;
    const presentSheet = stripeHook?.presentPaymentSheet;
    if (!presentSheet) {
      Alert.alert('Payment not available', 'Tip payment is not supported on this device.');
      return;
    }
    setTipPaying(true);
    try {
      const amountPence = Math.round(tipAmount * 100);
      const { data, error } = await supabase.functions.invoke('hyper-endpoint', {
        body: {
          bookingId,
          amount: amountPence,
          currency: 'gbp',
          customerId: user.id,
          description: `${booking?.location_id ? 'Tip for wash hub' : 'Tip for valeter'} - booking ${bookingId}`,
        },
      });
      if (error) throw error;
      const cs = data?.clientSecret ?? data?.client_secret ?? data?.paymentIntentClientSecret ?? data?.payment_intent_client_secret ?? data?.paymentIntent?.clientSecret ?? data?.paymentIntent?.client_secret;
      if (!cs) throw new Error('No payment secret returned');
      const { error: initErr } = await stripeHook.initPaymentSheet({
        paymentIntentClientSecret: cs,
        merchantDisplayName: 'Wish a Wash',
        returnURL: 'waw://stripe-redirect',
        style: 'automatic',
      });
      if (initErr) throw initErr;
      const { error: presentErr } = await presentSheet();
      if (presentErr) {
        if (presentErr.code !== 'Canceled') throw presentErr;
        setTipPaying(false);
        return;
      }
      await supabase.from('bookings').update({ tip_amount: tipAmount }).eq('id', bookingId);
      setTipPaid(true);
      hapticFeedback('success');
    } catch (e: any) {
      Alert.alert('Tip payment failed', e?.message || 'Please try again.');
    } finally {
      setTipPaying(false);
    }
  };

  const handleSubmitReview = async () => {
    if (rating === 0) {
      Alert.alert('Rating Required', 'Please select a rating');
      return;
    }
    if (tipAmount > 0 && !tipPaid) {
      Alert.alert('Tip not paid', 'You selected a tip but haven\'t paid it yet. Tap "Pay £' + tipAmount + ' tip" to add a tip, or choose "None" to skip.');
      return;
    }

    await hapticFeedback('medium');

    try {
      const { error } = await supabase
        .from('bookings')
        .update({
          rating,
          tip_amount: tipPaid ? tipAmount : 0,
          status: 'completed',
        })
        .eq('id', bookingId);

      if (error) throw error;
      router.replace('/owner/owner-dashboard');
    } catch (error) {
      console.error('Error submitting review:', error);
      Alert.alert('Error', 'Could not save your rating. Please try again.');
    }
  };

  const handleSkip = () => {
    router.replace('/owner/owner-dashboard');
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Rate & Tip"
        subtitle={booking?.valeter_id ? 'How was your valeter?' : booking?.location_id ? 'How was your wash?' : 'Service complete!'}
        showBack
        onBack={() => { hapticFeedback('light'); router.back(); }}
      />

      <Animated.View
        style={[
          styles.content,
          {
            opacity: fadeAnim,
          },
        ]}
      >
        <ScrollView
          showsVerticalScrollIndicator={false}
          contentContainerStyle={[
            styles.scrollContent,
            { paddingTop: HEADER_CONTENT_OFFSET, opacity: showSuccessOverlay ? 0 : 1 },
          ]}
          pointerEvents={showSuccessOverlay ? 'none' : 'auto'}
        >
          {/* Journey complete – mini map */}
          {booking?.location_lat != null && booking?.location_lng != null && (
            <View style={styles.journeyCompleteSection}>
              <Text style={styles.journeyCompleteTitle}>Journey complete</Text>
              <View style={styles.miniMapWrap}>
                <MapView
                  style={styles.miniMap}
                  region={{
                    latitude: booking.location_lat,
                    longitude: booking.location_lng,
                    latitudeDelta: 0.004,
                    longitudeDelta: 0.004,
                  }}
                  scrollEnabled={false}
                  pitchEnabled={false}
                  rotateEnabled={false}
                  customMapStyle={BOOKING_MAP_STYLE}
                >
                  <Marker
                    coordinate={{
                      latitude: booking.location_lat,
                      longitude: booking.location_lng,
                    }}
                    title="Service completed"
                  >
                    <View style={styles.completionMarker}>
                      <Ionicons name="checkmark-circle" size={36} color={SKY} />
                    </View>
                  </Marker>
                </MapView>
              </View>
            </View>
          )}

          {/* Valeter Profile Card */}
          {booking?.valeter_id && (
            <GlassCard style={styles.profileCard}>
              <View style={styles.profileCardRow}>
                <View style={styles.profileAvatarWrap}>
                  {valeterPhoto ? (
                    <Image source={{ uri: valeterPhoto }} style={styles.profileAvatar} />
                  ) : (
                    <View style={styles.profileAvatarPlaceholder}>
                      <Ionicons name="person" size={32} color={SKY} />
                    </View>
                  )}
                </View>
                <View style={styles.profileInfo}>
                  <Text style={styles.profileName}>{valeterName}</Text>
                  {valeterStats && (
                    <View style={styles.profileStatsRow}>
                      <View style={styles.profileStat}>
                        <Ionicons name="water" size={14} color={SKY} />
                        <Text style={styles.profileStatText}>{valeterStats.totalJobs} washes</Text>
                      </View>
                      {valeterStats.averageRating > 0 && (
                        <View style={styles.profileStat}>
                          <Ionicons name="star" size={14} color="#FBBF24" />
                          <Text style={styles.profileStatText}>{valeterStats.averageRating.toFixed(1)}</Text>
                        </View>
                      )}
                    </View>
                  )}
                  <View style={styles.serviceTheyDid}>
                    <Text style={styles.serviceTheyDidLabel}>Wash they did for you</Text>
                    <Text style={styles.serviceTheyDidValue}>
                      {getServiceDisplayName(booking.service_type, booking.service_name)} • £{Number(booking.price ?? 0).toFixed(2)}
                    </Text>
                  </View>
                </View>
              </View>
            </GlassCard>
          )}

          {/* Wash Hub Profile Card */}
          {booking?.location_id && (
            <GlassCard style={styles.profileCard}>
              <View style={styles.profileCardRow}>
                <View style={[styles.profileAvatarWrap, styles.hubAvatarWrap]}>
                  <Ionicons name="business" size={32} color={SKY} />
                </View>
                <View style={styles.profileInfo}>
                  <Text style={styles.profileName}>{hubName || 'Wash Hub'}</Text>
                  {hubAddress ? (
                    <Text style={styles.profileMeta} numberOfLines={2}>{hubAddress}</Text>
                  ) : null}
                  {hubStats && (
                    <View style={styles.profileStatsRow}>
                      <View style={styles.profileStat}>
                        <Ionicons name="water" size={14} color={SKY} />
                        <Text style={styles.profileStatText}>{hubStats.totalJobs} washes</Text>
                      </View>
                      {hubStats.averageRating > 0 && (
                        <View style={styles.profileStat}>
                          <Ionicons name="star" size={14} color="#FBBF24" />
                          <Text style={styles.profileStatText}>{hubStats.averageRating.toFixed(1)}</Text>
                        </View>
                      )}
                    </View>
                  )}
                  <View style={styles.serviceTheyDid}>
                    <Text style={styles.serviceTheyDidLabel}>Service you had</Text>
                    <Text style={styles.serviceTheyDidValue}>
                      {getServiceDisplayName(booking.service_type, booking.service_name)} • £{Number(booking.price ?? 0).toFixed(2)}
                    </Text>
                  </View>
                </View>
              </View>
            </GlassCard>
          )}

          {/* Rating Section */}
          <GlassCard style={styles.ratingCard}>
            <View style={styles.ratingHeader}>
              <Ionicons name="star" size={24} color="#FBBF24" />
              <Text style={styles.ratingTitle}>Rate Your Experience</Text>
            </View>
            <View style={styles.starsContainer}>
              {[1, 2, 3, 4, 5].map((value) => (
                <TouchableOpacity
                  key={value}
                  onPress={() => handleRatingSelect(value)}
                  style={styles.starButton}
                >
                  <Ionicons
                    name={value <= rating ? 'star' : 'star-outline'}
                    size={40}
                    color={value <= rating ? '#FBBF24' : '#6B7280'}
                  />
                </TouchableOpacity>
              ))}
            </View>
            {rating > 0 && (
              <Text style={styles.ratingText}>
                {rating === 5 ? 'Excellent!' : rating === 4 ? 'Great!' : rating === 3 ? 'Good!' : rating === 2 ? 'Fair' : 'Poor'}
              </Text>
            )}
          </GlassCard>

          {/* Tip Section - for valeter or wash hub */}
          {(booking?.valeter_id || booking?.location_id) && (
            <GlassCard style={styles.tipCard}>
              <View style={styles.tipHeader}>
                <Ionicons name="heart-outline" size={22} color={SKY} />
                <Text style={styles.tipTitle}>
                  {booking?.valeter_id ? 'Add a tip for your valeter?' : 'Add a tip for the wash hub?'}
                </Text>
              </View>
              <View style={styles.tipOptions}>
                {TIP_OPTIONS.map((amount) => (
                  <TouchableOpacity
                    key={amount}
                    onPress={async () => {
                      await hapticFeedback('light');
                      setTipAmount(amount);
                      if (amount === 0) setTipPaid(false);
                    }}
                    style={[styles.tipOption, tipAmount === amount && styles.tipOptionSelected]}
                  >
                    <Text style={[styles.tipOptionText, tipAmount === amount && styles.tipOptionTextSelected]}>
                      {amount === 0 ? 'None' : `£${amount}`}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
              {tipAmount > 0 && (
                <TouchableOpacity
                  onPress={handlePayTip}
                  disabled={tipPaid || tipPaying}
                  style={[styles.payTipButton, tipPaid && styles.payTipButtonPaid]}
                  activeOpacity={0.9}
                >
                  <LinearGradient
                    colors={tipPaid ? ['#10B981', '#059669'] : [SKY, '#60A5FA']}
                    style={styles.payTipGradient}
                  >
                    {tipPaying ? (
                      <Text style={styles.payTipText}>Processing…</Text>
                    ) : tipPaid ? (
                      <>
                        <Ionicons name="checkmark-circle" size={20} color="#FFFFFF" />
                        <Text style={styles.payTipText}>Tip paid £{tipAmount}</Text>
                      </>
                    ) : (
                      <>
                        <Ionicons name="wallet" size={20} color="#FFFFFF" />
                        <Text style={styles.payTipText}>Pay £{tipAmount} tip</Text>
                      </>
                    )}
                  </LinearGradient>
                </TouchableOpacity>
              )}
            </GlassCard>
          )}

          {/* Action Buttons */}
          <View style={styles.actionsContainer}>
            <TouchableOpacity
              onPress={handleSubmitReview}
              style={styles.submitButton}
              activeOpacity={0.8}
            >
                <LinearGradient
                  colors={[SKY, '#60A5FA']}
                  style={styles.submitGradient}
                >
                  <Text style={styles.submitText}>
                    {rating > 0 ? 'Submit Review' : 'Submit Rating'}
                    {tipAmount > 0 ? ` + £${tipAmount} tip` : ''}
                  </Text>
                </LinearGradient>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={handleSkip}
              style={styles.skipButton}
            >
              <Text style={styles.skipText}>Skip for Now</Text>
            </TouchableOpacity>
          </View>
        </ScrollView>
      </Animated.View>

      {/* Boom! overlay with confetti - shows first, then ratings/profile/tip */}
      <SuccessOverlay
        visible={showSuccessOverlay}
        type="completed"
        message="Boom! Your super clean now"
        onComplete={() => setShowSuccessOverlay(false)}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
    alignItems: 'center',
  },
  journeyCompleteSection: {
    width: '100%',
    maxWidth: 400,
    marginBottom: 20,
  },
  journeyCompleteTitle: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 14,
    fontWeight: '700',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
    marginBottom: 8,
    paddingHorizontal: 4,
  },
  miniMapWrap: {
    height: 160,
    borderRadius: 16,
    overflow: 'hidden',
    backgroundColor: 'rgba(15,23,42,0.5)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  miniMap: {
    width: '100%',
    height: '100%',
    borderRadius: 16,
  },
  completionMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  successContainer: {
    alignItems: 'center',
    marginBottom: 32,
  },
  successCircle: {
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(16,185,129,0.2)',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  successTitle: {
    color: '#F9FAFB',
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  successSubtitle: {
    color: SKY,
    fontSize: 16,
  },
  profileCard: {
    padding: 20,
    marginBottom: 16,
    width: '100%',
  },
  profileCardRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 16,
  },
  profileAvatarWrap: {
    width: 64,
    height: 64,
  },
  profileAvatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
  },
  profileAvatarPlaceholder: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  hubAvatarWrap: {
    backgroundColor: 'rgba(135,206,235,0.2)',
    borderRadius: 32,
    justifyContent: 'center',
    alignItems: 'center',
  },
  profileInfo: {
    flex: 1,
    minWidth: 0,
  },
  profileName: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
  },
  profileMeta: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
    marginBottom: 8,
  },
  profileStatsRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 10,
  },
  profileStat: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  profileStatText: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  serviceTheyDid: {
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: 'rgba(135,206,235,0.2)',
  },
  serviceTheyDidLabel: {
    color: '#94A3B8',
    fontSize: 12,
    fontWeight: '600',
    marginBottom: 2,
  },
  serviceTheyDidValue: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
  },
  tipCard: {
    padding: 20,
    marginBottom: 24,
    width: '100%',
  },
  tipHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 14,
  },
  tipTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '700',
  },
  tipOptions: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 10,
  },
  tipOption: {
    paddingVertical: 12,
    paddingHorizontal: 20,
    borderRadius: 12,
    backgroundColor: 'rgba(148,163,184,0.15)',
    borderWidth: 1.5,
    borderColor: 'rgba(148,163,184,0.3)',
  },
  tipOptionSelected: {
    backgroundColor: 'rgba(135,206,235,0.25)',
    borderColor: SKY,
  },
  tipOptionText: {
    color: '#94A3B8',
    fontSize: 15,
    fontWeight: '700',
  },
  tipOptionTextSelected: {
    color: SKY,
  },
  payTipButton: {
    marginTop: 16,
    borderRadius: 14,
    overflow: 'hidden',
  },
  payTipButtonPaid: {
    opacity: 0.9,
  },
  payTipGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 14,
    paddingHorizontal: 24,
    gap: 10,
  },
  payTipText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
  ratingCard: {
    padding: 24,
    marginBottom: 24,
    width: '100%',
  },
  ratingHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 20,
  },
  ratingTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: 'bold',
  },
  starsContainer: {
    flexDirection: 'row',
    justifyContent: 'center',
    gap: 12,
    marginBottom: 16,
  },
  starButton: {
    padding: 4,
  },
  ratingText: {
    color: SKY,
    fontSize: 16,
    fontWeight: '600',
    textAlign: 'center',
  },
  actionsContainer: {
    width: '100%',
    gap: 12,
  },
  submitButton: {
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  submitGradient: {
    paddingVertical: 16,
    paddingHorizontal: 32,
    alignItems: 'center',
  },
  submitText: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: 'bold',
  },
  skipButton: {
    paddingVertical: 12,
    alignItems: 'center',
  },
  skipText: {
    color: '#9CA3AF',
    fontSize: 14,
  },
});

