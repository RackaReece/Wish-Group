import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Dimensions,
  Animated,
  Alert,
  Image,
  ActivityIndicator,
  Modal,
  TextInput,
  Pressable,
} from 'react-native';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { BlurView } from 'expo-blur';
import { Ionicons } from '@expo/vector-icons';
import { router, useLocalSearchParams } from 'expo-router';
import MapView, { Region, Marker, MapPressEvent } from 'react-native-maps';
import * as Location from 'expo-location';
import useLiveLocation from '../../../src/hooks/useLiveLocation';
import { useAuth } from '../../../src/providers/enhanced-auth-context';
import { supabase } from '../../../src/lib/supabase';
import { hapticFeedback } from '../../../src/services/HapticFeedbackService';
import { TAB_BAR_TOTAL_HEIGHT } from '../../components/NavigationTab';
import { serviceOptions, detailingServiceOptions, addOnOptions } from '../../../src/constants/serviceOptions';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../../../src/components/shared/AppHeader';
import { colors } from '../../../src/constants/colors';
import { customerTheme } from '../../../src/constants/customerTheme';
import {
  calculateDisplayPrice,
  getVehicleSize,
  mapServiceIdToWashId,
  FrontendPricingInput
} from '../../../src/pricing/pricingEngine';


import { BOOKING_CARD } from '../../../src/constants/bookingCardTheme';
import UnifiedBookingCard from '../../../src/components/booking/UnifiedBookingCard';
import InfoIconButton from '../../../src/components/shared/InfoIconButton';
import { DEFAULT_MAP_REGION, BOOKING_MAP_STYLE, RECENTER_BUTTON_RIGHT, RECENTER_BUTTON_TOP_BELOW_ACTIONS } from '../../../src/constants/mapConstants';

const { width } = Dimensions.get('window');
const CARD_WIDTH = BOOKING_CARD.CARD_WIDTH;
const SKY = colors.SKY;
const CARD_GRADIENT = BOOKING_CARD.GRADIENT;
const BG = colors.BG;
const LOCATION_CARD_GREEN = colors.ECO_GREEN;
const DETAILING_YELLOW = colors.DETAILING_YELLOW;

type Vehicle = {
  id: string;
  type?: string;
  make: string;
  model: string;
  color: string;
  registration: string;
  is_default: boolean;
  size?: string;
  image_url?: string | null;
  photo?: string | null;
};

function formatVehicleSize(size: string | null | undefined): string {
  if (!size) return '';
  const s = String(size).toLowerCase();
  if (s === 'small') return 'Small';
  if (s === 'medium') return 'Medium';
  if (s === 'large') return 'Large';
  return s.charAt(0).toUpperCase() + s.slice(1);
}

/** Map vehicle color name to hex for card border; fallback SKY. */
function getVehicleBorderColor(color: string | null | undefined, fallback: string): string {
  if (!color?.trim()) return fallback;
  const c = color.trim().toLowerCase();
  const map: Record<string, string> = {
    black: '#111827',
    white: '#E5E7EB',
    silver: '#9CA3AF',
    grey: '#6B7280',
    gray: '#6B7280',
    red: '#DC2626',
    blue: '#2563EB',
    navy: '#1E3A8A',
    green: '#059669',
    yellow: '#EAB308',
    gold: '#B45309',
    orange: '#EA580C',
    brown: '#92400E',
    beige: '#A16207',
    tan: '#D4A574',
    purple: '#7C3AED',
    burgundy: '#881337',
    bronze: '#92400E',
    champagne: '#D6D3C4',
    cream: '#FEF3C7',
  };
  if (map[c]) return map[c];
  for (const [key, hex] of Object.entries(map)) {
    if (c.includes(key)) return hex;
  }
  return fallback;
}

/** Strip color for service card side border: wash tiers, or yellow for all detailing services. */
function getServiceStripColor(serviceId: string, fallback: string): string {
  const id = serviceId.toLowerCase();
  const washMap: Record<string, string> = {
    'bronze-wash': '#92400E',
    'eco-bronze-wash': '#92400E',
    'silver-wash': '#C0C0C0',
    'eco-silver-wash': '#C0C0C0',
    'gold-wash': '#EAB308',
    'eco-gold-wash': '#EAB308',
    'platinum-wash': '#334155',
    'eco-platinum-wash': '#334155',
  };
  if (washMap[id]) return washMap[id];
  const detailingIds = ['interior-detail', 'exterior-detail', 'full-detail', 'paint-correction', 'ceramic-coating', 'ppf'];
  if (detailingIds.includes(id)) return DETAILING_YELLOW;
  return fallback;
}

type BookingStep = 'location' | 'vehicle' | 'service';

type ServiceMode = 'wash' | 'detailing';

function getBookingHeaderConfig(step: BookingStep): { title: string; subtitle: string; backStep: BookingStep | null } {
  switch (step) {
    case 'location':
      return { title: 'Confirm location', subtitle: 'Tap on map to set where your washer will arrive', backStep: null };
    case 'vehicle':
      return { title: 'Confirm vehicle', subtitle: 'Swipe to see all vehicles', backStep: 'location' };
    default:
      return { title: 'Confirm service', subtitle: 'Swipe to see all services', backStep: 'vehicle' };
  }
}

// eslint-disable-next-line sonarjs/cognitive-complexity -- multi-step booking flow; logic split via getBookingHeaderConfig and step renderers
export default function BookingCreate() {
  const params = useLocalSearchParams<{ serviceMode?: string; customerOffersWater?: string; customerOffersElectricity?: string }>();
  const [offersWater, setOffersWater] = useState(params.customerOffersWater === 'true');
  const [offersElectricity, setOffersElectricity] = useState(params.customerOffersElectricity === 'true');
  const [infoService, setInfoService] = useState<{ id?: string; name?: string; icon?: string; price?: number | string; desc?: string; bulletPoints?: string[] } | null>(null);
  const [infoVehicle, setInfoVehicle] = useState<Vehicle | null>(null);
  const [vehicleWashCount, setVehicleWashCount] = useState(0);
  const [showAddressOverlay, setShowAddressOverlay] = useState(false);
  const [addressSearchInput, setAddressSearchInput] = useState('');
  const [addressSearching, setAddressSearching] = useState(false);
  const insets = useSafeAreaInsets();
  const { user } = useAuth();
  const [currentStep, setCurrentStep] = useState<BookingStep>('location');
  const [selectedLocation, setSelectedLocation] = useState<{ latitude: number; longitude: number; address: string } | null>(null);
  const [selectedService, setSelectedService] = useState<string | null>(null);
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null);
  const [washType, setWashType] = useState<'exterior' | 'interior' | null>(null);
  const [serviceMode] = useState<ServiceMode>(
    (params.serviceMode === 'detailing' ? 'detailing' : 'wash') as ServiceMode
  );
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>([]);
  const [showAddOnsModal, setShowAddOnsModal] = useState(false);
  const [showBronzeWashTypeOverlay, setShowBronzeWashTypeOverlay] = useState(false);
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState(true);
  const { coords: liveCoords } = useLiveLocation();
  const [region, setRegion] = useState<Region | null>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [mapLocation, setMapLocation] = useState<{ latitude: number; longitude: number } | null>(null);

  const fadeAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(50)).current;
  const stepSlideAnim = useRef(new Animated.Value(0)).current;
  const markerPulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    Animated.loop(
      Animated.sequence([
        Animated.timing(markerPulse, { toValue: 1.2, duration: 1000, useNativeDriver: true }),
        Animated.timing(markerPulse, { toValue: 1, duration: 1000, useNativeDriver: true }),
      ])
    ).start();
  }, []);

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fadeAnim, {
        toValue: 1,
        duration: 600,
        useNativeDriver: true,
      }),
      Animated.spring(slideAnim, {
        toValue: 0,
        tension: 50,
        friction: 8,
        useNativeDriver: true,
      }),
    ]).start();
  }, []);

  useEffect(() => {
    loadVehicles();
  }, [user?.id]);

  useEffect(() => {
    stepSlideAnim.setValue(24);
    Animated.timing(stepSlideAnim, {
      toValue: 0,
      duration: 320,
      useNativeDriver: true,
    }).start();
  }, [currentStep]);

  // Get user location from live location and load nearby valeters (no placeholder map)
  useEffect(() => {
    const applyCoords = async (coords: { latitude: number; longitude: number }) => {
      setUserLocation(coords);
      setMapLocation(coords);
      setRegion({
        latitude: coords.latitude,
        longitude: coords.longitude,
        latitudeDelta: 0.002,
        longitudeDelta: 0.002,
      });
      try {
        const [result] = await Location.reverseGeocodeAsync(coords);
        if (result) {
          const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current Location';
          setSelectedLocation({ ...coords, address: addr });
        }
      } catch (e) {
        console.warn('Reverse geocode error:', e);
      }
    };

    if (liveCoords) {
      const coords = { latitude: liveCoords.latitude, longitude: liveCoords.longitude };
      applyCoords(coords);
    } else {
      (async () => {
        try {
          const { status } = await Location.requestForegroundPermissionsAsync();
          if (status !== 'granted') return;
          const location = await Location.getCurrentPositionAsync({ accuracy: Location.Accuracy.Balanced });
          const coords = { latitude: location.coords.latitude, longitude: location.coords.longitude };
          await applyCoords(coords);
        } catch (error) {
          console.warn('Error getting location:', error);
        }
      })();
    }
  }, [liveCoords]);

  const handleMapPress = async (event: MapPressEvent) => {
    const coords = event.nativeEvent.coordinate;
    setMapLocation(coords);
    setRegion({
      latitude: coords.latitude,
      longitude: coords.longitude,
      latitudeDelta: 0.002,
      longitudeDelta: 0.002,
    });

    try {
      const [result] = await Location.reverseGeocodeAsync(coords);
      if (result) {
        const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Selected Location';
        setSelectedLocation({ ...coords, address: addr });
        await hapticFeedback('light');
      }
    } catch (e) {
      console.warn('Reverse geocode error:', e);
    }
  };

  const handleUseCurrentLocation = async () => {
    await hapticFeedback('medium');
    if (userLocation) {
      setMapLocation(userLocation);
      setRegion({
        latitude: userLocation.latitude,
        longitude: userLocation.longitude,
        latitudeDelta: 0.002,
        longitudeDelta: 0.002,
      });
      try {
        const [result] = await Location.reverseGeocodeAsync(userLocation);
        if (result) {
          const addr = `${result.street || ''} ${result.city || ''} ${result.postalCode || ''}`.trim() || 'Current Location';
          setSelectedLocation({ ...userLocation, address: addr });
        }
      } catch (e) {
        console.warn('Reverse geocode error:', e);
      }
    }
  };

  const openVehicleInfo = async (vehicle: Vehicle) => {
    hapticFeedback('light');
    setInfoVehicle(vehicle);
    setVehicleWashCount(0);
    try {
      const res = await supabase
        .from('bookings')
        .select('id', { count: 'exact', head: true })
        .eq('vehicle_id', vehicle.id)
        .eq('status', 'completed');
      setVehicleWashCount((res as { count?: number }).count ?? 0);
    } catch {
      setVehicleWashCount(0);
    }
  };

  const handleAddressSearch = async () => {
    const q = addressSearchInput.trim();
    if (!q) return;
    setAddressSearching(true);
    try {
      const results = await Location.geocodeAsync(q);
      if (results?.length && results.length > 0) {
        const { latitude, longitude } = results[0];
        const coords = { latitude, longitude };
        setMapLocation(coords);
        setRegion({ ...coords, latitudeDelta: 0.002, longitudeDelta: 0.002 });
        const [rev] = await Location.reverseGeocodeAsync(coords);
        const addr = rev
          ? `${rev.street || ''} ${rev.city || ''} ${rev.postalCode || ''}`.trim() || q
          : q;
        setSelectedLocation({ ...coords, address: addr });
        setShowAddressOverlay(false);
        setAddressSearchInput('');
        await hapticFeedback('medium');
      } else {
        Alert.alert('Address not found', 'Try a different address or more specific search.');
      }
    } catch (e) {
      Alert.alert('Search failed', (e as Error)?.message || 'Could not find that address.');
    } finally {
      setAddressSearching(false);
    }
  };

  const loadVehicles = async () => {
    if (!user?.id) return;
    try {
      const { data, error } = await supabase
        .from('customer_vehicles')
        .select('*')
        .eq('user_id', user.id)
        .order('is_default', { ascending: false });

      if (error) throw error;
      const rows = (data || []).map((r: any) => ({ ...r, image_url: r.image_url ?? r.photo ?? null }));
      setVehicles(rows);
      if (rows.length > 0) {
        const defaultVehicle = rows.find((v: Vehicle) => v.is_default) || rows[0];
        setSelectedVehicle(defaultVehicle.id);
      }
    } catch (error) {
      console.error('Error loading vehicles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLocationContinue = async () => {
    if (!selectedLocation) {
      Alert.alert('Location Required', 'Please select a location on the map or use your current location.');
      return;
    }
    await hapticFeedback('medium');
    setCurrentStep('vehicle');
  };

  const handleVehicleContinue = async () => {
    if (!selectedVehicle) {
      Alert.alert('Vehicle Required', 'Please select a vehicle.');
      return;
    }
    await hapticFeedback('medium');
    setCurrentStep('service');
  };

  const handleServiceSelect = async (serviceId: string) => {
    await hapticFeedback('light');
    setSelectedService(serviceId);
    if (serviceId === 'bronze-wash') {
      setShowBronzeWashTypeOverlay(true);
    } else {
      setWashType(null);
    }
  };

  const handleWashTypeSelect = async (type: 'exterior' | 'interior') => {
    await hapticFeedback('light');
    setWashType(type);
    setShowBronzeWashTypeOverlay(false);
  };

  const handleServiceContinue = async () => {
    if (!selectedService || !selectedVehicle || !selectedLocation) {
      return;
    }
    if (serviceMode === 'wash' && selectedService === 'bronze-wash' && !washType) {
      return;
    }
    await hapticFeedback('medium');
    const baseForDiscount = basePrice ?? selectedServiceData?.price ?? 0;
    const discountAmount = (offersWater || offersElectricity) ? baseForDiscount * 0.25 : 0;

    router.push({
      pathname: '/owner/booking/valeter-selection',
      params: {
        serviceId: selectedService,
        vehicleId: selectedVehicle,
        latitude: selectedLocation.latitude.toString(),
        longitude: selectedLocation.longitude.toString(),
        address: selectedLocation.address,
        washType: washType || '',
        serviceMode: serviceMode,
        addOnIds: selectedAddOns.length ? selectedAddOns.join(',') : '',
        addOnsTotal: addOnsTotal.toString(),
        customerOffersWater: offersWater.toString(),
        customerOffersElectricity: offersElectricity.toString(),
        discountAmount: discountAmount.toString(),
      },
    });
  };

  const currentServiceOptions = serviceMode === 'wash' ? serviceOptions : detailingServiceOptions;
  const selectedServiceData = currentServiceOptions.find(s => s.id === selectedService);
  const selectedVehicleData = vehicles.find(v => v.id === selectedVehicle);

  const addOnsTotal = selectedAddOns.reduce((sum, id) => {
    const addOn = addOnOptions.find(a => a.id === id);
    return sum + (addOn?.price ?? 0);
  }, 0);

  const basePrice = (() => {
    if (!selectedServiceData || !selectedVehicleData) return null;
    const washId = mapServiceIdToWashId(selectedService);
    if (washId) {
      const vehicleSize = getVehicleSize(selectedVehicleData);
      const input: FrontendPricingInput = {
        washId,
        vehicleSize,
        isMobile: true,
        isPhysicalLocation: false,
        scheduledDateTime: new Date(),
      };
      const breakdown = calculateDisplayPrice(input);
      return breakdown?.total ?? selectedServiceData.price;
    }
    return selectedServiceData.price;
  })();

  const totalWithAddOns = basePrice == null ? null : basePrice + addOnsTotal;

  const toggleAddOn = (id: string) => {
    hapticFeedback('light');
    setSelectedAddOns((prev) => {
      if (prev.includes(id)) return prev.filter((x) => x !== id);
      return [...prev, id];
    });
  };

  const headerConfig = getBookingHeaderConfig(currentStep);
  const headerTitle = headerConfig.title;
  const headerSubtitle = headerConfig.subtitle;
  const headerOnBack = headerConfig.backStep === null ? undefined : () => setCurrentStep(headerConfig.backStep!);

  const renderVehicleStepContent = () => {
    if (loading) {
      return (
        <View style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
          <UnifiedBookingCard stripColor={SKY}>
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color={SKY} />
              <Text style={styles.loadingText}>Loading vehicles…</Text>
            </View>
          </UnifiedBookingCard>
        </View>
      );
    }
    if (vehicles.length === 0) {
      return (
        <View style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
          <UnifiedBookingCard stripColor={SKY}>
            <LinearGradient colors={[SKY + '12', 'transparent']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
            <View style={styles.modernCard}>
              <View style={styles.emptyContent}>
                <View style={[styles.iconWrap, { backgroundColor: SKY + '20', borderColor: SKY + '40' }]}>
                  <Ionicons name="car-outline" size={28} color={SKY} />
                </View>
                <Text style={styles.emptyText}>No vehicles found</Text>
                <Text style={styles.emptySubtext}>Add a vehicle to continue</Text>
                <TouchableOpacity onPress={() => router.push('/owner/settings/vehicle-management')} style={styles.addButton} activeOpacity={0.85}>
                  <LinearGradient colors={[SKY, '#60A5FA']} style={styles.addButtonGradient}>
                    <Ionicons name="add-circle" size={20} color="#FFFFFF" />
                    <Text style={styles.addButtonText}>Add Vehicle</Text>
                  </LinearGradient>
                </TouchableOpacity>
              </View>
            </View>
          </UnifiedBookingCard>
        </View>
      );
    }
    return (
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.cardsScrollContent}
        snapToInterval={BOOKING_CARD.SNAP_INTERVAL}
        decelerationRate="fast"
        snapToAlignment="start"
      >
        {vehicles.map((vehicle) => {
          const isSelected = selectedVehicle === vehicle.id;
          const vehicleBorderColor = getVehicleBorderColor(vehicle.color, SKY);
          return (
            <View key={vehicle.id} style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
              <UnifiedBookingCard
                stripColor={vehicleBorderColor}
                onPress={() => { hapticFeedback('light'); setSelectedVehicle(vehicle.id); }}
              >
              <View style={StyleSheet.absoluteFill} pointerEvents="none">
              {isSelected && (
                <LinearGradient colors={[SKY + '08', SKY + '04', 'transparent']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
              )}
              </View>
              <View style={[styles.vehicleCard, isSelected && styles.vehicleCardSelected]}>
                <View style={styles.vehicleCardInfoIcon}>
                  <InfoIconButton
                    onPress={() => { hapticFeedback('light'); openVehicleInfo(vehicle); }}
                    accentColor={SKY}
                  />
                </View>
                <View style={styles.vehicleCardTop}>
                  <View style={[styles.vehicleCardCarIcon, { backgroundColor: (isSelected ? SKY : '#94A3B8') + '18', borderColor: (isSelected ? SKY : '#94A3B8') + '30' }]}>
                    <Ionicons name="car-sport" size={28} color={isSelected ? SKY : '#94A3B8'} />
                  </View>
                  <View style={styles.vehicleCardContent}>
                    <Text style={styles.vehicleCardTitle} numberOfLines={1}>{vehicle.make} {vehicle.model}</Text>
                    <Text style={styles.vehicleCardSubtitle} numberOfLines={1}>{vehicle.color}</Text>
                    <View style={styles.vehicleCardMetaRow}>
                      <View style={[styles.quickHint, { backgroundColor: (isSelected ? SKY : '#94A3B8') + '18' }]}>
                        <Ionicons name="card-outline" size={12} color={isSelected ? SKY : '#94A3B8'} />
                        <Text style={[styles.quickHintText, { color: isSelected ? SKY : '#94A3B8' }]} numberOfLines={1}>{vehicle.registration}</Text>
                      </View>
                      {(vehicle as any).size && (
                        <View style={[styles.quickHint, { backgroundColor: (isSelected ? SKY : '#94A3B8') + '18' }]}>
                          <Text style={[styles.quickHintText, { color: isSelected ? SKY : '#94A3B8' }]}>{formatVehicleSize((vehicle as any).size)}</Text>
                        </View>
                      )}
                    </View>
                    {vehicle.is_default && (
                      <View style={styles.vehicleCardMetaRow}>
                        <View style={styles.vehicleCardDefaultBadge}>
                          <Ionicons name="star" size={11} color="#FBBF24" />
                          <Text style={styles.vehicleCardDefaultText}>Default vehicle</Text>
                        </View>
                      </View>
                    )}
                    {(vehicle as any).size === 'medium' && (
                      <Text style={styles.vehicleSizeHint}>Medium – no size surcharge</Text>
                    )}
                  </View>
                  {(vehicle.image_url ?? vehicle.photo) ? (
                    <View style={styles.vehicleCardPhotoBox}>
                      <Image source={{ uri: vehicle.image_url ?? vehicle.photo ?? '' }} style={styles.vehicleCardPhotoSmall} resizeMode="cover" />
                    </View>
                  ) : null}
                </View>
              </View>
              </UnifiedBookingCard>
            </View>
          );
        })}
      </ScrollView>
    );
  };

  return (
    <SafeAreaView style={styles.container} edges={[]}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />
      {/* Fullscreen map – real map with default region until location loads */}
      <View style={StyleSheet.absoluteFill}>
        <MapView
          style={StyleSheet.absoluteFill}
          region={region ?? DEFAULT_MAP_REGION}
          onPress={currentStep === 'location' ? handleMapPress : undefined}
          showsUserLocation
          showsMyLocationButton={false}
          toolbarEnabled={false}
          customMapStyle={BOOKING_MAP_STYLE}
        >
          {userLocation && (
            <Marker coordinate={userLocation}>
              <View style={styles.userMarkerContainer}>
                <Image
                  source={require('../../../assets/car.png')}
                  style={styles.userMarker}
                  resizeMode="contain"
                />
              </View>
            </Marker>
          )}
          {mapLocation && currentStep === 'location' && (
            <Marker coordinate={mapLocation}>
              <Animated.View style={[styles.selectedLocationMarker, { transform: [{ scale: markerPulse }] }]}>
                <View style={styles.selectedLocationMarkerInner}>
                  <Ionicons name="location" size={20} color="#FFFFFF" />
                </View>
              </Animated.View>
            </Marker>
          )}
        </MapView>
      </View>

      <TouchableOpacity
        onPress={() => {
          hapticFeedback('light');
          if (currentStep === 'location') {
            handleUseCurrentLocation();
          } else if (userLocation) {
            setRegion({ ...userLocation, latitudeDelta: 0.002, longitudeDelta: 0.002 });
          }
        }}
        style={[styles.recenterButtonFloating, { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + RECENTER_BUTTON_TOP_BELOW_ACTIONS, right: RECENTER_BUTTON_RIGHT }]}
        activeOpacity={0.7}
      >
        <Ionicons name="locate" size={22} color={SKY} />
      </TouchableOpacity>

      <AppHeader
        title={headerTitle}
        subtitle={headerSubtitle}
        showBack={currentStep !== 'location'}
        onBack={headerOnBack}
        rightAction={
          <View style={{ flexDirection: 'row', gap: 8, alignItems: 'center' }}>
            <TouchableOpacity
              onPress={() => { hapticFeedback('light'); router.push('/owner/wash-vs-detail-info'); }}
              style={styles.headerLocateButton}
              activeOpacity={0.7}
            >
              <Ionicons name="information-circle" size={22} color={SKY} />
            </TouchableOpacity>
            <TouchableOpacity
              onPress={async () => {
                await hapticFeedback('light');
                router.replace('/owner/owner-dashboard' as any);
              }}
              style={styles.exitButton}
              activeOpacity={0.7}
            >
              <Ionicons name="close" size={22} color="#FFFFFF" />
            </TouchableOpacity>
          </View>
        }
      />

      {/* Resources toggle – icon highlights when selected, no full fill */}
      {currentStep === 'service' && (
        <View
          style={[
            styles.resourcesToggleFixed,
            { top: (insets?.top ?? 0) + HEADER_CONTENT_OFFSET + 12 },
          ]}
          pointerEvents="box-none"
        >
          <View style={styles.serviceModeToggle}>
            <TouchableOpacity
              onPress={() => { hapticFeedback('light'); setOffersWater((v) => !v); }}
              activeOpacity={0.8}
              style={styles.serviceModePill}
            >
              <Ionicons name="water-outline" size={18} color={offersWater ? SKY : 'rgba(135,206,235,0.5)'} />
              <Text style={[styles.serviceModeLabel, offersWater && styles.serviceModeLabelHighlight]}>Water</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => { hapticFeedback('light'); setOffersElectricity((v) => !v); }}
              activeOpacity={0.8}
              style={styles.serviceModePill}
            >
              <Ionicons name="flash-outline" size={18} color={offersElectricity ? DETAILING_YELLOW : 'rgba(135,206,235,0.5)'} />
              <Text style={[styles.serviceModeLabel, offersElectricity && styles.serviceModeLabelHighlightYellow]}>Electricity</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}

      {/* Floating cards container - matches Book Your Wash */}
      <Animated.View
        style={[
          styles.cardsContainer,
          {
            opacity: fadeAnim,
            transform: [{ translateY: slideAnim }],
            paddingBottom: Math.max(insets.bottom, 14) + 14 + TAB_BAR_TOTAL_HEIGHT + 12,
          },
        ]}
      >
        <Animated.View style={{ transform: [{ translateX: stepSlideAnim }] }}>
        {/* Step 1: Location Selection */}
        {currentStep === 'location' && (
          <View style={[styles.cardWrapper, { width: CARD_WIDTH }]}>
            <UnifiedBookingCard stripColor={LOCATION_CARD_GREEN}>
            {selectedLocation && (
              <LinearGradient
                colors={[SKY + '15', SKY + '08', 'transparent']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
                style={StyleSheet.absoluteFill}
                pointerEvents="none"
              />
            )}
            <View style={[styles.modernCard, selectedLocation == null ? styles.modernCardEmpty : undefined]}>
              {selectedLocation == null ? (
                <View style={styles.emptyContent}>
                  <View style={[styles.iconWrap, { backgroundColor: SKY + '20', borderColor: SKY + '40' }]}>
                    <Ionicons name="location-outline" size={28} color={SKY} />
                  </View>
                  <Text style={styles.emptyText}>Tap on the map</Text>
                  <Text style={styles.emptySubtext}>Tap to set where your washer will arrive</Text>
                </View>
              ) : (
                <View style={styles.cardTop}>
                  <View style={[styles.iconWrap, { backgroundColor: SKY + '25', borderColor: SKY + '40' }]}>
                    <LinearGradient colors={CARD_GRADIENT} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={styles.iconGradient}>
                      <Ionicons name="location" size={26} color="#FFFFFF" />
                    </LinearGradient>
                  </View>
                  <View style={styles.cardContent}>
                    <View style={styles.titleRow}>
                      <Text style={styles.cardTitle} numberOfLines={1}>Location</Text>
                      <View style={styles.titleRowRight}>
                        <TouchableOpacity
                          onPress={() => { hapticFeedback('light'); setAddressSearchInput(selectedLocation?.address ?? ''); setShowAddressOverlay(true); }}
                          style={styles.changeBtn}
                          activeOpacity={0.8}
                        >
                          <Ionicons name="pencil" size={14} color={SKY} />
                          <Text style={styles.changeBtnText}>Change</Text>
                        </TouchableOpacity>
                      </View>
                    </View>
                    <Text style={styles.cardSubtitle} numberOfLines={2}>{selectedLocation.address}</Text>
                    <Text style={styles.locationMicrocopy}>Your washer will arrive here</Text>
                  </View>
                </View>
              )}
            </View>
            </UnifiedBookingCard>
          </View>
        )}

        {/* Step 2: Vehicle Selection */}
        {currentStep === 'vehicle' && renderVehicleStepContent()}

        {/* Step 3: Service Selection */}
        {currentStep === 'service' && (
          <View style={styles.serviceStepWrap}>
            <ScrollView
              horizontal
              showsHorizontalScrollIndicator={false}
              contentContainerStyle={styles.cardsScrollContent}
              snapToInterval={BOOKING_CARD.SNAP_INTERVAL}
              decelerationRate="fast"
              snapToAlignment="start"
            >
              {currentServiceOptions.map((service) => {
                const isSelected = selectedService === service.id;
                const serviceColor = service.colors[0];
                const serviceStripColor = getServiceStripColor(service.id, serviceColor);

                return (
                  <View key={service.id} style={[styles.cardWrapper, styles.serviceCardCurved, { width: CARD_WIDTH }]}>
                    <UnifiedBookingCard
                      stripColor={serviceStripColor}
                      onPress={() => handleServiceSelect(service.id)}
                      style={styles.serviceCardUnified}
                    >
                    {isSelected && (
                      <LinearGradient colors={[serviceColor + '15', serviceColor + '08', 'transparent']} start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }} style={StyleSheet.absoluteFill} pointerEvents="none" />
                    )}
                    <View style={[styles.modernCard, isSelected && styles.modernCardSelected]}>
                      <View style={styles.cardTop}>
                        <View style={[styles.iconWrap, { backgroundColor: serviceColor + '25', borderColor: serviceColor + '40' }]}>
                          <Ionicons name={service.icon as any} size={26} color={serviceColor} />
                        </View>
                        <View style={styles.cardContent}>
                          <View style={styles.titleRow}>
                            <Text style={styles.cardTitle} numberOfLines={1}>{service.name}</Text>
                            <InfoIconButton
                              onPress={() => { hapticFeedback('light'); setInfoService(service); }}
                              accentColor={serviceColor}
                            />
                          </View>
                          <Text style={styles.cardSubtitle}>{service.dur}</Text>
                          {isSelected && (service.id === 'platinum-wash' || service.id === 'eco-platinum-wash') && (
                            <Text style={styles.serviceReinforcement}>Deep clean — no paint correction</Text>
                          )}
                          {isSelected && serviceMode === 'detailing' && service.id === 'exterior-detail' && (
                            <Text style={styles.serviceReinforcement}>Includes light polishing, not full correction</Text>
                          )}
                          {isSelected && serviceMode === 'detailing' && service.id === 'paint-correction' && (
                            <Text style={styles.serviceReinforcement}>Inspection required – results vary by condition</Text>
                          )}
                          {/* Light price hint – full breakdown on payment screen */}
                          <View style={styles.cardMetaRow}>
                            <View style={[styles.quickHint, { backgroundColor: serviceColor + '15' }]}>
                              <Text style={[styles.quickHintText, { color: serviceColor }]}>
                                {isSelected && totalWithAddOns != null
                                  ? `£${totalWithAddOns.toFixed(2)} total`
                                  : `From £${service.price}`}
                              </Text>
                            </View>
                          </View>
                        </View>
                      </View>

                      {/* Add-ons row – always visible so users can tap to open modal */}
                      <View style={styles.addOnsRow}>
                        <TouchableOpacity
                          onPress={(e) => { e.stopPropagation(); hapticFeedback('light'); setShowAddOnsModal(true); }}
                          style={styles.addOnsButton}
                          activeOpacity={0.8}
                        >
                          <View style={styles.addOnsButtonIconWrap}>
                            <Ionicons name="add-circle-outline" size={22} color={SKY} />
                          </View>
                          <View>
                            <Text style={styles.addOnsButtonText}>Optional add-ons</Text>
                            <Text style={styles.addOnsButtonHint}>
                              {selectedAddOns.length > 0
                                ? `${selectedAddOns.length} selected · +£${addOnsTotal.toFixed(2)}`
                                : 'Pet hair, stains, odour & more'}
                            </Text>
                          </View>
                          {selectedAddOns.length > 0 && (
                            <View style={styles.addOnsBadge}>
                              <Text style={styles.addOnsBadgeText}>{selectedAddOns.length}</Text>
                            </View>
                          )}
                          <Ionicons name="chevron-forward" size={18} color={SKY} />
                        </TouchableOpacity>
                      </View>

                    </View>
                    </UnifiedBookingCard>
                  </View>
                );
              })}
            </ScrollView>
          </View>
        )}
        </Animated.View>

        {/* Floating Continue button */}
        <View style={[styles.ctaWrapper, { paddingBottom: insets.bottom + 12 }]}>
          {currentStep === 'location' && (
            <TouchableOpacity
              onPress={handleLocationContinue}
              disabled={!selectedLocation}
              style={styles.ctaButton}
              activeOpacity={0.9}
            >
              <LinearGradient
                colors={selectedLocation ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.ctaGradient}
              >
                <Text style={styles.ctaText}>{selectedLocation ? 'Confirm location' : 'Tap map to set location'}</Text>
                <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
              </LinearGradient>
            </TouchableOpacity>
          )}
          {currentStep === 'vehicle' && (
            <TouchableOpacity
              onPress={handleVehicleContinue}
              disabled={!selectedVehicle}
              style={styles.ctaButton}
              activeOpacity={0.9}
            >
              <LinearGradient
                colors={selectedVehicle ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={styles.ctaGradient}
              >
                <Text style={styles.ctaText}>{selectedVehicle ? 'Confirm & continue' : 'Confirm vehicle'}</Text>
                <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
              </LinearGradient>
            </TouchableOpacity>
          )}
          {currentStep === 'service' && (
            <>
              {serviceMode === 'detailing' && selectedService ? (
                <Text style={styles.conditionMicrocopy}>
                  Detailing is condition-based. Results vary by vehicle condition.
                </Text>
              ) : null}
              <TouchableOpacity
                onPress={handleServiceContinue}
                disabled={!selectedVehicle || (serviceMode === 'wash' && selectedService === 'bronze-wash' && !washType)}
                style={styles.ctaButton}
                activeOpacity={0.9}
              >
                <LinearGradient
                  colors={selectedVehicle && (serviceMode !== 'wash' || selectedService !== 'bronze-wash' || washType) ? [SKY, '#0EA5E9'] : ['#475569', '#334155']}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 0 }}
                  style={styles.ctaGradient}
                >
                  <Text style={styles.ctaText}>
                    {selectedVehicle && (serviceMode !== 'wash' || selectedService !== 'bronze-wash' || washType) ? 'Confirm & continue' : 'Confirm service'}
                  </Text>
                  <Ionicons name="arrow-forward" size={20} color="#FFFFFF" />
                </LinearGradient>
              </TouchableOpacity>
            </>
          )}
        </View>

        {/* Service Info Modal - recreated overlay */}
        <Modal
          visible={!!infoService}
          transparent
          animationType="fade"
          statusBarTranslucent
          onRequestClose={() => setInfoService(null)}
        >
          <View style={styles.serviceInfoModalOverlay}>
            <Pressable style={StyleSheet.absoluteFill} onPress={() => setInfoService(null)} />
            <Pressable style={styles.serviceInfoModalContent} onPress={(e) => e.stopPropagation()}>
              <View style={[styles.serviceInfoModalCard, { borderColor: customerTheme.primary + '35' }]}>
                <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} />
                <View style={styles.modalHeaderHubStyle}>
                  <Text style={styles.modalTitleHubStyle}>Service info</Text>
                  <TouchableOpacity onPress={() => setInfoService(null)} style={styles.modalCloseBtn} hitSlop={12}>
                    <Ionicons name="close" size={24} color={customerTheme.primary} />
                  </TouchableOpacity>
                </View>
                <ScrollView showsVerticalScrollIndicator={false} style={styles.modalScrollContent}>
                  {infoService && (
                    <>
                      <View style={[styles.modalIconWrapper, { backgroundColor: customerTheme.primary + '22' }]}>
                        <Ionicons name={(infoService.icon ?? 'information-circle') as keyof typeof Ionicons.glyphMap} size={28} color={customerTheme.primary} />
                      </View>
                      <View style={styles.modalTitleContainer}>
                        <Text style={styles.modalTitle}>{infoService.name}</Text>
                        <Text style={styles.modalPrice}>£{infoService.price}</Text>
                      </View>
                      <Text style={styles.modalDescription}>{infoService.desc}</Text>
                      {(infoService.bulletPoints?.length ?? 0) > 0 && (
                        <View style={styles.bulletPointsContainer}>
                          {infoService.bulletPoints.map((point: string) => (
                            <View key={point} style={styles.bulletPoint}>
                              <Ionicons name="checkmark-circle" size={18} color={customerTheme.primary} />
                              <Text style={styles.bulletPointText}>{point}</Text>
                            </View>
                          ))}
                        </View>
                      )}
                      {selectedAddOns.length > 0 && (
                        <View style={styles.modalAddOnsSection}>
                          <Text style={styles.modalAddOnsTitle}>Selected add-ons</Text>
                          {selectedAddOns.map((id) => {
                            const addOn = addOnOptions.find(a => a.id === id);
                            if (!addOn) return null;
                            return (
                              <View key={addOn.id} style={styles.modalAddOnRow}>
                                <Ionicons name={addOn.icon as any} size={18} color={customerTheme.primary} />
                                <Text style={styles.modalAddOnName}>{addOn.name}</Text>
                                <Text style={styles.modalAddOnPrice}>+£{addOn.price}</Text>
                              </View>
                            );
                          })}
                          <View style={styles.modalAddOnTotal}>
                            <Text style={styles.modalAddOnTotalLabel}>Add-ons total</Text>
                            <Text style={styles.modalAddOnTotalValue}>+£{addOnsTotal}</Text>
                          </View>
                        </View>
                      )}
                    </>
                  )}
                </ScrollView>
              </View>
            </Pressable>
          </View>
        </Modal>

        {/* Vehicle Info Modal */}
        <Modal visible={!!infoVehicle} transparent animationType="fade" onRequestClose={() => setInfoVehicle(null)}>
          <Pressable style={styles.modalOverlay} onPress={() => setInfoVehicle(null)}>
            <Pressable style={styles.vehicleInfoModalContent} onPress={(e) => e.stopPropagation()}>
              <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} />
              {infoVehicle && (
                <>
                  <View style={styles.vehicleInfoModalHeader}>
                    {(infoVehicle.image_url ?? infoVehicle.photo) ? (
                      <Image source={{ uri: infoVehicle.image_url ?? infoVehicle.photo ?? '' }} style={styles.vehicleInfoModalPhoto} resizeMode="cover" />
                    ) : (
                      <View style={styles.vehicleInfoModalPhotoPlaceholder}>
                        <Ionicons name="car-sport-outline" size={48} color={SKY} style={{ opacity: 0.5 }} />
                      </View>
                    )}
                    <View style={styles.vehicleInfoModalTitleRow}>
                      <Text style={styles.vehicleInfoModalTitle}>{infoVehicle.make} {infoVehicle.model}</Text>
                      <TouchableOpacity onPress={() => setInfoVehicle(null)} hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}>
                        <Ionicons name="close" size={24} color={customerTheme.primary} />
                      </TouchableOpacity>
                    </View>
                  </View>
                  <View style={styles.vehicleInfoModalBody}>
                    <View style={styles.vehicleInfoModalRow}>
                      <Ionicons name="car-sport-outline" size={18} color={customerTheme.primary} />
                      <Text style={styles.vehicleInfoModalText}>{infoVehicle.color} • {infoVehicle.registration}</Text>
                    </View>
                    {infoVehicle.type && (
                      <View style={styles.vehicleInfoModalRow}>
                        <Ionicons name="shapes-outline" size={18} color={customerTheme.primary} />
                        <Text style={styles.vehicleInfoModalText}>{infoVehicle.type}</Text>
                      </View>
                    )}
                    {infoVehicle.size && (
                      <View style={styles.vehicleInfoModalRow}>
                        <Ionicons name="resize-outline" size={18} color={customerTheme.primary} />
                        <Text style={styles.vehicleInfoModalText}>{formatVehicleSize(infoVehicle.size)} vehicle</Text>
                      </View>
                    )}
                    <View style={styles.vehicleInfoModalRow}>
                      <Ionicons name="checkmark-done" size={18} color={colors.ecoGreen} />
                      <Text style={styles.vehicleInfoModalText}>{vehicleWashCount} washes completed</Text>
                    </View>
                  </View>
                  <TouchableOpacity onPress={() => setInfoVehicle(null)} style={styles.vehicleInfoModalDone} activeOpacity={0.9}>
                    <Text style={styles.vehicleInfoModalDoneText}>Close</Text>
                  </TouchableOpacity>
                </>
              )}
            </Pressable>
          </Pressable>
        </Modal>

        {/* Address search overlay */}
        <Modal visible={showAddressOverlay} transparent animationType="fade" onRequestClose={() => setShowAddressOverlay(false)}>
          <Pressable style={styles.modalOverlay} onPress={() => setShowAddressOverlay(false)}>
            <View style={styles.addressOverlayContent}>
              <BlurView intensity={28} tint="dark" style={StyleSheet.absoluteFill} />
              <Pressable style={styles.addressOverlayContentInner} onPress={(e) => e.stopPropagation()}>
              <Text style={styles.addressOverlayTitle}>Change location</Text>
              <Text style={styles.addressOverlaySubtitle}>Search for an address to find it on the map</Text>
              <TextInput
                style={styles.addressOverlayInput}
                placeholder="Enter address..."
                placeholderTextColor="#64748B"
                value={addressSearchInput}
                onChangeText={setAddressSearchInput}
                onSubmitEditing={handleAddressSearch}
                returnKeyType="search"
                autoCapitalize="none"
              />
              <View style={styles.addressOverlayButtons}>
                <TouchableOpacity style={styles.addressOverlayCancel} onPress={() => setShowAddressOverlay(false)} activeOpacity={0.8}>
                  <Text style={styles.addressOverlayCancelText}>Cancel</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.addressOverlaySearch, addressSearching && { opacity: 0.7 }]}
                  onPress={handleAddressSearch}
                  disabled={addressSearching}
                  activeOpacity={0.8}
                >
                  {addressSearching ? (
                    <ActivityIndicator size="small" color="#fff" />
                  ) : (
                    <>
                      <Ionicons name="search" size={18} color="#fff" />
                      <Text style={styles.addressOverlaySearchText}>Search</Text>
                    </>
                  )}
                </TouchableOpacity>
              </View>
              </Pressable>
            </View>
          </Pressable>
        </Modal>

        {/* Add-ons modal – redesigned for reliable render and clearer UI */}
        <Modal visible={showAddOnsModal} transparent animationType="fade" statusBarTranslucent onRequestClose={() => setShowAddOnsModal(false)}>
          <Pressable style={styles.addOnsModalOverlay} onPress={() => setShowAddOnsModal(false)}>
            <Pressable style={styles.addOnsModalContent} onPress={(e) => e.stopPropagation()}>
              <BlurView intensity={36} tint="dark" style={StyleSheet.absoluteFill} />
              <LinearGradient colors={['rgba(15,23,42,0.98)', 'rgba(30,41,59,0.96)']} style={StyleSheet.absoluteFill} />
              <View style={styles.addOnsModalContentInner}>
                <View style={styles.addOnsModalHeader}>
                  <View style={styles.addOnsModalTitleRow}>
                    <View style={styles.addOnsModalTitleIcon}>
                      <Ionicons name="add-circle" size={24} color={SKY} />
                    </View>
                    <Text style={styles.addOnsModalTitle}>Optional add-ons</Text>
                  </View>
                  <TouchableOpacity onPress={() => setShowAddOnsModal(false)} style={styles.addOnsModalCloseBtn} hitSlop={12}>
                    <Ionicons name="close" size={24} color="#94A3B8" />
                  </TouchableOpacity>
                </View>
                <Text style={styles.addOnsModalSubtitle}>Extras added to your service. Tap to select.</Text>

                <ScrollView
                  style={styles.addOnsModalList}
                  contentContainerStyle={styles.addOnsModalListContent}
                  showsVerticalScrollIndicator={true}
                  bounces={true}
                >
                  {addOnOptions.map((addOn) => {
                    const isSelected = selectedAddOns.includes(addOn.id);
                    return (
                      <TouchableOpacity
                        key={addOn.id}
                        onPress={() => toggleAddOn(addOn.id)}
                        style={[styles.addOnsModalRow, isSelected && styles.addOnsModalRowSelected]}
                        activeOpacity={0.75}
                      >
                        <View style={[styles.addOnsModalRowIcon, isSelected && styles.addOnsModalRowIconSelected]}>
                          <Ionicons name={(addOn.icon ?? 'add') as keyof typeof Ionicons.glyphMap} size={22} color={isSelected ? SKY : '#94A3B8'} />
                        </View>
                        <View style={styles.addOnsModalRowBody}>
                          <Text style={styles.addOnsModalRowName}>{addOn.name}</Text>
                          <Text style={styles.addOnsModalRowDesc} numberOfLines={2}>{addOn.desc}</Text>
                          <Text style={[styles.addOnsModalRowPriceInline, isSelected && styles.addOnsModalRowPriceSelected]}>+£{addOn.price}</Text>
                        </View>
                        <View style={[styles.addOnsModalCheck, isSelected && styles.addOnsModalCheckSelected]}>
                          {isSelected ? <Ionicons name="checkmark" size={14} color="#FFFFFF" /> : null}
                        </View>
                      </TouchableOpacity>
                    );
                  })}
                </ScrollView>

                {selectedAddOns.length > 0 && (
                  <View style={styles.addOnsModalFooter}>
                    <Text style={styles.addOnsModalFooterLabel}>Add-ons total</Text>
                    <Text style={styles.addOnsModalFooterValue}>+£{addOnsTotal.toFixed(2)}</Text>
                  </View>
                )}
                <TouchableOpacity
                  onPress={() => { hapticFeedback('light'); setShowAddOnsModal(false); }}
                  style={styles.addOnsModalDone}
                  activeOpacity={0.85}
                >
                  <Text style={styles.addOnsModalDoneText}>Done</Text>
                </TouchableOpacity>
              </View>
            </Pressable>
          </Pressable>
        </Modal>

        {/* Bronze wash: Exterior / Interior pop overlay */}
        <Modal visible={showBronzeWashTypeOverlay} transparent animationType="fade" onRequestClose={() => setShowBronzeWashTypeOverlay(false)}>
          <Pressable style={styles.bronzeWashTypeOverlay} onPress={() => setShowBronzeWashTypeOverlay(false)}>
            <Pressable style={styles.bronzeWashTypeModalContent} onPress={(e) => e.stopPropagation()}>
              <View style={StyleSheet.absoluteFill}>
                <BlurView intensity={40} tint="dark" style={StyleSheet.absoluteFill} />
                <View style={[StyleSheet.absoluteFill, { backgroundColor: 'rgba(15,23,42,0.75)' }]} />
              </View>
              <View style={styles.bronzeWashTypeModalContentInner}>
              <View style={[styles.bronzeWashTypeModalAccent, { backgroundColor: getServiceStripColor('bronze-wash', SKY) }]} />
              <View style={styles.bronzeWashTypeModalHeader}>
                <View>
                  <Text style={styles.bronzeWashTypeModalTitle}>Bronze Wash</Text>
                  <Text style={styles.bronzeWashTypeModalSubtitle}>What do you want cleaned?</Text>
                </View>
                <TouchableOpacity onPress={() => setShowBronzeWashTypeOverlay(false)} style={styles.bronzeWashTypeModalClose} hitSlop={12}>
                  <Ionicons name="close" size={22} color="#94A3B8" />
                </TouchableOpacity>
              </View>
              <View style={styles.bronzeWashTypeModalOptions}>
                <TouchableOpacity onPress={() => handleWashTypeSelect('exterior')} style={[styles.bronzeWashTypeModalOption, { borderColor: getServiceStripColor('bronze-wash', SKY) + '40' }]} activeOpacity={0.85}>
                  <View style={[styles.bronzeWashTypeModalOptionIcon, { backgroundColor: getServiceStripColor('bronze-wash', SKY) + '20' }]}>
                    <Ionicons name="car-sport-outline" size={26} color={getServiceStripColor('bronze-wash', SKY)} />
                  </View>
                  <View style={styles.bronzeWashTypeModalOptionText}>
                    <Text style={styles.bronzeWashTypeModalOptionLabel}>Exterior</Text>
                    <Text style={styles.bronzeWashTypeModalOptionDesc}>Hand wash & wheels</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={18} color="#64748B" />
                </TouchableOpacity>
                <TouchableOpacity onPress={() => handleWashTypeSelect('interior')} style={[styles.bronzeWashTypeModalOption, { borderColor: getServiceStripColor('bronze-wash', SKY) + '40' }]} activeOpacity={0.85}>
                  <View style={[styles.bronzeWashTypeModalOptionIcon, { backgroundColor: getServiceStripColor('bronze-wash', SKY) + '20' }]}>
                    <Ionicons name="layers-outline" size={26} color={getServiceStripColor('bronze-wash', SKY)} />
                  </View>
                  <View style={styles.bronzeWashTypeModalOptionText}>
                    <Text style={styles.bronzeWashTypeModalOptionLabel}>Interior</Text>
                    <Text style={styles.bronzeWashTypeModalOptionDesc}>Vacuum & wipe-down</Text>
                  </View>
                  <Ionicons name="chevron-forward" size={18} color="#64748B" />
                </TouchableOpacity>
              </View>
            </View>
            </Pressable>
          </Pressable>
        </Modal>
      </Animated.View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: customerTheme.backgroundColor,
  },
  userMarkerContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  userMarker: {
    width: 48,
    height: 48,
  },
  selectedLocationMarker: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  selectedLocationMarkerInner: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: SKY,
    justifyContent: 'center',
    alignItems: 'center',
    elevation: 4,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.4,
    shadowRadius: 6,
  },
  recenterButton: {
    position: 'absolute',
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: SKY,
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 100,
  },
  recenterButtonFloating: {
    position: 'absolute',
    zIndex: 100,
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  currentLocationButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 8,
  },
  headerLocateButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(15, 23, 42, 0.85)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.4)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  exitButton: {
    width: 40,
    height: 40,
    borderRadius: 18,
    backgroundColor: 'rgba(0, 0, 0, 0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
    elevation: 8,
  },
  cardsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    paddingHorizontal: 16,
    paddingTop: 10,
  },
  ctaWrapper: {
    position: 'absolute',
    left: 16,
    right: 16,
    bottom: 0,
  },
  stepDots: {
    position: 'absolute',
    left: 16,
    flexDirection: 'row',
    gap: 8,
    zIndex: 100,
  },
  stepDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(148,163,184,0.4)',
  },
  stepDotDone: {
    backgroundColor: SKY,
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  stepDotActive: {
    backgroundColor: SKY,
    width: 12,
    height: 8,
    borderRadius: 4,
  },
  modernCard: {
    padding: 14,
    overflow: 'hidden',
  },
  modernCardEmpty: {
    alignItems: 'center',
  },
  modernCardSelected: {
    borderWidth: 0,
    borderColor: 'transparent',
    shadowColor: SKY,
    shadowOpacity: 0.08,
    shadowRadius: 4,
    elevation: 2,
  },
  cardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  iconWrap: {
    width: 44,
    height: 44,
    borderRadius: 12,
    marginRight: 10,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  iconGradient: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  cardContent: {
    flex: 1,
    minWidth: 0,
  },
  titleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 4,
  },
  cardTitle: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    flex: 1,
  },
  cardSubtitle: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
  },
  serviceReinforcement: {
    color: '#87CEEB',
    fontSize: 12,
    marginTop: 4,
    fontStyle: 'italic',
  },
  locationMicrocopy: {
    marginTop: 4,
    fontSize: 12,
    fontWeight: '600',
    color: SKY,
  },
  washTypeQuestion: {
    fontSize: 13,
    fontWeight: '600',
    marginBottom: 6,
  },
  badgeSmall: {
    paddingHorizontal: 6,
    paddingVertical: 4,
    borderRadius: 10,
    borderWidth: 1,
  },
  titleRowRight: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  changeBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: SKY + '15',
    borderWidth: 1,
    borderColor: SKY + '30',
  },
  changeBtnText: {
    color: SKY,
    fontSize: 12,
    fontWeight: '600',
  },
  cardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 8,
  },
  quickHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  quickHintText: {
    fontSize: 11,
    fontWeight: '600',
  },
  infoIconBtn: {
    padding: 6,
    borderRadius: 10,
  },
  ctaDivider: {
    height: 1,
    marginTop: 14,
    marginBottom: 12,
    borderRadius: 1,
  },
  conditionMicrocopy: {
    color: '#94A3B8',
    fontSize: 13,
    lineHeight: 18,
    marginBottom: 10,
    fontStyle: 'italic',
    textAlign: 'center',
  },
  ctaButton: {
    borderRadius: 18,
    overflow: 'hidden',
    elevation: 5,
    shadowColor: '#0EA5E9',
    shadowOffset: { width: 0, height: 3 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    borderWidth: 1,
    borderColor: 'rgba(59,130,246,0.4)',
  },
  ctaGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 18,
    paddingHorizontal: 20,
    gap: 10,
  },
  ctaText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '900',
    letterSpacing: 0.2,
  },
  cardsScrollContent: {
    paddingRight: 16,
  },
  cardWrapper: {
    marginRight: 12,
  },
  serviceCardCurved: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
  },
  serviceCardUnified: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    ...BOOKING_CARD.CURVED,
  },
  vehicleCardStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 5,
    borderTopLeftRadius: 16,
    borderBottomLeftRadius: 16,
    zIndex: 1,
  },
  locationCardStrip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: 5,
    borderTopLeftRadius: 16,
    borderBottomLeftRadius: 16,
    zIndex: 1,
  },
  emptyContent: {
    alignItems: 'center',
    paddingVertical: 24,
  },
  emptyText: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginTop: 14,
    marginBottom: 4,
  },
  emptySubtext: {
    color: '#94A3B8',
    fontSize: 13,
    textAlign: 'center',
    marginBottom: 16,
  },
  loadingContainer: {
    paddingVertical: 40,
    paddingHorizontal: 20,
    alignItems: 'center',
    gap: 16,
  },
  loadingText: {
    color: SKY,
    fontSize: 15,
    fontWeight: '700',
  },
  addButton: {
    borderRadius: 12,
    overflow: 'hidden',
    marginTop: 16,
    elevation: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 12,
  },
  addButtonGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 24,
    paddingVertical: 14,
    gap: 8,
  },
  addButtonText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  carPhotoBox: {
    width: 56,
    height: 56,
    borderRadius: 14,
    overflow: 'hidden',
    marginLeft: 10,
  },
  /* Vehicle cards – same size as hub cards, more info */
  vehicleCard: {
    padding: 20,
    overflow: 'hidden',
    position: 'relative',
  },
  vehicleCardSelected: {
    borderWidth: 0,
    borderColor: 'transparent',
    shadowColor: SKY,
    shadowOpacity: 0.12,
    shadowRadius: 8,
    elevation: 4,
  },
  vehicleCardInfoIcon: {
    position: 'absolute',
    top: 14,
    right: 14,
    zIndex: 1,
  },
  vehicleCardTop: {
    flexDirection: 'row',
    alignItems: 'flex-start',
  },
  vehicleCardCarIcon: {
    width: 52,
    height: 52,
    borderRadius: 18,
    marginRight: 14,
    borderWidth: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleCardContent: {
    flex: 1,
    minWidth: 0,
    paddingRight: 44,
  },
  vehicleCardTitle: {
    color: '#F9FAFB',
    fontSize: 18,
    fontWeight: '800',
    marginBottom: 4,
  },
  vehicleCardSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '500',
    marginBottom: 6,
  },
  vehicleCardMetaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    flexWrap: 'wrap',
    gap: 8,
    marginTop: 6,
  },
  vehicleCardDefaultBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    backgroundColor: 'rgba(16,185,129,0.12)',
  },
  vehicleCardDefaultText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#FBBF24',
  },
  vehicleSizeHint: {
    fontSize: 12,
    color: '#94A3B8',
    fontWeight: '500',
    marginTop: 4,
  },
  vehicleCardPhotoBox: {
    width: 56,
    height: 56,
    borderRadius: 14,
    overflow: 'hidden',
    marginLeft: 10,
  },
  vehicleCardPhotoSmall: {
    width: 56,
    height: 56,
  },
  vehicleCardPhotoPlaceholder: {
    width: 56,
    height: 56,
    backgroundColor: 'rgba(135,206,235,0.08)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleCardDivider: {
    height: 1,
    marginTop: 10,
    marginBottom: 8,
    borderRadius: 1,
    opacity: 0.6,
  },
  vehicleCardCta: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 10,
    borderWidth: 1.5,
    gap: 6,
  },
  vehicleCardCtaText: {
    fontSize: 14,
    fontWeight: '600',
  },
  carPhotoTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: 'rgba(0,0,0,0.2)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  carPhotoSmall: {
    width: 56,
    height: 56,
  },
  carPhotoPlaceholder: {
    width: 56,
    height: 56,
    backgroundColor: 'rgba(135,206,235,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
    justifyContent: 'center',
    alignItems: 'center',
  },
  washTypeRow: {
    flexDirection: 'row',
    gap: 8,
    marginTop: 12,
  },
  washTypePillClean: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.3)',
  },
  washTypePillTextClean: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  bronzeWashTypeOverlay: {
    flex: 1,
    backgroundColor: 'transparent',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  bronzeWashTypeModalContent: {
    width: '100%',
    maxWidth: 340,
    minHeight: 280,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 1,
    borderColor: 'rgba(205,127,50,0.4)',
    overflow: 'hidden',
    backgroundColor: 'rgba(30,41,59,0.95)',
  },
  bronzeWashTypeModalContentInner: {
    minHeight: 260,
  },
  bronzeWashTypeModalAccent: {
    height: 4,
    width: '100%',
  },
  bronzeWashTypeModalHeader: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingTop: 18,
    paddingBottom: 4,
  },
  bronzeWashTypeModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    letterSpacing: -0.3,
    marginBottom: 2,
  },
  bronzeWashTypeModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
  },
  bronzeWashTypeModalClose: {
    padding: 4,
  },
  bronzeWashTypeModalOptions: {
    padding: 16,
    paddingTop: 8,
    gap: 10,
  },
  bronzeWashTypeModalOption: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 14,
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 1.5,
    backgroundColor: 'rgba(255,255,255,0.03)',
  },
  bronzeWashTypeModalOptionIcon: {
    width: 48,
    height: 48,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    justifyContent: 'center',
    alignItems: 'center',
  },
  bronzeWashTypeModalOptionText: {
    flex: 1,
  },
  bronzeWashTypeModalOptionLabel: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '700',
    marginBottom: 2,
  },
  bronzeWashTypeModalOptionDesc: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '500',
    lineHeight: 18,
  },
  serviceStepWrap: {
    width: '100%',
  },
  resourcesToggleFixed: {
    position: 'absolute',
    left: 16,
    right: 16,
    zIndex: 10,
  },
  serviceModeToggle: {
    flexDirection: 'row',
    gap: 10,
    paddingHorizontal: 4,
  },
  serviceModePill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 18,
    backgroundColor: 'rgba(15,23,42,0.6)',
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.3)',
  },
  serviceModeLabel: {
    color: 'rgba(135,206,235,0.6)',
    fontSize: 15,
    fontWeight: '700',
  },
  serviceModeLabelHighlight: {
    color: SKY,
  },
  serviceModeLabelHighlightYellow: {
    color: DETAILING_YELLOW,
  },
  addOnsRow: {
    marginTop: 14,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: 'rgba(148,163,184,0.2)',
  },
  addOnsButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 14,
    backgroundColor: 'rgba(135,206,235,0.08)',
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.25)',
  },
  addOnsButtonIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: SKY + '20',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addOnsButtonText: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
  },
  addOnsButtonHint: {
    color: '#94A3B8',
    fontSize: 12,
    marginTop: 1,
  },
  addOnsBadge: {
    backgroundColor: SKY,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 10,
    marginLeft: 'auto',
  },
  addOnsBadgeText: {
    color: '#FFFFFF',
    fontSize: 12,
    fontWeight: '800',
  },
  modalAddOnsSection: {
    marginTop: 14,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: customerTheme.primary + '20',
  },
  modalAddOnsTitle: {
    color: customerTheme.primary,
    fontSize: 11,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
    marginBottom: 10,
  },
  modalAddOnRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    paddingVertical: 6,
  },
  modalAddOnName: {
    color: colors.headerText,
    fontSize: 13,
    fontWeight: '600',
    flex: 1,
  },
  modalAddOnPrice: {
    color: customerTheme.primary,
    fontSize: 13,
    fontWeight: '700',
  },
  modalAddOnTotal: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 10,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: customerTheme.primary + '18',
  },
  modalAddOnTotalLabel: {
    color: colors.headerSubtext,
    fontSize: 13,
    fontWeight: '600',
  },
  modalAddOnTotalValue: {
    color: customerTheme.primary,
    fontSize: 15,
    fontWeight: '800',
  },
  addOnsModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  addOnsModalContent: {
    width: '100%',
    maxWidth: 360,
    height: '85%',
    maxHeight: 560,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(135,206,235,0.35)',
    overflow: 'hidden',
  },
  addOnsModalContentInner: {
    flex: 1,
    padding: 20,
    minHeight: 320,
  },
  addOnsModalHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 4,
  },
  addOnsModalTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  addOnsModalTitleIcon: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: SKY + '22',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addOnsModalTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
  },
  addOnsModalCloseBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(148,163,184,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  addOnsModalSubtitle: {
    color: '#94A3B8',
    fontSize: 14,
    marginBottom: 16,
    lineHeight: 20,
  },
  addOnsModalList: {
    flex: 1,
    minHeight: 200,
  },
  addOnsModalListContent: {
    paddingBottom: 16,
  },
  addOnsModalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 14,
    borderRadius: 14,
    backgroundColor: 'rgba(255,255,255,0.06)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.15)',
    marginBottom: 10,
  },
  addOnsModalRowSelected: {
    backgroundColor: SKY + '12',
    borderColor: SKY + '35',
  },
  addOnsModalRowIcon: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: 'rgba(148,163,184,0.12)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  addOnsModalRowIconSelected: {
    backgroundColor: SKY + '25',
  },
  addOnsModalRowBody: {
    flex: 1,
    minWidth: 0,
  },
  addOnsModalRowName: {
    color: '#F9FAFB',
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 2,
  },
  addOnsModalRowDesc: {
    color: '#94A3B8',
    fontSize: 12,
    lineHeight: 17,
    marginBottom: 4,
  },
  addOnsModalRowPriceInline: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '800',
  },
  addOnsModalRowPriceSelected: {
    color: SKY,
  },
  addOnsModalCheck: {
    width: 26,
    height: 26,
    borderRadius: 13,
    borderWidth: 2,
    borderColor: 'rgba(148,163,184,0.45)',
    justifyContent: 'center',
    alignItems: 'center',
    marginLeft: 8,
  },
  addOnsModalCheckSelected: {
    backgroundColor: SKY,
    borderColor: SKY,
  },
  addOnsModalFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 14,
    paddingHorizontal: 16,
    borderRadius: 14,
    backgroundColor: SKY + '15',
    borderWidth: 1,
    borderColor: SKY + '30',
    marginTop: 12,
    marginBottom: 12,
  },
  addOnsModalFooterLabel: {
    color: '#94A3B8',
    fontSize: 14,
    fontWeight: '700',
  },
  addOnsModalFooterValue: {
    color: SKY,
    fontSize: 18,
    fontWeight: '800',
  },
  addOnsModalDone: {
    paddingVertical: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: 14,
    backgroundColor: SKY + '28',
    borderWidth: 1,
    borderColor: SKY + '50',
  },
  addOnsModalDoneText: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
  },
  serviceCardRight: {
    alignItems: 'flex-end',
    gap: 6,
  },
  servicePriceClean: {
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  serviceIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  selectedCheck: {
    width: 24,
    height: 24,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  infoIconBtnInCard: {
    padding: 4,
  },
  serviceName: {
    color: '#F9FAFB',
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 8,
    letterSpacing: -0.2,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  statPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    backgroundColor: 'rgba(148,163,184,0.15)',
    paddingHorizontal: 10,
    paddingVertical: 6,
    borderRadius: 10,
  },
  statText: {
    color: '#94A3B8',
    fontSize: 13,
    fontWeight: '600',
  },
  servicePrice: {
    fontSize: 20,
    fontWeight: '900',
    letterSpacing: -0.3,
  },
  serviceBadgeBox: {
    width: 64,
    height: 64,
    marginLeft: 12,
  },
  serviceBadgeTouch: {
    width: '100%',
    height: '100%',
    borderRadius: 12,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
  },
  washTypeSection: {
    marginTop: 4,
    gap: 12,
  },
  washTypeTitle: {
    color: '#F9FAFB',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: -0.2,
  },
  washTypeOptions: {
    flexDirection: 'row',
    gap: 12,
  },
  washTypePill: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: 'rgba(135,206,235,0.25)',
    backgroundColor: 'rgba(135,206,235,0.08)',
  },
  washTypePillSelected: {
    borderColor: SKY,
    backgroundColor: SKY + '20',
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 4,
  },
  washTypePillText: {
    color: 'rgba(249,250,251,0.8)',
    fontSize: 15,
    fontWeight: '700',
  },
  continueBtn: {
    height: 54,
    borderRadius: 18,
    overflow: 'hidden',
    marginTop: 8,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.5,
    shadowRadius: 12,
    elevation: 12,
    width: '100%',
  },
  continueBtnGradient: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 10,
    paddingHorizontal: 20,
  },
  continueBtnText: {
    color: '#FFFFFF',
    fontSize: 17,
    fontWeight: '800',
    letterSpacing: 0.3,
  },
  // Modal styles
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10,25,41,0.78)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  serviceInfoModalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(10,25,41,0.78)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 24,
  },
  serviceInfoModalContent: {
    width: '100%',
    maxWidth: 320,
    maxHeight: '85%',
    justifyContent: 'center',
    alignItems: 'center',
  },
  serviceInfoModalCard: {
    width: '100%',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 1,
    overflow: 'hidden',
  },
  vehicleInfoModalContent: {
    width: '100%',
    maxWidth: 320,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: customerTheme.primary + '35',
  },
  vehicleInfoModalHeader: {
    position: 'relative',
  },
  vehicleInfoModalPhoto: {
    width: '100%',
    height: 100,
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  vehicleInfoModalPhotoPlaceholder: {
    width: '100%',
    height: 100,
    backgroundColor: customerTheme.primary + '18',
    justifyContent: 'center',
    alignItems: 'center',
  },
  vehicleInfoModalTitleRow: {
    position: 'absolute',
    top: 12,
    left: 12,
    right: 12,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  vehicleInfoModalTitle: {
    color: colors.headerText,
    fontSize: 18,
    fontWeight: '800',
  },
  vehicleInfoModalBody: {
    padding: 16,
  },
  vehicleInfoModalRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 10,
  },
  vehicleInfoModalText: {
    color: colors.headerSubtext,
    fontSize: 13,
    opacity: 0.95,
  },
  vehicleInfoModalDone: {
    margin: 16,
    marginTop: 0,
    backgroundColor: customerTheme.primary,
    borderRadius: 12,
    paddingVertical: 14,
    alignItems: 'center',
  },
  vehicleInfoModalDoneText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '700',
  },
  addressOverlayContent: {
    width: '100%',
    maxWidth: 360,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    borderWidth: 1.5,
    borderColor: customerTheme.primary + '40',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.35,
    shadowRadius: 24,
    elevation: 24,
    overflow: 'hidden',
  },
  addressOverlayContentInner: {
    padding: 24,
  },
  addressOverlayTitle: {
    color: '#F9FAFB',
    fontSize: 20,
    fontWeight: '800',
    marginBottom: 4,
    letterSpacing: 0.2,
  },
  addressOverlaySubtitle: {
    color: 'rgba(148,163,184,0.95)',
    fontSize: 14,
    marginBottom: 20,
    lineHeight: 20,
  },
  addressOverlayInput: {
    backgroundColor: '#0F172A',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    paddingHorizontal: 18,
    paddingVertical: 16,
    color: '#F9FAFB',
    fontSize: 16,
    borderWidth: 1.5,
    borderColor: SKY + '30',
  },
  addressOverlayButtons: {
    flexDirection: 'row',
    gap: 12,
    marginTop: 24,
  },
  addressOverlayCancel: {
    flex: 1,
    paddingVertical: 16,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    backgroundColor: 'rgba(148,163,184,0.18)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.3)',
    alignItems: 'center',
  },
  addressOverlayCancelText: {
    color: '#94A3B8',
    fontSize: 16,
    fontWeight: '700',
  },
  addressOverlaySearchWrap: {
    flex: 1,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    elevation: 4,
    shadowColor: SKY,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.35,
    shadowRadius: 8,
  },
  addressOverlaySearch: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 16,
    paddingHorizontal: 20,
  },
  addressOverlaySearchText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: '800',
    letterSpacing: 0.2,
  },
  modalContent: {
    backgroundColor: customerTheme.backgroundColor,
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    padding: 24,
    borderWidth: 1.5,
    borderColor: customerTheme.primary + '35',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 10 },
    shadowOpacity: 0.5,
    shadowRadius: 20,
    elevation: 20,
  },
  modalContentTouch: {
    width: '100%',
    maxWidth: 320,
    maxHeight: '82%',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    borderColor: customerTheme.primary + '30',
  },
  modalContentBlur: {
    flex: 1,
    overflow: 'hidden',
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    paddingBottom: 16,
  },
  modalHeaderHubStyle: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: customerTheme.primary + '20',
  },
  modalTitleHubStyle: {
    color: customerTheme.primary,
    fontSize: 13,
    fontWeight: '700',
    letterSpacing: 1,
    textTransform: 'uppercase',
  },
  modalCloseBtn: {
    padding: 4,
  },
  modalScrollContent: {
    maxHeight: 360,
    paddingHorizontal: 16,
    paddingTop: 14,
  },
  modalHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 12,
  },
  modalIconWrapper: {
    width: 44,
    height: 44,
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: customerTheme.primary + '25',
  },
  modalTitleContainer: {
    flex: 1,
  },
  modalTitle: {
    color: colors.headerText,
    fontSize: 17,
    fontWeight: '800',
    marginBottom: 2,
  },
  modalPrice: {
    color: customerTheme.primary,
    fontSize: 16,
    fontWeight: '800',
  },
  modalDescription: {
    color: colors.headerSubtext,
    fontSize: 13,
    lineHeight: 20,
    marginBottom: 12,
    opacity: 0.95,
  },
  bulletPointsContainer: {
    gap: 8,
    marginBottom: 14,
  },
  bulletPoint: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 8,
  },
  bulletPointText: {
    color: colors.headerText,
    fontSize: 13,
    lineHeight: 18,
    flex: 1,
    opacity: 0.92,
  },
  modalCloseButton: {
    borderRadius: BOOKING_CARD.BORDER_RADIUS,
    overflow: 'hidden',
    shadowColor: customerTheme.primary,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.2,
    shadowRadius: 6,
    elevation: 3,
  },
  modalCloseButtonGradient: {
    padding: 12,
    alignItems: 'center',
  },
  modalCloseButtonText: {
    color: '#FFFFFF',
    fontWeight: '800',
    fontSize: 16,
    letterSpacing: 0.3,
  },
});