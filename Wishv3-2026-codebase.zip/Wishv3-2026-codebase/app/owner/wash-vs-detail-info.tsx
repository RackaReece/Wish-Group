import React, { useState, useRef, useCallback, useMemo } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Dimensions,
  FlatList,
  ViewToken,
  TouchableOpacity,
  ScrollView,
  useWindowDimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { SafeAreaView, useSafeAreaInsets } from 'react-native-safe-area-context';
import AppHeader from '../../src/components/shared/AppHeader';
import { hapticFeedback } from '../../src/services/HapticFeedbackService';
import { getNavTabBottomPadding } from '../../src/constants/layoutConstants';
import { colors } from '../../src/constants/colors';
import { customerTheme } from '../../src/constants/customerTheme';

const { width } = Dimensions.get('window');
const isSmallScreen = width < 375;
const SKY = colors.SKY;
const DETAIL = colors.DETAILING_YELLOW;

type TabId = 'wash' | 'detail';

interface SlideData {
  id: string;
  title: string;
  subtitle: string;
  pros: string[];
  cons: string[];
  icon: keyof typeof Ionicons.glyphMap;
  accent: string;
}

const WASH_SLIDES: SlideData[] = [
  {
    id: 'w1',
    title: 'What are washes?',
    subtitle: 'Regular cleaning, fast & fixed price',
    pros: ['Day-to-day cleanliness', 'Fixed price, predictable', 'Quick (typically 30–60 min)', 'Same result every time', 'Best for regular upkeep'],
    cons: ['No paint correction or polishing', 'Won’t remove scratches or swirls', 'Not for heavily soiled or neglected cars'],
    icon: 'water',
    accent: SKY,
  },
  {
    id: 'w2',
    title: 'Wash tiers',
    subtitle: 'Bronze → Silver → Gold → Platinum',
    pros: ['Bronze: quick exterior', 'Silver & Gold: deeper clean', 'Platinum: premium valet', 'Choose the level you need'],
    cons: ['None are detailing — no machine polishing', 'Platinum is still a wash, not paint enhancement'],
    icon: 'layers',
    accent: SKY,
  },
  {
    id: 'w3',
    title: 'Choose a wash when…',
    subtitle: 'You want clean, not correction',
    pros: ['Your car is in decent condition', 'You want it clean and fresh', 'You wash regularly', 'You prefer a set time and price'],
    cons: ['Not suitable if paint is dull or scratched', 'Not for interior deep clean or protection'],
    icon: 'checkmark-done',
    accent: SKY,
  },
];

const DETAIL_SLIDES: SlideData[] = [
  {
    id: 'd1',
    title: 'What is detailing?',
    subtitle: 'Restore, enhance & protect',
    pros: ['Condition-based: restore dull or scratched paint', 'Interior stains, odours, deep clean', 'Paint correction, ceramic coating, PPF', 'Skilled work — results vary by condition'],
    cons: ['Takes longer than a wash', 'Price reflects time & skill', 'Heavily used cars may need more'],
    icon: 'diamond',
    accent: DETAIL,
  },
  {
    id: 'd2',
    title: 'Detailing services',
    subtitle: 'Interior, exterior, full detail & more',
    pros: ['Interior / Exterior / Full detail', 'Paint correction & enhancement', 'Ceramic coating & PPF', 'Prep for resale or protection'],
    cons: ['Platinum wash ≠ exterior detail', 'Wash = clean only; detail = correct & protect', 'Book the right one for your goals'],
    icon: 'sparkles',
    accent: DETAIL,
  },
  {
    id: 'd3',
    title: 'Choose detailing when…',
    subtitle: 'You need more than a wash',
    pros: ['Paint looks dull or scratched', 'Interior has stains or odours', 'You want protection or resale prep', 'You’re ready for condition-based results'],
    cons: ['Not a “quick clean” — allow time', 'Cost reflects skill and condition'],
    icon: 'diamond',
    accent: DETAIL,
  },
];

function InfoHubFooter({
  slides,
  slideIndex,
  accent,
  bottomPad,
  contentPadH,
  isLastSlide,
  onBack,
  onNext,
  onBook,
}: Readonly<{
  slides: SlideData[];
  slideIndex: number;
  accent: string;
  bottomPad: number;
  contentPadH: number;
  isLastSlide: boolean;
  onBack: () => void;
  onNext: () => void;
  onBook: () => void;
}>) {
  return (
    <View style={[styles.footer, { paddingHorizontal: contentPadH, paddingTop: 16, paddingBottom: bottomPad }]}>
      <View style={styles.dotsRow}>
        {slides.map((s, i) => (
          <View
            key={s.id}
            style={[styles.dot, i === slideIndex && styles.dotActive, i === slideIndex && { backgroundColor: accent }]}
          />
        ))}
      </View>
      <View style={styles.buttonRow}>
        {slideIndex > 0 ? (
          <TouchableOpacity style={[styles.backBtn, { borderColor: accent }]} onPress={onBack} activeOpacity={0.8}>
            <Ionicons name="arrow-back" size={18} color={accent} />
            <Text style={[styles.backBtnText, { color: accent }]}>Back</Text>
          </TouchableOpacity>
        ) : (
          <View style={styles.backBtnPlaceholder} />
        )}
        <TouchableOpacity style={[styles.nextBtn, { backgroundColor: accent }]} onPress={onNext} activeOpacity={0.9}>
          <Text style={styles.nextBtnText}>{isLastSlide ? 'Done' : 'Next'}</Text>
          <Ionicons name="arrow-forward" size={18} color="#fff" />
        </TouchableOpacity>
      </View>
      {isLastSlide && (
        <TouchableOpacity style={[styles.ctaButton, { backgroundColor: accent }]} onPress={onBook} activeOpacity={0.9}>
          <Text style={styles.ctaButtonTextWhite}>Book a service</Text>
          <Ionicons name="car-sport" size={18} color="#fff" />
        </TouchableOpacity>
      )}
    </View>
  );
}

function SlideCard({ slide, cardHeight }: Readonly<{ slide: SlideData; cardHeight: number }>) {
  const accent = slide.accent;
  return (
    <View style={[styles.slidePage, { minHeight: cardHeight }]}>
      <View style={styles.slideCard}>
        <LinearGradient
          colors={[accent + '18', accent + '06', 'transparent']}
          style={StyleSheet.absoluteFill}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
        />
        <ScrollView
          style={styles.slideScroll}
          contentContainerStyle={styles.slideScrollContent}
          showsVerticalScrollIndicator={false}
        >
          <View style={[styles.slideIconWrap, { backgroundColor: accent + '24' }]}>
            <Ionicons name={slide.icon as any} size={26} color={accent} />
          </View>
          <Text style={styles.slideTitle}>{slide.title}</Text>
          <Text style={[styles.slideSubtitle, { color: accent }]}>{slide.subtitle}</Text>

          <View style={styles.prosConsRow}>
            <View style={styles.prosConsBlock}>
              <View style={styles.prosConsHeader}>
                <Ionicons name="add-circle" size={14} color={colors.ECO_GREEN ?? '#10B981'} />
                <Text style={styles.prosConsTitle}>Pros</Text>
              </View>
              {slide.pros.map((p) => (
                <View key={p} style={styles.bulletRow}>
                  <View style={[styles.bulletDot, { backgroundColor: accent }]} />
                  <Text style={styles.bulletText}>{p}</Text>
                </View>
              ))}
            </View>
            <View style={styles.prosConsBlock}>
              <View style={styles.prosConsHeader}>
                <Ionicons name="remove-circle" size={14} color="rgba(248,113,113,0.9)" />
                <Text style={styles.prosConsTitle}>Cons</Text>
              </View>
              {slide.cons.map((c) => (
                <View key={c} style={styles.bulletRow}>
                  <View style={[styles.bulletDot, { backgroundColor: 'rgba(248,113,113,0.8)' }]} />
                  <Text style={styles.bulletText}>{c}</Text>
                </View>
              ))}
            </View>
          </View>
        </ScrollView>
      </View>
    </View>
  );
}

export default function WashVsDetailInfo() {
  const insets = useSafeAreaInsets();
  const { height: winHeight } = useWindowDimensions();
  const [tab, setTab] = useState<TabId>('wash');
  const [slideIndex, setSlideIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);

  const slides = tab === 'wash' ? WASH_SLIDES : DETAIL_SLIDES;
  const currentSlide = slides[slideIndex];
  const accent = currentSlide?.accent ?? SKY;
  const isLastSlide = slideIndex === slides.length - 1;

  const bottomPad = getNavTabBottomPadding(insets);
  const cardHeight = useMemo(() => {
    const headerH = 100;
    const tabsH = 52;
    const progressH = 24;
    const footerH = 120;
    return Math.max(220, winHeight - headerH - tabsH - progressH - footerH - bottomPad - (insets.top ?? 0) - 24);
  }, [winHeight, insets.top, insets.bottom, bottomPad]);

  const onViewableItemsChanged = useCallback(
    ({ viewableItems }: { viewableItems: ViewToken[] }) => {
      if (viewableItems[0]?.index != null) setSlideIndex(viewableItems[0].index);
    },
    []
  );
  const viewabilityConfig = { viewAreaCoveragePercentThreshold: 80 };

  const setTabAndReset = useCallback((t: TabId) => {
    hapticFeedback('light');
    setTab(t);
    setSlideIndex(0);
    flatListRef.current?.scrollToOffset({ offset: 0, animated: false });
  }, []);

  const handleNext = useCallback(() => {
    hapticFeedback('light');
    if (slideIndex < slides.length - 1) {
      flatListRef.current?.scrollToIndex({ index: slideIndex + 1, animated: true });
    } else {
      router.back();
    }
  }, [slideIndex, slides.length]);

  const handleBack = useCallback(() => {
    hapticFeedback('light');
    if (slideIndex > 0) {
      flatListRef.current?.scrollToIndex({ index: slideIndex - 1, animated: true });
    } else {
      router.back();
    }
  }, [slideIndex]);

  const handleBook = () => {
    hapticFeedback('medium');
    router.replace('/owner/owner-dashboard');
  };

  const contentPadH = isSmallScreen ? 16 : 20;

  return (
    <SafeAreaView style={styles.container} edges={['top', 'left', 'right']}>
      <LinearGradient colors={customerTheme.backgroundGradient} style={StyleSheet.absoluteFill} />

      <AppHeader
        title="Info hub"
        subtitle="Wash vs detail"
        variant="dashboard"
        showBack
        onBack={() => {
          hapticFeedback('light');
          router.back();
        }}
        accountType="customer"
      />

      {/* Tabs – spacing below header */}
      <View style={[styles.tabRow, { paddingHorizontal: contentPadH, marginTop: 12 }]}>
        <TouchableOpacity
          onPress={() => setTabAndReset('wash')}
          style={[styles.tab, tab === 'wash' && styles.tabActive, tab === 'wash' && { backgroundColor: SKY, borderColor: SKY }]}
          activeOpacity={0.8}
        >
          <Ionicons name="water-outline" size={18} color={tab === 'wash' ? '#fff' : SKY} />
          <Text style={[styles.tabLabel, tab === 'wash' && styles.tabLabelActive, tab === 'wash' && { color: '#fff' }]}>Wash</Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => setTabAndReset('detail')}
          style={[styles.tab, tab === 'detail' && styles.tabActive, tab === 'detail' && { backgroundColor: DETAIL, borderColor: DETAIL }]}
          activeOpacity={0.8}
        >
          <Ionicons name="diamond-outline" size={18} color={tab === 'detail' ? '#fff' : DETAIL} />
          <Text style={[styles.tabLabel, tab === 'detail' && styles.tabLabelActive, tab === 'detail' && { color: '#fff' }]}>Detail</Text>
        </TouchableOpacity>
      </View>

      {/* Progress */}
      <View style={[styles.progressRow, { paddingHorizontal: contentPadH, marginTop: 6 }]}>
        <View style={styles.progressTrack}>
          <View
            style={[
              styles.progressFill,
              { width: `${((slideIndex + 1) / slides.length) * 100}%`, backgroundColor: accent },
            ]}
          />
        </View>
      </View>

      {/* Slides */}
      <View style={styles.listWrap}>
        <FlatList
          ref={flatListRef}
          data={slides}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onViewableItemsChanged={onViewableItemsChanged}
          viewabilityConfig={viewabilityConfig}
          keyExtractor={(item) => item.id}
          renderItem={({ item }) => <SlideCard slide={item} cardHeight={cardHeight} />}
          getItemLayout={(_, index) => ({ length: width, offset: width * index, index })}
          style={styles.flatList}
          contentContainerStyle={styles.flatListContent}
        />
      </View>

      <InfoHubFooter
        slides={slides}
        slideIndex={slideIndex}
        accent={accent}
        bottomPad={bottomPad}
        contentPadH={contentPadH}
        isLastSlide={isLastSlide}
        onBack={handleBack}
        onNext={handleNext}
        onBook={handleBook}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: customerTheme.backgroundColor },
  tabRow: {
    flexDirection: 'row',
    gap: 10,
    paddingVertical: 6,
  },
  tab: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 12,
    borderRadius: 14,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.25)',
  },
  tabActive: {},
  tabLabel: {
    fontSize: 15,
    fontWeight: '700',
    color: '#E5E7EB',
  },
  tabLabelActive: {
    color: '#fff',
  },
  progressRow: { marginBottom: 4 },
  progressTrack: {
    height: 4,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.2)',
    overflow: 'hidden',
  },
  progressFill: { height: '100%', borderRadius: 2 },
  listWrap: { flex: 1, minHeight: 0 },
  flatList: { flex: 1 },
  flatListContent: {},
  slidePage: {
    width,
    paddingHorizontal: isSmallScreen ? 16 : 20,
    paddingVertical: 12,
    justifyContent: 'center',
  },
  slideCard: {
    borderRadius: 18,
    overflow: 'hidden',
    padding: 18,
    borderWidth: 1,
    borderColor: customerTheme.primary + '35',
    backgroundColor: customerTheme.backgroundColor,
    flex: 1,
    minHeight: 0,
    position: 'relative',
  },
  slideScroll: { flex: 1 },
  slideScrollContent: { paddingBottom: 4 },
  slideIconWrap: {
    width: 44,
    height: 44,
    borderRadius: 22,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 8,
  },
  slideTitle: {
    color: '#F9FAFB',
    fontSize: isSmallScreen ? 17 : 19,
    fontWeight: '800',
    marginBottom: 2,
  },
  slideSubtitle: {
    fontSize: 12,
    fontWeight: '700',
    marginBottom: 8,
  },
  prosConsRow: {
    flexDirection: 'row',
    gap: 10,
  },
  prosConsBlock: {
    flex: 1,
  },
  prosConsHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    marginBottom: 4,
  },
  prosConsTitle: {
    color: '#E5E7EB',
    fontSize: 11,
    fontWeight: '800',
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  bulletRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: 6,
    marginBottom: 2,
  },
  bulletDot: {
    width: 4,
    height: 4,
    borderRadius: 2,
    marginTop: 5,
  },
  bulletText: {
    color: '#D1D5DB',
    fontSize: 11,
    lineHeight: 16,
    flex: 1,
  },
  footer: {},
  dotsRow: {
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 6,
    marginBottom: 10,
  },
  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: 'rgba(255,255,255,0.35)',
  },
  dotActive: { width: 16 },
  buttonRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    gap: 8,
  },
  backBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingVertical: 10,
    paddingHorizontal: 12,
    borderRadius: 10,
    borderWidth: 2,
  },
  backBtnText: { fontSize: 14, fontWeight: '700' },
  backBtnPlaceholder: { width: 1 },
  nextBtn: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 5,
    paddingVertical: 10,
    paddingHorizontal: 16,
    borderRadius: 10,
  },
  nextBtnText: { color: '#fff', fontSize: 15, fontWeight: '800' },
  ctaButton: {
    marginTop: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    paddingVertical: 14,
    borderRadius: 12,
  },
  ctaButtonText: { fontSize: 15, fontWeight: '800' },
  ctaButtonTextWhite: { color: '#fff', fontSize: 16, fontWeight: '800' },
});
