import React, { useState, useRef, useEffect } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Animated,
  FlatList,
  ViewToken,
  StatusBar,
} from 'react-native';
import { router } from 'expo-router';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { LinearGradient } from 'expo-linear-gradient';
import { Video, ResizeMode, AVPlaybackStatus } from 'expo-av';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';
import AppHeader, { HEADER_CONTENT_OFFSET } from '../src/components/shared/AppHeader';
import { hapticFeedback } from '../src/services/HapticFeedbackService';

const { width, height } = Dimensions.get('window');

interface Slide {
  id: string;
  title: string;
  subtitle: string;
  description: string;
  iconName: keyof typeof Ionicons.glyphMap;
  accent: string;
}

const SLIDES: Slide[] = [
  {
    id: '1',
    title: 'Wish a Wash',
    subtitle: 'Premium car care at your door',
    description: 'Skip the car wash queue. Our professional valeters come to you — at home, work, or wherever you park. Book in seconds and get a gleaming car without leaving your seat.',
    iconName: 'car-sport',
    accent: '#5B8FA8',
  },
  {
    id: '2',
    title: 'How It Works',
    subtitle: 'Simple, fast, on your schedule',
    description: 'Pick your service — from a quick Bronze wash to a full Platinum valet or detailing. Choose your location and time. We match you with a vetted valeter nearby who comes to you.',
    iconName: 'calendar',
    accent: '#10B981',
  },
  {
    id: '3',
    title: 'Clear Pricing, No Surprises',
    subtitle: 'You see the price before you book',
    description: 'Every wash has a fixed price. No hidden fees, no upsells at the door. Our valeters earn fairly, and you know exactly what you’re paying.',
    iconName: 'wallet',
    accent: '#8B5CF6',
  },
  {
    id: '4',
    title: 'Track Your Valeter Live',
    subtitle: 'Real-time updates from start to finish',
    description: 'See your valeter on the map, get an ETA, and receive updates and photos when your car is done. Full transparency from book to finish.',
    iconName: 'navigate',
    accent: '#3B82F6',
  },
  {
    id: '5',
    title: 'Why Customers Love It',
    subtitle: 'Save time. Get pro results.',
    description: 'No driving to a car wash or waiting in line. Expert valeters, quality products, and optional eco-friendly washes. Your car gets the care it deserves, wherever you are.',
    iconName: 'sparkles',
    accent: '#F59E0B',
  },
];

export default function OnboardingScreen() {
  const [index, setIndex] = useState(0);
  const flatListRef = useRef<FlatList>(null);
  const progressAnim = useRef(new Animated.Value(0)).current;
  const slideAnim = useRef(new Animated.Value(1)).current;
  const videoRef = useRef<Video>(null);

  const handlePlaybackStatusUpdate = (status: AVPlaybackStatus) => {
    if (!status.isLoaded || !videoRef.current) return;
    if (status.didJustFinish) {
      videoRef.current.setPositionAsync(0).then(() => videoRef.current?.playAsync()).catch(() => {});
    }
  };

  useEffect(() => {
    Animated.parallel([
      Animated.timing(progressAnim, {
        toValue: (index + 1) / SLIDES.length,
        duration: 400,
        useNativeDriver: false,
      }),
      Animated.spring(slideAnim, {
        toValue: 1,
        tension: 50,
        friction: 9,
        useNativeDriver: true,
      }),
    ]).start();
  }, [index]);

  const onViewableItemsChanged = useRef(({ viewableItems }: { viewableItems: ViewToken[] }) => {
    if (viewableItems[0]?.index != null) {
      setIndex(viewableItems[0].index);
    }
  }).current;

  const handleNext = () => {
    if (index < SLIDES.length - 1) {
      flatListRef.current?.scrollToIndex({ index: index + 1, animated: true });
    } else {
      handleGetStarted();
    }
  };

  const handleGetStarted = async () => {
    try {
      await AsyncStorage.setItem('onboarding_seen', 'true');
    } catch {
      // ignore
    }
    router.replace('/auth/login');
  };

  const renderSlide = ({ item }: { item: Slide }) => (
    <View style={[styles.slide, { width }]}>
      <Animated.View
        style={[
          styles.iconWrap,
          {
            backgroundColor: item.accent + '22',
            borderColor: item.accent + '44',
            transform: [{ scale: slideAnim }],
          },
        ]}
      >
        <Ionicons name={item.iconName} size={64} color={item.accent} />
      </Animated.View>

      <Text style={styles.title}>{item.title}</Text>
      <Text style={styles.subtitle}>{item.subtitle}</Text>
      <Text style={styles.description}>{item.description}</Text>
    </View>
  );

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor="transparent" translucent />
      <Video
        ref={videoRef}
        source={require('../assets/onboarding.mp4')}
        style={styles.videoBackground}
        resizeMode={ResizeMode.COVER}
        shouldPlay
        isLooping
        isMuted
        onPlaybackStatusUpdate={handlePlaybackStatusUpdate}
      />
      <LinearGradient
        colors={['rgba(10,25,41,0.85)', 'rgba(26,47,74,0.75)', 'rgba(10,25,41,0.9)']}
        style={StyleSheet.absoluteFill}
        pointerEvents="none"
      />
      <SafeAreaView style={styles.safe} edges={[]}>
        <AppHeader
          title="Wish a Wash"
          showBack
          onBack={() => { hapticFeedback('light'); router.back(); }}
        />
        {/* Progress row */}
        <View style={[styles.header, { paddingTop: 8 + HEADER_CONTENT_OFFSET }]}>
          <View style={styles.progressTrack}>
            <Animated.View
              style={[
                styles.progressFill,
                {
                  width: progressAnim.interpolate({
                    inputRange: [0, 1],
                    outputRange: ['0%', '100%'],
                  }),
                },
              ]}
            />
          </View>
          <TouchableOpacity onPress={handleGetStarted} style={styles.skip} activeOpacity={0.8}>
            <Text style={styles.skipText}>Skip</Text>
          </TouchableOpacity>
        </View>

        {/* Slides */}
        <FlatList
          ref={flatListRef}
          data={SLIDES}
          renderItem={renderSlide}
          keyExtractor={(s) => s.id}
          horizontal
          pagingEnabled
          showsHorizontalScrollIndicator={false}
          onViewableItemsChanged={onViewableItemsChanged}
          viewabilityConfig={{ viewAreaCoveragePercentThreshold: 50 }}
          getItemLayout={(_, i) => ({ length: width, offset: width * i, index: i })}
          scrollEventThrottle={16}
        />

        {/* Footer */}
        <View style={styles.footer}>
          <View style={styles.dots}>
            {SLIDES.map((_, i) => (
              <View
                key={i}
                style={[
                  styles.dot,
                  i === index && styles.dotActive,
                  i < index && styles.dotDone,
                ]}
              />
            ))}
          </View>
          <TouchableOpacity
            style={[styles.nextBtn, { backgroundColor: SLIDES[index]?.accent ?? '#5B8FA8' }]}
            onPress={handleNext}
            activeOpacity={0.9}
          >
            <Text style={styles.nextText}>
              {index === SLIDES.length - 1 ? 'Get Started' : 'Next'}
            </Text>
            <Ionicons name="arrow-forward" size={20} color="#fff" />
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0A1929',
  },
  videoBackground: {
    ...StyleSheet.absoluteFillObject,
  },
  safe: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: 8,
    paddingBottom: 16,
    gap: 12,
  },
  progressTrack: {
    flex: 1,
    height: 4,
    backgroundColor: 'rgba(255,255,255,0.12)',
    borderRadius: 2,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: '#5B8FA8',
    borderRadius: 2,
  },
  skip: {
    paddingVertical: 8,
    paddingHorizontal: 14,
  },
  skipText: {
    color: 'rgba(255,255,255,0.7)',
    fontSize: 15,
    fontWeight: '600',
  },
  slide: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
    paddingBottom: 24,
  },
  iconWrap: {
    width: 130,
    height: 130,
    borderRadius: 65,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 40,
    borderWidth: 2,
  },
  title: {
    fontSize: 28,
    fontWeight: '800',
    color: '#fff',
    textAlign: 'center',
    marginBottom: 8,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 17,
    color: '#5B8FA8',
    textAlign: 'center',
    marginBottom: 16,
    fontWeight: '600',
  },
  description: {
    fontSize: 16,
    color: 'rgba(255,255,255,0.88)',
    textAlign: 'center',
    lineHeight: 25,
    maxWidth: 320,
  },
  footer: {
    paddingHorizontal: 24,
    paddingBottom: 40,
    paddingTop: 24,
    alignItems: 'center',
    gap: 20,
  },
  dots: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: 'rgba(255,255,255,0.25)',
  },
  dotActive: {
    width: 24,
    backgroundColor: '#5B8FA8',
  },
  dotDone: {
    backgroundColor: 'rgba(91,143,168,0.6)',
  },
  nextBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 16,
    paddingHorizontal: 32,
    borderRadius: 14,
    minWidth: 180,
    gap: 8,
  },
  nextText: {
    color: '#fff',
    fontSize: 17,
    fontWeight: '700',
  },
});
