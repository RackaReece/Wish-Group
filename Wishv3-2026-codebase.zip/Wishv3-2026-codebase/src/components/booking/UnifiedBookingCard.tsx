import React from 'react';
import { View, StyleSheet, TouchableOpacity, ViewStyle } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { colors } from '../../constants/colors';
import { BOOKING_CARD, HEADER_STYLE_CARD_GRADIENT, HEADER_STYLE_CARD_BORDER } from '../../constants/bookingCardTheme';

const SKY = colors.SKY;
const CARD_RADIUS = BOOKING_CARD.BORDER_RADIUS;
const STRIP_WIDTH = 3;

export interface UnifiedBookingCardProps {
  children: React.ReactNode;
  onPress?: () => void;
  style?: ViewStyle;
  contentStyle?: ViewStyle;
  /** Accent colour for strip and border (e.g. SKY for wash, PREMIUM_PURPLE for detailing). Default SKY. */
  stripColor?: string;
  /** Blur intensity. Default 18 (lighter look). */
  intensity?: number;
  /** Show the curved left strip. Default true. */
  showStrip?: boolean;
  /** Use semi-transparent header-style background (same as Book a Service header). Default true. */
  headerStyle?: boolean;
}

/**
 * Unified card design for wash hub and mobile valeter flows: semi-transparent header-style
 * gradient, BlurView, curved border. Use for all booking flow cards and tracking.
 */
export default function UnifiedBookingCard({
  children,
  onPress,
  style,
  contentStyle,
  stripColor = SKY,
  intensity = 28,
  showStrip = true,
  headerStyle = true,
}: Readonly<UnifiedBookingCardProps>) {
  const borderColor = headerStyle ? HEADER_STYLE_CARD_BORDER : stripColor + '25';

  const content = (
    <View style={[styles.card, { borderColor }]}>
      {headerStyle && (
        <LinearGradient
          colors={HEADER_STYLE_CARD_GRADIENT}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={StyleSheet.absoluteFill}
        />
      )}
      <BlurView
        intensity={intensity}
        tint="dark"
        style={[StyleSheet.absoluteFill, styles.blur]}
      />
      {showStrip && (
        <View style={[styles.strip, { backgroundColor: stripColor }]} />
      )}
      <View style={[styles.inner, contentStyle]}>{children}</View>
    </View>
  );

  if (onPress) {
    return (
      <TouchableOpacity
        activeOpacity={0.9}
        onPress={onPress}
        style={[styles.touchable, style]}
      >
        {content}
      </TouchableOpacity>
    );
  }

  return <View style={[styles.wrapper, style]}>{content}</View>;
}

const styles = StyleSheet.create({
  wrapper: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
  },
  touchable: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
  },
  card: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
    borderWidth: 1,
    padding: 12,
  },
  blur: {
    borderRadius: CARD_RADIUS,
    overflow: 'hidden',
  },
  strip: {
    position: 'absolute',
    left: 0,
    top: 0,
    bottom: 0,
    width: STRIP_WIDTH,
    borderTopLeftRadius: CARD_RADIUS,
    borderBottomLeftRadius: CARD_RADIUS,
  },
  inner: {},
});
