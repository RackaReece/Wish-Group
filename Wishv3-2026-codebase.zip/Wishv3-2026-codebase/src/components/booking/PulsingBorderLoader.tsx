import React, { useEffect, useRef, useState } from 'react';
import { View, StyleSheet, Animated, ViewStyle } from 'react-native';

const DOT_SIZE = 10;
const STROKE = 2;
const DURATION = 2400; // one full lap
const PULSE_DURATION = 600;

type PulsingBorderLoaderProps = {
  color?: string;
  style?: ViewStyle;
  borderRadius?: number;
};

/**
 * A dashed border with a pulsing dot that travels around the card perimeter,
 * giving a loading / "waiting for jobs" feel. Use when there are no jobs.
 */
export default function PulsingBorderLoader({
  color = '#87CEEB',
  style,
  borderRadius = 16,
}: PulsingBorderLoaderProps) {
  const [layout, setLayout] = useState({ width: 0, height: 0 });
  const progress = useRef(new Animated.Value(0)).current;
  const pulse = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.timing(progress, {
        toValue: 1,
        duration: DURATION,
        useNativeDriver: true,
      })
    );
    loop.start();
    return () => loop.stop();
  }, [progress]);

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, {
          toValue: 1.35,
          duration: PULSE_DURATION,
          useNativeDriver: true,
        }),
        Animated.timing(pulse, {
          toValue: 1,
          duration: PULSE_DURATION,
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [pulse]);

  const w = Math.max(0, layout.width - STROKE * 2);
  const h = Math.max(0, layout.height - STROKE * 2);
  const perimeter = 2 * w + 2 * h;

  const steps = 40;
  const inputRange: number[] = [];
  const outputRangeX: number[] = [];
  const outputRangeY: number[] = [];
  const halfDot = DOT_SIZE / 2;
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    inputRange.push(t);
    const pos = t * perimeter;
    let x: number, y: number;
    if (pos < w) {
      x = pos;
      y = 0;
    } else if (pos < w + h) {
      x = w;
      y = pos - w;
    } else if (pos < 2 * w + h) {
      x = 2 * w + h - pos;
      y = h;
    } else {
      x = 0;
      y = perimeter - pos;
    }
    outputRangeX.push(x + STROKE - halfDot);
    outputRangeY.push(y + STROKE - halfDot);
  }

  const dotX = progress.interpolate({ inputRange, outputRange: outputRangeX });
  const dotY = progress.interpolate({ inputRange, outputRange: outputRangeY });

  if (layout.width === 0 || layout.height === 0) {
    return (
      <View
        style={[styles.outer, style]}
        onLayout={(e) => {
          const { width, height } = e.nativeEvent.layout;
          setLayout({ width, height });
        }}
      />
    );
  }

  return (
    <View
      style={[styles.outer, style]}
      onLayout={(e) => {
        const { width, height } = e.nativeEvent.layout;
        setLayout({ width, height });
      }}
    >
      <View
        style={[
          styles.dashedBorder,
          {
            width: layout.width,
            height: layout.height,
            borderRadius,
            borderColor: color,
          },
        ]}
      />
      {/* Dot: position via transform only (native driver does not support left/top on Animated.View) */}
      <View style={[styles.dotPosition, { width: layout.width, height: layout.height }]}>
        <Animated.View
          style={{
            width: DOT_SIZE,
            height: DOT_SIZE,
            borderRadius: DOT_SIZE / 2,
            backgroundColor: color,
            transform: [
              { translateX: dotX },
              { translateY: dotY },
              { scale: pulse },
            ],
          }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  outer: {
    position: 'absolute',
    left: 0,
    right: 0,
    top: 0,
    bottom: 0,
    alignItems: 'center',
    justifyContent: 'center',
  },
  dashedBorder: {
    position: 'absolute',
    left: 0,
    top: 0,
    borderWidth: STROKE,
    borderStyle: 'dashed',
    opacity: 0.7,
  },
  dotPosition: {
    position: 'absolute',
    left: 0,
    top: 0,
    overflow: 'visible',
  },
});
