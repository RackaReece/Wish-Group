import React, { useEffect, useState, useRef } from 'react';
import { View, Text, StyleSheet, Animated } from 'react-native';
import { BlurView } from 'expo-blur';
import { LinearGradient } from 'expo-linear-gradient';
import { Ionicons } from '@expo/vector-icons';

interface CountdownTimerProps {
  seconds: number;
  onComplete?: () => void;
  size?: 'small' | 'medium' | 'large';
  showIcon?: boolean;
  /** When 'integrated', renders inline to match card styling (no blue, no standalone box) */
  variant?: 'default' | 'integrated';
}

export default function CountdownTimer({ 
  seconds, 
  onComplete, 
  size = 'medium',
  showIcon = true,
  variant = 'default',
}: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState(seconds);
  const scaleAnim = useRef(new Animated.Value(1)).current;
  const pulseAnim = useRef(new Animated.Value(1)).current;
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const onCompleteRef = useRef(onComplete);
  onCompleteRef.current = onComplete;

  useEffect(() => {
    if (seconds <= 0) {
      setTimeLeft(0);
      onCompleteRef.current?.();
      return;
    }
    setTimeLeft(seconds);
  }, [seconds]);

  useEffect(() => {
    if (seconds <= 0) return;
    timerRef.current = setInterval(() => {
      setTimeLeft(prev => {
        const next = prev <= 1 ? 0 : prev - 1;
        if (next === 0) {
          if (timerRef.current) {
            clearInterval(timerRef.current);
            timerRef.current = null;
          }
          onCompleteRef.current?.();
        }
        return next;
      });
    }, 1000);
    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
        timerRef.current = null;
      }
    };
  }, [seconds]);

  useEffect(() => {
    if (timeLeft <= 0) return;
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 1.1,
        duration: 200,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 200,
        useNativeDriver: true,
      }),
    ]).start();
  }, [timeLeft]);

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.05,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [pulseAnim]);

  const formatTime = (totalSeconds: number) => {
    const mins = Math.floor(totalSeconds / 60);
    const secs = totalSeconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const fontSize = size === 'small' ? 24 : size === 'medium' ? 32 : 48;
  const iconSize = size === 'small' ? 16 : size === 'medium' ? 20 : 28;

  if (variant === 'integrated') {
    return (
      <Animated.View style={[styles.integratedContainer, { transform: [{ scale: pulseAnim }] }]}>
        <View style={styles.integratedInner}>
          {showIcon && (
            <Ionicons name="time-outline" size={iconSize} color="#94A3B8" style={styles.icon} />
          )}
          <Animated.Text 
            style={[
              styles.integratedTimeText, 
              { 
                fontSize: size === 'small' ? 20 : fontSize,
                transform: [{ scale: scaleAnim }]
              }
            ]}
          >
            {formatTime(timeLeft)}
          </Animated.Text>
        </View>
      </Animated.View>
    );
  }

  return (
    <Animated.View style={[styles.container, { transform: [{ scale: pulseAnim }] }]}>
      <BlurView intensity={60} tint="dark" style={styles.blurContainer}>
        <LinearGradient
          colors={['rgba(15, 23, 42, 0.75)', 'rgba(15, 23, 42, 0.85)']}
          style={StyleSheet.absoluteFill}
        />
        <View style={[styles.border, { borderColor: 'rgba(96,165,250,0.3)' }]} />
        <View style={styles.content}>
          {showIcon && (
            <Ionicons name="time-outline" size={iconSize} color="#60A5FA" style={styles.icon} />
          )}
          <Animated.Text 
            style={[
              styles.timeText, 
              { 
                fontSize,
                transform: [{ scale: scaleAnim }]
              }
            ]}
          >
            {formatTime(timeLeft)}
          </Animated.Text>
        </View>
      </BlurView>
    </Animated.View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  integratedContainer: {
    alignSelf: 'stretch',
    borderRadius: 12,
    backgroundColor: 'rgba(255,255,255,0.04)',
    borderWidth: 1,
    borderColor: 'rgba(148,163,184,0.15)',
    paddingVertical: 12,
    paddingHorizontal: 16,
  },
  integratedInner: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  integratedTimeText: {
    color: '#E5E7EB',
    fontWeight: '600',
    fontVariant: ['tabular-nums'],
  },
  blurContainer: {
    borderRadius: 18,
    overflow: 'hidden',
    borderWidth: 1,
    paddingHorizontal: 24,
    paddingVertical: 16,
    minWidth: 140,
    elevation: 8,
    shadowColor: '#60A5FA',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 12,
  },
  border: {
    ...StyleSheet.absoluteFillObject,
    borderRadius: 18,
    borderWidth: 1,
  },
  content: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
  },
  icon: {
    marginRight: 4,
  },
  timeText: {
    color: '#F9FAFB',
    fontWeight: 'bold',
    fontVariant: ['tabular-nums'],
  },
});

