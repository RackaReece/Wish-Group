import React, { useEffect, useRef } from 'react';
import { View, StyleSheet, Animated } from 'react-native';

// Dot positions as % of parent (so they sit around the map edges)
const DOT_POSITIONS: { left: number; top: number }[] = [
  { left: 0.08, top: 0.22 },
  { left: 0.85, top: 0.18 },
  { left: 0.12, top: 0.65 },
  { left: 0.78, top: 0.58 },
  { left: 0.25, top: 0.12 },
  { left: 0.7, top: 0.42 },
  { left: 0.05, top: 0.48 },
  { left: 0.92, top: 0.72 },
  { left: 0.4, top: 0.85 },
  { left: 0.55, top: 0.28 },
];

const DOT_SIZE = 6;
const PULSE_DURATION = 1800;

export default function PulsingMapDots() {
  const anims = useRef(DOT_POSITIONS.map(() => new Animated.Value(0.4))).current;

  useEffect(() => {
    const loops = anims.map((anim, i) => {
      const delay = (i * 120) % 800;
      const seq = Animated.loop(
        Animated.sequence([
          Animated.delay(delay),
          Animated.timing(anim, {
            toValue: 1,
            duration: PULSE_DURATION / 2,
            useNativeDriver: true,
          }),
          Animated.timing(anim, {
            toValue: 0.35,
            duration: PULSE_DURATION / 2,
            useNativeDriver: true,
          }),
        ])
      );
      seq.start();
      return seq;
    });
    return () => loops.forEach((l) => l.stop());
  }, []);

  return (
    <View style={styles.container} pointerEvents="none">
      {DOT_POSITIONS.map((pos, i) => (
        <Animated.View
          key={i}
          style={[
            styles.dot,
            {
              left: `${pos.left * 100}%`,
              top: `${pos.top * 100}%`,
              marginLeft: -DOT_SIZE / 2,
              marginTop: -DOT_SIZE / 2,
              opacity: anims[i],
              transform: [
                {
                  scale: anims[i].interpolate({
                    inputRange: [0.35, 1],
                    outputRange: [0.8, 1.3],
                  }),
                },
              ],
            },
          ]}
        />
      ))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    ...StyleSheet.absoluteFillObject,
    zIndex: 1,
  },
  dot: {
    position: 'absolute',
    width: DOT_SIZE,
    height: DOT_SIZE,
    borderRadius: DOT_SIZE / 2,
    backgroundColor: 'rgba(91, 143, 168, 0.9)',
    borderWidth: 1,
    borderColor: 'rgba(135, 206, 235, 0.5)',
  },
});
