import React, { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  Animated,
  Easing,
  Image,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { customerTheme } from '../constants/customerTheme';
import { colors } from '../constants/colors';
import { APP_LOGO_SOURCE } from '../constants/appAssets';
import { SHADOWS } from '../constants/designTokens';

const LOGO_SIZE = 160;
const LOGO_BORDER_RADIUS = 32;
const SKY = colors.SKY;

interface LoadingScreenProps {
  /** 0–1 progress for boot loading bar. When provided, shows a progress bar below the logo. */
  progress?: number;
}

export default function LoadingScreen({ progress }: Readonly<LoadingScreenProps>) {
  const pulseAnim = useRef(new Animated.Value(1)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.08,
          duration: 2000,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 2000,
          easing: Easing.inOut(Easing.ease),
          useNativeDriver: true,
        }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [pulseAnim]);

  return (
    <View style={styles.container}>
      {/* Same background as dashboard */}
      <LinearGradient
        colors={customerTheme.backgroundGradient}
        style={StyleSheet.absoluteFill}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
      />

      <View style={styles.content}>
        {/* Rounded square logo (same as splash/auth) with pulse zoom */}
        <Animated.View
          style={[
            styles.logoWrapper,
            { transform: [{ scale: pulseAnim }] },
          ]}
        >
          <View style={styles.logoInner}>
            <Image
              source={APP_LOGO_SOURCE}
              style={styles.logoImage}
              resizeMode="contain"
            />
          </View>
        </Animated.View>

        <View style={styles.brandContainer}>
          <Text style={styles.brandTitle}>Wish a Wash</Text>
          <Text style={styles.brandSubtitle}>Your Wish, Our Wash</Text>
        </View>

        {/* Progress bar for boot loading */}
        {progress != null && (
          <View style={styles.progressBarContainer}>
            <View style={styles.progressBarTrack}>
              <LinearGradient
                colors={[SKY, colors.LIGHT_SKY ?? SKY]}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 0 }}
                style={[styles.progressBarFill, { width: `${Math.min(100, Math.max(0, progress * 100))}%` }]}
              />
            </View>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    overflow: 'hidden',
  },
  content: {
    alignItems: 'center',
    justifyContent: 'center',
    flex: 1,
  },
  logoWrapper: {
    width: LOGO_SIZE,
    height: LOGO_SIZE,
    borderRadius: LOGO_BORDER_RADIUS,
    backgroundColor: colors.surfaceOverlayMid,
    overflow: 'hidden',
    ...SHADOWS.xl,
    shadowOffset: { width: 0, height: 6 },
    shadowRadius: 14,
    borderWidth: 2,
    borderColor: colors.borderLight,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  logoInner: {
    width: LOGO_SIZE,
    height: LOGO_SIZE,
    borderRadius: LOGO_BORDER_RADIUS,
    overflow: 'hidden',
  },
  logoImage: {
    width: LOGO_SIZE,
    height: LOGO_SIZE,
    borderRadius: LOGO_BORDER_RADIUS,
  },
  brandContainer: {
    alignItems: 'center',
  },
  brandTitle: {
    fontSize: 28,
    fontWeight: '800',
    color: colors.LIGHT_SKY,
    marginBottom: 6,
    textShadowColor: 'rgba(135, 206, 235, 0.5)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 8,
    letterSpacing: 1,
  },
  brandSubtitle: {
    fontSize: 15,
    color: SKY,
    textAlign: 'center',
    fontWeight: '600',
    letterSpacing: 0.3,
    opacity: 0.92,
  },
  progressBarContainer: {
    width: '70%',
    maxWidth: 240,
    marginTop: 28,
  },
  progressBarTrack: {
    height: 4,
    borderRadius: 2,
    backgroundColor: colors.surfaceOverlayStrong,
    overflow: 'hidden',
  },
  progressBarFill: {
    height: '100%',
    borderRadius: 2,
  },
});
