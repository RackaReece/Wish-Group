import { customerTheme } from './customerTheme';
import { colors } from './colors';

export type AccountType = 'customer' | 'valeter' | 'business';

export interface AccountTheme {
  primary: string;
  primaryAlt: string;
  background: [string, string];
  headerBackground?: [string, string]; // Optional header-specific background to match nav tabs
  glassBorder: string;
  glassBorderAlt?: string;
  accent: string;
  accentAlt: string;
}

export const accountThemes: Record<AccountType, AccountTheme> = {
  customer: {
    primary: '#7EB8D4', // Toned-down sky blue
    primaryAlt: '#6B9AAA',
    background: customerTheme.backgroundGradient,
    headerBackground: ['rgba(126,184,212,0.28)', 'rgba(126,184,212,0.16)'],
    glassBorder: 'rgba(148,163,184,0.4)',
    accent: '#7EB8D4',
    accentAlt: '#6B9AAA',
  },
  valeter: {
    primary: '#10B981',
    primaryAlt: '#F59E0B',
    background: ['#0A1929', '#1E3A8A'],
    glassBorder: 'rgba(16,185,129,0.35)',
    glassBorderAlt: 'rgba(245,158,11,0.35)',
    accent: '#10B981',
    accentAlt: '#F59E0B',
  },
  business: {
    primary: '#84CC16',
    primaryAlt: '#10B981',
    background: ['#0A1929', '#065F46'],
    glassBorder: 'rgba(132,204,22,0.35)',
    glassBorderAlt: 'rgba(16,185,129,0.35)',
    accent: '#84CC16',
    accentAlt: '#10B981',
  },
};

export const getAccountTheme = (accountType: AccountType): AccountTheme => {
  return accountThemes[accountType];
};

