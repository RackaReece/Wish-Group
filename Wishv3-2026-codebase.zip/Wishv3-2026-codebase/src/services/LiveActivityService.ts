/**
 * iOS Live Activity / Dynamic Island integration.
 * Start, update, and end a Live Activity from tracking/waiting screens.
 * No-op on Android and web; requires native build (no Expo Go).
 */

import { Platform } from 'react-native';

let widgetModule: {
  areActivitiesEnabled: () => boolean;
  startActivity: (a: string, b: string, c: string, d: string, e: string) => void;
  updateActivity: (a: string, b: string, c: string, d: string, e: string) => void;
  endActivity: () => void;
} | null = null;

if (Platform.OS === 'ios') {
  try {
    widgetModule = require('react-native-widget-extension');
  } catch {
    // Native module not linked (e.g. Expo Go)
  }
}

export const areActivitiesEnabled = (): boolean => {
  if (Platform.OS !== 'ios' || !widgetModule) return false;
  try {
    return widgetModule.areActivitiesEnabled();
  } catch {
    return false;
  }
};

/**
 * Start or update the Live Activity (Dynamic Island + Lock Screen).
 * bookingId, status, statusLabel, serviceName, locationName
 */
export const startLiveActivity = (
  bookingId: string,
  status: string,
  statusLabel: string,
  serviceName: string,
  locationName: string
): void => {
  if (Platform.OS !== 'ios' || !widgetModule) return;
  try {
    widgetModule.startActivity(bookingId, status, statusLabel, serviceName, locationName);
  } catch (e) {
    if (__DEV__) console.warn('[LiveActivity] startActivity failed', e);
  }
};

/**
 * Update the current Live Activity content.
 */
export const updateLiveActivity = (
  bookingId: string,
  status: string,
  statusLabel: string,
  serviceName: string,
  locationName: string
): void => {
  if (Platform.OS !== 'ios' || !widgetModule) return;
  try {
    widgetModule.updateActivity(bookingId, status, statusLabel, serviceName, locationName);
  } catch (e) {
    if (__DEV__) console.warn('[LiveActivity] updateActivity failed', e);
  }
};

/**
 * End the Live Activity (e.g. when booking completes or user leaves tracking).
 */
export const endLiveActivity = (): void => {
  if (Platform.OS !== 'ios' || !widgetModule) return;
  try {
    widgetModule.endActivity();
  } catch (e) {
    if (__DEV__) console.warn('[LiveActivity] endActivity failed', e);
  }
};
