// Video requires - outside app/ so Expo Router doesn't treat as route
module.exports = {
  onboardingVideo: require('../assets/onboarding.mp4'),
};
