import React from 'react';
import { motion } from 'framer-motion';

interface ToggleSwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  disabled?: boolean;
}

export const ToggleSwitch: React.FC<ToggleSwitchProps> = ({
  checked,
  onChange,
  disabled = false
}) => {
  return (
    <button
      onClick={() => !disabled && onChange(!checked)}
      disabled={disabled}
      className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-primary-accent/50 focus:ring-offset-2 focus:ring-offset-primary-bg ${
        checked
          ? 'bg-primary-accent'
          : 'bg-white/20'
      } ${disabled ? 'opacity-50 cursor-not-allowed' : 'cursor-pointer'}`}
    >
      <motion.span
        animate={{
          x: checked ? 20 : 4,
          backgroundColor: checked ? '#EAF1FF' : '#EAF1FF'
        }}
        transition={{
          type: 'spring',
          stiffness: 500,
          damping: 30
        }}
        className={`inline-block h-4 w-4 transform rounded-full shadow-lg ${
          checked ? 'bg-white' : 'bg-white'
        }`}
      />
    </button>
  );
};
