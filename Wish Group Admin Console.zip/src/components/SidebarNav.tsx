import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { motion } from 'framer-motion';
import {
  IoSpeedometerOutline,
  IoPeopleOutline,
  IoDocumentTextOutline,
  IoStarOutline,
  IoAlertCircleOutline,
  IoCashOutline,
  IoAnalyticsOutline,
  IoDocumentOutline,
  IoMegaphoneOutline,
  IoRibbonOutline,
  IoSettingsOutline,
  IoArrowForwardOutline
} from 'react-icons/io5';

interface SidebarNavProps {
  collapsed: boolean;
  onToggle: () => void;
}

const navItems = [
  { path: '/', label: 'Dashboard', icon: <IoSpeedometerOutline /> },
  { path: '/pros-users', label: 'Pros & Users', icon: <IoPeopleOutline /> },
  { path: '/documents', label: 'Documents', icon: <IoDocumentTextOutline /> },
  { path: '/reviews', label: 'Reviews', icon: <IoStarOutline /> },
  { path: '/disputes', label: 'Disputes', icon: <IoAlertCircleOutline /> },
  { path: '/revenue', label: 'Revenue & Fees', icon: <IoCashOutline /> },
  { path: '/analytics', label: 'Analytics', icon: <IoAnalyticsOutline /> },
  { path: '/reports', label: 'Reports', icon: <IoDocumentOutline /> },
  { path: '/broadcasts', label: 'Broadcasts', icon: <IoMegaphoneOutline /> },
  { path: '/promotions', label: 'Promotions', icon: <IoRibbonOutline /> },
  { path: '/settings', label: 'Settings', icon: <IoSettingsOutline /> },
];

export const SidebarNav: React.FC<SidebarNavProps> = ({ collapsed, onToggle }) => {
  const location = useLocation();

  return (
    <motion.aside
      initial={false}
      animate={{ width: collapsed ? 80 : 280 }}
      transition={{ duration: 0.3, ease: 'easeInOut' }}
      className="glass-card sidebar-glow h-screen flex flex-col"
    >
      {/* Logo */}
      <div className="p-6 border-b border-white/10">
        <motion.div
          animate={{ scale: collapsed ? 0.8 : 1 }}
          className="flex items-center space-x-3"
        >
          <div className="w-10 h-10 bg-gradient-to-br from-primary-accent to-primary-accent-secondary rounded-lg flex items-center justify-center text-white font-bold text-lg">
            W
          </div>
          {!collapsed && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.1 }}
            >
              <h1 className="text-xl font-poppins font-semibold text-primary-text">
                Wish Group
              </h1>
              <p className="text-sm text-primary-text/70">Admin Console</p>
            </motion.div>
          )}
        </motion.div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 p-4 space-y-2">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center space-x-3 p-3 rounded-xl transition-all duration-200 ${
                isActive
                  ? 'bg-primary-accent/20 text-primary-accent border border-primary-accent/30'
                  : 'text-primary-text/70 hover:text-primary-text hover:bg-white/5'
              }`}
            >
              <span className="text-xl">{item.icon}</span>
              {!collapsed && (
                <motion.span
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.1 }}
                  className="font-medium"
                >
                  {item.label}
                </motion.span>
              )}
            </Link>
          );
        })}
      </nav>

      {/* Collapse Toggle */}
      <div className="p-4 border-t border-white/10">
        <button
          onClick={onToggle}
          className="w-full flex items-center justify-center p-3 rounded-xl text-primary-text/70 hover:text-primary-text hover:bg-white/5 transition-all duration-200"
        >
          <span className="text-xl">
            {collapsed ? <IoArrowForwardOutline /> : <IoArrowForwardOutline className="rotate-180" />}
          </span>
          {!collapsed && (
            <motion.span
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.1 }}
              className="ml-3 font-medium"
            >
              Collapse
            </motion.span>
          )}
        </button>
      </div>
    </motion.aside>
  );
};
