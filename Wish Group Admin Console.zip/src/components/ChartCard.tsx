import React from 'react';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { GlassCard } from './GlassCard';
import { IoBarChartOutline } from 'react-icons/io5';

interface ChartCardProps {
  title: string;
  type: 'line' | 'bar' | 'pie';
  data: any[];
  color?: string;
}

export const ChartCard: React.FC<ChartCardProps> = ({
  title,
  type,
  data,
  color = '#0A84FF'
}) => {
  const renderChart = () => {
    if (!data || data.length === 0) {
      return (
        <div className="w-full h-72 flex items-center justify-center text-primary-text/60">
          <div className="flex flex-col items-center">
            <IoBarChartOutline className="text-3xl mb-2" />
            <span className="text-sm">No data available</span>
          </div>
        </div>
      );
    }
    switch (type) {
      case 'line':
        return (
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis 
                dataKey="name" 
                stroke="rgba(234,241,255,0.7)"
                fontSize={12}
              />
              <YAxis 
                stroke="rgba(234,241,255,0.7)"
                fontSize={12}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(6,18,41,0.9)',
                  border: '1px solid rgba(10,132,255,0.3)',
                  borderRadius: '8px',
                  color: '#EAF1FF'
                }}
              />
              <Line
                type="monotone"
                dataKey="value"
                stroke={color}
                strokeWidth={2}
                dot={{ fill: color, strokeWidth: 2, r: 4 }}
                activeDot={{ r: 6, stroke: color, strokeWidth: 2 }}
              />
            </LineChart>
          </ResponsiveContainer>
        );
      
      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={data}>
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis 
                dataKey="name" 
                stroke="rgba(234,241,255,0.7)"
                fontSize={12}
              />
              <YAxis 
                stroke="rgba(234,241,255,0.7)"
                fontSize={12}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(6,18,41,0.9)',
                  border: '1px solid rgba(10,132,255,0.3)',
                  borderRadius: '8px',
                  color: '#EAF1FF'
                }}
              />
              <Bar dataKey="value" fill={color} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        );
      
      case 'pie':
        return (
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie
                data={data}
                cx="50%"
                cy="50%"
                labelLine={false}
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                outerRadius={80}
                fill="#8884d8"
                dataKey="value"
              >
                {data.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.color || color} />
                ))}
              </Pie>
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(6,18,41,0.9)',
                  border: '1px solid rgba(10,132,255,0.3)',
                  borderRadius: '8px',
                  color: '#EAF1FF'
                }}
              />
            </PieChart>
          </ResponsiveContainer>
        );
      
      default:
        return null;
    }
  };

  return (
    <GlassCard>
      <h3 className="text-xl font-poppins font-semibold text-primary-text mb-4">
        {title}
      </h3>
      <div className="h-80">
        {renderChart()}
      </div>
    </GlassCard>
  );
};
