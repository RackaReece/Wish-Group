import React from 'react';
import { motion } from 'framer-motion';

interface PageHeaderProps {
  title: string;
  description?: string;
  actionButton?: React.ReactNode;
}

export const PageHeader: React.FC<PageHeaderProps> = ({ title, description, actionButton }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: -20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0"
    >
      <div>
        <h1 className="text-3xl font-poppins font-bold text-primary-text mb-2">
          {title}
        </h1>
        {description && (
          <p className="text-primary-text/70">{description}</p>
        )}
      </div>
      {actionButton && <div>{actionButton}</div>}
    </motion.div>
  );
};

