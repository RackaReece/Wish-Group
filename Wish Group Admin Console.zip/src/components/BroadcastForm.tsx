import React, { useState } from 'react';
import { IoMegaphoneOutline, IoTimeOutline, IoFlashOutline, IoPeopleOutline, IoConstructOutline, IoPersonOutline, IoPhonePortraitOutline } from 'react-icons/io5';

interface BroadcastFormProps {
  onSubmit: (data: any) => void;
  onCancel: () => void;
}

export const BroadcastForm: React.FC<BroadcastFormProps> = ({ onSubmit, onCancel }) => {
  const [formData, setFormData] = useState({
    title: '',
    message: '',
    audience: 'all',
    app: 'all',
    scheduleType: 'immediate',
    scheduledDate: '',
    scheduledTime: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit(formData);
  };

  const audienceOptions = [
    { value: 'all', label: 'All Users', icon: <IoPeopleOutline /> },
    { value: 'pros', label: 'Pros Only', icon: <IoConstructOutline /> },
    { value: 'customers', label: 'Customers Only', icon: <IoPersonOutline /> },
    { value: 'app', label: 'By App', icon: <IoPhonePortraitOutline /> }
  ];

  const appOptions = [
    { value: 'all', label: 'All Apps' },
    { value: 'wash', label: 'Wash-a-Wash' },
    { value: 'pro', label: 'Wish-a-Pro' },
    { value: 'fix', label: 'Wish-a-Fix' }
  ];

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      {/* Title */}
      <div>
        <label className="block text-sm font-medium text-primary-text mb-2">
          Broadcast Title
        </label>
        <input
          type="text"
          name="title"
          value={formData.title}
          onChange={handleInputChange}
          placeholder="Enter broadcast title..."
          className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-primary-text placeholder-primary-text/50 focus:outline-none focus:border-primary-accent/50 focus:ring-2 focus:ring-primary-accent/20 transition-all duration-200"
          required
        />
      </div>

      {/* Message */}
      <div>
        <label className="block text-sm font-medium text-primary-text mb-2">
          Message Content
        </label>
        <textarea
          name="message"
          value={formData.message}
          onChange={handleInputChange}
          placeholder="Enter your message..."
          rows={6}
          className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-primary-text placeholder-primary-text/50 focus:outline-none focus:border-primary-accent/50 focus:ring-2 focus:ring-primary-accent/20 transition-all duration-200 resize-none"
          required
        />
      </div>

      {/* Audience Selection */}
      <div>
        <label className="block text-sm font-medium text-primary-text mb-3">
          Target Audience
        </label>
        <div className="grid grid-cols-2 gap-3">
          {audienceOptions.map((option) => (
            <button
              key={option.value}
              type="button"
              onClick={() => setFormData(prev => ({ ...prev, audience: option.value }))}
              className={`p-4 rounded-xl border transition-all duration-200 ${
                formData.audience === option.value
                  ? 'border-primary-accent bg-primary-accent/10 text-primary-accent'
                  : 'border-white/10 bg-white/5 text-primary-text hover:border-primary-accent/30'
              }`}
            >
              <div className="text-center">
                <div className="flex justify-center mb-2 text-2xl">{option.icon}</div>
                <div className="text-sm font-medium">{option.label}</div>
              </div>
            </button>
          ))}
        </div>
      </div>

      {/* App Selection (if audience is 'app') */}
      {formData.audience === 'app' && (
        <div>
          <label className="block text-sm font-medium text-primary-text mb-2">
            Select App
          </label>
          <select
            name="app"
            value={formData.app}
            onChange={handleInputChange}
            className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-primary-text focus:outline-none focus:border-primary-accent/50"
          >
            {appOptions.map((option) => (
              <option key={option.value} value={option.value}>
                {option.label}
              </option>
            ))}
          </select>
        </div>
      )}

      {/* Schedule Type */}
      <div>
        <label className="block text-sm font-medium text-primary-text mb-3">
          Schedule
        </label>
        <div className="grid grid-cols-2 gap-3">
          <button
            type="button"
            onClick={() => setFormData(prev => ({ ...prev, scheduleType: 'immediate' }))}
            className={`p-4 rounded-xl border transition-all duration-200 ${
              formData.scheduleType === 'immediate'
                ? 'border-primary-accent bg-primary-accent/10 text-primary-accent'
                : 'border-white/10 bg-white/5 text-primary-text hover:border-primary-accent/30'
            }`}
          >
            <div className="text-center">
              <div className="text-2xl mb-2"><IoFlashOutline /></div>
              <div className="text-sm font-medium">Send Now</div>
            </div>
          </button>
          <button
            type="button"
            onClick={() => setFormData(prev => ({ ...prev, scheduleType: 'scheduled' }))}
            className={`p-4 rounded-xl border transition-all duration-200 ${
              formData.scheduleType === 'scheduled'
                ? 'border-primary-accent bg-primary-accent/10 text-primary-accent'
                : 'border-white/10 bg-white/5 text-primary-text hover:border-primary-accent/30'
            }`}
          >
            <div className="text-center">
              <div className="text-2xl mb-2"><IoTimeOutline /></div>
              <div className="text-sm font-medium">Schedule</div>
            </div>
          </button>
        </div>
      </div>

      {/* Scheduled Date/Time (if scheduled) */}
      {formData.scheduleType === 'scheduled' && (
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">
              Date
            </label>
            <input
              type="date"
              name="scheduledDate"
              value={formData.scheduledDate}
              onChange={handleInputChange}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-primary-text focus:outline-none focus:border-primary-accent/50"
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">
              Time
            </label>
            <input
              type="time"
              name="scheduledTime"
              value={formData.scheduledTime}
              onChange={handleInputChange}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-primary-text focus:outline-none focus:border-primary-accent/50"
              required
            />
          </div>
        </div>
      )}

      {/* Preview */}
      <div>
        <label className="block text-sm font-medium text-primary-text mb-2">
          Preview
        </label>
        <div className="bg-white/5 p-4 rounded-xl border border-white/10">
          <div className="space-y-2">
            <h4 className="text-sm font-semibold text-primary-text">{formData.title || 'Broadcast Title'}</h4>
            <p className="text-sm text-primary-text/80">
              {formData.message || 'Your message content will appear here...'}
            </p>
            <div className="text-xs text-primary-text/50 pt-2 border-t border-white/10">
              To: {audienceOptions.find(opt => opt.value === formData.audience)?.label}
              {formData.audience === 'app' && ` - ${appOptions.find(opt => opt.value === formData.app)?.label}`}
            </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex justify-end space-x-4 pt-6 border-t border-white/10">
        <button
          type="button"
          onClick={onCancel}
          className="px-6 py-2 bg-white/5 text-primary-text rounded-xl hover:bg-white/10 transition-colors"
        >
          Cancel
        </button>
        <button
          type="submit"
          className="glow-button px-6 py-2 text-sm font-semibold"
        >
          <IoMegaphoneOutline /> {formData.scheduleType === 'immediate' ? 'Send Broadcast' : 'Schedule Broadcast'}
        </button>
      </div>
    </form>
  );
};
