import React from 'react';
import { motion } from 'framer-motion';

interface FeeControlProps {
  app: string;
  currentFee: number;
  onFeeChange: (fee: number) => void;
  description: string;
}

export const FeeControl: React.FC<FeeControlProps> = ({
  app,
  currentFee,
  onFeeChange,
  description
}) => {
  const handleSliderChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    onFeeChange(parseInt(e.target.value));
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseInt(e.target.value);
    if (!isNaN(value) && value >= 0 && value <= 50) {
      onFeeChange(value);
    }
  };

  const getFeeColor = (fee: number) => {
    if (fee <= 10) return 'text-success';
    if (fee <= 20) return 'text-yellow-500';
    return 'text-danger';
  };

  const getFeeBg = (fee: number) => {
    if (fee <= 10) return 'bg-success/20';
    if (fee <= 20) return 'bg-yellow-500/20';
    return 'bg-danger/20';
  };

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="p-6 bg-white/5 rounded-xl border border-white/10 hover:border-primary-accent/30 transition-all duration-200"
    >
      <div className="space-y-4">
        {/* App Header */}
        <div className="text-center">
          <h4 className="text-lg font-semibold text-primary-text mb-1">{app}</h4>
          <p className="text-xs text-primary-text/70">{description}</p>
        </div>

        {/* Current Fee Display */}
        <div className="text-center">
          <div className={`inline-flex items-center px-4 py-2 rounded-full text-2xl font-bold ${getFeeBg(currentFee)} ${getFeeColor(currentFee)}`}>
            {currentFee}%
          </div>
        </div>

        {/* Fee Slider */}
        <div className="space-y-3">
          <input
            type="range"
            min="0"
            max="50"
            value={currentFee}
            onChange={handleSliderChange}
            className="w-full h-2 bg-white/10 rounded-lg appearance-none cursor-pointer slider"
            style={{
              background: `linear-gradient(to right, #0A84FF 0%, #0A84FF ${(currentFee / 50) * 100}%, rgba(255,255,255,0.1) ${(currentFee / 50) * 100}%, rgba(255,255,255,0.1) 100%)`
            }}
          />
          
          <div className="flex justify-between text-xs text-primary-text/70">
            <span>0%</span>
            <span>25%</span>
            <span>50%</span>
          </div>
        </div>

        {/* Manual Input */}
        <div className="flex items-center space-x-2">
          <label className="text-sm text-primary-text/70">Manual:</label>
          <input
            type="number"
            min="0"
            max="50"
            value={currentFee}
            onChange={handleInputChange}
            className="w-20 px-2 py-1 bg-white/5 border border-white/10 rounded text-primary-text text-sm focus:outline-none focus:border-primary-accent/50"
          />
          <span className="text-sm text-primary-text/70">%</span>
        </div>

        {/* Fee Impact Info */}
        <div className="text-center">
          <p className="text-xs text-primary-text/70">
            Platform earns £{(1000 * currentFee / 100).toFixed(0)} per £1000 in bookings
          </p>
        </div>
      </div>

      <style>{`
        .slider::-webkit-slider-thumb {
          appearance: none;
          height: 20px;
          width: 20px;
          border-radius: 50%;
          background: #0A84FF;
          cursor: pointer;
          border: 2px solid #061229;
          box-shadow: 0 0 10px rgba(10, 132, 255, 0.3);
        }

        .slider::-moz-range-thumb {
          height: 20px;
          width: 20px;
          border-radius: 50%;
          background: #0A84FF;
          cursor: pointer;
          border: 2px solid #061229;
          box-shadow: 0 0 10px rgba(10, 132, 255, 0.3);
        }
      `}</style>
    </motion.div>
  );
};
