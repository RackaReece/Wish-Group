import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { IoMenuOutline, IoSearchOutline, IoNotificationsOutline, IoMegaphoneOutline, IoPersonCircleOutline, IoLogOutOutline } from 'react-icons/io5';

interface HeaderBarProps {
  onMenuToggle: () => void;
  onLogout: () => void;
}

export const HeaderBar: React.FC<HeaderBarProps> = ({ onMenuToggle, onLogout }) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [showLogoutMenu, setShowLogoutMenu] = useState(false);

  return (
    <header className="glass-card border-b border-white/10 p-4">
      <div className="flex items-center justify-between">
        {/* Left Section */}
        <div className="flex items-center space-x-4">
          <button
            onClick={onMenuToggle}
            className="p-2 rounded-lg text-primary-text/70 hover:text-primary-text hover:bg-white/5 transition-all duration-200"
          >
            <span className="text-xl"><IoMenuOutline /></span>
          </button>
          
          {/* Search Bar */}
          <div className="relative">
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-80 px-4 py-2 pl-10 bg-white/5 border border-white/10 rounded-xl text-primary-text placeholder-primary-text/50 focus:outline-none focus:border-primary-accent/50 focus:ring-2 focus:ring-primary-accent/20 transition-all duration-200"
            />
            <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-primary-text/50">
              <IoSearchOutline />
            </span>
          </div>
        </div>

        {/* Right Section */}
        <div className="flex items-center space-x-4">
          {/* Broadcast Button */}
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => {}}
            className="glow-button px-6 py-2 text-sm font-semibold"
          >
            <span className="inline-flex items-center space-x-2">
              <IoMegaphoneOutline />
              <span>Broadcast</span>
            </span>
          </motion.button>

          {/* Notifications */}
          <div className="relative">
            <button className="p-2 rounded-lg text-primary-text/70 hover:text-primary-text hover:bg-white/5 transition-all duration-200">
              <span className="text-xl"><IoNotificationsOutline /></span>
            </button>
          </div>

          {/* Admin Avatar with Logout */}
          <div className="relative">
            <div 
              className="flex items-center space-x-3 cursor-pointer hover:opacity-80 transition-opacity"
              onClick={() => setShowLogoutMenu(!showLogoutMenu)}
            >
            <div className="w-10 h-10 rounded-full overflow-hidden text-white">
              <IoPersonCircleOutline className="w-10 h-10 text-primary-accent" />
            </div>
            <div className="text-sm">
              <p className="text-primary-text font-medium">Admin User</p>
              <p className="text-primary-text/50 text-xs">Super Admin</p>
            </div>
            </div>
            
            {/* Logout Dropdown */}
            {showLogoutMenu && (
              <>
                {/* Click outside to close */}
                <div 
                  className="fixed inset-0 z-40"
                  onClick={() => setShowLogoutMenu(false)}
                />
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="absolute right-0 top-full mt-2 w-48 glass-card border border-white/10 rounded-xl overflow-hidden z-50"
                >
                  <button
                    onClick={onLogout}
                    className="w-full px-4 py-3 flex items-center space-x-3 hover:bg-white/10 transition-colors text-left"
                  >
                    <IoLogOutOutline className="text-xl text-danger" />
                    <span className="text-sm text-primary-text">Log Out</span>
                  </button>
                </motion.div>
              </>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
