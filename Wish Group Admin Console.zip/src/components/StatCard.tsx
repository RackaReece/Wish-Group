import React from 'react';
import { motion } from 'framer-motion';
import { GlassCard } from './GlassCard';
import { IoTrendingUpOutline, IoTrendingDownOutline, IoRemoveOutline } from 'react-icons/io5';

interface StatCardProps {
  title: string;
  value: string | number;
  change?: string;
  changeType?: 'positive' | 'negative' | 'neutral';
  icon?: React.ReactNode;
  trend?: 'up' | 'down' | 'stable';
}

export const StatCard: React.FC<StatCardProps> = ({
  title,
  value,
  change,
  changeType = 'neutral',
  icon,
  trend
}) => {
  const getChangeColor = () => {
    switch (changeType) {
      case 'positive':
        return 'text-success';
      case 'negative':
        return 'text-danger';
      default:
        return 'text-primary-text/70';
    }
  };

  const getTrendIcon = () => {
    switch (trend) {
      case 'up':
        return <IoTrendingUpOutline />;
      case 'down':
        return <IoTrendingDownOutline />;
      default:
        return <IoRemoveOutline />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <GlassCard>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <p className="text-primary-text/70 text-sm font-medium mb-2">{title}</p>
            <p className="text-3xl font-bold text-primary-text mb-2">{value}</p>
            {change && (
              <div className="flex items-center space-x-1">
                <span className={`text-sm font-medium ${getChangeColor()}`}>
                  {change}
                </span>
                {trend && (
                  <span className="text-sm">{getTrendIcon()}</span>
                )}
              </div>
            )}
          </div>
          {icon && (
            <div className="text-3xl opacity-60">
              {icon}
            </div>
          )}
        </div>
      </GlassCard>
    </motion.div>
  );
};
