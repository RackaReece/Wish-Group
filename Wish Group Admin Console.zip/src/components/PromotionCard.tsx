import React from 'react';
import { motion } from 'framer-motion';
import { IoRibbonOutline, IoGiftOutline, IoPeopleOutline, IoCashOutline, IoCheckmarkCircleOutline, IoAnalyticsOutline, IoTrashOutline, IoPauseOutline, IoPlayOutline, IoEyeOutline } from 'react-icons/io5';

interface PromotionCardProps {
  promotion: {
    id: string;
    name: string;
    type: string;
    app: string;
    discountPercent: number;
    startDate: string;
    endDate: string;
    status: string;
    usageCount: number;
    maxUsage: number;
    description: string;
  };
  onView: () => void;
  onToggle: () => void;
  onDelete: () => void;
}

export const PromotionCard: React.FC<PromotionCardProps> = ({
  promotion,
  onView,
  onToggle,
  onDelete
}) => {
  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active':
        return 'text-success';
      case 'Scheduled':
        return 'text-yellow-500';
      case 'Expired':
        return 'text-gray-500';
      case 'Paused':
        return 'text-danger';
      default:
        return 'text-primary-text/70';
    }
  };

  const getStatusBg = (status: string) => {
    switch (status) {
      case 'Active':
        return 'bg-success/20';
      case 'Scheduled':
        return 'bg-yellow-500/20';
      case 'Expired':
        return 'bg-gray-500/20';
      case 'Paused':
        return 'bg-danger/20';
      default:
        return 'bg-gray-500/20';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'Discount':
        return <IoCashOutline />;
      case 'Reward':
        return <IoGiftOutline />;
      case 'Referral':
        return <IoPeopleOutline />;
      default:
        return <IoRibbonOutline />;
    }
  };

  const getAppColor = (app: string) => {
    switch (app) {
      case 'Wash-a-Wash':
        return 'text-blue-400';
      case 'Wish-a-Pro':
        return 'text-cyan-400';
      case 'Wish-a-Fix':
        return 'text-green-400';
      default:
        return 'text-primary-text';
    }
  };

  const usagePercentage = (promotion.usageCount / promotion.maxUsage) * 100;

  return (
    <motion.div
      whileHover={{ scale: 1.02 }}
      className="glass-card p-6 hover:border-primary-accent/30 transition-all duration-200"
    >
      <div className="space-y-4">
        {/* Header */}
        <div className="flex items-start justify-between">
          <div className="flex items-center space-x-3">
            <div className="text-2xl">{getTypeIcon(promotion.type)}</div>
            <div>
              <h3 className="text-sm font-semibold text-primary-text">{promotion.name}</h3>
              <p className={`text-xs ${getAppColor(promotion.app)}`}>{promotion.app}</p>
            </div>
          </div>
          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusBg(promotion.status)} ${getStatusColor(promotion.status)}`}>
            {promotion.status}
          </span>
        </div>

        {/* Discount Info */}
        {promotion.discountPercent > 0 && (
          <div className="text-center">
            <div className="text-2xl font-bold text-primary-accent">
              {promotion.discountPercent}% OFF
            </div>
            <p className="text-xs text-primary-text/70">Discount</p>
          </div>
        )}

        {/* Description */}
        <p className="text-xs text-primary-text/70 line-clamp-2">
          {promotion.description}
        </p>

        {/* Usage Progress */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs text-primary-text/70">
            <span>Usage</span>
            <span>{promotion.usageCount.toLocaleString()} / {promotion.maxUsage.toLocaleString()}</span>
          </div>
          <div className="w-full bg-white/10 rounded-full h-2">
            <motion.div
              initial={{ width: 0 }}
              animate={{ width: `${Math.min(usagePercentage, 100)}%` }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className={`h-2 rounded-full ${
                usagePercentage > 80 ? 'bg-danger' :
                usagePercentage > 60 ? 'bg-yellow-500' :
                'bg-success'
              }`}
            />
          </div>
        </div>

        {/* Dates */}
        <div className="text-xs text-primary-text/70">
          <div>Start: {promotion.startDate}</div>
          <div>End: {promotion.endDate}</div>
        </div>

        {/* Actions */}
        <div className="flex items-center justify-between pt-2 border-t border-white/10">
          <button
            onClick={onView}
            className="text-xs text-primary-accent hover:text-primary-text transition-colors"
          >
            View Details
          </button>
          <div className="flex space-x-2">
            <button
              onClick={onToggle}
              className={`p-1 rounded transition-colors ${
                promotion.status === 'Active'
                  ? 'text-danger hover:bg-danger/20'
                  : 'text-success hover:bg-success/20'
              }`}
              title={promotion.status === 'Active' ? 'Pause' : 'Activate'}
            >
              {promotion.status === 'Active' ? <IoPauseOutline /> : <IoPlayOutline />}
            </button>
            <button
              onClick={onDelete}
              className="p-1 text-gray-500 hover:bg-gray-500/20 rounded transition-colors"
              title="Delete"
            >
              <IoTrashOutline />
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
};
