declare module 'react-icons/io5' {
  import React from 'react';
  
  export interface IconBaseProps extends React.SVGAttributes<SVGElement> {
    children?: React.ReactNode;
    size?: string | number;
    color?: string;
    title?: string;
  }
  
  export type IconComponent = (props: IconBaseProps) => React.JSX.Element;
  
  export const IoBarChartOutline: IconComponent;
  export const IoMenuOutline: IconComponent;
  export const IoSearchOutline: IconComponent;
  export const IoMegaphoneOutline: IconComponent;
  export const IoNotificationsOutline: IconComponent;
  export const IoPersonCircleOutline: IconComponent;
  export const IoSpeedometerOutline: IconComponent;
  export const IoPeopleOutline: IconComponent;
  export const IoDocumentTextOutline: IconComponent;
  export const IoStarOutline: IconComponent;
  export const IoAlertCircleOutline: IconComponent;
  export const IoCashOutline: IconComponent;
  export const IoAnalyticsOutline: IconComponent;
  export const IoDocumentOutline: IconComponent;
  export const IoRibbonOutline: IconComponent;
  export const IoSettingsOutline: IconComponent;
  export const IoTrendingUpOutline: IconComponent;
  export const IoTrendingDownOutline: IconComponent;
  export const IoRemoveOutline: IconComponent;
  export const IoPersonOutline: IconComponent;
  export const IoConstructOutline: IconComponent;
  export const IoPhonePortraitOutline: IconComponent;
  export const IoTimeOutline: IconComponent;
  export const IoFlashOutline: IconComponent;
  export const IoGiftOutline: IconComponent;
  export const IoCheckmarkCircleOutline: IconComponent;
  export const IoTrashOutline: IconComponent;
  export const IoPauseOutline: IconComponent;
  export const IoPlayOutline: IconComponent;
  export const IoEyeOutline: IconComponent;
  export const IoArrowForwardOutline: IconComponent;
  export const IoCopyOutline: IconComponent;
  export const IoCloseOutline: IconComponent;
  export const IoAddOutline: IconComponent;
  export const IoDocumentOutline: IconComponent;
  export const IoServerOutline: IconComponent;
  export const IoCalendarOutline: IconComponent;
  export const IoDownloadOutline: IconComponent;
  export const IoSaveOutline: IconComponent;
  export const IoFlagOutline: IconComponent;
  export const IoSwapVerticalOutline: IconComponent;
  export const IoArrowUpOutline: IconComponent;
  export const IoArrowDownOutline: IconComponent;
  export const IoLockClosedOutline: IconComponent;
  export const IoMailOutline: IconComponent;
  export const IoLogInOutline: IconComponent;
  export const IoLogOutOutline: IconComponent;
  export const IoShieldCheckmarkOutline: IconComponent;
  export const IoColorPaletteOutline: IconComponent;
  export const IoLanguageOutline: IconComponent;
  export const IoHeadsetOutline: IconComponent;
  export const IoKeyOutline: IconComponent;
  export const IoBuildOutline: IconComponent;
  export const IoVideocamOutline: IconComponent;
}
