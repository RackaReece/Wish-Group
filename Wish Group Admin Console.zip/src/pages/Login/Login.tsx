import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { GlassCard } from '../../components/GlassCard';
import { IoLockClosedOutline, IoMailOutline, IoLogInOutline } from 'react-icons/io5';

interface LoginProps {
  onLogin?: () => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin }) => {
  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Actual authentication will be implemented later
    if (onLogin) {
      onLogin();
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-primary-background via-primary-background to-primary-background-secondary p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5 }}
        className="w-full max-w-md"
      >
        <GlassCard className="p-8">
          {/* Logo */}
          <div className="text-center mb-8">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring" }}
              className="w-16 h-16 bg-gradient-to-br from-primary-accent to-primary-accent-secondary rounded-2xl flex items-center justify-center mx-auto mb-4"
            >
              <span className="text-white text-2xl font-bold">W</span>
            </motion.div>
            <h1 className="text-3xl font-poppins font-bold text-primary-text mb-2">
              Admin Console
            </h1>
            <p className="text-primary-text/70">
              Sign in to manage your Wish Group ecosystem
            </p>
          </div>

          {/* Login Form */}
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Email Input */}
            <div>
              <label className="block text-sm font-medium text-primary-text/70 mb-2">
                Email Address
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <IoMailOutline className="text-primary-text/50 text-xl" />
                </div>
                <input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="admin@wishgroup.com"
                  className="w-full pl-12 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-primary-text placeholder-primary-text/50 focus:outline-none focus:border-primary-accent/50 focus:ring-2 focus:ring-primary-accent/20 transition-all duration-200"
                  required
                />
              </div>
            </div>

            {/* Password Input */}
            <div>
              <label className="block text-sm font-medium text-primary-text/70 mb-2">
                Password
              </label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <IoLockClosedOutline className="text-primary-text/50 text-xl" />
                </div>
                <input
                  type="password"
                  name="password"
                  value={formData.password}
                  onChange={handleInputChange}
                  placeholder="Enter your password"
                  className="w-full pl-12 pr-4 py-3 bg-white/5 border border-white/10 rounded-xl text-primary-text placeholder-primary-text/50 focus:outline-none focus:border-primary-accent/50 focus:ring-2 focus:ring-primary-accent/20 transition-all duration-200"
                  required
                />
              </div>
            </div>

            {/* Remember Me & Forgot Password */}
            <div className="flex items-center justify-between text-sm">
              <label className="flex items-center space-x-2 cursor-pointer">
                <input
                  type="checkbox"
                  className="w-4 h-4 text-primary-accent bg-white/5 border-white/20 rounded focus:ring-primary-accent/50"
                />
                <span className="text-primary-text/70">Remember me</span>
              </label>
              <button type="button" className="text-primary-accent hover:text-primary-accent-secondary transition-colors">
                Forgot password?
              </button>
            </div>

            {/* Submit Button */}
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              type="submit"
              className="w-full glow-button py-3 text-base font-semibold"
            >
              <span className="flex items-center justify-center space-x-2">
                <IoLogInOutline className="text-xl" />
                <span>Sign In</span>
              </span>
            </motion.button>
          </form>

          {/* Footer */}
          <div className="mt-8 pt-6 border-t border-white/10 text-center">
            <p className="text-xs text-primary-text/50">
              © 2024 Wish Group Ltd. All rights reserved.
            </p>
          </div>
        </GlassCard>
      </motion.div>
    </div>
  );
};
