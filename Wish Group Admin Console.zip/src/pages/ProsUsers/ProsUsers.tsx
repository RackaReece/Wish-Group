import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Table } from '../../components/Table';
import { Modal } from '../../components/Modal';
import { GlassCard } from '../../components/GlassCard';
import { IoStarOutline, IoCheckmarkCircleOutline, IoConstructOutline, IoPeopleOutline, IoDocumentTextOutline } from 'react-icons/io5';

export const ProsUsers: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'pros' | 'customers'>('pros');
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filter, setFilter] = useState<'all' | 'pending' | 'active' | 'suspended' | 'rejected'>('all');

  const prosData: any[] = [];

  const customersData: any[] = [];

  const currentData = activeTab === 'pros' ? prosData : customersData;
  const filteredData = filter === 'all' 
    ? currentData 
    : currentData.filter(item => item.status.toLowerCase() === filter);

  const columns = [
    { key: 'name', label: 'Name', sortable: true },
    { key: 'role', label: 'Role', sortable: true },
    { key: 'city', label: 'City', sortable: true },
    { 
      key: 'rating', 
      label: 'Rating', 
      sortable: true,
      render: (value: number) => (
        <div className="flex items-center space-x-1">
          <span><IoStarOutline /></span>
          <span>{value}</span>
        </div>
      )
    },
    { 
      key: 'status', 
      label: 'Status', 
      sortable: true,
      render: (value: string) => (
        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
          value === 'Active' ? 'bg-success/20 text-success' :
          value === 'Pending' ? 'bg-yellow-500/20 text-yellow-500' :
          value === 'Suspended' ? 'bg-danger/20 text-danger' :
          'bg-gray-500/20 text-gray-500'
        }`}>
          {value}
        </span>
      )
    },
    { key: 'docs', label: 'Docs', sortable: true },
    { key: 'joinedDate', label: 'Joined', sortable: true }
  ];

  const handleRowClick = (row: any) => {
    setSelectedUser(row);
    setIsModalOpen(true);
  };

  const handleApprove = (id: number) => {
    // Action logged
  };

  const handleReject = (id: number) => {
    // Action logged
  };

  const handleRemove = (id: number) => {
    // Action logged
  };

  const actions = (row: any) => (
    <>
      <button
        onClick={(e) => {
          e.stopPropagation();
          handleApprove(row.id);
        }}
        className="px-3 py-1 bg-success/20 text-success rounded-lg text-xs hover:bg-success/30 transition-colors"
      >
        <IoCheckmarkCircleOutline /> Approve
      </button>
      <button
        onClick={(e) => {
          e.stopPropagation();
          handleReject(row.id);
        }}
        className="px-3 py-1 bg-danger/20 text-danger rounded-lg text-xs hover:bg-danger/30 transition-colors"
      >
        🚫 Decline
      </button>
      <button
        onClick={(e) => {
          e.stopPropagation();
          handleRemove(row.id);
        }}
        className="px-3 py-1 bg-gray-500/20 text-gray-500 rounded-lg text-xs hover:bg-gray-500/30 transition-colors"
      >
        🗑 Remove
      </button>
    </>
  );

  // const kpiData: any[] = [];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <h1 className="text-3xl font-poppins font-bold text-primary-text mb-2">
          Pros & Users Management
        </h1>
        <p className="text-primary-text/70">
          Manage valeters and customers across all Wish Group platforms.
        </p>
      </motion.div>

      {/* KPI Cards */}
      <GlassCard>
        <p className="text-primary-text/70 text-sm">No KPI data available</p>
      </GlassCard>

      {/* Tabs and Filters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
      >
        <GlassCard>
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            {/* Tabs */}
            <div className="flex space-x-1 bg-white/5 p-1 rounded-xl">
              <button
                onClick={() => setActiveTab('pros')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  activeTab === 'pros'
                    ? 'bg-primary-accent text-white'
                    : 'text-primary-text/70 hover:text-primary-text'
                }`}
              >
                <IoConstructOutline /> Pros ({prosData.length})
              </button>
              <button
                onClick={() => setActiveTab('customers')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 ${
                  activeTab === 'customers'
                    ? 'bg-primary-accent text-white'
                    : 'text-primary-text/70 hover:text-primary-text'
                }`}
              >
                <IoPeopleOutline /> Customers ({customersData.length})
              </button>
            </div>

            {/* Filters */}
            <div className="flex items-center space-x-4">
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value as any)}
                className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-primary-text focus:outline-none focus:border-primary-accent/50"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="active">Active</option>
                <option value="suspended">Suspended</option>
                <option value="rejected">Rejected</option>
              </select>
            </div>
          </div>
        </GlassCard>
      </motion.div>

      {/* Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.3 }}
      >
        <Table
          columns={columns}
          data={filteredData}
          onRowClick={handleRowClick}
          actions={actions}
        />
      </motion.div>

      {/* User Profile Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={`${selectedUser?.name} - Profile Details`}
        size="lg"
      >
        {selectedUser && (
          <div className="space-y-6">
            {/* Basic Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-lg font-semibold text-primary-text mb-4">Basic Information</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-primary-text/70">Name</label>
                    <p className="text-primary-text">{selectedUser.name}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Email</label>
                    <p className="text-primary-text">{selectedUser.email}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Phone</label>
                    <p className="text-primary-text">{selectedUser.phone}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">City</label>
                    <p className="text-primary-text">{selectedUser.city}</p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-lg font-semibold text-primary-text mb-4">Account Details</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-primary-text/70">Status</label>
                    <p className="text-primary-text">{selectedUser.status}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Joined Date</label>
                    <p className="text-primary-text">{selectedUser.joinedDate}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Completed Jobs</label>
                    <p className="text-primary-text">{selectedUser.completedJobs}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Rating</label>
                    <div className="flex items-center space-x-1">
                      <span><IoStarOutline /></span>
                      <span className="text-primary-text">{selectedUser.rating}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Documents (for pros only) */}
            {selectedUser.role === 'Valeter' && selectedUser.documents && (
              <div>
                <h4 className="text-lg font-semibold text-primary-text mb-4">Verification Documents</h4>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {selectedUser.documents.map((doc: any, index: number) => (
                    <div key={index} className="p-4 bg-white/5 rounded-xl border border-white/10">
                      <div className="text-center">
                        <div className="text-2xl mb-2"><IoDocumentTextOutline /></div>
                        <p className="text-sm font-medium text-primary-text">{doc.type}</p>
                        <p className={`text-xs ${
                          doc.status === 'Verified' ? 'text-success' :
                          doc.status === 'Pending' ? 'text-yellow-500' :
                          'text-danger'
                        }`}>
                          {doc.status}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex justify-end space-x-4 pt-6 border-t border-white/10">
              <button
                onClick={() => {
                  handleApprove(selectedUser.id);
                  setIsModalOpen(false);
                }}
                className="px-6 py-2 bg-success/20 text-success rounded-xl hover:bg-success/30 transition-colors"
              >
                <IoCheckmarkCircleOutline /> Approve
              </button>
              <button
                onClick={() => {
                  handleReject(selectedUser.id);
                  setIsModalOpen(false);
                }}
                className="px-6 py-2 bg-danger/20 text-danger rounded-xl hover:bg-danger/30 transition-colors"
              >
                🚫 Reject
              </button>
              <button
                onClick={() => {
                  handleRemove(selectedUser.id);
                  setIsModalOpen(false);
                }}
                className="px-6 py-2 bg-gray-500/20 text-gray-500 rounded-xl hover:bg-gray-500/30 transition-colors"
              >
                🗑 Remove
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
