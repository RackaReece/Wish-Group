import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { GlassCard } from '../../components/GlassCard';
import { Modal } from '../../components/Modal';
import { BroadcastForm } from '../../components/BroadcastForm';
import { IoMegaphoneOutline, IoCopyOutline, IoTrashOutline } from 'react-icons/io5';

export const Broadcasts: React.FC = () => {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  // const [selectedBroadcast, setSelectedBroadcast] = useState<any>(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);

  const broadcastsData: any[] = [];

  const handleCreateBroadcast = (broadcastData: any) => {
    // Action logged
    setIsCreateModalOpen(false);
  };

  // const handleViewBroadcast = (broadcast: any) => {
  //   setSelectedBroadcast(broadcast);
  //   setIsViewModalOpen(true);
  // };

  const handleDuplicateBroadcast = (broadcastId: string) => {
    // Action logged
  };

  const handleDeleteBroadcast = (broadcastId: string) => {
    // Action logged
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Sent':
        return 'text-success';
      case 'Scheduled':
        return 'text-yellow-500';
      case 'Failed':
        return 'text-danger';
      default:
        return 'text-primary-text/70';
    }
  };

  const getStatusBg = (status: string) => {
    switch (status) {
      case 'Sent':
        return 'bg-success/20';
      case 'Scheduled':
        return 'bg-yellow-500/20';
      case 'Failed':
        return 'bg-danger/20';
      default:
        return 'bg-gray-500/20';
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          <div>
            <h1 className="text-3xl font-poppins font-bold text-primary-text mb-2">
              Broadcast Center
            </h1>
            <p className="text-primary-text/70">
              Send announcements and updates to users across all Wish Group platforms.
            </p>
          </div>
          
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="glow-button px-6 py-2 text-sm font-semibold"
          >
            <IoMegaphoneOutline /> Create Broadcast
          </button>
        </div>
      </motion.div>

      {/* Broadcast Stats */}
      <GlassCard>
        <p className="text-primary-text/70 text-sm">No broadcast statistics available</p>
      </GlassCard>

      {/* Past Broadcasts */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
      >
        <GlassCard>
          <h3 className="text-xl font-poppins font-semibold text-primary-text mb-6">
            Past Broadcasts
          </h3>
          
          {broadcastsData.length === 0 ? (
            <p className="text-primary-text/70 text-sm">No broadcasts found</p>
          ) : (
            <div className="space-y-4" />
          )}
        </GlassCard>
      </motion.div>

      {/* Create Broadcast Modal */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Create New Broadcast"
        size="lg"
      >
        <BroadcastForm
          onSubmit={handleCreateBroadcast}
          onCancel={() => setIsCreateModalOpen(false)}
        />
      </Modal>

      {/* View Broadcast Modal - Commented out until selectedBroadcast is implemented */}
      {/* <Modal
        isOpen={isViewModalOpen}
        onClose={() => setIsViewModalOpen(false)}
        title={`Broadcast Details - ${selectedBroadcast?.title}`}
        size="lg"
      >
        {selectedBroadcast && (
          <div className="space-y-6">
            <GlassCard>
              <p className="text-primary-text/70">Broadcast details will be displayed here</p>
            </GlassCard>
          </div>
        )}
      </Modal> */}
    </div>
  );
};
