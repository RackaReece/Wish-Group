import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { GlassCard } from '../../components/GlassCard';
import { Modal } from '../../components/Modal';
import { IoCheckmarkCircleOutline, IoCloseOutline } from 'react-icons/io5';

export const Documents: React.FC = () => {
  const [selectedDocument, setSelectedDocument] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filter, setFilter] = useState<'all' | 'id' | 'insurance' | 'vehicle' | 'certificate'>('all');
  const [selectedDocs, setSelectedDocs] = useState<number[]>([]);

  const documentsData: any[] = [];

  const filteredDocuments = filter === 'all' 
    ? documentsData 
    : documentsData.filter(doc => doc.type.toLowerCase() === filter);

  const handleDocumentClick = (document: any) => {
    setSelectedDocument(document);
    setIsModalOpen(true);
  };

  const handleApprove = (id: number) => {
    // Action logged
  };

  const handleReject = (id: number) => {
    // Action logged
  };

  const handleBatchApprove = () => {
    // Action logged
    setSelectedDocs([]);
  };

  const handleBatchReject = () => {
    // Action logged
    setSelectedDocs([]);
  };

  const toggleDocumentSelection = (id: number) => {
    setSelectedDocs(prev => 
      prev.includes(id) 
        ? prev.filter(docId => docId !== id)
        : [...prev, id]
    );
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Approved':
        return 'text-success';
      case 'Rejected':
        return 'text-danger';
      case 'Pending':
        return 'text-yellow-500';
      default:
        return 'text-primary-text/70';
    }
  };

  const getStatusBg = (status: string) => {
    switch (status) {
      case 'Approved':
        return 'bg-success/20';
      case 'Rejected':
        return 'bg-danger/20';
      case 'Pending':
        return 'bg-yellow-500/20';
      default:
        return 'bg-gray-500/20';
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <h1 className="text-3xl font-poppins font-bold text-primary-text mb-2">
          Documents & Verification
        </h1>
        <p className="text-primary-text/70">
          Review and verify valeter documents across all platforms.
        </p>
      </motion.div>

      {/* Stats Cards */}
      <GlassCard>
        <p className="text-primary-text/70 text-sm">No document stats available</p>
      </GlassCard>

      {/* Filters and Batch Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
      >
        <GlassCard>
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            {/* Filters */}
            <div className="flex items-center space-x-4">
              <select
                value={filter}
                onChange={(e) => setFilter(e.target.value as any)}
                className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-primary-text focus:outline-none focus:border-primary-accent/50"
              >
                <option value="all">All Types</option>
                <option value="id">ID Documents</option>
                <option value="insurance">Insurance</option>
                <option value="vehicle">Vehicle</option>
                <option value="certificate">Certificates</option>
              </select>
            </div>

            {/* Batch Actions */}
            {selectedDocs.length > 0 && (
              <div className="flex items-center space-x-3">
                <span className="text-sm text-primary-text/70">
                  {selectedDocs.length} selected
                </span>
                <button
                  onClick={handleBatchApprove}
                  className="px-4 py-2 bg-success/20 text-success rounded-xl hover:bg-success/30 transition-colors text-sm font-medium"
                >
                  <IoCheckmarkCircleOutline /> Approve Selected
                </button>
                <button
                  onClick={handleBatchReject}
                  className="px-4 py-2 bg-danger/20 text-danger rounded-xl hover:bg-danger/30 transition-colors text-sm font-medium"
                >
                  <IoCloseOutline /> Reject Selected
                </button>
              </div>
            )}
          </div>
        </GlassCard>
      </motion.div>

      {/* Documents Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.3 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6"
      >
        {filteredDocuments.map((document, index) => (
          <motion.div
            key={document.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 }}
          >
            <GlassCard
              hover
              onClick={() => handleDocumentClick(document)}
              className="cursor-pointer"
            >
              <div className="space-y-4">
                {/* Document Preview */}
                <div className="text-center">
                  <div className="text-4xl mb-2">{document.preview}</div>
                  <p className="text-sm font-medium text-primary-text">{document.type}</p>
                </div>

                {/* Document Info */}
                <div className="space-y-2">
                  <div>
                    <p className="text-xs text-primary-text/70">Valeter</p>
                    <p className="text-sm font-medium text-primary-text">{document.proName}</p>
                    <p className="text-xs text-primary-text/50">{document.proId}</p>
                  </div>
                  
                  <div>
                    <p className="text-xs text-primary-text/70">Status</p>
                    <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getStatusBg(document.status)} ${getStatusColor(document.status)}`}>
                      {document.status}
                    </span>
                  </div>

                  <div>
                    <p className="text-xs text-primary-text/70">Uploaded</p>
                    <p className="text-xs text-primary-text">{document.uploadedDate}</p>
                  </div>

                  <div>
                    <p className="text-xs text-primary-text/70">File Size</p>
                    <p className="text-xs text-primary-text">{document.fileSize}</p>
                  </div>
                </div>

                {/* Selection Checkbox */}
                <div className="flex items-center justify-between pt-2 border-t border-white/10">
                  <label className="flex items-center space-x-2 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={selectedDocs.includes(document.id)}
                      onChange={(e) => {
                        e.stopPropagation();
                        toggleDocumentSelection(document.id);
                      }}
                      className="w-4 h-4 text-primary-accent bg-white/5 border-white/20 rounded focus:ring-primary-accent/50"
                    />
                    <span className="text-xs text-primary-text/70">Select</span>
                  </label>
                  
                  <div className="flex space-x-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleApprove(document.id);
                      }}
                      className="p-1 text-success hover:bg-success/20 rounded transition-colors"
                    >
                      <IoCheckmarkCircleOutline />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleReject(document.id);
                      }}
                      className="p-1 text-danger hover:bg-danger/20 rounded transition-colors"
                    >
                      <IoCloseOutline />
                    </button>
                  </div>
                </div>
              </div>
            </GlassCard>
          </motion.div>
        ))}
      </motion.div>

      {/* Document Viewer Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={`${selectedDocument?.type} Document - ${selectedDocument?.proName}`}
        size="xl"
      >
        {selectedDocument && (
          <div className="space-y-6">
            {/* Document Preview */}
            <div className="text-center">
              <div className="text-6xl mb-4">{selectedDocument.preview}</div>
              <h3 className="text-xl font-semibold text-primary-text mb-2">
                {selectedDocument.description}
              </h3>
              <p className="text-primary-text/70">{selectedDocument.fileName}</p>
            </div>

            {/* Document Details */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-lg font-semibold text-primary-text mb-4">Document Information</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-primary-text/70">Type</label>
                    <p className="text-primary-text">{selectedDocument.type}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">File Name</label>
                    <p className="text-primary-text">{selectedDocument.fileName}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">File Size</label>
                    <p className="text-primary-text">{selectedDocument.fileSize}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Uploaded Date</label>
                    <p className="text-primary-text">{selectedDocument.uploadedDate}</p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-lg font-semibold text-primary-text mb-4">Valeter Information</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-primary-text/70">Name</label>
                    <p className="text-primary-text">{selectedDocument.proName}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Pro ID</label>
                    <p className="text-primary-text">{selectedDocument.proId}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Current Status</label>
                    <span className={`inline-block px-3 py-1 rounded-full text-sm font-medium ${getStatusBg(selectedDocument.status)} ${getStatusColor(selectedDocument.status)}`}>
                      {selectedDocument.status}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-center space-x-4 pt-6 border-t border-white/10">
              <button
                onClick={() => {
                  handleApprove(selectedDocument.id);
                  setIsModalOpen(false);
                }}
                className="px-8 py-3 bg-success/20 text-success rounded-xl hover:bg-success/30 transition-colors font-medium"
              >
                <IoCheckmarkCircleOutline /> Approve Document
              </button>
              <button
                onClick={() => {
                  handleReject(selectedDocument.id);
                  setIsModalOpen(false);
                }}
                className="px-8 py-3 bg-danger/20 text-danger rounded-xl hover:bg-danger/30 transition-colors font-medium"
              >
                <IoCloseOutline /> Reject Document
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
