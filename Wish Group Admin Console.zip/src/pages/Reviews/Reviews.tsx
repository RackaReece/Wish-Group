import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Table } from '../../components/Table';
import { GlassCard } from '../../components/GlassCard';
import { ChartCard } from '../../components/ChartCard';
import { IoStarOutline, IoCheckmarkCircleOutline, IoFlagOutline } from 'react-icons/io5';

export const Reviews: React.FC = () => {
  const [filter, setFilter] = useState<'all' | 'wash' | 'pro' | 'fix'>('all');

  const reviewsData: any[] = [];

  const filteredReviews = filter === 'all' 
    ? reviewsData 
    : reviewsData.filter(review => review.app.toLowerCase().includes(filter));

  // const averageRatings: any[] = [];

  // const ratingTrendData: any[] = [];

  const columns = [
    { key: 'app', label: 'App', sortable: true },
    { key: 'serviceType', label: 'Service Type', sortable: true },
    { key: 'customer', label: 'Customer', sortable: true },
    { key: 'provider', label: 'Provider', sortable: true },
    { 
      key: 'rating', 
      label: 'Rating', 
      sortable: true,
      render: (value: number) => (
        <div className="flex items-center space-x-1">
          {[...Array(5)].map((_, i) => (
            <span key={i} className={i < value ? 'text-yellow-400' : 'text-gray-500'}>
              <IoStarOutline />
            </span>
          ))}
          <span className="ml-1 text-sm text-primary-text/70">({value})</span>
        </div>
      )
    },
    { 
      key: 'comment', 
      label: 'Comment', 
      render: (value: string) => (
        <div className="max-w-xs truncate" title={value}>
          {value}
        </div>
      )
    },
    { key: 'date', label: 'Date', sortable: true },
    { 
      key: 'flagged', 
      label: 'Status', 
      render: (value: boolean) => (
        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
          value ? 'bg-danger/20 text-danger' : 'bg-success/20 text-success'
        }`}>
          {value ? <><IoFlagOutline /> Flagged</> : <><IoCheckmarkCircleOutline /> Normal</>}
        </span>
      )
    }
  ];

  const handleFlagReview = (id: number) => {
    // Action logged
  };

  const actions = (row: any) => (
    <button
      onClick={() => handleFlagReview(row.id)}
      className={`px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
        row.flagged 
          ? 'bg-success/20 text-success hover:bg-success/30' 
          : 'bg-danger/20 text-danger hover:bg-danger/30'
      }`}
    >
      {row.flagged ? <><IoCheckmarkCircleOutline /> Unflag</> : <><IoFlagOutline /> Flag</>}
    </button>
  );

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <h1 className="text-3xl font-poppins font-bold text-primary-text mb-2">
          Reviews & Ratings
        </h1>
        <p className="text-primary-text/70">
          Monitor customer feedback and ratings across all Wish Group platforms.
        </p>
      </motion.div>

      {/* Average Ratings Cards */}
      <GlassCard>
        <p className="text-primary-text/70 text-sm">No rating summaries available</p>
      </GlassCard>

      {/* Rating Trend Chart */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
      >
        <ChartCard title="Average Rating Trend (3 Apps Compared)" type="line" data={[]} />
      </motion.div>

      {/* Reviews Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.3 }}
      >
        <GlassCard>
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 mb-6">
            <h3 className="text-xl font-poppins font-semibold text-primary-text">
              Recent Reviews
            </h3>
            
            {/* Filter Dropdown */}
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value as any)}
              className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-primary-text focus:outline-none focus:border-primary-accent/50"
            >
              <option value="all">All Apps</option>
              <option value="wash">Wash-a-Wash</option>
              <option value="pro">Wish-a-Pro</option>
              <option value="fix">Wish-a-Fix</option>
            </select>
          </div>

          <Table
            columns={columns}
            data={filteredReviews}
            actions={actions}
            pagination={true}
            pageSize={10}
          />
        </GlassCard>
      </motion.div>

      {/* Review Summary Stats */}
      <GlassCard>
        <p className="text-primary-text/70 text-sm">No review statistics available</p>
      </GlassCard>
    </div>
  );
};
