import React from 'react';
import { motion } from 'framer-motion';
import { GlassCard } from '../../components/GlassCard';
import { ChartCard } from '../../components/ChartCard';

export const Dashboard: React.FC = () => {
  const bookingsOverTime: any[] = [];
  const feeRevenue: any[] = [];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <h1 className="text-3xl font-poppins font-bold text-primary-text mb-2">
          Dashboard
        </h1>
        <p className="text-primary-text/70">
          Welcome back! Here's what's happening with your Wish Group ecosystem.
        </p>
      </motion.div>

      {/* KPI Placeholder */}
      <GlassCard>
        <p className="text-primary-text/70 text-sm">No KPI data available</p>
      </GlassCard>

      {/* Charts Row */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
        className="grid grid-cols-1 lg:grid-cols-2 gap-6"
      >
        <ChartCard title="Bookings Over Time" type="line" data={bookingsOverTime} />
        <ChartCard title="Platform Fee Revenue" type="bar" data={feeRevenue} />
      </motion.div>

      {/* Quick Actions & Mini Map */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.3 }}
        className="grid grid-cols-1 lg:grid-cols-2 gap-6"
      >
        {/* Quick Actions Placeholder */}
        <GlassCard>
          <h3 className="text-xl font-poppins font-semibold text-primary-text mb-2">Quick Actions</h3>
          <p className="text-primary-text/70 text-sm">No quick actions available</p>
        </GlassCard>

        {/* Map Placeholder */}
        <GlassCard>
          <h3 className="text-xl font-poppins font-semibold text-primary-text mb-2">Active Jobs Heat Map</h3>
          <p className="text-primary-text/70 text-sm">Map unavailable</p>
        </GlassCard>
      </motion.div>

      {/* System Status */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.4 }}
      >
        <GlassCard>
          <h3 className="text-xl font-poppins font-semibold text-primary-text mb-2">System Status</h3>
          <p className="text-primary-text/70 text-sm">No status data available</p>
        </GlassCard>
      </motion.div>
    </div>
  );
};
