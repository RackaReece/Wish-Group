import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { GlassCard } from '../../components/GlassCard';
import { Modal } from '../../components/Modal';
import { IoAddOutline, IoDocumentOutline, IoServerOutline, IoAnalyticsOutline, IoCalendarOutline, IoSettingsOutline, IoDownloadOutline } from 'react-icons/io5';

export const Reports: React.FC = () => {
  const [isGenerateModalOpen, setIsGenerateModalOpen] = useState(false);
  const [newReportType, setNewReportType] = useState<'weekly' | 'monthly' | 'quarterly' | 'custom'>('weekly');
  const [customDateRange, setCustomDateRange] = useState({ start: '', end: '' });

  const reportsData: any[] = [];

  // const handleDownload = (reportId: string, format: 'pdf' | 'csv') => {
  //   console.log(`Downloading report ${reportId} as ${format.toUpperCase()}`);
  // };

  const handleGenerateReport = () => {
    // Generating new report
    setIsGenerateModalOpen(false);
  };

  // const handleDeleteReport = (reportId: string) => {
  //   // Action logged
  // };

  // const getStatusColor = (status: string) => {
  //   switch (status) {
  //     case 'Ready':
  //       return 'text-success';
  //     case 'Generating':
  //       return 'text-yellow-500';
  //     case 'Failed':
  //       return 'text-danger';
  //     default:
  //       return 'text-primary-text/70';
  //   }
  // };

  // const getStatusBg = (status: string) => {
  //   switch (status) {
  //     case 'Ready':
  //       return 'bg-success/20';
  //     case 'Generating':
  //       return 'bg-yellow-500/20';
  //     case 'Failed':
  //       return 'bg-danger/20';
  //     default:
  //       return 'bg-gray-500/20';
  //   }
  // };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          <div>
            <h1 className="text-3xl font-poppins font-bold text-primary-text mb-2">
              Reports & Analytics
            </h1>
            <p className="text-primary-text/70">
              Generate and manage comprehensive reports across all Wish Group platforms.
            </p>
          </div>
          
          <button
            onClick={() => setIsGenerateModalOpen(true)}
            className="glow-button px-6 py-2 text-sm font-semibold"
          >
            <IoAddOutline className="inline mr-2" />
            Generate New Report
          </button>
        </div>
      </motion.div>

      {/* Report Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.1 }}
        className="grid grid-cols-1 md:grid-cols-4 gap-6"
      >
        <GlassCard>
          <div className="text-center">
            <IoDocumentOutline className="text-3xl mb-2" />
            <p className="text-2xl font-bold text-primary-text">0</p>
            <p className="text-sm text-primary-text/70">Total Reports</p>
          </div>
        </GlassCard>
        <GlassCard>
          <div className="text-center">
            <IoDownloadOutline className="text-3xl mb-2" />
            <p className="text-2xl font-bold text-primary-text">0</p>
            <p className="text-sm text-primary-text/70">Total Downloads</p>
          </div>
        </GlassCard>
        <GlassCard>
          <div className="text-center">
            <IoAnalyticsOutline className="text-3xl mb-2" />
            <p className="text-2xl font-bold text-yellow-500">0</p>
            <p className="text-sm text-primary-text/70">Generating</p>
          </div>
        </GlassCard>
        <GlassCard>
          <div className="text-center">
            <IoServerOutline className="text-3xl mb-2" />
            <p className="text-2xl font-bold text-primary-text">0 MB</p>
            <p className="text-sm text-primary-text/70">Storage Used</p>
          </div>
        </GlassCard>
      </motion.div>

      {/* Reports List */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
      >
        <GlassCard>
          <h3 className="text-xl font-poppins font-semibold text-primary-text mb-6">
            Generated Reports
          </h3>
          
          {reportsData.length === 0 ? (
            <p className="text-primary-text/70 text-sm">No reports available</p>
          ) : (
            <div className="space-y-4" />
          )}
        </GlassCard>
      </motion.div>

      {/* Generate Report Modal */}
      <Modal
        isOpen={isGenerateModalOpen}
        onClose={() => setIsGenerateModalOpen(false)}
        title="Generate New Report"
        size="md"
      >
        <div className="space-y-6">
          {/* Report Type */}
          <div>
            <label className="block text-sm font-medium text-primary-text mb-3">
              Report Type
            </label>
            <div className="grid grid-cols-2 gap-3">
              {[
                { value: 'weekly', label: 'Weekly', icon: <IoCalendarOutline /> },
                { value: 'monthly', label: 'Monthly', icon: <IoAnalyticsOutline /> },
                { value: 'quarterly', label: 'Quarterly', icon: <IoAnalyticsOutline /> },
                { value: 'custom', label: 'Custom', icon: <IoSettingsOutline /> }
              ].map((type) => (
                <button
                  key={type.value}
                  onClick={() => setNewReportType(type.value as any)}
                  className={`p-4 rounded-xl border transition-all duration-200 ${
                    newReportType === type.value
                      ? 'border-primary-accent bg-primary-accent/10 text-primary-accent'
                      : 'border-white/10 bg-white/5 text-primary-text hover:border-primary-accent/30'
                  }`}
                >
                  <div className="text-center">
                    <div className="text-2xl mb-2">{type.icon}</div>
                    <div className="text-sm font-medium">{type.label}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Custom Date Range */}
          {newReportType === 'custom' && (
            <div>
              <label className="block text-sm font-medium text-primary-text mb-3">
                Date Range
              </label>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs text-primary-text/70 mb-1">Start Date</label>
                  <input
                    type="date"
                    value={customDateRange.start}
                    onChange={(e) => setCustomDateRange(prev => ({ ...prev, start: e.target.value }))}
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-primary-text focus:outline-none focus:border-primary-accent/50"
                  />
                </div>
                <div>
                  <label className="block text-xs text-primary-text/70 mb-1">End Date</label>
                  <input
                    type="date"
                    value={customDateRange.end}
                    onChange={(e) => setCustomDateRange(prev => ({ ...prev, end: e.target.value }))}
                    className="w-full px-3 py-2 bg-white/5 border border-white/10 rounded-lg text-primary-text focus:outline-none focus:border-primary-accent/50"
                  />
                </div>
              </div>
            </div>
          )}

          {/* Report Options */}
          <div>
            <label className="block text-sm font-medium text-primary-text mb-3">
              Include Data
            </label>
            <div className="space-y-2">
              {[
                'User Analytics',
                'Revenue Data',
                'Booking Statistics',
                'Platform Performance',
                'Customer Feedback'
              ].map((option) => (
                <label key={option} className="flex items-center space-x-3">
                  <input
                    type="checkbox"
                    defaultChecked
                    className="w-4 h-4 text-primary-accent bg-white/5 border-white/20 rounded focus:ring-primary-accent/50"
                  />
                  <span className="text-sm text-primary-text">{option}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Generate Button */}
          <div className="flex justify-end space-x-4 pt-6 border-t border-white/10">
            <button
              onClick={() => setIsGenerateModalOpen(false)}
              className="px-6 py-2 bg-white/5 text-primary-text rounded-xl hover:bg-white/10 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={handleGenerateReport}
              className="glow-button px-6 py-2 text-sm font-semibold"
            >
              <IoAnalyticsOutline className="inline mr-2" />
              Generate Report
            </button>
          </div>
        </div>
      </Modal>
    </div>
  );
};
