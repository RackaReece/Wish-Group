import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { GlassCard } from '../../components/GlassCard';
import { ChartCard } from '../../components/ChartCard';
import { IoAnalyticsOutline, IoDocumentTextOutline } from 'react-icons/io5';

export const Analytics: React.FC = () => {
  const [dateRange, setDateRange] = useState<'7d' | '30d' | '90d' | '1y'>('30d');

  // const activeUsersData: any[] = [];

  // const appUsageData: any[] = [];

  const topCitiesData: any[] = [];

  const conversionFunnelData: any[] = [];

  // const kpiData: any[] = [];

  const handleExport = (format: 'csv' | 'pdf') => {
    // Exporting analytics data
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          <div>
            <h1 className="text-3xl font-poppins font-bold text-primary-text mb-2">
              Analytics Dashboard
            </h1>
            <p className="text-primary-text/70">
              Comprehensive analytics and insights across all Wish Group platforms.
            </p>
          </div>
          
          <div className="flex items-center space-x-4">
            {/* Date Range Picker */}
            <select
              value={dateRange}
              onChange={(e) => setDateRange(e.target.value as any)}
              className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-primary-text focus:outline-none focus:border-primary-accent/50"
            >
              <option value="7d">Last 7 Days</option>
              <option value="30d">Last 30 Days</option>
              <option value="90d">Last 90 Days</option>
              <option value="1y">Last Year</option>
            </select>

            {/* Export Buttons */}
            <div className="flex space-x-2">
              <button
                onClick={() => handleExport('csv')}
                className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-primary-text hover:bg-white/10 transition-colors text-sm"
              >
                <IoAnalyticsOutline className="inline mr-1" /> CSV
              </button>
              <button
                onClick={() => handleExport('pdf')}
                className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-primary-text hover:bg-white/10 transition-colors text-sm"
              >
                <IoDocumentTextOutline className="inline mr-1" /> PDF
              </button>
            </div>
          </div>
        </div>
      </motion.div>

      {/* KPI Cards */}
      <GlassCard>
        <p className="text-primary-text/70 text-sm">No analytics KPIs available</p>
      </GlassCard>

      {/* Charts Grid */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
        className="grid grid-cols-1 lg:grid-cols-2 gap-6"
      >
        <ChartCard title="Active Users Over Time" type="line" data={[]} />
        <ChartCard title="App Usage Distribution" type="pie" data={[]} />
      </motion.div>

      {/* Top Cities and Conversion Funnel */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.3 }}
        className="grid grid-cols-1 lg:grid-cols-2 gap-6"
      >
        {/* Top Cities */}
        <GlassCard>
          <h3 className="text-xl font-poppins font-semibold text-primary-text mb-6">
            Top Cities by Job Volume
          </h3>
          <div className="space-y-4">
            {topCitiesData.length === 0 && (
              <p className="text-primary-text/70 text-sm">No city data available</p>
            )}
          </div>
        </GlassCard>

        {/* Conversion Funnel */}
        <GlassCard>
          <h3 className="text-xl font-poppins font-semibold text-primary-text mb-6">
            Conversion Funnel
          </h3>
          <div className="space-y-4">
            {conversionFunnelData.length === 0 && (
              <p className="text-primary-text/70 text-sm">No funnel data available</p>
            )}
          </div>
        </GlassCard>
      </motion.div>

      {/* Additional Analytics Cards */}
      <GlassCard>
        <p className="text-primary-text/70 text-sm">No additional analytics available</p>
      </GlassCard>
    </div>
  );
};
