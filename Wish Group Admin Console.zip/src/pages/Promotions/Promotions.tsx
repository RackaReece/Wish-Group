import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { GlassCard } from '../../components/GlassCard';
import { Modal } from '../../components/Modal';
import { IoRibbonOutline, IoGiftOutline, IoPeopleOutline, IoCashOutline, IoCheckmarkCircleOutline, IoAnalyticsOutline, IoTrashOutline, IoPauseOutline, IoPlayOutline } from 'react-icons/io5';

export const Promotions: React.FC = () => {
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false);
  const [selectedPromotion] = useState<any>(null);
  const [isViewModalOpen, setIsViewModalOpen] = useState(false);

  // const promotionsData: any[] = [];

  // const handleCreatePromotion = (promotionData: any) => {
  //   console.log('Creating promotion:', promotionData);
  //   setIsCreateModalOpen(false);
  // };

  // const handleViewPromotion = (promotion: any) => {
  //   setSelectedPromotion(promotion);
  //   setIsViewModalOpen(true);
  // };

  const handleTogglePromotion = (promotionId: string) => {
    // Toggling promotion
  };

  const handleDeletePromotion = (promotionId: string) => {
    // Deleting promotion
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Active':
        return 'text-success';
      case 'Scheduled':
        return 'text-yellow-500';
      case 'Expired':
        return 'text-gray-500';
      case 'Paused':
        return 'text-danger';
      default:
        return 'text-primary-text/70';
    }
  };

  const getStatusBg = (status: string) => {
    switch (status) {
      case 'Active':
        return 'bg-success/20';
      case 'Scheduled':
        return 'bg-yellow-500/20';
      case 'Expired':
        return 'bg-gray-500/20';
      case 'Paused':
        return 'bg-danger/20';
      default:
        return 'bg-gray-500/20';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'Discount':
        return <IoCashOutline />;
      case 'Reward':
        return <IoGiftOutline />;
      case 'Referral':
        return <IoPeopleOutline />;
      default:
        return <IoRibbonOutline />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
          <div>
            <h1 className="text-3xl font-poppins font-bold text-primary-text mb-2">
              Promotions Management
            </h1>
            <p className="text-primary-text/70">
              Create and manage promotional campaigns across all Wish Group platforms.
            </p>
          </div>
          
          <button
            onClick={() => setIsCreateModalOpen(true)}
            className="glow-button px-6 py-2 text-sm font-semibold"
          >
            <IoRibbonOutline /> Create Promotion
          </button>
        </div>
      </motion.div>

      {/* Promotion Stats */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.1 }}
        className="grid grid-cols-1 md:grid-cols-4 gap-6"
      >
        <GlassCard>
          <div className="text-center">
            <div className="text-3xl mb-2"><IoRibbonOutline /></div>
            <p className="text-2xl font-bold text-primary-text">0</p>
            <p className="text-sm text-primary-text/70">Total Promotions</p>
          </div>
        </GlassCard>
        <GlassCard>
          <div className="text-center">
            <div className="text-3xl mb-2"><IoCheckmarkCircleOutline /></div>
            <p className="text-2xl font-bold text-success">0</p>
            <p className="text-sm text-primary-text/70">Active</p>
          </div>
        </GlassCard>
        <GlassCard>
          <div className="text-center">
            <div className="text-3xl mb-2"><IoAnalyticsOutline /></div>
            <p className="text-2xl font-bold text-primary-text">0</p>
            <p className="text-sm text-primary-text/70">Total Usage</p>
          </div>
        </GlassCard>
        <GlassCard>
          <div className="text-center">
            <div className="text-3xl mb-2"><IoCashOutline /></div>
            <p className="text-2xl font-bold text-primary-text">£0</p>
            <p className="text-sm text-primary-text/70">Total Savings</p>
          </div>
        </GlassCard>
      </motion.div>

      {/* Promotions Grid */}
      <GlassCard>
        <p className="text-primary-text/70 text-sm">No promotions available</p>
      </GlassCard>

      {/* Create Promotion Modal */}
      <Modal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        title="Create New Promotion"
        size="lg"
      >
        <div className="space-y-6">
          {/* Promotion Form */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-primary-text mb-2">
                Promotion Name
              </label>
              <input
                type="text"
                placeholder="Enter promotion name..."
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-primary-text placeholder-primary-text/50 focus:outline-none focus:border-primary-accent/50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-primary-text mb-2">
                Type
              </label>
              <select className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-primary-text focus:outline-none focus:border-primary-accent/50">
                <option value="discount">Discount</option>
                <option value="reward">Reward</option>
                <option value="referral">Referral</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-primary-text mb-2">
                App
              </label>
              <select className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-primary-text focus:outline-none focus:border-primary-accent/50">
                <option value="all">All Apps</option>
                <option value="wash">Wash-a-Wash</option>
                <option value="pro">Wish-a-Pro</option>
                <option value="fix">Wish-a-Fix</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-primary-text mb-2">
                Discount %
              </label>
              <input
                type="number"
                placeholder="0"
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-primary-text placeholder-primary-text/50 focus:outline-none focus:border-primary-accent/50"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-medium text-primary-text mb-2">
                Start Date
              </label>
              <input
                type="date"
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-primary-text focus:outline-none focus:border-primary-accent/50"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-primary-text mb-2">
                End Date
              </label>
              <input
                type="date"
                className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-primary-text focus:outline-none focus:border-primary-accent/50"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">
              Description
            </label>
            <textarea
              placeholder="Enter promotion description..."
              rows={3}
              className="w-full px-4 py-3 bg-white/5 border border-white/10 rounded-xl text-primary-text placeholder-primary-text/50 focus:outline-none focus:border-primary-accent/50 resize-none"
            />
          </div>

          <div className="flex justify-end space-x-4 pt-6 border-t border-white/10">
            <button
              onClick={() => setIsCreateModalOpen(false)}
              className="px-6 py-2 bg-white/5 text-primary-text rounded-xl hover:bg-white/10 transition-colors"
            >
              Cancel
            </button>
            <button
              onClick={() => setIsCreateModalOpen(false)}
              className="glow-button px-6 py-2 text-sm font-semibold"
            >
              <IoRibbonOutline /> Create Promotion
            </button>
          </div>
        </div>
      </Modal>

      {/* View Promotion Modal */}
      <Modal
        isOpen={isViewModalOpen}
        onClose={() => setIsViewModalOpen(false)}
        title={`Promotion Details - ${selectedPromotion?.name}`}
        size="lg"
      >
        {selectedPromotion && (
          <div className="space-y-6">
            {/* Promotion Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-lg font-semibold text-primary-text mb-4">Promotion Details</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-primary-text/70">Name</label>
                    <p className="text-primary-text">{selectedPromotion.name}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Type</label>
                    <p className="text-primary-text flex items-center space-x-2">
                      <span>{getTypeIcon(selectedPromotion.type)}</span>
                      <span>{selectedPromotion.type}</span>
                    </p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">App</label>
                    <p className="text-primary-text">{selectedPromotion.app}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Status</label>
                    <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium ${getStatusBg(selectedPromotion.status)} ${getStatusColor(selectedPromotion.status)}`}>
                      {selectedPromotion.status}
                    </span>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-lg font-semibold text-primary-text mb-4">Usage Statistics</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-primary-text/70">Usage Count</label>
                    <p className="text-primary-text">{selectedPromotion.usageCount.toLocaleString()}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Max Usage</label>
                    <p className="text-primary-text">{selectedPromotion.maxUsage.toLocaleString()}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Usage Rate</label>
                    <p className="text-primary-text">
                      {((selectedPromotion.usageCount / selectedPromotion.maxUsage) * 100).toFixed(1)}%
                    </p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Discount</label>
                    <p className="text-primary-text">{selectedPromotion.discountPercent}%</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Description */}
            <div>
              <h4 className="text-lg font-semibold text-primary-text mb-4">Description</h4>
              <p className="text-primary-text/80 bg-white/5 p-4 rounded-xl">
                {selectedPromotion.description}
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-center space-x-4 pt-6 border-t border-white/10">
              <button
                onClick={() => handleTogglePromotion(selectedPromotion.id)}
                className={`px-6 py-2 rounded-xl font-medium transition-colors ${
                  selectedPromotion.status === 'Active'
                    ? 'bg-danger/20 text-danger hover:bg-danger/30'
                    : 'bg-success/20 text-success hover:bg-success/30'
                }`}
              >
                {selectedPromotion.status === 'Active' ? <><IoPauseOutline /> Pause</> : <><IoPlayOutline /> Activate</>}
              </button>
              <button
                onClick={() => handleDeletePromotion(selectedPromotion.id)}
                className="px-6 py-2 bg-danger/20 text-danger rounded-xl hover:bg-danger/30 transition-colors font-medium"
              >
                <IoTrashOutline /> Delete Promotion
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
