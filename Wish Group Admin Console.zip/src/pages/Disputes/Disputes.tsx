import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Table } from '../../components/Table';
import { Modal } from '../../components/Modal';
import { GlassCard } from '../../components/GlassCard';
import { IoCheckmarkCircleOutline, IoCashOutline } from 'react-icons/io5';

export const Disputes: React.FC = () => {
  const [selectedDispute, setSelectedDispute] = useState<any>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [filter, setFilter] = useState<'all' | 'open' | 'in-progress' | 'resolved'>('all');

  const disputesData: any[] = [];

  const filteredDisputes = filter === 'all' 
    ? disputesData 
    : disputesData.filter(dispute => dispute.status.toLowerCase().replace(' ', '-') === filter);

  const columns = [
    { key: 'id', label: 'Dispute ID', sortable: true },
    { key: 'user', label: 'User', sortable: true },
    { key: 'pro', label: 'Pro', sortable: true },
    { key: 'reason', label: 'Reason', sortable: true },
    { 
      key: 'status', 
      label: 'Status', 
      sortable: true,
      render: (value: string) => (
        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
          value === 'Open' ? 'bg-danger/20 text-danger' :
          value === 'In Progress' ? 'bg-yellow-500/20 text-yellow-500' :
          'bg-success/20 text-success'
        }`}>
          {value}
        </span>
      )
    },
    { key: 'lastUpdate', label: 'Last Update', sortable: true },
    { key: 'amount', label: 'Amount', sortable: true }
  ];

  const handleDisputeClick = (dispute: any) => {
    setSelectedDispute(dispute);
    setIsModalOpen(true);
  };

  const handleMarkResolved = (id: string) => {
    // Action logged
    setIsModalOpen(false);
  };

  const handleRefundIssued = (id: string) => {
    // Action logged
    setIsModalOpen(false);
  };

  const handleEscalate = (id: string) => {
    // Action logged
    setIsModalOpen(false);
  };

  const actions = (row: any) => (
    <button
      onClick={() => handleDisputeClick(row)}
      className="px-3 py-1 bg-primary-accent/20 text-primary-accent rounded-lg text-xs hover:bg-primary-accent/30 transition-colors"
    >
      View Details
    </button>
  );

  // const kpiData: any[] = [];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <h1 className="text-3xl font-poppins font-bold text-primary-text mb-2">
          Disputes Management
        </h1>
        <p className="text-primary-text/70">
          Resolve customer disputes and maintain service quality across all platforms.
        </p>
      </motion.div>

      {/* KPI Cards */}
      <GlassCard>
        <p className="text-primary-text/70 text-sm">No dispute KPIs available</p>
      </GlassCard>

      {/* Filters */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
      >
        <GlassCard>
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0">
            <h3 className="text-xl font-poppins font-semibold text-primary-text">
              Disputes List
            </h3>
            
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value as any)}
              className="px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-primary-text focus:outline-none focus:border-primary-accent/50"
            >
              <option value="all">All Status</option>
              <option value="open">Open</option>
              <option value="in-progress">In Progress</option>
              <option value="resolved">Resolved</option>
            </select>
          </div>
        </GlassCard>
      </motion.div>

      {/* Disputes Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.3 }}
      >
        <Table
          columns={columns}
          data={filteredDisputes}
          onRowClick={handleDisputeClick}
          actions={actions}
        />
      </motion.div>

      {/* Dispute Details Modal */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title={`Dispute ${selectedDispute?.id} - ${selectedDispute?.reason}`}
        size="xl"
      >
        {selectedDispute && (
          <div className="space-y-6">
            {/* Dispute Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="text-lg font-semibold text-primary-text mb-4">Dispute Details</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-primary-text/70">Dispute ID</label>
                    <p className="text-primary-text">{selectedDispute.id}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Reason</label>
                    <p className="text-primary-text">{selectedDispute.reason}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Amount</label>
                    <p className="text-primary-text font-semibold">{selectedDispute.amount}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Priority</label>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      selectedDispute.priority === 'High' ? 'bg-danger/20 text-danger' :
                      selectedDispute.priority === 'Medium' ? 'bg-yellow-500/20 text-yellow-500' :
                      'bg-success/20 text-success'
                    }`}>
                      {selectedDispute.priority}
                    </span>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="text-lg font-semibold text-primary-text mb-4">Parties Involved</h4>
                <div className="space-y-3">
                  <div>
                    <label className="text-sm text-primary-text/70">Customer</label>
                    <p className="text-primary-text">{selectedDispute.user}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Service Provider</label>
                    <p className="text-primary-text">{selectedDispute.pro}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Last Update</label>
                    <p className="text-primary-text">{selectedDispute.lastUpdate}</p>
                  </div>
                  <div>
                    <label className="text-sm text-primary-text/70">Status</label>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      selectedDispute.status === 'Open' ? 'bg-danger/20 text-danger' :
                      selectedDispute.status === 'In Progress' ? 'bg-yellow-500/20 text-yellow-500' :
                      'bg-success/20 text-success'
                    }`}>
                      {selectedDispute.status}
                    </span>
                  </div>
                </div>
              </div>
            </div>

            {/* Description */}
            <div>
              <h4 className="text-lg font-semibold text-primary-text mb-4">Description</h4>
              <p className="text-primary-text/80 bg-white/5 p-4 rounded-xl">
                {selectedDispute.description}
              </p>
            </div>

            {/* Chat Thread */}
            <div>
              <h4 className="text-lg font-semibold text-primary-text mb-4">Conversation Thread</h4>
              <div className="space-y-4 max-h-80 overflow-y-auto">
                {selectedDispute.messages.map((message: any) => (
                  <div
                    key={message.id}
                    className={`flex ${message.senderType === 'admin' ? 'justify-center' : message.senderType === 'customer' ? 'justify-start' : 'justify-end'}`}
                  >
                    <div className={`max-w-xs lg:max-w-md px-4 py-3 rounded-xl ${
                      message.senderType === 'admin' 
                        ? 'bg-primary-accent/20 text-primary-accent' 
                        : message.senderType === 'customer'
                        ? 'bg-white/5 text-primary-text'
                        : 'bg-primary-accent/10 text-primary-text'
                    }`}>
                      <div className="flex items-center space-x-2 mb-1">
                        <span className="text-xs font-medium">{message.sender}</span>
                        <span className="text-xs text-primary-text/50">{message.timestamp}</span>
                      </div>
                      <p className="text-sm">{message.message}</p>
                      {message.attachments && message.attachments.length > 0 && (
                        <div className="mt-2 pt-2 border-t border-white/10">
                          <p className="text-xs text-primary-text/70 mb-1">Attachments:</p>
                          {message.attachments.map((file: string, index: number) => (
                            <span key={index} className="text-xs text-primary-accent hover:underline cursor-pointer">
                              {file}
                            </span>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex justify-center space-x-4 pt-6 border-t border-white/10">
              <button
                onClick={() => handleMarkResolved(selectedDispute.id)}
                className="px-6 py-2 bg-success/20 text-success rounded-xl hover:bg-success/30 transition-colors font-medium"
              >
                <IoCheckmarkCircleOutline /> Mark Resolved
              </button>
              <button
                onClick={() => handleRefundIssued(selectedDispute.id)}
                className="px-6 py-2 bg-primary-accent/20 text-primary-accent rounded-xl hover:bg-primary-accent/30 transition-colors font-medium"
              >
                <IoCashOutline /> Refund Issued
              </button>
              <button
                onClick={() => handleEscalate(selectedDispute.id)}
                className="px-6 py-2 bg-danger/20 text-danger rounded-xl hover:bg-danger/30 transition-colors font-medium"
              >
                ⚠️ Escalate
              </button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
};
