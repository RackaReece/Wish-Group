import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { GlassCard } from '../../components/GlassCard';
import { ChartCard } from '../../components/ChartCard';
import { FeeControl } from '../../components/FeeControl';
import { IoSaveOutline } from 'react-icons/io5';

export const Revenue: React.FC = () => {
  const [platformFees, setPlatformFees] = useState({
    wash: 0,
    pro: 0,
    fix: 0
  });

  const [feeHistory, setFeeHistory] = useState<any[]>([]);

  // const revenueData: any[] = [];

  const appRevenueData: any[] = [];

  // const revenueByAppData: any[] = [];

  // const monthlyRevenueData: any[] = [];

  const handleFeeChange = (app: string, newFee: number) => {
    setPlatformFees(prev => ({
      ...prev,
      [app]: newFee
    }));
    
    // Add to fee history
    const newHistoryEntry = {
      date: new Date().toISOString().split('T')[0],
      app: app === 'wash' ? 'Wash-a-Wash' : app === 'pro' ? 'Wish-a-Pro' : 'Wish-a-Fix',
      oldFee: platformFees[app as keyof typeof platformFees],
      newFee: newFee,
      changedBy: 'Admin User'
    };
    
    setFeeHistory(prev => [newHistoryEntry, ...prev]);
    // Platform fee updated
  };

  const handleSaveChanges = () => {
    // Saving platform fee changes
    // Here you would typically send the changes to your backend
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <h1 className="text-3xl font-poppins font-bold text-primary-text mb-2">
          Revenue & Fees
        </h1>
        <p className="text-primary-text/70">
          Monitor revenue streams and manage platform fees across all Wish Group services.
        </p>
      </motion.div>

      {/* Revenue KPI Placeholder */}
      <GlassCard>
        <p className="text-primary-text/70 text-sm">No revenue KPIs available</p>
      </GlassCard>

      {/* Charts Row */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.2 }}
        className="grid grid-cols-1 lg:grid-cols-2 gap-6"
      >
        <ChartCard title="Revenue by App (This Month)" type="pie" data={[]} />
        <ChartCard title="Monthly Revenue Trend" type="bar" data={[]} />
      </motion.div>

      {/* Platform Fee Controls */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.3 }}
      >
        <GlassCard>
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between space-y-4 lg:space-y-0 mb-6">
            <h3 className="text-xl font-poppins font-semibold text-primary-text">
              Platform Fee Controls
            </h3>
            <button
              onClick={handleSaveChanges}
              className="glow-button px-6 py-2 text-sm font-semibold"
            >
              <IoSaveOutline /> Save Changes
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <FeeControl
              app="Wash-a-Wash"
              currentFee={platformFees.wash}
              onFeeChange={(fee) => handleFeeChange('wash', fee)}
              description="Car washing and valeting services"
            />
            <FeeControl
              app="Wish-a-Pro"
              currentFee={platformFees.pro}
              onFeeChange={(fee) => handleFeeChange('pro', fee)}
              description="Professional home services"
            />
            <FeeControl
              app="Wish-a-Fix"
              currentFee={platformFees.fix}
              onFeeChange={(fee) => handleFeeChange('fix', fee)}
              description="Repair and maintenance services"
            />
          </div>
        </GlassCard>
      </motion.div>

      {/* Revenue Breakdown Table */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.4 }}
      >
        <GlassCard>
          <h3 className="text-xl font-poppins font-semibold text-primary-text mb-6">
            Revenue Breakdown by App
          </h3>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-white/10">
                  <th className="px-6 py-4 text-left text-sm font-semibold text-primary-text/70">App</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-primary-text/70">Total Jobs</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-primary-text/70">Gross Revenue</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-primary-text/70">Platform Fee (%)</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-primary-text/70">Platform Fee (£)</th>
                  <th className="px-6 py-4 text-left text-sm font-semibold text-primary-text/70">Net Revenue</th>
                </tr>
              </thead>
              <tbody>
                {appRevenueData.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-6 py-10 text-center text-sm text-primary-text/60">No revenue data available</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </GlassCard>
      </motion.div>

      {/* Fee History */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.5 }}
      >
        <GlassCard>
          <h3 className="text-xl font-poppins font-semibold text-primary-text mb-6">
            Fee Change History
          </h3>
          
          {feeHistory.length === 0 ? (
            <p className="text-primary-text/70 text-sm">No fee changes recorded</p>
          ) : (
            <div className="space-y-4" />
          )}
        </GlassCard>
      </motion.div>
    </div>
  );
};
