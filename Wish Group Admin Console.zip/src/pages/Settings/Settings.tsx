import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { GlassCard } from '../../components/GlassCard';
import { 
  IoNotificationsOutline, 
  IoShieldCheckmarkOutline,
  IoColorPaletteOutline,
  IoLanguageOutline,
  IoKeyOutline,
  IoTrendingUpOutline,
  IoBuildOutline,
  IoAlertCircleOutline,
  IoHeadsetOutline
} from 'react-icons/io5';

export const Settings: React.FC = () => {
  const [settings, setSettings] = useState({
    notifications: {
      email: true,
      push: false,
      sms: false
    },
    appearance: {
      theme: 'dark',
      compact: false
    },
    language: 'en',
    timezone: 'UTC',
    privacy: {
      dataTracking: true,
      analytics: true
    }
  });

  const handleThemeApply = (theme: string) => {
    // Apply theme to the document
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
    handleSelect('appearance', 'theme', theme);
  };

  // Initialize theme on load
  React.useEffect(() => {
    const savedTheme = localStorage.getItem('theme') || 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);
    handleSelect('appearance', 'theme', savedTheme);
  }, []);

  const handleToggle = (category: string, key: string) => {
    setSettings((prev: any) => ({
      ...prev,
      [category]: {
        ...prev[category],
        [key]: !prev[category][key]
      }
    }));
  };

  const handleSelect = (category: string, key: string, value: any) => {
    setSettings((prev: any) => ({
      ...prev,
      [category]: {
        ...prev[category],
        [key]: value
      }
    }));
  };

  const settingSections = [
    {
      icon: <IoNotificationsOutline className="text-2xl" />,
      title: 'Notifications',
      description: 'Manage how you receive notifications',
      content: (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-primary-text">Email Notifications</p>
              <p className="text-xs text-primary-text/60">Receive updates via email</p>
            </div>
            <button
              onClick={() => handleToggle('notifications', 'email')}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                settings.notifications.email ? 'bg-primary-accent' : 'bg-white/10'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  settings.notifications.email ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-primary-text">Push Notifications</p>
              <p className="text-xs text-primary-text/60">Browser push notifications</p>
            </div>
            <button
              onClick={() => handleToggle('notifications', 'push')}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                settings.notifications.push ? 'bg-primary-accent' : 'bg-white/10'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  settings.notifications.push ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-primary-text">SMS Notifications</p>
              <p className="text-xs text-primary-text/60">Text message alerts</p>
            </div>
            <button
              onClick={() => handleToggle('notifications', 'sms')}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                settings.notifications.sms ? 'bg-primary-accent' : 'bg-white/10'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  settings.notifications.sms ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>
      )
    },
    {
      icon: <IoColorPaletteOutline className="text-2xl" />,
      title: 'Appearance',
      description: 'Customize the look and feel',
      content: (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">Theme</label>
            <select
              value={settings.appearance.theme}
              onChange={(e) => handleThemeApply(e.target.value)}
              className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-primary-text focus:outline-none focus:border-primary-accent/50"
            >
              <option value="dark">Dark Mode</option>
              <option value="light-sky-blue">Light Mode - Sky Blue</option>
              <option value="light-navy">Light Mode - Navy</option>
              <option value="auto">Auto</option>
            </select>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-primary-text">Compact Mode</p>
              <p className="text-xs text-primary-text/60">Reduce spacing for more content</p>
            </div>
            <button
              onClick={() => handleToggle('appearance', 'compact')}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                settings.appearance.compact ? 'bg-primary-accent' : 'bg-white/10'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  settings.appearance.compact ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
        </div>
      )
    },
    {
      icon: <IoLanguageOutline className="text-2xl" />,
      title: 'Language & Region',
      description: 'Set your preferred language and timezone',
      content: (
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">Language</label>
            <select
              value={settings.language}
              onChange={(e) => handleSelect('settings', 'language', e.target.value)}
              className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-primary-text focus:outline-none focus:border-primary-accent/50"
            >
              <option value="en">English</option>
              <option value="es">Spanish</option>
              <option value="fr">French</option>
              <option value="de">German</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">Timezone</label>
            <select
              value={settings.timezone}
              onChange={(e) => handleSelect('settings', 'timezone', e.target.value)}
              className="w-full px-4 py-2 bg-white/5 border border-white/10 rounded-xl text-primary-text focus:outline-none focus:border-primary-accent/50"
            >
              <option value="UTC">UTC</option>
              <option value="EST">Eastern Time (EST)</option>
              <option value="PST">Pacific Time (PST)</option>
              <option value="GMT">GMT</option>
            </select>
          </div>
        </div>
      )
    },
    {
      icon: <IoShieldCheckmarkOutline className="text-2xl" />,
      title: 'Privacy & Security',
      description: 'Manage your data and security preferences',
      content: (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-primary-text">Data Tracking</p>
              <p className="text-xs text-primary-text/60">Help improve our services</p>
            </div>
            <button
              onClick={() => handleToggle('privacy', 'dataTracking')}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                settings.privacy.dataTracking ? 'bg-primary-accent' : 'bg-white/10'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  settings.privacy.dataTracking ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-primary-text">Analytics</p>
              <p className="text-xs text-primary-text/60">Share usage statistics</p>
            </div>
            <button
              onClick={() => handleToggle('privacy', 'analytics')}
              className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
                settings.privacy.analytics ? 'bg-primary-accent' : 'bg-white/10'
              }`}
            >
              <span
                className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                  settings.privacy.analytics ? 'translate-x-6' : 'translate-x-1'
                }`}
              />
            </button>
          </div>
          <button className="w-full mt-4 px-4 py-2 bg-danger/20 text-danger rounded-xl hover:bg-danger/30 transition-colors text-sm font-medium">
            Change Password
          </button>
        </div>
      )
    }
  ];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3 }}
      >
        <h1 className="text-3xl font-poppins font-bold text-primary-text mb-2">
          Settings
        </h1>
        <p className="text-primary-text/70">
          Manage your administrative preferences and account settings.
        </p>
      </motion.div>

      {/* Settings Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {settingSections.map((section, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3, delay: index * 0.1 }}
          >
            <GlassCard className="p-6">
              <div className="flex items-start space-x-4 mb-4">
                <div className="text-primary-accent">{section.icon}</div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-primary-text mb-1">
                    {section.title}
                  </h3>
                  <p className="text-sm text-primary-text/60">
                    {section.description}
                  </p>
                </div>
              </div>
              {section.content}
            </GlassCard>
          </motion.div>
        ))}
      </div>

      {/* Additional Actions */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.3, delay: 0.4 }}
      >
        <GlassCard className="p-6">
          <h3 className="text-lg font-semibold text-primary-text mb-4">Account Actions</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <button className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-colors">
              <IoKeyOutline className="text-2xl text-primary-text/70 mb-2" />
              <span className="text-sm text-primary-text">API Keys</span>
            </button>
            <button className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-colors">
              <IoLanguageOutline className="text-2xl text-primary-text/70 mb-2" />
              <span className="text-sm text-primary-text">Backups</span>
            </button>
            <button className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-colors">
              <IoHeadsetOutline className="text-2xl text-primary-text/70 mb-2" />
              <span className="text-sm text-primary-text">Support</span>
            </button>
            <button className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-colors">
              <IoTrendingUpOutline className="text-2xl text-primary-text/70 mb-2" />
              <span className="text-sm text-primary-text">Usage Stats</span>
            </button>
            <button className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-colors">
              <IoBuildOutline className="text-2xl text-primary-text/70 mb-2" />
              <span className="text-sm text-primary-text">Preferences</span>
            </button>
            <button className="flex flex-col items-center justify-center p-4 bg-white/5 rounded-xl hover:bg-white/10 transition-colors">
              <IoAlertCircleOutline className="text-2xl text-primary-text/70 mb-2" />
              <span className="text-sm text-primary-text">Advanced</span>
            </button>
          </div>
        </GlassCard>
      </motion.div>
    </div>
  );
};