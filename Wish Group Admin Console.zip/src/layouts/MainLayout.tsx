import React, { useState, useEffect } from 'react';
import { SidebarNav } from '../components/SidebarNav';
import { HeaderBar } from '../components/HeaderBar';

interface MainLayoutProps {
  children: React.ReactNode;
  onLogout?: () => void;
}

export const MainLayout: React.FC<MainLayoutProps> = ({ children, onLogout }) => {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  // Initialize theme on load
  useEffect(() => {
    const savedTheme = localStorage.getItem('theme') || 'dark';
    document.documentElement.setAttribute('data-theme', savedTheme);
  }, []);

  const handleLogout = () => {
    if (onLogout) {
      onLogout();
    }
  };

  return (
    <div className="min-h-screen bg-primary-bg flex">
      <SidebarNav 
        collapsed={sidebarCollapsed} 
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)} 
      />
      <div className="flex-1 flex flex-col">
        <HeaderBar 
          onMenuToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
          onLogout={handleLogout}
        />
        <main className="flex-1 p-6 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
};
