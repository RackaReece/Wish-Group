import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { MainLayout } from './layouts/MainLayout';
import { Dashboard } from './pages/Dashboard/Dashboard';
import { ProsUsers } from './pages/ProsUsers/ProsUsers';
import { Documents } from './pages/Documents/Documents';
import { Reviews } from './pages/Reviews/Reviews';
import { Disputes } from './pages/Disputes/Disputes';
import { Revenue } from './pages/Revenue/Revenue';
import { Analytics } from './pages/Analytics/Analytics';
import { Reports } from './pages/Reports/Reports';
import { Broadcasts } from './pages/Broadcasts/Broadcasts';
import { Promotions } from './pages/Promotions/Promotions';
import { Settings } from './pages/Settings/Settings';
import { Login } from './pages/Login/Login';

function App() {
  // TODO: This will be replaced with actual authentication state management
  // To test the login page, change this to false
  const [isAuthenticated, setIsAuthenticated] = useState(true);

  const handleLogout = () => {
    setIsAuthenticated(false);
  };

  // If not authenticated, show login page
  if (!isAuthenticated) {
    return (
      <Router>
        <Login onLogin={() => setIsAuthenticated(true)} />
      </Router>
    );
  }

  return (
    <Router>
      <MainLayout onLogout={handleLogout}>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/pros-users" element={<ProsUsers />} />
          <Route path="/documents" element={<Documents />} />
          <Route path="/reviews" element={<Reviews />} />
          <Route path="/disputes" element={<Disputes />} />
          <Route path="/revenue" element={<Revenue />} />
          <Route path="/analytics" element={<Analytics />} />
          <Route path="/reports" element={<Reports />} />
          <Route path="/broadcasts" element={<Broadcasts />} />
          <Route path="/promotions" element={<Promotions />} />
          <Route path="/settings" element={<Settings />} />
        </Routes>
      </MainLayout>
    </Router>
  );
}

export default App;
