# Wish Group Admin Console 2.0

A modern, glass-blue web app admin console that controls the entire Wish Group ecosystem: Wish-a-Wash, Wish-a-Pro, and Wish-a-Fix.

## 🎨 Design System

- **Primary Background**: #061229 (Dark Navy)
- **Accent Colour**: #0A84FF (Electric Blue)
- **Secondary Accent**: #00E5FF (Cyan)
- **Success/Danger**: #00C853 / #FF3B30
- **Text Primary**: #EAF1FF
- **Card Background**: rgba(255,255,255,0.06) + backdrop-blur(14px)
- **Border Radius**: 18px
- **Fonts**: Inter / Poppins (semibold headings)

## 🚀 Features

### 📊 Dashboard
- Real-time KPIs and metrics
- Interactive charts and visualisations
- Quick action buttons
- System status monitoring
- Mini heat map of active jobs

### 👥 Pros & Users Management
- Comprehensive user management
- Document verification system
- Approval/rejection workflows
- Detailed user profiles with verification status

### 📄 Documents & Verification
- Grid view of pending documents
- Batch approval/rejection actions
- Document preview modals
- Filter by document type

### ⭐ Reviews & Ratings
- Review management across all apps
- Rating trend analysis
- Flagging system for problematic reviews
- Performance metrics

### ⚖️ Disputes Management
- Chat-style dispute resolution interface
- Status tracking and escalation
- Resolution workflow management
- Performance analytics

### 💰 Revenue & Fees
- Real-time revenue tracking
- **Editable platform fee controls** with sliders
- Revenue breakdown by app
- Fee change history tracking

### 📈 Analytics
- Multi-chart analytics dashboard
- User engagement metrics
- Conversion funnel analysis
- Export capabilities (CSV/PDF)

### 📋 Reports
- Automated report generation
- Custom date range reports
- Multiple export formats
- Report history management

### 📢 Broadcast Center
- Create targeted announcements
- Audience segmentation
- Performance tracking
- Schedule management

### 🎯 Promotions
- Campaign management
- Usage tracking and analytics
- Toggle on/off functionality
- Performance metrics

### ⚙️ Settings
- Branding customisation
- System configuration
- Admin management
- Notification preferences

## 🛠️ Technology Stack

- **React 18** with TypeScript
- **TailwindCSS** for styling
- **Framer Motion** for animations
- **Recharts** for data visualisation
- **React Router** for navigation

## 🚀 Getting Started

1. **Install Dependencies**
   ```bash
   npm install
   ```

2. **Start Development Server**
   ```bash
   npm start
   ```

3. **Open Browser**
   Navigate to `http://localhost:3000`

## 📱 Responsive Design

The admin console is fully responsive and works seamlessly across:
- Desktop (1200px+)
- Tablet (768px - 1199px)
- Mobile (320px - 767px)

## 🎨 UI Components

### Core Components
- `GlassCard` - Main container with glass morphism effect
- `StatCard` - KPI display cards with trend indicators
- `Table` - Sortable, paginated data tables
- `Modal` - Glass overlay modals with animations
- `ChartCard` - Recharts integration wrapper

### Specialised Components
- `FeeControl` - Interactive platform fee sliders
- `BroadcastForm` - Multi-step broadcast creation
- `PromotionCard` - Promotion management cards
- `ToggleSwitch` - Animated toggle switches

## 🔧 Key Features

### Platform Fee Management
The revenue page includes interactive sliders for each app (Wash-a-Wash, Wish-a-Pro, Wish-a-Fix) allowing real-time adjustment of platform fees with visual feedback and change tracking.

### Glass Morphism Design
Consistent glass morphism effects throughout the interface with:
- Semi-transparent backgrounds
- Backdrop blur effects
- Subtle borders and glows
- Smooth hover animations

### Real-time Data
All data is mock-generated but structured to easily integrate with real APIs. The interface includes:
- Live updating KPIs
- Interactive charts
- Real-time status indicators
- Dynamic content loading

## 📊 Data Structure

The application uses mock data that follows realistic patterns:
- User management with verification statuses
- Revenue tracking with platform fee calculations
- Review and rating systems
- Dispute resolution workflows
- Promotion campaign management

## 🎯 Performance

- Optimised for smooth 60fps animations
- Lazy loading for large datasets
- Efficient re-rendering with React hooks
- Responsive image handling
- Minimal bundle size

## 🔒 Security Considerations

- Input validation on all forms
- XSS protection in text rendering
- Secure file upload handling
- Admin role management
- Audit logging for sensitive actions

## 📈 Future Enhancements

- Real-time WebSocket integration
- Advanced analytics with machine learning
- Mobile app companion
- API rate limiting dashboard
- Advanced user segmentation
- Automated report scheduling

## 🤝 Contributing

This is a UI shell project designed for demonstration purposes. All interactions are logged to console for easy integration with backend services.

## 📄 License

This project is part of the Wish Group ecosystem and is proprietary software.

---

**Built with ❤️ for the Wish Group ecosystem**
