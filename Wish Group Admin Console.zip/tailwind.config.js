/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          bg: 'var(--primary-bg)',
          accent: 'var(--primary-accent)',
          'accent-secondary': '#00E5FF',
          text: 'var(--primary-text)',
          'bg-secondary': 'var(--primary-bg-secondary)',
        },
        success: '#00C853',
        danger: '#FF3B30',
        glass: 'rgba(255,255,255,0.06)',
      },
      fontFamily: {
        'inter': ['Inter', 'sans-serif'],
        'poppins': ['Poppins', 'sans-serif'],
      },
      borderRadius: {
        'glass': '18px',
      },
      backdropBlur: {
        'glass': '14px',
      },
      boxShadow: {
        'glow': '0 0 20px rgba(10, 132, 255, 0.3)',
        'glow-soft': '0 0 10px rgba(10, 132, 255, 0.2)',
      },
    },
  },
  plugins: [],
}
